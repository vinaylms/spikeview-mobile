import 'dart:io';
import 'dart:typed_data';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:thumbnails/thumbnails.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';



class VideoViewBlack extends StatefulWidget {
  final String path;
  bool isPlay = false;
  bool isLoader = false;
  String feedId;
  String type;

  VideoViewBlack(this.path, this.feedId,this.isLoader,this.type);

  @override
  State createState() {
    return _VideoViewBlackState();
  }
}



class _VideoViewBlackState extends State<VideoViewBlack> {
  VoidCallback listener;
  bool isApiNeedToCall = true;



  VideoPlayerController controller;
  ChewieController _chewieController;



  // ChewieController _chewieController;



  @override
  void initState() {
    super.initState();
    controller =
        VideoPlayerController.network(widget.path.replaceAll(" ", "%20"));



    controller.setVolume(0.0);



    controller.pause();
    controller.initialize();
    // controller.seekTo(Duration(seconds: 5));
  }



  @override
  void deactivate() {
    controller.setVolume(0.0);
    controller.removeListener(listener);
    //_chewieController.dispose();
    super.deactivate();
  }



  @override
  Widget build(BuildContext context) {
    final List<Widget> children = <Widget>[
      Container(
        width:controller.value.aspectRatio,
        child: controller.value.initialized

            ? AspectRatio(
          aspectRatio: controller.value.aspectRatio,
          child: VideoPlayer(controller),
        )
            : Container(

          color: Colors.black,
        ),),





    ];


    return Stack(
      alignment: Alignment.bottomCenter,
      fit: StackFit.passthrough,
      children: children,
    );
  }
}