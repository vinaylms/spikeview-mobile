import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(),
        body: Stack(
          children: [
            Positioned(
              top: 84,
              left: 316,
              child: Image.asset('assets/newFeature/Group 4531.png', height: 56, width: 56),
            ),
            Positioned(
              top: 119,
              left: 247,
              child: Image.asset('assets/newFeature/Group 4532.png', height: 104.9, width: 85.96),
            ),

            Positioned(
              top: 213,
              left: 184,
              child: Center(
                child: Text('Community Post',
                    style: TextStyle(fontSize: 18, fontFamily: 'Nunito', fontWeight: FontWeight.w600, color: Colors.white)),
              ),
            ),

            Positioned(
              top: 237,
              left: 142,
              child: Center(
                child: Text('Ac amet non adipiscing, vitae, habitasse.',
                    style: TextStyle(fontSize: 12, fontFamily: 'Nunito', fontWeight: FontWeight.w600, color: Colors.white)),
              ),
            ),
          ],
        )
    );
  }
}
