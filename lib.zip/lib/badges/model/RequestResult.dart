class RequestResult {
  RequestResult({
      this.badgeReqId, 
      this.message, 
      this.status, 
      this.date, 
      this.type, 
      this.name, 
      this.image, 
      this.reminderDay, 
      this.badgeId, 
      this.companyName,
  this.isReminderEnable,
  this.userImage,this.userName,this.userTagline
    ,this.userId,
    this.userRoleId});

  RequestResult.fromJson(dynamic json) {
    badgeReqId = json['badgeReqId'];
    message = json['message'];
    status = json['status'];
    date = json['date'];
    type = json['type'];
    name = json['name'];
    image = json['image'];
    reminderDay = json['reminderDay'];
    badgeId = json['badgeId'];
    companyName = json['companyName'];
    isReminderEnable =json['isReminderEnable'];
    userImage = json['userImage'];
    userName = json['userName'];
    userTagline = json['userTagline'];
    userId = json['userId'].toString();
    userRoleId = json['userRoleId'].toString();
  }
  int badgeReqId;
  String message;
  String status;
  int date;
  String type;
  String name;
  String image;
  String userId;
  String userRoleId;
  int reminderDay;
  int badgeId;
  String companyName,userImage, userName, userTagline;
  bool isReminderEnable;
  bool isMore = false;
  bool showReminderTimer =false;
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['badgeReqId'] = badgeReqId;
    map['message'] = message;
    map['status'] = status;
    map['date'] = date;
    map['type'] = type;
    map['name'] = name;
    map['image'] = image;
    map['reminderDay'] = reminderDay;
    map['badgeId'] = badgeId;
    map['companyName'] = companyName;
    map['isReminderEnable'] = isReminderEnable;
    map['userImage'] = userImage;
    map['userName'] = userName;
    map['userTagline'] = userTagline;
    map['userId'] = userId;
    map['userRoleId'] = userRoleId;
    return map;
  }

}