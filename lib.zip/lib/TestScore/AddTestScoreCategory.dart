import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TestScoreModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:url_launcher/url_launcher.dart';

import 'AddTestScoreCategoryForm.dart';

// Create a Form Widget
class AddTestScoreCategory extends StatefulWidget {
  ProfileData profileInfoModal;
  List<SebjectDetailModel> subjectListModel;
  TestScoreModel testScoreModel;
  String testName = '';
  int testId;

  AddTestScoreCategory(
    this.profileInfoModal,
    this.subjectListModel,
    this.testName,
    this.testId,
    this.testScoreModel,
  );

  @override
  AddTestScoreCategoryState createState() {
    return AddTestScoreCategoryState();
  }
}

class AddTestScoreCategoryState extends State<AddTestScoreCategory> {
  ScrollController _controller = ScrollController();
  String isPerformChanges = "pop";
  String userIdPref;

  bool isValid = true;
  bool isTestSelected = false;
  File mediaImage;

  String dob;

  getSharedPreferences() async {
    userIdPref = widget.profileInfoModal.userId;
    dob = widget.profileInfoModal.dob;
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();
    super.initState();
  }

  //--------------------------Delete Education Data ------------------

  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Column getCompetencyItem(position) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
            20.0,
            0.0,
            20.0,
            0.0,
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    //                   <--- left side
                    color: Color(0xffE5EBF0),
                    width: 1.0,
                  ),
                ),
              ),
              child: InkWell(
                child: Padding(
                  padding: const EdgeInsets.only(
                    top: 14.0,
                    bottom: 14,
                  ),
                  child: BaseText(
                    text: widget.subjectListModel[position].subjectName,
                    textColor: widget.subjectListModel[position].isSelected
                        ? ColorValues.BLUE_COLOR_BOTTOMBAR
                        : AppConstants.colorStyle.darkBlue,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 18,
                    maxLines: 3,
                  ),
                ),
                onTap: () async {
                  var result = await Navigator.of(context).push(
                      new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              AddTestScoreCategoryForm(
                                  widget.profileInfoModal,
                                  widget.subjectListModel,
                                  widget.testName,
                                  widget.testId,
                                  widget.testScoreModel,
                                  position)));

                  if (result != null && result) {
                    Navigator.pop(context, result);
                  }
                },
              ),
            ),
          ),
        ],
      );
    }

    return GestureDetector(
      child: WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: GestureDetector(
          child: customAppbar(
            context,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0, right: 20, top: 24, bottom: 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        BaseText(
                          text: widget.testName,
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w700,
                          fontSize: 28,
                          textAlign: TextAlign.start,
                          maxLines: 3,
                        ),
                      ],
                    ),
                  ),
                  flex: 0,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                    child: widget.subjectListModel.length > 0
                        ? ListView.builder(
                            controller: _controller,
                            itemCount: widget.subjectListModel.length,
                            itemBuilder: (BuildContext context, int position) {
                              return getCompetencyItem(position);
                            })
                        : Container(
                            height: 0.0,
                          ),
                  ),
                  flex: 1,
                ),
              ],
            ),
            () {
              Navigator.pop(context);
            },
            isShowIcon: false,
          ),
        ),
      ),
    );
  }
}
