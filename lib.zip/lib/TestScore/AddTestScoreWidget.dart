import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TestScoreModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:url_launcher/url_launcher.dart';

// Create a Form Widget
class AddTestScoreWidget extends StatefulWidget {
  ProfileInfoModal profileInfoModal;

  AddTestScoreWidget(this.profileInfoModal);

  @override
  AddTestScoreWidgetState createState() {
    return AddTestScoreWidgetState();
  }
}

class AddTestScoreWidgetState extends State<AddTestScoreWidget> {
  List<TestScoreModel> testList = List();
  ScrollController _controller = ScrollController();
  String isPerformChanges = "pop";
  String userIdPref;
  SharedPreferences prefs;
  TextEditingController dobController;
  int strDateOfBirth = 0;
  DateTime pickedDate;
  bool isValid = true;
  bool isTestSelected = false;
  String previousTestScorePosition = "", previousSubjectPosition = "";
  File mediaImage;
  File imagePath;
  UploadMedia uploadMedia;

  //List<String> dataValue =     List();
  List<String> mediaDocumentList = List();
  List<String> mediaList = List();
  List<String> mediaImagesList = List();
  String sasToken, containerName, strPrefixPathforPhoto;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  final formKey = GlobalKey<FormState>();
  DateTime startDate;
  Map<int, String> dataValue = {};
  String dob;

  FocusNode textFocus0 = FocusNode();
  FocusNode textFocus1 = FocusNode();
  FocusNode textFocus2 = FocusNode();
  FocusNode textFocus3 = FocusNode();
  FocusNode textFocus4 = FocusNode();
  FocusNode textFocus5 = FocusNode();
  FocusNode textFocus6 = FocusNode();
  FocusNode textFocus7 = FocusNode();
  FocusNode textFocus8 = FocusNode();
  FocusNode textFocus9 = FocusNode();
  FocusNode textFocus10 = FocusNode();
  FocusNode textFocus11 = FocusNode();
  FocusNode textFocus12 = FocusNode();
  FocusNode textFocus13 = FocusNode();
  FocusNode textFocus14 = FocusNode();
  FocusNode textFocus15 = FocusNode();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    dob = widget.profileInfoModal.dob;
    if (dob != null) {
      int d = int.tryParse(dob);
      startDate = DateTime.fromMillisecondsSinceEpoch(d);
      setState(() {
        startDate;
      });
    } else {
      startDate = DateTime.now();
    }
    dobController = TextEditingController(text: '');
    mediaDocumentList.add(null);
    mediaImagesList.add(null);
    TestDataApi(true);
    callApiForSaas();

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
  }

  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_APP_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();
    super.initState();
  }

  showSucessMsg(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: AppTextStyle.getDynamicStyleGroup(
                                        ColorValues.dark_Green,
                                        13.0,
                                        FontType
                                            .Regular), *//* TextStyle(
                                        color:     Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),*//*
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));*/

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            negativeText: 'OK',
            msg: msg,
            isSucessPopup: true,
            onNegativeTap: (){
              Navigator.pop(context, "push");
            },
          );
        });
  }

  Future apiCalling(model, addIntoProfile) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;
        mediaDocumentList.removeAt(0);
        mediaImagesList.removeAt(0);
        mediaList.addAll(mediaImagesList);
        //  mediaList.addAll(mediaDocumentList);
        List<ScoreModel> scoreList = List();
        dataValue.forEach((k, v) {
          if (v == null || v == "null") {
            v = "";
          }
          scoreList.add(new ScoreModel(v, k));
        });

        Map map = {
          "testId": model.testId,
          "userId": userIdPref,
          "dateTaken": strDateOfBirth,
          "docUrl": mediaDocumentList.map((item) => item).toList(),
          "imageUrl": mediaImagesList.map((item) => item).toList(),
          "score": scoreList.map((item) => item.toJson()).toList(),
          "addIntoProfile": addIntoProfile
        };

        print("map+++" + map.toString());
        response = await ApiCalling2().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_TEST_SCORE_DATA, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              isPerformChanges = "push";
              showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        mediaDocumentList.add("");
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      mediaDocumentList.add("");
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future TestDataApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_TEST_SCORE_DATA, "get");

        print("response education" + response.toString());

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              testList.clear();
              testList = ParseJson.parseTestScoreData(response.data['result']);
              if (testList.length > 0) {
                if (mounted) {
                  setState(() {
                    testList;
                  });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------Delete Education Data ------------------

  Widget build(BuildContext context) {
    Constant.applicationContext = context;
//============================================ grid view achevements nd core logic =====================================

    resetSelection(currentPoition) {
      dataValue = {};
      strDateOfBirth = 0;
      dobController = TextEditingController(text: '');
      isValid = true;

      if (previousSubjectPosition == "") {
        if (previousTestScorePosition != "")
          testList[int.parse(previousTestScorePosition)].isSelected = false;
      } else {
        if (currentPoition == previousTestScorePosition)
          testList[int.parse(previousTestScorePosition)]
              .subjectListModel[int.parse(previousSubjectPosition)]
              .isSelected = false;
        else {
          testList[int.parse(previousTestScorePosition)].isSelected = false;
          testList[int.parse(previousTestScorePosition)]
              .subjectListModel[int.parse(previousSubjectPosition)]
              .isSelected = false;
        }
      }
    }

    Future<Null> selectDob(BuildContext context) async {
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime: DateTime.now(),
        initialDateTime: pickedDate == null ? DateTime.now() : pickedDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());

          if (dateTime != null) {
            pickedDate = dateTime;
            strDateOfBirth = dateTime.millisecondsSinceEpoch;
            String date = Util.getDate(dateTime);

            setState(() {
              isValid = true;
              pickedDate;

              dobController = TextEditingController(text: date);
            });
          } else {
            FocusScope.of(context).requestFocus(new FocusNode());
          }
        },
      );
    }

    final dateOBUI = InkWell(
      child: Container(
        padding: EdgeInsets.only(left: 0.0, top: 0.0, right: 0.0, bottom: 0.0),
        child: TextField(
          keyboardType: TextInputType.text,
          controller: dobController,
          enabled: (!isValid),
          onTap: () {
            setState(() {
              selectDob(context);
            });
          },
          style: TextStyle(
              color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
          decoration: /*BaseCommonWidget.textFormFieldDecorationAddTest(
              MessageConstant.TEXT_SCORE_DATE_TAKEN,
              "",
              (!isValid) ? MessageConstant.SELECT_DATE_TAKEN_VAL : null,
              14.0), */ InputDecoration(

            errorStyle: Util.errorTextStyle,
            contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            errorText: (!isValid) ? MessageConstant.SELECT_DATE_TAKEN_VAL : null,
            disabledBorder:     UnderlineInputBorder(
                borderSide:     BorderSide(
                    color:     ColorValues.DARK_GREY,width: 1.0)),
            enabledBorder:     UnderlineInputBorder(
                borderSide:     BorderSide(
                    color:     ColorValues.DARK_GREY,width: 1.0)),

          ),
        ),
      ),
      onTap: () {
        selectDob(context);
      },
    );
    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      setState(() {});

      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        if (type == "doc") {
          mediaDocumentList.add(path);
          setState(() {
            mediaDocumentList;
          });
        } else {
          mediaImagesList.add(path);
          setState(() {
            mediaImagesList;
          });
        }

        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    getDocuments() async {
      try {
        // Platform messages may fail, so we use a try/catch PlatformException.
        try {
          FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
            allowedFileExtensions: ['pdf'],
            allowedMimeTypes: ['application/pdf'],
            invalidFileNameSymbols: ['/'],
          );

          String path =
              await FlutterDocumentPicker.openDocument(params: params);
          if (path != null && path != "") {
            if ((Util.getFileExtension(path) == ".pdf") && path != null) {
              print("path+++++" + path.toString());

              CustomProgressLoader.showLoader(context);
              Timer _timer = Timer(const Duration(milliseconds: 400), () {
                checkMediaAndUpload(
                    imagePath: path
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    type: "doc");
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.INVALID_FILE_FORMAT_VAL, context);
            }
          }
        } catch (e) {
          ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
        }
      } catch (e) {
        ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
      }
    }

    void conformationDialog(type, file) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      MessageConstant
                                                          .REMOVE_NAME,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: AppTextStyle
                                                          .getDynamicStyleGroupHEIGHT(
                                                              ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontType.Regular,
                                                              1.2),
                                                      /*TextStyle(
                                                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),*/
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        16.0,
                                                        FontType.Regular),
                                                /*TextStyle(
                                                        color:     ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.REMOVE,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        16.0,
                                                        FontType.Regular),
                                                /* TextStyle(
                                                        color:      ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (type == "image") {
                                                  mediaImagesList.remove(file);
                                                  setState(() {
                                                    mediaImagesList;
                                                  });
                                                } else if (type == "doc") {
                                                  mediaDocumentList
                                                      .remove(file);
                                                  setState(() {
                                                    mediaDocumentList;
                                                  });
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }

    onTapImageAddButton() async {
      mediaImage = await UploadMedia(context).pickImageFromGallery();

     // mediaImage = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (mediaImage != null) {
        imagePath = mediaImage;
        //await _cropImage(mediaImage);
        if (imagePath != null) {
          CustomProgressLoader.showLoader(context);
          Timer _timer = Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "image");
          });
        }
      } else {
        //ToastWrap.showToast("'No file was selected'", context);
      }
    }

    final mediaImageListUIData = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaImagesList.map((file) {
        if (file == null) {
          return Stack(children: <Widget>[
            InkWell(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                child: Container(
                    height: 54.0,
                    width: 80.0,
                    decoration: BoxDecoration(
                        border: Border.all(
                            color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                    child: Image.asset(
                      "assets/newDesignIcon/userprofile/add.png",
                      height: 25.0,
                      width: 25.0,
                    )),
              ),
              onTap: () async {
                var status = await Permission.photos.status;
                if (status.isGranted) {
                  onTapImageAddButton();
                } else {
                  checkPermissionPhoto(context);
                }
              },
            )
          ]);
        } else {
          return Container(
              height: 60.0,
              child: Stack(
                children: <Widget>[
                  Positioned(
                    top: 5.0,
                    child: new Column(
                      children: <Widget>[
                        FadeInImage.assetNetwork(
                          fit: BoxFit.cover,
                          placeholder: 'assets/aerial/default_img.png',
                          image: Constant.IMAGE_PATH + file,
                          height: 50.0,
                          width: 75.0,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                    child: Container(
                      height: 50.0,
                      width: 75.0,
                      color: Color(0XFFC0C0C0).withOpacity(.4),
                    ),
                  ),
                  Positioned(
                      right: 20.0,
                      top: 0.0,
                      bottom: 0.0,
                      left: 0.0,
                      child: Container(
                          height: 20.0,
                          width: 20.0,
                          child: Center(
                              child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                      Image.asset(
                                        "assets/remove_grey.png",
                                        width: 20.0,
                                        height: 20.0,
                                      )),
                                  onTap: () {
                                    conformationDialog("image", file);
                                  })
                            ],
                          )))),
                ],
              ));
        }
      }).toList(),
    ));

    final docListUiData =     Container(
        padding:     EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 20.0),
        child:     GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.50,
          scrollDirection: Axis.vertical,
          crossAxisCount: 4,
          children: mediaDocumentList.map((file) {
            if (file == null) {
              return     Stack(children: <Widget>[
                InkWell(
                  child:   Padding(
                      padding: const EdgeInsets.fromLTRB(0.0,5,20,0),
                      child:new Container(
                          height: 54.0,
                          width: 58.0,
                          decoration:     BoxDecoration(border:     Border.all(color:     ColorValues.LIGHT_GREY_TEXT_COLOR)),
                          child:     Image.asset(
                            "assets/newDesignIcon/userprofile/add.png",
                            height: 25.0,
                            width: 25.0,
                          ))),
                  onTap: ()async {
                    if (mediaDocumentList.length <= 5) {
                      getDocuments();
                      /* var status = await Permission.storage.status;
                      if (status.isGranted) {
                        getDocuments();
                      }  else {
                        checkStoragePermissionStorage(context);
                      }*/
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
                    }
                  },
                )
              ]);


            } else {
              return      Stack(
                children: <Widget>[
                  Padding(
                      padding: const EdgeInsets.fromLTRB(7.0,5,20,0),
                      child:      Container(
                          decoration:     BoxDecoration(border:     Border.all(color:     ColorValues.LIGHT_GREY_TEXT_COLOR)),
                          child:     InkWell(child:Padding(
                            padding: const EdgeInsets.all(5.0),
                            child:     Container(
                                height: 58.0,
                                width: 58.0,
                                child:     Image.asset(
                                  "assets/newDesignIcon/patner/pdf.png",
                                  height: 58.0,
                                  width: 58.0,
                                )),
                          ),onTap: (){
                            launch(Constant.IMAGE_PATH +file);
                          },))),
                  Positioned(
                      right: 10.0,
                      top: 0.0,
                      child:     Container(
                          height: 20.0,
                          width: 20.0,
                          child:     Center(
                              child:     Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                          Image.asset(
                                            "assets/remove_grey.png",
                                            width: 20.0,
                                            height: 20.0,
                                          )),
                                      onTap: () {
                                        conformationDialog("doc",file);
                                      })
                                ],
                              )))),
                ],

              );


            }
          }).toList(),
        ));

    void conformationDialogForCommunityPost(model) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      MessageConstant
                                                          .TEXT_SCORE_DO_YOU_WANT_PUBLISH,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: AppTextStyle
                                                          .getDynamicStyleGroupHEIGHT(
                                                              ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontType.Regular,
                                                              1.2),
                                                      /* TextStyle(
                                                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),*/
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.NO,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        16.0,
                                                        FontType.Regular),
                                                /* TextStyle(
                                                        color:     ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCalling(model, false);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.YES,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        16.0,
                                                        FontType.Regular),
                                                /*TextStyle(
                                                        color:      ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCalling(model, true);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void _checkValidation(TestScoreModel model) async {
      final form = formKey.currentState;
      form.save();

      if (form.validate()) {
        if (strDateOfBirth != 0) {
          isValid = true;

          if (Util.dobCheck(widget.profileInfoModal.dob) &&
              widget.profileInfoModal.publicUrl != null &&
              widget.profileInfoModal.publicUrl != "null" &&
              widget.profileInfoModal.publicUrl != "") {
            conformationDialogForCommunityPost(model);
          } else {
            apiCalling(model, false);
          }
        } else {
          isValid = false;
        }
      } else {
        if (strDateOfBirth == 0) {
          isValid = false;
        }
      }
      setState(() {});
    }

    void takeNumber(String text, int name) {
      try {
        //  int number = int.parse(text);
        dataValue[name] = text;
        print(dataValue);
      } on FormatException {}
    }

    validateMethod(SebjectDetailModel model, value) {
      if (value >= model.minScore && value <= model.maxScore) {
        return null;
      }

      return "Please enter value between " +
          model.minScore.toString() +
          "-" +
          model.maxScore.toString();
    }

    Widget getFormViewUi(isMultipleSubject, position, subjectPosition) {
      return PaddingWrap.paddingfromLTRB(
          0.0,
          0.0,
          0.0,
          5.0,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                          color: ColorValues.DEVIDER_COLOR, width: 1.0)),
                  child: PaddingWrap.paddingfromLTRB(
                    13.0,
                    10.0,
                    13.0,
                    20.0,
                    Form(
                        key: formKey,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[

                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  5.0,
                                  0.0,
                                  0.0,
                                  Text(
                                    MessageConstant.TEXT_SCORE_DATE_TAKEN,
                                    style: TextStyle(
                                        color: ColorValues
                                            .GREY_TEXT_COLOR,
                                        fontFamily: Constant
                                            .TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  )),
                              dateOBUI,

                              isMultipleSubject
                                  ? Column(
                                      children: List.generate(
                                      testList[position]
                                          .subjectListModel
                                          .length,
                                      (int subjectIndex) {
                                        SebjectDetailModel modelData =
                                            testList[position]
                                                .subjectListModel[subjectIndex];
                                        return  Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children:  <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  15.0,
                                                  0.0,
                                                  0.0,
                                                  Text(
                                                    modelData.subjectName +
                                                        "(" +
                                                        modelData.minScore
                                                            .toString() +
                                                        "-" +
                                                        modelData.maxScore
                                                            .toString() +
                                                        ")",
                                                    maxLines: 2,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR,
                                                        fontSize: 14.0),
                                                  )),
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    left: 0.0,
                                                    top: 0.0,
                                                    right: 0.0,
                                                    bottom: 0.0),
                                                child: TextFormField(                                              keyboardType:
                                                TextInputType.number,

                                                  focusNode: subjectIndex == 0
                                                      ? textFocus0
                                                      : subjectIndex == 1
                                                      ? textFocus1
                                                      : subjectIndex == 2
                                                      ? textFocus2
                                                      : subjectIndex == 3
                                                      ? textFocus3
                                                      : subjectIndex ==
                                                      4
                                                      ? textFocus4
                                                      : subjectIndex ==
                                                      5
                                                      ? textFocus5
                                                      : subjectIndex ==
                                                      6
                                                      ? textFocus6
                                                      : subjectIndex == 7
                                                      ? textFocus7
                                                      : subjectIndex == 8
                                                      ? textFocus8
                                                      : subjectIndex == 9
                                                      ? textFocus9
                                                      : subjectIndex == 10
                                                      ? textFocus10
                                                      : subjectIndex == 11
                                                      ? textFocus11
                                                      : subjectIndex == 12
                                                      ? textFocus12
                                                      : subjectIndex == 13
                                                      ? textFocus13
                                                      : subjectIndex == 14
                                                      ? textFocus14
                                                      : textFocus15,
                                                  cursorColor:
                                                  Constant.CURSOR_COLOR,
                                                  inputFormatters: <TextInputFormatter>[
                                                    WhitelistingTextInputFormatter.digitsOnly

                                                  ],
                                                  validator: (val) => modelData
                                                      .isOptional &&
                                                      (val == null || val == "")
                                                      ? null
                                                      : validateMethod(
                                                      modelData,
                                                      val != null && val != ""
                                                          ? int.parse(val)
                                                          : 0),
                                                  onSaved: (text) {
                                                    takeNumber(
                                                        text, modelData.testSubId);
                                                  },
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                  decoration: InputDecoration(
                                                    contentPadding:
                                                    const EdgeInsets.fromLTRB(
                                                        0.0, 0.0, 0.0, 0.0),
                                                    counterText: "",
                                                    focusedBorder:
                                                    UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: ColorValues
                                                                .DARK_GREY,
                                                            width: 1.0)),
                                                    enabledBorder:
                                                    UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: ColorValues
                                                                .DARK_GREY,
                                                            width: 1.0)),
                                                    counterStyle: TextStyle(
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                    /* labelText:
                                                    modelData.subjectName +
                                                        "(" +
                                                        modelData.minScore
                                                            .toString() +
                                                        "-" +
                                                        modelData.maxScore
                                                            .toString() +
                                                        ")",*/
                                                    errorStyle: TextStyle(
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                    ),
                                                    disabledBorder:
                                                    UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: ColorValues
                                                                .DARK_GREY,
                                                            width: 1.0)),
                                                  ),
                                                ),
                                              )
                                            ]);
                                      },
                                    ))
                                  :  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:  <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        15.0,
                                        0.0,
                                        0.0,
                                        Text(
                                          testList[position]
                                              .subjectListModel[
                                          subjectPosition]
                                              .subjectName +
                                              "(" +
                                              testList[position]
                                                  .subjectListModel[
                                              subjectPosition]
                                                  .minScore
                                                  .toString() +
                                              "-" +
                                              testList[position]
                                                  .subjectListModel[
                                              subjectPosition]
                                                  .maxScore
                                                  .toString() +
                                              ")",
                                          maxLines: 2,
                                          style: TextStyle(
                                              color:
                                              ColorValues.GREY_TEXT_COLOR,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 14.0),
                                        )),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          left: 0.0,
                                          top: 0.0,
                                          right: 0.0,
                                          bottom: 0.0),
                                      child: TextFormField(
                                        keyboardType: TextInputType.number,
                                        cursorColor: Constant.CURSOR_COLOR,
                                        inputFormatters: <TextInputFormatter>[
                                          WhitelistingTextInputFormatter.digitsOnly

                                        ],
                                        validator: (val) => testList[position]
                                            .subjectListModel[
                                        subjectPosition]
                                            .isOptional
                                            ? null
                                            : validateMethod(
                                            testList[position]
                                                .subjectListModel[
                                            subjectPosition],
                                            val != null && val != ""
                                                ? int.parse(val)
                                                : 0),
                                        onSaved: (text) {
                                          takeNumber(
                                              text,
                                              testList[position]
                                                  .subjectListModel[
                                              subjectPosition]
                                                  .testSubId);
                                        },
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR),
                                        decoration: InputDecoration(
                                          contentPadding:
                                          const EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          counterText: "",
                                          counterStyle: TextStyle(
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                          focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color:
                                                  ColorValues.DARK_GREY,
                                                  width: 1.0)),
                                          enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color:
                                                  ColorValues.DARK_GREY,
                                                  width: 1.0)),

                                          errorStyle: Util.errorTextStyle,

                                          disabledBorder:
                                          UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: ColorValues
                                                      .DARK_GREY,
                                                  width: 1.0)),
                                        ),
                                      ),
                                    )
                                  ]),
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  20.0,
                                  0.0,
                                  10.0,
                                  Text(
                                    "Documents (PDF only)",
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.secondaryTextColor,
                                        14,
                                        FontType.Regular),
                                  )),
                              docListUiData,
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  10.0,
                                  Text(
                                    MessageConstant.TEXT_SCORE_PHOTOS,
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.secondaryTextColor,
                                        14,
                                        FontType.Regular),
                                  )),
                              mediaImageListUIData,
                              Container(
                                  height: 30.0,
                                  width: 80.0,
                                  child: FlatButton(
                                    onPressed: () {
                                      _checkValidation(testList[position]);
                                    },
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(0)),
                                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    child: Row(
                                      // Replace with a Row for horizontal icon + text
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          'SAVE',
                                          style: AppTextStyle.getDynamicStyleGroup(
                                              ColorValues.WHITE,
                                              12.0,
                                              FontType
                                                  .Regular), /*TextStyle(
                                                fontSize: 12.0,
                                                fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                color: Colors.white)*/
                                        ),
                                      ],
                                    ),
                                  ))
                            ])),
                  ))
            ],
          ));
    }

    Column getCompetencyItem(position) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
              13.0,
              0.0,
              13.0,
              0.0,
              Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                          color: ColorValues.DEVIDER_COLOR, width: 1.0)),
                  child: InkWell(
                      child: ListTile(
                        trailing: Container(
                            padding: EdgeInsets.all(8.0),
                            height: 40.0,
                            width: 30.0,
                            child: Image.asset(
                              /* testList[position].isSelected
                                  ? "assets/newDesignIcon/competency/down_arrow.png"
                                  :*/ /* "assets/newDesignIcon/competency/down_arrow.png"*/
                              "",
                              height: 15.0,
                              width: 15.0,
                            )),
                        title: Text(
                          testList[position].testName,
                          style: AppTextStyle.getDynamicStyleGroup(
                              testList[position].isSelected
                                  ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                  : ColorValues.HEADING_COLOR_EDUCATION,
                              16.0,
                              FontType
                                  .Regular), /*TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 16.0,
                              color: testList[position].isSelected
                                  ?     ColorValues.BLUE_COLOR_BOTTOMBAR
                                  :      ColorValues.HEADING_COLOR_EDUCATION),*/
                        ),
                      ),
                      onTap: () {
                        mediaDocumentList.clear();
                        mediaImagesList.clear();
                        mediaDocumentList.add(null);
                        mediaImagesList.add(null);
                        if (testList[position].isSelected) {
                          testList[position].isSelected = false;
                        } else {
                          resetSelection(position.toString());
                          previousTestScorePosition = position.toString();
                          testList[position].isSelected = true;
                        }
                        setState(() {
                          if (position == (testList.length - 1)) {
                            _controller.jumpTo(
                                _controller.position.maxScrollExtent + 80.0);
                          }

                          testList[position].isSelected;
                        });
                      }))),
          testList[position].isSelected && testList[position].isSubCategory
              ? PaddingWrap.paddingfromLTRB(
                  0.0,
                  10.0,
                  0.0,
                  5.0,
                  Container(
                      /*    decoration:     BoxDecoration(
                          color: Colors.white,
                          border:     Border.all(
                              color:      ColorValues.DEVIDER_COLOR,
                              width: 1.0)),*/
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: List.generate(
                              testList[position].subjectListModel.length,
                              (int index) {
                            return PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Column(
                                  children: <Widget>[
                                    Container(
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color:
                                                    ColorValues.DEVIDER_COLOR,
                                                width: 1.0)),
                                        child: ListTile(
                                          title: Text(
                                            testList[position]
                                                .subjectListModel[index]
                                                .subjectName,
                                            style: AppTextStyle.getDynamicStyleGroup(
                                                ColorValues
                                                    .HEADING_COLOR_EDUCATION,
                                                16.0,
                                                FontType
                                                    .Regular), /*TextStyle(
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                fontSize: 16.0,
                                                color:     ColorValues.HEADING_COLOR_EDUCATION),*/
                                          ),
                                          onTap: () {
                                            //onTap Data
                                            if (testList[position]
                                                .subjectListModel[index]
                                                .isSelected) {
                                              testList[position]
                                                  .subjectListModel[index]
                                                  .isSelected = false;
                                            } else {
                                              resetSelection(
                                                  position.toString());
                                              previousTestScorePosition =
                                                  position.toString();
                                              previousSubjectPosition =
                                                  index.toString();
                                              testList[position]
                                                  .subjectListModel[index]
                                                  .isSelected = true;
                                            }
                                            setState(() {});
                                          },
                                        )),
                                    testList[position]
                                            .subjectListModel[index]
                                            .isSelected
                                        ? getFormViewUi(false, position, index)
                                        : Container(
                                            height: 0.0,
                                          ),
                                  ],
                                ));
                          }))))
              : testList[position].isSelected
                  ? PaddingWrap.paddingfromLTRB(
                      13.0, 0.0, 13.0, 0.0, getFormViewUi(true, position, 0))
                  : Container(
                      height: 0.0,
                    ),
        ],
      );
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child: Scaffold(
            backgroundColor: ColorValues.SCREEN_BG_COLOR,
            appBar: AppBar(
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              elevation: 0.0,
              title: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: CustomViews.getBackButton(),
                      onTap: () {
                        Navigator.pop(context, isPerformChanges);
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Text(
                      MessageConstant.TEXT_SCORE_SELECT_TEST,
                      textAlign: TextAlign.center,
                      style: AppTextStyle.getDynamicStyleGroup(
                          ColorValues.HEADING_COLOR_EDUCATION,
                          18.0,
                          FontType
                              .Regular), /* TextStyle(
                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                Container(
                  width: 40.0,
                )
              ],
              backgroundColor: Colors.white,
            ),
            body: FormKeyboardActions(
                nextFocus: false,
                keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                keyboardBarColor: Colors.grey[200],
                actions: [
                  KeyboardAction(
                    focusNode: textFocus0,
                  ),
                  KeyboardAction(
                    focusNode: textFocus1,
                  ),
                  KeyboardAction(
                    focusNode: textFocus2,
                  ),
                  KeyboardAction(
                    focusNode: textFocus3,
                  ),
                  KeyboardAction(
                    focusNode: textFocus4,
                  ),
                  KeyboardAction(
                    focusNode: textFocus5,
                  ),
                  KeyboardAction(
                    focusNode: textFocus6,
                  ),
                  KeyboardAction(
                    focusNode: textFocus7,
                  ),
                  KeyboardAction(
                    focusNode: textFocus8,
                  ),
                  KeyboardAction(
                    focusNode: textFocus9,
                  ),
                  KeyboardAction(
                    focusNode: textFocus10,
                  ),
                  KeyboardAction(
                    focusNode: textFocus11,
                  ),
                  KeyboardAction(
                    focusNode: textFocus12,
                  ),
                  KeyboardAction(
                    focusNode: textFocus13,
                  ),
                  KeyboardAction(
                    focusNode: textFocus14,
                  ),
                  KeyboardAction(
                    focusNode: textFocus15,
                  ),
                ],
                child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () {
                      FocusScopeNode currentFocus = FocusScope.of(context);

                      if (!currentFocus.hasPrimaryFocus &&
                          currentFocus.focusedChild != null) {
                        FocusManager.instance.primaryFocus.unfocus();
                      }
                    },
                    child: new Column(
                      children: <Widget>[
                        CustomViews.getSepratorLine(),

                        /* isTestSelected
                    ? */
                        new Expanded(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 15, 0, 0),
                            child: testList.length > 0
                                ? ListView.builder(
                                    controller: _controller,
                                    itemCount: testList.length,
                                    itemBuilder:
                                        (BuildContext context, int position) {
                                      return getCompetencyItem(position);
                                    })
                                : Container(
                                    height: 0.0,
                                  ),
                          ),
                          flex: 1,
                        )
                        /* :     Container(
                        height: 0.0,
                      )*/
                      ],
                    )))));
  }
}
