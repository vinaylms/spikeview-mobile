import 'dart:io';

class ReportOptionMedel {
  String reason;
bool isSelected=false;
  ReportOptionMedel(this.reason);
  Map<String, dynamic> toJson() => {'userId': int.parse(reason)};

}

