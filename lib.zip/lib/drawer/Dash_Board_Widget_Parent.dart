import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:package_info/package_info.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_friend_list.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/Connection/Connections.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/drawer/Acount_Setting.dart';
import 'package:spike_view_project/drawer/OpportunitySearch.dart';
import 'package:spike_view_project/drawer/drawer_menu.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/group/New/GroupBaseWidgetNew.dart';
import 'package:spike_view_project/home_page/ui/new_home_widget.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/ConnectionNotificationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/newfeature/NewFeautreBasePageWidget.dart';
import 'package:spike_view_project/notification/NotificationWidget.dart';
import 'package:spike_view_project/parentProfile/ParentProfile.dart';
import 'package:spike_view_project/parentProfile/wizard/newpages/onboarding_child_interest_widget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/EditProfileImageWidget.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/recommendation/manageRecommendation/Manage_Recommendation_dashbaord.dart';
import 'package:spike_view_project/story/PartnerStory.dart';
import 'package:spike_view_project/story/profile_story.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/role_widget.dart';

class DashBoardWidgetParent extends StatefulWidget {
  String isParentRole, isPartnerRole, isUserRole, currentPage = "", userId;
  ProfileInfoModal profileInfoModal;

  DashBoardWidgetParent(this.isParentRole, this.isPartnerRole, this.isUserRole,
      {this.currentPage, this.userId, this.profileInfoModal});

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    print("-----isParentRoleisParentRoleisParentRole-------sk" +
        isParentRole +
        " isPartnerRole " +
        isPartnerRole +
        " isUserRole " +
        isUserRole);
    return DashBoardStateParent(isParentRole, isPartnerRole, isUserRole);
  }
}

class DashBoardStateParent extends State<DashBoardWidgetParent>
    with WidgetsBindingObserver {
  DashBoardStateParent(this.isParentRole, this.isPartnerRole, this.isUserRole);

  bool isUserProfile = true;
  bool isHome = false;
  bool isConnection = false;
  bool isMessage = false;
  bool isMore = false;
  static StreamController syncDoneController = StreamController.broadcast();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  SharedPreferences prefs;
  bool changes = false;
  String profilePath = "",
      userIdPref,
      roleId,
      companyPath = "",
      companyName = "",
      deviceId,
      userName = "";
  ConnectionNotificationModel connectionNotificationModel;
  StreamSubscription<dynamic> _streamSubscription;
  StreamSubscription<dynamic> _streamSubscription2;
  StreamSubscription<dynamic> _streamSubscription3;
  String isParentRole, isPartnerRole, isUserRole;
  List<Friends> spikeBotdataList = List();
  bool isFeedPopUP = false;
  bool isDisplayNewFeaturePopUp = false;
  PackageInfo packageInfo;
  Timer _timer1;

  //PageController pageController = PageController();

  final pageController = PageController();

  Future fetchSpikeBotInfo() async {
    try {

      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCall3(
            context,
            Constant.ENDPOINT_SPIKE_BOT_USER + userIdPref + "&roleId=" + roleId,
            "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              spikeBotdataList.clear();
              spikeBotdataList =
                  ParseJson.parseBotData(response.data['result'], userIdPref);
              if (spikeBotdataList != null) {
                setState(() {});
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_INACTIVE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  changeState(value) {
    switch (value) {
      case 0:
        {
          setState(() {
            isUserProfile = true;
            isHome = false;
            isConnection = false;
            isMessage = false;
            isMore = false;
          });
          print("clicked 1");

          break;
        }
      case 1:
        {
          setState(() {
            isHome = true;
            isUserProfile = false;
            isConnection = false;
            isMessage = false;
            isMore = false;
          });
          print("clicked 1");

          break;
        }
      case 2:
        {
          setState(() {
            isHome = false;
            isUserProfile = false;
            isConnection = true;
            isMessage = false;
            isMore = false;
          });
          if (connectionNotificationModel != null &&
              connectionNotificationModel.connectionCount != "0" &&
              connectionNotificationModel.connectionCount != "" &&
              connectionNotificationModel.connectionCount != "null") {
            connectionNotificationModel.connectionCount = "0";
            setState(() {
            });

            apiCallingForUpdateFeed(
                "0",
                connectionNotificationModel.messagingCount,
                connectionNotificationModel.notificationCount,
                connectionNotificationModel.groupCount);
          }
          print("clicked 2");
          break;
        }

      case 3:
        {
          setState(() {
            isHome = false;
            isConnection = false;
            isUserProfile = false;
            isMessage = true;
            isMore = false;
          });
          if (connectionNotificationModel != null &&
              connectionNotificationModel.messagingCount != "0" &&
              connectionNotificationModel.messagingCount != "" &&
              connectionNotificationModel.messagingCount != "null") {
            connectionNotificationModel.messagingCount = "0";
            setState(() {
            });
            apiCallingForUpdateFeed(
                connectionNotificationModel.connectionCount,
                "0",
                connectionNotificationModel.notificationCount,
                connectionNotificationModel.groupCount);
          }
          print("clicked 4");
          break;
        }
      case 4:
        {
          setState(() {
            isHome = false;
            isConnection = false;
            isUserProfile = false;
            isMessage = false;
            isMore = true;
          });
          // if(int.parse(connectionNotificationModel.groupCount)>0)
          apiCallingForUpdateFeed(
              connectionNotificationModel.connectionCount,
              connectionNotificationModel.messagingCount,
              connectionNotificationModel.notificationCount,
              "0");
          print("clicked 5");
          break;
        }
    }
  }

  ontapBottomNavigationBar(value) {
    switch (value) {
      case 0:
        {
          setState(() {
            isUserProfile = true;
            isHome = false;
            isConnection = false;
            isMessage = false;
            isMore = false;
            pageController.jumpToPage(0);
          });
          print("clicked 1");

          break;
        }
      case 1:
        {
          setState(() {
            isHome = true;
            isUserProfile = false;
            isConnection = false;
            isMessage = false;
            isMore = false;
            pageController.jumpToPage(1);
          });
          print("clicked 1");

          break;
        }
      case 2:
        {
          setState(() {
            isHome = false;
            isUserProfile = false;
            isConnection = true;
            isMessage = false;
            isMore = false;
            pageController.jumpToPage(2);
          });
          if (connectionNotificationModel != null &&
              connectionNotificationModel.connectionCount != "0" &&
              connectionNotificationModel.connectionCount != "" &&
              connectionNotificationModel.connectionCount != "null") {
            connectionNotificationModel.connectionCount = "0";
            setState(() {
            });

            apiCallingForUpdateFeed(
                "0",
                connectionNotificationModel.messagingCount,
                connectionNotificationModel.notificationCount,
                connectionNotificationModel.groupCount);
          }
          print("clicked 2");
          break;
        }

      case 3:
        {
          setState(() {
            isHome = false;
            isConnection = false;
            isUserProfile = false;
            isMessage = true;
            isMore = false;
            pageController.jumpToPage(3);
          });
          if (connectionNotificationModel != null &&
              connectionNotificationModel.messagingCount != "0" &&
              connectionNotificationModel.messagingCount != "" &&
              connectionNotificationModel.messagingCount != "null") {
            connectionNotificationModel.messagingCount = "0";
            setState(() {
            });
            apiCallingForUpdateFeed(
                connectionNotificationModel.connectionCount,
                "0",
                connectionNotificationModel.notificationCount,
                connectionNotificationModel.groupCount);
          }
          print("clicked 4");
          break;
        }
      case 4:
        {
          setState(() {
            isHome = false;
            isConnection = false;
            isUserProfile = false;
            isMessage = false;
            isMore = true;
            pageController.jumpToPage(4);
          });
          // if(int.parse(connectionNotificationModel.groupCount)>0)
          apiCallingForUpdateFeed(
              connectionNotificationModel.connectionCount,
              connectionNotificationModel.messagingCount,
              connectionNotificationModel.notificationCount,
              "0");
          print("clicked 5");
          break;
        }
    }
  }

  Future apiCallingUpdateDialogStatus() async {
    try {
      Response response;
      print("DatatCallingmap:-");
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "featureKey": ["gamification", "exploreOpportunity"],
        "display": false
      };

      print("map   ENDPOINT_UPDATE_DIALOG_STATUS:-" + map.toString());
      response = await ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_DIALOG_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            setState(() {});
          }
        }
      }
    } catch (e) {
      print("Errorr:-" + e.toString());
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  onTapSignOut() async {
    try {
      Constant.isAlreadyLoggedIn = false;

      Map map = {
        "userId": int.parse( prefs.getString(UserPreference.USER_ID)),
        "deviceId": prefs.getString("deviceId")
      };
      GlobalSocketConnection.socket.emitWithAck("disconnect1", [map]).then((data) {

        print("chat-login++++" + data.toString());
      });
      GlobalSocketConnection.socket.emit("disconnect2", []);
      /*   await GlobalSocketConnection.manager
          .clearInstance(GlobalSocketConnection.socket);*/
      prefs.setBool(UserPreference.LOGIN_STATUS, false);
      prefs.setString(UserPreference.PATHURL,'');
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
      prefs.setBool(UserPreference.IS_USER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
      prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
      prefs.setString(UserPreference.NAME, "");
      prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
      bloc.resetData(prefs);
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage(null)),
      );
    } catch (e) {
      print("Error++++" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  Future apiCallForLogout() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {
          "deviceId": prefs.getString("deviceId"),
        };

        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_LOGOUT, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              onTapSignOut();
            } else {
              ToastWrap.showToast(msg, context);
            }
          } else {
            if (response.statusCode == 401) {
              onTapSignOut();
            }
          }
        } else {
          onTapSignOut();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      onTapSignOut();
      CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  Future apiCallingForGetNotificationCount() async {
    try {
      print("roleId+++++++ parent" + "&roleId=" + Constant.ROLE_ID);
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_NOTIFICATION_COUNT +
              userIdPref +
              "&roleId=" +
              roleId,
          "get");
      print("response Child" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            connectionNotificationModel =
                ParseJson.parseConnectionNotification(response.data['result']);
            if (connectionNotificationModel != null) {
              setState(() {
                connectionNotificationModel;
              });
              if (int.parse(connectionNotificationModel.notificationCount) >
                  0) {
                syncDoneController
                    .add(connectionNotificationModel.notificationCount);
              }
            }
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  Future refresh() async {
    try {
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_NOTIFICATION_COUNT +
              userIdPref +
              "&roleId=" +
              prefs.getString(UserPreference.ROLE_ID),
          "get");
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            connectionNotificationModel =
                ParseJson.parseConnectionNotification(response.data['result']);
            if (connectionNotificationModel != null) {
              setState(() {
                connectionNotificationModel;
              });
              if (int.parse(connectionNotificationModel.notificationCount) >
                  0) {
                syncDoneController
                    .add(connectionNotificationModel.notificationCount);
              }
            }
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  Future apiCallingForUpdateFeed2(
      connectionCount, messageCount, notificationCount, groupCount) async {
    try {
      Map map = {
        "userId": int.parse(userIdPref),
        "connectionCount": connectionCount,
        "messagingCount": messageCount,
        "notificationCount": "0",
        "roleId": roleId,
      };
      Response response = await ApiCalling2().apiCallPutWithMapData(
          Constant.applicationContext,
          Constant.ENDPOINT_NOTIFICATION_UPDATE,
          map);

      print("response api update notification:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            connectionNotificationModel = ConnectionNotificationModel(
                connectionCount, messageCount, "0", groupCount);
            syncDoneController.add("0");
            setState(() {
              connectionNotificationModel;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  Future apiCallingForUpdateFeed(
      connectionCount, messageCount, notificationCount, groupCount) async {
    try {
      Map map = {
        "userId": int.parse(userIdPref),
        "connectionCount": connectionCount,
        "messagingCount": messageCount,
        "notificationCount": notificationCount,
        "roleId": roleId,
      };
      Response response = await ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_NOTIFICATION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            connectionNotificationModel = ConnectionNotificationModel(
                connectionCount, messageCount, notificationCount, groupCount);

            setState(() {
              connectionNotificationModel;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  void addUser() {
    /*   List<dynamic> dataUser =  List();
    dataUser.add(userIdPref+deviceId);
    dataUser.add(deviceId);
  */
    Map map = {
      "userId": int.parse(userIdPref),
      // "deviceId": deviceId,
      // "roleId": roleId,
    };
    print("data for addUser" + map.toString());
    GlobalSocketConnection.socket.emitWithAck("chat-login", [map]).then((data) {
      // this callback runs when this specific message is acknowledged by the server
      print("chat-login ++++" + data.toString());
    });
  }

  ProfileInfoModal profileInfoModal;

  Future profileApi(isShowLaoder, value) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        // if (isShowLaoder) CustomProgressLoader.showLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++" +
            Constant.ENDPOINT_PERSONAL_INFO_NEW +
            userIdPref +
            "/false/1/0");
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_PERSONAL_INFO_NEW + userIdPref + "/false/2/0",
            "get");

        //if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                if (mounted) {
                  setState(() {
                    profileInfoModal;
                    prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                        profileInfoModal.profilePicture);
                    var introducingFeature =
                        response.data['result']["introducingFeatures"];
                    prefs.setString(
                        UserPreference.NAME,
                        profileInfoModal.firstName +
                            " " +
                            profileInfoModal.lastName);
                    try {
                      String schoolCode = profileInfoModal.schoolCode;
                      if (schoolCode == null ||
                          schoolCode == "" ||
                          schoolCode == "null") {
                        schoolCode = "";
                        prefs.setBool(UserPreference.IS_SCHOOL, false);
                      } else {
                        prefs.setBool(UserPreference.IS_SCHOOL, true);
                      }
                      prefs.setString(UserPreference.SCHOOL_CODE, schoolCode);
                    } catch (e) {}
                    for (int i = 0; i < introducingFeature.length; i++) {
                      if (introducingFeature[i]["roleId"].toString() ==
                          roleId) {
                        if (introducingFeature[i]["exploreOpportunity"]) {
                          isFeedPopUP = true;
                        }

                        prefs.setBool(UserPreference.IS_COMMUNITY_POPUP, false);
                        isDisplayNewFeaturePopUp =
                            introducingFeature[i]["display"];
                        if (isDisplayNewFeaturePopUp) {
                          syncDoneController.add("dialogVisible");
                        }
                        setState(() {
                          isFeedPopUP;
                          isDisplayNewFeaturePopUp;
                        });
                      }
                    }
                  });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  Future getVersion() async {
    try {
      print("------------SPIKE BOAT");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("------------getVersion" +
            Constant.ENDPOINT_APP_VERSION +
            "?version=" +
            packageInfo.version.toString());

        Response response = await ApiCalling2().apiCall3(
            context,
            Platform.isAndroid
                ? Constant.ENDPOINT_APP_VERSION +
                    "?version=" +
                    packageInfo.version.toString() +
                    "&appType=android"
                : Constant.ENDPOINT_APP_VERSION +
                    "?version=" +
                    packageInfo.version.toString() +
                    "&appType=ios",
            "get");
        print("------------getVersion" + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              double versionForAbndroid;
              double versionForIos;
              String isIosRestrict = "false";
              String isAndroidRestrict = "false";
              try {
                versionForAbndroid = double.parse(
                    response.data['result']['androidVersion'].toString());
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "ParentDashboard", context);
              }

              try {
                versionForIos = double.parse(
                    response.data['result']['iosVersion'].toString());
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "ParentDashboard", context);
              }

              try {
                isIosRestrict =
                    response.data['result']['isIosRestrict'].toString();
                isAndroidRestrict =
                    response.data['result']['isAndroidRestrict'].toString();
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "ParentDashboard", context);
              }

              String upgradeMessage =
                  response.data['result']['upgradeMessage'].toString();

              print("------------getVersionANdroid" +
                  versionForAbndroid.toString());
              print("------------getVersionIOS" + versionForIos.toString());
              print("------------getVersion" + packageInfo.version.toString());
              print("------------getVersionios" + isIosRestrict);
              print("------------getVersionAndroid" + isAndroidRestrict);
              print("------------getVersion" +
                  response.data['result']['isRestrict'].toString());
              if (Platform.isAndroid) {
                if (double.parse(packageInfo.version) < versionForAbndroid) {
                  print("------------getVersion true" + packageInfo.version);
                  if (_timer1 != null) {
                    _timer1.cancel();
                  }
                  if (mounted && isAndroidRestrict == "true") {
                    syncDoneController.add("dialogVisible");
                    Util.showUpdateDialog(context,
                        response.data['result']['isRestrict'], upgradeMessage);
                  }
                }
              } else {
                if (double.parse(packageInfo.version) < versionForIos) {
                  if (_timer1 != null) {
                    _timer1.cancel();
                  }
                  if (mounted && isIosRestrict == "true") {
                    syncDoneController.add("dialogVisible");
                    Util.showUpdateDialog(context,
                        response.data['result']['isRestrict'], upgradeMessage);
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("error++++++++++++" + e.toString());
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  String linkData;

  getSharedPrefrence() async {
    // accessControl();

    packageInfo = await PackageInfo.fromPlatform();

    prefs = await SharedPreferences.getInstance();
    profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    deviceId = prefs.getString(UserPreference.DEVICE_ID);
    companyPath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    companyName = prefs.getString(UserPreference.COMPANY_NAME_PATH);
    print("profilepath:-" + profilePath);
    userName = prefs.getString(UserPreference.NAME);
    setCurentPage();
    try {
      var access_feedLike = prefs.getBool(UserPreference.IS_SCHOOL);
      if (access_feedLike == null) {
        bloc.accessControlParam(prefs);
      }
    } catch (e) {
      bloc.accessControlParam(prefs);
    }
    GlobalSocketConnection.socket.onConnect((data) {
      print("=====connected...");

      addUser();
    });
    addUser();
    // await getVersion();
    await profileApi(false, "");

    apiCallingForGetNotificationCount();
    print("------------SPIKE BOAT1");
    fetchSpikeBotInfo();

    setState(() {
      print("-----isParentRoleisParentRoleisParentRole-------SPIKE BOAT1" +
          isParentRole);
      isParentRole;
      isPartnerRole;
      isUserRole;
    });

    if (isDisplayNewFeaturePopUp) {
      syncDoneController.add("dialogVisible");
      await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => NewFeautreBasePageWidget()));
      try {
        CustomProgressLoader.cancelLoader(context);
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print('state = $state');
    if (state == AppLifecycleState.resumed) {
      /*   Map map = {
        "userId": int.parse(userIdPref),
      };
      print("data for addUser" + map.toString());
      GlobalSocketConnection.socket
          .emitWithAck("chat-login", [map]).then((data) {
        // this callback runs when this specific message is acknowledged by the server
        print("chat-login++++" + data.toString());
      });*/
    } else {
      //  calling();
    }
    print("dispose test13 method call");
  }

  calling() async {
    print("dispose test2 method call");
/*    List<dynamic> dataUser =  List();
    dataUser.add(userIdPref);
    dataUser.add(deviceId);*/

    Map map = {
      "userId": int.parse(userIdPref),
      // "deviceId": deviceId,
      // "roleId": roleId,
    };
    print("disconnect+++++" + map.toString());
    // await GlobalSocketConnection.manager.clearInstance( GlobalSocketConnection.socket);

    print("dispose disconnect1 method call");
  }

  @override
  void dispose() {
    // TODO: implement dispose
    print("dispose test12 method call");
    calling();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  getdat() async {
    await getSharedPrefrence();
  }

  setCurentPage() {
    switch (widget.currentPage) {
      case Constant.PROFILE_TYPE:
        {
          ontapBottomNavigationBar(0);
          break;
        }
      case Constant.FEED_TYPE:
        {
          ontapBottomNavigationBar(1);
          break;
        }
      case Constant.CHAT_TYPE:
        {
          ontapBottomNavigationBar(3);
          break;
        }
      case Constant.CONNECTIONS_TYPE:
        {
          ontapBottomNavigationBar(2);
          break;
        }
      case Constant.GROUP_TYPE:
        {
          ontapBottomNavigationBar(4);
          break;
        }
    }
  }

  bool isUserRepoted = true;

  List<DrawerMenu> drawerMenu = [];

  @override
  void initState() {
    drawerMenu.addAll([
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/invite_friend_earn.png",
        title: "Invite friends & earn",
        onTap: () {
            Navigator.of(context).pop();
            print("Invite Friends and Earn onTap()");
            String referCode =
            prefs.getString(UserPreference.referCode);
            Util.shareAppLinkViaOtherAppParent(
                context,
                referCode,
                roleId == "4"
                    ? prefs.getString(
                    UserPreference.COMPANY_NAME_PATH)
                    : prefs.getString(UserPreference.NAME));
          },
      ),
      DrawerMenu(
        assetIcon: "assets/drawer/ic_manage_recommendation.png",
        title: "Manage recommendations",
        onTap: () {
          Navigator.of(context).pop();

          Navigator.of(context).push(
              MaterialPageRoute(
                  builder: (BuildContext
                  context) =>
                      ManageRequestDashBoard(
                          "")));
        },
      ),
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/spikeview_boot.png",
        title: "Help (spikeview bot)",
        onTap: () {
          Navigator.of(context).pop();
          if (spikeBotdataList.length > 0) {
            Navigator.of(context).push(MaterialPageRoute(
                builder: (BuildContext context) =>
                    ChatRoomWidget(
                        spikeBotdataList[0], "", "")));
          }
        },
      ),
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/account_setting.png",
        title: "Account settings",
        onTap: () {
          Navigator.of(context).pop();
          onTapProfile();
        },
      ),
   /*   DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/help.png",
        title: "Help",
        onTap: () {
          Navigator.of(context).pop();
          if (spikeBotdataList.length > 0) {
            Navigator.of(context).push(MaterialPageRoute(
                builder: (BuildContext context) =>
                    ChatRoomWidget(
                        spikeBotdataList[0], "", "")));
          }
        },
      ),*/
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/privacy_policy.png",
        title: "Privacy policy",
        onTap: () {
          Navigator.of(context).pop();
          Navigator.push(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => WebViewWidget(
                      Constant.PRIVACY_POLICY,
                      "Privacy Policy")));
        },
      ),
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/about_spike_view.png",
        title: "About spikeview",
        onTap: () {
          Navigator.of(context).pop();
          Navigator.push(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => WebViewWidget(
                      Constant.ABOUT_US,
                      "About spikeview")));
        },
      ),
      DrawerMenu(
        assetIcon: "assets/drawer/ic_explore_opportunities.png",
        title: "Explore opportunities",
        onTap: () {
          Navigator.of(context).pop();
          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) => OpportunitySearch("")));
        },
      ),
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/sigen_out.png",
        title: "Sign out",
        onTap: () {
          showSignOutDialog();
        },
      ),
    ]);
    super.initState();
    //GlobalSocketConnection.initSocket();
    if (widget.currentPage == Constant.GROUP_TYPE) {
      if (widget.userId != null) {
        print("datat++++++" + widget.userId);
        userIdPref = widget.userId;
        setState(() {
          userIdPref;
        });
      }
    }

    isUserRepoted = UserPreference.getIsUserReported();

    getdat();
    _streamSubscription2 =
        SelectingChildIterestWidgetState.syncDoneController.stream.listen((value) {
      print("api called student" + value);
      if (value == "feed") {
        ontapBottomNavigationBar(1);
      } else if (value == "connection") {
        ontapBottomNavigationBar(2);
      }
    });
    WidgetsBinding.instance.addObserver(this);

    // TODO: implement initState
    _streamSubscription2 =
        ChatFriendListView.syncDoneController.stream.listen((value) {
      //profileApi(true,value);

      apiCallingForUpdateFeed(
          connectionNotificationModel.connectionCount,
          "0",
          connectionNotificationModel.notificationCount,
          connectionNotificationModel.groupCount);
    });

    _streamSubscription2 =
        EditProfileImageWidgetState.syncDoneController.stream.listen((value) {
      profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
      userName = prefs.getString(UserPreference.NAME);
      profilePath;
      userName;
      if (mounted) {
        setState(() {});
      }
    });
    _streamSubscription3 =
        ParentProfilePageState.syncDoneController.stream.listen((value) {
      profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
      userName = prefs.getString(UserPreference.NAME);
      profilePath;
      userName;
      if (mounted) {
        setState(() {});
      }
    });

    _streamSubscription =
        SplashScreenState.syncDoneController.stream.listen((value) {
      print("value changes" + value);

      refresh();
    });

    _streamSubscription =
        NotificationWidgetState.syncDoneController.stream.listen((value) {
      if (value == "connectionPage") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(2);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else if (value == "Feed") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(1);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else if (value == "groupPage") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(4);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else if (value == "chatPage") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(3);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else if (value == "profilePage") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(0);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else {
        apiCallingForUpdateFeed2(
            connectionNotificationModel.connectionCount,
            connectionNotificationModel.messagingCount,
            0,
            connectionNotificationModel.groupCount);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    //SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);
    final bottomBar = BottomAppBar(
      elevation: 0.0,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration:  BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(25.0),
            topLeft: Radius.circular(25.0),
          ),

        ),

        height: 72.0,
        child: Padding(
          padding: const EdgeInsets.only(top:2.0),
          child: Container(
            // ***
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(25.0),
                topLeft: Radius.circular(25.0),
              ),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: const Color(0x75CCDCF7),
                  spreadRadius: 1,
                  blurRadius: 2,
                )
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.only(left:10.0,right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              isUserProfile
                                  ? "assets/newDesignIcon/profile_blue.png"
                                  : "assets/newDesignIcon/profile_new.png",
                              width: 40.0,
                              height: 40.0,
                            ),
                            TextViewWrap.textView(
                                "Profile",
                                TextAlign.center,
                                isUserProfile
                                    ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                    : AppConstants.colorStyle.lightPurple,
                                14.0,
                                FontWeight.normal),
                          ],
                        ),
                        onTap: () {
                          ontapBottomNavigationBar(0);
                        }),
                    flex: 2,
                  ),
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              isHome
                                  ? "assets/newDesignIcon/feed_blue.png"
                                  : "assets/newDesignIcon/feed.png",
                              width: 40.0,
                              height: 40.0,
                            ),
                            TextViewWrap.textView(
                                "Feed",
                                TextAlign.center,
                                isHome
                                    ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                    : AppConstants.colorStyle.lightPurple,
                                14.0,
                                FontWeight.normal),
                          ],
                        ),
                        onTap: () {
                          ontapBottomNavigationBar(1);
                        }),
                    flex: 2,
                  ),
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            connectionNotificationModel == null ||
                                    connectionNotificationModel.connectionCount ==
                                        "null" ||
                                    connectionNotificationModel.connectionCount ==
                                        "" ||
                                    int.parse(connectionNotificationModel
                                            .connectionCount) ==
                                        0
                                ? Image.asset(
                                    isConnection
                                        ? "assets/newDesignIcon/connection_blue.png"
                                        : "assets/newDesignIcon/connection.png",
                                    width: 40.0,
                                    height: 40.0,
                                  )
                                : Stack(
                                    children: <Widget>[
                                      Image.asset(
                                        isConnection
                                            ? "assets/newDesignIcon/connection_blue.png"
                                            : "assets/newDesignIcon/connection.png",
                                        width: 40.0,
                                        height: 40.0,
                                      ),
                                      Positioned(
                                        top: 4.0,
                                        right: 4.0,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(15),
                                              boxShadow: [
                                                BoxShadow(


                                                  color: Color.fromRGBO(255, 0, 0, 0.65),
                                                )
                                              ]
                                          ),
                                          height: 8.0,
                                          width: 8.0,),
                                      )
                                    ],
                                  ),
                            TextViewWrap.textView(
                                "Connections",
                                TextAlign.center,
                                isConnection
                                    ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                    : AppConstants.colorStyle.lightPurple,
                                14.0,
                                FontWeight.normal),
                          ],
                        ),
                        onTap: () {
                          ontapBottomNavigationBar(2);
                        }),
                    flex: 3,
                  ),
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            connectionNotificationModel == null ||
                                    connectionNotificationModel.messagingCount ==
                                        "null" ||
                                    connectionNotificationModel.messagingCount ==
                                        "" ||
                                    int.parse(connectionNotificationModel
                                            .messagingCount) ==
                                        0
                                ? Image.asset(
                                    isMessage
                                        ? "assets/newDesignIcon/chat_blue.png"
                                        : "assets/newDesignIcon/chat_new.png",
                                    width: 40.0,
                                    height: 40.0,

                                  )
                                : Stack(
                                    children: <Widget>[
                                      Image.asset(
                                        "assets/newDesignIcon/chat_new.png",

                                        width: 40.0,
                                        height: 40.0,
                                      ),
                                      Positioned(
                                        top: 4.0,
                                        right: 4.0,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(15),
                                              boxShadow: [
                                                BoxShadow(


                                                  color: Color.fromRGBO(255, 0, 0, 0.65),
                                                )
                                              ]
                                          ),
                                          height: 8.0,
                                          width: 8.0,),
                                      )
                                    ],
                                  ),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                TextViewWrap.textView(
                                    "Chat",
                                    TextAlign.center,
                                    isMessage
                                        ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                        : AppConstants.colorStyle.lightPurple,
                                    14.0,
                                    FontWeight.normal)),
                          ],
                        ),
                        onTap: () {
                          // if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                          ontapBottomNavigationBar(3);
                          /*} else {
                            ToastWrap.showToast(
                                "Please have your parents approve your account before you can use these features.",
                                context);
                          }*/
                        }),
                    flex: 2,
                  ),
                  Constant.V_CONTROL
                      ? Expanded(
                          child: InkWell(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  connectionNotificationModel == null ||
                                          connectionNotificationModel.groupCount ==
                                              "null" ||
                                          connectionNotificationModel.groupCount ==
                                              "" ||
                                          int.parse(connectionNotificationModel
                                                  .groupCount) ==
                                              0
                                      ? Image.asset(
                                          isMore
                                              ? "assets/newDesignIcon/group_blue.png"
                                              : "assets/newDesignIcon/group_n.png",
                                          width: 40.0,
                                          height: 40.0,
                                        )
                                      : Stack(
                                          children: <Widget>[
                                            Image.asset(
                                              isMore
                                                  ? "assets/newDesignIcon/group_blue.png"
                                                  : "assets/newDesignIcon/group_n.png",
                                              width: 40.0,
                                              height: 40.0,
                                            ),
                                            Positioned(
                                              top: 4.0,
                                              right: 4.0,
                                              child: Container(
                                                  decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(15),
                                                      boxShadow: [
                                                        BoxShadow(


                                                          color: Color.fromRGBO(255, 0, 0, 0.65),
                                                        )
                                                      ]
                                                  ),
                                                  height: 8.0,
                                                  width: 8.0,),
                                            )
                                          ],
                                        ),
                                  TextViewWrap.textView(
                                      "Groups",
                                      TextAlign.center,
                                      isMore
                                          ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                          : AppConstants.colorStyle.lightPurple,
                                      14.0,
                                      FontWeight.normal),
                                ],
                              ),
                              onTap: () {
                                // if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                                ontapBottomNavigationBar(4);
                                /* } else {
                            ToastWrap.showToast(
                                "Please have your parents approve your account before you can use these features.",
                                context);
                          }*/
                              }),
                          flex: 2,
                        )
                      : Container(
                          height: 0.0,
                        ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    
    final List<Widget> pages = [
      ParentProfilePage(
          _scaffoldKey,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount),
          profileInfoModal: widget.profileInfoModal),
      NewHomeWidget(
          _scaffoldKey,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount)),


      ConnectionsWidget(
          _scaffoldKey,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount),roleId),
      ChatFriendListView(
          _scaffoldKey,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount))
/*       MessageWidget(
          _scaffoldKey,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount))*/
      ,
      GroupBaseWidgetNew(
          userIdPref,
          _scaffoldKey,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount))
    ];

    return Stack(children: <Widget>[
      WillPopScope(
          onWillPop: () {
            CustomProgressLoader.showDialogBackDialog(context);
          },
          child: Scaffold(
            key: _scaffoldKey,
            backgroundColor: ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
            resizeToAvoidBottomPadding: false,
            /*     appBar: AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 2.0,
              backgroundColor: Colors.black.withOpacity(.9),
              brightness: Brightness.light,
              title: title,
              leading: navigationIcon,
              actions: <Widget>[search, notification]),*/
            drawer: _drawerView(),
            body: PageView(
                scrollDirection: Axis.horizontal,
                onPageChanged: (index) {
                  changeState(index);
                },
                physics: NeverScrollableScrollPhysics(),
                pageSnapping: false,
                controller: pageController,
                children: pages),
            bottomNavigationBar: MediaQuery.of(context).viewInsets.bottom == 0
                ? bottomBar
                : null,
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerDocked,
          )),
      isFeedPopUP
          ? Positioned(
              left: 0.0,
              right: 0.0,
              top: 0.0,
              bottom: 0.0,
              child: Material(
                  type: MaterialType.transparency,
                  child: InkWell(
                      onTap: () {
                        isFeedPopUP = false;
                        if (mounted) {
                          setState(() {});
                        }
                        apiCallingUpdateDialogStatus();
                      },
                      child: Container(
                        color: Colors.black.withOpacity(.8),
                        child: Stack(
                          children: [
                            Positioned(
                              top: -20,
                              right: -15,
                              child: Image.asset(
                                  'assets/newFeature/Group 4527.png',
                                  height: 150,
                                  width: 150),
                            ),
                            Positioned(
                              top: 45.98,
                              right: 0,
                              left: 0.0,
                              bottom: 0.0,
                              child: Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Container(),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                0.0, 0, 15, 0),
                                            child: Image.asset(
                                                'assets/newFeature/Group 4528.png',
                                                height: 104.9),
                                          ),
                                          flex: 2,
                                        ),
                                      ],
                                    ),
                                    Text('Explore Opportunities',
                                        style: TextStyle(
                                            fontSize: 18,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            color: Colors.white)),
                                    Text(
                                        'Take advantage of amazing opportunities.',
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            color: Colors.white)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ))),
            )
          : Container(
              height: 0.0,
            )
    ]);
  }

  void showSignOutDialog() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            msg: 'Are you sure you want to sign out?',
            negativeText: 'No',
            positiveText: 'Yes',
            isSucessPopup: false,
            positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              apiCallForLogout();
            },
          );
        });



  }

  Future<void> onTapProfile() async {
    prefs.setString(
        UserPreference.USER_ID, prefs.get(UserPreference.PARENT_ID));
    /*  String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>  EditParentProfile()));*/
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => Account_Setting(userIdPref, "2")));
    if (result == "push") {
      syncDoneController.add("success");
    }
  }

  Future<void> onTapPartnerMenu() async {
    /*   String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               CompanyInfoForSideNavigation()));*/
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => PartnerStory(
          userIdPref,
        )));

/*
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>  CompanyInfoNew(
                personalInfoObject: UserModel(),
                userId: userIdPref,
                pageName: "dashBoard",
              )));

      if (result == "push") apiForUpdateRole("4");*/
  }

  bool _showOtherRole = false;
  Widget _drawerView(){
    return  Drawer(
          child: Container(
            color: ColorValues.SELECTION_BG,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.fromLTRB(20, 33, 13, 0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        InkWell(
                            onTap: () => Navigator.pop(context),
                            child: Padding(
                              padding: const EdgeInsets.only(top:5.0,right: 5),
                              child: Image.asset(
                                'assets/drawer/ic_back_drawer.png',
                                height: 22,
                                width: 22,
                              ),
                            )),
                        const SizedBox(height: 20),
                        InkWell(
                          onTap: () {
                            if ( isUserRole == "true" ||
                                isPartnerRole == "true") {
                              setState(() {
                                _showOtherRole = !_showOtherRole;
                              });
                            }
                          },
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Row(
                                children: [
                                  Expanded(
                                    child: RichText(
                                      maxLines: 3,
                                      textAlign: TextAlign.start,
                                      text: TextSpan(
                                        text: userName,
                                        style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 22.0,
                                          fontWeight: FontWeight.w500,
                                          fontFamily: Constant.latoMedium,
                                        ),
                                      ),
                                    ),
                                  ),
                                  isUserRole == "true" ||
                                      isPartnerRole == "true"
                                      ? Image.asset(
                                    _showOtherRole
                                        ? "assets/drawer/ic_arrow_up.png"
                                        : 'assets/drawer/ic_arrow_down.png',
                                    height: 12,
                                    width: 12,
                                  )
                                      : const SizedBox.shrink()
                                ],
                              ),
                              const SizedBox(height: 6),
                              BaseText(
                                text: "Parent",
                                textColor: const Color(0xff666B9A),
                                fontFamily: Constant.latoRegular,
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                              )
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        Visibility(
                          visible: _showOtherRole,
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 16),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                isUserRole == "true"
                                    ? RoleWidget(
                                  name: userName,
                                  role: "Student",
                                  profile: profilePath,
                                    onTap: () {
                                      if (isUserRole == "true") {
                                        DbHelper().deleteTable();
                                        prefs.setString(
                                            UserPreference.ROLE_ID, "1");
                                        Constant.ROLE_ID = "1";
                                        Navigator.of(context).pop();
                                        /*Navigator.of(context).pushReplacement(
                                         MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                DashBoardWidget(
                                                    prefs.getString(
                                                        UserPreference
                                                            .IS_PARENT_ROLE),
                                                    prefs.getString(
                                                        UserPreference
                                                            .IS_PARTNER_ROLE),
                                                    prefs.getString(
                                                        UserPreference
                                                            .IS_USER_ROLE))));*/
                                        print('userIdPref:: $userIdPref');
                                        StudentOnBoarding()
                                            .getStudentOnBoardingInit(
                                            context, null, '', userIdPref);
                                      } else {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (BuildContext context) =>
                                                    ProfileStory()));
                                        // apiForUpdateRole("1");
                                      }
                                    },
                                )
                                    : const SizedBox.shrink(),
                                const Divider(
                                  color: Color(0xffE5EBF0),
                                  height: 28,
                                  thickness: 1,
                                ),
                                isPartnerRole == "true"
                                    ? RoleWidget(
                                  name: companyName,
                                  role: "Partner",
                                  profile: companyPath,
                                    onTap: () {
                                      if (isUserRole == "true") {
                                        DbHelper().deleteTable();
                                        prefs.setString(
                                            UserPreference.ROLE_ID, "1");
                                        Constant.ROLE_ID = "1";
                                        Navigator.of(context).pop();
                                        /*Navigator.of(context).pushReplacement(
                                         MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                DashBoardWidget(
                                                    prefs.getString(
                                                        UserPreference
                                                            .IS_PARENT_ROLE),
                                                    prefs.getString(
                                                        UserPreference
                                                            .IS_PARTNER_ROLE),
                                                    prefs.getString(
                                                        UserPreference
                                                            .IS_USER_ROLE))));*/
                                        print('userIdPref:: $userIdPref');
                                        StudentOnBoarding()
                                            .getStudentOnBoardingInit(
                                            context, null, '', userIdPref);
                                      } else {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (BuildContext context) =>
                                                    ProfileStory()));
                                        // apiForUpdateRole("1");
                                      }
                                    },
                                )
                                    : const SizedBox.shrink(),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    color: Color(0xffE5EBF0),
                    height: 12,
                    thickness: 1,
                  ),
                  Expanded(
                    child: ListView.separated(
                      itemBuilder: (_, index) {
                        final item = drawerMenu[index];
                        return InkWell(
                          onTap: item.onTap,
                          child: Container(
                            padding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
                            child: Row(
                              children: [
                                Image.asset(
                                  item.assetIcon,
                                  height: 40,
                                  width: 40,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: BaseText(
                                      text: item.title,
                                      fontFamily: Constant.latoMedium,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      textColor:
                                      ColorValues.HEADING_COLOR_EDUCATION_1),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (_, index) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: const Divider(
                          color: Color(0xffE5EBF0),
                          height: 0,
                          thickness: 1,
                        ),
                      ),
                      itemCount: drawerMenu.length,
                      shrinkWrap: true,
                      padding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
          ),
        )
   ;
  }
 
}
