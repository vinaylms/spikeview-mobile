import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:thumbnails/thumbnails.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

class VideoWithThumbnailFile extends StatefulWidget {
  final String filePath;

  VideoWithThumbnailFile({@required this.filePath});

  @override
  _VideoWithThumbnailState createState() => _VideoWithThumbnailState();
}

class _VideoWithThumbnailState extends State<VideoWithThumbnailFile> {
  Future futureThumbnail;
  void initState() {
    super.initState();
    futureThumbnail = getThumbnail();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: futureThumbnail,
      builder: (context, snapshot) {
        if (ConnectionState.done == snapshot.connectionState) {
          return Container(
              width: double.infinity,
              child: Image.memory(snapshot.data,fit:BoxFit.fitWidth ,));
        } else {
          return CircularProgressIndicator();
        }
      },
    );
  }

  Future<Uint8List> getThumbnail() async {
    try {
      Uint8List _mUint8List;
      String thumb = await Thumbnails.getThumbnail(

          videoFile: "http://spikeviewmediastorage.blob.core.windows.net/spikeview-media-development/sv_305/feeds/image_3f671dd4ee87454d9684bfda410a0697.jpg",
          imageType: ThumbFormat.WEBP,//this image will store in created folderpath
          quality: 30);


      return _mUint8List;
    }catch(e){
    }
  }
}