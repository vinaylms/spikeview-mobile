import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/widgets/full_image_widget.dart';
import 'package:spike_view_project/widgets/remove_button.dart';

class ListImageView extends StatelessWidget {
  final String imageUrl;
  final VoidCallback onRemoveTap;
  final File imageFile;

  const ListImageView({
    @required this.imageUrl,
    @required this.onRemoveTap,
    this.imageFile,
});

  @override
  Widget build(BuildContext context) {
    double width = 120;
    double height = 75;
    return Container(
      width: width,
      height: height,
      margin: EdgeInsets.only(right: 12),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.black,
      ),
      child: Stack(
        children: [
          imageFile != null
          ?Image.file(
      imageFile,
        width: width,
        height: height,
        fit: BoxFit.fill,
      )
          :CachedNetworkImage(
            imageUrl: imageUrl.contains(Constant.IMAGE_PATH)
                ? imageUrl
                : Constant.IMAGE_PATH + imageUrl,
            width: width,
            height: height,
            fit: BoxFit.fill,
            placeholder: (_, str) {
              return Center(
                child: SizedBox(
                  width: 30,
                  height: 30,
                  child:
                  CircularProgressIndicator(
                    valueColor:
                    AlwaysStoppedAnimation(
                      Colors.white,
                    ),
                    strokeWidth: 2.0,
                  ),
                ),
              );
            },
            errorWidget: (_, str, e) {
              return Image.asset(
                "assets/portfolio/certificate.png",
                width: width,
                height: height,
                fit: BoxFit.fill,
              );
            },
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: Container(
              color: Colors.black12,
              padding: const EdgeInsets.fromLTRB(0, 0, 10, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    padding: EdgeInsets.zero,
                    icon: Image.asset(
                      'assets/profile/skills/CornersOut.png',
                      width: 32,
                      height: 32,
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                         MaterialPageRoute(
                          builder: (BuildContext context) => FullImageWidget(
                            imagePath: imageFile != null
                                ? imageFile.path
                            :imageUrl.contains(Constant.IMAGE_PATH)
                                ? imageUrl.replaceAll(Constant.IMAGE_PATH, '')
                                : imageUrl,
                            type: imageFile != null
                                ? FullImageType.file
                            :FullImageType.network,
                          ),
                        ),
                      );
                    },
                  ),
                  RemoveButton(onTap: onRemoveTap),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
