

class IssuerModel {
  String status;
  List<IssuerData> result;
  int totalCount;

  IssuerModel({this.status, this.result, this.totalCount});

  IssuerModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result = <IssuerData>[];
      json['result'].forEach((v) {
        result.add(new IssuerData.fromJson(v));
      });
    }
    totalCount = json['totalCount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    data['totalCount'] = this.totalCount;
    return data;
  }
}

class IssuerData {
  String sId;
  int userId;
  int roleId;
  String profilePicture;
  String partnerStatus;
  String firstName;

  IssuerData(
      {this.sId,
        this.userId,
        this.roleId,
        this.profilePicture,
        this.partnerStatus,
        this.firstName});

  IssuerData.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    userId = json['userId'];
    roleId = json['roleId'];
    profilePicture = json['profilePicture'];
    partnerStatus = json['partnerStatus'];
    firstName = json['firstName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['userId'] = this.userId;
    data['roleId'] = this.roleId;
    data['profilePicture'] = this.profilePicture;
    data['partnerStatus'] = this.partnerStatus;
    data['firstName'] = this.firstName;
    return data;
  }
}


