import 'dart:io';

class IntroDuctioVideoModel {
  String status;
  String message;
  IntroVideoModel result;

  IntroDuctioVideoModel({this.status, this.message, this.result});

  IntroDuctioVideoModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    result =
    json['result'] != null ?  IntroVideoModel.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class IntroVideoModel {
  IntroVideo introVideo;

  IntroVideoModel({this.introVideo});

  IntroVideoModel.fromJson(Map<String, dynamic> json) {
    introVideo = json['introVideo'] != null
        ?  IntroVideo.fromJson(json['introVideo'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    if (this.introVideo != null) {
      data['introVideo'] = this.introVideo.toJson();
    }
    return data;
  }
}

class IntroVideo {
  String videoUrl;
  String thumbnailUrl;

  IntroVideo({this.videoUrl, this.thumbnailUrl});

  IntroVideo.fromJson(Map<String, dynamic> json) {
    videoUrl = json['videoUrl'];
    thumbnailUrl = json['thumbnailUrl'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['videoUrl'] = this.videoUrl;
    data['thumbnailUrl'] = this.thumbnailUrl;
    return data;
  }
}