import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/gateway/ChangePassword.dart';
import 'package:spike_view_project/gateway/partner_signup/partner_profile_view.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ProfileLogDataModel.dart';
import 'package:spike_view_project/modal/ProfileShareLogModel.dart';
import 'package:spike_view_project/parentProfile/EditParentProfile.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/Company_Edit_Widget.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ProfileVisiblity extends StatefulWidget {
  String userIdPref, role;

  ProfileVisiblity(this.userIdPref, this.role);

  @override
  ProfileVisiblityState createState() => ProfileVisiblityState();
}

class ProfileVisiblityState extends State<ProfileVisiblity> {
  String isPerformChanges = "pop", userIdPref, roleId, dob = "0", isHide = "";
  int diffrenceInDob;
  SharedPreferences prefs;
  bool isLoading = false;

  List<ProfileShareModel> profileShareLogLIst = List();

  ProfileLogDataModel _mProfileLogDataModel;

  Future apiCallForGetShareLog() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        print(
            'Log Api URL:: ${Constant.ENDPOINT_SHARE_LOG + widget.userIdPref + "&roleId=" + roleId}');
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_SHARE_LOG +
                widget.userIdPref +
                "&roleId=" +
                roleId,
            "get");

        isLoading = false;
        setState(() {
          isLoading;
        });

        print(Constant.ENDPOINT_SHARE_LOG + widget.userIdPref);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileShareLogLIst.clear();
              profileShareLogLIst =
                  ParseJson.parseMapShareLog(response.data['result']);
              if (profileShareLogLIst.length > 0) {
                setState(() {
                  profileShareLogLIst;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future getData(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(
            context, Constant.ENDPOINT_PROFILE_SHARE_LOG + userIdPref, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS] == "Success") {
              _mProfileLogDataModel =
                  ProfileLogDataModel.fromJson(response.data);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    dob = prefs.getString(UserPreference.DOB);
    isHide = prefs.getString(UserPreference.ISHide);
    setState(() {
      isLoading = true;
    });
    apiCallForGetShareLog();
    getData(true);
    setState(() {
      isLoading = false;
    });
    setState(() {});
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  onTapProfilePage() async {
    String result;
    if (widget.role == "1") {
      result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => EditUserProfile("")));

      /* result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>  EditUserProfile("")));*/
    } else if (widget.role == "2") {
      result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => EditUserProfile(
                "",
                roleId: '2',
              )));
      /* result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>  EditParentProfile()));*/
    } else {
      result = await Navigator.of(context).push(
        new MaterialPageRoute(
          builder: (BuildContext context) => PartnerProfileView(
            signUpUsing: SignUpUsing.email,
            action: PartnerProfileAction.edit,
          ),
        ),
      );

      /*   result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                 Company_Edit_Widget(widget.userIdPref)));*/
    }

    if (result == "push") {
      isPerformChanges = "push";
    }
  }

  onTapChangePassword() async {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ChangePassword("", widget.role)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
          return Future.value(false);
        },
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                InkWell(
                  child: SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        5.0,
                        0.0,
                        3.0,
                        Center(
                            child: Image.asset(
                                "assets/newDesignIcon/navigation/back.png",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),
                  ),
                  onTap: () {
                    Navigator.pop(context, isPerformChanges);
                  },
                )
              ],
            ),
            title: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  "Profile Visibility",
                  style: TextStyle(
                      fontSize: 18.0,
                      fontFamily: Constant.customRegular,
                      color: ColorValues.HEADING_COLOR_EDUCATION),
                )
              ],
            ),
            actions: <Widget>[
              InkWell(
                child: Padding(
                  padding: const EdgeInsets.only(right: 20.0),
                  child: Image.asset(
                    'assets/profile/parent/info.png',
                    height: 20.0,
                    width: 20.0,
                  ),
                ),
                onTap: () {},
              ),
            ],
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
          backgroundColor: ColorValues.SCREEN_BG_COLOR,
          body: isLoading
              ? Container(
                  height: 0.0,
                )
              : Container(
                  child: Column(
                  children: <Widget>[
                    Expanded(
                      child: CustomViews.getSepratorLine(),
                      flex: 0,
                    ),
                    Expanded(
                      flex: 1,
                      child: ListView(
                        children: <Widget>[
                          InkWell(
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 12, top: 16, right: 5),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Text(
                                            "Profile Visibility To Connected Users",
                                            style: TextStyle(
                                                fontSize: 16,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMBOLD)),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                            "Choose how your profile appears to your connected users",
                                            style: TextStyle(
                                                fontSize: 12,
                                                color:
                                                    ColorValues.GREY_TEXT_COLOR,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMBOLD)),
                                      ],
                                    ),
                                  ),
                                ),
                                Padding(
                                    padding: const EdgeInsets.only(
                                        top: 34, right: 14),
                                    child: Image.asset(
                                      "assets/newDesignIcon/right_arrow.png",
                                      height: 17.0,
                                      width: 9.0,
                                    )),
                              ],
                            ),
                            onTap: () async {
                              onTapProfilePage();
                            },
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(
                                13.0, 15.0, 13.0, 0.0),
                            child: Container(
                              height: 1.0,
                              color: ColorValues.GREY__COLOR_DIVIDER,
                            ),
                          ),
                          InkWell(
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 12, top: 16, right: 5),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                              "Profile Visiblity To Non Connected Users",
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMBOLD)),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                              "Choose how your profile appears to your nonn connected uers",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMBOLD)),
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 34, right: 14),
                                        child: Image.asset(
                                          "assets/newDesignIcon/right_arrow.png",
                                          height: 17.0,
                                          width: 9.0,
                                        )),
                                    onTap: () async {},
                                  ),
                                ],
                              ),
                              onTap: () async {
                                onTapChangePassword();
                              }),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(
                                13.0, 15.0, 13.0, 0.0),
                            child: Container(
                              height: 1.0,
                              color: ColorValues.GREY__COLOR_DIVIDER,
                            ),
                          ),
                          InkWell(
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 12, top: 16, right: 5),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text("Public Profile Visiblity",
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMBOLD)),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                              "Choose how your profile appears to non-logged in members via search",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMBOLD)),
                                        ],
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 34, right: 14),
                                        child: Image.asset(
                                          "assets/newDesignIcon/right_arrow.png",
                                          height: 17.0,
                                          width: 9.0,
                                        )),
                                    onTap: () async {},
                                  ),
                                ],
                              ),
                              onTap: () async {
                                onTapChangePassword();
                              }),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(
                                13.0, 15.0, 13.0, 0.0),
                            child: Container(
                              height: 1.0,
                              color: ColorValues.GREY__COLOR_DIVIDER,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              left: 12,
                              top: 16,
                              right: 5,
                              bottom: 10,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text("Custom Profile Share",
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontFamily: Constant.TYPE_CUSTOMBOLD)),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                    "Lorem ipsum dolor sit amet, consectetur adipiscing eli. Vulputate quis ut imperdiet pellentesque.",
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: ColorValues.GREY_TEXT_COLOR,
                                        fontFamily: Constant.TYPE_CUSTOMBOLD)),
                                //getProfileLogs(),
                              ],
                            ),
                          ),
                          getProfileLogs(),
                        ],
                      ),
                    ),
//                     Expanded(
//                      child: getProfileLogs(),
//                      flex: 1,
//                    ),
                  ],
                )),
        ));
  }

  getProfileLogs() {
    return (profileShareLogLIst != null && profileShareLogLIst.length > 0) ||
            (_mProfileLogDataModel != null &&
                _mProfileLogDataModel.result != null)
        ? Column(
            children: <Widget>[
              _mProfileLogDataModel != null &&
                      _mProfileLogDataModel.result != null
                  ? Container(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: List.generate(
                              _mProfileLogDataModel.result.length, (int index) {
                            return PaddingWrap.paddingfromLTRB(
                              13.0,
                              5.0,
                              13.0,
                              5.0,
                              Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(
                                        color: ColorValues.BORDER_COLOR,
                                        width: 0.5)),
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                        padding: EdgeInsets.fromLTRB(
                                            13.0, 13.0, 13.0, 13.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 0.0),
                                              child: Text(
                                                _mProfileLogDataModel
                                                    .result[index]
                                                    .customProfileLink,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontFamily:
                                                        Constant.customRegular),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 5.0, 0.0, 0.0),
                                              child: Row(
                                                children: <Widget>[
                                                  TextViewWrap
                                                      .textViewSingleLine(
                                                          "Expires On: ",
                                                          TextAlign.start,
                                                          _mProfileLogDataModel
                                                                  .result[index]
                                                                  .isActive
                                                              ? ColorValues
                                                                  .GREY__COLOR
                                                              : ColorValues
                                                                  .GREY__COLOR
                                                                  .withOpacity(
                                                                      .4),
                                                          14.0,
                                                          FontWeight.normal),
                                                  PaddingWrap.paddingAll(
                                                      0.0,
                                                      TextViewWrap.textViewMultiLine(
                                                          Util.getConvertedDateTimeStamp(
                                                              _mProfileLogDataModel
                                                                  .result[index]
                                                                  .createdAt
                                                                  .toString()),
                                                          TextAlign.center,
                                                          _mProfileLogDataModel
                                                                  .result[index]
                                                                  .isActive
                                                              ? ColorValues
                                                                  .GREY__COLOR
                                                              : ColorValues
                                                                  .GREY__COLOR
                                                                  .withOpacity(
                                                                      .4),
                                                          14.0,
                                                          FontWeight.normal,
                                                          2)),
                                                ],
                                              ),
                                            ),
                                            Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    0.0, 5.0, 0.0, 5.0),
                                                child: Divider(
                                                  color: ColorValues.DARK_GREY,
                                                  height: 0.0,
                                                )),
                                            _mProfileLogDataModel
                                                    .result[index].isActive
                                                ? GestureDetector(
                                                    onTap: () {
                                                      setState(() {
                                                        confromAtionDialogNew(
                                                            index, "new");
                                                      });
                                                    },
                                                    child: Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          0.0, 0, 0, 0),
                                                      child: Text(
                                                        "Revoke Access",
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            fontSize: 14.0,
                                                            color: ColorValues
                                                                .BLUE_COLOR_BOTTOMBAR,
                                                            fontFamily: Constant
                                                                .customRegular),
                                                      ),
                                                    ))
                                                : GestureDetector(
                                                    onTap: () {
                                                      setState(() {
                                                        _mProfileLogDataModel
                                                            .result[index]
                                                            .isActive = true;
                                                        apiCallingForUpdateURl(
                                                            index);
                                                      });
                                                    },
                                                    child: Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          0.0, 0, 0, 0),
                                                      child: Text(
                                                        "Grant",
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            fontSize: 14.0,
                                                            color: ColorValues
                                                                .BLUE_COLOR_BOTTOMBAR,
                                                            fontFamily: Constant
                                                                .customRegular),
                                                      ),
                                                    )),
                                          ],
                                        )),
                                  ],
                                ),
                                //color: Colors.transparent
                              ),
                            );
                          })),
                    )
                  : Container(
                      height: 0.0,
                    ),
              Container(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:
                        List.generate(profileShareLogLIst.length, (int index) {
                      return PaddingWrap.paddingfromLTRB(
                        13.0,
                        10.0,
                        13.0,
                        10.0,
                        Container(
                            child: Column(
                              children: <Widget>[
                                Container(
                                  child: Container(
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                height: 50.0,
                                                width: 50.0,
                                                child: Stack(
                                                  children: <Widget>[
                                                    ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              100),
                                                      child: FadeInImage(
                                                          fit: BoxFit.cover,
                                                          placeholder:
                                                              AssetImage(
                                                            'assets/profile/user_on_user.png',
                                                          ),
                                                          image: NetworkImage(
                                                            Constant.IMAGE_PATH_SMALL +
                                                                ParseJson.getSmallImage(
                                                                    profileShareLogLIst[
                                                                            index]
                                                                        .shareToprofilePicture),
                                                          )),
                                                    ),
                                                    profileShareLogLIst[index]
                                                                .isActive ==
                                                            "true"
                                                        ? Container(
                                                            height: 0.0,
                                                          )
                                                        : Container(
                                                            height: 50.0,
                                                            width: 50.0,
                                                            color: Colors.white
                                                                .withOpacity(
                                                                    .6),
                                                          )
                                                  ],
                                                )),
                                            onTap: () {
                                              onTapImageTile(
                                                  profileShareLogLIst[index]
                                                      .shareTo,
                                                  profileShareLogLIst[index]
                                                      .roleId);
                                            },
                                          ),
                                          flex: 0,
                                        ),
                                        Expanded(
                                          child: Container(
                                              padding: EdgeInsets.fromLTRB(
                                                  10.0, 0.0, 0.0, 0.0),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Row(
                                                    children: <Widget>[
                                                      Expanded(
                                                        child: Row(
                                                          children: <Widget>[
                                                            TextViewWrap
                                                                .textViewSingleLine(
                                                                    profileShareLogLIst[index].shareToFirstName ==
                                                                            "null"
                                                                        ? profileShareLogLIst[index]
                                                                            .shareToEmail
                                                                        : profileShareLogLIst[index].shareToLastName ==
                                                                                "null"
                                                                            ? profileShareLogLIst[index]
                                                                                .shareToFirstName
                                                                            : profileShareLogLIst[index].shareToFirstName +
                                                                                " " +
                                                                                profileShareLogLIst[index]
                                                                                    .shareToLastName,
                                                                    TextAlign
                                                                        .start,
                                                                    profileShareLogLIst[index].isActive ==
                                                                            "true"
                                                                        ? ColorValues
                                                                            .HEADING_COLOR_EDUCATION
                                                                        : ColorValues
                                                                            .HEADING_COLOR_EDUCATION
                                                                            .withOpacity(
                                                                                .4),
                                                                    14.0,
                                                                    FontWeight
                                                                        .bold),
                                                            profileShareLogLIst[
                                                                            index] !=
                                                                        null &&
                                                                    profileShareLogLIst[index]
                                                                            .profileOwnerRole ==
                                                                        "1"
                                                                //true
                                                                ? Util.getStudentBadge12(
                                                                    profileShareLogLIst[
                                                                            index]
                                                                        .badge,
                                                                    profileShareLogLIst[
                                                                            index]
                                                                        .badgeImage)
                                                                : Container(),
                                                          ],
                                                        ),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: profileShareLogLIst[
                                                                        index]
                                                                    .isActive ==
                                                                "true"
                                                            ? Align(
                                                                alignment:
                                                                    Alignment
                                                                        .topRight,
                                                                child: GestureDetector(
                                                                    onTap: () {
                                                                      setState(
                                                                          () {
                                                                        confromAtionDialog(
                                                                            index,
                                                                            "");
                                                                      });
                                                                    },
                                                                    child: Container(
                                                                        width: 50.0,
                                                                        height: 20.0,
                                                                        child: Column(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.end,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.end,
                                                                          children: <
                                                                              Widget>[
                                                                            Center(
                                                                                child: Text(
                                                                              "Revoke",
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(fontSize: 12.0, color: ColorValues.BLUE_COLOR_BOTTOMBAR, fontFamily: Constant.customRegular),
                                                                            ))
                                                                          ],
                                                                        ))))
                                                            : Align(
                                                                alignment: Alignment.topRight,
                                                                child: GestureDetector(
                                                                    onTap: () {
                                                                      setState(
                                                                          () {
                                                                        profileShareLogLIst[index].isActive =
                                                                            "true";
                                                                        apiCallingForUpdateStudentStatus(
                                                                            index);
                                                                      });
                                                                    },
                                                                    child: Container(
                                                                        width: 50.0,
                                                                        height: 20.0,
                                                                        child: Column(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.end,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.end,
                                                                          children: <
                                                                              Widget>[
                                                                            Center(
                                                                                child: Text(
                                                                              "Grant",
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(fontSize: 12.0, color: ColorValues.BLUE_COLOR_BOTTOMBAR, fontFamily: Constant.customRegular),
                                                                            ))
                                                                          ],
                                                                        )))),
                                                        flex: 0,
                                                      )
                                                    ],
                                                  ),
                                                  /*  PaddingWrap.paddingfromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            TextViewWrap.textViewSingleLine(
                                                                                profileShareLogLIst[index].shareToEmail,
                                                                                TextAlign.start,
                                                                                profileShareLogLIst[index].isActive == "true" ? ColorValues.GREY_TEXT_COLOR : ColorValues.GREY_TEXT_COLOR.withOpacity(.4),
                                                                                12.0,
                                                                                FontWeight.normal)),*/
                                                ],
                                              )),
                                          flex: 1,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(5.0, 5.0, 0.0, 0.0),
                                  child: Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            TextViewWrap.textViewSingleLine(
                                                "Shared By:",
                                                TextAlign.center,
                                                profileShareLogLIst[index]
                                                            .isActive ==
                                                        "true"
                                                    ? ColorValues
                                                        .GREY_TEXT_COLOR
                                                    : ColorValues
                                                        .GREY_TEXT_COLOR
                                                        .withOpacity(.4),
                                                12.0,
                                                FontWeight.normal),
                                            PaddingWrap.paddingAll(
                                                5.0,
                                                TextViewWrap.textViewSingleLine(
                                                    profileShareLogLIst[index]
                                                        .sharedType,
                                                    TextAlign.center,
                                                    profileShareLogLIst[index]
                                                                .isActive ==
                                                            "true"
                                                        ? ColorValues
                                                            .HEADING_COLOR_EDUCATION
                                                        : ColorValues
                                                            .HEADING_COLOR_EDUCATION
                                                            .withOpacity(.4),
                                                    12.0,
                                                    FontWeight.normal)),
                                          ],
                                        ),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        child: Container(),
                                        flex: 1,
                                      ),
                                      Expanded(
                                        child: Row(
                                          children: <Widget>[
                                            TextViewWrap.textViewSingleLine(
                                                "On: ",
                                                TextAlign.start,
                                                profileShareLogLIst[index]
                                                            .isActive ==
                                                        "true"
                                                    ? ColorValues
                                                        .GREY_TEXT_COLOR
                                                    : ColorValues
                                                        .GREY_TEXT_COLOR
                                                        .withOpacity(.4),
                                                12.0,
                                                FontWeight.normal),
                                            PaddingWrap.paddingAll(
                                                0.0,
                                                TextViewWrap.textViewMultiLine(
                                                    profileShareLogLIst[index]
                                                        .shareTime,
                                                    TextAlign.center,
                                                    profileShareLogLIst[index]
                                                                .isActive ==
                                                            "true"
                                                        ? ColorValues
                                                            .HEADING_COLOR_EDUCATION
                                                        : ColorValues
                                                            .HEADING_COLOR_EDUCATION
                                                            .withOpacity(.4),
                                                    12.0,
                                                    FontWeight.normal,
                                                    2)),
                                          ],
                                        ),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        child: Container(),
                                        flex: 1,
                                      ),
                                      Expanded(
                                        child: Align(
                                            alignment: Alignment.topRight,
                                            child: Row(
                                              children: <Widget>[
                                                TextViewWrap.textViewSingleLine(
                                                    "Status: ",
                                                    TextAlign.start,
                                                    profileShareLogLIst[index]
                                                                .isActive ==
                                                            "true"
                                                        ? ColorValues
                                                            .GREY_TEXT_COLOR
                                                        : ColorValues
                                                            .GREY_TEXT_COLOR
                                                            .withOpacity(.4),
                                                    12.0,
                                                    FontWeight.normal),
                                                PaddingWrap.paddingAll(
                                                    0.0,
                                                    TextViewWrap.textViewMultiLine(
                                                        profileShareLogLIst[
                                                                        index]
                                                                    .isViewed ==
                                                                "true"
                                                            ? "Viewed"
                                                            : "Not Viewed",
                                                        TextAlign.center,
                                                        profileShareLogLIst[
                                                                        index]
                                                                    .isActive ==
                                                                "true"
                                                            ? ColorValues
                                                                .HEADING_COLOR_EDUCATION
                                                            : ColorValues
                                                                .HEADING_COLOR_EDUCATION
                                                                .withOpacity(
                                                                    .4),
                                                        12.0,
                                                        FontWeight.normal,
                                                        2)),
                                              ],
                                            )),
                                        flex: 0,
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        10.0, 10.0, 0.0, 0.0),
                                    child: Divider(
                                      color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                                      height: 0.0,
                                    ))
                              ],
                            ),
                            color: profileShareLogLIst[index].isViewed == "true"
                                ? Colors.transparent
                                : ColorValues.WHITE.withOpacity(0.1)),
                      );
                    })),
              )
            ],
          )
        : isLoading
            ? Container(
                height: 0.0,
              )
            : Center(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        Image.asset(
                          "assets/no_shareing.png",
                          width: double.infinity,
                          height: 151.0,
                        )),
                    PaddingWrap.paddingfromLTRB(
                        40.0,
                        20.0,
                        40.0,
                        5.0,
                        TextViewWrap.textViewMultiLine(
                            "You haven’t shared your profile yet.",
                            TextAlign.center,
                            ColorValues.GREY_TEXT_COLOR,
                            16.0,
                            FontWeight.bold,
                            2)),
                    PaddingWrap.paddingfromLTRB(
                        40.0,
                        7.0,
                        40.0,
                        40.0,
                        TextViewWrap.textViewMultiLine(
                            "Looks like you have not yet shared your profile with anyone. You can do so from your profile page. Try it out!",
                            TextAlign.center,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                  ],
                ),
              );
  }

  void confromAtionDialogNew(index, type) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 175.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 125.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Center(
                                              child: Column(
                                                children: <Widget>[
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      30.0,
                                                      0.0,
                                                      0.0,
                                                      Text(
                                                          "Are you sure you want to stop sharing using this URL ?",
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontSize: 16.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR))),
                                                  /* PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        10.0,
                                                        0.0,
                                                        0.0,
                                                        RichText(
                                                          maxLines: 5,
                                                          textAlign:
                                                              TextAlign.center,
                                                          text: TextSpan(
                                                            text:
                                                                ' Are you sure you want to stop sharing using this URL ? ',
                                                            style:  TextStyle(
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontSize: 14.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                            children: <
                                                                TextSpan>[],
                                                          ),
                                                        ))*/
                                                ],
                                              ),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Revoke",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);

                                              apiCallingForUpdateURl(index);
                                              setState(() {
                                                _mProfileLogDataModel
                                                    .result[index]
                                                    .isActive = false;
                                              });
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallingForUpdateURl(index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String profileId = _mProfileLogDataModel.result[index].customProfileLink
            .split("/Linear/")[1];
        Codec<String, String> stringToBase64 = utf8.fuse(base64);
        String decodedSharedId =
            stringToBase64.decode(profileId.replaceAll("&SPK", "="));
        Map map = {
          "userId": userIdPref,
          "roleId": roleId,
          "profileId": decodedSharedId,
          "isActive": _mProfileLogDataModel.result[index].isActive
        };
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_PROFILE_SHARE_UPDATE, map);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg+profileShareLogLIst[index].isActive.toString());
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  onTapImageTile(tapedUserId, roleId) {
    if (tapedUserId == userIdPref) {
    } else {
      Util.onTapImageTile(
          tapedUserRole: roleId, partnerUserId: tapedUserId, context: context);
    }
  }

  void confromAtionDialog(index, type) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Center(
                                              child: Column(
                                                children: <Widget>[
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      Text(
                                                          "Are you sure you want to stop sharing?",
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontSize: 16.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR))),
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      RichText(
                                                        maxLines: 5,
                                                        textAlign:
                                                            TextAlign.center,
                                                        text: TextSpan(
                                                          text:
                                                              ' Once stopped ',
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontSize: 14.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                          children: <TextSpan>[
                                                            TextSpan(
                                                                text: profileShareLogLIst[index]
                                                                            .shareToLastName ==
                                                                        "null"
                                                                    ? profileShareLogLIst[
                                                                            index]
                                                                        .shareToFirstName
                                                                    : profileShareLogLIst[
                                                                                index]
                                                                            .shareToFirstName +
                                                                        " " +
                                                                        profileShareLogLIst[
                                                                                index]
                                                                            .shareToLastName,
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR)),
                                                            TextSpan(
                                                              text:
                                                                  " would not be able to see your profile",
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .HEADING_COLOR_EDUCATION,
                                                                  fontSize:
                                                                      14.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            ),
                                                          ],
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Revoke",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              if (type == "new") {
                                                Navigator.pop(context);

                                                apiCallingForUpdateURl(index);
                                                setState(() {
                                                  _mProfileLogDataModel
                                                      .result[index]
                                                      .isActive = false;
                                                });
                                              } else {
                                                Navigator.pop(context);

                                                apiCallingForUpdateStudentStatus(
                                                    index);
                                                setState(() {
                                                  profileShareLogLIst[index]
                                                      .isActive = "false";
                                                });
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallingForUpdateStudentStatus(index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "sharedId": int.parse(profileShareLogLIst[index].sharedId),
          "isActive": profileShareLogLIst[index].isActive
        };

        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_SHARE_UPDATE, map);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg+profileShareLogLIst[index].isActive.toString());
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }
}
