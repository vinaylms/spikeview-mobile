class CategoryFormModel {
  String status;
  List<MainCategory> mainCategoryList;

  CategoryFormModel({this.status, this.mainCategoryList});

  CategoryFormModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      mainCategoryList =  List<MainCategory>();
      json['result'].forEach((v) {
        mainCategoryList.add(new MainCategory.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.mainCategoryList != null) {
      data['result'] = this.mainCategoryList.map((v) => v.toJson()).toList();
    }
    return data;
  }

  int  getUnselctedMainSubjectCount(){
    int unselectedListCount=0;
    for(MainCategory _mMainCategory in mainCategoryList){
      if(!_mMainCategory.isSelected){
        unselectedListCount++;

      }
    }
    return unselectedListCount;
  }

 int  getUnselctedSubjectCount(){
    int unselectedListCount=0;
    for(MainCategory _mMainCategory in mainCategoryList){
      if(_mMainCategory.isSelected){
        for(SubCategory _mSubCategory in _mMainCategory.subCategoryList){
          if(!_mSubCategory.isSelected){
            unselectedListCount++;
          }
        }
      }
    }
    return unselectedListCount;
  }
}

class MainCategory {
  int categoryId;
  String name;
  String description;
  List<SubCategory> subCategoryList;
  bool isSelected = false;

  MainCategory(
      {this.categoryId, this.name, this.description, this.subCategoryList});

  MainCategory.fromJson(Map<String, dynamic> json) {
    categoryId = json['categoryId'];
    name = json['name'];
    description = json['description'];
    if (json['subjects'] != null) {
      subCategoryList =  List<SubCategory>();
      json['subjects'].forEach((v) {
        subCategoryList.add(new SubCategory.fromJson(v));
      });
    }
  }

  String toMapString() {
    String data = "";

    data = data + this.name;

    return data;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['categoryId'] = this.categoryId;
    data['name'] = this.name;
    data['description'] = this.description;
    if (this.subCategoryList != null) {
      data['subjects'] = this.subCategoryList.map((v) => v.toJson()).toList();
    }
    return data;
  }

  String toJsonSelection() {
    return isSelected.toString();
  }
  String toJson12() {
    String data;
    if (this.subCategoryList != null) {
      data = this.subCategoryList.map((v) => v.toJson11()).toString();
    }
    return data;
  }

  List<Map<String, dynamic>> toJsonSubCategory() {
    return this.subCategoryList.map((v) {
      if (v.isSelected) return v.toJson2();
    }).toList();
  }

  Map<String, dynamic> toJson2(isDesignationOtherSelected) {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['categoryId'] = this.categoryId;
    data['name'] = this.name;
    data['isOther'] = isDesignationOtherSelected;

    return data;
  }
}

class SubCategory {
  int subjectId;
  String name;
  String description;
  int categoryId;
  int iV;
  bool isSelected = false;

  SubCategory(
      {this.subjectId, this.name, this.description, this.categoryId, this.iV});

  SubCategory.fromJson(Map<String, dynamic> json) {
    subjectId = json['subjectId'];
    name = json['name'];
    description = json['description'];
    categoryId = json['categoryId'];
    iV = json['__v'];
  }

  String toMapString() {
    String data = "";

    data = data + this.name;

    return data;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['subjectId'] = this.subjectId;
    data['name'] = this.name;
    data['description'] = this.description;
    data['categoryId'] = this.categoryId;
    data['__v'] = this.iV;
    return data;
  }

  String toJson11() {
    return isSelected.toString();
  }

  Map<String, dynamic> toJson2() => {
        "subjectId": subjectId,
        "name": name,
        "isOther": false,
      };
}
