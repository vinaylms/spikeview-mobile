import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/spider_chart_model.dart';

import '../resources/home_repositry.dart';
import 'package:rxdart/rxdart.dart';

class HomeBloc {
  final _repository = HomeRepositry();

  final _postFetcher = PublishSubject<List<UserPostModal>>();

  Stream<List<UserPostModal>> get home => _postFetcher.stream;
  static List<UserPostModal> itemModel;
  bool isApiCalling = false;
  static StreamController homeSyncController = StreamController.broadcast();

  fetcPost(String userId,String roleId, BuildContext context) async {
   // if (itemModel == null && !isApiCalling) {
    try {
      print("fetchPost bloc api call===========");
      isApiCalling = true;
      itemModel = await _repository.fetchPost(userId, roleId, context);
      print(
          "fetchPost bloc api call1===========" + itemModel.length.toString());

      homeSyncController.add(itemModel);
      _postFetcher.sink.add(itemModel);
    }catch(e){
      print(
          "fetchPost bloc api call1===========" + e.toString());
      List<UserPostModal> userPostList =  List<UserPostModal>();
      homeSyncController.add(userPostList);
    }
  /*  } else {
      print("fetchPost bloc alredy save===========");
      var data=DbHelper().getNoteRecs();
      _postFetcher.sink.add(itemModel);
      homeSyncController.add(itemModel);

    }*/
  }



  dispose() {
    _postFetcher.close();

  }
}

final homeBloc = HomeBloc();
