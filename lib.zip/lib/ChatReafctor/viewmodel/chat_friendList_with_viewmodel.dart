import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/ChatReafctor/services/posts_service.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:stacked/stacked.dart';

import '../app/locator.dart';
import 'package:stacked/stacked.dart';

class ChatFriendListWithViewModel extends FutureViewModel<List<Friends>>
    with WidgetsBindingObserver {
  final _postsService = locator<PostsService>();
  List<Friends> friendList =  List();
  String userIdPref, roleId;
  SharedPreferences prefs;
  bool isLoading = true;

  String link, shareId, sharedProfileId,pageName;

  ChatFriendListWithViewModel(this.link, this.shareId, this.sharedProfileId,{this.pageName});

  StreamSubscription<dynamic> _streamSubscription;
  BuildContext context;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    try {

      _streamSubscription =
          GlobalSocketConnection.updateChatController.stream.listen((data) {
            for (Friends model in friendList) {
              if ((model.partnerId == data['sender'] &&
                  model.partnerRoleId == data['senderRoleId']) ||
                  (model.partnerId == data['receiver'] &&
                      model.partnerRoleId == data['receiverRoleId'])) {
                model.lastMessage = data["chat_object"]['lastMessage'];
                model.textSentBy = data["sender"];

                if (data["sender"] != model.userId)
                  model.unreadMessages = model.unreadMessages + 1;

                friendList.remove(model);
                if (userIdPref == "1"||model.partnerId==1) {
                  friendList.insert(0, model);
                  notifyListeners();
                  break;
                } else {
                  friendList.insert(1, model);
                  notifyListeners();
                  break;
                }
                break;
              }
            }
          });

      _streamSubscription =
          GlobalSocketConnection.onlineStatusController.stream.listen((data) {
            for (Friends model in friendList) {
              if (model.partnerId == data['userId']) {
                if (data['presence_status'] == "online") {
                  model.online = 1;
                } else if (data['presence_status'] == "offline") {
                  model.online = 0;
                }
              }
            }
            notifyListeners();
          });


    //  bloc.fetchChatList(userIdPref, context, prefs, false,"0");

      friendList.clear();
      notifyListeners();
      print("friendList length++++" + friendList.length.toString());
      friendList = await _postsService.getPosts();
      isLoading = false;
      print("friendList length++++" + friendList.length.toString());
      notifyListeners();
    } catch (e) {
      print("Error+++" + e.toString());
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // fetchMessages();

      print("onresume viewModel++++++++++++++");
    }
  }

  @override
  Future initialise() {
    WidgetsBinding.instance.addObserver(this);
    getSharedPreferences();
    // TODO: implement initialise
    return super.initialise();
  }

  @override
  Future<List<Friends>> futureToRun() {
    return null;
  }

  onTapItem(context, Friends model) async {

    if (model.isActive) {
      await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               ChatRoomWidget(model, link, shareId,pageName: pageName)));
      Navigator.pop(context);
    } else {
      ToastWrap.showToast(MessageConstant.CONNECTION_INACTIVE_ERROR, context);
    }
  }

  Future<Null> onRefresh() async {
    print("refreshpage+++++++++");
    friendList.clear();
    notifyListeners();
    isLoading = true;
    friendList = await _postsService.getPosts();
    isLoading = false;
    print("friendlist+++++" + friendList.length.toString());
    notifyListeners();
    return null;
  }
}
