import 'dart:async';

import 'package:adhara_socket_io/manager.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';

import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';

import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';


class GroupRequestSentWidgetNew extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return GroupRequestSentWidgetNewState();
  }
}

class GroupRequestSentWidgetNewState extends State<GroupRequestSentWidgetNew> {
  SharedPreferences prefs;
  String userIdPref, roleId, zipCode;
  bool isLoading = true;
  String isPerformChanges = "false";
  List<GroupModel> groupList = List();

  int offset = 0;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    zipCode = prefs.getString(UserPreference.ZIPCODE);
    await apiCallForGet();

    GroupDetailWidgetState.syncDoneController.stream.listen((value) {
      apiCallForGet();
    });
  }

  ScrollController _scrollController = ScrollController();
  int skip = 0;
  bool isLoadMore = true;
  bool isLoadingData = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _scrollController = ScrollController();
    _scrollController.addListener(_scrollListener);
    getSharedPreferences();
    print("==================== INIT STATE");
  }

  _scrollListener() {
    if (_scrollController.offset >=
        _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      offset++;
      if (isLoadMore) {
        apiCallForLoadMore();
      }
    }
  }



//==========================================================

  Future apiCallForGet() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        offset=0;
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.GET_GROUP_BY_TYPE +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=0&status=Requested&name=",
            "get");
        isLoading = false;
        setState(() {
          isLoading;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groupList = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {
                groupList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallForLoadMore() async {
    try {
      print("load mo0re call");
      isLoadingData = true;
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        print("load mo0re call++" +
            Constant.GET_GROUP_BY_TYPE +
            userIdPref +
            "&roleId=" +
            roleId +
            "&skip=$offset&status=Requested&name=");
        response = await ApiCalling().apiCall(
            context,
            Constant.GET_GROUP_BY_TYPE +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=$offset&status=Requested&name=",
            "get");

        isLoadingData = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var groupList1 = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {
                groupList.addAll(groupList1);
              });

              if (groupList1.length > 0) {
                setState(() {
                  groupList.addAll(groupList1);
                });
              } else {
                isLoadMore = false;
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadingData = false;

      e.toString();
    }
  }

  Future apiCallForDelete(groupId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "groupId": groupId,
          "status": "Rejected",
          "roleId": int.parse(roleId),
          "isAdmin": true,
          "userId": int.parse(userIdPref),
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_DELETE_GROUP_MEMBER, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg, context);

              if (mounted) {
                apiCallForGet();
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupRequestSentWidget", context);
      e.toString();
    }
  }

  void showConfirmationAlert(groupId, index) {

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            msg: 'Are you sure you want to withdraw?',
            negativeText: 'Cancel',
            positiveText: 'Withdraw',
            isSucessPopup: false,
            positiveTextColor:AppConstants
                .colorStyle.btn_text_red,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              apiCallForDelete(groupId, index);
            },
          );
        });


  }



  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Widget getListview(groupModel, index) {
      print("url" + groupModel.groupImage);

      return PaddingWrap.paddingfromLTRB(
        20.0,
        10.0,
        20.0,
        0.0,
        InkWell(
          child: Column(
            children: [
              Container(
                  child: Row(

                    children: <Widget>[
                      Expanded(child:
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [




                          Expanded(
                            child:  ProfileImageView(
                              imagePath:Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getSmallImage(
                                      groupModel.groupImage) ,
                              placeHolderImage:'assets/newDesignIcon/group/default_circle_bg.png',
                              height: 48.0,
                              width: 48.0,
                              onTap: () async{
                                String result = await     Navigator.of(context).push(MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        GroupDetailWidget(
                                            groupModel.groupId, "", "", "", "")));
                                // print('refresh++++++connected++'+result.trim().toString());
                                if (result == 'push') {
                                  apiCallForGet();
                                }
                              },
                            ) ,
                            flex: 0,
                          ),
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                5.0,
                                10.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        7.0,
                                        0.0,
                                        2.0,
                                        0.0,
                                        RichText(
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.start,
                                          text: TextSpan(
                                            text: groupModel.groupName + " ",
                                            style: TextStyle(
                                              fontStyle: FontStyle.normal,
                                              color: AppConstants.colorStyle.darkBlue,
                                              fontSize: 16,
                                              fontWeight: FontWeight.w600,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoMedium,
                                            ),
                                            children: (!groupModel.isAdmin)
                                                ? null
                                                : <TextSpan>[
                                              TextSpan(
                                                  text: '(Owner)',
                                                  style: TextStyle(
                                                    fontStyle: FontStyle.normal,
                                                    color: AppConstants
                                                        .colorStyle.darkBlue,
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily: AppConstants
                                                        .stringConstant
                                                        .latoRegular,
                                                  ))
                                            ],
                                          ),
                                        )),
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                7.0,
                                                6.0,
                                                0.0,
                                                0.0,
                                                Image.asset(
                                                  groupModel.type == "private"
                                                      ? "assets/png/private_group.png"
                                                      : "assets/png/public_group.png",
                                                  height: 15.0,
                                                  width: 15.0,
                                                ),
                                              ),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  5.0,
                                                  0.0,
                                                  0.0,
                                                  BaseText(
                                                    text: groupModel.type ==
                                                        MessageConstant
                                                            .ABOUT_GROUP_PRIVATE
                                                        ? MessageConstant
                                                        .ABOUT_GROUP_PRIVATE_GROUP
                                                        : MessageConstant
                                                        .ABOUT_GROUP_PUBLIC_GROUP,
                                                    textColor: ColorValues
                                                        .labelColor,
                                                    fontFamily: AppConstants
                                                        .stringConstant.latoRegular,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 14,
                                                    textAlign: TextAlign.start,
                                                    maxLines: 3,
                                                  ))
                                            ],
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    )
                                  ],
                                )),
                            flex: 1,
                          ),
                        ],),flex: 1,),

                      Expanded(child:
                      Row(children: [
                        Center(
                          child:   ButtonView(
                            btnName: MessageConstant
                                .ABOUT_GROUP_REVOKE,

                            onButtonTap: () {
                              showConfirmationAlert(
                                  groupModel.groupId, index);
                            },
                          ),
                        )
                      ],),flex: 0,)

                    ],
                  )),
              Padding(
                padding: const EdgeInsets.only(top: 16.0, bottom: 8),
                child: Container(
                  height: 1,
                  color: AppConstants.colorStyle.btnBg,
                ),
              )
            ],
          ),
          onTap: () {
            Navigator.of(context).push(MaterialPageRoute(
                builder: (BuildContext context) =>
                    GroupDetailWidget(groupModel.groupId, "", "", "", "")));
          },
        ),
      );
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child: isLoading
            ? SizedBox()
            : groupList.length > 0
            ? ListView(
          controller: _scrollController,
          children: <Widget>[
            Column(
              children: <Widget>[
                Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:
                    List.generate(groupList.length, (int index) {
                      return getListview(groupList[index], index);
                    }))
              ],
            )
          ],
        )
            : Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            PaddingWrap.paddingfromLTRB(
                0.0,
                100.0,
                0.0,
                0.0,
                Image.asset(
                  'assets/newDesignIcon/connections/man_to_guide.png',
                  width: double.infinity,
                  height: 111.0,
                )),
            PaddingWrap.paddingfromLTRB(
                40.0,
                20.0,
                40.0,
                5.0,
                TextViewWrap.textViewMultiLine(
                    "Hmm, No results found!",
                    TextAlign.center,
                    ColorValues.GREY_TEXT_COLOR,
                    16.0,
                    FontWeight.bold,
                    2)),
          ],
        ));
  }
}