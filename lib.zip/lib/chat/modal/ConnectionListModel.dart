class ConnectionListModel {
  final String userId;
  final String firstName, lastName,isActive;
  final String email, profilePicture,partnerRoleId;
  final int dateTime;
   String creationTime;

   String partnerFirstName, partnerLastName, partnerProfilePicture,lastMessage, unreadMessageCount,textSentBy;

  final String receiverId, connectId;
  bool isOnline = false;
  bool isSelected = false;

  ConnectionListModel(
      this.userId,
      this.firstName,
      this.lastName,
      this.email,
      this.profilePicture,
      this.dateTime,
      this.receiverId,
      this.connectId,
      this.lastMessage,
      this.unreadMessageCount,
      this.partnerFirstName,
      this.partnerLastName,
      this.partnerProfilePicture,this.isOnline,this.textSentBy,this.isActive,this.isSelected,this.partnerRoleId,this.creationTime);


}