import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:flutter/rendering.dart';

import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';

import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';



class CreateLinkUrl extends StatefulWidget {
  final String selectedLink;
  final List<String> otherLinks;

  CreateLinkUrl({@required this.selectedLink, this.otherLinks});

  @override
  CreateLinkUrlState createState() => CreateLinkUrlState();
}

class CreateLinkUrlState extends State<CreateLinkUrl> with BaseCommonWidget {
  final linkUrlController = TextEditingController();
  final linkFormKey = GlobalKey<FormState>();
  final FocusNode linkTitleFocus = FocusNode();

  @override
  void initState() {
    if (widget.selectedLink != null && widget.selectedLink.isNotEmpty) {
      linkUrlController.text = widget.selectedLink;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext=context;
    return SafeArea(
      child: Scaffold(
        appBar:  AppBar(
          elevation: 0.0,
          backgroundColor: Colors.white,
          centerTitle: true,
          title: Text('Link',
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.primaryTextColor, 18, FontType.Regular)),
          leading: backIcon(context),
          actions: <Widget>[
            InkWell(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(right: 14.0),
                  child: Text(
                    'Done  ',
                    textAlign: TextAlign.center,
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 16, FontType.Regular),
                  ),
                ),
              ),
              onTap: () {
                gotoPreviousPage();
              },
            )
          ],
        ),
        body: Container(
          color: Palette.webColor,
          child: ListView(
            children: <Widget>[
              CustomViews.getSepratorLine(),
              Form(
                key: linkFormKey,
                child: Container(
                  padding: EdgeInsets.all(UIHelper.screenPadding),
                  child:  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      jobWidget(),
                      UIHelper.verticalGapBetweenBox,
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  jobWidget() {
    return Container(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                  right: UIHelper.screenPadding,
                  top: 5,
                  bottom: UIHelper.screenPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  TextFormField(
                    focusNode: linkTitleFocus,
                    controller: linkUrlController,
                    decoration: textFormFieldDecorationWithLabel('URL Of Page',
                        helperText: 'Add a link to a page on your website'),
                    style: textFormFieldValueStyle(),
                    keyboardType: TextInputType.text,
                    textCapitalization: TextCapitalization.none,
                    onFieldSubmitted: (term) {
                      linkTitleFocus.unfocus();
                      gotoPreviousPage();
                    },
                    validator: (value) {
                      return ValidationChecks.validateWebUrl(value);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  gotoPreviousPage() {
    if (linkFormKey.currentState.validate()) {
      Navigator.of(context).pop(linkUrlController.text.toString());
    }
  }
}
