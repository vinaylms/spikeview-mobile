class ChatRoomModel {
  String messageId, connectorId, sender, receiver, time, text, type, status;
  String opportunityId, opportunityTitle, opportunityImage, opportunityDesc;

  ChatRoomModel(
      String messageId,
      String connectorId,
      String sender,
      String receiver,
      String time,
      String text,
      String type,
      String status,
      String opportunityId,
      String opportunityTitle,
      String opportunityImage,
      String opportunityDesc) {
    this.messageId = messageId;
    this.connectorId = connectorId;
    this.sender = sender;
    this.receiver = receiver;
    this.time = time;
    this.text = text;
    this.type = type;
    this.status = status;

    this.opportunityId = opportunityId;
    this.opportunityTitle = opportunityTitle;
    this.opportunityImage = opportunityImage;
    this.opportunityDesc = opportunityDesc;
  }
}