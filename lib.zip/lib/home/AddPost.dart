import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:metadata_fetch/metadata_fetch.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/home/group_list_for_post.dart';
import 'package:spike_view_project/home/video_player_offline.dart';
import 'package:spike_view_project/home_page/blocs/home_bloc.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/modal/option_menu.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:video_compress/video_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/AddTagGroupWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:path/path.dart' as path;
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

// Create a Form Widget
class AddPost extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  String groupId, link;
  GroupDetailModel groupDetailModel;

  AddPost(this.profileInfoModal, this.groupId,
      {this.groupDetailModel, this.link});

  @override
  AddPostState createState() {
    return AddPostState();
  }
}

class AddPostState extends State<AddPost> {
  var isButtonEnable = false;
  File imageLocalPath;
  int clickEvent = 1;
  int whichSection = 1;
  int dotIndex = 0;
  String proceedButtonName = "Next";
  String uploadedVideoFile = "";
  final addUrlController = TextEditingController();
  String linkTitle, linkImg, linkDes;
  FocusNode descFocusNode = FocusNode();

  SharedPreferences prefs;
  String userIdPref,
      roleId,
      token,
      userProfilePath,
      companyImagePath,
      companyName;
  final _formKey = GlobalKey<FormState>();
  String isType = "Community";
  String thumbnailImagePath;
  List<AssestForPost> assestList = List();
  VoidCallback listener;
  File videoPath;
  String strVideo, strVideo1;
  TextEditingController edtController;

  String sasToken, containerName, strPrefixPathforFeed;
  String strFirstName, strLastName, strEmail;
  List<dynamic> images;

  Future<File> videoFile;
  List<String> azureImageUploadList = List();
  List<String> azureVideoUploadList = List();
  List<AssetIV> azureImageVideoUploadList = List();
  List<VideoPlayerController> _controllerList = List();
  VideoPlayerController _controller;

  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<TagsPost> selectedUerTagLIst = List();

  List<TagModel> selectedUerTagLIst1 = List();
  List<TagsPost> selectedtScopeList = List();
  File imagePath;
  List<String> groupidList = List();
  bool isGroupPost = false;

  Future apiCallingUpdateDialogStatus() async {
    try {
      Response response;
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "featureKey": ["communityPost"],
        "display": false
      };

      response = await ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_DIALOG_STATUS, map);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setBool(UserPreference.IS_COMMUNITY_POPUP, false);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    companyImagePath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    companyName = prefs.getString(UserPreference.COMPANY_NAME_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);

    if (widget.groupId != "") {
      setState(() {
        isType = "Group";
        isGroupPost = true;
      });
    }

    setState(() {
      userProfilePath;
    });

    strPrefixPathforFeed = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
    await callApiForSaas();
    if (widget.link != null && widget.link != "") {
      edtController.selection =
          TextSelection.fromPosition(TextPosition(offset: 0));
    }
    //anaylytics.setCurrentSreen(ScreenNameConstant.add_post);
  }

  @override
  void initState() {
    edtController = TextEditingController(text: '');
    if (widget.link != null && widget.link != "") {
      edtController.text = widget.link;
      edtController.selection =
          TextSelection.fromPosition(TextPosition(offset: 0));
    }
    getSharedPreferences();

    // TODO: implement initState
    listener = () {
      setState(() {});
    };

    super.initState();
  }

  @override
  void deactivate() {
    if (_controller != null) {
      _controller.setVolume(0.0);
      _controller.removeListener(listener);
    }
    super.deactivate();
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling().apiCall2(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future<String> compressonVideoFile(File file, String targetPath) async {
    File uploadingFile;

    final info = await VideoCompress.compressVideo(
      file.path,
      quality: VideoQuality.MediumQuality,
      deleteOrigin: false,
    );

    debugPrint(info.toJson().toString());
//uploadingFile =  File(info.path);

    return info.path;
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath, isImage) async {
    try {
      if (sasToken != "" && containerName != "") {
        final String result = await platform.invokeMethod('getBatteryLevel', {
          "sasToken": sasToken,
          "imagePath": imagePath,
          "uploadPath": Constant.IMAGE_PATH + prefixPath
        });

        return result;
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  //-------------------------------------Api Calling for feed--------------------------

  Future apiCalling() async {
    try {
      if (assestList.length > 0) {
        for (int i = 0; i < assestList.length; i++) {
          if (assestList[i].type == 'image') {
            String azureUploadPath = await uploadImgOnAzure(
                assestList[i].imagePath, strPrefixPathforFeed, true);
            azureImageUploadList.add(strPrefixPathforFeed + azureUploadPath);
            azureImageVideoUploadList.add(AssetIV(
                file: strPrefixPathforFeed + azureUploadPath, type: "image"));
          } else {
            String videopath = await uploadImgOnAzure(
                assestList[i].file, strPrefixPathforFeed, false);
            print("sss video path ${strPrefixPathforFeed + videopath}");
            strVideo1 = videopath;
            azureVideoUploadList.add(strPrefixPathforFeed + videopath);
            azureImageVideoUploadList.add(
                AssetIV(file: strPrefixPathforFeed + videopath, type: "video"));
          }
        }
      }
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map;

        bool isCommunityPost = false;
        if (isType == "Community") {
          isCommunityPost = true;
        }

        if (edtController.text != "" || assestList.length > 0) {
          if (assestList.length > 0) {
            map = {
              "post": {
                "text": edtController.text,
                "assets": azureImageVideoUploadList.map((e) => e).toList(),
                // "images": azureImageUploadList.map((item) => item).toList(),
                // "media": azureVideoUploadList.length > 0
                //     ? strPrefixPathforFeed + strVideo1//azureVideoUploadList.map((item) => item).toList()
                //     : ""
              },
              "postedBy": int.parse(userIdPref),
              "dateTime": DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": widget.profileInfoModal.isActive,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
              "isCommunityPost": isCommunityPost,
              "groupIds": groupidList.map((item) => int.parse(item)).toList(),
            };
          }
          else {
            map = {
              "post": {
                "text": edtController.text,
                "assets": [],
                //  "images": [], "media": ""
              },
              "postedBy": int.parse(userIdPref),
              "dateTime": DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": widget.profileInfoModal.isActive,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
              "isCommunityPost": isCommunityPost,
              "groupIds": groupidList.map((item) => int.parse(item)).toList(),
            };
          }
          print("SSS success ${map.toString()}");
          Response response = await ApiCalling()
              .apiCallPostWithMapData(context, Constant.ENDPOINT_ADD_FEED, map);
          if (widget.link != null && widget.link != null) {
            if (widget.groupId == null || widget.groupId == "") {
            } else {
              CustomProgressLoader.cancelLoader(context);
            }
          } else {
            CustomProgressLoader.cancelLoader(context);
          }
          if (response != null) {
            print("SSS success ${response.data}");
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];

              if (status == "Success") {
                //ToastWrap.showToast(msg);
                if (widget.link != null && widget.link != null) {
                  if (roleId == "1") {
                    // For Studenet
                    print("SSS api call 1");
                    DbHelper().deleteTable();
                    homeBloc.fetcPost(userIdPref, roleId, context);
                    if (widget.groupId == null || widget.groupId == "") {
                      Timer(const Duration(milliseconds: 2000), () async {
                        CustomProgressLoader.cancelLoader(context);
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) => DashBoardWidget(
                                    prefs.getString(
                                        UserPreference.IS_PARENT_ROLE),
                                    prefs.getString(
                                        UserPreference.IS_PARTNER_ROLE),
                                    prefs
                                        .getString(UserPreference.IS_USER_ROLE),
                                    currentPage: widget.groupId == null ||
                                            widget.groupId == ""
                                        ? Constant.FEED_TYPE
                                        : Constant.GROUP_TYPE)));
                      });
                    } else {
                      print("SSS api call 2");
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) => DashBoardWidget(
                                  prefs
                                      .getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(
                                      UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: widget.groupId == null ||
                                          widget.groupId == ""
                                      ? Constant.FEED_TYPE
                                      : Constant.GROUP_TYPE)));
                    }
                  } else if (roleId == "2") {
                    print("SSS api call 3");
                    DbHelper().deleteTable();
                    homeBloc.fetcPost(userIdPref, roleId, context);
                    if (widget.groupId == null || widget.groupId == "") {
                      Timer(const Duration(milliseconds: 2000), () async {
                        CustomProgressLoader.cancelLoader(context);
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) => DashBoardWidgetParent(
                                    prefs.getString(
                                        UserPreference.IS_PARENT_ROLE),
                                    prefs.getString(
                                        UserPreference.IS_PARTNER_ROLE),
                                    prefs
                                        .getString(UserPreference.IS_USER_ROLE),
                                    currentPage: widget.groupId == null ||
                                            widget.groupId == ""
                                        ? Constant.FEED_TYPE
                                        : Constant.GROUP_TYPE)));
                      });
                    } else {
                      print("SSS api call 4");
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) => DashBoardWidgetParent(
                                  prefs
                                      .getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(
                                      UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: widget.groupId == null ||
                                          widget.groupId == ""
                                      ? Constant.FEED_TYPE
                                      : Constant.GROUP_TYPE)));
                    }

                    // For Parent
                  } else if (roleId == "4") {
                    print("SSS api call 5");
                    DbHelper().deleteTable();
                    homeBloc.fetcPost(userIdPref, roleId, context);
                    if (widget.groupId == null || widget.groupId == "") {
                      Timer(const Duration(milliseconds: 2000), () async {
                        CustomProgressLoader.cancelLoader(context);
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) => DashBoardWidgetPartner(
                                    prefs.getString(
                                        UserPreference.IS_PARENT_ROLE),
                                    prefs.getString(
                                        UserPreference.IS_PARTNER_ROLE),
                                    prefs
                                        .getString(UserPreference.IS_USER_ROLE),
                                    currentPage: widget.groupId == null ||
                                            widget.groupId == ""
                                        ? Constant.FEED_TYPE
                                        : Constant.GROUP_TYPE)));
                      });
                    } else {
                      print("SSS api call 6");
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) => DashBoardWidgetPartner(
                                  prefs
                                      .getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(
                                      UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: widget.groupId == null ||
                                          widget.groupId == ""
                                      ? Constant.FEED_TYPE
                                      : Constant.GROUP_TYPE)));
                    }

                    // For Partner
                  }
                } else {
                  print("SSS api call 7");
                  final GlobalKey<ScaffoldState> _scaffoldKey1 =
                      GlobalKey<ScaffoldState>();
                  RewardStatusResponse apiResponse =
                      RewardStatusResponse.fromJson(response.data);
                  Navigator.pop(context, apiResponse);
                  /*     Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              NewHomeWidget(_scaffoldKey1, 0)));*/
                  // Util.showRewardPointPush(apiResponse.rewardStatus, context);
                  //Navigator.pop(context, "push");
                }
              }
            }
          }
        } else {
          ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  void conformationDialogForCommunityPost() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "spikeview community post has to be reviewed by the community admin. It will be visible once approved.",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Post",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              CustomProgressLoader.showLoader(
                                                  context);

                                              apiCalling();
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  @override
  void dispose() {
    super.dispose();
    if (_controller != null) _controller.dispose();
  }

  void onTapTagBtn() async {
    if (widget.groupId == "") {
      List<TagModel> result = await Navigator.of(context).push(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  AddTagWidget("Tag connections", selectedUerTagLIst1)));

      if (result != null) {
        selectedUerTagLIst1.clear();
        selectedUerTagLIst.clear();
        selectedUerTagLIst1 = result;
      }

      // Create List for API Calling

      setState(() {
        for (int i = 0; i < selectedUerTagLIst1.length; i++) {
          selectedUerTagLIst.add(new TagsPost(
              selectedUerTagLIst1[i].userId, selectedUerTagLIst1[i].roleId));
        }
      });
    } else {
      List<TagModel> result = await Navigator.of(context).push(
          MaterialPageRoute(
              builder: (BuildContext context) => AddTagGroupWidget(
                  "Tagging", widget.groupId, selectedUerTagLIst1)));

      if (result != null) {
        selectedUerTagLIst1.clear();
        selectedUerTagLIst.clear();
        selectedUerTagLIst1 = result;
      }

      // Create List for API Calling

      setState(() {
        for (int i = 0; i < selectedUerTagLIst1.length; i++) {
          selectedUerTagLIst.add(new TagsPost(
              selectedUerTagLIst1[i].userId, selectedUerTagLIst1[i].roleId));
        }
      });
    }
  }

  _buildChoiceList() {
    List<Widget> choices = List();
    selectedUerTagLIst1.forEach((item) {
      if (item.isSelected) {
        choices.add(PaddingWrap.paddingAll(
            7.0,
            Container(
              decoration: BoxDecoration(
                color: AppConstants.colorStyle.orangeShade,
                borderRadius: const BorderRadius.all(Radius.circular(10)),
              ),
              padding: const EdgeInsets.all(10.0),
              child: Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                children: <Widget>[
                  Text(
                    item.firstName + " " + item.lastName,
                    overflow: TextOverflow.ellipsis,
                    style: AppConstants.txtStyle.heading16500LatoRegularWhite,
                  ),
                  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                        Icon(
                          Icons.clear,
                          color: Colors.white,
                          size: 18.0,
                        )),
                    onTap: () {
                      setState(() {
                        selectedUerTagLIst1.remove(item);
                        selectedUerTagLIst.remove(item);
                      });
                    },
                  )
                ],
              ),
            )));
      }
    });
    return choices;
  }

  Widget sectionsSeparators() {
    return Row(
      children: [
        Expanded(
          child: Container(
              margin: EdgeInsets.only(left: 20),
              height: 6,
              decoration: BoxDecoration(
                color: ColorValues.DARK_YELLOW,
                borderRadius: const BorderRadius.all(Radius.circular(4)),
              )),
        ),
        Expanded(
          child: Container(
              margin: EdgeInsets.only(right: 20, left: 6),
              height: 6,
              decoration: BoxDecoration(
                color: whichSection == 1
                    ? ColorValues.LIGHT_GREY
                    : ColorValues.DARK_YELLOW,
                borderRadius: const BorderRadius.all(Radius.circular(4)),
              )),
        ),
      ],
    );
  }

  sectionOne() {
    return Expanded(
      child: ListView(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        children: <Widget>[
          const SizedBox(height: 40),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Padding(
                  padding: const EdgeInsets.only(
                      top: 0.0, left: 20, right: 20, bottom: 10),
                  child: CustomFormField(
                    autovalidateMode: AutovalidateMode.disabled,
                    maxLines: 3,
                    minLines: 3,
                    maxLength: 2000,
                    counterTextValue: true,
                    alignLabelWithHint: true,
                    controller: edtController,
                    textInputType: TextInputType.text,
                    onType: (val) {
                      setState(() {
                        if (val.isNotEmpty && edtController.text.trim() != "") {
                          isButtonEnable = true;
                        } else
                          isButtonEnable = false;
                      });
                    },
                    onSaved: (text) {},
                    label: 'Description',
                  )),
              clickEvent == 1
                  ? PaddingWrap.paddingfromLTRB(
                      20.0, 27.0, 20.0, 0.0, mediaSection())
                  : clickEvent == 2
                      ? PaddingWrap.paddingfromLTRB(
                          20.0, 26.0, 20.0, 0.0, linkSection())
                      : SizedBox(),
              const SizedBox(height: 100),
            ],
          ),
        ],
      ),
      flex: 1,
    );
  }

  sectionTwo() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(top: 23),
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          children: [
            assestList.length > 0
                ? SizedBox(
                    height: 280,
                    width: double.maxFinite,
                    child: PageIndicatorContainer(
                      pageView: PageView.builder(
                        itemCount: assestList.length,
                        controller: PageController(),
                        itemBuilder: (context, index) {
                          return Stack(
                            children: <Widget>[
                              assestList.length > 0
                                  ? assestList[index].type == 'image'
                                      ? Container(
                                          height: 280.00,
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                          ),
                                          child: Image.file(
                                              File(assestList[index].imagePath),
                                              fit: BoxFit.cover,
                                              height: 280.0,
                                              width: MediaQuery.of(context)
                                                  .size
                                                  .width))
                                      : Center(
                                          child: Container(
                                          color: Colors.black,
                                          child: Center(
                                            child: VideoPlayPauseOffline(
                                                assestList[index].file, "", true,
                                                pageName: "AddPost"),
                                          ),
                                        ))
                                  : const SizedBox.shrink(),
                              Container(
                                padding:
                                    const EdgeInsets.fromLTRB(20, 12, 20, 12),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Color(0xff000000),
                                      Color(0x00000000),
                                    ],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    ProfileImageView(
                                      imagePath: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getSmallImage(roleId == "4"
                                              ? companyImagePath
                                              : userProfilePath),
                                      placeHolderImage: roleId == "4"
                                          ? "assets/profile/partner_img.png"
                                          : 'assets/profile/user_on_user.png',
                                      height: 46,
                                      width: 46,
                                      onTap: () {},
                                      withoutShadow: true,
                                    ),
                                    const SizedBox(width: 13),
                                    Expanded(
                                      child: Text(
                                        roleId == "4"
                                            ? companyName
                                            : widget.profileInfoModal != null
                                                ? widget.profileInfoModal
                                                                .lastName ==
                                                            null ||
                                                        widget.profileInfoModal
                                                                .lastName ==
                                                            "null" ||
                                                        widget.profileInfoModal
                                                                .lastName ==
                                                            ""
                                                    ? widget.profileInfoModal
                                                        .firstName
                                                    : widget.profileInfoModal
                                                            .firstName +
                                                        " " +
                                                        widget.profileInfoModal
                                                            .lastName
                                                : "",
                                        overflow: TextOverflow.ellipsis,
                                        style: assestList.length > 0
                                            ? AppConstants.txtStyle
                                                .heading16500LatoRegularWhite
                                            : AppConstants.txtStyle
                                                .heading14400LatoRegularDarkBlue,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          );
                        },
                        onPageChanged: (index) {},
                      ),
                      align: IndicatorAlign.bottom,
                      length: assestList.length,
                      indicatorSpace: 10,
                      indicatorColor: assestList.length == 1
                          ? Colors.transparent
                          : const Color(0xffc4c4c4),
                      indicatorSelectorColor: assestList.length == 1
                          ? Colors.transparent
                          : Colors.white,
                      shape: IndicatorShape.circle(size: 5),
                    ),
                  )
                : Container(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        ProfileImageView(
                          imagePath: Constant.IMAGE_PATH_SMALL +
                              ParseJson.getSmallImage(roleId == "4"
                                  ? companyImagePath
                                  : userProfilePath),
                          placeHolderImage: roleId == "4"
                              ? "assets/profile/partner_img.png"
                              : 'assets/profile/user_on_user.png',
                          height: 46,
                          width: 46,
                          onTap: () {},
                        ),
                        const SizedBox(width: 13),
                        Expanded(
                          child: Text(
                            roleId == "4"
                                ? companyName
                                : widget.profileInfoModal != null
                                    ? widget.profileInfoModal.lastName == null ||
                                            widget.profileInfoModal.lastName ==
                                                "null" ||
                                            widget.profileInfoModal.lastName == ""
                                        ? widget.profileInfoModal.firstName
                                        : widget.profileInfoModal.firstName +
                                            " " +
                                            widget.profileInfoModal.lastName
                                    : "",
                            overflow: TextOverflow.ellipsis,
                            style: AppConstants
                                .txtStyle.heading14400LatoRegularDarkBlue,
                          ),
                          flex: 1,
                        )
                      ],
                    ),
                  ), //
            Padding(
              padding: const EdgeInsets.only(left: 20, top: 17),
              child: Row(
                children: <Widget>[
                  Image.asset(
                    "assets/feed/heart_blue.png",
                    height: 15.0,
                    width: 15.0,
                  ),
                  SizedBox(
                    width: 7,
                  ),
                  Image.asset(
                    "assets/feed/comment.png",
                    height: 20.0,
                    width: 20.0,
                  ),
                  SizedBox(
                    width: 7,
                  ),
                  Transform.translate(
                    offset: const Offset(0,-1),
                    child: Image.asset(
                      "assets/feed/share.png",
                      height: 18.0,
                      width: 18.0,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 17, top: 12),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  edtController.text.trim(),
                  textAlign: TextAlign.left,
                  // "We award \$50,000, \$25,000 and \$10,000 scholarships to gifted and high-achieving students, 18 years old.",
                  style: AppConstants.txtStyle.heading14400LatoRegularDarkBlue,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 53),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Tag connections",
                          style: AppConstants
                              .txtStyle.heading18500LatoRegularLightPurple,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 17, top: 10),
                          child: Divider(
                            color: AppConstants.colorStyle.btnBg,
                            thickness: 1,
                            height: 0,
                          ),
                        ),
                      ],
                    ),
                  ),
                  isType == "Private"
                      ? Container(
                          height: 0.0,
                        )
                      : InkWell(
                          onTap: () {
                            onTapTagBtn();
                          },
                          child: Image.asset(
                            "assets/feed/tag_add.png",
                            height: 32.0,
                            width: 32.0,
                          ),
                        ),
                ],
              ),
            ),
            Container(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(15.0, 14.0, 0.0, 0.0),
                  child: Wrap(
                    children: _buildChoiceList(),
                  ),
                )),
            widget.groupId != ""
                ? Container()
                : Container(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.only(left: 20, top: 30),
                    child: Text(
                      AppConstants.stringConstant.sharePostWith,
                      style: AppConstants
                          .txtStyle.heading14500LatoRegularLightPurple,
                    ),
                  ),
            widget.groupId != ""
                ? Container()
                : Padding(
                    padding: EdgeInsets.fromLTRB(20.0, 3.0, 20.0, 0.0),
                    child: isType == "Public"
                        ? InkWell(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Expanded(
                                  child: Text(
                                    "Public",
                                    textAlign: TextAlign.start,
                                    style: AppConstants
                                        .txtStyle.heading18500LatoRegularDarkBlue,
                                  ),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: Image.asset(
                                    "assets/feed/down_arrow.png",
                                    height: 24.0,
                                    width: 24.0,
                                  ),
                                  flex: 0,
                                ),
                              ],
                            ),
                            onTap: () {
                              //_settingModalBottomSheet(context);
                              //onTapWhoCanSeePost();
                              showWhoCanSeeYourPostPopup();
                            })
                        : isType == "Private"
                            ? InkWell(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                      child: Text(
                                        "Private",
                                        textAlign: TextAlign.start,
                                        style: AppConstants.txtStyle
                                            .heading18500LatoRegularDarkBlue,
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: Image.asset(
                                        "assets/feed/down_arrow.png",
                                        height: 24.0,
                                        width: 24.0,
                                      ),
                                      flex: 0,
                                    ),
                                  ],
                                ),
                                onTap: () {
                                  //_settingModalBottomSheet(context);
                                  //onTapWhoCanSeePost();
                                  showWhoCanSeeYourPostPopup();
                                })
                            : isType == "AllConnections"
                                ? InkWell(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            "Connections",
                                            textAlign: TextAlign.start,
                                            style: AppConstants.txtStyle
                                                .heading18500LatoRegularDarkBlue,
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: Image.asset(
                                            "assets/feed/down_arrow.png",
                                            height: 24.0,
                                            width: 24.0,
                                          ),
                                          flex: 0,
                                        ),
                                      ],
                                    ),
                                    onTap: () {
                                      // _settingModalBottomSheet(context);
                                      //onTapWhoCanSeePost();
                                      showWhoCanSeeYourPostPopup();
                                    })
                                : isType == "Community"
                                    ? InkWell(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Expanded(
                                              child: Text(
                                                "Community",
                                                textAlign: TextAlign.start,
                                                style: AppConstants.txtStyle
                                                    .heading18500LatoRegularDarkBlue,
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Image.asset(
                                                "assets/feed/down_arrow.png",
                                                height: 24.0,
                                                width: 24.0,
                                              ),
                                              flex: 0,
                                            ),
                                          ],
                                        ),
                                        onTap: () {
                                          // _settingModalBottomSheet(context);
                                          //onTapWhoCanSeePost();
                                          showWhoCanSeeYourPostPopup();
                                        })
                                    : isType == "Group"
                                        ? InkWell(
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: <Widget>[
                                                Expanded(
                                                  child: Text(
                                                    "Group",
                                                    textAlign: TextAlign.start,
                                                    style: AppConstants.txtStyle
                                                        .heading18500LatoRegularDarkBlue,
                                                  ),
                                                  flex: 1,
                                                ),
                                                Expanded(
                                                  child: Image.asset(
                                                    "assets/feed/down_arrow.png",
                                                    height: 24.0,
                                                    width: 24.0,
                                                  ),
                                                  flex: 0,
                                                ),
                                              ],
                                            ),
                                            onTap: () {
                                              // _settingModalBottomSheet(context);
                                              // onTapWhoCanSeePost();
                                              showWhoCanSeeYourPostPopup();
                                            })
                                        : InkWell(
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: <Widget>[
                                                Expanded(
                                                  child: Text(
                                                    "Selected Connections",
                                                    textAlign: TextAlign.start,
                                                    style: AppConstants.txtStyle
                                                        .heading18500LatoRegularDarkBlue,
                                                  ),
                                                  flex: 1,
                                                ),
                                                Expanded(
                                                  child: Image.asset(
                                                    "assets/feed/down_arrow.png",
                                                    height: 24.0,
                                                    width: 24.0,
                                                  ),
                                                  flex: 0,
                                                ),
                                              ],
                                            ),
                                            onTap: () {
                                              //_settingModalBottomSheet(context);
                                              // onTapWhoCanSeePost();
                                              showWhoCanSeeYourPostPopup();
                                            }),
                  ),
            widget.groupId != ""
                ? Container()
                : Padding(
                    padding: const EdgeInsets.only(right: 20, top: 10, left: 20),
                    child: Divider(
                      color: AppConstants.colorStyle.btnBg,
                      thickness: 1,
                      height: 0,
                    ),
                  ),
            const SizedBox(height: 23),
          ],
        ),
      ),
      flex: 1,
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return WillPopScope(
      onWillPop: () {
        if (widget.link != null && widget.link != null) {
          if (roleId == "1") {
            // For Studenet
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) => DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage:
                            widget.groupId == null || widget.groupId == ""
                                ? Constant.FEED_TYPE
                                : Constant.GROUP_TYPE)));
          } else if (roleId == "2") {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) => DashBoardWidgetParent(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage:
                            widget.groupId == null || widget.groupId == ""
                                ? Constant.FEED_TYPE
                                : Constant.GROUP_TYPE)));

            // For Parent
          } else if (roleId == "4") {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) => DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage:
                            widget.groupId == null || widget.groupId == ""
                                ? Constant.FEED_TYPE
                                : Constant.GROUP_TYPE)));

            // For Partner
          }
        } else {
          Navigator.pop(context, null);
        }
        return Future.value(false);
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: ColorValues.WHITE,
        appBar: AppBar(
          elevation: 0.0,
          automaticallyImplyLeading: false,
          brightness: Brightness.light,
          leadingWidth: 0,
          titleSpacing: 20,
          toolbarHeight: 75,
          actions: [
            const HelpButtonWidget(),
            const SizedBox(width: 20),
          ],
          title: BaseText(
            text: AppConstants.stringConstant.createPost,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              fontFamily: Constant.latoRegular,
              color: ColorValues.HEADING_COLOR_EDUCATION,
            ),
          ),
          backgroundColor: Colors.white,
        ),
        /*appBar: CustomAppBar(
          title: AppConstants.stringConstant.createPost,
          icon: "assets/generateScript/help.png",
          click: () {},
        ),*/
        /*AppBar(
              elevation: 0.0,
              automaticallyImplyLeading: false,
              titleSpacing: 2.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          3.0,
                          Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      if (widget.link != null && widget.link != null) {
                        if (roleId == "1") {
                          // For Studenet
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) =>  DashBoardWidget(
                                      prefs.getString(
                                          UserPreference.IS_PARENT_ROLE),
                                      prefs.getString(
                                          UserPreference.IS_PARTNER_ROLE),
                                      prefs.getString(
                                          UserPreference.IS_USER_ROLE),
                                      currentPage: widget.groupId == null ||
                                          widget.groupId == ""
                                          ? Constant.FEED_TYPE
                                          : Constant.GROUP_TYPE)));
                        } else if (roleId == "2") {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) =>
                                      DashBoardWidgetParent(
                                          prefs.getString(UserPreference
                                              .IS_PARENT_ROLE),
                                          prefs.getString(UserPreference
                                              .IS_PARTNER_ROLE),
                                          prefs.getString(
                                              UserPreference.IS_USER_ROLE),
                                          currentPage: widget.groupId ==
                                              null ||
                                              widget.groupId == ""
                                              ? Constant.FEED_TYPE
                                              : Constant
                                              .GROUP_TYPE)));

                          // For Parent
                        } else if (roleId == "4") {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) =>
                                      DashBoardWidgetPartner(
                                          prefs.getString(UserPreference
                                              .IS_PARENT_ROLE),
                                          prefs.getString(UserPreference
                                              .IS_PARTNER_ROLE),
                                          prefs.getString(
                                              UserPreference.IS_USER_ROLE),
                                          currentPage: widget.groupId ==
                                              null ||
                                              widget.groupId == ""
                                              ? Constant.FEED_TYPE
                                              : Constant
                                              .GROUP_TYPE)));

                          // For Partner
                        }
                      } else {
                        Navigator.pop(context, null);
                      }
                    },
                  )
                ],
              ),
              actions: <Widget>[
                InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      13.0,
                      0.0,
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            "Post",
                            style:  TextStyle(
                                fontSize: 16.0,
                                fontFamily: Constant.customRegular,
                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                          )
                        ],
                      )),
                  onTap: () {
                    if (assestList.length > 0 ||
                        edtController.text.trim() != "" ||
                        videoPath != null) {
                      CustomProgressLoader.showLoader(context);
                      Timer _timer =
                      Timer(const Duration(milliseconds: 400), () {
                        onTapPostButton();
                      });
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.WRITE_SOMETHING_ERROR, context);
                    }
                  },
                )
              ],
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "Create",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:
                        ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              backgroundColor: Colors.white,
            ),*/
        body: Column(
          children: <Widget>[
            const SizedBox(height: 20),
            sectionsSeparators(),
            whichSection == 1 ? sectionOne() : sectionTwo(),
            bottomSection(),
          ],
        ),
      ),
    );
  }

  void getImageLocal() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 205.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        20.0,
                                        0.0,
                                        20.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  const BorderRadius.all(
                                                      Radius.circular(10)),
                                            ),
                                            width: double.infinity,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          AppConstants
                                                              .stringConstant
                                                              .camera,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppConstants
                                                              .txtStyle
                                                              .title18500LatoRegularBlackPopUpTxt,
                                                        )),
                                                    onTap: () async {
                                                      Navigator.pop(context);
                                                      var status =
                                                          await Permission
                                                              .photos.status;
                                                      if (status.isGranted) {
                                                        getThumbnailImage(
                                                            ImageSource.camera);
                                                      } else {
                                                        checkPermissionPhoto(
                                                            context);
                                                      }
                                                    },
                                                  ),
                                                  Container(
                                                    color: AppConstants
                                                        .colorStyle
                                                        .dividerPopUp,
                                                    height: 1.0,
                                                  ),
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          AppConstants
                                                              .stringConstant
                                                              .photoLibrary,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppConstants
                                                              .txtStyle
                                                              .title18500LatoRegularBlackPopUpTxt,
                                                        )),
                                                    onTap: () async {
                                                      Navigator.pop(context);
                                                      var status =
                                                          await Permission
                                                              .photos.status;
                                                      if (status.isGranted) {
                                                        getThumbnailImage(
                                                            ImageSource
                                                                .gallery);
                                                      } else {
                                                        checkPermissionPhoto(
                                                            context);
                                                      }
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 50.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                20.0,
                                0.0,
                                20.0,
                                0.0,
                                Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(10)),
                                    ),
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: AppConstants.txtStyle
                                                  .heading18600LatoRegularLightBlue,
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void uploadPopUp() {
    final List<OptionMenu> list = [
      OptionMenu(
        title: "Camera",
        onTap: () async {
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getImage(ImageSource.camera);
          } else {
            checkPermissionPhoto(context);
          }
        },
      ),
      OptionMenu(
        title: "Photo library",
        onTap: () async {
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getImage(ImageSource.gallery);
          } else {
            checkPermissionPhoto(context);
          }
        },
      ),
      OptionMenu(
        title: "Video library",
        onTap: () async {
          _controller = null;
          videoPath = null;
          print("SSS S");
          getInitVideo();
        },
      ),
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ListView.separated(
                  itemBuilder: (_, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        list[index].onTap();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: BaseText(
                          text: list[index].title,
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          textColor: const Color(0xff27275A),
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (_, index) => Divider(
                    height: 0,
                    thickness: 1,
                    color: const Color(0xffE5EBF0),
                  ),
                  itemCount: list.length,
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                ),
              ),
              const SizedBox(height: 12),
              InkWell(
                onTap: () => Navigator.pop(context),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.all(13),
                  child: BaseText(
                    text: 'Cancel',
                    maxLines: 1,
                    textAlign: TextAlign.center,
                    textColor: const Color(0xff27275A),
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );

    /*showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 32.0,
                            child: Container(
                                height: 205.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        20.0,
                                        0.0,
                                        20.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  const BorderRadius.all(
                                                      Radius.circular(10)),
                                            ),
                                            width: double.infinity,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          AppConstants
                                                              .stringConstant
                                                              .camera,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppConstants
                                                              .txtStyle
                                                              .title18500LatoRegularBlackPopUpTxt,
                                                        )),
                                                    onTap: () async {
                                                      Navigator.pop(context);
                                                      var status =
                                                          await Permission
                                                              .photos.status;
                                                      if (status.isGranted) {
                                                        getImage(
                                                            ImageSource.camera);
                                                      } else {
                                                        checkPermissionPhoto(
                                                            context);
                                                      }
                                                    },
                                                  ),
                                                  Container(
                                                    color: AppConstants
                                                        .colorStyle
                                                        .dividerPopUp,
                                                    height: 1.0,
                                                  ),
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          AppConstants
                                                              .stringConstant
                                                              .photoLibrary,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppConstants
                                                              .txtStyle
                                                              .title18500LatoRegularBlackPopUpTxt,
                                                        )),
                                                    onTap: () async {
                                                      Navigator.pop(context);
                                                      var status =
                                                          await Permission
                                                              .photos.status;
                                                      if (status.isGranted) {
                                                        getImage(ImageSource
                                                            .gallery);
                                                      } else {
                                                        checkPermissionPhoto(
                                                            context);
                                                      }
                                                    },
                                                  ),
                                                  Container(
                                                    color: AppConstants
                                                        .colorStyle
                                                        .dividerPopUp,
                                                    height: 1.0,
                                                  ),
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          AppConstants
                                                              .stringConstant
                                                              .videoLibrary,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppConstants
                                                              .txtStyle
                                                              .title18500LatoRegularBlackPopUpTxt,
                                                        )),
                                                    onTap: () async {
                                                      Navigator.pop(context);
                                                      _controller = null;
                                                      videoPath = null;
                                                      print("SSS S");
                                                      getInitVideo();
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 20.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                20.0,
                                0.0,
                                20.0,
                                0.0,
                                Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(10)),
                                    ),
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: AppConstants.txtStyle
                                                  .heading18600LatoRegularLightBlue,
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));*/
  }

  getLinkData(String url) async {
    print("before data++");
    Metadata data = await extract(
        url); // Use the extract() function to fetch data from the url
    linkTitle = data.title.toString();
    linkImg = data.image.toString();
    linkDes = data.description.toString();
    setState(() {});
  }

  linkSection() {
    return Column(
      children: [
        Padding(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: TextFormField(
              scrollPadding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              keyboardType: TextInputType.text,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              obscureText: false,
              maxLength: TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
              textInputAction: TextInputAction.done,
              controller: addUrlController,
              cursorColor: Constant.CURSOR_COLOR,
              textCapitalization: TextCapitalization.sentences,
              style: AppConstants.txtStyle.heading18500LatoRegularLightBlue,
              decoration: inputDecor("Add URL"),
              validator: (value) {
                if (value.isEmpty) {
                  linkTitle = "";
                  linkImg = "";
                  linkDes = "";
                  //  setState(() {
                  //   linkTitle;
                  //   linkImg;
                  //   linkDes;
                  //  });
                  return '* Field required';
                }
                return null;
              },
              onChanged: (value) {
                setState(() {
                  // if (value.isNotEmpty) {
                  //   isButtonEnable = true;
                  // } else {
                  //   isButtonEnable = false;
                  // }
                  if (ValidationChecks.validateDocURL(value) == null) {
                    isButtonEnable = true;
                    getLinkData(value);
                    /* Timer(Duration(seconds: 5), () async {
                      if (value.startsWith('https')) {
                        apiCall(value);
                      } else {
                        String strAddHttps = "https://" + value;
                        apiCall(strAddHttps);
                      }
                    });*/
                  } else {
                    isButtonEnable = false;
                    linkTitle = "";
                    linkImg = "";
                    linkDes = "";
                    setState(() {
                      linkTitle;
                      linkImg;
                      linkDes;
                    });
                  }
                });
              }),
        ),
        const SizedBox(height: 25),
        Container(
          margin: EdgeInsets.only(left: 12, right: 12),
          child: Stack(
            alignment: Alignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: CachedNetworkImage(
                  imageUrl: linkImg != null && linkImg != ""
                      ? linkImg
                      : "https://www.spikeview.com/wp-content/uploads/2023/01/sv-NSTEMhonors.jpg",
                  placeholder: (context, url) =>
                      _loader(context, "assets/newIcon/add_img.png"),
                  errorWidget: (context, url, error) =>
                      _error("assets/newIcon/add_img.png"),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 50),
                    child: Image.asset(
                      "assets/feed/play_url_video.png",
                      height: 40.0,
                      width: 40.0,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 50),
                    child: Image.asset(
                      "assets/generateScript/cross_close.png",
                      height: 40.0,
                      width: 40.0,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.topLeft,
          child: Text(
            linkTitle != null && linkTitle != "" ? linkTitle : "",
            maxLines: 1,
            style: AppConstants.txtStyle.heading14_500LatoRegularDarkBlue,
          ),
        ),
        const SizedBox(height: 5),
        Align(
          alignment: Alignment.topLeft,
          child: Text(
            /*_mLinkResponseModel!=null?_mLinkResponseModel.result.description:*/
            linkDes != null && linkDes != "" ? linkDes : "",
            style: AppConstants.txtStyle.heading12500LatoRegularLightPurple,
          ),
        ),
        const SizedBox(height: 29),
        thumbnailImagePath != null && thumbnailImagePath != ""
            ? gridSelectedThumbnail()
            : Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: [
                  InkWell(
                    onTap: () {
                      getImageLocal();
                    },
                    child: Column(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 96,
                          child: imageLocalPath != null
                              ? Image.file(
                                  imageLocalPath,
                                )
                              : Column(
                                  children: [
                                    const SizedBox(height: 18),
                                    Image.asset(
                                      "assets/generateScript/camera.png",
                                      height: 26.0,
                                      width: 25.0,
                                    ),
                                    const SizedBox(height: 5),
                                    Text(
                                      'Upload new thumbnail(Optional)',
                                      maxLines: 1,
                                      textAlign: TextAlign.center,
                                      style: AppConstants.txtStyle
                                          .heading14400LatoItalicLightPurple,
                                    ),
                                  ],
                                ),
                          decoration: BoxDecoration(
                            color: AppConstants.colorStyle.tabBg,
                            border: Border.all(
                                color: AppConstants
                                    .colorStyle.borderGenerateScript),
                            borderRadius:
                                const BorderRadius.all(Radius.circular(10)),
                          ),
                        ),
                        SizedBox(
                          height: 12,
                        )
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: InkWell(
                      radius: 50,
                      onTap: () {
                        getImageLocal();
                      },
                      child: Image.asset(
                        "assets/generateScript/plus_icon.png",
                        height: 26.0,
                        width: 25.0,
                      ),
                    ),
                  ),
                ],
              ),
      ],
    );
  }

  InputDecoration inputDecor(labelText) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
      fillColor: Colors.transparent,
      counterText: "",
      labelText: labelText,
      errorStyle: Util.errorTextStyle,
      labelStyle: TextStyle(
          fontFamily: Constant.latoRegular,
          fontStyle: FontStyle.normal,
          fontSize: 18,
          color: Color(0xFF666B9A),
          letterSpacing: 0.0,
          wordSpacing: 0.0,
          fontWeight: FontWeight.w500),
      focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(
              color: ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED, width: 1.0)),
      enabledBorder: UnderlineInputBorder(
          borderSide:
              BorderSide(color: ColorValues.BORDER_COLOR_NEW, width: 1.0)),
      border: UnderlineInputBorder(
          borderSide:
              BorderSide(color: ColorValues.BORDER_COLOR_NEW, width: 1.0)),
    );
  }

  mediaSection() {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            onTap: () {
              uploadPopUp();
            },
            child: Stack(
              alignment: Alignment.center,
              overflow: Overflow.visible,
              children: [
                Column(
                  children: [
                    assestList.length == 0
                        ? Container(
                            width: MediaQuery.of(context).size.width,
                            height: 110,
                            child: Column(
                              children: [
                                const SizedBox(height: 18),
                                assestList.length == 0
                                    ? Image.asset(
                                        "assets/generateScript/camera.png",
                                        height: 26.0,
                                        width: 25.0,
                                      )
                                    : SizedBox(),
                                const SizedBox(height: 5),
                                Text(
                                  assestList.length == 0
                                      ? 'Your uploaded photos/videos will appear here'
                                      : "",
                                  maxLines: 1,
                                  textAlign: TextAlign.center,
                                  style: AppConstants.txtStyle
                                      .heading14400LatoItalicLightPurple,
                                ),
                              ],
                            ),
                            decoration: BoxDecoration(
                              color: AppConstants.colorStyle.tabBg,
                              border: Border.all(
                                  color: AppConstants
                                      .colorStyle.borderGenerateScript),
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                            ),
                          )
                        : Container(
                            width: MediaQuery.of(context).size.width,
                            height: 100,
                            decoration: BoxDecoration(
                              color: AppConstants.colorStyle.tabBg,
                              border: Border.all(
                                  color: AppConstants
                                      .colorStyle.borderGenerateScript),
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(10)),
                            ),
                          ),
                    assestList.length == 0
                        ? SizedBox(
                            height: 12,
                          )
                        : SizedBox()
                  ],
                ),
                Positioned.fill(child: gridSelectedImagesVideos()),
                Positioned(
                  bottom: assestList.length == 0 ? 0 : -12,
                  child: InkWell(
                    radius: 50,
                    onTap: () {
                      uploadPopUp();
                    },
                    child: Image.asset(
                      "assets/generateScript/plus_icon.png",
                      height: 26.0,
                      width: 25.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  cancelButton() {
    return Expanded(
      child: Container(
          margin: EdgeInsets.only(left: 20, right: 12, top: 20, bottom: 30),
          height: 44.0,
          width: 120,
          child: FlatButton(
            onPressed: () async {
              if (proceedButtonName == AppConstants.stringConstant.proceed) {
                setState(() {
                  whichSection = 1;
                  isButtonEnable = true;
                  proceedButtonName = "Next";
                });
              } else {
                if (widget.link != null && widget.link != null) {
                  if (roleId == "1") {
                    // For Student
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                            builder: (context) => DashBoardWidget(
                                prefs.getString(UserPreference.IS_PARENT_ROLE),
                                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                prefs.getString(UserPreference.IS_USER_ROLE),
                                currentPage: widget.groupId == null ||
                                        widget.groupId == ""
                                    ? Constant.FEED_TYPE
                                    : Constant.GROUP_TYPE)));
                  } else if (roleId == "2") {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                            builder: (context) => DashBoardWidgetParent(
                                prefs.getString(UserPreference.IS_PARENT_ROLE),
                                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                prefs.getString(UserPreference.IS_USER_ROLE),
                                currentPage: widget.groupId == null ||
                                        widget.groupId == ""
                                    ? Constant.FEED_TYPE
                                    : Constant.GROUP_TYPE)));

                    // For Parent
                  } else if (roleId == "4") {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                            builder: (context) => DashBoardWidgetPartner(
                                prefs.getString(UserPreference.IS_PARENT_ROLE),
                                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                prefs.getString(UserPreference.IS_USER_ROLE),
                                currentPage: widget.groupId == null ||
                                        widget.groupId == ""
                                    ? Constant.FEED_TYPE
                                    : Constant.GROUP_TYPE)));

                    // For Partner
                  }
                } else {
                  Navigator.pop(context, null);
                }
              }
            },
            shape: RoundedRectangleBorder(
                side: BorderSide(color: AppConstants.colorStyle.btnBg),
                borderRadius: BorderRadius.circular(10)),
            color: AppConstants.colorStyle.white,
            child: Row(
              // Replace with a Row for horizontal icon + text
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Cancel",
                    style: AppConstants
                        .txtStyle.heading18600LatoRegularLightPurple.copyWith(
                      fontFamily: Constant.latoMedium,
                    )),
              ],
            ),
          )),
    );
  }

  proceedButton() {
    return Expanded(
      flex: 2,
      child: Container(
          margin: EdgeInsets.only(right: 20, top: 20, bottom: 30),
          width: 212,
          height: 44.0,
          child: FlatButton(
            onPressed: () {
              if (proceedButtonName == AppConstants.stringConstant.proceed) {
                if (isType == "Community") {
                  postPopUp();
                } else {
                  CustomProgressLoader.showLoader(context);
                  Timer(Duration(seconds: 1),(){
                    apiCalling();
                  });
                }
              } else {
                if (assestList.length > 0 ||
                    edtController.text.trim() != "" ||
                    videoPath != null) {
                  setState(() {
                    whichSection = 2;
                    isButtonEnable = true;
                    proceedButtonName = AppConstants.stringConstant.proceed;
                  });
                } else {
                  ToastWrap.showToast(
                      MessageConstant.WRITE_SOMETHING_ERROR, context);
                }
              }
            },
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            color: isButtonEnable
                ? AppConstants.colorStyle.lightBlue
                : AppConstants.colorStyle.lightBlueButtonDisableColor,
            child: Row(
              // Replace with a Row for horizontal icon + text
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(proceedButtonName,
                    style: AppConstants.txtStyle.heading18600LatoRegularWhite),
              ],
            ),
          )),
    );
  }

  bottomSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        cancelButton(),
        proceedButton(),
      ],
    );
  }

  showWhoCanSeeYourPostPopup() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        builder: (BuildContext bc) {
          return StatefulBuilder(builder: (context, state) {
            return Scaffold(
                backgroundColor: ColorValues.WHITE,
                body: SafeArea(
                  child: Stack(
                    children: [
                      Container(
                        height: double.infinity,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(
                                    "assets/generateScript/script_background.png"),
                                fit: BoxFit.fill)),
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 40, left: 20, right: 20),
                        child: SizedBox(
                          height: 100,
                          width: double.infinity,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pop(context, 'pop');
                                },
                                child: Image.asset(
                                  "assets/generateScript/back.png",
                                  height: 32.0,
                                  width: 32.0,
                                ),
                              ),
                              const HelpButtonWidget(),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          margin: const EdgeInsets.only(top: 125),
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(30),
                                topRight: Radius.circular(30),
                              ),
                            ),
                            child: Column(
                              children: [
                                const SizedBox(height: 25),
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 20, right: 20),
                                  alignment: Alignment.centerLeft,
                                  width: MediaQuery.of(context).size.width,
                                  child: Text(
                                      AppConstants
                                          .stringConstant.whoCanSeeYourPost,
                                      style: AppConstants.txtStyle
                                          .heading28_700LatoRegularDarkBlue),
                                ),
                                const SizedBox(height: 40),
                                Expanded(
                                  child: SingleChildScrollView(
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10),
                                      child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            27.0,
                                                            10.0,
                                                            11.0,
                                                            10.0,
                                                            Image.asset(
                                                              "assets/feed/community.png",
                                                              width: 26.0,
                                                              height: 26.0,
                                                              color: isType == "Community"
                                                                  ? ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR
                                                                  : ColorValues
                                                                      .HEADING_COLOR_EDUCATION,
                                                            )),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            8.0,
                                                            0.0,
                                                            3.0,
                                                            Text("Community",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType ==
                                                                        "Community"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            13.0,
                                                            Text(
                                                                "Visible to all spikeview community members.",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                selectedtScopeList.clear();
                                                groupidList.clear();
                                                isType = "Community";
                                                setState(() {
                                                  isType;
                                                });
                                              },
                                            ),
                                            CustomViews.getSeparatorLineNewUI(
                                                leftPadding: 20.0,
                                                rightPadding: 20.0,
                                                topPadding: 10.0,
                                                bottomPadding: 10.0),
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        27.0,
                                                        10.0,
                                                        11.0,
                                                        10.0,
                                                        Image.asset(
                                                            "assets/feed/group.png",
                                                            width: 26.0,
                                                            height: 26.0,
                                                            color: isType ==
                                                                    "Group"
                                                                ? ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue)),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            8.0,
                                                            0.0,
                                                            3.0,
                                                            Text("Group",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType == "Group"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            4.0,
                                                            13.0,
                                                            Text(
                                                                "Visible to all members in selected groups.",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onClickGroup();
                                              },
                                            ),
                                            CustomViews.getSeparatorLineNewUI(
                                                leftPadding: 20.0,
                                                rightPadding: 20.0,
                                                topPadding: 10.0,
                                                bottomPadding: 10.0),
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            27.0,
                                                            10.0,
                                                            11.0,
                                                            10.0,
                                                            Image.asset(
                                                              "assets/feed/connections.png",
                                                              width: 26.0,
                                                              height: 26.0,
                                                              color: isType == "AllConnections"
                                                                  ? ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR
                                                                  : AppConstants
                                                                      .colorStyle
                                                                      .darkBlue,
                                                            )),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            3.0,
                                                            Text("Connections",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType ==
                                                                        "AllConnections"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            13.0,
                                                            Text(
                                                                "Your connections on spikeview",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 0,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                selectedtScopeList.clear();
                                                groupidList.clear();
                                                isType = "AllConnections";
                                                setState(() {
                                                  isType;
                                                });
                                              },
                                            ),
                                            CustomViews.getSeparatorLineNewUI(
                                                leftPadding: 20.0,
                                                rightPadding: 20.0,
                                                topPadding: 10.0,
                                                bottomPadding: 10.0),
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            27.0,
                                                            10.0,
                                                            11.0,
                                                            10.0,
                                                            Image.asset(
                                                              "assets/feed/selected_connections.png",
                                                              width: 26.0,
                                                              height: 26.0,
                                                              // color: isType == "SelectedConnections"
                                                              //     ? ColorValues
                                                              //         .BLUE_COLOR_BOTTOMBAR
                                                              //     : AppConstants
                                                              //         .colorStyle
                                                              //         .darkBlue,
                                                            )),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            3.0,
                                                            Text(
                                                                "Selected Connections",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType ==
                                                                        "SelectedConnections"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            13.0,
                                                            Text(
                                                                "Only visible to some connections",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 0,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onTapTagSelectedConnection();
                                              },
                                            ),
                                            CustomViews.getSeparatorLineNewUI(
                                                leftPadding: 20.0,
                                                rightPadding: 20.0,
                                                topPadding: 10.0,
                                                bottomPadding: 10.0),
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        27.0,
                                                        15.0,
                                                        11.0,
                                                        10.0,
                                                        Image.asset(
                                                            "assets/feed/private_lock.png",
                                                            width: 26.0,
                                                            height: 26.0,
                                                            color: isType ==
                                                                    "Private"
                                                                ? ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR
                                                                : AppConstants
                                                                .colorStyle
                                                                .darkBlue)),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            3.0,
                                                            Text(
                                                                "Make it Private",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType ==
                                                                        "Private"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            13.0,
                                                            Text(
                                                                "Only visible to me",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 0,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                selectedtScopeList.clear();
                                                groupidList.clear();
                                                selectedUerTagLIst1.clear();
                                                selectedUerTagLIst.clear();
                                                isType = "Private";
                                                setState(() {
                                                  isType;
                                                  selectedUerTagLIst1;
                                                  selectedUerTagLIst;
                                                });
                                              },
                                            ),
                                          ]),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
            );
          });
        }).then((value) => _closeModal(value));
  }

  finalPostButtonPopup() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        enableDrag: false,
        builder: (BuildContext bc) {
          return StatefulBuilder(builder: (context, state) {
            return Scaffold(
              resizeToAvoidBottomInset: false,
              floatingActionButtonLocation:
                  FloatingActionButtonLocation.centerFloat,
              bottomSheet: postButton(),
              backgroundColor: Colors.white,
              body: Stack(
                children: [
                  Container(
                    height: double.infinity,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage(
                                "assets/generateScript/script_background.png"),
                            fit: BoxFit.fill)),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.only(top: 40, left: 20, right: 20),
                    child: SizedBox(
                      height: 100,
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {
                              Navigator.pop(context, 'pop');
                            },
                            child: Image.asset(
                              "assets/generateScript/back.png",
                              height: 32.0,
                              width: 32.0,
                            ),
                          ),
                          const HelpButtonWidget(),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      margin: const EdgeInsets.only(top: 125),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30),
                          ),
                        ),
                        child: Container(
                          transform:
                              Matrix4.translationValues(0.0, -125.0, 0.0),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                SvgPicture.asset("assets/feed/info.svg",
                                    semanticsLabel: 'info Icon'),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 28, right: 28, top: 10),
                                  child: Text(
                                      AppConstants.stringConstant
                                          .spikeCommunityReviewed,
                                      textAlign: TextAlign.center,
                                      style: AppConstants.txtStyle
                                          .heading16600LatoRegularLightPurple),
                                ),
                              ]),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            );
          });
        }).then((value) => _closeModal(value));
  }

  postButton() {
    return Container(
        color: AppConstants.colorStyle.white,
        child: Padding(
            padding: EdgeInsets.only(top: 10.0),
            child: Container(
                margin: EdgeInsets.only(left: 20, right: 20, bottom: 70),
                height: 44.0,
                child: FlatButton(
                  onPressed: () {
                    CustomProgressLoader.showLoader(context);
                    apiCalling();
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  color: AppConstants.colorStyle.lightBlue,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(AppConstants.stringConstant.post,
                          style: AppConstants
                              .txtStyle.heading18600LatoRegularWhite),
                    ],
                  ),
                ))));
  }

  void _closeModal(void value) {
    setState(() {
      //showSignupButton = true;
      //isOpenSignup = !isOpenSignup;
      // isOpenLogin = !isOpenLogin;
    });
  }

// Updated View for POST TYPE
  onClickGroup() async {
    List<String> groupData = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => GroupListForPost(groupidList, widget.groupId)),
    );
    if (groupData != null && groupData.length > 0) {
      selectedtScopeList.clear();
      groupidList.clear();
      groupidList.addAll(groupData);
      isType = "Group";
      setState(() {
        isType;
      });
    }
  }

  void onTapTagSelectedConnection() async {
    List<TagsPost> result = await Navigator.of(context).push(MaterialPageRoute(
        builder: (BuildContext context) => AddMyConnectionSharePost(
            "Select Connections", selectedtScopeList)));

    if (result != null) {
      if (result != null && result.length > 0) {
        isType = "SelectedConnections";

        selectedtScopeList.clear();
        groupidList.clear();
        selectedtScopeList = result;
        setState(() {
          isType;
        });
      }
    }
  }

  void postPopUp() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 50.0,
                            child: Container(
                                height: 205.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        20.0,
                                        0.0,
                                        20.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  const BorderRadius.all(
                                                      Radius.circular(10)),
                                            ),
                                            width: double.infinity,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  SizedBox(
                                                    height: 15,
                                                  ),
                                                  Text(
                                                    AppConstants.stringConstant
                                                        .communityPost,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: AppConstants.txtStyle
                                                        .heading14700LatoRegularDarkBlue,
                                                  ),
                                                  SizedBox(
                                                    height: 7,
                                                  ),
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 14,
                                                            right: 14),
                                                    child: Text(
                                                      AppConstants
                                                          .stringConstant
                                                          .spikeCommunityReviewed,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: AppConstants
                                                          .txtStyle
                                                          .heading14400LatoRegularLightPurple,
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 15,
                                                  ),
                                                  Container(
                                                    color: AppConstants
                                                        .colorStyle
                                                        .dividerPopUp,
                                                    height: 1.0,
                                                  ),
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                12.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          AppConstants
                                                              .stringConstant
                                                              .post,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppConstants
                                                              .txtStyle
                                                              .heading16500LatoRegularLightBlue,
                                                        )),
                                                    onTap: () async {
                                                      Navigator.pop(
                                                          context, 'pop');
                                                      // onTapReviewedPost();
                                                      CustomProgressLoader
                                                          .showLoader(context);
                                                      apiCalling();
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 32.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                20.0,
                                0.0,
                                20.0,
                                0.0,
                                Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(10)),
                                    ),
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              AppConstants
                                                  .stringConstant.cancel,
                                              textAlign: TextAlign.center,
                                              style: AppConstants.txtStyle
                                                  .heading16500LatoRegularDarkBlue,
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future onTapReviewedPost() async {
    finalPostButtonPopup();
    // String result = await Navigator.of(context).push(new MaterialPageRoute(
    //     builder: (BuildContext context) => ReviewedPostScreen()));
    // if (result != "pop") {}
  }

  getImage(type) async {
    if (assestList.length < 8) {
      int numberOfItems = 8 - assestList.length;
      // if (numberOfItems == 1) {

      if (type == ImageSource.gallery) {
        imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
        print("SSS-- 1 ${imagePath}");
        if (imagePath != null) {
          String strPath = imagePath.toString().substring(
              imagePath.toString().lastIndexOf("/") + 1,
              imagePath.toString().length);
          print("SSS-- 2 ${strPath}");
          if (strPath.toString().contains(".") &&
              (!strPath.toString().contains(".gif"))) {
            // await _cropImage(imagePath);
            print("SSS-- 3 ${strPath}");
            if (imagePath != null) {
              print(
                  "SSS-- 4 ${imagePath.toString().replaceAll("File: ", "").replaceAll("'", "").trim()}");
              assestList.add(new AssestForPost(
                  imagePath
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  "image",
                  "",
                  false));
              setState(() {
                assestList;
                if (assestList.length > 0) {
                  isButtonEnable = true;
                }
              });
              // }
            }
          } else {
            ToastWrap.showToast(
                MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
          }
        }
      } else if (type == ImageSource.camera) {
        imagePath = await ImagePicker.pickImage(source: ImageSource.camera);
        print("sss image cam ${imagePath}");
        if (imagePath != null) {
          String strPath = imagePath.toString().substring(
              imagePath.toString().lastIndexOf("/") + 1,
              imagePath.toString().length);
          if (strPath.toString().contains(".") &&
              (!strPath.toString().contains(".gif"))) {
            //  await _cropImage(imagePath);
            if (imagePath != null) {
              assestList.add(new AssestForPost(
                  imagePath
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  "image",
                  "",
                  false));
              setState(() {
                FocusScope.of(context).requestFocus(FocusNode());
                assestList;
                if (assestList.length > 0) {
                  isButtonEnable = true;
                }
              });
              // }
            }
          } else {
            ToastWrap.showToast(
                MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
          }
        }
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.MAXIMUM_8_IMAGE_UPLOADED_VAL, context);
    }
  }

  getThumbnailImage(type) async {
    if (type == ImageSource.gallery) {
      imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);

      if (imagePath != null) {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          // await _cropImage(imagePath);
          if (imagePath != null) {
            thumbnailImagePath = imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim();

            print("SSS image path 1 ${thumbnailImagePath}");
            setState(() {
              thumbnailImagePath;
            });
            // }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    } else if (type == ImageSource.camera) {
      imagePath = await ImagePicker.pickImage(source: ImageSource.camera);

      if (imagePath != null) {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          //  await _cropImage(imagePath);
          if (imagePath != null) {
            thumbnailImagePath = imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim();

            print("SSS image path ${thumbnailImagePath}");
            setState(() {
              FocusScope.of(context).requestFocus(FocusNode());
              thumbnailImagePath;
            });
            // }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }
  }

  getInitVideo() async {
    try {
      if (_controller == null && videoPath == null) {
        print("sss 1 getVideo");
        var status = await Permission.photos.status;
        if (status.isGranted) {
          getVideo();
        } else {
          checkPermissionPhoto(context);
        }
      } else if (_controller != null && (videoPath != null)) {
        // If there was a controller, we need to dispose of the old one first
        final oldController = _controller;
        print("sss 2 getVideo");
        // Registering a callback for the end of next frame
        // to dispose of an old controller
        // (which won't be used anymore after calling setState)
        WidgetsBinding.instance.addPostFrameCallback((_) async {
          await oldController.dispose();

          // Initing  controller
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getVideo();
          } else {
            checkPermissionPhoto(context);
          }
        });

        // Making sure that controller is not used by setting it to null
        setState(() {
          _controller = null;
          videoPath = null;
        });
      }
    } catch (e) {}
  }

  getVideo() async {
    try {
      if (_controllerList.length < 1) {
        String getFileExtension(File file) {
          print("sss file path${path.extension(file.path)}");
          return path.extension(file.path);
        }

        await ImagePicker.pickVideo(source: ImageSource.gallery)
            .then((File file) {
          if (file != null &&
              getFileExtension(file) != null &&
              getFileExtension(file).length > 0) {
            setState(() {
              _controller = VideoPlayerController.file(file)
                ..addListener(listener)
                ..setVolume(1.0)
                ..initialize()
                ..setLooping(false);
              _controllerList.add(_controller);
              videoPath = file;
              if (videoPath != null && _controller != null) {
                assestList.add(new AssestForPost(
                    "",
                    "video",
                    videoPath
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    false,
                    controller: _controller,
                    videoPath: videoPath));
                print(
                    "sss video path 1 ${videoPath.toString().replaceAll("File: ", "").replaceAll("'", "").trim()}");
                setState(() {
                  assestList;
                  if (assestList.length > 0) {
                    isButtonEnable = true;
                  }
                });
              }
            });
          } else if (file != null) {
            ToastWrap.showToast(
                MessageConstant.VIDEO_SOURCE_INCORRECT_ERROR, context);
          } else {
            setState(() {
              _controller = null;
              videoPath = null;
            });
          }
        });
      } else {
        ToastWrap.showToast(
            MessageConstant.MAXIMUM_1_VIDEO_UPLOADED_VAL, context);
      }
    } catch (e) {}
  }

  void reorderData(int oldindex, int newindex) {
    setState(() {
      if (newindex > oldindex) {
        newindex -= 1;
      }
      final items = assestList.removeAt(oldindex);
      assestList.insert(newindex, items);
    });
  }

  Widget gridSelectedImagesVideos() {
    return assestList != null && assestList.length > 0
        ? PaddingWrap.paddingfromLTRB(
            15.0,
            0.0,
            15.0,
            0.0,
            Container(
              width: double.maxFinite,
              height: 100.0,
              child: ReorderableListView(
                onReorder: reorderData,
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.zero,
                children: List.generate(assestList.length, (int index) {
                  return assestList[index].imagePath.isEmpty
                      ? Container(
                          width: 150,
                          height: 60,
                          key: ValueKey(assestList[index]),
                          margin: const EdgeInsets.only(right: 12),
                          child: Stack(
                            key: ValueKey(assestList[index]),
                            children: [
                              Container(
                                width: 150,
                                child: Row(
                                  children: [
                                    Image.asset(
                                      "assets/generateScript/wall_frame_video.png",
                                      height: 60.0,
                                      width: 25.0,
                                    ),
                                    _controllerList.length > 0
                                        //_controller.value.initialized
                                        ? Container(
                                            transform:
                                                Matrix4.translationValues(
                                                    -4, 0.0, 0.0),
                                            width: 100,
                                            height: 60,
                                            child: AspectRatio(
                                              aspectRatio: assestList[index]
                                                  .controller
                                                  .value
                                                  .aspectRatio,
                                              child: VideoPlayer(
                                                  assestList[index].controller),
                                            ),
                                          )
                                        : Container(
                                            transform:
                                                Matrix4.translationValues(
                                                    -4, 0.0, 0.0),
                                            height: 60,
                                            width: 100,
                                            child: Image.asset(
                                              "assets/newIcon/add_img.png",
                                            ),
                                          ),
                                    Container(
                                      transform: Matrix4.translationValues(
                                          -8, 0.0, 0.0),
                                      child: Image.asset(
                                        "assets/generateScript/wall_frame_video.png",
                                        height: 60.0,
                                        width: 25.0,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Positioned(
                                top: 16,
                                left: 30,
                                child: InkWell(
                                  onTap: () {
                                    print("SSS Play videos");
                                    thumbnailVideoImagePopup(index);
                                    if (uploadedVideoFile.isNotEmpty) {
                                      print("SSS Play videos");
                                      //uploadedVideoPopUp();
                                    }
                                  },
                                  child: Image.asset(
                                    "assets/generateScript/play_video_mini.png",
                                    height: 25.0,
                                    width: 25.0,
                                  ),
                                ),
                              ),
                              Positioned(
                                top: 16,
                                right: 35,
                                child: InkWell(
                                  onTap: () {
                                    print("SSS tab cancel");
                                    assestList.removeAt(index);
                                    _controllerList.clear();
                                    _controller = null;
                                    videoPath = null;
                                    setState(() {
                                      if (assestList.length > 0) {
                                        print("Enable btn");
                                      } else {
                                        isButtonEnable = false;
                                      }
                                    });
                                  },
                                  child: Image.asset(
                                    "assets/generateScript/cross_close.png",
                                    height: 25.0,
                                    width: 25.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      : Container(
                          width: 120,
                          height: 60,
                          key: ValueKey(assestList[index]),
                          margin: const EdgeInsets.only(right: 12),
                          child: Stack(
                            key: ValueKey(assestList[index]),
                            children: [
                              Container(
                                width: 120,
                                height: 60,
                                child: Image.file(
                                  File(assestList[index].imagePath),
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(
                                        "assets/generateScript/light_dark_bgrnd.png"),
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                width: 120,
                                height: 60,
                                child: null,
                              ),
                              Positioned(
                                right: 20,
                                left: 16,
                                top: 0,
                                bottom: 0,
                                child: Center(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          thumbnailVideoImagePopup(index);
                                          if (uploadedVideoFile.isNotEmpty) {
                                            //uploadedVideoPopUp();
                                          }
                                        },
                                        child: Image.asset(
                                          "assets/generateScript/corners_out.png",
                                          height: 25.0,
                                          width: 25.0,
                                        ),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          assestList.removeAt(index);
                                          setState(() {
                                            if (assestList.length > 0) {
                                              print("Enable btn");
                                            } else {
                                              isButtonEnable = false;
                                            }
                                          });
                                        },
                                        child: Image.asset(
                                          "assets/generateScript/cross_close.png",
                                          height: 25.0,
                                          width: 25.0,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                }).toList(),
              ),
            ),
          )
        : const SizedBox.shrink();
  }

  Padding gridSelectedThumbnail() {
    return PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        0.0,
        0.0,
        Container(
          width: MediaQuery.of(context).size.width,
          height: 96,
          child: PaddingWrap.paddingfromLTRB(
              15.0,
              0.0,
              15.0,
              0.0,
              Center(
                child: Container(
                    height: 60.0,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: List.generate(1, (int index) {
                        return Stack(
                          children: [
                            Container(
                              width: 123,
                              height: 57,
                              margin: EdgeInsets.only(right: 20),
                              child: Image.file(
                                File(thumbnailImagePath),
                                fit: BoxFit.cover,
                              ),
                            ),
                            Positioned(
                              top: 16,
                              left: 20,
                              child: InkWell(
                                onTap: () {
                                  if (uploadedVideoFile.isNotEmpty) {
                                    //uploadedVideoPopUp();
                                  }
                                },
                                child: Image.asset(
                                  "assets/generateScript/play_video_mini.png",
                                  height: 25.0,
                                  width: 25.0,
                                ),
                              ),
                            ),
                            Positioned(
                              top: 16,
                              right: 40,
                              child: InkWell(
                                onTap: () {
                                  thumbnailImagePath = "";
                                  setState(() {
                                    thumbnailImagePath;
                                  });
                                },
                                child: Image.asset(
                                  "assets/generateScript/cross_close.png",
                                  height: 25.0,
                                  width: 25.0,
                                ),
                              ),
                            ),
                          ],
                        );
                      }).toList(),
                    )),
              )),
          decoration: BoxDecoration(
            color: AppConstants.colorStyle.tabBg,
            border:
                Border.all(color: AppConstants.colorStyle.borderGenerateScript),
            borderRadius: const BorderRadius.all(Radius.circular(10)),
          ),
        ));
  }

  thumbnailVideoImagePopup(int index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: false,
        builder: (BuildContext bc) {
          return StatefulBuilder(builder: (context, state) {
            return Scaffold(
                backgroundColor: ColorValues.WHITE,
                body: Container(
                  constraints: BoxConstraints(
                    minHeight: 500, //minimum height
                    minWidth: 300, // minimum width

                    maxHeight: 500,
                    //maximum height set to 100% of vertical height

                    maxWidth: MediaQuery.of(context).size.width,
                    //maximum width set to 100% of width
                  ),
                  child: Stack(
                    children: [
                      Container(
                        height: 500,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(
                                    "assets/generateScript/script_background.png"),
                                fit: BoxFit.fill)),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 10, left: 20, right: 20, bottom: 10),
                        child: SizedBox(
                          height: 35,
                          width: double.infinity,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pop(context, 'pop');
                                },
                                child: Image.asset(
                                  "assets/generateScript/cross_close.png",
                                  height: 32.0,
                                  width: 32.0,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          margin: const EdgeInsets.only(top: 55),
                          child: Container(
                              width: MediaQuery.of(context).size.width,
                              height: 300,
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(30),
                                  topRight: Radius.circular(30),
                                ),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 0.0),
                                child: Padding(
                                  padding: const EdgeInsets.only(right: 0.0),
                                  child: Stack(
                                    children: <Widget>[
                                      assestList[index].type == 'image'
                                          ? Center(
                                              child: Image.file(
                                                  File(assestList[index]
                                                      .imagePath),
                                                  fit: BoxFit.contain,
                                                  height: 280.0,
                                                  width: MediaQuery.of(context)
                                                      .size
                                                      .width))
                                          : Center(
                                              child: Container(
                                              color: Colors.black,
                                              child: Center(
                                                child: VideoPlayPauseOffline(
                                                    assestList[index].file,
                                                    "",
                                                    true,
                                                    pageName: "AddPost"),
                                              ),
                                            )),
                                    ],
                                  ),
                                ),
                              )),
                        ),
                      )
                    ],
                  ),
                ));
          });
        }).then((value) => _closeModal(value));
  }
}
