import 'package:flutter/cupertino.dart';

class AgeBetween {
  int fromAge;
  int toAge;
  bool isShowAge = false;

  TextEditingController ageYearFrom = new TextEditingController();

  AgeBetween({this.toAge, this.fromAge});

  static Map<String, dynamic> toMap(AgeBetween ageBetween) {
    Map<String, dynamic> assetMap = Map();
    assetMap['from'] = ageBetween.fromAge;
    assetMap['to'] = ageBetween.toAge;

    return assetMap;
  }

  static List<Map<String, dynamic>> mapList(List<AgeBetween> agegroup) {
    List<Map<String, dynamic>> listOfOffer = agegroup
        .map((offer) => {
              "from": offer.fromAge,
              "to": offer.toAge,
            })
        .toList();
    return listOfOffer;
  }

  AgeBetween.fromJson(Map<String, dynamic> json) {
    toAge = json['to'];
    fromAge = json['from'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['to'] = this.toAge;
    data['from'] = this.fromAge;
    return data;
  }

  Map<String, dynamic> toJson2() => {
        'to': toAge,
        'from': fromAge,
      };
}
