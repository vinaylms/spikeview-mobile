import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geocoder/geocoder.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/CustomFormFieldWithPrefix.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart' as studentModel;
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfile.dart';
import 'package:spike_view_project/parentProfile/wizard/CongratulationMobileParent.dart';
import 'package:spike_view_project/parentProfile/wizard/newpages/AddEducationWidgetParentChild.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

// Create a Form Widget
class AddStudent extends StatefulWidget {
  String title;
  ProfileInfoModal profileInfoModal;
  String page;

  AddStudent(this.title, this.profileInfoModal, this.page);

  @override
  AddStudentState createState() {
    return AddStudentState();
  }
}

final homeScaffoldKey = GlobalKey<ScaffoldState>();

class AddStudentState extends State<AddStudent> {
  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: Constant.kGoogleApiKey);
  SharedPreferences prefs;
  String userIdPref, token;
  final _formKey = GlobalKey<FormState>();
  bool allFieldCompleted = false;
  String strPrefixPathOrganization = '', sasToken = '', containerName = '';
  TextEditingController fromDateController;
  String selectedCountryCode = '1';
  String strFirstName = "",
      strLastName = "",
      strEmail = "",
      strAdd = "",
      strMobile;
  File profileImageFile;
  static const platform = const MethodChannel('samples.flutter.io/battery');

  String profileImagePath = "";
  String isParentGender, emailId;
  String strParentZip = "";
  TextEditingController firstNameController = TextEditingController(),
      lastNameController = TextEditingController(),
      emailController = TextEditingController(),
      mobileController = TextEditingController();
  String _email = "";
  TextEditingController parentZipController = TextEditingController(text: "");
  FocusNode zipcodeFocusNode = FocusNode();
  DateTime startDate;
  bool isGenderSelected = true;
  FocusNode mobileFocusNode = FocusNode();
  final add1Controller = TextEditingController();
  Map addressData = {};

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    emailId = prefs.getString(UserPreference.EMAIL);
    token = prefs.getString(UserPreference.USER_TOKEN);
    if (widget.profileInfoModal.dob != null &&
        widget.profileInfoModal.dob != "null") {
      startDate = DateTime.fromMillisecondsSinceEpoch(
          int.parse(widget.profileInfoModal.dob));
    }
    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_PROFILE +
        "/";
    _callApiForSaas();
  }

  Future<void> _callApiForSaas() async {
    try {
      final response = await ApiCalling().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  String strCountryName = "";
  bool isStudentCountrySelected = true;
  CountryList _mCountryItem;
  CountryListModel _mCountryListModel;
  List<CountryList> countryList = List();
  final searchCountryController = TextEditingController();
  List<Item> countries = List();
  Item selectedCityItem;
  bool isShowStudentCitySelectionError = true;
  bool showList = false;

  DateTime pickedDate;
  int strDateOfBirth = 0;
  int diffrenceInDob = 14;
  TextEditingController dobController;
  bool isValid = true;
  String isMostCloselyIdentified = "";
  String dob, strDate;

  onTapNavigate(userIdNew, profilePicture) async {
    ParentProfilePageState.isEducationAdded = "false";
    ParentProfilePageState.isAchivmentAdded = "false";
    prefs.setString(UserPreference.PARENT_WIZARD_USERID, userIdNew);

    StudentDataModel model = studentModel.StudentDataModel(
        userIdNew,
        strFirstName,
        strLastName,
        strEmail.toLowerCase(),
        "",
        profilePicture,
        "1",
        "false",
        "",
        "",
        "",
        "",
        "",
        "",
        strDateOfBirth.toString(),
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        null,
        null,
        "false",
        "false",
        "false",
        null,
        "false",
        "0",
        true,
        false,
        '',
        0,
        '');
    DateTime date = DateTime.fromMillisecondsSinceEpoch(
        int.tryParse(strDateOfBirth.toString()));
    int endYar = DateTime.now().year + 10;
    await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => AddEducationWidgetParentChild(
              studModel: model,
              startYear: date.year,
              endYear: endYar,
              userId: userIdNew,
            )));

/*    await Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) => CongratulationMobileParent(
            studentModel.StudentDataModel(
                userIdNew,
                strFirstName,
                strLastName,
                strEmail.toLowerCase(),
                "",
                profilePicture,
                "1",
                "false",
                "",
                "",
                "",
                "",
                "",
                "",
                strDateOfBirth.toString(),
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                null,
                null,
                "false",
                "false",
                "false",
                null,
                "false",
                "0",
                true,
                false,
                '',
                0,
                ''))));*/
    //Navigator.pop(context, "push");
  }

  //--------------------------Api Calling ------------------

  Future<String> uploadImgOnAzure(imagePath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          profileImagePath = "";
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + strPrefixPathOrganization
          });

          profileImagePath = strPrefixPathOrganization + result;
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      CustomProgressLoader.cancelLoader(context);
      return "";
    }
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Timer(const Duration(milliseconds: 600), () async {
          if (profileImageFile != null) {
            await uploadImgOnAzure(profileImageFile
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim());
          }
        });
        Response response;

        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": 2,
          "profilePicture": profileImagePath == null ? '' : profileImagePath,
          "firstName": firstNameController.text.trim(),
          "lastName": lastNameController.text.trim(),
          "email": emailController.text.trim(),
          "gender": isMostCloselyIdentified == "Non-Binary"
              ? "NonBinary"
              : isMostCloselyIdentified,
          "genderAtBirth": isMostCloselyIdentified == "Non-Binary"
              ? "NonBinary"
              : isMostCloselyIdentified,
          "dob": strDateOfBirth,
          "city": addressData['city'] ?? "",
          "state": addressData['state'] ?? "",
          "country": addressData['country'] ?? "",
          "zipCode": addressData['zip'] ?? "",
          //  "address": add1Controller.text,
          "address": addressData,
          "signupType": "spikeview",
          "countryCode": "+$selectedCountryCode",
          "mobileNo": mobileController.text.trim(),
          "isUnderAge": false
        };

        log(" request :-" + map.toString());
        response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_STUDENT, map);
        CustomProgressLoader.cancelLoader(context);
        print("response shubh:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              String userIdNew =
                  response.data["result"]['studentId'].toString();
              String profilePicture =
                  response.data["result"]['profilePicture'].toString();
              apiCallingUpdate(userIdNew, profilePicture, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddStudent", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Widget _errorEmptyProfileView() {
    return Container(
      height: 115,
      width: 115,
      color: const Color(0xff666B9A),
      alignment: Alignment.center,
      child: Image.asset(
        'assets/default_avatar.png',
        height: 64,
        width: 64,
      ),
    );
  }

  Future<void> _chooseImage() async {
    var status = await Permission.photos.status;
    if (status.isGranted) {
      _getImage();
    } else {
      checkPermissionPhoto(context);
    }
  }

  Future<void> _getImage() async {
    final imagePath = await UploadMedia(context).pickImageFromGallery();
    if (imagePath != null) {
      String strPath = imagePath.toString().substring(
          imagePath.toString().lastIndexOf("/") + 1,
          imagePath.toString().length);
      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        if (imagePath != null) {
          profileImageFile = imagePath;
          setState(() {});
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  Future<void> checkPermissionPhoto(BuildContext context) async {
    showDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
        title: Text('Please allow access'),
        content: RichText(
          maxLines: 2,
          textAlign: TextAlign.center,
          text: TextSpan(
            text: '',
            style: TextStyle(
                color: ColorValues.HEADING_COLOR_EDUCATION,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            children: <TextSpan>[
              TextSpan(
                text: 'This app needs access to photos and camera roll',
                style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                  fontSize: 15.0,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          CupertinoDialogAction(
            child: Text('Deny'),
            onPressed: () => Navigator.of(context).pop(),
          ),
          CupertinoDialogAction(
              child: Text('Settings'),
              onPressed: () {
                Navigator.of(context).pop();
                openAppSettings();
              }),
        ],
      ),
    );
  }

  Future apiCallingUpdate(
      userIdNew, profilePicture, BuildContext mContext) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {"userId": userIdPref, "stage": "3"};
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            print("update data+++ apiCallingUpdate");
            if (status == "Success") {
              onTapNavigate(userIdNew, profilePicture);
            } else {}
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    dobController = TextEditingController(text: '');
    // genderList.add("Gender");

    getSharedPreferences();
    super.initState();
  }

  void _checkValidation() async {
    final form = _formKey.currentState;
    form.save();
    if (strDateOfBirth == 0) {
      setState(() {
        isValid = false;
      });
    } else {
      setState(() {
        isValid = true;
      });
    }
    if (isParentGender == "") {
      setState(() {
        isGenderSelected = false;
      });
    } else {
      setState(() {
        isGenderSelected = true;
      });
    }

    if (_mCountryItem == null) {
      setState(() {
        isStudentCountrySelected = false;
      });
    } else {
      setState(() {
        isStudentCountrySelected = true;
      });
    }

    if (_mCountryItem != null &&
        (!_mCountryItem.isZipcode) &&
        selectedCityItem == null) {
      isShowStudentCitySelectionError = false;
    } else {
      isShowStudentCitySelectionError = true;
    }

    if (form.validate()) {
      if (strDateOfBirth == 0) {
        setState(() {
          isValid = false;
        });
      }
      if (isParentGender == null || isParentGender == "") {
        /* setState(() {
            isGenderSelected = false;
          });*/
        ToastWrap.showToast(MessageConstant.SELECT_GENDER_VAL, context);
      } else if (!isStudentCountrySelected) {
        setState(() {
          isGenderSelected = false;
        });
      } else if (!isShowStudentCitySelectionError) {
      } else {
        try {
          setState(() {
            isValid = true;
          });

          if (emailId.toLowerCase().trim() != strEmail.toLowerCase().trim())
            apiCalling();
          else
            ToastWrap.showToast(MessageConstant.EMAIL_VALIDATION, context);
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "AddStudent", context);
          CustomProgressLoader.cancelLoader(context);
        }
      }
    } else {
      print("Failure 00");
    }
  }

  checkAllFieldSubmitter() {
    if (ValidationWidget.isName(firstNameController.text) &&
        ValidationWidget.isName(lastNameController.text) &&
        add1Controller.text.length > 0 &&
        dobController.text.length > 0 &&
        isMostCloselyIdentified.length > 0) {
      print('++++++true');
      if (mobileController.text.length == 0) {
        allFieldCompleted = true;
        setState(() {});
      } else if (mobileController.text.length > 0 &&
          ValidationChecks.validatePhone(mobileController.text).toString() ==
              'null') {
        allFieldCompleted = true;
        setState(() {});
      } else {
        print('++++++22false');
        allFieldCompleted = false;
        setState(() {});
      }
    } else {
      allFieldCompleted = false;
      setState(() {});
    }

    print("+++++++1" + firstNameController.text.toString());
    print("+++++++2" + lastNameController.text.toString());
    print("+++++++3" + add1Controller.text.toString());
    print("+++++++4" + dobController.text.toString());
    print("+++++++5" + isMostCloselyIdentified.toString());
    print("+++++++7" + mobileController.text.toString());
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(new FocusNode());
      },
      child: Scaffold(
        backgroundColor: ColorValues.SCREEN_BG_COLOR,
        key: homeScaffoldKey,
        bottomNavigationBar: Container(
          height: 90,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          decoration: BoxDecoration(
            color: AppConstants.colorStyle.white,
            boxShadow: [
              BoxShadow(
                color: const Color(0x75CCDCF7),
                blurRadius: 13,
                spreadRadius: 13,
              )
            ],
          ),
          child: Row(
            children: [
              Expanded(
                flex: 2,
                child: InkWell(
                  child: Container(
                    height: 45,
                    padding: EdgeInsets.symmetric(vertical: 11),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: ColorValues.WHITE,
                      border: Border.all(color: Color(0xffB2BDDB)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "Back",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: AppConstants.colorStyle.lightPurple,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  onTap: () async {
                    Navigator.pop(context, "push");
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 3,
                child: Stack(
                  children: [
                    /* allFieldCompleted
                        ? SizedBox(
                            height: 0,
                          )
                        :*/
                    InkWell(
                      child: Container(
                        height: 45,
                        padding: EdgeInsets.symmetric(vertical: 11),
                        decoration: BoxDecoration(
                          color: AppConstants.colorStyle.lightBlue,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'Proceed',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: ColorValues.WHITE,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontSize: 18,
                          ),
                        ),
                      ),
                      onTap: () {
                        if (_formKey?.currentState?.validate() ?? false) {
                          apiCalling();
                        }


                      },
                    ),
                    allFieldCompleted
                        ? SizedBox(
                      height: 0,
                    )
                        : Container(
                      height: 45.0,
                      width: double.infinity,
                      color: Colors.white.withOpacity(0.75),
                    )

                  ],
                ),
              ),
            ],
          ),
        ),
        body: FormKeyboardActions(
          nextFocus: false,
          keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
          keyboardBarColor: Colors.grey[200],
          actions: [
            KeyboardAction(
              focusNode: zipcodeFocusNode,
            ),
          ],
          child: Theme(
            data: ThemeData(hintColor: Colors.grey[300]),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 50, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      BaseText(
                        text: widget.title,
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        maxLines: 1,
                      ),
                      const HelpButtonWidget(),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    flex: 1,
                    child: Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            BaseText(
                              text: "Provide profile details",
                              textColor: const Color(0xff666B9A),
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                            const SizedBox(height: 24),
                            Center(
                              child: SizedBox(
                                width: 115,
                                height: 115,
                                child: InkWell(
                                  child: Stack(
                                    children: <Widget>[

                                      Container(
                                          width: 115,
                                          height: 115,
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(35),
                                              border: Border.all(
                                                  color: Colors.white,
                                                  width: 2),
                                              boxShadow: [
                                                BoxShadow(
                                                  spreadRadius: 3,
                                                  blurRadius: 3,
                                                  offset: Offset(0, 2),
                                                  color: Color.fromRGBO(98, 175, 226, 0.15),
                                                )
                                              ]
                                          ),
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(35.0),
                                            child:profileImageFile != null
                                                ? Image.file(
                                              profileImageFile,
                                              width: 115,
                                              height: 115,
                                              fit: BoxFit.cover,
                                            )
                                                : _errorEmptyProfileView(),
                                          )),




                                      Positioned(
                                        bottom: 12.0,
                                        right: 12.0,
                                        child: Image.asset(
                                          "assets/png/edit1.png",
                                          height: 24,
                                          width: 24,
                                        ),
                                      )
                                    ],
                                  ),
                                  onTap: () => _chooseImage(),
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),
                            CustomFormField(
                              alignLabelWithHint: true,
                              autovalidateMode: AutovalidateMode.disabled,
                              textInputType: TextInputType.text,
                              maxLength:
                                  TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
                              onType: (v) {
                                checkAllFieldSubmitter();
                              },
                              controller: firstNameController,
                              onSaved: (val) => strFirstName = val,
                              label: 'First name',
                              validation: (val) => val.trim().length == 0
                                  ? MessageConstant.ENTER_FIRST_NAME_VAL
                                  : !ValidationWidget.isName(val)
                                      ? MessageConstant
                                          .FIRST_NAME_CONTAINS_ALPHABET_VAL
                                      : null,
                            ),
                            const SizedBox(height: 24),
                            CustomFormField(
                              alignLabelWithHint: true,
                              autovalidateMode: AutovalidateMode.disabled,
                              textInputType: TextInputType.text,
                              maxLength:
                                  TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
                              onType: (v) {
                                checkAllFieldSubmitter();
                              },
                              controller: lastNameController,
                              label: 'Last name',
                              validation: (val) => val.trim().length == 0
                                  ? MessageConstant.ENTER_LAST_NAME_VAL
                                  : !ValidationWidget.isName(val)
                                      ? MessageConstant
                                          .LAST_NAME_CONTAINS_ALPHABET_VAL
                                      : null,
                              onSaved: (val) => strLastName = val,
                            ),
                            const SizedBox(height: 24),
                            CustomFormField(
                              // maxLength: 35,

                              onSaved: (val) => _email = val,
                              autovalidateMode: AutovalidateMode.disabled,
                              onType: (val) {
                                checkAllFieldSubmitter();
                              },
                              controller: emailController,
                              label: "Email",
                              validation: (val) => val.trim().length == 0
                                  ? MessageConstant.ENTER_EMAIL_VAL
                                  : !ValidationWidget.isEmail(val)
                                      ? MessageConstant.VALID_EMAIL_VAL
                                      : null,
                            ),
                            const SizedBox(height: 24),
                            CustomFormField(
                                alignLabelWithHint: true,
                                onSaved: (val) => strDate = val,
                                readOnly: true,
                                controller: dobController,
                                label: "Date of birth",
                                onClick: () async {
                                  DateTime pickedDate1 = await showDatePicker(
                                    context: context,
                                    initialDate: pickedDate == null
                                        ? DateTime.now()
                                        : pickedDate,
                                    firstDate: DateTime(1900),
                                    lastDate: DateTime.now(),
                                    confirmText: 'Apply',
                                    cancelText: 'Cancel',
                                  );
                                  if (pickedDate1 != null) {
                                    pickedDate = pickedDate1;
                                    strDateOfBirth =
                                        pickedDate1.millisecondsSinceEpoch;
                                    String date = Util.getDate(pickedDate1);
                                    setState(() {
                                      dobController =
                                          TextEditingController(text: date);
                                    });
                                  }

                                  checkAllFieldSubmitter();
                                  // selectDob(context);
                                },
                                validation: (value) {
                                  return value.length == 0
                                      ? MessageConstant.SELECT_DATE_TAKEN_VAL
                                      : null;
                                }),
                            const SizedBox(height: 24),
                            CustomFormField(
                                onSaved: (val) => strAdd = val,
                                readOnly: true,
                                alignLabelWithHint: true,
                                autovalidateMode: AutovalidateMode.disabled,
                                textInputType: TextInputType.text,
                                label: "Address",
                                controller: add1Controller,
                                onType: (v) {},
                                onClick: () {
                                  _handlePressButton();
                                },
                                validation: (value) {
                                  return value.length == 0
                                      ? 'Please enter valid address'
                                      : null;
                                }),
                            const SizedBox(height: 24),
                            CustomFormFieldWithPrefix(
                                // maxLength: 35,
                                autoValidateMode: AutovalidateMode.disabled,
                                prefixWidget: Padding(
                                  padding: const EdgeInsets.only(right: 5.0),
                                  child: Container(
                                    width: 57,
                                    child: CountryCodePicker(
                                      dense: false,
                                      showFlag: true,
                                      isNew: true,
                                      //displays flag, true by default
                                      showDialingCode: false,
                                      showUnderLine: false,
                                      //displays dialing code, false by default
                                      showName: false,
                                      //displays country name, true by default
                                      onChanged: (CountryCode country) {
                                        setState(() {
                                          selectedCountryCode =
                                              country.dialingCode;
                                        });
                                      },
                                      selectedCountryCode: selectedCountryCode,
                                    ),
                                  ),
                                ),
                                focusNode: mobileFocusNode,
                                baseAlign: true,
                                onSaved: (val) => strMobile = val,
                                textInputType: TextInputType.number,
                                maxLength: TextLength.MOBILE_NUMBER_MAX_LENGTH,
                                label: "Phone number",
                                onType: (v) {
                                  checkAllFieldSubmitter();
                                },
                                controller: mobileController,
                                suffixWidget: Padding(
                                  padding: const EdgeInsets.only(top: 20.0),
                                  child: BaseText(
                                    textAlign: TextAlign.center,
                                    text: 'Optional  ',
                                    textColor: AppConstants.colorStyle.darkBlue,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                    fontStyle: FontStyle.italic,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                  ),
                                ),
                                validation: (value) {
                                  return value.length > 0
                                      ? ValidationChecks.validatePhone(value)
                                      : null;
                                }),
                            /*      countryUi,
                                            isStudentCountrySelected
                                                ?  Container(
                                              height: 0.0,
                                            )
                                                : PaddingWrap
                                                .paddingfromLTRB(
                                                20.0,
                                                5.0,
                                                20.0,
                                                0.0,
                                                Text(
                                                  "Please select country",
                                                  style:  TextStyle(
                                                      color: Colors
                                                          .red[
                                                      600],
                                                      fontSize:
                                                      12.0),
                                                )),
                                            _mCountryItem == null
                                                ? parentZipUi
                                                : _mCountryItem
                                                .isZipcode
                                                ? parentZipUi
                                                : PaddingWrap
                                                .paddingfromLTRB(
                                              20.0,
                                              5.0,
                                              20.0,
                                              0.0,
                                              Container(
                                                  decoration:
                                                  BoxDecoration(
                                                      border:
                                                      Border(bottom: BorderSide(color: isShowStudentCitySelectionError ? Palette.dividerColor : Colors.red[600]))),
                                                  child: Column(
                                                    mainAxisSize:
                                                    MainAxisSize
                                                        .min,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: <
                                                        Widget>[
                                                      Row(
                                                        mainAxisSize:
                                                        MainAxisSize.max,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment.spaceBetween,
                                                        children: <
                                                            Widget>[
                                                          Expanded(
                                                            flex: 1,
                                                            child: selectCountryCityTextField(),
                                                          ),
                                                          searchCountryController.text.length>0?     IconButton(
                                                            onPressed: () {
                                                              showList =
                                                              !showList;
                                                              setState(() {});
                                                            },
                                                            icon: Padding(
                                                              padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left:
                                                                  15.0),
                                                              child: Icon(showList
                                                                  ? Icons
                                                                  .arrow_drop_up
                                                                  : Icons
                                                                  .arrow_drop_down),
                                                            ),
                                                          ):new Container(height:0.0),
                                                        ],
                                                      ),
                                                    ],
                                                  )),
                                            ),
                                            isShowStudentCitySelectionError
                                                ?  Container(
                                              height: 0.0,
                                            )
                                                : PaddingWrap
                                                .paddingfromLTRB(
                                                20.0,
                                                5.0,
                                                20.0,
                                                0.0,
                                                Text(
                                                  "Please select city",
                                                  style:  TextStyle(
                                                      color: Colors
                                                          .red[
                                                      600],
                                                      fontSize:
                                                      12.0),
                                                )),
                                            countryOrCityListWidget(),*/
                            const SizedBox(height: 30),
                            _genderView(),
                            const SizedBox(height: 24),
                            /*
                                            PaddingWrap.paddingfromLTRB(
                                                20.0,
                                                40.0,
                                                20.0,
                                                20.0,
                                                InkWell(
                                                  child: Container(
                                                    width: MediaQuery.of(context).size.width,
                                                    padding: const EdgeInsets.fromLTRB(34, 8, 34, 8),
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(10),
                                                      color: ColorValues.HEADING_COLOR_EDUCATION_2,
                                                    ),
                                                    child: BaseText(
                                                      text: 'Save',
                                                      textColor: ColorValues.WHITE,
                                                      fontFamily: AppConstants.stringConstant.latoMedium,
                                                      fontWeight: FontWeight.w600,
                                                      textAlign: TextAlign.center,
                                                      fontSize: 18,
                                                    ),
                                                  ),
                                                  onTap: (){
                                                    _checkValidation();
                                                  },
                                                )),*/
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _handlePressButton() async {
    Prediction p = await PlacesAutocomplete.show(
      context: context,
      apiKey: Constant.kGoogleApiKey,
      onError: onError,
      hint: "Search here..",
      logo: Image.asset("assets/logo"),
      mode: Mode.fullscreen,
      components: [
        Component(Component.country, "ind"),
        Component(Component.country, "uk"),
        Component(Component.country, "usa"),
      ],
    );
    displayPrediction(p);
  }

  void onError(PlacesAutocompleteResponse response) {
    ToastWrap.showToast(response.errorMessage, context);
  }

  Future<Null> displayPrediction(Prediction p) async {
    if (p != null) {
      PlacesDetailsResponse detail =
          await _places.getDetailsByPlaceId(p.placeId);
      final lat = detail.result.geometry.location.lat;
      final lng = detail.result.geometry.location.lng;
      try {
        final coordinates = Coordinates(lat, lng);
        var addresses =
            await Geocoder.local.findAddressesFromCoordinates(coordinates);
        var first = addresses.first;
        setState(() {
          add1Controller.text =
              first.addressLine != null && p.description != "null"
                  ? p.description
                  : "";
          addressData = {
            "street1": add1Controller.text.trim(),
            "address": add1Controller.text.trim(),
            "street2": first.subLocality != null && first.subLocality != "null"
                ? first.subLocality
                : "",
            "city": first.subAdminArea != null && first.subAdminArea != "null"
                ? first.subAdminArea
                : "",
            "state": first.adminArea != null && first.adminArea != "null"
                ? first.adminArea
                : "",
            "country": first.countryName != null && first.countryName != "null"
                ? first.countryName
                : "",
            "zip": first.postalCode != null && first.postalCode != "null"
                ? first.postalCode
                : ""
          };
        });
      } catch (e) {
        setState(() {
          add1Controller.text = p.description;
        });
      }

      checkAllFieldSubmitter();
    }
  }

  Widget _genderView() {
    return Row(
      children: <Widget>[
        Flexible(
          child: InkWell(
            onTap: () {
              isMostCloselyIdentified = "Male";
              FocusScope.of(context).requestFocus(new FocusNode());
              setState(() {});
              checkAllFieldSubmitter();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Male"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Male"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10.0),
                    bottomLeft: Radius.circular(10.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'Male',
                  textColor: isMostCloselyIdentified == "Male"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "Female";
              setState(() {});
              checkAllFieldSubmitter();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Female"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Female"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(0.0),
                    bottomLeft: Radius.circular(0.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'Female',
                  textColor: isMostCloselyIdentified == "Female"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "Non-Binary";
              setState(() {});
              checkAllFieldSubmitter();
            },
            child: Container(
              height: 35,
              width: 96,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Non-Binary"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Non-Binary"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(0.0),
                    bottomLeft: Radius.circular(0.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: ' Non-binary ',
                  textColor: isMostCloselyIdentified == "Non-Binary"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "NA";
              setState(() {});
              checkAllFieldSubmitter();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "NA"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "NA"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10.0),
                  topRight: Radius.circular(10.0),
                ),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'NA',
                  textColor: isMostCloselyIdentified == "NA"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 1,
        ),
      ],
    );
  }
}

Future<void> checkPermissionPhoto(BuildContext context) async {
  showDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
            title: Text('Please allow access'),
            content: RichText(
              maxLines: 2,
              textAlign: TextAlign.center,
              text: TextSpan(
                text: '',
                style: TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                children: <TextSpan>[
                  TextSpan(
                      text: 'This app needs access to photos and camera roll',
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          fontSize: 15.0,
                          fontWeight: FontWeight.normal)),
                ],
              ),
            ),
            actions: <Widget>[
              CupertinoDialogAction(
                child: Text('Deny'),
                onPressed: () => Navigator.of(context).pop(),
              ),
              CupertinoDialogAction(
                  child: Text('Settings'),
                  onPressed: () {
                    Navigator.of(context).pop();
                    openAppSettings();
                  }),
            ],
          ));
}
