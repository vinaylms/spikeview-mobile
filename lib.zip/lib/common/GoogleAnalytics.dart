
import 'dart:async';

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';


class GoogleAnalytics {
  static FirebaseAnalytics analytics = FirebaseAnalytics();
  static FirebaseAnalyticsObserver observer = FirebaseAnalyticsObserver(
     analytics: analytics);

  Future<void> setCurrentSreen(String screenName) async {
    await analytics.setCurrentScreen(
      screenName: 'spikeview',
      screenClassOverride: screenName,
    );
  }
}
final anaylytics = GoogleAnalytics();


//long beginTime = System.currentTimeMillis();

//your code to call the rest api

//long responseTime = System.currentTimeMillis() - beginTime;