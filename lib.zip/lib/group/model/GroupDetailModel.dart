import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';

class GroupDetailModel {
  String _id,
      groupId,
      groupName,
      type,
      creationDate,
      createdBy,
      isActive,
      aboutGroup,
      otherInfo,
      groupImage,adminRoleId,
      status;
  bool isAdmin = false;
  bool isOpportunityAdded = false;
  String adminName;

  List<MemberModelDetail> memberList;
  List<MemberModelDetail> requestedList;
  List<MemberModelDetail> invitedList;
  List<MemberModelDetail> allMembersList;

  GroupDetailModel(
      this._id,
      this.groupId,
      this.groupName,
      this.type,
      this.creationDate,
      this.createdBy,
      this.isActive,
      this.aboutGroup,
      this.otherInfo,
      this.groupImage,
      this.memberList,
      this.isAdmin,
      this.status,
      this.adminName,
      this.requestedList,
      this.invitedList,this.isOpportunityAdded,this.allMembersList,this.adminRoleId);
}

class MemberModelDetail {
  String status,
      isAdmin,schoolCode,
      userId,
      roleId,
      firstName,
      lastName,
      profilePicture,
      email,
      tagline,
      connectionStatus,
      title,isActive;
  bool isSelected = false;
  String badge;
  String badgeImage;
  int gamificationPoints;

  MemberModelDetail(
      this.status,
      this.isAdmin,
      this.userId,
      this.roleId,
      this.firstName,
      this.lastName,
      this.profilePicture,
      this.email,
      this.tagline,
      this.isSelected,
      this.connectionStatus,
      this.title,this.isActive,this.badge,this.gamificationPoints,this.badgeImage,this.schoolCode);
}
