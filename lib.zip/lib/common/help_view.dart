import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/video_player/video_play_view.dart';
import 'package:url_launcher/url_launcher.dart';
import 'CommonFullViewWidget.dart';
import 'Util.dart';

class HelpView extends StatefulWidget {
  const HelpView({
    Key key,
  }) : super(key: key);

  @override
  State<HelpView> createState() => _HelpViewState();
}

class _HelpViewState extends State<HelpView> {
  TextEditingController _searchQuery = TextEditingController();

  // video
  // final bool isVideoPlaying = false;
  // final VoidCallback onAddEditVideoTap;
  // final VoidCallback onPlayTap;
  // final String videoUrl = '';
  // final String videoThumbnailUrl = '';
  // final String imgUrl = 'abc';
  // bool isVideoPlay = false;

  final List<HelpItemModel> dataList = [
    HelpItemModel.fromMap(
      {
        'headerIconUrl': "assets/new_onboarding/person.png",
        'headerTitle': 'How to add profile image',
        'descriptionTop':
            "Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the, when an unknown printer took a galley",
        'imgTitle': 'Profile image add tutorial',
        'imageUrlList': [
          'https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_1280.jpg',
          'https://pimylifeup.com/wp-content/uploads/2022/06/Ubuntu-Taking-a-Screenshot-Thumbnail.jpg',
        ],
        'descBottom':
            'Long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      },
    ),
    HelpItemModel.fromMap(
      {
        'headerIconUrl': "assets/new_onboarding/person.png",
        'headerTitle': 'How to add name',
        'descriptionTop':
            "Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the, when an unknown printer took a galley",
        'tutorialTitle': 'Add name tutorial',
        'videoUrl': [
          'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
          'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'
        ],
        'descBottom':
            'Long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      },
    ),
    HelpItemModel.fromMap(
      {
        'headerIconUrl': "assets/new_onboarding/person.png",
        'headerTitle': 'Add name tutorial',
        'descriptionTop':
            "Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the, when an unknown printer took a galley",
        'tutorialTitle': 'Add spike chart tutorial',
        'imgTitle': 'Interests & Future Goals images',
        'imageUrlList': [
          'https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_1280.jpg',
          'https://pimylifeup.com/wp-content/uploads/2022/06/Ubuntu-Taking-a-Screenshot-Thumbnail.jpg',
        ],
        'videoUrl': [
          'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
          'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'
        ],
        'descBottom':
            'Long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      },
    )
  ];

// 1. app bar
  Widget appbarCustom() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            BaseText(
              text: AppConstants.stringConstant.HELP_HEDING,
              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
              fontFamily: AppConstants.stringConstant.latoMedium,
              fontWeight: FontWeight.w700,
              fontSize: 28,
              maxLines: 1,
            ),
            InkWell(
              child: SizedBox(
                height: 32.0,
                width: 32.0,
                child: Center(
                    child: Image.asset("assets/new_onboarding/cancel_icon.png",
                        height: 32.0, width: 32.0, fit: BoxFit.fitHeight)),
              ),
              onTap: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        ),
        const SizedBox(height: 5),
        Align(
          alignment: Alignment.topLeft,
          child: BaseText(
            textAlign: TextAlign.start,
            text: AppConstants.stringConstant.help_subtitle,
            textColor: AppConstants.colorStyle.lightPurple,
            fontFamily: AppConstants.stringConstant.latoMedium,
            fontWeight: FontWeight.w400,
            fontSize: 16,
            maxLines: 1,
          ),
        ),
      ],
    );
  }

//  2. search box
  Widget searchBoxCustom() {
    return Container(
        height: 40,
        margin: EdgeInsets.symmetric(vertical: 24.0),
        child: TextField(
          controller: _searchQuery,
          autocorrect: false,
          autofocus: false,
          keyboardType: TextInputType.text,
          onChanged: (s) {
            // if (s.trim().isNotEmpty) {
            //   if (_timer?.isActive ?? false) {
            //     _timer?.cancel();
            //   }
            //   _timer =
            //       Timer(Duration(milliseconds: 1000), () {
            //     friendList.clear();
            //     skip = 0;
            //     setState(() {});
            //     apiCallingForTagSearch(_searchQuery.text.trim());
            //   });
            // } else {
            //   dismissSearch();
            // }
          },
          style: TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
          decoration: InputDecoration(
            focusedBorder: OutlineInputBorder(
                //<-- SEE HERE
                borderSide: BorderSide(width: 1, color: Color(0xffE5EBF0)),
                borderRadius: BorderRadius.circular(10.0)),
            border: OutlineInputBorder(
                //<-- SEE HERE
                borderSide: BorderSide(width: 1, color: Color(0xffE5EBF0)),
                borderRadius: BorderRadius.circular(10.0)),
            disabledBorder: OutlineInputBorder(
                //<-- SEE HERE
                borderSide: BorderSide(width: 1, color: Color(0xffE5EBF0)),
                borderRadius: BorderRadius.circular(10.0)),
            enabledBorder: OutlineInputBorder(
                //<-- SEE HERE
                borderSide: BorderSide(width: 1, color: Color(0xffE5EBF0)),
                borderRadius: BorderRadius.circular(10.0)),
            fillColor: Color(0xffF3F5FF),
            filled: true,
            suffixIcon: _searchQuery.text.isNotEmpty
                ? IconButton(
                    color: Colors.black,
                    icon: Icon(
                      Icons.clear,
                      size: 25.0,
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                    ),
                    onPressed: () {
                      // dismissSearch();
                    })
                : IconButton(
                    onPressed: () {},
                    icon: Image.asset(
                      "assets/newDesignIcon/connections/new_search.png",
                      height: 20,
                      width: 20,
                    ),
                  ),
            contentPadding:
                const EdgeInsets.only(left: 13, right: 13, top: 10, bottom: 10),
            errorStyle: Util.errorTextStyle,
            hintText: 'Search in your connections',
            hintStyle: TextStyle(
                fontFamily: Constant.latoRegular,
                fontSize: 14,
                color: Color(0xff666B9A)),
            labelStyle: TextStyle(
                fontSize: 16.0,
                color: ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
          ),
        ));
  }

// 3. Details description widget
  Widget itemDetailsWidget(HelpItemModel item) {
    return Container(
      margin: EdgeInsets.only(bottom: 15.0),
      decoration: BoxDecoration(
          color: Color(0xffF5F6FA), borderRadius: BorderRadius.circular(10.0)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // heading
          Container(
            padding: EdgeInsets.all(8.0),
            decoration: BoxDecoration(
                color: Color(0xffE8ECFF),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 35.0,
                  width: 35.0,
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.5),
                      color: Colors.white),
                  child: Center(
                      child: Image.asset(
                    item.headerIconUrl,
                  )),
                ),
                SizedBox(width: 10.0),
                BaseText(
                  text: item.headerTitle,
                  textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 18,
                  maxLines: 1,
                ),
              ],
            ),
          ),
          SizedBox(height: 12.0),

          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // description
                item.descriptionTop == ''
                    ? Container()
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          BaseText(
                            text: 'Description',
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            maxLines: 1,
                          ),
                          SizedBox(height: 10.0),
                          BaseText(
                            text: item.descriptionTop,
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w400,
                            fontSize: 12,
                            // maxLines: 1,
                          ),
                        ],
                      ),

                // image

                item.imageUrlList.isEmpty
                    ? Container()
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          item.imgTitle == ''
                              ? Container()
                              : Padding(
                                  padding: const EdgeInsets.only(top: 12),
                                  child: BaseText(
                                    text: item.imgTitle,
                                    textColor:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    maxLines: 1,
                                  ),
                                ),
                          Container(
                              margin: EdgeInsets.only(top: 12.0),
                              clipBehavior: Clip.antiAlias,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              height: 184,
                              child: PageIndicatorContainer(
                                align: IndicatorAlign.bottom,
                                length: item.imageUrlList.length,
                                indicatorSpace: 10.0,
                                indicatorColor: item.imageUrlList.length == 1
                                    ? Colors.transparent
                                    : Color(0xffc4c4c4),
                                indicatorSelectorColor:
                                    item.imageUrlList.length == 1
                                        ? Colors.transparent
                                        : Color(0XFFFFFFFF),
                                shape: IndicatorShape.circle(size: 5.0),
                                pageView: PageView.builder(
                                  itemCount: item.imageUrlList.length,
                                  controller: PageController(),
                                  itemBuilder: (_, innerIndex) {
                                    return InkWell(
                                      child: Stack(
                                        children: <Widget>[
                                          Container(
                                              decoration: BoxDecoration(
                                                color: Colors.black,
                                              ),
                                              child: CachedNetworkImage(
                                                width: double.infinity,
                                                height: 184,
                                                // imageUrl:
                                                // Constant.IMAGE_PATH + '',
                                                imageUrl: item
                                                    .imageUrlList[innerIndex],
                                                fit: BoxFit.fill,
                                                placeholder: (context, url) =>
                                                    Util.loader(context,
                                                        "assets/aerial/default_img.png"),
                                                errorWidget: (context, url,
                                                        error) =>
                                                    Util.error(
                                                        "assets/aerial/default_img.png"),
                                              )),
                                        ],
                                      ),
                                      onTap: () {
                                        Navigator.of(context).push(
                                          MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                CommonFullViewWidget(
                                              item.imageUrlList,
                                              MessageConstant
                                                  .ACCOMPLISHMENT_HEDING,
                                              innerIndex,
                                              'Full View',
                                            ),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  onPageChanged: (index) {},
                                ),
                              )),
                        ],
                      ),
                // video

                item.videoUrlList.isEmpty
                    ? Container()
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          item.tutorialTitle == ''
                              ? Container()
                              : Padding(
                                  padding: const EdgeInsets.only(top: 12.0),
                                  child: BaseText(
                                    text: item.tutorialTitle,
                                    textColor:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    maxLines: 1,
                                  ),
                                ),
                          Container(
                              margin: EdgeInsets.only(top: 12.0),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              clipBehavior: Clip.antiAlias,
                              width: double.maxFinite,
                              height: 200,
                              child: PageIndicatorContainer(
                                align: IndicatorAlign.bottom,
                                length: item.videoUrlList.length,
                                indicatorSpace: 10.0,
                                indicatorColor: item.videoUrlList.length == 1
                                    ? Colors.transparent
                                    : Color(0xffc4c4c4),
                                indicatorSelectorColor:
                                    item.videoUrlList.length == 1
                                        ? Colors.transparent
                                        : Color(0XFFFFFFFF),
                                shape: IndicatorShape.circle(size: 5.0),
                                pageView: PageView.builder(
                                    itemCount: item.videoUrlList.length,
                                    controller: PageController(),
                                    itemBuilder: (_, innerIndex) {
                                      return VideoPlayerView(
                                        videoPath:
                                            'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                                        // videoPath:
                                        //     item.videoUrlList[innerIndex],
                                        // Constant
                                        //     .PATH_FOR_VIDEO +
                                        //     userPostModal
                                        //         ?.opportunityModelForFeed
                                        //         ?.assestVideoAndImage[
                                        //     index2]
                                        //         ?.file
                                        //         ?.replaceAll(
                                        //         Constant
                                        //             .PATH_FOR_VIDEO,
                                        //         '') ??
                                        //     '',
                                        videoType: VideoType.network,
                                      );
                                      // return item.videoUrlList[innerIndex]
                                      //             ?.isNotEmpty ??
                                      //         false
                                      //     ? isVideoPlaying ?? false
                                      //         ? VideoPlayPause(
                                      //             item.videoUrlList[innerIndex],
                                      //             "",
                                      //             true,
                                      //             pageName: "profile",
                                      //           )
                                      //         : Container(
                                      //             color: Colors.black,
                                      //             child: Stack(
                                      //               children: [
                                      //                 videoThumbnailUrl
                                      //                             ?.isNotEmpty ??
                                      //                         false
                                      //                     ? CachedNetworkImage(
                                      //                         height: 200,
                                      //                         width: double
                                      //                             .infinity,
                                      //                         imageUrl: videoThumbnailUrl
                                      //                                     .toLowerCase()
                                      //                                     .contains(
                                      //                                         "http") ||
                                      //                                 videoThumbnailUrl
                                      //                                     .toLowerCase()
                                      //                                     .contains(
                                      //                                         "www.")
                                      //                             ? videoThumbnailUrl
                                      //                             : "${Constant.IMAGE_PATH}$videoThumbnailUrl",
                                      //                         fit: BoxFit
                                      //                             .contain,
                                      //                         placeholder: (context,
                                      //                                 url) =>
                                      //                             Util.loader(
                                      //                                 context,
                                      //                                 ""),
                                      //                         errorWidget: (context,
                                      //                                 url,
                                      //                                 error) =>
                                      //                             Util.error(
                                      //                                 ""),
                                      //                       )
                                      //                     : const SizedBox
                                      //                         .shrink(),
                                      //                 Center(
                                      //                   child: InkWell(
                                      //                     onTap: () {
                                      //                       // onPlayTap

                                      //                       final url = item
                                      //                           .videoUrlList[
                                      //                               innerIndex]
                                      //                           .toLowerCase();
                                      //                       if (url.contains(
                                      //                               "http") ||
                                      //                           url.contains(
                                      //                               "www.")) {
                                      //                         if (!url.contains(
                                      //                             'http')) {
                                      //                           String url = "http://" +
                                      //                               item.videoUrlList[
                                      //                                   innerIndex];
                                      //                           launch(url);
                                      //                         } else {
                                      //                           launch(item
                                      //                                   .videoUrlList[
                                      //                               innerIndex]);
                                      //                         }
                                      //                       } else {
                                      //                         setState(() {
                                      //                           isVideoPlay =
                                      //                               true;
                                      //                         });
                                      //                       }
                                      //                     },
                                      //                     child: Image.asset(
                                      //                       'assets/ic_intro_play.png',
                                      //                       height: 40,
                                      //                       width: 40,
                                      //                     ),
                                      //                   ),
                                      //                 )
                                      //               ],
                                      //             ),
                                      //           )
                                      //     : Stack(
                                      //         children: [
                                      //           Image.asset(
                                      //             'assets/intro_default_img.png',
                                      //             width: double.maxFinite,
                                      //             height: 230,
                                      //             fit: BoxFit.fill,
                                      //           ),
                                      //           Center(
                                      //             child: Column(
                                      //               mainAxisSize:
                                      //                   MainAxisSize.min,
                                      //               children: [
                                      //                 BaseText(
                                      //                   text: AppConstants
                                      //                       .stringConstant
                                      //                       .addYourIntroductionVideo,
                                      //                   textColor: const Color(
                                      //                       0xff27275A),
                                      //                   fontSize: 16,
                                      //                   fontWeight:
                                      //                       FontWeight.w700,
                                      //                   fontFamily: Constant
                                      //                       .latoRegular,
                                      //                 ),
                                      //                 const SizedBox(
                                      //                     height: 12),
                                      //                 InkWell(
                                      //                   onTap: () {
                                      //                     // onAddEditVideoTap
                                      //                   },
                                      //                   child: Container(
                                      //                     decoration:
                                      //                         BoxDecoration(
                                      //                       color: AppConstants
                                      //                           .colorStyle
                                      //                           .lightBlueAddVideo,
                                      //                       borderRadius:
                                      //                           BorderRadius
                                      //                               .all(
                                      //                         Radius.circular(
                                      //                             8),
                                      //                       ),
                                      //                     ),
                                      //                     padding:
                                      //                         const EdgeInsets
                                      //                                 .fromLTRB(
                                      //                             10, 5, 10, 5),
                                      //                     child: BaseText(
                                      //                       text: "Add Video",
                                      //                       textColor:
                                      //                           Colors.white,
                                      //                       fontSize: 12,
                                      //                       fontWeight:
                                      //                           FontWeight.w700,
                                      //                       fontFamily:
                                      //                           'NunitoRegular',
                                      //                     ),
                                      //                   ),
                                      //                 )
                                      //               ],
                                      //             ),
                                      //           )
                                      //         ],
                                      //       );
                                    }),
                              )),
                        ],
                      ), // desc

                // bottom desc

                item.descBottom == ''
                    ? Container()
                    : Padding(
                        padding: const EdgeInsets.only(top: 12.0),
                        child: BaseText(
                          text: item.descBottom,
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                          // maxLines: 1,
                        ),
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pop(context, "push");
        return Future.value(false);
      },
      child: Scaffold(
        backgroundColor: ColorValues.WHITE,
        body: PaddingWrap.paddingfromLTRB(
            20.0,
            50.0,
            20.0,
            0.0,
            SingleChildScrollView(
              child: Container(
                child: Column(
                  children: [
                    // app bar
                    appbarCustom(),
                    // search box
                    searchBoxCustom(),
                    // Details description widget
                    MediaQuery.removePadding(
                      context: context,
                      removeTop: true,
                      child: ListView.builder(
                          itemCount: dataList.length,
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemBuilder: (context, i) {
                            return itemDetailsWidget(dataList[i]);
                          }),
                    )
                  ],
                ),
              ),
            )),
      ),
    );
  }
}

// model
class HelpItemModel {
  String _headerIconUrl = '';
  String _headerTitle = '';
  String _descriptionTop = '';
  String _imgTitle = '';
  String _tutorialTitle = '';
  List<String> _imgUrlList = [];
  List<String> _videoUrl = [];
  String _descBottom = '';

  HelpItemModel.fromMap(Map<String, dynamic> json) {
    _headerIconUrl = json['headerIconUrl'] ?? '';
    _headerTitle = json['headerTitle'] ?? '';
    _descriptionTop = json['descriptionTop'] ?? '';
    _imgTitle = json['imgTitle'];

    _tutorialTitle = json['tutorialTitle'] ?? '';
    if (json['imageUrlList'] != null) {
      for (var i = 0; i < json['imageUrlList'].length; i++) {
        _imgUrlList.add(json['imageUrlList'][i]);
      }
    }
    if (json['videoUrl'] != null) {
      for (var j = 0; j < json['videoUrl'].length; j++) {
        _videoUrl.add(json['videoUrl'][j]);
      }
    }

    _descBottom = json['descBottom'];
  }

  String get headerIconUrl => _headerIconUrl;

  String get headerTitle => _headerTitle;

  String get descriptionTop => _descriptionTop;

  String get tutorialTitle => _tutorialTitle;

  String get imgTitle => _imgTitle;

  List get imageUrlList => _imgUrlList;

  List<String> get videoUrlList => _videoUrl;

  String get descBottom => _descBottom;
}
