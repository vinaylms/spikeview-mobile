// Updated COde

import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/CustomFormFieldWithPrefix.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/image_utils.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/gateway/EmailVerification.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/gateway/ReferalCodeResponse.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class SignupStudentPageNew extends StatefulWidget {
  final LoginRole loginRole;
  static String tag = 'login-page';
  bool isRedirectToRecommendation, isValid, isEditable;
  String pageName,
      signupType,
      firstName = "",
      lastName = "",
      email = "",
      qrCode = "",
      qrType = "",
      image = "";

  SignupStudentPageNew(
    this.isRedirectToRecommendation,
    this.pageName,
    this.signupType, {
    @required this.loginRole,
    this.firstName,
    this.lastName,
    this.email,
    this.image,
    this.isValid,
    this.isEditable,
    this.qrCode,
    this.qrType,
  });

  @override
  SignupStudentPageState createState() =>
      SignupStudentPageState(firstName, lastName, email);
}

class SignupStudentPageState extends State<SignupStudentPageNew> {
  String sasToken = '';
  bool isFieldEditable = true;
  ProfileInfoModal profileInfoModal;

  String userId = '';

  SignupStudentPageState(this.strFirstName, this.strLastName, this.strEmail);

  Color borderColor = Colors.amber;
  bool isAgree = false;
  StreamSubscription<dynamic> _streamSubscription;
  final formKey = GlobalKey<FormState>();
  final formKeyReferal = GlobalKey<FormState>();
  String _email = "", _password = "", referralCode;

  String strFirstName = "",
      strLastName = "",
      strEmail = "",
      strZip = "",
      strParentZip = "",
      strParentEmail = "",
      strParentLastName = "",
      strParentFirstName = "",
      signinType = "spikeview";

  GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseAuth _fbAuth = FirebaseAuth.instance;
  bool _isLoading = false;

  bool isValid = true;
  bool isValidParent = true;
  static StreamController syncDoneController = StreamController.broadcast();

  TextEditingController emailController = TextEditingController(text: "");
  TextEditingController paswordController = TextEditingController(text: "");

  final FocusNode firstNameFocus = FocusNode();
  final FocusNode pfirstNameFocus = FocusNode();
  final FocusNode lastNameFocus = FocusNode();
  final FocusNode plastNameFocus = FocusNode();
  final FocusNode emailFocus = FocusNode();
  final FocusNode pemailFocus = FocusNode();
  final FocusNode passwordFocus = FocusNode();
  static const platform = const MethodChannel('samples.flutter.io/battery');
  bool _newPassObscureText = true;

  ShareProfileModal shareProfileModal;
  String strNewPassword = "";

  SharedPreferences prefs;
  String token = "", linkUrl, referalUserId = "", referalUserRoleId = "";

  FocusNode referalFocusNode = FocusNode();
  TextEditingController referalController = TextEditingController();
  bool isValidateReferal = false;
  ReferalCodeResponse referalCodeResponse;

  bool password_error_lenght = false;
  bool password_error_number = false;
  bool password_error_lower = false;
  bool password_error_upper = false;
  bool password_error_specile = false;
  bool allFieldCompleted = false;
  bool referalFieldCompleted = false;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    token = prefs.getString(UserPreference.USER_TOKEN);
    String roleId = prefs.getString(UserPreference.ROLE_ID);
    String name = prefs.getString(UserPreference.NAME);
    String email = prefs.getString(UserPreference.EMAIL);

    if (MediaQuery.of(context).size.height <= 750) {
      setRecommendationPadding();
    }
    if (email != null && email != "notdelete@gmail.com") {
      emailController = TextEditingController(text: email);

      setState(() {
        emailController;
      });
    }
  }

  linkPreferences() async {
    prefs = await SharedPreferences.getInstance();
    linkUrl = prefs.getString(UserPreference.PATHURL);

    if (linkUrl == null) {
      linkUrl = "";
    }
    // https://app.spikeview.com/studentSignup/shubh0001@yopmail.com/shubh/sharma
    print("linkurl+++" + prefs.getString(UserPreference.PATHURL));
    if (linkUrl == "" || linkUrl == " ") {
    } else {
      if (linkUrl.contains("referNow")) {
        // https://spikeview.com/referNow?userId=1830&roleId=1&email=sk1213@yopmail.com&pass=null
        List<String> mesagelist = linkUrl.split("=");

        referalUserId = mesagelist[1].replaceAll("&roleId", "");
        referalUserRoleId = mesagelist[2].replaceAll("&email", "");
        String email = mesagelist[3].replaceAll("&pass", "");

        print(
            "userId{$referalUserId} roleId {$referalUserRoleId}  emaail {$email}");

        userId = referalUserId;
        emailController = TextEditingController(text: email);
      } else if (linkUrl.contains("studentSignup")) {
        // https://app.spikeview.com/studentSignup/shubh0001@yopmail.com/shubh/sharma
        isFieldEditable = false;
        emailController = TextEditingController(text: widget.email);
      }

      setState(() {
        emailController;
      });
    }
  }

  @override
  void dispose() {
    super.dispose(); // always call super for dispose/initState
  }

  double padding0 = 10.0,
      padding1 = 30.0,
      padding2 = 25.0,
      padding3 = 15.0,
      padding4 = 25.0,
      padding5 = 30.0;
  bool isSetPadding = false;

  setRecommendationPadding() {
    padding0 = 5.0;
    padding1 = 20.0;
    padding2 = 20.0;
    padding3 = 10.0;
    padding4 = 20.0;
    padding5 = 9.0;
    setState(() {});
  }

  @override
  void initState() {
    try {
      if (widget.isEditable == null) {
        widget.isEditable = false;
      }
    } catch (e) {
      widget.isEditable = false;
    }
    print('rec+++++0');
    if (widget.isRedirectToRecommendation) {
      print('rec+++++1');
      isSetPadding = true;
      setRecommendationPadding();
      getSharedPreferences();
    } else {
      print('rec+++++2');
      linkPreferences();
    }

    if (widget.email != "") {
      emailController.text = widget.email;
    }
  }

  void _checkValidation() {
    print('onClick++1');
    final form = formKey.currentState;
    print("object.12345678.");
    form.save();

    if (form.validate()) {
      if (widget.isValid) {
        print('onClick++3');
        loginServiceCall();
      } else {
        ToastWrap.showToastLong(MessageConstant.PRIVATE_EMAIL_MSG, context);
      }
    }

    // } else {}
  }

  showSucessMsgLong(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");
      Navigator.of(context);

      if (widget.pageName == "Login") {
        Navigator.of(context).popUntil((route) => route.isFirst);
      } else {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => LoginPage(null)));
      }
    });

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => WillPopScope(
        onWillPop: () {},
        child: GestureDetector(
          onTap: () {},
          child: Scaffold(
            backgroundColor: Colors.transparent,
            body: Stack(
              children: <Widget>[
                Positioned(
                    right: 0.0,
                    top: 55.0,
                    left: 0.0,
                    child: Container(
                      height: 90.0,
                      padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                      color: Color(0xffF1EDC3),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            RichText(
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.start,
                              text: TextSpan(
                                text: msg,
                                style: TextStyle(
                                    color: Color(0xff408738),
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.normal,
                                    fontFamily: Constant.customRegular),
                              ),
                            )
                          ]),
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }

  goto() {
    print('inside goto SignUp');
    prefs.setString(UserPreference.PATHURL, "");
    Navigator.of(context).popUntil((route) => route.isFirst);

    Navigator.of(context).pushReplacement(
      new MaterialPageRoute(
        builder: (BuildContext context) => EmailVerification(
          profileInfoModal,
          sasToken,
          loginRole: widget.loginRole,
          isRedirectToRecommendation: widget.isRedirectToRecommendation,
          email: profileInfoModal?.email ?? '',
          firstName: widget.firstName,
          lastName: widget.lastName,
          pageName: widget.pageName,
        ),
      ),
    );

    /*  if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
      Navigator.of(context).pushReplacement(
          new MaterialPageRoute(builder: (BuildContext context) => MoreData()));
    } else {
      StudentOnBoarding().getStudentOnBoardingInit(
          context, profileInfoModal, sasToken, userId);
    }*/
  }

  onTapPresoView() async {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await Navigator.pushReplacement(
        Constant.applicationContext,
        MaterialPageRoute(
            builder: (context) => SharePresoView23(
                shareProfileModal.profileOwner, shareProfileModal, "main")));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  processForUri(result, email) async {
    print("resultData+++" + result);
    if (result.toString().toLowerCase().contains(email)) {
      if (result.contains("previewprofile")) {
        //Navigator.of(context).popUntil((route) => route.isFirst);//Apurva did changes for social signup

        goto();
      } else if (result.contains("joingroup")) {
        /*  if (studentAgeSelection == 1) {
          goto();
        } else {*/
        List<String> mesagelist = result.split("=");

        String groupId = mesagelist[2].replaceAll("&email", "");
        String email = mesagelist[3].replaceAll("&pass", "");
        String pass = mesagelist[4];
        prefs.setString(UserPreference.ROLE_ID, "1");
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    GroupDetailWidget(groupId, "signup", "", "", "")));
        // }
      } else if (result.contains("recommendation") ||
          result.contains("badges")) {
        /*  if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => MoreData()));
        } else {*/
        StudentOnBoarding().getStudentOnBoardingInit(
            context, profileInfoModal, sasToken, userId);
        //   }
      }
    } else {
      //Navigator.of(context).popUntil((route) => route.isFirst);//Apurva did changes for social signup
      goto();
    }
    prefs.setString(UserPreference.PATHURL, "");
  }

  signInWithGoogle(BuildContext context, String type) async {
    User user = FirebaseAuth.instance.currentUser;
    bool isSignedIn = await _googleSignIn.isSignedIn();
    if (isSignedIn) {
      _googleSignIn.signOut();
    } else {}
    _googleSignIn = GoogleSignIn();
    final GoogleSignInAccount googleSignInAccount =
        await _googleSignIn.signIn();
    if (googleSignInAccount != null) {
      try {
        final GoogleSignInAccount googleUser = await _googleSignIn.signIn();
        final GoogleSignInAuthentication googleAuth =
            await googleUser.authentication;
        final GoogleAuthCredential credential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );
        final UserCredential authResult =
            await _fbAuth.signInWithCredential(credential);
        final User user = authResult.user;
        assert(!user.isAnonymous);
        assert(await user.getIdToken() != null);
        final User currentUser = _fbAuth.currentUser;
        assert(currentUser.uid == user.uid);
        print("log______" + user.toString());
        try {
          emailController.text = user.email;
          widget.signupType = "google";
          if (type == "Signup") {
            String firstName = "";
            String lastName = "";
            if (user.displayName != null) {
              List<String> data = user.displayName.split(" ");
              firstName = data[0];
              lastName = data[1];
            }
            String image = user.photoURL;
            if (image == null || image == "null") {
              image = "";
            }

            loginServiceCall();
          } else {
            loginServiceCall();
          }
        } catch (e) {}
        //return user;

      } catch (e) {
        print("eroor+++++++e+" + e.toString());
        crashlytics_bloc.recordCrashlyticsError(e, "LoginPage", context);
        if (e.code == 'account-exists-with-different-credential') {
        } else if (e.code == 'invalid-credential') {}
      }
    }
  }

  loginServiceCall() async {
    print('inside loginServiceCall() widget.signupType:: ${widget.signupType}');
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);

        String encryptedstrNewPassword = "";

        encryptedstrNewPassword = await platform.invokeMethod('encryption', {
          "password": paswordController.text,
        });

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token};
        // Prepare Data

        Map map = {};
        switch (widget.loginRole) {
          case LoginRole.student:
            map = {
              "deviceId": prefs.getString("deviceId"),
              "email": emailController.text.toLowerCase(),
              "roleId": 1,
              "recommendationWebFlag": widget.isRedirectToRecommendation,
              "password": encryptedstrNewPassword,
              "referralUserId": referalUserId,
              "referralUserRoleId": referalUserRoleId,
              "referCode": referalController.text.toString().trim(),
              "signupType": widget.signupType,
              "type": widget.qrType == null ? '' : widget.qrType,
              "inviteBy": widget.qrCode == null ? '' : widget.qrCode,
              "socialId": "",
              "isAcceptedTermCon": true,
              "platformType": "mobile"
            };
            break;
          case LoginRole.parent:
            map = {
              "deviceId": prefs.getString("deviceId"),
              "email": emailController.text.trim().toLowerCase(),
              "roleId": 2,
              "recommendationWebFlag": widget.isRedirectToRecommendation,
              "password": encryptedstrNewPassword,
              "referralUserId": referalUserId,
              "referralUserRoleId": referalUserRoleId,
              "referCode": referalController.text.toString().trim(),
              "signupType": widget.signupType,
              "socialId": "",
              "platformType": "mobile",
              "isAcceptedTermCon": true,
            };
            break;
          case LoginRole.partner:
            map = {
              "email": emailController.text.trim().toLowerCase(),
              "password": encryptedstrNewPassword,
              "roleId": 4,
              "deviceId": prefs.getString("deviceId"),
              "recommendationWebFlag": widget.isRedirectToRecommendation,
              "referralUserId": referalUserId,
              "referralUserRoleId": referalUserRoleId,
              "referCode": referalController.text.toString().trim(),
              "signupType": widget.signupType,
              "type": widget.qrType == null ? '' : widget.qrType,
              "inviteBy": widget.qrCode == null ? '' : widget.qrCode,
              "socialId": "",
              "isAcceptedTermCon": true,
              "platformType": "mobile"
            };
            break;
        }

        log("dataMap" + map.toString());

        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_PARENT_SIGNUP,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];
          //userId = response.data[LoginResponseConstant.ID];
          if (status == "Success") {
            String path = prefs.getString(UserPreference.PATHURL);
            prefs.setString(UserPreference.chat_skip_count, "0");
            prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, false);
            prefs.setBool(UserPreference.isEducationAdded, false);
            userId = response.data['result']['userId'].toString();
            // Api call for get setting data
            bloc.fetchSetting(userId, context, prefs);
            if ((widget.signupType == "apple" ||
                    widget.signupType == "google" ||
                    widget.signupType == "spikeview") &&
                (!widget.isRedirectToRecommendation)) {
              // setState(() {
              Constant.isAlreadyLoggedIn = true;
              prefs.setBool(UserPreference.IS_ADDED_DOB, false);

              //note perform changes on userprofile page on the basis of dob selection
              prefs.setBool(
                  UserPreference.IS_UNDER_AGE,
                  /*studentAgeSelection == 1 ? true :*/ false);

              if (widget.loginRole == LoginRole.partner) {
                prefs.setString(UserPreference.IS_USER_ROLE, "false");
                prefs.setString(UserPreference.IS_PARENT_ROLE, "false");
                prefs.setString(UserPreference.IS_PARTNER_ROLE, "true");
              } else if (widget.loginRole == LoginRole.parent) {
                prefs.setString(UserPreference.IS_USER_ROLE, "false");
                prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
                prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");
              } else {
                prefs.setString(UserPreference.IS_USER_ROLE, "true");
                prefs.setString(UserPreference.IS_PARENT_ROLE, "false");
                prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");
              }
              var companyMap = response.data['result']['company'];
              Company company = Company('', '', false);
              if (companyMap != null) {
                company = Company(
                    companyMap['name'].toString(),
                    companyMap['partnerStatus'].toString(),
                    companyMap['isActive']);

                if (company.partnerStatus.toString() == 'Decline')
                  prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP, true);
                else
                  prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP, false);
              }
              userId = response.data['result']['userId'].toString();
              String firstName =
                  response.data['result']['firstName'].toString();
              String lastName = response.data['result']['lastName'].toString();
              String email = response.data['result']['email'].toString();
              String salt = response.data['result']['salt'].toString();
              String mobileNo = response.data['result']['mobileNo'].toString();
              String profilePicture =
                  response.data['result']['profilePicture'].toString();
              String roleId = response.data['result']['roleId'].toString();
              String dob = response.data['result']['dob'].toString();
              if (dob == null || dob == "null" || dob == "") {
                dob = "0";
              }
              String companyName =
                  response.data['result']['companyName'].toString();
              String companyProfilePicture =
                  response.data['result']['companyProfilePicture'].toString();
              bool ProfileCreatedByParent =
                  response.data['result']['profileCreatedByParent'];
              if (ProfileCreatedByParent == null) {
                ProfileCreatedByParent = false;
              }

              bool userLoginFirstTime =
                  response.data['result']['userLoginFirstTime'];
              if (userLoginFirstTime == null) {
                userLoginFirstTime = false;
              }
              String schoolCode =
                  response.data['result']['schoolCode'].toString();
              if (schoolCode == "null" || schoolCode == "") {
                schoolCode = "";
              }
              prefs.setBool(
                  UserPreference.SHOW_BOT_DEFAULT_COUNT, userLoginFirstTime);
              prefs.setBool(
                  UserPreference.IS_USER_LOGIN_FIRST_TIME, userLoginFirstTime);

              prefs.setString(UserPreference.DOB, dob);

              //  roleId = "1";
              String token = response.data['result']['token'].toString();
              bool isPasswordChanged =
                  response.data['result']['isPasswordChanged'];
              print('widget.signupType:: ${widget.signupType}');
              if (widget.signupType == "apple" ||
                  widget.signupType == "google") {
                isPasswordChanged = true;
              }
              userList.add(new UserData(userId, firstName, lastName, email,
                  salt, mobileNo, profilePicture, roleId));
              prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
              String isActive = response.data['result']['isActive'].toString();
              String isHide = response.data['result']['isHide'].toString();
              prefs.setString(UserPreference.ISHide, isHide);
              prefs.setString(UserPreference.ISACTIVE, isActive);
              prefs.setBool(UserPreference.LOGIN_STATUS, true);
              prefs.setString(UserPreference.ROLE_ID, roleId);

              Constant.ROLE_ID = roleId;
              prefs.setBool(
                  UserPreference.IS_PASSWORD_CHANGED, isPasswordChanged);
              prefs.setBool(UserPreference.IS_PROFILECRETED_BY_PARENT,
                  ProfileCreatedByParent);

              prefs.setString(UserPreference.USER_ID, userId);
              prefs.setBool(
                  UserPreference.IS_PARENT, roleId == "2" ? true : false);
              prefs.setString(UserPreference.PARENT_ID, userId);
              if (strFirstName == null ||
                  strFirstName == "null" ||
                  strFirstName == "") {
                prefs.setString(UserPreference.NAME, "");
              } else {
                prefs.setString(
                    UserPreference.NAME, firstName + " " + lastName);
              }
              prefs.setString(UserPreference.EMAIL, email);
              prefs.setString(UserPreference.MOBILE, mobileNo);
              prefs.setString(UserPreference.PASSWORD, "");

              prefs.setString(
                  UserPreference.PROFILE_IMAGE_PATH, profilePicture);
              prefs.setString(
                  UserPreference.COMPANY_IMAGE_PATH, companyProfilePicture);

              prefs.setString(UserPreference.COMPANY_NAME_PATH, companyName);

              prefs.setString(UserPreference.USER_TOKEN, "Spike " + token);
              String path = "";
              try {
                path = prefs.getString(UserPreference.PATHURL);
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "StudentSignup", context);
              }

              String requireParentApproval =
                  response.data['result']['requireParentApproval'].toString();
              String isPasswordChanged1 =
                  response.data['result']['isPasswordChanged'].toString();
              if (widget.signupType == "apple" ||
                  widget.signupType == "google") {
                isPasswordChanged1 = "true";
              }
              String ccToParents =
                  response.data['result']['ccToParents'].toString();
              String lastAccess =
                  response.data['result']['lastAccess'].toString();
              String organizationId =
                  response.data['result']['organizationId'].toString();
              String gender = response.data['result']['gender'].toString();
              String genderAtBirth =
                  response.data['result']['genderAtBirth'].toString();
              String usCitizenOrPR =
                  response.data['result']['usCitizenOrPR'].toString();
              String summary = response.data['result']['summary'].toString();
              String coverImage =
                  response.data['result']['coverImage'].toString();
              String tagline = response.data['result']['tagline'].toString();
              String title = response.data['result']['title'].toString();
              String tempPassword =
                  response.data['result']['tempPassword'].toString();
              String isArchived =
                  response.data['result']['isArchived'].toString();
              String groupId = response.data['result']['groupId'].toString();
              String groupName =
                  response.data['result']['groupName'].toString();
              String groupImage =
                  response.data['result']['groupImage'].toString();
              String zipCode = response.data['result']['zipCode'].toString();
              bool referralPopup = response.data['result']['referralPopup'];
              String stage = response.data['result']['stage'].toString();
              if (widget.signupType == "apple" ||
                  widget.signupType == "google") {
                stage = '1';
              }

              bool isExistingUser = response.data['result']['isExistingUser'];
              bool isCollegeAdded = response.data['result']['isCollegeAdded'];

              if (isExistingUser == null) {
                isExistingUser = false;
              }
              if (isCollegeAdded == null) {
                isCollegeAdded = false;
              }

              String creationTime = "0";
              creationTime = response.data['result']['creationTime'].toString();
              if (creationTime == "null") {
                creationTime = "0";
              }

              bool isPublicUrlActive =
                  response.data['result']['isPublicUrlActive'];
              if (isPublicUrlActive == "null") {
                isPublicUrlActive = false;
              }

              bool isPublicProfileGlobalyActive =
                  response.data['result']['isPublicProfileGlobalyActive'];
              if (isPublicProfileGlobalyActive == null ||
                  isPublicProfileGlobalyActive == "null") {
                isPublicProfileGlobalyActive = false;
              }

              String publicUrl =
                  response.data['result']['publicUrl'].toString().trim();
              if (publicUrl == "null") {
                publicUrl = "";
              }

              String referCode =
                  response.data['result']['referCode'].toString();

              bool isPreLoginSetting =
                  response.data["result"]["isLeaderboardDisplay"];
              if (isPreLoginSetting == null) {
                isPreLoginSetting = false;
              }
              prefs.setBool(UserPreference.IS_PRE_LOGIN, isPreLoginSetting);

              String badgeImage =
                  response.data['result']['badgeImage'].toString();
              if (badgeImage == null ||
                  badgeImage == "null" ||
                  badgeImage == "") {
                badgeImage = "";
              }
              String badge = response.data['result']['badge'].toString();
              if (badge == null || badge == "null" || badge == "") {
                badge = "";
              }
              String gamification =
                  response.data['result']['gamificationPoints'].toString();
              int gamificationPoints;
              if (gamification == null ||
                  gamification == "" ||
                  gamification == "null") {
                gamificationPoints = 0;
              } else {
                gamificationPoints = int.parse(gamification);
              }

              prefs.setString(UserPreference.referCode, referCode);
              prefs.setString(UserPreference.badgeType, badge);
              prefs.setInt(
                  UserPreference.gamificationPoints, gamificationPoints);
              prefs.setString(UserPreference.badgeImage, badgeImage);

              if (referralPopup == null || referralPopup == "null") {
                referralPopup = false;
              }

              List<SocialLinkData> socialLinkList = List();
              var socalLinkMap = response.data['result']['socialLinks'];
              if (socalLinkMap != null && socalLinkMap.length > 0) {
                for (int i = 0; i < socalLinkMap.length; i++) {
                  String image = socalLinkMap[i]['image'].toString();
                  String socialName = socalLinkMap[i]['socialName'].toString();
                  String socialUrl = socalLinkMap[i]['socialUrl'].toString();
                  int socialId = socalLinkMap[i]['socialId'];

                  socialLinkList.add(new SocialLinkData(
                      image: image,
                      socialName: socialName,
                      socialUrl: socialUrl,
                      socialId: socialId));
                }
              }

              profileInfoModal = ProfileInfoModal(
                  userId,
                  firstName,
                  lastName,
                  email,
                  mobileNo,
                  profilePicture,
                  roleId,
                  isActive,
                  requireParentApproval,
                  ccToParents,
                  lastAccess,
                  isPasswordChanged1,
                  organizationId,
                  gender,
                  dob,
                  genderAtBirth,
                  usCitizenOrPR,
                  null,
                  summary,
                  coverImage,
                  tagline,
                  title,
                  tempPassword,
                  isArchived,
                  null,
                  false,
                  groupId,
                  groupName,
                  groupImage,
                  "",
                  "",
                  zipCode,
                  isHide,
                  referralPopup,
                  userLoginFirstTime,
                  stage,
                  creationTime,
                  badge,
                  gamificationPoints,
                  badgeImage,
                  referCode,
                  socialLinkList,
                  publicUrl,
                  isPublicUrlActive,
                  isPublicProfileGlobalyActive,
                  null,
                  company,
                  isExistingUser,
                  isCollegeAdded,
                  null,
                  schoolCode,
                  '',
                  "",
                  false,
                  false);

              prefs.setString(
                  UserPreference.CREATION_TIME, profileInfoModal.creationTime);
              prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
              prefs.setString(UserPreference.ZIPCODE, profileInfoModal.zipCode);
              prefs.setString(UserPreference.NAME,
                  profileInfoModal.firstName + " " + profileInfoModal.lastName);
              prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                  profileInfoModal.profilePicture);

              prefs.setString(UserPreference.TAGLINE, profileInfoModal.tagline);
              prefs.setString(
                  UserPreference.ISACTIVE, profileInfoModal.isActive);
              //Navigator.of(context).popUntil((route) => route.isFirst); //Apurva did changes for social signup
              goto();
            } else if (widget.isRedirectToRecommendation) {
              prefs.setBool(UserPreference.IS_ADDED_DOB, false);
              prefs.setBool(
                  UserPreference.IS_UNDER_AGE,
                  /*  studentAgeSelection == 1 ? true :*/ false);

              prefs.setBool(UserPreference.LOGIN_STATUS, true);
              prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
              prefs.setBool(UserPreference.IS_PARENT, false);
              prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");
              prefs.setString(UserPreference.IS_PARENT_ROLE, "false");
              prefs.setString(UserPreference.IS_USER_ROLE, "true");
              prefs.setString(UserPreference.ROLE_ID, "1");
              Constant.ROLE_ID = "1";
              prefs.setBool(UserPreference.IS_USER_LOGIN_FIRST_TIME, true);
              prefs.setString(UserPreference.NAME, '');
              prefs.setString(UserPreference.EMAIL, emailController.text);
              prefs.setString(UserPreference.PASSWORD, strNewPassword);
              processForUri(path, strEmail.toLowerCase());
            }
            /* else {
              print('inside loginServiceCall() else');
              prefs.setString(UserPreference.PATHURL, "");
              showSucessMsgLong(message, context);
            }*/
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          setState(() => _isLoading = false);
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "StudentSignup", context);
        if (mounted) CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      setState(() => _isLoading = false);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  void onParentSuccess(Response response, String message) {
    prefs.setString(UserPreference.chat_skip_count, "0");
    prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, false);
    prefs.setBool(UserPreference.isEducationAdded, false);

    bloc.fetchSetting('', context, prefs);
    String path = prefs.getString(UserPreference.PATHURL);
    if (widget.signupType == "apple" || widget.signupType == "google") {
      Constant.isAlreadyLoggedIn = true;
      Navigator.of(context).popUntil((route) => route.isFirst);
      goto();
    } else if (widget.isRedirectToRecommendation) {
      prefs.setString(
          UserPreference.EMAIL, emailController.text.trim().toLowerCase());
      prefs.setString(UserPreference.PASSWORD, strNewPassword);
      prefs.setBool(UserPreference.LOGIN_STATUS, true);
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
      prefs.setBool(UserPreference.IS_USER_LOGIN_FIRST_TIME, true);
      prefs.setBool(UserPreference.IS_PARENT, true);
      prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");
      prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
      prefs.setString(UserPreference.IS_USER_ROLE, "false");
      prefs.setString(UserPreference.ROLE_ID, "2");
      prefs.setBool(UserPreference.IS_ADDED_DOB, false);
      prefs.setBool(UserPreference.IS_UNDER_AGE, true);
      Constant.ROLE_ID = "2";
      processForUri(path, emailController.text.trim().toLowerCase());
    } else {
      Navigator.of(context).popUntil((route) => route.isFirst);
      processForUri(path, emailController.text.trim().toLowerCase());
    }
  }

  bool isShowConformationDialog() {
    if (emailController.text.length > 0) {
      return true;
    }
    return false;
  }

  void conformationDialogForBackNavigation(back) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: MessageConstant.STUDENT_DISCARD_ALL_CHANGES,
            negativeText: 'Cancel',
            positiveText: 'OK',
            isSucessPopup: false,
            positiveTextColor: AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {},
            onPositiveTap: () {
              prefs.setString(UserPreference.PATHURL, "");
              if (widget.pageName == "main") {
                Navigator.pushReplacement(
                    Constant.applicationContext,
                    MaterialPageRoute(
                        builder: (context) => LoginPage(
                              null,
                              showLogin: true,
                            )));
              } else if (back == "back") {
                Navigator.pop(context);
              } else {
                if (widget.pageName == "Login") {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                } else {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => LoginPage(null)));
                }
              }
            },
          );
        });

    /*  showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.fromLTRB(
                                                15.0, 10.0, 15.0, 10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    MessageConstant
                                                        .STUDENT_DISCARD_ALL_CHANGES,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.CANCEL,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.STUDENT_OK,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              prefs.setString(
                                                  UserPreference.PATHURL, "");
                                              if (widget.pageName == "main") {
                                                Navigator.pushReplacement(
                                                    Constant.applicationContext,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            LoginPage(
                                                              null,
                                                              showLogin: true,
                                                            )));
                                              } else if (back == "back") {
                                                Navigator.pop(context);
                                              } else {
                                                if (widget.pageName ==
                                                    "Login") {
                                                  Navigator.of(context)
                                                      .popUntil((route) =>
                                                          route.isFirst);
                                                } else {
                                                  Navigator.of(context)
                                                      .popUntil((route) =>
                                                          route.isFirst);
                                                  Navigator.of(context)
                                                      .pushReplacement(
                                                          MaterialPageRoute(
                                                              builder: (BuildContext
                                                                      context) =>
                                                                  LoginPage(
                                                                      null)));
                                                }
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));*/
  }

  checkAllFieldSubmitter() {
    if (emailController.text.length > 0 && paswordController.text.length > 0) {
      allFieldCompleted = true;
      setState(() {});
    } else {
      allFieldCompleted = false;
      setState(() {});
    }
  }

  checkRefferalField() {
    if (referalController.text.trim().length > 0) {
      referalFieldCompleted = true;
      setState(() {});
    } else {
      referalFieldCompleted = false;
      setState(() {});
    }
  }

  String _getHeading() {
    switch (widget.loginRole) {
      case LoginRole.student:
        return AppConstants.stringConstant.strSignup;
      case LoginRole.parent:
        return "Sign up as a parent";
      case LoginRole.partner:
        return "Sign up as a partner";
      default:
        return "Sign up";
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Widget showReferelPopUp(context) {
      showModalBottomSheet(
          context: context,
          backgroundColor: Colors.white,
          isScrollControlled: true,
          builder: (BuildContext context) {
            return StatefulBuilder(
                builder: (BuildContext context, StateSetter myState
                    /*You can rename this!*/) {
              return customAppbar(
                  context,
                  SingleChildScrollView(
                    child: Form(
                        key: formKeyReferal,
                        child: Container(
                          padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).viewInsets.bottom,
                            left: 0, //11.0,
                            right: 0, // 11.0,
                          ),
                          child: Container(
                            height: 275.0,
                            //color: Colors.black.withOpacity(0.8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: const EdgeInsets.only(
                                        left: 20.0,
                                        right: 0.0,
                                        top: 25.0,
                                        bottom: 0),
                                    child: RichText(
                                      maxLines: 1,
                                      textAlign: TextAlign.center,
                                      text: TextSpan(
                                        text: 'Referral',
                                        style: AppConstants.txtStyle
                                            .heading400LatoRegularDarkBlue
                                            .copyWith(
                                                fontSize: 28,
                                                fontWeight: FontWeight.w700),
                                        children: [
                                          TextSpan(
                                              text: ' code',
                                              recognizer: TapGestureRecognizer()
                                                ..onTap = () {},
                                              style: AppConstants.txtStyle
                                                  .heading40018LatoRegularDarkBlue
                                                  .copyWith(
                                                      fontSize: 28,
                                                      fontWeight:
                                                          FontWeight.w700)),
                                        ],
                                      ),
                                    )),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 20.0, right: 20, top: 50),
                                  child: CustomFormField(
                                    controller: referalController,
                                    label: "Referral code",
                                    onType: (value) {
                                      checkRefferalField();
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )),
                  ), () {
                Navigator.pop(context);
              },
                  bottomNavigation: Container(
                      child: Padding(
                          padding: EdgeInsets.only(
                              left: 20.0, top: 0.0, right: 20.0, bottom: 50.0),
                          child: Stack(
                            children: <Widget>[
                              Container(
                                  height: 44.0,
                                  width: double.infinity,
                                  child: FlatButton(
                                    onPressed: () async {
                                      //callZip();
                                      callApiToValidateTheaReferalCode('');
                                    },
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    color: AppConstants.colorStyle.lightBlue,
                                    child: Row(
                                      // Replace with a Row for horizontal icon + text
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Text(MessageConstant.STUDENT_CONFIRM,
                                            style: AppConstants.txtStyle
                                                .heading18600LatoRegularWhite),
                                      ],
                                    ),
                                  )),
                              referalFieldCompleted
                                  ? SizedBox(
                                      height: 0,
                                    )
                                  : Container(
                                      height: 44.0,
                                      width: double.infinity,
                                      color: Colors.white.withOpacity(0.75),
                                    )
                            ],
                          ))),
                  isShowExplanation: false);
            });
          }).then((value) => (value) {});
    }

    final loginButton = Container(
        child: Padding(
            padding:
                EdgeInsets.only(left: 0.0, top: 0.0, right: 0.0, bottom: 13.0),
            child: Stack(
              children: <Widget>[
                Container(
                    height: 44.0,
                    width: double.infinity,
                    child: FlatButton(
                      onPressed: () async {
                        //callZip();
                        print('onClick++');
                        // final form = formKey.currentState;
                        //form.save();

                        _checkValidation();
                      },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: AppConstants.colorStyle.lightBlue,
                      child: Row(
                        // Replace with a Row for horizontal icon + text
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text('Sign up',
                              style: AppConstants
                                  .txtStyle.heading18600LatoRegularWhite),
                        ],
                      ),
                    )),
                allFieldCompleted
                    ? SizedBox(
                        height: 0,
                      )
                    : Container(
                        height: 44.0,
                        width: double.infinity,
                        color: Colors.white.withOpacity(0.75),
                      )
              ],
            )));

    final body = FormKeyboardActions(
      nextFocus: false,
      keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
      //optional
      keyboardBarColor: Colors.grey[200],
      //optional
      actions: [],
      child: Container(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          children: <Widget>[
            Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Padding(
                      padding: const EdgeInsets.only(
                          left: 0.0, right: 0.0, top: 0.0, bottom: 45),
                      child: RichText(
                        maxLines: 1,
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          text: _getHeading(),
                          style: AppConstants
                              .txtStyle.heading400LatoRegularDarkBlue
                              .copyWith(
                                  fontSize: 28, fontWeight: FontWeight.w700),
                        ),
                      )),
                  CustomFormField(
                    // maxLength: 35,
                    prefixWidget: Image.asset(
                      getAssetsPNGImg('email'),
                      height: 20,
                      width: 20,
                    ),
                    onSaved: (val) => _email = val,
                    autovalidateMode: AutovalidateMode.disabled,
                    onType: (val) {
                      checkAllFieldSubmitter();
                    },
                    enable: widget.isRedirectToRecommendation
                        ? false
                        : widget?.isEditable ?? false
                            ? false
                            : referalUserId != ""
                                ? false
                                : true,
                    controller: emailController,
                    label: "Enter email",
                    validation: (val) => val.trim().length == 0
                        ? MessageConstant.ENTER_EMAIL_VAL
                        : !ValidationWidget.isEmail(val)
                            ? MessageConstant.VALID_EMAIL_VAL
                            : null,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  CustomFormField(
                    // maxLength: 35,
                    controller: paswordController,
                    onSaved: (val) => _password = val,
                    autovalidateMode: AutovalidateMode.disabled,
                    prefixWidget: Image.asset(
                      getAssetsPNGImg('password'),
                      height: 20,
                      width: 20,
                    ),
                    onType: (val) {
                      checkAllFieldSubmitter();
                    },
                    label: "Create password",
                    isObsecure: _newPassObscureText,
                    suffixWidget: GestureDetector(
                      child: _newPassObscureText
                          ? Padding(
                              padding:
                                  EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 6.0),
                              child: Image.asset(
                                "assets/newDesignIcon/login/hide.png",
                                width: 25.0,
                                height: 25.0,
                              ))
                          : Padding(
                              padding:
                                  EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 6.0),
                              child: Image.asset(
                                "assets/newDesignIcon/login/unhide.png",
                                width: 25.0,
                                height: 25.0,
                                color: AppConstants.colorStyle.lightPurple,
                              )),
                      onTap: () {
                        if (_newPassObscureText)
                          _newPassObscureText = false;
                        else
                          _newPassObscureText = true;

                        setState(() {
                          _newPassObscureText;
                        });
                      },
                    ),
                    validation: (val) => val.trim().length == 0
                        ? MessageConstant.ENTER_PASSWORD_VAL
                        : !ValidationWidget.isPass(val)
                            ? MessageConstant.ENTER_PASSWORD_MESSAGE
                            : null,
                  ),
                  referalCodeResponse != null &&
                          referalCodeResponse.status == "Success"
                      ? Padding(
                          padding: const EdgeInsets.only(top: 45.0, bottom: 16),
                          child: CustomFormFieldWithPrefix(
                            controller: referalController,
                            readOnly: true,
                            onSaved: (val) => referralCode = val,
                            prefixWidget: Container(
                              height: 20,
                              width: 20,
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    top: 20, bottom: 0, right: 5),
                                child: SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: Image.asset(
                                    getAssetsPNGImg('check'),
                                    height: 20,
                                    width: 20,
                                  ),
                                ),
                              ),
                            ),
                            onType: (val) {},
                            label: "",
                            suffixWidget: GestureDetector(
                              child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 0.0),
                                child: Icon(
                                  Icons.clear,
                                  color: Color(0xffEB5757),
                                  size: 20,
                                ),
                              ),
                              onTap: () {
                                referalController.text = '';
                                referalCodeResponse = null;
                                setState(() {});
                              },
                            ),
                          ),
                        )
                      : Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 55, 0.0, 20.0),
                          child: Center(
                            child: InkWell(
                              child: BaseText(
                                text:
                                    MessageConstant.STUDENT_HAVE_REFERRAL_CODE,
                                textColor: AppConstants.colorStyle.lightBlue,
                                fontFamily:
                                    AppConstants.stringConstant.latoSemibold,
                                fontWeight: FontWeight.w600,
                                fontSize: 18,
                              ),
                              onTap: () {
                                showReferelPopUp(context);
                              },
                            ),
                          ),
                        ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Container(
                        padding: EdgeInsets.fromLTRB(0.0, 2.0, 0.0, 0.0),
                        child: Column(
                          children: <Widget>[
                            loginButton,
                            Padding(
                                padding:
                                    EdgeInsets.only(top: 14.0, bottom: 24.0),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        height: 1.0,
                                        color: ColorValues.BORDER_COLOR,
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: Text(
                                        '   or continue with   ',
                                        style: AppConstants.txtStyle
                                            .heading14400LatoRegularLightPurple,
                                      ),
                                      flex: 0,
                                    ),
                                    Expanded(
                                      child: Container(
                                        height: 1.0,
                                        color: ColorValues.BORDER_COLOR,
                                      ),
                                      flex: 1,
                                    )
                                  ],
                                )),
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 12.0),
                                    child: InkWell(
                                      onTap: () {
                                        signInWithGoogle(context, "Signup");
                                      },
                                      child: Container(
                                        height: 45.0,
                                        decoration: BoxDecoration(
                                            color:
                                                AppConstants.colorStyle.btnBg,
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0.0, 0, 13, 0),
                                              child: Image.asset(
                                                'assets/login/google.png',
                                                height: 20.0,
                                                width: 20.0,
                                              ),
                                            ),
                                            Text(
                                              MessageConstant
                                                  .LOGIN_SIGN_WITH_GOOGLE,
                                              textAlign: TextAlign.center,
                                              style: AppConstants.txtStyle
                                                  .heading14500LatoRegularDarkBlue,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 12.0),
                                    child: InkWell(
                                      onTap: () async {
                                        final credential = await SignInWithApple
                                            .getAppleIDCredential(
                                          scopes: [
                                            AppleIDAuthorizationScopes.email,
                                            AppleIDAuthorizationScopes.fullName,
                                          ],
                                          webAuthenticationOptions:
                                              WebAuthenticationOptions(
                                            // TODO: Set the `clientId` and `redirectUri` arguments to the values you entered in the Apple Developer portal during the setup
                                            clientId:
                                                'com.spikeview.spikeviewproject',
                                            redirectUri: Uri.parse(
                                              //  'https://quick-mangrove-marble.glitch.me/callbacks/sign_in_with_apple',
                                              'https://app.spikeview.com/ui/callbacks/sign_in_with_apple',
                                            ),
                                          ),
                                          // TODO: Remove these if you have no need for them
                                        );

                                        emailController.text =
                                            credential.email.toString();
                                        if (credential.email.toString() ==
                                                "null" ||
                                            credential.email.toString() == "") {
                                          String yourToken =
                                              credential.identityToken;
                                          Map<String, dynamic> decodedToken =
                                              JwtDecoder.decode(yourToken);
                                          print("decode++++++++++++++" +
                                              decodedToken.toString());
                                          print("decode++++++++++++++" +
                                              decodedToken["email"]);
                                          emailController.text =
                                              decodedToken["email"];
                                        }
                                        widget.signupType = "apple";
                                        loginServiceCall();
                                      },
                                      child: Container(
                                          height: 45.0,
                                          decoration: BoxDecoration(
                                              color:
                                                  AppConstants.colorStyle.btnBg,
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        0.0, 0, 13, 0),
                                                child: Image.asset(
                                                  'assets/login/apple.png',
                                                  height: 20.0,
                                                  width: 20.0,
                                                ),
                                              ),
                                              Text(
                                                MessageConstant
                                                    .LOGIN_SIGN_WITH_APPLE,
                                                textAlign: TextAlign.center,
                                                style: AppConstants.txtStyle
                                                    .heading14500LatoRegularDarkBlue,
                                              ),
                                            ],
                                          )),
                                    ),
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 30,
                            )
                          ],
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );

    final botombar = Container(
      color: Colors.white,
      height: 100.0,
      child: Padding(
        padding: EdgeInsets.only(left: 35.0, right: 35.0, top: 0, bottom: 30),
        child: Center(
          child: RichText(
            maxLines: 3,
            textAlign: TextAlign.center,
            text: TextSpan(
              text: MessageConstant.STUDENT_SIGNING_UP_AGREE,
              style: AppConstants.txtStyle.heading400LatoRegularDarkBlue,
              children: <TextSpan>[
                TextSpan(
                    text: 'Terms, Data',
                    recognizer: TapGestureRecognizer()
                      ..onTap = () {
                        Navigator.push(
                            Constant.applicationContext,
                            MaterialPageRoute(
                                builder: (context) => WebViewWidget(
                                    Constant.TERMS,
                                    MessageConstant.STUDENT_TERMS_DATA)));
                      },
                    style:
                        AppConstants.txtStyle.heading400LatoRegularLightBlue),
                TextSpan(
                  text: " & ",
                  style: AppConstants.txtStyle.heading400LatoRegularDarkBlue,
                ),
                TextSpan(
                  text: MessageConstant.STUDENT_PRIVACY_POLICY,
                  recognizer: TapGestureRecognizer()
                    ..onTap = () {
                      Navigator.push(
                        Constant.applicationContext,
                        MaterialPageRoute(
                          builder: (context) => WebViewWidget(
                              Constant.PRIVACY_POLICY,
                              MessageConstant.STUDENT_PRIVACY_POLICY),
                        ),
                      );
                    },
                  style: AppConstants.txtStyle.heading400LatoRegularLightBlue,
                ),
                /*widget.loginRole == LoginRole.parent
                    ? TextSpan(
                        text:
                            " and confirming your age selected above is accurate.",
                        style:
                            AppConstants.txtStyle.heading400LatoRegularDarkBlue,
                      )
                    :*/
                TextSpan(
                  text: ".",
                  style: AppConstants.txtStyle.heading400LatoRegularDarkBlue,
                ),
              ],
            ),
          ),
        ),
      ),
    );

    onBack() {
      if (widget.pageName == 'main') {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);

        Navigator.pushReplacement(Constant.applicationContext,
            MaterialPageRoute(builder: (context) => LoginPage(null)));
      } else {
        if (isShowConformationDialog()) {
          conformationDialogForBackNavigation("back");
        } else {
          Navigator.pop(context);
        }
      }
    }

    return GestureDetector(
        child: WillPopScope(
            onWillPop: () {
              if (isShowConformationDialog()) {
                conformationDialogForBackNavigation("back");
              } else {
                if (widget.pageName == "main") {
                  Navigator.pushReplacement(
                      Constant.applicationContext,
                      MaterialPageRoute(
                          builder: (context) => LoginPage(
                                null,
                                showLogin: true,
                              )));
                } else
                  Navigator.pop(context);
              }
            },
            child: GestureDetector(
                child: customAppbar(context, body, onBack,
                    signupType: widget.loginRole == LoginRole.parent
                        ? 'parent'
                        : widget.loginRole == LoginRole.partner
                            ? 'partner'
                            : '',
                    bottomNavigation: botombar))));
  }

  Future callApiToValidateTheaReferalCode(String from) async {
    print('inside callApiToValidateTheaReferalCode() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'URL Referal:: ${Constant.ENDPOINT_VALIDATE_REFERAL_CODE_API + referalController.text.trim()}');

        Response response = await ApiCalling().apiCallWithouAuth(
            context,
            Constant.ENDPOINT_VALIDATE_REFERAL_CODE_API +
                referalController.text.trim(),
            "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String message = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              ReferalCodeResponse apiResponse =
                  ReferalCodeResponse.fromJson(response.data);
              referalCodeResponse = apiResponse; //apiResponse.result;
              Navigator.of(context).pop();
              setState(() {});
              print(
                  'Apurva ReferalCodeResponse::::: ${referalCodeResponse.message.toString()}');
              if (from == 'continue') {
                if (widget.isValid) {
                  loginServiceCall();
                } else {
                  ToastWrap.showToastLong(
                      MessageConstant.PRIVATE_EMAIL_MSG, context);
                }
              } else {
                //  ToastWrap.showToastGreen(message, context);
              }
            } else {
              //if(from == 'continue'){
              //ToastWrap.showToast(MessageConstant.INVALID_REFERRAL_CODE, context);
              ToastWrap.showToast(message, context);
              //}
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "StudentSignup", context);
      e.toString();
    }
  }
}
