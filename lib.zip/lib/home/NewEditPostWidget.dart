import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:page_indicator/page_indicator.dart';

import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_multiline_text_form.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/home/group_list_for_post.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/list_image_view.dart';
import 'package:spike_view_project/widgets/positive_button.dart';
import 'package:spike_view_project/widgets/remove_button.dart';
import 'package:spike_view_project/widgets/stepper_widget.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/AddTagGroupWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/widgets/video_player/video_play_view.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:path/path.dart' as path;
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class NewEditPostWidget extends StatefulWidget {
  final ProfileInfoModal profileInfoModal;
  final String groupId;
  final GroupDetailModel groupDetailModel;
  final UserPostModal _mUserPostModal;

  const NewEditPostWidget(
    this.profileInfoModal,
    this.groupId,
    this.groupDetailModel,
    this._mUserPostModal,
  );

  @override
  NewEditPostWidgetState createState() {
    return NewEditPostWidgetState();
  }
}

class NewEditPostWidgetState extends State<NewEditPostWidget> {
  SharedPreferences prefs;
  String userIdPref,
      roleId,
      token,
      userProfilePath,
      companyImagePath,
      companyName;
  String isType = "Community";
  String isPreviousType = "Community";
  List<AssestForPost> assestList = List();
  List<AssetIV> azureImageVideoUploadList = List();
  VoidCallback listener;
  File videoPath;
  String strVideo;
  String strVideoPrevious;
  TextEditingController edtController;
  String sasToken, containerName, strPrefixPathforFeed;
  String strFirstName, strLastName, strEmail;
  List<dynamic> images;
  Future<File> videoFile;
  List<String> azureImageUploadList = List();
  VideoPlayerController _controller;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<TagsPost> selectedUerTagLIst = List();
  List<TagModel> selectedUerTagLIst1 = List();
  List<TagsPost> selectedtScopeList = List();
  File imagePath;
  List<String> groupidList = List();
  bool isGroupPost = false;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    companyImagePath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    companyName = prefs.getString(UserPreference.COMPANY_NAME_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);
    strPrefixPathforFeed = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
    callApiForSaas();
    setState(() {});
  }

  @override
  void initState() {
    edtController = TextEditingController(text: '');
    if (widget._mUserPostModal.visibility == "") {
      isPreviousType = widget._mUserPostModal.visibility;
    } else {
      isType = widget._mUserPostModal.visibility;
      isPreviousType = widget._mUserPostModal.visibility;
    }
    edtController.text = widget._mUserPostModal.postdata.text;
    if (widget._mUserPostModal.tagList.length > 0) {
      for (int i = 0; i < widget._mUserPostModal.tagList.length; i++) {
        var model = widget._mUserPostModal.tagList[i];

        selectedUerTagLIst1.add(new TagModel(
            model.userId,
            model.name,
            "",
            "",
            model.profilePicture,
            true,
            model.roleId,
            model.badge,
            model.gamificationPoints,
            model.badgeImage));

        selectedUerTagLIst.add(new TagsPost(model.userId, model.roleId));
      }
    }
    if (widget._mUserPostModal.groupList.length > 0) {
      for (int i = 0; i < widget._mUserPostModal.groupList.length; i++) {
        var model = widget._mUserPostModal.groupList[i];

        groupidList.add(model.groupId.toString());
      }
    }
    if (widget._mUserPostModal.scopeList.length > 0) {
      for (int i = 0; i < widget._mUserPostModal.scopeList.length; i++) {
        var model = widget._mUserPostModal.scopeList[i];

        selectedtScopeList
            .add(TagsPost(model.userId.toString(), model.roleId.toString()));
      }
    }
    if (widget._mUserPostModal.postdata.assetsList.length > 0) {
      for (int i = 0;
          i < widget._mUserPostModal.postdata.assetsList.length;
          i++) {
        if (widget._mUserPostModal.postdata.assetsList[i].type == "image") {
          assestList.add(AssestForPost(
              widget._mUserPostModal.postdata.assetsList[i].file,
              "image",
              "uploaded",
              false));
        } else {
          assestList.add(AssestForPost(
              widget._mUserPostModal.postdata.assetsList[i].file,
              "video",
              "uploaded",
              false));
          strVideo = widget._mUserPostModal.postdata.assetsList[i].file;
          strVideoPrevious = widget._mUserPostModal.postdata.assetsList[i].file;
          setState(() {});
        }
      }
    } else if (widget._mUserPostModal.postdata.media != null &&
        widget._mUserPostModal.postdata.media != "") {
      strVideo = widget._mUserPostModal.postdata.media;
      strVideoPrevious = widget._mUserPostModal.postdata.media;
      setState(() {});
    }
    if (strVideo == null || strVideo == "null") {
      strVideo = "";
    }
    getSharedPreferences();
    listener = () {
      setState(() {});
    };
    super.initState();
  }

  @override
  void deactivate() {
    if (_controller != null) {
      _controller.setVolume(0.0);
      _controller.removeListener(listener);
    }
    super.deactivate();
  }

  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling().apiCall2(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPostWidget", context);
    }
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath, isImage) async {
    try {
      if (sasToken != "" && containerName != "") {
        final String result = await platform.invokeMethod('getBatteryLevel', {
          "sasToken": sasToken,
          "imagePath": imagePath,
          "uploadPath": Constant.IMAGE_PATH + prefixPath
        });
        print("image_path" + result);
        return result;
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPostWidget", context);
      return "";
    }
  }

  Future apiCalling() async {
    try {
      if (assestList.length > 0) {
        for (int i = 0; i < assestList.length; i++) {
          if (assestList[i].file == "uploaded") {
            azureImageUploadList.add(assestList[i].imagePath);
            azureImageVideoUploadList.add(AssetIV(
                file: assestList[i].imagePath, type: assestList[i].type));
          } else {
            if (assestList[i].type == 'image') {
              String azureUploadPath = await uploadImgOnAzure(
                  assestList[i].imagePath, strPrefixPathforFeed, true);
              azureImageUploadList.add(strPrefixPathforFeed + azureUploadPath);
              azureImageVideoUploadList.add(AssetIV(
                  file: strPrefixPathforFeed + azureUploadPath, type: "image"));
            } else {
              String videopath = await uploadImgOnAzure(
                  assestList[i].file, strPrefixPathforFeed, false);
              azureImageVideoUploadList.add(AssetIV(
                  file: strPrefixPathforFeed + videopath, type: "video"));
            }
          }
        }
      } else if (videoPath != null) {
        strVideo = await uploadImgOnAzure(
            videoPath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            strPrefixPathforFeed,
            false);
      }
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map;
        bool isCommunityPost = false;
        if (isType == "Community") {
          isCommunityPost = true;
        }
        if (edtController.text != "" ||
            assestList.length > 0 ||
            videoPath != null ||
            strVideo != "") {
          if (assestList.length > 0) {
            map = {
              "feedId": widget._mUserPostModal.feedId,
              "post": {
                "text": edtController.text,
                "assets": azureImageVideoUploadList.map((e) => e).toList(),
                // "images": azureImageUploadList.map((item) => item).toList(),
                // "media": ""
              },
              "postedBy": int.parse(userIdPref),
              "dateTime": DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": widget.profileInfoModal.isActive,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == ""
                  ? widget._mUserPostModal.postedGroupId == "null" ||
                          widget._mUserPostModal.postedGroupId == "" ||
                          widget._mUserPostModal.postedGroupId == "0"
                      ? ""
                      : int.parse(widget._mUserPostModal.postedGroupId)
                  : widget.groupId == "0"
                      ? ""
                      : widget.groupId,
              "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
              "isCommunityPost": isCommunityPost,
              "groupIds": groupidList.map((item) => int.parse(item)).toList(),
            };
          } else {
            map = {
              "feedId": widget._mUserPostModal.feedId,
              "post": {
                "text": edtController.text,
                "assets": []
              }, //"images": [], "media": ""},
              "postedBy": int.parse(userIdPref),
              "dateTime": DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": widget.profileInfoModal.isActive,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == ""
                  ? widget._mUserPostModal.postedGroupId == "null" ||
                          widget._mUserPostModal.postedGroupId == "" ||
                          widget._mUserPostModal.postedGroupId == "0"
                      ? ""
                      : int.parse(widget._mUserPostModal.postedGroupId)
                  : widget.groupId == "0"
                      ? ""
                      : widget.groupId,
              "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
              "isCommunityPost": isCommunityPost,
              "groupIds": groupidList.map((item) => int.parse(item)).toList(),
            };
          }
          print("map:-" + map.toString());
          Response response = await ApiCalling()
              .apiCallPutWithMapData(context, Constant.ENDPOINT_EDIT_FEED, map);
          CustomProgressLoader.cancelLoader(context);
          print("response sss:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              if (status == "Success") {
                Navigator.pop(context, "push");
              }
            }
          }
        } else {
          ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        print("error sss1");
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPostWidget", context);
      CustomProgressLoader.cancelLoader(context);
    }
  }

  void conformationDialogForCommunityPost() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black38,
          body: Stack(
            children: <Widget>[
              Positioned(
                  right: 0.0,
                  left: 0.0,
                  bottom: 40.0,
                  child: Container(
                      height: 200.0,
                      color: Colors.transparent,
                      child: Stack(
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              13.0,
                              20.0,
                              13.0,
                              0.0,
                              ListView(children: <Widget>[
                                Container(
                                  height: 145.0,
                                  padding: EdgeInsets.all(10.0),
                                  width: double.infinity,
                                  color: Colors.white,
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          "spikeview community post has to be reviewed by the community admin. It will be visible once approved.",
                                          textAlign: TextAlign.center,
                                          maxLines: 5,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              height: 1.2,
                                              fontSize: 16.0,
                                              fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR),
                                        ),
                                      ]),
                                )
                              ])),
                        ],
                      ))),
              Positioned(
                right: 0.0,
                left: 0.0,
                bottom: 10.0,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: PaddingWrap.paddingfromLTRB(
                      13.0,
                      0.0,
                      13.0,
                      0.0,
                      Container(
                          color: Colors.white,
                          padding: EdgeInsets.all(10.0),
                          height: 51.0,
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: InkWell(
                                  child: Container(
                                      child: Text(
                                    "Cancel",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: ColorValues.GREY_TEXT_COLOR,
                                        fontSize: 16.0,
                                        fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR),
                                  )),
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                ),
                                flex: 1,
                              ),
                              Expanded(
                                child: InkWell(
                                  child: Container(
                                      child: Text(
                                    "Post",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontSize: 16.0,
                                        fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR),
                                  )),
                                  onTap: () {
                                    Navigator.pop(context);
                                    // CustomProgressLoader.showLoader(
                                    //     context);
                                    apiCalling();
                                  },
                                ),
                                flex: 1,
                              )
                            ],
                          ))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    if (_controller != null) _controller.dispose();
  }

  int currentStep = 0, dotIndex = 0;
  final PageController _pageController = PageController();
  bool _isProcessEnable = true;

  void _goToNextStep() {
    _pageController.nextPage(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  void _goToPreviousStep() {
    _pageController.previousPage(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  void _onBackPressed() {
    if (currentStep == 1) {
      _goToPreviousStep();
    } else {
      widget._mUserPostModal.postdata.media = strVideoPrevious;
      Navigator.pop(context, null);
    }
  }

  Widget _negativeButton({@required String title}) {
    return InkWell(
      onTap: () => _onBackPressed(),
      child: Container(
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          border: Border.all(color: Color(0xffB2BDDB)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: const Color(0xff7C89AD),
            fontFamily: AppConstants.stringConstant.latoMedium,
            fontSize: 16,
          ),
        ),
      ),
    );
  }

  void _positiveTap() {
    if (currentStep == 0) {
      if (assestList.length > 0 ||
          edtController.text.trim() != "" ||
          videoPath != null) {
        _goToNextStep();
      } else {
        ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
      }
    } else {
      CustomProgressLoader.showLoader(context);
      Timer(const Duration(milliseconds: 400), () {
        onTapPostButton();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return WillPopScope(
      onWillPop: () {
        _onBackPressed();
        return Future.value(false);
      },
      child: Scaffold(
        backgroundColor: ColorValues.WHITE,
        appBar: AppBar(
          elevation: 0.0,
          automaticallyImplyLeading: false,
          brightness: Brightness.light,
          leadingWidth: 0,
          titleSpacing: 20,
          actions: [
            const HelpButtonWidget(),
            const SizedBox(width: 20),
          ],
          title: BaseText(
            text: "Edit Post",
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              fontFamily: Constant.latoRegular,
              color: ColorValues.HEADING_COLOR_EDUCATION,
            ),
          ),
          backgroundColor: Colors.white,
        ),
        bottomNavigationBar: Container(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
          height: 90,
          alignment: Alignment.center,
          child: Row(
            children: [
              Expanded(
                flex: 30,
                child: _negativeButton(
                    title: currentStep == 1 ? 'Back' : 'Cancel'),
              ),
              currentStep >= 0
                  ? Expanded(
                      flex: 66,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 12),
                        child: SizedBox(
                          height: 44,
                          child: PositiveButton(
                            onTap: () => _positiveTap(),
                            isEnable: _isProcessEnable,
                            title: currentStep == 1 ? 'Update' : 'Next',
                          ),
                        ),
                      ),
                    )
                  : const SizedBox.shrink(),
            ],
          ),
        ),
        body: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 25, 20, 10),
              child: StepperWidget(length: 2, currentStep: currentStep),
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                onPageChanged: (value) {
                  currentStep = value;
                  setState(() {});
                },
                children: [
                  _stepOneView(),
                  _stepTwoView(),
                ],
              ),
              flex: 1,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> getImage(type) async {
    if (assestList.length < 8) {
      if (type == ImageSource.gallery) {
        imagePath = await ImagePicker.pickImage(
            source: ImageSource
                .gallery); //await UploadMedia(context).pickImageFromGallery();
        if (imagePath != null) {
          String strPath = imagePath.toString().substring(
              imagePath.toString().lastIndexOf("/") + 1,
              imagePath.toString().length);
          if (strPath.toString().contains(".") &&
              (!strPath.toString().contains(".gif"))) {
            // await _cropImage(imagePath);
            if (imagePath != null) {
              assestList.add(new AssestForPost(
                  imagePath
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  "image",
                  "",
                  false));
              setState(() {});
            }
          } else {
            ToastWrap.showToast(
                MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
          }
        }
      } else if (type == ImageSource.camera) {
        imagePath = await ImagePicker.pickImage(source: ImageSource.camera);
        if (imagePath != null) {
          String strPath = imagePath.toString().substring(
              imagePath.toString().lastIndexOf("/") + 1,
              imagePath.toString().length);
          if (strPath.toString().contains(".") &&
              (!strPath.toString().contains(".gif"))) {
            //  await _cropImage(imagePath);
            if (imagePath != null) {
              assestList.add(new AssestForPost(
                  imagePath
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  "image",
                  "",
                  false));
              setState(() {
                FocusScope.of(context).requestFocus(FocusNode());
              });
            }
          } else {
            ToastWrap.showToast(
                MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
          }
        }
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.MAXIMUM_8_IMAGE_UPLOADED_VAL, context);
    }
  }

  Future<void> getInitVideo() async {
    try {
      if (_controller == null && videoPath == null) {
        var status = await Permission.photos.status;
        if (status.isGranted) {
          getVideo();
        } else {
          checkPermissionPhoto(context);
        }
      } else if (_controller != null && (videoPath != null)) {
        final oldController = _controller;
        WidgetsBinding.instance.addPostFrameCallback((_) async {
          await oldController.dispose();
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getVideo();
          } else {
            checkPermissionPhoto(context);
          }
        });
        setState(() {
          _controller = null;
          videoPath = null;
        });
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPostWidget", context);
      print("error+" + e.toString());
    }
  }

  Future<void> getVideo() async {
    try {
      String getFileExtension(File file) {
        return path.extension(file.path);
      }

      await ImagePicker.pickVideo(source: ImageSource.gallery)
          .then((File file) {
        if (file != null &&
            getFileExtension(file) != null &&
            getFileExtension(file).length > 0) {
          _controller = VideoPlayerController.file(file)
            ..addListener(listener)
            ..setVolume(1.0)
            ..initialize()
            ..setLooping(false);
          videoPath = file;
          assestList.add(new AssestForPost(
            "",
            "video",
            file.path
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            false,
            controller: _controller,
            videoPath: file,
          ));
          setState(() {
            strVideo = "";
          });
        } else if (file != null) {
          ToastWrap.showToast(
              MessageConstant.VIDEO_SOURCE_INCORRECT_ERROR, context);
        } else {
          setState(() {
            _controller = null;
            videoPath = null;
          });
        }
      });
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPostWidget", context);
      print("error+" + e.toString());
    }
  }

  void uploadPopUp() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black38,
          body: Stack(
            children: <Widget>[
              Positioned(
                right: 0.0,
                left: 0.0,
                bottom: 60.0,
                child: Container(
                  height: 205.0,
                  color: Colors.transparent,
                  child: Stack(
                    children: <Widget>[
                      PaddingWrap.paddingfromLTRB(
                        20.0,
                        0.0,
                        20.0,
                        0.0,
                        ListView(
                          children: <Widget>[
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius:
                                    const BorderRadius.all(Radius.circular(10)),
                              ),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  InkWell(
                                    child: Container(
                                        height: 50.0,
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 13.0, 0.0, 13.0),
                                        child: Text(
                                          AppConstants.stringConstant.camera,
                                          textAlign: TextAlign.center,
                                          style: AppConstants.txtStyle
                                              .title18500LatoRegularBlackPopUpTxt,
                                        )),
                                    onTap: () async {
                                      Navigator.pop(context);
                                      if (videoPath == null) {
                                        var status =
                                            await Permission.photos.status;
                                        if (status.isGranted) {
                                          getImage(ImageSource.camera);
                                        } else {
                                          checkPermissionPhoto(context);
                                        }
                                      }
                                    },
                                  ),
                                  Container(
                                    color: AppConstants.colorStyle.dividerPopUp,
                                    height: 1.0,
                                  ),
                                  InkWell(
                                    child: Container(
                                        height: 50.0,
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 13.0, 0.0, 13.0),
                                        child: Text(
                                          AppConstants
                                              .stringConstant.photoLibrary,
                                          textAlign: TextAlign.center,
                                          style: AppConstants.txtStyle
                                              .title18500LatoRegularBlackPopUpTxt,
                                        )),
                                    onTap: () async {
                                      Navigator.pop(context);
                                      var status =
                                          await Permission.photos.status;
                                      if (status.isGranted) {
                                        getImage(ImageSource.gallery);
                                      } else {
                                        checkPermissionPhoto(context);
                                      }
                                      // } else
                                      //   null;
                                    },
                                  ),
                                  Container(
                                    color: AppConstants.colorStyle.dividerPopUp,
                                    height: 1.0,
                                  ),
                                  InkWell(
                                    child: Container(
                                        height: 50.0,
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 13.0, 0.0, 13.0),
                                        child: Text(
                                          AppConstants
                                              .stringConstant.videoLibrary,
                                          textAlign: TextAlign.center,
                                          style: AppConstants.txtStyle
                                              .title18500LatoRegularBlackPopUpTxt,
                                        )),
                                    onTap: () async {
                                      if (videoPath == null && strVideo == "") {
                                        Navigator.pop(context);
                                        getInitVideo();
                                      } else {
                                        ToastWrap.showToast(
                                            MessageConstant
                                                .MAXIMUM_1_VIDEO_UPLOADED_VAL,
                                            context);
                                      }
                                    },
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                right: 0.0,
                left: 0.0,
                bottom: 50.0,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: PaddingWrap.paddingfromLTRB(
                      20.0,
                      0.0,
                      20.0,
                      0.0,
                      Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius:
                                const BorderRadius.all(Radius.circular(10)),
                          ),
                          padding: EdgeInsets.all(10.0),
                          height: 51.0,
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: InkWell(
                                  child: Container(
                                      child: Text(
                                    "Cancel",
                                    textAlign: TextAlign.center,
                                    style: AppConstants.txtStyle
                                        .heading18600LatoRegularLightBlue,
                                  )),
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                ),
                                flex: 1,
                              ),
                            ],
                          ))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _stepOneView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(15.0),
                child: Container(
                  height: 60.0,
                  width: 60.0,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.white, width: 1),
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 15,
                        offset: Offset(2, 2),
                        color: Color.fromRGBO(98, 175, 226, 0.09),
                      )
                    ],
                  ),
                  child: FadeInImage(
                    fit: BoxFit.cover,
                    placeholder: AssetImage(
                      roleId == "4"
                          ? "assets/profile/partner_img.png"
                          : 'assets/profile/user_on_user.png',
                    ),
                    image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                        ParseJson.getSmallImage(roleId == "4"
                            ? companyImagePath
                            : userProfilePath)),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Row(
                  children: <Widget>[
                    Text(
                      roleId == "4"
                          ? companyName
                          : widget.profileInfoModal != null
                              ? widget.profileInfoModal.lastName == null ||
                                      widget.profileInfoModal.lastName ==
                                          "null" ||
                                      widget.profileInfoModal.lastName == ""
                                  ? widget.profileInfoModal.firstName
                                  : widget.profileInfoModal.firstName +
                                      " " +
                                      widget.profileInfoModal.lastName
                              : "",
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.bold,
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontSize: 14.0),
                    ),
                    widget.profileInfoModal != null
                        ? widget.profileInfoModal.roleId == "1"
                            ?
                            //true ?
                            Util.getStudentBadge12(
                                widget.profileInfoModal.badge,
                                widget.profileInfoModal.badgeImage)
                            : const SizedBox.shrink()
                        : const SizedBox.shrink(),
                  ],
                ),
                flex: 1,
              )
            ],
          ),
          const SizedBox(height: 24),
          CustomMultilineTextForm(
            textInputType: TextInputType.text,
            label: "Description",
            hint: "Share your thoughts",
            maxLength: TextLength.POST_MSG_MAX_LENGTH,
            maxLines: 3,
            alignLabelWithHint: true,
            controller: edtController,
            validation: (val) => val.trim().isEmpty
                ? MessageConstant.ENTER_DESCRIPTION_VAL
                : null,
          ),
          const SizedBox(height: 30),
          SizedBox(
            width: double.maxFinite,
            height: 120,
            child: InkWell(
              onTap: assestList.isNotEmpty ? null : () => uploadPopUp(),
              child: Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 14,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: EdgeInsets.symmetric(
                          horizontal: assestList.isNotEmpty ? 0 : 10),
                      child: assestList.isNotEmpty
                          ? gridSelectedImagesVideos()
                          : Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(height: 18),
                                Image.asset(
                                  "assets/recommendation/ic_camera.png",
                                  height: 26,
                                  width: 25,
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  'Your uploaded photos will appear here',
                                  maxLines: 1,
                                  textAlign: TextAlign.center,
                                  style: AppConstants.txtStyle
                                      .heading14400LatoItalicLightPurple,
                                ),
                              ],
                            ),
                      decoration: BoxDecoration(
                        color: AppConstants.colorStyle.tabBg,
                        border: Border.all(
                          color: AppConstants.colorStyle.borderGenerateScript,
                        ),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(7),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: InkWell(
                      onTap: () => uploadPopUp(),
                      child: Image.asset(
                        "assets/generateScript/plus_icon.png",
                        height: 24,
                        width: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          /*Visibility(
            visible: assestList.length > 1,
            child: getTextView("Uploads(${assestList.length})"),
          ),*/
        ],
      ),
    );
  }

  Widget gridSelectedImagesVideos() {
    return assestList != null && assestList.length > 0
        ? PaddingWrap.paddingfromLTRB(
            15.0,
            0.0,
            15.0,
            0.0,
            SizedBox(
              height: 120,
              child: ReorderableListView(
                onReorder: reorderData,
                scrollDirection: Axis.horizontal,
                children: List.generate(assestList.length, (index) {
                  return assestList[index].type != "image"
                      ? Padding(
                          key: ValueKey(assestList[index]),
                          padding:
                              const EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                          child: _videoItem(
                            index,
                            () => _showRemoveDialog(index),
                            () => _videoPlayDialog(index),
                          ),
                        )
                      : Padding(
                          key: ValueKey(assestList[index]),
                          padding: const EdgeInsets.fromLTRB(5, 0, 0, 0),
                          child: _imageItem(
                            assestList[index].file == "uploaded",
                            assestList[index].imagePath,
                            index,
                          ),
                        );
                }).toList(),
              ),
            ),
          )
        : const SizedBox.shrink();
  }

  void _videoPlayDialog(int index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: false,
        builder: (bc) {
          return StatefulBuilder(builder: (context, state) {
            return Scaffold(
              backgroundColor: ColorValues.WHITE,
              body: Container(
                constraints: BoxConstraints(
                  minHeight: 500,
                  minWidth: 300,
                  maxHeight: 500,
                  maxWidth: MediaQuery.of(context).size.width,
                ),
                child: Stack(
                  children: [
                    Container(
                      height: 500,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(
                              "assets/generateScript/script_background.png"),
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          top: 10, left: 20, right: 20, bottom: 10),
                      child: SizedBox(
                        height: 35,
                        width: double.infinity,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.pop(context, 'pop');
                              },
                              child: Image.asset(
                                "assets/generateScript/cross_close.png",
                                height: 32.0,
                                width: 32.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 55),
                      width: MediaQuery.of(context).size.width,
                      height: 300,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                        ),
                      ),
                      child: assestList[index].videoPath != null
                          ? VideoPlayerView(
                              videoPath: assestList[index].videoPath.path,
                              videoType: VideoType.file,
                            )
                          : VideoPlayerView(
                              videoPath: Constant.PATH_FOR_VIDEO +
                                  widget?._mUserPostModal?.postdata
                                      ?.assetsList[index]?.file
                                      ?.replaceAll(Constant.PATH_FOR_VIDEO, ''),
                              videoType: VideoType.network,
                            ),
                    )
                  ],
                ),
              ),
            );
          });
        }).then((value) => _closeModal(value));
  }

  void reorderData(int oldindex, int newindex) {
    setState(() {
      if (newindex > oldindex) {
        newindex -= 1;
      }
      final items = assestList.removeAt(oldindex);
      assestList.insert(newindex, items);
    });
  }

  onClickGroup() async {
    List<String> groupData = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => GroupListForPost(groupidList, widget.groupId)),
    );
    if (groupData != null && groupData.length > 0) {
      selectedtScopeList.clear();
      groupidList.clear();
      groupidList.addAll(groupData);
      isType = "Group";
      setState(() {});
    }
  }

  void onTapTagBtn() async {
    if (widget.groupId == "") {
      List<TagModel> result = await Navigator.of(context).push(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  AddTagWidget("Tag connections", selectedUerTagLIst1)));

      if (result != null) {
        selectedUerTagLIst1.clear();
        selectedUerTagLIst.clear();
        selectedUerTagLIst1 = result;
      }

      // Create List for API Calling

      setState(() {
        for (int i = 0; i < selectedUerTagLIst1.length; i++) {
          selectedUerTagLIst.add(new TagsPost(
              selectedUerTagLIst1[i].userId, selectedUerTagLIst1[i].roleId));
        }
      });
    } else {
      List<TagModel> result = await Navigator.of(context).push(
          MaterialPageRoute(
              builder: (BuildContext context) => AddTagGroupWidget(
                  "Tagging", widget.groupId, selectedUerTagLIst1)));

      if (result != null) {
        selectedUerTagLIst1.clear();
        selectedUerTagLIst.clear();
        selectedUerTagLIst1 = result;
      }

      // Create List for API Calling

      setState(() {
        for (int i = 0; i < selectedUerTagLIst1.length; i++) {
          selectedUerTagLIst.add(new TagsPost(
              selectedUerTagLIst1[i].userId, selectedUerTagLIst1[i].roleId));
        }
      });
    }
  }

  void onTapTagSelectedConnection() async {
    List<TagsPost> result = await Navigator.of(context).push(MaterialPageRoute(
        builder: (BuildContext context) => AddMyConnectionSharePost(
            "Select Connections", selectedtScopeList)));

    if (result != null) {
      if (result != null && result.length > 0) {
        isType = "SelectedConnections";
        selectedtScopeList.clear();
        groupidList.clear();
        selectedtScopeList = result;
        setState(() {});
      }
    }
  }

  void postPopUp() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black38,
          body: Stack(
            children: <Widget>[
              Positioned(
                right: 0.0,
                left: 0.0,
                bottom: 50.0,
                child: Container(
                  height: 205.0,
                  color: Colors.transparent,
                  child: Stack(
                    children: <Widget>[
                      PaddingWrap.paddingfromLTRB(
                        20.0,
                        0.0,
                        20.0,
                        0.0,
                        ListView(
                          children: <Widget>[
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius:
                                    const BorderRadius.all(Radius.circular(10)),
                              ),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Text(
                                    AppConstants.stringConstant.communityPost,
                                    textAlign: TextAlign.center,
                                    maxLines: 5,
                                    style: AppConstants.txtStyle
                                        .heading14700LatoRegularDarkBlue,
                                  ),
                                  SizedBox(
                                    height: 7,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 14, right: 14),
                                    child: Text(
                                      AppConstants.stringConstant
                                          .spikeCommunityReviewed,
                                      textAlign: TextAlign.center,
                                      maxLines: 5,
                                      style: AppConstants.txtStyle
                                          .heading14400LatoRegularLightPurple,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Container(
                                    color: AppConstants.colorStyle.dividerPopUp,
                                    height: 1.0,
                                  ),
                                  InkWell(
                                    child: Container(
                                        height: 50.0,
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 12.0, 0.0, 13.0),
                                        child: Text(
                                          AppConstants.stringConstant.post,
                                          textAlign: TextAlign.center,
                                          style: AppConstants.txtStyle
                                              .heading16500LatoRegularLightBlue,
                                        )),
                                    onTap: () async {
                                      // Navigator.pop(
                                      //     context, 'pop');
                                      // onTapReviewedPost();

                                      Navigator.pop(context);
                                      CustomProgressLoader.showLoader(context);
                                      apiCalling();
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                right: 0.0,
                left: 0.0,
                bottom: 32.0,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: PaddingWrap.paddingfromLTRB(
                    20.0,
                    0.0,
                    20.0,
                    0.0,
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(10)),
                      ),
                      padding: EdgeInsets.all(10.0),
                      height: 51.0,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: InkWell(
                              child: Container(
                                  child: Text(
                                AppConstants.stringConstant.cancel,
                                textAlign: TextAlign.center,
                                style: AppConstants
                                    .txtStyle.heading16500LatoRegularDarkBlue,
                              )),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  onTapPostButton() async {
    if (assestList.length > 0 ||
        edtController.text.trim() != "" ||
        videoPath != null) {
      if (isType == "Community" && (!isGroupPost)) {
        CustomProgressLoader.cancelLoader(context);
        postPopUp();
        //conformationDialogForCommunityPost();
      } else {
        apiCalling();
      }
    } else {
      ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
    }
  }

  void _closeModal(void value) {
    setState(() {
      //showSignupButton = true;
      //isOpenSignup = !isOpenSignup;
      // isOpenLogin = !isOpenLogin;
    });
  }

  showWhoCanSeeYourPostPopup() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        builder: (BuildContext bc) {
          return StatefulBuilder(builder: (context, state) {
            return Scaffold(
                backgroundColor: ColorValues.WHITE,
                body: SafeArea(
                  child: Stack(
                    children: [
                      Container(
                        height: double.infinity,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(
                                    "assets/generateScript/script_background.png"),
                                fit: BoxFit.fill)),
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 40, left: 20, right: 20),
                        child: SizedBox(
                          height: 100,
                          width: double.infinity,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pop(context, 'pop');
                                },
                                child: Image.asset(
                                  "assets/generateScript/back.png",
                                  height: 32.0,
                                  width: 32.0,
                                ),
                              ),
                              const HelpButtonWidget(),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          margin: const EdgeInsets.only(top: 125),
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(30),
                                topRight: Radius.circular(30),
                              ),
                            ),
                            child: Column(
                              children: [
                                const SizedBox(height: 25),
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 20, right: 20),
                                  alignment: Alignment.centerLeft,
                                  width: MediaQuery.of(context).size.width,
                                  child: Text(
                                      AppConstants
                                          .stringConstant.whoCanSeeYourPost,
                                      style: AppConstants.txtStyle
                                          .heading28_700LatoRegularDarkBlue),
                                ),
                                const SizedBox(height: 40),
                                Expanded(
                                  child: SingleChildScrollView(
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10),
                                      child:
                                          isPreviousType == "Group" &&
                                                  widget._mUserPostModal.postedGroupId !=
                                                      ""
                                              ? Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: <
                                                  Widget>[
                                                  InkWell(
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                                  27.0,
                                                                  10.0,
                                                                  11.0,
                                                                  10.0,
                                                                  Image.asset(
                                                                    "assets/feed/community.png",
                                                                    width: 26.0,
                                                                    height:
                                                                        26.0,
                                                                    color: isType ==
                                                                            "Community"
                                                                        ? ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR
                                                                        : ColorValues
                                                                            .HEADING_COLOR_EDUCATION,
                                                                  )),
                                                          flex: 0,
                                                        ),
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  8.0,
                                                                  0.0,
                                                                  3.0,
                                                                  Text("Community",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      style: isType ==
                                                                              "Community"
                                                                          ? AppConstants
                                                                              .txtStyle
                                                                              .heading18600LatoRegularLightBlue
                                                                          : AppConstants
                                                                              .txtStyle
                                                                              .heading18600LatoRegularDarkBlue)),
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  13.0,
                                                                  Text(
                                                                      "Visible to all spikeview community members.",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      maxLines:
                                                                          2,
                                                                      style: AppConstants
                                                                          .txtStyle
                                                                          .heading16600LatoRegularLightPurple)),
                                                            ],
                                                          ),
                                                          flex: 1,
                                                        )
                                                      ],
                                                    ),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      selectedtScopeList
                                                          .clear();
                                                      groupidList.clear();
                                                      isType = "Community";
                                                      setState(() {});
                                                    },
                                                  ),
                                                  CustomViews
                                                      .getSeparatorLineNewUI(
                                                          leftPadding: 20.0,
                                                          rightPadding: 20.0,
                                                          topPadding: 10.0,
                                                          bottomPadding: 10.0),
                                                  InkWell(
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: PaddingWrap.paddingfromLTRB(
                                                              27.0,
                                                              10.0,
                                                              11.0,
                                                              10.0,
                                                              Image.asset(
                                                                  "assets/feed/group.png",
                                                                  width: 26.0,
                                                                  height: 26.0,
                                                                  color: isType ==
                                                                          "Group"
                                                                      ? ColorValues
                                                                          .BLUE_COLOR_BOTTOMBAR
                                                                      : AppConstants
                                                                          .colorStyle
                                                                          .darkBlue)),
                                                          flex: 0,
                                                        ),
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  8.0,
                                                                  0.0,
                                                                  3.0,
                                                                  Text("Group",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      style: isType ==
                                                                              "Group"
                                                                          ? AppConstants
                                                                              .txtStyle
                                                                              .heading18600LatoRegularLightBlue
                                                                          : AppConstants
                                                                              .txtStyle
                                                                              .heading18600LatoRegularDarkBlue)),
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  4.0,
                                                                  13.0,
                                                                  Text(
                                                                      "Visible to all members in selected groups.",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      maxLines:
                                                                          2,
                                                                      style: AppConstants
                                                                          .txtStyle
                                                                          .heading16600LatoRegularLightPurple)),
                                                            ],
                                                          ),
                                                          flex: 1,
                                                        )
                                                      ],
                                                    ),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      onClickGroup();
                                                    },
                                                  ),
                                                  CustomViews
                                                      .getSeparatorLineNewUI(
                                                          leftPadding: 20.0,
                                                          rightPadding: 20.0,
                                                          topPadding: 10.0,
                                                          bottomPadding: 10.0),
                                                  InkWell(
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                                  27.0,
                                                                  10.0,
                                                                  11.0,
                                                                  10.0,
                                                                  Image.asset(
                                                                    "assets/feed/connections.png",
                                                                    width: 26.0,
                                                                    height:
                                                                        26.0,
                                                                    color: isType ==
                                                                            "AllConnections"
                                                                        ? ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR
                                                                        : AppConstants
                                                                            .colorStyle
                                                                            .darkBlue,
                                                                  )),
                                                          flex: 0,
                                                        ),
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  10.0,
                                                                  0.0,
                                                                  3.0,
                                                                  Text("Connections",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      style: isType ==
                                                                              "AllConnections"
                                                                          ? AppConstants
                                                                              .txtStyle
                                                                              .heading18600LatoRegularLightBlue
                                                                          : AppConstants
                                                                              .txtStyle
                                                                              .heading18600LatoRegularDarkBlue)),
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  13.0,
                                                                  Text(
                                                                      "Your connections on spikeview",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      maxLines:
                                                                          2,
                                                                      style: AppConstants
                                                                          .txtStyle
                                                                          .heading16600LatoRegularLightPurple)),
                                                            ],
                                                          ),
                                                          flex: 0,
                                                        )
                                                      ],
                                                    ),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      selectedtScopeList
                                                          .clear();
                                                      groupidList.clear();
                                                      isType = "AllConnections";
                                                      setState(() {});
                                                    },
                                                  ),
                                                  CustomViews
                                                      .getSeparatorLineNewUI(
                                                          leftPadding: 20.0,
                                                          rightPadding: 20.0,
                                                          topPadding: 10.0,
                                                          bottomPadding: 10.0),
                                                  InkWell(
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                                  27.0,
                                                                  10.0,
                                                                  11.0,
                                                                  10.0,
                                                                  Image.asset(
                                                                    "assets/feed/selected_connections.png",
                                                                    width: 26.0,
                                                                    height:
                                                                        26.0,
                                                                  )),
                                                          flex: 0,
                                                        ),
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  10.0,
                                                                  0.0,
                                                                  3.0,
                                                                  Text("Selected Connections",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      style: isType ==
                                                                              "SelectedConnections"
                                                                          ? AppConstants
                                                                              .txtStyle
                                                                              .heading18600LatoRegularLightBlue
                                                                          : AppConstants
                                                                              .txtStyle
                                                                              .heading18600LatoRegularDarkBlue)),
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  13.0,
                                                                  Text(
                                                                      "Only visible to some connections",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .start,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      maxLines:
                                                                          2,
                                                                      style: AppConstants
                                                                          .txtStyle
                                                                          .heading16600LatoRegularLightPurple)),
                                                            ],
                                                          ),
                                                          flex: 0,
                                                        )
                                                      ],
                                                    ),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      onTapTagSelectedConnection();
                                                    },
                                                  ),
                                                ])
                                              : isPreviousType == "Private"
                                                  ? Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                          InkWell(
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                Expanded(
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          27.0,
                                                                          10.0,
                                                                          11.0,
                                                                          10.0,
                                                                          Image
                                                                              .asset(
                                                                            "assets/feed/community.png",
                                                                            width:
                                                                                26.0,
                                                                            height:
                                                                                26.0,
                                                                            color: isType == "Community"
                                                                                ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                                : ColorValues.HEADING_COLOR_EDUCATION,
                                                                          )),
                                                                  flex: 0,
                                                                ),
                                                                Expanded(
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          8.0,
                                                                          0.0,
                                                                          3.0,
                                                                          Text(
                                                                              "Community",
                                                                              textAlign: TextAlign.start,
                                                                              style: isType == "Community" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          13.0,
                                                                          Text(
                                                                              "Visible to all spikeview community members.",
                                                                              textAlign: TextAlign.start,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              maxLines: 2,
                                                                              style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                    ],
                                                                  ),
                                                                  flex: 1,
                                                                )
                                                              ],
                                                            ),
                                                            onTap: () {
                                                              Navigator.pop(
                                                                  context);
                                                              selectedtScopeList
                                                                  .clear();
                                                              groupidList
                                                                  .clear();
                                                              isType =
                                                                  "Community";
                                                              setState(() {});
                                                            },
                                                          ),
                                                          CustomViews
                                                              .getSeparatorLineNewUI(
                                                                  leftPadding:
                                                                      20.0,
                                                                  rightPadding:
                                                                      20.0,
                                                                  topPadding:
                                                                      10.0,
                                                                  bottomPadding:
                                                                      10.0),
                                                          InkWell(
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                Expanded(
                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                      27.0,
                                                                      10.0,
                                                                      11.0,
                                                                      10.0,
                                                                      Image.asset(
                                                                          "assets/feed/group.png",
                                                                          width:
                                                                              26.0,
                                                                          height:
                                                                              26.0,
                                                                          color: isType == "Group"
                                                                              ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                              : AppConstants.colorStyle.darkBlue)),
                                                                  flex: 0,
                                                                ),
                                                                Expanded(
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          8.0,
                                                                          0.0,
                                                                          3.0,
                                                                          Text(
                                                                              "Group",
                                                                              textAlign: TextAlign.start,
                                                                              style: isType == "Group" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          4.0,
                                                                          13.0,
                                                                          Text(
                                                                              "Visible to all members in selected groups.",
                                                                              textAlign: TextAlign.start,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              maxLines: 2,
                                                                              style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                    ],
                                                                  ),
                                                                  flex: 1,
                                                                )
                                                              ],
                                                            ),
                                                            onTap: () {
                                                              Navigator.pop(
                                                                  context);
                                                              onClickGroup();
                                                            },
                                                          ),
                                                          CustomViews
                                                              .getSeparatorLineNewUI(
                                                                  leftPadding:
                                                                      20.0,
                                                                  rightPadding:
                                                                      20.0,
                                                                  topPadding:
                                                                      10.0,
                                                                  bottomPadding:
                                                                      10.0),
                                                          InkWell(
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                Expanded(
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          27.0,
                                                                          10.0,
                                                                          11.0,
                                                                          10.0,
                                                                          Image
                                                                              .asset(
                                                                            "assets/feed/connections.png",
                                                                            width:
                                                                                26.0,
                                                                            height:
                                                                                26.0,
                                                                            color: isType == "AllConnections"
                                                                                ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                                : AppConstants.colorStyle.darkBlue,
                                                                          )),
                                                                  flex: 0,
                                                                ),
                                                                Expanded(
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          3.0,
                                                                          Text(
                                                                              "Connections",
                                                                              textAlign: TextAlign.start,
                                                                              style: isType == "AllConnections" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          13.0,
                                                                          Text(
                                                                              "Your connections on spikeview",
                                                                              textAlign: TextAlign.start,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              maxLines: 2,
                                                                              style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                    ],
                                                                  ),
                                                                  flex: 0,
                                                                )
                                                              ],
                                                            ),
                                                            onTap: () {
                                                              Navigator.pop(
                                                                  context);
                                                              selectedtScopeList
                                                                  .clear();
                                                              groupidList
                                                                  .clear();
                                                              isType =
                                                                  "AllConnections";
                                                              setState(() {});
                                                            },
                                                          ),
                                                          CustomViews
                                                              .getSeparatorLineNewUI(
                                                                  leftPadding:
                                                                      20.0,
                                                                  rightPadding:
                                                                      20.0,
                                                                  topPadding:
                                                                      10.0,
                                                                  bottomPadding:
                                                                      10.0),
                                                          InkWell(
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                Expanded(
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          27.0,
                                                                          10.0,
                                                                          11.0,
                                                                          10.0,
                                                                          Image
                                                                              .asset(
                                                                            "assets/feed/selected_connections.png",
                                                                            width:
                                                                                26.0,
                                                                            height:
                                                                                26.0,
                                                                          )),
                                                                  flex: 0,
                                                                ),
                                                                Expanded(
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          3.0,
                                                                          Text(
                                                                              "Selected Connections",
                                                                              textAlign: TextAlign.start,
                                                                              style: isType == "SelectedConnections" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          13.0,
                                                                          Text(
                                                                              "Only visible to some connections",
                                                                              textAlign: TextAlign.start,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              maxLines: 2,
                                                                              style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                    ],
                                                                  ),
                                                                  flex: 0,
                                                                )
                                                              ],
                                                            ),
                                                            onTap: () {
                                                              Navigator.pop(
                                                                  context);
                                                              onTapTagSelectedConnection();
                                                            },
                                                          ),
                                                          CustomViews
                                                              .getSeparatorLineNewUI(
                                                                  leftPadding:
                                                                      20.0,
                                                                  rightPadding:
                                                                      20.0,
                                                                  topPadding:
                                                                      10.0,
                                                                  bottomPadding:
                                                                      10.0),
                                                          InkWell(
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                Expanded(
                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                      27.0,
                                                                      15.0,
                                                                      11.0,
                                                                      10.0,
                                                                      Image.asset(
                                                                          "assets/feed/private_lock.png",
                                                                          width:
                                                                              26.0,
                                                                          height:
                                                                              26.0,
                                                                          color: isType == "Private"
                                                                              ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                              : AppConstants
                                                                              .colorStyle
                                                                              .darkBlue)),
                                                                  flex: 0,
                                                                ),
                                                                Expanded(
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          3.0,
                                                                          Text(
                                                                              "Make it Private",
                                                                              textAlign: TextAlign.start,
                                                                              style: isType == "Private" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          13.0,
                                                                          Text(
                                                                              "Only visible to me",
                                                                              textAlign: TextAlign.start,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              maxLines: 2,
                                                                              style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                    ],
                                                                  ),
                                                                  flex: 0,
                                                                )
                                                              ],
                                                            ),
                                                            onTap: () {
                                                              Navigator.pop(
                                                                  context);
                                                              selectedtScopeList
                                                                  .clear();
                                                              groupidList
                                                                  .clear();
                                                              selectedUerTagLIst1
                                                                  .clear();
                                                              selectedUerTagLIst
                                                                  .clear();
                                                              isType =
                                                                  "Private";
                                                              setState(() {});
                                                            },
                                                          ),
                                                        ])
                                                  : isPreviousType ==
                                                          "SelectedConnections"
                                                      ? Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                              InkWell(
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Expanded(
                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                          27.0,
                                                                          10.0,
                                                                          11.0,
                                                                          10.0,
                                                                          Image.asset(
                                                                            "assets/feed/community.png",
                                                                            width:
                                                                                26.0,
                                                                            height:
                                                                                26.0,
                                                                            color: isType == "Community"
                                                                                ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                                : ColorValues.HEADING_COLOR_EDUCATION,
                                                                          )),
                                                                      flex: 0,
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              8.0,
                                                                              0.0,
                                                                              3.0,
                                                                              Text("Community", textAlign: TextAlign.start, style: isType == "Community" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              13.0,
                                                                              Text("Visible to all spikeview community members.", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                        ],
                                                                      ),
                                                                      flex: 1,
                                                                    )
                                                                  ],
                                                                ),
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                  selectedtScopeList
                                                                      .clear();
                                                                  groupidList
                                                                      .clear();
                                                                  isType =
                                                                      "Community";
                                                                  setState(
                                                                      () {});
                                                                },
                                                              ),
                                                              CustomViews.getSeparatorLineNewUI(
                                                                  leftPadding:
                                                                      20.0,
                                                                  rightPadding:
                                                                      20.0,
                                                                  topPadding:
                                                                      10.0,
                                                                  bottomPadding:
                                                                      10.0),
                                                              InkWell(
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Expanded(
                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                          27.0,
                                                                          10.0,
                                                                          11.0,
                                                                          10.0,
                                                                          Image.asset(
                                                                              "assets/feed/group.png",
                                                                              width: 26.0,
                                                                              height: 26.0,
                                                                              color: isType == "Group" ? ColorValues.BLUE_COLOR_BOTTOMBAR : AppConstants.colorStyle.darkBlue)),
                                                                      flex: 0,
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              8.0,
                                                                              0.0,
                                                                              3.0,
                                                                              Text("Group", textAlign: TextAlign.start, style: isType == "Group" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              0.0,
                                                                              4.0,
                                                                              13.0,
                                                                              Text("Visible to all members in selected groups.", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                        ],
                                                                      ),
                                                                      flex: 1,
                                                                    )
                                                                  ],
                                                                ),
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                  onClickGroup();
                                                                },
                                                              ),
                                                              CustomViews.getSeparatorLineNewUI(
                                                                  leftPadding:
                                                                      20.0,
                                                                  rightPadding:
                                                                      20.0,
                                                                  topPadding:
                                                                      10.0,
                                                                  bottomPadding:
                                                                      10.0),
                                                              InkWell(
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Expanded(
                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                          27.0,
                                                                          10.0,
                                                                          11.0,
                                                                          10.0,
                                                                          Image.asset(
                                                                            "assets/feed/connections.png",
                                                                            width:
                                                                                26.0,
                                                                            height:
                                                                                26.0,
                                                                            color: isType == "AllConnections"
                                                                                ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                                : AppConstants.colorStyle.darkBlue,
                                                                          )),
                                                                      flex: 0,
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              10.0,
                                                                              0.0,
                                                                              3.0,
                                                                              Text("Connections", textAlign: TextAlign.start, style: isType == "AllConnections" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              13.0,
                                                                              Text("Your connections on spikeview", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                        ],
                                                                      ),
                                                                      flex: 0,
                                                                    )
                                                                  ],
                                                                ),
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                  selectedtScopeList
                                                                      .clear();
                                                                  groupidList
                                                                      .clear();
                                                                  isType =
                                                                      "AllConnections";
                                                                  setState(
                                                                      () {});
                                                                },
                                                              ),
                                                              CustomViews.getSeparatorLineNewUI(
                                                                  leftPadding:
                                                                      20.0,
                                                                  rightPadding:
                                                                      20.0,
                                                                  topPadding:
                                                                      10.0,
                                                                  bottomPadding:
                                                                      10.0),
                                                              InkWell(
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Expanded(
                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                          27.0,
                                                                          10.0,
                                                                          11.0,
                                                                          10.0,
                                                                          Image.asset(
                                                                            "assets/feed/selected_connections.png",
                                                                            width:
                                                                                26.0,
                                                                            height:
                                                                                26.0,
                                                                            // color: isType ==
                                                                            //         "SelectedConnections"
                                                                            //     ? ColorValues
                                                                            //         .BLUE_COLOR_BOTTOMBAR
                                                                            //     : AppConstants
                                                                            //         .colorStyle
                                                                            //         .darkBlue,
                                                                          )),
                                                                      flex: 0,
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              10.0,
                                                                              0.0,
                                                                              3.0,
                                                                              Text("Selected Connections", textAlign: TextAlign.start, style: isType == "SelectedConnections" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              13.0,
                                                                              Text("Only visible to some connections", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                        ],
                                                                      ),
                                                                      flex: 0,
                                                                    )
                                                                  ],
                                                                ),
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                  onTapTagSelectedConnection();
                                                                },
                                                              ),
                                                            ])
                                                      : isPreviousType ==
                                                              "AllConnections"
                                                          ? Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                  InkWell(
                                                                    child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: <
                                                                          Widget>[
                                                                        Expanded(
                                                                          child: PaddingWrap.paddingfromLTRB(
                                                                              27.0,
                                                                              10.0,
                                                                              11.0,
                                                                              10.0,
                                                                              Image.asset(
                                                                                "assets/feed/community.png",
                                                                                width: 26.0,
                                                                                height: 26.0,
                                                                                color: isType == "Community" ? ColorValues.BLUE_COLOR_BOTTOMBAR : ColorValues.HEADING_COLOR_EDUCATION,
                                                                              )),
                                                                          flex:
                                                                              0,
                                                                        ),
                                                                        Expanded(
                                                                          child:
                                                                              Column(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              PaddingWrap.paddingfromLTRB(0.0, 8.0, 0.0, 3.0, Text("Community", textAlign: TextAlign.start, style: isType == "Community" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                              PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 13.0, Text("Visible to all spikeview community members.", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                            ],
                                                                          ),
                                                                          flex:
                                                                              1,
                                                                        )
                                                                      ],
                                                                    ),
                                                                    onTap: () {
                                                                      Navigator.pop(
                                                                          context);
                                                                      selectedtScopeList
                                                                          .clear();
                                                                      groupidList
                                                                          .clear();
                                                                      isType =
                                                                          "Community";
                                                                      setState(
                                                                          () {});
                                                                    },
                                                                  ),
                                                                  CustomViews.getSeparatorLineNewUI(
                                                                      leftPadding:
                                                                          20.0,
                                                                      rightPadding:
                                                                          20.0,
                                                                      topPadding:
                                                                          10.0,
                                                                      bottomPadding:
                                                                          10.0),
                                                                  InkWell(
                                                                    child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: <
                                                                          Widget>[
                                                                        Expanded(
                                                                          child: PaddingWrap.paddingfromLTRB(
                                                                              27.0,
                                                                              10.0,
                                                                              11.0,
                                                                              10.0,
                                                                              Image.asset("assets/feed/group.png", width: 26.0, height: 26.0, color: isType == "Group" ? ColorValues.BLUE_COLOR_BOTTOMBAR : AppConstants.colorStyle.darkBlue)),
                                                                          flex:
                                                                              0,
                                                                        ),
                                                                        Expanded(
                                                                          child:
                                                                              Column(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              PaddingWrap.paddingfromLTRB(0.0, 8.0, 0.0, 3.0, Text("Group", textAlign: TextAlign.start, style: isType == "Group" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                              PaddingWrap.paddingfromLTRB(0.0, 0.0, 4.0, 13.0, Text("Visible to all members in selected groups.", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                            ],
                                                                          ),
                                                                          flex:
                                                                              1,
                                                                        )
                                                                      ],
                                                                    ),
                                                                    onTap: () {
                                                                      Navigator.pop(
                                                                          context);
                                                                      onClickGroup();
                                                                    },
                                                                  ),
                                                                  CustomViews.getSeparatorLineNewUI(
                                                                      leftPadding:
                                                                          20.0,
                                                                      rightPadding:
                                                                          20.0,
                                                                      topPadding:
                                                                          10.0,
                                                                      bottomPadding:
                                                                          10.0),
                                                                  InkWell(
                                                                    child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: <
                                                                          Widget>[
                                                                        Expanded(
                                                                          child: PaddingWrap.paddingfromLTRB(
                                                                              27.0,
                                                                              10.0,
                                                                              11.0,
                                                                              10.0,
                                                                              Image.asset(
                                                                                "assets/feed/connections.png",
                                                                                width: 26.0,
                                                                                height: 26.0,
                                                                                color: isType == "AllConnections" ? ColorValues.BLUE_COLOR_BOTTOMBAR : AppConstants.colorStyle.darkBlue,
                                                                              )),
                                                                          flex:
                                                                              0,
                                                                        ),
                                                                        Expanded(
                                                                          child:
                                                                              Column(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 3.0, Text("Connections", textAlign: TextAlign.start, style: isType == "AllConnections" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                              PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 13.0, Text("Your connections on spikeview", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                            ],
                                                                          ),
                                                                          flex:
                                                                              0,
                                                                        )
                                                                      ],
                                                                    ),
                                                                    onTap: () {
                                                                      Navigator.pop(
                                                                          context);
                                                                      selectedtScopeList
                                                                          .clear();
                                                                      groupidList
                                                                          .clear();
                                                                      isType =
                                                                          "AllConnections";
                                                                      setState(
                                                                          () {});
                                                                    },
                                                                  ),
                                                                ])
                                                          : isPreviousType ==
                                                                  "Group"
                                                              ? Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                      InkWell(
                                                                        child:
                                                                            Row(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: <
                                                                              Widget>[
                                                                            Expanded(
                                                                              child: PaddingWrap.paddingfromLTRB(
                                                                                  27.0,
                                                                                  10.0,
                                                                                  11.0,
                                                                                  10.0,
                                                                                  Image.asset(
                                                                                    "assets/feed/community.png",
                                                                                    width: 26.0,
                                                                                    height: 26.0,
                                                                                    color: isType == "Community" ? ColorValues.BLUE_COLOR_BOTTOMBAR : ColorValues.HEADING_COLOR_EDUCATION,
                                                                                  )),
                                                                              flex: 0,
                                                                            ),
                                                                            Expanded(
                                                                              child: Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: [
                                                                                  PaddingWrap.paddingfromLTRB(0.0, 8.0, 0.0, 3.0, Text("Community", textAlign: TextAlign.start, style: isType == "Community" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                                  PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 13.0, Text("Visible to all spikeview community members.", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                                ],
                                                                              ),
                                                                              flex: 1,
                                                                            )
                                                                          ],
                                                                        ),
                                                                        onTap:
                                                                            () {
                                                                          Navigator.pop(
                                                                              context);
                                                                          selectedtScopeList
                                                                              .clear();
                                                                          groupidList
                                                                              .clear();
                                                                          isType =
                                                                              "Community";
                                                                          setState(
                                                                              () {});
                                                                        },
                                                                      ),
                                                                      CustomViews.getSeparatorLineNewUI(
                                                                          leftPadding:
                                                                              20.0,
                                                                          rightPadding:
                                                                              20.0,
                                                                          topPadding:
                                                                              10.0,
                                                                          bottomPadding:
                                                                              10.0),
                                                                      InkWell(
                                                                        child:
                                                                            Row(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: <
                                                                              Widget>[
                                                                            Expanded(
                                                                              child: PaddingWrap.paddingfromLTRB(27.0, 10.0, 11.0, 10.0, Image.asset("assets/feed/group.png", width: 26.0, height: 26.0, color: isType == "Group" ? ColorValues.BLUE_COLOR_BOTTOMBAR : AppConstants.colorStyle.darkBlue)),
                                                                              flex: 0,
                                                                            ),
                                                                            Expanded(
                                                                              child: Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: [
                                                                                  PaddingWrap.paddingfromLTRB(0.0, 8.0, 0.0, 3.0, Text("Group", textAlign: TextAlign.start, style: isType == "Group" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                                  PaddingWrap.paddingfromLTRB(0.0, 0.0, 4.0, 13.0, Text("Visible to all members in selected groups.", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                                ],
                                                                              ),
                                                                              flex: 1,
                                                                            )
                                                                          ],
                                                                        ),
                                                                        onTap:
                                                                            () {
                                                                          Navigator.pop(
                                                                              context);
                                                                          onClickGroup();
                                                                        },
                                                                      ),
                                                                    ])
                                                              : Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                      InkWell(
                                                                        child:
                                                                            Row(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: <
                                                                              Widget>[
                                                                            Expanded(
                                                                              child: PaddingWrap.paddingfromLTRB(
                                                                                  27.0,
                                                                                  10.0,
                                                                                  11.0,
                                                                                  10.0,
                                                                                  Image.asset(
                                                                                    "assets/feed/community.png",
                                                                                    width: 26.0,
                                                                                    height: 26.0,
                                                                                    color: isType == "Community" ? ColorValues.BLUE_COLOR_BOTTOMBAR : ColorValues.HEADING_COLOR_EDUCATION,
                                                                                  )),
                                                                              flex: 0,
                                                                            ),
                                                                            Expanded(
                                                                              child: Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: [
                                                                                  PaddingWrap.paddingfromLTRB(0.0, 8.0, 0.0, 3.0, Text("Community", textAlign: TextAlign.start, style: isType == "Community" ? AppConstants.txtStyle.heading18600LatoRegularLightBlue : AppConstants.txtStyle.heading18600LatoRegularDarkBlue)),
                                                                                  PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 13.0, Text("Visible to all spikeview community members.", textAlign: TextAlign.start, overflow: TextOverflow.ellipsis, maxLines: 2, style: AppConstants.txtStyle.heading16600LatoRegularLightPurple)),
                                                                                ],
                                                                              ),
                                                                              flex: 1,
                                                                            )
                                                                          ],
                                                                        ),
                                                                        onTap:
                                                                            () {
                                                                          Navigator.pop(
                                                                              context);
                                                                          selectedtScopeList
                                                                              .clear();
                                                                          groupidList
                                                                              .clear();
                                                                          isType =
                                                                              "Community";
                                                                          setState(
                                                                              () {});
                                                                        },
                                                                      ),
                                                                    ]),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ));
          });
        }).then((value) => _closeModal(value));
  }

  Widget getTextView(String text) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        text,
        style: TextStyle(
            fontSize: 12.0,
            fontFamily: Constant.customRegular,
            color: ColorValues.HEADING_COLOR_EDUCATION_1),
        textAlign: TextAlign.left,
      ),
    );
  }

  Widget _imageItem(bool uploaded, String path, int index) {
    return uploaded
        ? ListImageView(
            imageUrl: path.replaceAll(Constant.IMAGE_PATH_SMALL, ''),
            onRemoveTap: () => _showRemoveDialog(index),
          )
        : ListImageView(
            imageUrl: '',
            imageFile: File(path),
            onRemoveTap: () => _showRemoveDialog(index),
          );
  }

  void _showRemoveDialog(int index) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: 'Are you sure you want to remove this?',
          onPositiveTap: () {
            if (assestList[index].type != "image") {
              _controller = null;
              videoPath = null;
              strVideo = "";
            }
            assestList.removeAt(index);
            setState(() {});
          },
        );
      },
    );
  }

  Widget _videoItem(
    int index,
    VoidCallback onRemoveTap,
    VoidCallback onPlayTap,
  ) {
    double width = 140;
    double height = 75;
    /* return FutureBuilder<File>(
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return Center(
            child: SizedBox(
              width: 30.0,
              height: 30.0,
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(
                  Colors.black54,
                ),
                strokeWidth: 2.0,
              ),
            ),
          );
        } else {
          return ListVideoItem(
            videoUrl: '',
            onPlayTap:onPlayTap,
            onRemoveTap: onRemoveTap,
            thumbnailFile: snap.data,
          );
        }
      },
      future: UploadMedia.getThumbnailFromUrl(
          assestList[index].videoPath != null
      ? assestList[index].videoPath.path
      :Constant.PATH_FOR_VIDEO +widget?._mUserPostModal?.postdata
              ?.assetsList[index]?.file?.replaceAll(Constant.PATH_FOR_VIDEO, '',)),
    );*/
    return Container(
      height: height,
      width: width,
      margin: EdgeInsets.only(right: 10),
      child: Stack(
        children: [
          Row(
            children: [
              Image.asset(
                "assets/generateScript/wall_frame_video.png",
                height: height,
                width: 20,
                fit: BoxFit.fitHeight,
              ),
              Container(
                height: height,
                width: 100,
                color: Colors.black,
                child: assestList[index].videoPath != null
                    ? VideoPlayerView(
                        videoPath: assestList[index].videoPath.path,
                        videoType: VideoType.file,
                        hideController: true,
                      )
                    : VideoPlayerView(
                        videoPath: Constant.PATH_FOR_VIDEO +
                            widget?._mUserPostModal?.postdata?.assetsList[index]
                                ?.file
                                ?.replaceAll(
                              Constant.PATH_FOR_VIDEO,
                              '',
                            ),
                        videoType: VideoType.network,
                        hideController: true,
                      ),
              ),
              Image.asset(
                "assets/generateScript/wall_frame_video.png",
                height: height,
                width: 20,
                fit: BoxFit.fitHeight,
              ),
            ],
          ),
          Positioned(
            left: 20,
            right: 20,
            top: 0,
            bottom: 0,
            child: Container(
              color: Colors.black12,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    child: Image.asset(
                      'assets/experience/ic_play.png',
                      width: 24,
                      height: 26,
                    ),
                    onTap: onPlayTap,
                  ),
                  RemoveButton(onTap: onRemoveTap),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stepTwoView() {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: ListView(
        padding: EdgeInsets.zero,
        shrinkWrap: true,
        children: [
          assestList.length > 0
              ? SizedBox(
                  height: 280,
                  child: Stack(
                    children: [
                      PageIndicatorContainer(
                        pageView: PageView.builder(
                          itemCount: assestList.length,
                          controller: PageController(),
                          itemBuilder: (context, index) {
                            return assestList[index].type == 'image'
                                ? Container(
                                    height: 280,
                                    decoration: BoxDecoration(
                                      color: Colors.black,
                                    ),
                                    child: assestList[index].file == "uploaded"
                                        ? CachedNetworkImage(
                                            height: 280,
                                            width: double.maxFinite,
                                            imageUrl:
                                                Constant.IMAGE_PATH_SMALL +
                                                    assestList[index].imagePath,
                                            fit: BoxFit.contain,
                                            placeholder: (context, url) =>
                                                Center(
                                              child: SizedBox(
                                                width: 30,
                                                height: 30,
                                                child:
                                                    CircularProgressIndicator(
                                                  valueColor:
                                                      AlwaysStoppedAnimation(
                                                    Colors.black54,
                                                  ),
                                                  strokeWidth: 2.0,
                                                ),
                                              ),
                                            ),
                                            errorWidget:
                                                (context, url, error) =>
                                                    Image.asset(
                                              "assets/aerial/feed_default_img.png",
                                              fit: BoxFit.cover,
                                              height: 280,
                                            ),
                                          )
                                        : Image.file(
                                            File(assestList[index].imagePath),
                                            fit: BoxFit.contain,
                                            height: 280,
                                            width: MediaQuery.of(context)
                                                .size
                                                .width,
                                          ),
                                  )
                                : Container(
                                    height: 280,
                                    color: Colors.black,
                                    child: assestList[index].file != null
                                        ? VideoPlayerView(
                                            videoPath: Constant.PATH_FOR_VIDEO +
                                                widget
                                                    ?._mUserPostModal
                                                    ?.postdata
                                                    ?.assetsList[index]
                                                    ?.file
                                                    ?.replaceAll(
                                                        Constant.PATH_FOR_VIDEO,
                                                        ''),
                                            videoType: VideoType.network,
                                          )
                                        : VideoPlayerView(
                                            videoPath: assestList[index].file,
                                            videoType: VideoType.file,
                                          ),
                                  );
                          },
                          onPageChanged: (index) {},
                        ),
                        align: IndicatorAlign.bottom,
                        length: assestList.length,
                        indicatorSpace: 10,
                        indicatorColor: assestList.length == 1
                            ? Colors.transparent
                            : const Color(0xffc4c4c4),
                        indicatorSelectorColor: assestList.length == 1
                            ? Colors.transparent
                            : Colors.white,
                        shape: IndicatorShape.circle(size: 5),
                      ),
                      Container(
                        padding: EdgeInsets.fromLTRB(20, 12, 20, 12),
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage(
                              "assets/feed/background_imageview.png",
                            ),
                            fit: BoxFit.cover,
                          ),
                        ),
                        child: Row(
                          children: <Widget>[
                            ProfileImageView(
                              imagePath: Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getSmallImage(
                                    roleId == "4"
                                        ? companyImagePath
                                        : userProfilePath,
                                  ),
                              placeHolderImage: roleId == "4"
                                  ? "assets/profile/partner_img.png"
                                  : 'assets/profile/user_on_user.png',
                              height: 46,
                              width: 46,
                              onTap: () {},
                              withoutShadow: true,
                            ),
                            const SizedBox(width: 13),
                            Expanded(
                              child: Text(
                                roleId == "4"
                                    ? companyName
                                    : widget.profileInfoModal != null
                                        ? widget.profileInfoModal.lastName ==
                                                    null ||
                                                widget.profileInfoModal
                                                        .lastName ==
                                                    "null" ||
                                                widget.profileInfoModal
                                                        .lastName ==
                                                    ""
                                            ? widget.profileInfoModal.firstName
                                            : widget.profileInfoModal
                                                    .firstName +
                                                " " +
                                                widget.profileInfoModal.lastName
                                        : "",
                                overflow: TextOverflow.ellipsis,
                                style: assestList.length > 0
                                    ? AppConstants
                                        .txtStyle.heading16500LatoRegularWhite
                                    : AppConstants.txtStyle
                                        .heading14400LatoRegularDarkBlue,
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              : Padding(
                  padding: EdgeInsets.fromLTRB(20.0, 12.0, 20.0, 0.0),
                  child: Row(
                    children: <Widget>[
                      ProfileImageView(
                        imagePath: Constant.IMAGE_PATH_SMALL +
                            ParseJson.getSmallImage(
                              roleId == "4"
                                  ? companyImagePath
                                  : userProfilePath,
                            ),
                        placeHolderImage: roleId == "4"
                            ? "assets/profile/partner_img.png"
                            : 'assets/profile/user_on_user.png',
                        height: 46,
                        width: 46,
                        onTap: () {},
                      ),
                      const SizedBox(width: 13),
                      Expanded(
                        child: Text(
                          roleId == "4"
                              ? companyName
                              : widget.profileInfoModal != null
                                  ? widget.profileInfoModal.lastName == null ||
                                          widget.profileInfoModal.lastName ==
                                              "null" ||
                                          widget.profileInfoModal.lastName == ""
                                      ? widget.profileInfoModal.firstName
                                      : widget.profileInfoModal.firstName +
                                          " " +
                                          widget.profileInfoModal.lastName
                                  : "",
                          overflow: TextOverflow.ellipsis,
                          style: AppConstants
                              .txtStyle.heading14400LatoRegularDarkBlue,
                        ),
                      )
                    ],
                  ),
                ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 17, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: <Widget>[
                    Image.asset(
                      "assets/feed/heart_blue.png",
                      height: 15.0,
                      width: 15.0,
                    ),
                    const SizedBox(width: 7),
                    Image.asset(
                      "assets/feed/comment.png",
                      height: 20.0,
                      width: 20.0,
                    ),
                    const SizedBox(width: 7),
                    Image.asset(
                      "assets/feed/share.png",
                      height: 18.0,
                      width: 18.0,
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  edtController.text.trim(),
                  style: AppConstants.txtStyle.heading14400LatoRegularDarkBlue,
                ),
                const SizedBox(height: 50),
                Visibility(
                  visible: selectedUerTagLIst1.length > 0,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: getTextView("Tags(${selectedUerTagLIst1.length})"),
                  ),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Tag people",
                            style: AppConstants
                                .txtStyle.heading18500LatoRegularLightPurple,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 17, top: 10),
                            child: Divider(
                              color: AppConstants.colorStyle.btnBg,
                              thickness: 1,
                              height: 0,
                            ),
                          ),
                        ],
                      ),
                    ),
                    isType == "Private"
                        ? const SizedBox.shrink()
                        : InkWell(
                            onTap: () {
                              onTapTagBtn();
                            },
                            child: Image.asset(
                              "assets/feed/tag_add.png",
                              height: 32.0,
                              width: 32.0,
                            ),
                          ),
                  ],
                ),
                const SizedBox(height: 14),
                Wrap(
                  runSpacing: 12,
                  spacing: 12,
                  children: List.generate(
                    selectedUerTagLIst1.length,
                    (index) {
                      final item = selectedUerTagLIst1[index];
                      return item.isSelected
                          ? Container(
                              decoration: BoxDecoration(
                                color: AppConstants.colorStyle.orangeShade,
                                borderRadius:
                                    const BorderRadius.all(Radius.circular(10)),
                              ),
                              padding: const EdgeInsets.fromLTRB(13, 9, 9, 10),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Flexible(
                                    child: Text(
                                      (item.firstName + " " + item.lastName)
                                          .trim(),
                                      overflow: TextOverflow.ellipsis,
                                      style: AppConstants.txtStyle
                                          .heading16500LatoRegularWhite,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  InkWell(
                                    child: Icon(
                                      Icons.clear,
                                      color: Colors.white,
                                      size: 18.0,
                                    ),
                                    onTap: () {
                                      setState(() {
                                        selectedUerTagLIst1.remove(item);
                                        selectedUerTagLIst.remove(item);
                                      });
                                    },
                                  )
                                ],
                              ),
                            )
                          : const SizedBox.shrink();
                    },
                  ),
                ),
                const SizedBox(height: 40),
                widget.groupId != ""
                    ? const SizedBox.shrink()
                    : Column(
                  mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          AppConstants.stringConstant.sharePostWith,
                          style:
                          AppConstants.txtStyle.heading14500LatoRegularLightPurple,
                        ),
                        isType == "Public"
                            ? InkWell(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                      child: Text(
                                        "Public",
                                        textAlign: TextAlign.start,
                                        style: AppConstants.txtStyle
                                            .heading18500LatoRegularDarkBlue,
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: Image.asset(
                                        "assets/feed/down_arrow.png",
                                        height: 24.0,
                                        width: 24.0,
                                      ),
                                      flex: 0,
                                    ),
                                  ],
                                ),
                                onTap: () {
                                  showWhoCanSeeYourPostPopup();
                                })
                            : isType == "Private"
                                ? InkWell(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            "Private",
                                            textAlign: TextAlign.start,
                                            style: AppConstants.txtStyle
                                                .heading18500LatoRegularDarkBlue,
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: Image.asset(
                                            "assets/feed/down_arrow.png",
                                            height: 24.0,
                                            width: 24.0,
                                          ),
                                          flex: 0,
                                        ),
                                      ],
                                    ),
                                    onTap: () {
                                      showWhoCanSeeYourPostPopup();
                                    })
                                : isType == "AllConnections"
                                    ? InkWell(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Expanded(
                                              child: Text(
                                                "Connections",
                                                textAlign: TextAlign.start,
                                                style: AppConstants.txtStyle
                                                    .heading18500LatoRegularDarkBlue,
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Image.asset(
                                                "assets/feed/down_arrow.png",
                                                height: 24.0,
                                                width: 24.0,
                                              ),
                                              flex: 0,
                                            ),
                                          ],
                                        ),
                                        onTap: () {
                                          showWhoCanSeeYourPostPopup();
                                        })
                                    : isType == "Community"
                                        ? InkWell(
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: <Widget>[
                                                Expanded(
                                                  child: Text(
                                                    "Community",
                                                    textAlign: TextAlign.start,
                                                    style: AppConstants.txtStyle
                                                        .heading18500LatoRegularDarkBlue,
                                                  ),
                                                  flex: 1,
                                                ),
                                                Expanded(
                                                  child: Image.asset(
                                                    "assets/feed/down_arrow.png",
                                                    height: 24.0,
                                                    width: 24.0,
                                                  ),
                                                  flex: 0,
                                                ),
                                              ],
                                            ),
                                            onTap: () {
                                              showWhoCanSeeYourPostPopup();
                                            })
                                        : isType == "Group"
                                            ? InkWell(
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Text(
                                                        "Group",
                                                        textAlign: TextAlign.start,
                                                        style: AppConstants.txtStyle
                                                            .heading18500LatoRegularDarkBlue,
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                      child: Image.asset(
                                                        "assets/feed/down_arrow.png",
                                                        height: 24.0,
                                                        width: 24.0,
                                                      ),
                                                      flex: 0,
                                                    ),
                                                  ],
                                                ),
                                                onTap: () {
                                                  showWhoCanSeeYourPostPopup();
                                                })
                                            : InkWell(
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Text(
                                                        "Selected Connections",
                                                        textAlign: TextAlign.start,
                                                        style: AppConstants.txtStyle
                                                            .heading18500LatoRegularDarkBlue,
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                      child: Image.asset(
                                                        "assets/feed/down_arrow.png",
                                                        height: 24.0,
                                                        width: 24.0,
                                                      ),
                                                      flex: 0,
                                                    ),
                                                  ],
                                                ),
                                                onTap: () {
                                                  showWhoCanSeeYourPostPopup();
                                                }),
                        Divider(
                          color: AppConstants.colorStyle.btnBg,
                          thickness: 1,
                          height: 20,
                        ),
                      ],
                    ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
