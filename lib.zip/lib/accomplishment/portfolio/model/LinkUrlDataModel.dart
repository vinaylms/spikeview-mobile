import 'package:flutter/material.dart';
class LinkUrlDataModel {

  TextEditingController
  labelController=new TextEditingController(text: ""),
      urlController=new TextEditingController(text: ""),
 descController=new TextEditingController(text: "");

  LinkUrlDataModel(
      this.labelController, this.urlController, this.descController);

  Map<String, dynamic> toJson() => {
    "label": this.labelController.text==null?"":this.labelController.text,
    "url": this.urlController.text==null?"":this.urlController.text,
    "description": this.descController.text==null?"":this.descController.text,

  };

}