import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';

class ButtonView extends StatelessWidget {
  final String btnName;
  final VoidCallback onButtonTap;
  final Color borderColor;
  final Color bgColor;
  final Color txtColor;
  const ButtonView({
    @required this.btnName,
    this.onButtonTap,
    this.borderColor,
    this.bgColor,
    this.txtColor,
  });

  @override
  Widget build(BuildContext context) {
    return  InkWell(
      onTap: (){
        if (onButtonTap != null) {
          onButtonTap();
        }
      },
        child:Container(
        height: 26.0,

        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(
              color: borderColor??AppConstants.colorStyle.borderColorBTN,
              width: 1),
          color:bgColor??Colors.white,
          borderRadius:
          BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.center,
          mainAxisAlignment:
          MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.fromLTRB(
                  8.0, 0.0, 8.0, 2.0),
              child: BaseText(
                text: '$btnName',
                textColor: txtColor??AppConstants
                    .colorStyle.lightGreyShade1,
                fontFamily: AppConstants
                    .stringConstant.latoRegular,
                fontWeight: FontWeight.w400,
                fontSize: 14,
                textAlign: TextAlign.start,
                maxLines: 3,
              ),
            ),
          ],
        )));
  }
}
