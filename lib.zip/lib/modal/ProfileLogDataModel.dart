import 'dart:io';

class ProfileLogDataModel {
  String status;
  List<Result> result;

  ProfileLogDataModel({this.status, this.result});

  ProfileLogDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<Result>();
      json['result'].forEach((v) {
        result.add(new Result.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Result {
  String sId;
  int userId;
  int createdAt;
  String expirationDate;
  String customProfileLink;
  bool isActive;
  bool isProfileLinkExpire;

  /*{
    isActive: true,
  isProfileLinkExpire: true,
  _id: 61fa6eae1168d4731a49c7dc,
  profileId: 5246,
  userId: 82,
  createdAt: 1643802286898,
  linkExpirationDate: 10,
  customProfileLink: https://app.spikeview.com/cus/Preso/NTI0Ng==,
  expirationDate: 1644666286898
  }*/

  Result(
      {this.sId,
        this.userId,
        this.createdAt,
        this.expirationDate,
        this.customProfileLink,
        this.isActive,
        this.isProfileLinkExpire
      });

  Result.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    userId = json['userId'];
    createdAt = json['createdAt'];
    expirationDate = json['expirationDate'].toString();
    customProfileLink = json['customProfileLink'];
    isActive = json['isActive'];
    isProfileLinkExpire = json['isProfileLinkExpire'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['userId'] = this.userId;
    data['createdAt'] = this.createdAt;
    data['expirationDate'] = this.expirationDate;
    data['customProfileLink'] = this.customProfileLink;
    data['isActive'] = this.isActive;
    data['isProfileLinkExpire'] = this.isProfileLinkExpire;
    return data;
  }
}