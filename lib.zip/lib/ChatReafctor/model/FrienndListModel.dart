

class FrienndListModel {
  String status;


  List<Friends> friendsList;

  FrienndListModel({this.status, this.friendsList});

  FrienndListModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      friendsList =  List<Friends>();
      json['result'].forEach((v) {
        friendsList.add(new Friends.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.friendsList != null) {
      data['result'] = this.friendsList.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Friends {
  int connectId;
  int userId;
  String firstName;
  String lastName;
  String profilePicture;
  int partnerId;
  String partnerFirstName;
  String partnerLastName;
  int partnerRoleId;
  String partnerProfilePicture;
  int dateTime;
  int creationTime;
  bool isActive;
  int online;
  String lastMessage;
  int unreadMessages;
  int lastTime;
  int lastSeen;
  int textSentBy;
  bool isTyping = false;
  String badge;
  String badgeImage;
  int gamificationPoints;

  Friends(
      {this.connectId,
        this.userId,
        this.firstName,
        this.lastName,
        this.profilePicture,
        this.partnerId,
        this.partnerFirstName,
        this.partnerLastName,
        this.partnerRoleId,
        this.partnerProfilePicture,
        this.dateTime,
        this.creationTime,
        this.isActive,
        this.online,
        this.lastMessage,
        this.unreadMessages,
        this.lastTime,
        this.lastSeen,
        this.textSentBy,
        this.badge,
        this.badgeImage,
        this.gamificationPoints

      });

  Friends.fromJson(Map<String, dynamic> json) {
    connectId = json['connectId'];
    userId = json['userId'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    profilePicture = json['profilePicture'];
    partnerId = json['partnerId'];
    partnerFirstName = json['partnerFirstName'];
    partnerLastName = json['partnerLastName'];
    partnerRoleId = json['partnerRoleId'];
    partnerProfilePicture = json['partnerProfilePicture'];
    dateTime = json['dateTime'];
    creationTime = json['creationTime'];
    isActive = json['isActive'];
    online = json['online'];
    lastMessage = json['partnerId'] == 1 || json['userId'] == 1
        ? json['lastMessage'] == "" ||
        json['lastMessage'] == null ||
        json['lastMessage'] == "null"
        ? "Welcome to spikeview! Look around, invite your friends and let us know how we can help."
        : json['lastMessage']
        : json['lastMessage'];
    unreadMessages = json['unreadMessages'];
    lastTime = json['lastTime'] == null||json['lastTime'] == "" ? 0 : json['lastTime'];
    lastSeen = json['lastSeen'] == null||json['lastSeen'] == "" ? 0 : json['lastSeen'];
    textSentBy = json['partnerId'] == 1 || json['userId'] == 1
        ? json['lastMessage'] == "" ||
        json['lastMessage'] == null ||
        json['lastMessage'] == "null"
        ? 1
        : json['textSentBy']
        : json['textSentBy'];
    badge = json['badge'];
    gamificationPoints = json['gamificationPoints'];
    badgeImage = json['badgeImage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['connectId'] = this.connectId;
    data['userId'] = this.userId;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['profilePicture'] = this.profilePicture;
    data['partnerId'] = this.partnerId;
    data['partnerFirstName'] = this.partnerFirstName;
    data['partnerLastName'] = this.partnerLastName;
    data['partnerRoleId'] = this.partnerRoleId;
    data['partnerProfilePicture'] = this.partnerProfilePicture;
    data['dateTime'] = this.dateTime;
    data['creationTime'] = this.creationTime;
    data['isActive'] = this.isActive;
    data['online'] = this.online;
    data['lastMessage'] = this.lastMessage;
    data['unreadMessages'] = this.unreadMessages;
    data['lastTime'] = this.lastTime;
    data['lastSeen'] = this.lastSeen;
    data['textSentBy'] = this.textSentBy;
    data['badge'] = this.badge;
    data['gamificationPoints'] = this.gamificationPoints;
    data['badgeImage'] = this.badgeImage;
    return data;
  }

}

