import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';

class NotificationModel {
  String notificationId,userId,actedBy,actedRoleId,postId,
      profilePicture,text,dateTime,isRead,textName,textMessage,roleId,type,values;
  String actionValue,requestId;
  String appModule,linkType,buttonText,buttonUrl,reqActionStatus, requestType;


  NotificationModel(this.notificationId, this.userId, this.actedBy,  this.actedRoleId,this.postId,
      this.profilePicture, this.text, this.dateTime, this.isRead,this.textName,this.textMessage,
      this.roleId,this.type,this.values,this.actionValue,

      this. appModule,this.linkType,this.buttonText,this.buttonUrl,this.reqActionStatus,this.requestType,this.requestId
      );

}

