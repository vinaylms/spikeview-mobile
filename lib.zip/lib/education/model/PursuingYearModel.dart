class PursuingYearModel {
  String status;
  List<CollegePursuingResult> result;

  PursuingYearModel({this.status, this.result});

  PursuingYearModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<CollegePursuingResult>();
      json['result'].forEach((v) {
        result.add(new CollegePursuingResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CollegePursuingResult {
  int id;
  String name;

  CollegePursuingResult({this.id, this.name});

  CollegePursuingResult.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}
