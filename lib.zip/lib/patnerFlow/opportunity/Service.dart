import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/age_between.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';

class Service {
  String title;
  String cities = "City";
  String gender = "Male";
  List<AgeBetween> ageBetween;
  List<Address> location;
  List<IntrestModel> interests;

  Service(this.title, this.cities, this.gender, this.ageBetween, this.location,
      this.interests);

  /* Service(
      {this.title,
        this.location,
        this.cities,
        this.gender,
        this.ageBetween,
        this.interests});*/



  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['title'] = this.title;
    data['location'] = this.location;
    data['cities'] = this.cities;
    data['gender'] = this.gender;
    String gender1=this.gender;
    if(gender1=="Non-binary"||gender1=="NonBinary"){
      data['gender'] ="Non-Binary";
    }
    if (this.ageBetween != null) {
      data['age'] = this.ageBetween.map((v) => v.toJson()).toList();
    }
    data['interests'] = this.interests;
    return data;
  }


  static List<String> getInterests() {
    return ["Interest1", "Interest2", "Interest3"];
  }
}
