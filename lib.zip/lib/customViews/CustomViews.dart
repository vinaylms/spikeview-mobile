import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/drawer/OpportunitySearch.dart';
import 'package:spike_view_project/drawer/SearchFriend_NewDesign.dart';
import 'package:spike_view_project/notification/NotificationWidget.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class CustomViews {
  static Padding getSepratorLine() {
    return Padding(
        padding: EdgeInsets.fromLTRB(0.0, 1.0, 0.0, 0.0),
        child: Container(
          height: 0.5,
          color: ColorValues.BORDER_COLOR,
        ));
  }

  static Padding getSeparatorLineNewUI(
      {double leftPadding = 0.0,
      topPadding = 1.0,
      rightPadding = 0.0,
      bottomPadding = 0.0}) {
    return Padding(
        padding: EdgeInsets.fromLTRB(
            leftPadding, topPadding, rightPadding, bottomPadding),
        child: Container(
          height: 1,
          color: ColorValues.BORDER_COLOR_NEW,
        ));
  }

  static Padding getSepratorLineNew() {
    return Padding(
        padding: EdgeInsets.fromLTRB(20.0, 1.0, 20.0, 0.0),
        child: Container(
          transform: Matrix4.translationValues(0.0, -23.0, 0.0),
          height: 1,
          color: ColorValues.BORDER_COLOR_NEW,
        ));
  }

  static Widget getBackButton() {
    return Image.asset(
      "assets/new_onboarding/back_blue_icon.png",
      height: 32,
      width: 32,
      fit: BoxFit.fill,
    );
  }

  static Widget getMoreButton() {
    return Center(
      child: Image.asset(
        "assets/newDesignIcon/icon/more_icon.png",
        height: 32.0,
        width: 32.0,
        fit: BoxFit.fill,
      ),
    );
  }

  static onTapSearch(context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    if (prefs.getBool("isParent") != null && prefs.getBool("isParent")) {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => SearchFriendNewDesign()));
    } else {
      if (prefs.getString(UserPreference.ISACTIVE) == "true") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => SearchFriendNewDesign()));
      } else {
        ToastWrap.showToast(
            MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
            context);
      }
    }
  }

  static AppBar getAppBar(String title, GlobalKey<ScaffoldState> _scaffoldKey,
      context, prefs, notificationCount) {
    return AppBar(
      backgroundColor: Colors.white,
      brightness: Brightness.light,
      automaticallyImplyLeading: false,
      elevation: 0.0,
      titleSpacing: 0,
      leading: Padding(
        padding: const EdgeInsets.only(left: 18),
        child: Center(
          child: InkWell(
            child: Image.asset(
              "assets/newDesignIcon/navigation_icon.png",
              height: 32.0,
              width: 32.0,
            ),
            onTap: () {
              _scaffoldKey.currentState.openDrawer();
            },
          ),
        ),
      ),
      title: PaddingWrap.paddingfromLTRB(
          15.0,
          12.0,
          0.0,
          10.0,
          Align(
            alignment: Alignment.center,
            child: Text(
              title,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                  fontSize: 18.0),
            ),
          )),
      actions: <Widget>[
        PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            12.0,
            0.0,
            InkWell(
              child: Image.asset(
                "assets/newDesignIcon/search_icon.png",
                width: 32.0,
                height: 32.0,
              ),
              onTap: () {
                onTapSearch(context);
              },
            )),
        PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            12.0,
            0.0,
            HelpButtonWidget()),
        // PaddingWrap.paddingfromLTRB(
        //     0.0,
        //     0.0,
        //     12.0,
        //     0.0,
        //     InkWell(
        //       child: Image.asset(
        //         "assets/newDesignIcon/help_icon.png", //opp_briefcase_black
        //         width: 32.0,
        //         height: 32.0,
        //       ),
        //       onTap: () {
        //         if (prefs.getString(UserPreference.ISACTIVE) == "true" ||
        //             prefs.getString(UserPreference.ROLE_ID) == "2" ||
        //             prefs.getString(UserPreference.ROLE_ID) == "4") {
        //      /*     Navigator.of(context).push(new MaterialPageRoute(
        //               builder: (BuildContext context) =>
        //                   OpportunitySearch("")));*/
        //         } else {
        //           ToastWrap.showToast(
        //               MessageConstant
        //                   .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
        //               context);
        //         }
        //       },
        //     )),
        PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            20.0,
            0.0,
            notificationCount == 0
                ? InkWell(
                    child: Image.asset(
                      "assets/newDesignIcon/notification_icon.png",
                      width: 32.0,
                      height: 32.0,
                    ),
                    onTap: () {
                      String isActive;
                      try {
                        isActive = prefs.getString(UserPreference.ISACTIVE);
                      } catch (e) {
                        isActive = "true";
                      }

                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              NotificationWidget(isActive: isActive)));
                    },
                  )
                : InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        13.0,
                        0.0,
                        0.0,
                        Stack(
                          children: <Widget>[
                            Image.asset(
                              "assets/newDesignIcon/notification_icon.png",
                              width: 32.0,
                              height: 32.0,
                            ),
                            Positioned(
                              top: 4.0,
                              right: 4.0,
                              child: Container(
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    boxShadow: [
                                      BoxShadow(


                                        color: Color.fromRGBO(255, 0, 0, 0.65),
                                      )
                                    ]
                                ),
                                height: 8.0,
                                width: 8.0,),
                            )
                          ],
                        )),
                    onTap: () {
                      String isActive;
                      try {
                        isActive = prefs.getString(UserPreference.ISACTIVE);
                      } catch (e) {
                        isActive = "true";
                      }
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              NotificationWidget(isActive: isActive)));
                    },
                  ))
      ],
      // bottom:  PreferredSize(child: CustomViews.getSepratorLine()),
    );
  }
}
