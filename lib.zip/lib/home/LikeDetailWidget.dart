import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class LikeDetailWidget extends StatefulWidget {
  List<Likes> likesList;
  String userId;

  LikeDetailWidget(this.likesList, this.userId);

  @override
  LikeDetailWidgetState createState() {
    return  LikeDetailWidgetState(likesList, userId);
  }
}

class LikeDetailWidgetState extends State<LikeDetailWidget> {
  List<Likes> likesList;
  SharedPreferences prefs;
  BuildContext context;
  String userIdPref, userProfilePath;
  String userId;

  LikeDetailWidgetState(this.likesList, this.userId);

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);

    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);


  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above


    onTapImageTile(tapedUserId,roleId) {
      if (tapedUserId == userIdPref) {

      }   else {
        Util.onTapImageTile(
            tapedUserRole:roleId
            , partnerUserId: tapedUserId,
            context: context
        );
      }
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.GRAY_BG,
            appBar:  AppBar(
              elevation: 0.0,
              automaticallyImplyLeading: false,
              titleSpacing: 2.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  )
                ],
              ),
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Likes ",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              actions: <Widget>[
                 Container(
                  width: 45.0,
                ),
              ],
              backgroundColor: Colors.white,
            ),
            body:  Column(
              children: <Widget>[
                // ignore: use_of_void_result
                CustomViews.getSepratorLine(),
                 Expanded(
                  child:  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 15.0, 0.0, 0.0),
                      child:  ListView.builder(
                          itemCount: likesList.length,
                          itemBuilder: (BuildContext context, int position) {
                            return  InkWell(
                              child:  Padding(
                                  padding:  EdgeInsets.fromLTRB(0.0,15.0,0.0,0.0),
                                  child:  Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                    MainAxisAlignment.center,
                                    children: <Widget>[
                                       Expanded(
                                        child: PaddingWrap.paddingfromLTRB(
                                          13.0,0.0,10.0,0.0,
                                           InkWell(
                                            child:  Container(
                                              height: 50.0,
                                              width: 50.0,
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(100),
                                                child: FadeInImage(
                                                  fit: BoxFit.cover,
                                                  placeholder: AssetImage(
                                                    likesList[position].roleId == "4"? "assets/profile/partner_img.png":  'assets/profile/user_on_user.png',
                                                  ),
                                                  image: NetworkImage(Constant
                                                          .IMAGE_PATH_SMALL +
                                                      ParseJson.getSmallImage(
                                                          likesList[position]
                                                              .profilePicture)),
                                                ),
                                              ),
                                            ),
                                            onTap: () {
                                              onTapImageTile(
                                                  likesList[position].userId,likesList[position].roleId);
                                            },
                                          ),
                                        ),
                                        flex: 0,
                                      ),
                                       Expanded(
                                          child:  Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                              Row(
                                                children: <Widget>[
                                                  TextViewWrap.textView(
                                                      likesList[position].name,
                                                      TextAlign.center,
                                                        ColorValues.HEADING_COLOR_EDUCATION,
                                                      14.0,
                                                      FontWeight.bold),
                                                  likesList[position] != null && likesList[position].roleId == "1"
                                                  //true
                                                      ? Util.getStudentBadge12(likesList[position].badge,likesList[position].badgeImage):Container(),


                                                ],
                                              ),
                                              likesList[position]
                                                  .title ==
                                                  "null"||likesList[position]
                                                  .title ==""
                                                  ?  Container(height: 0.0,):
                                                  TextViewWrap.textView(
                                                      likesList[position]
                                                                  .title ==
                                                              "null"
                                                          ? ""
                                                          : likesList[position]
                                                              .title,
                                                      TextAlign.start,
                                                       ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal),

                                            ],
                                          ),
                                          flex: 1),
                                      likesList[position].userId != userId
                                          ?  Expanded(
                                              child: Column(
                                                children: <Widget>[
                                                   InkWell(
                                                    child:  Padding(
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                0.0,
                                                                11.0,
                                                                0.0),
                                                        child:  Container(
                                                            height:  likesList[position].status == Constant.ACCEPTED?20.0:30.0,
                                                            width: likesList[position]
                                                                .status ==
                                                                Constant
                                                                    .ACCEPTED?20.0:30.0,
                                                            child: Image.asset(
                                                              likesList[position]
                                                                          .status ==
                                                                      Constant
                                                                          .ACCEPTED
                                                                  ? 'assets/newDesignIcon/connections/connected_right.png'
                                                                  : 'assets/newDesignIcon/connections/send_repquest_gray.png',
                                                            ))),
                                                    onTap: () {},
                                                  ),
                                                   Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              0.0,
                                                              2.0,
                                                              13.0,
                                                              0.0),
                                                      child:  Text(
                                                        likesList[position]
                                                                    .statusValue ==
                                                                "null"
                                                            ? ""
                                                            :likesList[position]
                                                            .statusValue,
                                                        style: TextStyle(
                                                            fontFamily: Constant
                                                                .customRegular,
                                                            color:  ColorValues.GREY_TEXT_COLOR,
                                                            fontSize: 10.0),
                                                      ))
                                                ],
                                              ),
                                              flex: 0,
                                            )
                                          :  Container(
                                              width: 0.0,
                                            ),
                                    ],
                                  )),
                              onTap: () {
                                if (likesList[position].userId == userIdPref) {
                                } else {


                                    Util.onTapImageTile(
                                        tapedUserRole:likesList[position].roleId
                                        , partnerUserId: likesList[position].userId,
                                        context: context
                                    );
                                  }


                              },
                            );
                          })),
                  flex: 1,
                )
              ],
            )));
  }
}
