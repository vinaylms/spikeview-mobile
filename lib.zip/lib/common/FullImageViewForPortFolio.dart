import 'dart:io';
import 'dart:typed_data';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:thumbnails/thumbnails.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';

class FullImageViewForPortFolio extends StatefulWidget {
  List<FileDataModel> fileDataList;

  FullImageViewForPortFolio(this.fileDataList);

  @override
  State createState() {
    return  FullImageViewForPortFolioState(fileDataList);
  }
}

class FullImageViewForPortFolioState extends State<FullImageViewForPortFolio> {
  // ChewieController _chewieController;
  List<FileDataModel> fileDataList;

  FullImageViewForPortFolioState(this.fileDataList);

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Widget _loader1(BuildContext context, String placeHolderImage) => Center(
            child: Container(
          child:  CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation(Colors.white),
          ),
        ));

    Widget _error1(String placeHolderImage) {
      return SizedBox(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Center(
          child: Image.asset(
            placeHolderImage,
            fit: BoxFit.cover,
          ),
        ),
      );
    }

    return  Scaffold(
        appBar:  AppBar(
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          elevation: 0.0,
          actions: [
             InkWell(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child:  Image.asset(
                  "assets/story_new/black_circle.png",
                  height: 25.0,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
              },
            )
          ],
          backgroundColor:  Color(0xff101621),
        ),
        backgroundColor:  Color(0xff101621),
        body:  CarouselSlider.builder(
          //physics: NeverScrollableScrollPhysics(),
          //scrollDirection: Axis.horizontal,
          //shrinkWrap: true,
          //controller: _controller,
          itemCount: fileDataList.length,
          options: CarouselOptions(
            height: double.infinity,
            //width: MediaQuery.of(context).size.width,
            //aspectRatio: 16/9,
            viewportFraction: 1.0,
            enableInfiniteScroll: false,
            reverse: false,
            autoPlay: false,
            //autoPlayInterval: Duration(seconds: 3),
            //autoPlayAnimationDuration: Duration(milliseconds: 800),
            //autoPlayCurve: Curves.fastOutSlowIn,
            //enlargeCenterPage: true,
            //onPageChanged: callbackFunction,
            scrollDirection: Axis.horizontal,
          ),
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 0.0),
              child: Padding(
                padding: const EdgeInsets.only(right: 0.0),
                //pagerList.length != index+1 ?  const EdgeInsets.only(right: 24.0): const EdgeInsets.only(right: 0.0),
                child: ListView(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[



                        fileDataList[index].type == 'image'
                            ? Center(
                                child:  CachedNetworkImage(
                                imageUrl:
                                    '${Constant.IMAGE_PATH}${fileDataList[index].filePath}',
                                fit: BoxFit.contain,
                                placeholder: (context, url) => _loader1(
                                    context, "assets/aerial/default_img.png"),
                                errorWidget: (context, url, error) =>
                                    _error1("assets/aerial/default_img.png"),
                              ))
                            : Center(
                                child:  Container(
                                  color: Colors.black,

                                child:  Center(
                                  child:  VideoPlayPause(
                                      fileDataList[index].filePath,
                                      "FromMediaDetailPage",
                                      true),
                                ),
                              )),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ));
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child:  Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }
}
