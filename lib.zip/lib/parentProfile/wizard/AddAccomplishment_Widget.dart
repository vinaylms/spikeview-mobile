import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/theme/palette.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfile.dart';
import 'package:spike_view_project/parentProfile/wizard/AllAccomplishmentListWidget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parentProfile/wizard/CompletedWizard.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:path/path.dart' as path;

// Create a Form Widget
class AddAcomplishmentForm extends StatefulWidget {
  List<Level3Competencies> level3Competencylist;
  String strCompetencyTypeId, strcompetencyTypeName;
  String sasToken;
  String level1Name;
  StudentDataModel studModel;
  String pageName;

  AddAcomplishmentForm(
      this.level1Name,
      this.level3Competencylist,
      this.strCompetencyTypeId,
      this.strcompetencyTypeName,
      this.sasToken,
      this.studModel,
      this.pageName);

  @override
  AddAchievmentFormStateNEW createState() {
    return  AddAchievmentFormStateNEW(level3Competencylist, studModel);
  }
}

class AddAchievmentFormStateNEW extends State<AddAcomplishmentForm> {
  static StreamController syncDoneController = StreamController.broadcast();

  List<FileModel> mediaVideosList =  List();

  UploadMedia uploadMedia;

  List<String> mediaAndVideoList =  List();

  bool isPredefinedMediaSelected = true;

  AddAchievmentFormStateNEW(this.level3Competencylist, this.studModel);

  final _formKey = GlobalKey<FormState>();
  StudentDataModel studModel;
  String strAchievement = "",
      strFromDate = "",
      strToDate = "",
      strName = "",
      strEmail = "",
      strTitle = "",
      strCoachLastName = "",
      strCoachFirstName = "",
      strRecommendationTitle = "",
      strRecommenderTitle = "",
      strCoachEmail = "",
      strDeascription = "";
  TextEditingController fromDateController, toDateController;
  List<AchievementImportanceModal> levelList =  List();
  List<AcvhievmentSkillModel> skillList =  List();
  List<Skill> skillsSelectedList =  List();
  List<Level3Competencies> level3Competencylist;
  SharedPreferences prefs;
  Level3Competencies competencySelected;
  String userIdPref,
      token,
      strCompetencyValue = "",
      strLevelValue = "",
      filterData = "",
      appliedFilter = "";
  Map<int, bool> filterStatus =  Map();
  File imagePath;
  AchievementImportanceModal levelSelected;
  String selectedImageType = "media",
      strPrefixPathforPhoto,
      strAzureImageUploadPath = "";
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<Assest> assestList =  List();
  bool isPresent = false;
  List<String> mediaList =  List();
  List<String> certificateList =  List();

  //List<String> badgeList =  List();
  // List<String> trophyList =  List();
  List<Assest> badgeAndTrophyList =  List();

  BuildContext context;
  DateTime fromDate, toDate;
  bool isMedaiDialog = false;
  bool isShowMedia = false;
  bool isPrompt = false;
  ScrollController _controller = ScrollController();
  Map<String, List<Level3Competencies>> competencyList =  Map();
  FocusNode _focus =  FocusNode();
  DateTime startDate;

//  static StreamController syncDoneController = StreamController.broadcast();

  Future apiCallWizardCompleted() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_COMPLETED_WIZARD +
              prefs.getString(UserPreference.PARENT_WIZARD_USERID),
          "get",
        );
        print("wizardapi" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            studModel.isWizardCompleted = "true";
            Navigator.of(context).popUntil((route) => route.isFirst);
            syncDoneController.add("suceess");
            /*         Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) =>  CompletedWizard()));*/
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------Recommendation Info api ------------------

  Future apiCallMaster() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_MASTER_DATA, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              skillList.clear();
              competencyList.clear();
              prefs.setString(
                  "skill", json.encode(response.data['result']['skills']));
              prefs.setString(
                  "level", json.encode(response.data['result']['importance']));

              prefs.setString("competencies",
                  json.encode(response.data['result']['competencies']));

              levelList = ParseJson.parseMapLevelList(
                  response.data['result']['importance']);
              skillList = ParseJson.parseMapSkillList(
                  response.data['result']['skills']);

              competencyList = ParseJson.parseMapMasterCompetency(
                  response.data['result']['competencies']);

              if (competencyList.length > 0) {
                level3Competencylist.clear();
                setState(() {
                  competencyList;

                  level3Competencylist =
                      competencyList[widget.strcompetencyTypeName];
                });
              }

              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }

              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallLevelList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_LEVEL_LIST, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              prefs.setString("level", json.encode(response.data['result']));
              levelList = ParseJson.parseMapLevelList(response.data['result']);
              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (widget.sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": widget.sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  //--------------------------Api Call for skills ------------------
  Future apiCallSkill() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_SKILLS, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              skillList.clear();
              prefs.setString("skill", json.encode(response.data['result']));
              skillList = ParseJson.parseMapSkillList(response.data['result']);
              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------Upload Acchievment Data ------------------

  bool validationCheck() {
    if (strCompetencyValue == "") {
      ToastWrap.showToast(MessageConstant.SELECT_COMPETENCY_VAL, context);
      return false;
    } else  if (appliedFilter == "") {
      return false;
    } else  if (strLevelValue == "") {
      return false;
    } if (strFromDate == "") {
      ToastWrap.showToast(MessageConstant.SELECT_FROM_DATE_VAL, context);
      return false;
    } else if (strToDate == "" && (!isPresent)) {
      ToastWrap.showToast(MessageConstant.SELECT_TO_DATE_VAL, context);
      return false;
    }
    /*else if(strCoachFirstName==""&&strCoachEmail!=""){
      ToastWrap.showToast("Please enter correct coach first name");
      return false;
    }else if(strCoachFirstName!=""&&strCoachEmail==""){
      ToastWrap.showToast("Please enter correct coach email");
      return false;
    }*/
    return true;
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        mediaList.removeLast();
        //  badgeList.removeLast();
        certificateList.removeLast();
        badgeAndTrophyList.removeLast();
        mediaVideosList.removeLast();
        assestList.clear();
        for (var file in mediaList) {
          assestList.add(new Assest("image", "media", file, "",false));
        }
        for (FileModel item in mediaVideosList) {
          assestList.add(new Assest("video", "media", item.path,"", false));
        }

        for (var file in certificateList) {
          assestList.add(new Assest("image", "certificates", file,"", false));
        }

        for (var file in badgeAndTrophyList) {
          assestList.add(new Assest("image", file.tag, file.file,"", false));
        }

        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {
          "achievementId": "",
          "competencyTypeId": widget.strCompetencyTypeId,
          "level2Competency": widget.strcompetencyTypeName,
          "level3Competency": strCompetencyValue,
          "userId": prefs.getString(UserPreference.PARENT_WIZARD_USERID),
          "parentId": prefs.getString(UserPreference.PARENT_ID),
          "badge": [],
          "certificate": [],
          "asset": assestList.map((item) => item.toJson()).toList(),
          "skills": skillsSelectedList.map((item) => item.toJson()).toList(),
          "title": strTitle,
          "description": strDeascription,
          "fromDate": strFromDate,
          "toDate": strToDate,
          "importance": strLevelValue,
          "guide": {
            "promptRecommendation": isPrompt.toString(),
            "firstName": strCoachFirstName,
            "lastName": strCoachLastName,
            "email": strCoachEmail,
            "title": strRecommenderTitle,
            "recommenderTitle": strRecommendationTitle,
           // "title": strRecommendationTitle,
            //"recommenderTitle": strRecommenderTitle,
          },
          "stories": "",
          "isActive": "true"
        };

        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              ParentProfilePageState.isAchivmentAdded = "true";
              studModel.isAchievement = "true";
              setState(() {
                studModel.isAchievement;
              });
              // Navigate to List
              if (widget.pageName == "all") {
                Navigator.pop(context, "push");
                syncDoneController.add("secess");
              } else {
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                         AllAccomplishmentListWidget(studModel)));
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);

    // await apiCallLevelList();
    try {
      if (prefs.getString("competencies") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("competencies"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          competencyList.clear();
          competencyList = ParseJson.parseMapMasterCompetency(data);
          if (competencyList.length > 0) {
            level3Competencylist.clear();
            setState(() {
              competencyList;

              level3Competencylist =
                  competencyList[widget.strcompetencyTypeName];
            });
          }
        }
      }

      if (prefs.getString("level") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("level"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          levelList.clear();
          levelList = ParseJson.parseMapLevelList(data);
          if (levelList.length > 0) {
            setState(() {
              levelList;
            });
          }
        }
      }

      if (prefs.getString("skill") == null) {
        await apiCallMaster();
      } else {
        final skill = json.decode(prefs.getString("skill"));
        if (skill == null || skill.length == 0) {
          await apiCallMaster();
        } else {
          skillList.clear();
          skillList = ParseJson.parseMapSkillList(skill);
          if (skillList.length > 0) {
            for (int i = 0; i < skillList.length; i++) {
              filterStatus[i] = false;
            }
            setState(() {
              filterStatus;
              skillList;
            });
          }
        }
      }

      if (level3Competencylist.length == 1) {
        competencySelected = level3Competencylist[0];
        strCompetencyValue = level3Competencylist[0].name;
        setState(() {
          competencySelected;
          strCompetencyValue;
        });
      }
    } catch (e) {
      e.toString();
    }
    //await apiCallSkill();
    // await callApiForSaas();

    mediaList.add("");
    mediaVideosList.add(null);
    certificateList.add("");

    // badgeList.addAll(achivmentModel.badgeList);
    // badgeList.add("");

    badgeAndTrophyList.add(new Assest("image", "badges", "","", false));

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
  }

  void _onFocusChange() {
    debugPrint("Focus: " + _focus.hasFocus.toString());
  }
  
bool addSkillsError = false;
  bool selectAchivmentLevel = false;
  @override
  void initState() {
    String date = studModel.dob;
    if (date != "" || date != null) {
      startDate =
           DateTime.fromMillisecondsSinceEpoch(int.parse(studModel.dob));
    } else {
      startDate =  DateTime.now();
    }
    getSharedPreferences();
    _focus.addListener(_onFocusChange);
    //assestList.add(new Assest("b", "fv", "fvf", false));
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    this.context = context;
    final dropdownMenuCompetency = level3Competencylist
        .map((Level3Competencies item) =>
             DropdownMenuItem<Level3Competencies>(
                value: item, child:  Text(item.name,style:  TextStyle(
                fontFamily:Constant.TYPE_CUSTOMREGULAR,
                color:  ColorValues.HEADING_COLOR_EDUCATION,
              ))))
        .toList();

    final dropdownMenuLevel = levelList
        .map((AchievementImportanceModal item) =>
             DropdownMenuItem<AchievementImportanceModal>(
                value: item, child:  Text(item.title,style:  TextStyle(
                fontFamily:Constant.TYPE_CUSTOMREGULAR,
                color:  ColorValues.HEADING_COLOR_EDUCATION,
              ))))
        .toList();

    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }

    //---------------------------------Skill Core Logic nd ui -----------------------
    void iterateFilters(key, value) {
      print('-------------$key:$value'); //string interpolation in action
      if (value) {
        if (key != 0) {
          if (filterData == "") {
            filterData = (key).toString();
            appliedFilter = skillList[key].title;

            skillsSelectedList.add(
                 Skill(skillList[key].title, skillList[key].skillId, key));
          } else {
            filterData = filterData + ", " + (key).toString();
            appliedFilter = appliedFilter + ",\n" + skillList[key].title;
            skillsSelectedList.add(
                 Skill(skillList[key].title, skillList[key].skillId, key));
          }
        }
      }
    }

    void onApplyClick() {
      filterData = "";
      appliedFilter = "";
      skillsSelectedList.clear();
      filterStatus.forEach(iterateFilters);
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());

        appliedFilter;
      });
      Navigator.pop(context);
    }

    void onCancelTap() {
      filterData = "";
      appliedFilter = "";
      skillsSelectedList.clear();
      for (int i = 0; i < filterStatus.length; i++) {
        filterStatus[i] = false;
      }
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());

        appliedFilter;
      });
      Navigator.pop(context);
    }

    /*   void getFilters2() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  AlertDialog(
              title:  Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Skills",
                    textAlign: TextAlign.center,
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                       Divider(
                        color: Colors.grey[300],
                      ))
                ],
              ),
              content:  Container(
                  width: 300.0,
                  child:  ListView.builder(
                      // itemCount: myData.lenght(),

                      shrinkWrap: true,
                      itemCount: skillList.length,
                      itemBuilder: (BuildContext context, int index) {
                        if ((skillList.length - 1) == index) {
                          return  Column(
                            children: <Widget>[
                               Padding(
                                  padding:  EdgeInsets.all(5.0),
                                  child:  Row(
                                    children: <Widget>[
                                       Expanded(
                                          child:
                                               Text(skillList[index].title),
                                          flex: 2),
                                       Expanded(
                                          child:  SizedBox(
                                              width: 20.0,
                                              height: 20.0,
                                              child:  Checkbox(
                                                value: filterStatus[index],
                                                onChanged: (bool value) {
                                                  setState(() {
                                                    if (index == 0) {
                                                      for (int i = 0;
                                                          i <
                                                              filterStatus
                                                                  .length;
                                                          i++) {
                                                        if (!value)
                                                          filterStatus[i] =
                                                              false;
                                                        else
                                                          filterStatus[i] =
                                                              true;
                                                      }
                                                    } else {
                                                      filterStatus[0] = false;
                                                      filterStatus[index] =
                                                          value;
                                                    }
                                                    FocusScope.of(context)
                                                        .requestFocus(
                                                             FocusNode());

                                                    Navigator.pop(context);
                                                    //  getFilters();
                                                  });
                                                },
                                              )),
                                          flex: 0),
                                    ],
                                  )),
                               Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                   Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        10.0,
                                        0.0,
                                         FlatButton(
                                            color:
                                                ColorValues.BLUE_COLOR,
                                            child:  Text(
                                              'DONE',
                                              style:  TextStyle(
                                                  fontSize: 16.0,
                                                  color: Colors.white),
                                            ),
                                            onPressed: onApplyClick)),
                                    flex: 1,
                                  ),
                                   Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                         FlatButton(
                                            color: Colors.black54,
                                            child:  Text(
                                              'CLOSE',
                                              style:  TextStyle(
                                                  fontSize: 16.0,
                                                  color: Colors.white),
                                            ),
                                            onPressed: onCancelTap)),
                                    flex: 1,
                                  ),
                                ],
                              )
                            ],
                          );
                        } else {
                          return  Padding(
                              padding:  EdgeInsets.all(5.0),
                              child:  Row(
                                children: <Widget>[
                                   Expanded(
                                      child:  Text(skillList[index].title),
                                      flex: 2),
                                   Expanded(
                                      child:  SizedBox(
                                          width: 20.0,
                                          height: 20.0,
                                          child:  Checkbox(
                                            value: filterStatus[index],
                                            onChanged: (bool value) {
                                              setState(() {
                                                if (index == 0) {
                                                  for (int i = 0;
                                                      i < filterStatus.length;
                                                      i++) {
                                                    if (!value)
                                                      filterStatus[i] = false;
                                                    else
                                                      filterStatus[i] = true;
                                                  }
                                                } else {
                                                  filterStatus[0] = false;
                                                  filterStatus[index] = value;
                                                }
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                         FocusNode());

                                                Navigator.pop(context);
                                                // getFilters();
                                              });
                                            },
                                          )),
                                      flex: 0),
                                ],
                              ));
                        }
                      }))));
    }
*/
    void getFilters() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  AlertDialog(
              title:  Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Skills",
                    textAlign: TextAlign.center,
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                       Divider(
                        color: Colors.grey[300],
                      ))
                ],
              ),
              content:  Container(
                  width: 300.0,
                  child:  ListView.builder(
                      // itemCount: myData.lenght(),
                      shrinkWrap: true,
                      itemCount: skillList.length,
                      itemBuilder: (BuildContext context, int index) {
                        if ((skillList.length - 1) == index) {
                          return  Column(
                            children: <Widget>[
                               InkWell(
                                child:  Padding(
                                    padding:  EdgeInsets.fromLTRB(
                                        0.0, 8.0, 0.0, 8.0),
                                    child:  Row(
                                      children: <Widget>[
                                        filterStatus[index]
                                            ?  Expanded(
                                                child:  Padding(
                                                    padding:
                                                         EdgeInsets.fromLTRB(
                                                            0.0, 5.0, 8.0, 5.0),
                                                    child:  Icon(
                                                      Icons.check,
                                                      color: Colors.blue,
                                                      size: 20.0,
                                                    )),
                                                flex: 0)
                                            :  Container(
                                                height: 0.0,
                                              ),
                                         Expanded(
                                            child:  Text(
                                          skillList[index].title,
                                          maxLines: 3,
                                          style:  TextStyle(fontSize: 15.0),
                                        )),
                                      ],
                                    )),
                                onTap: () {
                                  bool value = filterStatus[index];
                                  if (index == 0) {
                                    for (int i = 0;
                                        i < filterStatus.length;
                                        i++) {
                                      if (value)
                                        filterStatus[i] = false;
                                      else
                                        filterStatus[i] = true;
                                    }
                                  } else {
                                    filterStatus[0] = false;
                                    if (filterStatus[index]) {
                                      filterStatus[index] = false;
                                    } else {
                                      filterStatus[index] = true;
                                    }
                                  }
                                  Navigator.pop(context);
                                  getFilters();
                                },
                              ),
                               Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                   Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        10.0,
                                        0.0,
                                         FlatButton(
                                            color: Colors.black54,
                                            child:  Text(
                                              'CLOSE',
                                              style:  TextStyle(
                                                  fontSize: 16.0,
                                                  color: Colors.white),
                                            ),
                                            onPressed: onCancelTap)),
                                    flex: 1,
                                  ),
                                   Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                         FlatButton(
                                            color:
                                                ColorValues.BLUE_COLOR,
                                            child:  Text(
                                              'DONE',
                                              style:  TextStyle(
                                                  fontSize: 16.0,
                                                  color: Colors.white),
                                            ),
                                            onPressed: onApplyClick)),
                                    flex: 1,
                                  ),
                                ],
                              )
                            ],
                          );
                        } else {
                          return  InkWell(
                            child:  Padding(
                                padding:
                                     EdgeInsets.fromLTRB(0.0, 8.0, 0.0, 8.0),
                                child:  Row(
                                  children: <Widget>[
                                    filterStatus[index]
                                        ?  Expanded(
                                            child:  Padding(
                                                padding:
                                                     EdgeInsets.fromLTRB(
                                                        0.0, 5.0, 8.0, 5.0),
                                                child:  Icon(
                                                  Icons.check,
                                                  color: Colors.blue,
                                                  size: 20.0,
                                                )),
                                            flex: 0)
                                        :  Container(
                                            height: 0.0,
                                          ),
                                     Expanded(
                                        child:  Text(
                                      skillList[index].title,
                                      maxLines: 3,
                                      style:  TextStyle(fontSize: 15.0),
                                    )),
                                  ],
                                )),
                            onTap: () {
                              bool value = filterStatus[index];
                              if (index == 0) {
                                for (int i = 0; i < filterStatus.length; i++) {
                                  if (value)
                                    filterStatus[i] = false;
                                  else
                                    filterStatus[i] = true;
                                }
                              } else {
                                filterStatus[0] = false;
                                if (filterStatus[index]) {
                                  filterStatus[index] = false;
                                } else {
                                  filterStatus[index] = true;
                                }
                              }
                              Navigator.pop(context);
                              getFilters();
                            },
                          );
                        }
                      }))));
    }

    scrollTop() async {
      Timer _timer =  Timer(const Duration(milliseconds: 200), () async {
        _controller.jumpTo(_controller.position.minScrollExtent);
      });
    }

    scrollBottom() async {
      Timer _timer =  Timer(const Duration(milliseconds: 200), () async {
        _controller.jumpTo(_controller.position.maxScrollExtent);
      });
    }

    final skillUi =  Container(
        padding:  EdgeInsets.all(0.0),
        margin:  EdgeInsets.all(0.0),
        decoration:  BoxDecoration(
            border:  Border(bottom: BorderSide(color: Colors.grey[300]))),
        child:  InkWell(
          child:  TextFormField(
            enabled: false,
            maxLines: null,style:Util.errorTextStyle,
            controller:  TextEditingController(text: appliedFilter),
            keyboardType: TextInputType.text,
            decoration:  InputDecoration(
              filled: true,
              labelText: "Skills",errorStyle:Util.errorTextStyle,
              labelStyle:  TextStyle(color:  ColorValues.TEXT_LIGHT_GREY),
              hintStyle:  TextStyle(color: ColorValues.hintColor, fontSize: 15.0),
              fillColor: Colors.transparent,
              hintMaxLines: null,
              border: InputBorder.none,
            ),
          ),
          onTap: () {
            setState(() {
              setState(() {
                FocusScope.of(context).requestFocus(new FocusNode());
              });
            });
            getFilters();
          },
        ));
//======================================================================================
//--------------------------------Image Selectedview -------------------------
    Padding isImageSelectedView() {
      return PaddingWrap.paddingfromLTRB(
          15.0,
          25.0,
          15.0,
          20.0,
           Container(
              width: double.infinity,
              child:
                   Image.file(imagePath, fit: BoxFit.cover, height: 200.0)));
    }

    //---------------------Add media View and core logics  ---------------------
    ontapApply(type) async {
      if (imagePath != null) {
        strAzureImageUploadPath = await uploadImgOnAzure(
            imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            strPrefixPathforPhoto);
        setState(() {
          strAzureImageUploadPath;
        });
        CustomProgressLoader.cancelLoader(context);
        print("azureimagepath   :-" + strAzureImageUploadPath);
        if (strAzureImageUploadPath != "" &&
            strAzureImageUploadPath != "false") {
          assestList.add(new Assest("image", type,
              strPrefixPathforPhoto + strAzureImageUploadPath,"", false));

          print("assestList========   " + assestList.length.toString());
          if (type == "media") {
            mediaList.removeLast();

            mediaList.add(strPrefixPathforPhoto + strAzureImageUploadPath);
            mediaList.add("");
          } else if (type == "certificates") {
            certificateList.removeLast();

            certificateList
                .add(strPrefixPathforPhoto + strAzureImageUploadPath);
            certificateList.add("");
          } else if (type == "badges") {
            badgeAndTrophyList.removeLast();

            badgeAndTrophyList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath,"", false));
            badgeAndTrophyList.add(new Assest("image", type, "", "",false));
          } else if (type == "trophy") {
            badgeAndTrophyList.removeLast();

            badgeAndTrophyList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath, "",false));
            badgeAndTrophyList.add(new Assest("image", type, "","", false));
          }

          selectedImageType = "media";
          strAzureImageUploadPath = "";
          imagePath = null;
          setState(() {
            mediaList;
            isMedaiDialog = false;
            assestList;
            selectedImageType;
            strAzureImageUploadPath;
            imagePath;
          });
        }
      }
    }

    //------------------------Image Sewlection ---------------------------

    Future getImage(type) async {
      imagePath = await UploadMedia(context).pickImageFromGallery();

      //imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null) {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);
        print("imagepath shubh" + strPath);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          //await _cropImage(imagePath);
          if (imagePath != null) {
            /*setState(() {
            isMedaiDialog = true;
          });
          addMediaDialog();*/
            setState(() {
              imagePath;
            });

            CustomProgressLoader.showLoader(context);
            Timer _timer =  Timer(const Duration(milliseconds: 400), () {
              ontapApply(type);
            });
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    String getFileExtension2(File file) {
      return path.extension(file.path);
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      setState(() {});
      if (type == "video") {
        File file =
        await uploadMedia.compresssData(new File(imagePath), true, type);
        imagePath = file.path;
      } else if (type == "image") {
        File file = await uploadMedia.compressImage(new File(imagePath));
        imagePath = file.path;
      }
      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        if (type == "video") {
          mediaAndVideoList.add("");
          String path = Constant.IMAGE_PATH + strPrefixPathforPhoto + strAzureImageUploadPath;

          //final thumbnailFile = await uploadMedia.getVideoThumbnailFromUrl(path);
          final thumbnailFile = await uploadMedia.getVideoThumbnailFromUrl(imagePath);
          //final thumbnailFile = await uploadMedia.getVideoThumbnailFromFile(path);

          print('view thumbnailFile:: ${thumbnailFile}');
          mediaVideosList.removeLast();
          mediaVideosList.add(new FileModel(thumbnailFile, strPrefixPathforPhoto + strAzureImageUploadPath));
          mediaVideosList.add(null);
          setState(() {
            mediaVideosList;
          });

          /*if (isPredefinedMediaSelected) {
              isPredefinedMediaSelected = false;
              mediaList.removeLast();
            }
            mediaList.removeLast();
            mediaList.add(strPrefixPathforPhoto + strAzureImageUploadPath);
            mediaList.add("");
*/
        } else if (type == "image") {
          mediaAndVideoList.add("");
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        } else {
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        }

        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    onTapVideoAddButton() async {
      imagePath = await uploadMedia.pickVideoFromGallery();
      print('Apurva inside onTapVideoAddButton() imagePath:: imagePath');
      if (imagePath != null) {
        if (imagePath != null &&
            getFileExtension2(imagePath) != null &&
            getFileExtension2(imagePath).length > 0) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =  Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "video");

            //ontapApply("video");
          });
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    final competencyDropDownUi =  Container(
        height: 28.0,
        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration:  BoxDecoration(
            border:  Border(bottom: BorderSide(color: Colors.grey[300]))),
        width: double.infinity,
        child:  DropdownButtonHideUnderline(
            child:  DropdownButton<Level3Competencies>(
                hint:  Text(
                  "Competency",
                  style:  TextStyle(
                      fontSize: 16.0,
                      color:  ColorValues.GREY_TEXT_COLOR,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: competencySelected,
                items: dropdownMenuCompetency,
                onChanged: (Level3Competencies item) {
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    competencySelected = item;
                    strCompetencyValue = item.name;
                  });
                })));

    final competencyDropLevel =  Container(
        height: 28.0,
        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration:  BoxDecoration(
            border:  Border(bottom: BorderSide(color: Colors.grey[300]))),
        width: double.infinity,
        child:  DropdownButtonHideUnderline(
            child:  DropdownButton<AchievementImportanceModal>(
                hint:  Text(
                  "Achievement Level",
                  style:  TextStyle(
                      fontSize: 16.0,
                      color:  ColorValues.GREY_TEXT_COLOR,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: levelSelected,
                items: dropdownMenuLevel,
                onChanged: (AchievementImportanceModal level) {
                  setState(() {
                    selectAchivmentLevel= false;
                    FocusScope.of(context).requestFocus(new FocusNode());
                    levelSelected = level;
                    strLevelValue = level.importanceId;
                  });
                })));

    final titleUi =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          maxLength: 50,style:Util.errorTextStyle,
          focusNode: _focus,
          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          decoration:  InputDecoration(
            filled: true,
            labelText: "Title",errorStyle:Util.errorTextStyle,
            counterText: "",
            labelStyle:  TextStyle(color:  ColorValues.TEXT_LIGHT_GREY),
            fillColor: Colors.transparent,
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            enabledBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            /*  border: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(0.0)),
            gapPadding: 0.0,
            borderSide: BorderSide(
              color: Colors.grey[300],
            )),*/
          ),
          validator: (val) => val.trim().isEmpty ? 'Please enter title.' : null,
          onSaved: (val) => strTitle = val.trim(),
        ));

    final recommenderTitle =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            labelText: "Designation Title",errorStyle:Util.errorTextStyle,
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            enabledBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            fillColor: Colors.transparent,
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt ? MessageConstant.ENTER_TITLE_VAL : null
              : null,
          onSaved: (val) => strRecommenderTitle = val.trim(),
        ));

    final recommendationTitle =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          autofocus: true,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            enabledBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            labelText: "Recommendation Title",errorStyle:Util.errorTextStyle,
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt ? MessageConstant.ENTER_RECOMMENDATION_TITLE_VAL : null
              : null,
          onSaved: (val) => strRecommendationTitle = val.trim(),
        ));

    final coachFirstName =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            enabledBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            labelText: "First Name",errorStyle:Util.errorTextStyle,
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
            /*  border: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(0.0)),
            gapPadding: 0.0,
            borderSide: BorderSide(
              color: Colors.grey[300],
            )),*/
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_FIRST_NAME_VAL
                      : !ValidationWidget.isName(val)
                          ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_FIRST_NAME_VAL
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                      : null,
          onSaved: (val) => strCoachFirstName = val.trim(),
        ));
    final coachLastName =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),errorStyle:Util.errorTextStyle,
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            labelText: "Last Name",
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            enabledBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            fillColor: Colors.transparent,
            /*  border: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(0.0)),
            gapPadding: 0.0,
            borderSide: BorderSide(
              color: Colors.grey[300],
            )),*/
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_LAST_NAME_VAL
                      : !ValidationWidget.isName(val)
                          ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_LAST_NAME_VAL
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                      : null,
          onSaved: (val) => strCoachLastName = val.trim(),
        ));

    final coachEmail =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.emailAddress,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            labelText: "Email",
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),errorStyle:Util.errorTextStyle,
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
            enabledBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            /*  border: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(0.0)),
            gapPadding: 0.0,
            borderSide: BorderSide(
              color: Colors.grey[300],
            )),*/
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_EMAIL_VAL
                      : !ValidationWidget.isEmail(val)
                          ? MessageConstant.VALID_EMAIL_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_EMAIL_VAL
                  : !ValidationWidget.isEmail(val)
                      ? MessageConstant.VALID_EMAIL_VAL
                      : null,
          onSaved: (val) => strCoachEmail = val.trim(),
        ));

    final descriptrionUi =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:  InputDecoration(
            filled: true,
            labelText: "Description",errorStyle:Util.errorTextStyle,
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            enabledBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(
                    color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_DESCRIPTION_VAL : null,
          onSaved: (val) => strDeascription = val.trim(),
        ));

    Text getTextLabel(txt, size, color, fontWeight) {
      return  Text(
        txt,
        style:
             TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    Future<Null> selectFromDate(BuildContext context) async {
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime:  DateTime.now(),
        initialDateTime: fromDate == null ?  DateTime.now() : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime != null) {
            fromDate = dateTime;
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime);
            String date2 =  DateFormat("yyyy-MM-dd").format(dateTime);
            print(date);
            setState(() {
              strFromDate = (dateTime.millisecondsSinceEpoch).toString();
              fromDateController =  TextEditingController(text: date);
              toDateController =  TextEditingController(text: "");
            });
          }
        },
      );
    }

    final fromDateUi =  InkWell(
        child:  Container(
            padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
            decoration:  BoxDecoration(
                border:
                     Border(bottom: BorderSide(color: Colors.grey[300]))),
            child:  TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              controller: fromDateController,
              decoration:  InputDecoration(
                contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                border: InputBorder.none,
                labelText: "Date From",
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                hintStyle:  TextStyle(
                    color: ColorValues.hintColor,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
              ),
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());

            selectFromDate(context);
          });
        });

    Future<Null> selectToDate(BuildContext context) async {
      DateTime dateTime2;
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime:  DateTime.now(),
        initialDateTime: toDateController == null || toDateController.text == ""
            ? fromDate
            : toDate != null ? toDate : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime2 != null) {
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime2);
            String date2 =  DateFormat("yyyy-MM-dd").format(dateTime2);
            print(date);
            var differenceStartDate = dateTime2.difference(fromDate);

            if (differenceStartDate.inDays >= 0) {
              toDate = dateTime2;

              setState(() {
                isPresent = false;
                strToDate = (dateTime2.millisecondsSinceEpoch).toString();
                toDateController =  TextEditingController(text: date);
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.ENTER_CORRECT_DATE_RANGE_VAL, context);
            }
          }
        },
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
        },
        onConfirm: (dateTime, List<int> index) {
          dateTime2 = dateTime;
        },
      );
    }

    final toDateUi =  InkWell(
        child:  Container(
            padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
            decoration:  BoxDecoration(
                border:
                     Border(bottom: BorderSide(color: Colors.grey[300]))),
            child:  TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              controller: toDateController,
              decoration:  InputDecoration(
                contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                border: InputBorder.none,
                labelText: "Date To",
                hintStyle:  TextStyle(
                    color:  ColorValues.hintColor,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
              ),
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
            if (fromDate != null) {
              selectToDate(context);
            } else {
              ToastWrap.showToast(
                  MessageConstant.SELECT_FROM_DATE_VAL, context);
            }
          });
        });

    final submitButton = PaddingWrap.paddingfromLTRB(
        0.0,
        10.0,
        0.0,
        0.0,
         FlatButton(
          color:  ColorValues.BLUE_COLOR,
          child:  Container(
            height: 50.0,
            width: double.infinity,
            child:  Center(
                child:  Text(
              "SAVE",
              style:  TextStyle(color: Colors.white),
            )),
          ),
          onPressed: () {
            final form = _formKey.currentState;
            form.save();
            /* if(strTitle==""||strDeascription==""||strCompetencyValue==""||appliedFilter==""||strLevelValue==""){
              scrollTop();
            }else{
              if(strCoachFirstName!=""||strCoachEmail!=""){
                scrollBottom();
              }
            }*/
            if (appliedFilter == "") {
              setState(() {
                addSkillsError =true;
              });
            }else {
              setState(() {
                addSkillsError =false;
              });
            }
            if (strLevelValue == "") {
              setState(() {
                selectAchivmentLevel = true;
              });

            }else {
              selectAchivmentLevel = false;
            }


            if (form.validate()) {
              if (validationCheck()) {
                apiCalling();
              }
            }
          },
        ));
//==========================Grid View horizontal for Selected Images====================================
    Padding gridSelectedImages() {
      return assestList != null && assestList.length > 0
          ? PaddingWrap.paddingfromLTRB(
              5.0,
              10.0,
              5.0,
              10.0,
               Container(
                  height: 135.0,
                  child:  GridView.count(
                    primary: true,
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.all(5.0),
                    crossAxisCount: 1,
                    childAspectRatio: .80,
                    mainAxisSpacing: 5.0,
                    crossAxisSpacing: 2.0,
                    children:  List.generate(assestList.length, (int index) {
                      /* return index == 0
                          ?  InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  5.0,
                                  0.0,
                                  15.0,
                                  10.0,
                                   Image.asset(
                                    "assets/profile/add_image.png",
                                    width: 80.0,
                                    height: 80.0,
                                  )),
                              onTap: () {
                                getImage(ImageSource.gallery);
                              })
                          :*/
                      return  Stack(
                        children: <Widget>[
                           InkWell(
                              child:  Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                   Image.network(
                                    Constant.IMAGE_PATH +
                                        assestList[index].file,
                                    fit: BoxFit.cover,
                                    height: 85.0,
                                    width: 145.0,
                                  ),
                                   Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                       Expanded(
                                        child: TextViewWrap.textView(
                                            assestList[index].tag,
                                            TextAlign.start,
                                            Colors.black,
                                            12.0,
                                            FontWeight.bold),
                                        flex: 1,
                                      ),
                                       Expanded(
                                        child: assestList[index].tag == "media"
                                            ? PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                15.0,
                                                0.0,
                                                 Image.asset(
                                                  "assets/newIcon/general.png",
                                                  height: 20.0,
                                                  width: 20.0,
                                                ))
                                            : assestList[index].tag == "badges"
                                                ? PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    3.0,
                                                    15.0,
                                                    0.0,
                                                     Image.asset(
                                                      "assets/newIcon/badge_black.png",
                                                      height: 20.0,
                                                      width: 20.0,
                                                    ))
                                                : assestList[index].tag ==
                                                        "trophy"
                                                    ? PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            3.0,
                                                            15.0,
                                                            0.0,
                                                             Image.asset(
                                                              "assets/newIcon/trophy.png",
                                                              height: 20.0,
                                                              width: 20.0,
                                                            ))
                                                    : PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            3.0,
                                                            15.0,
                                                            0.0,
                                                             Image.asset(
                                                              "assets/newIcon/Certificate_black.png",
                                                              height: 20.0,
                                                              width: 20.0,
                                                            )),
                                        flex: 0,
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              onLongPress: () {
                                assestList.removeAt(index);
                                setState(() {
                                  assestList;
                                });
                              }),
                           Container(
                            height: 85.0,
                            width: 145.0,
                            color: Colors.black54.withOpacity(.4),
                          ),
                           Align(
                              alignment: Alignment.topRight,
                              child:  InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      13.0,
                                      0.0,
                                       Image.asset(
                                        "assets/profile/delete_red.png",
                                        width: 25.0,
                                        height: 25.0,
                                      )),
                                  onTap: () {
                                    assestList.removeAt(index);
                                    setState(() {
                                      assestList;
                                    });
                                  })),
                        ],
                      );
                    }).toList(),
                  )))
          : PaddingWrap.paddingfromLTRB(
              5.0,
              10.0,
              5.0,
              10.0,
               Container(
                child:  Text(""),
              ));
    }

    _buildChoiceList() {
      List<Widget> choices = List();
      skillsSelectedList.forEach((item) {
        choices.add(Container(
            padding: const EdgeInsets.all(3.0),
            child:  Row(
              children: <Widget>[
                 Flexible(
                  child:  Text(
                    item.label,
                    overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),
                  flex: 1,
                ),
                 Expanded(
                  child:  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                         Icon(
                          Icons.cancel,
                          color:  ColorValues.BG_CIRCLE_COLOR,
                          size: 17.0,
                        )),
                    onTap: () {
                      setState(() {
                        skillsSelectedList.remove(item);
                        filterStatus[item.index] = false;
                        filterStatus[0] = false;
                      });
                      filterData = "";
                      appliedFilter = "";
                      skillsSelectedList.clear();
                      filterStatus.forEach(iterateFilters);
                    },
                  ),
                  flex: 0,
                ),
              ],
            )));
      });
      return choices;
    }

    void selectSkillDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  Scaffold(
                  backgroundColor: Colors.black38,
                  body:  Center(
                      child: PaddingWrap.paddingAll(
                          10.0,
                          ListView(children: <Widget>[
                             Container(
                                padding:  EdgeInsets.all(0.0),
                                color: Colors.white,
                                child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                     Container(
                                      color:  Color(0XFFEDEDED),
                                      child: PaddingWrap.paddingfromLTRB(
                                          19.0,
                                          10.0,
                                          10.0,
                                          10.0,
                                           Text(
                                            "Each experience leads to skill building. So, select every skill you feel you built or exercised "
                                                "with this experience. Demonstrate why this experience was so enriching for you.",
                                            textAlign: TextAlign.start,
                                            style:  TextStyle(
                                                fontSize: 14.0,
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                          )),
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        19.0,
                                        20.0,
                                        10.0,
                                        10.0,
                                         Text(
                                          "Select all your skills from the list below:",
                                          textAlign: TextAlign.start,
                                          style:  TextStyle(
                                              fontSize: 14.0,
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                    PaddingWrap.paddingfromLTRB(
                                        19.0,
                                        0.0,
                                        10.0,
                                        10.0,
                                         ListView.builder(
                                            // itemCount: myData.lenght(),
                                            shrinkWrap: true,
                                            itemCount: skillList.length,
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              if ((skillList.length - 1) ==
                                                  index) {
                                                return  Column(
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Padding(
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  8.0,
                                                                  0.0,
                                                                  8.0),
                                                          child:  Row(
                                                            children: <Widget>[
                                                              filterStatus[
                                                                      index]
                                                                  ?  Expanded(
                                                                      child:  Padding(
                                                                          padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child:  Image.asset(
                                                                            "assets/newDesignIcon/navigation/check.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                      flex: 0)
                                                                  :  Expanded(
                                                                      child:  Padding(
                                                                          padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child:  Image.asset(
                                                                            "assets/newDesignIcon/navigation/uncheck.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                      flex: 0),
                                                               Expanded(
                                                                  child:
                                                                       Text(
                                                                skillList[index]
                                                                    .title,
                                                                maxLines: 3,
                                                                style:  TextStyle(
                                                                    fontSize:
                                                                        14.0,
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              )),
                                                            ],
                                                          )),
                                                      onTap: () {
                                                        bool value =
                                                            filterStatus[index];

                                                        if (index == 0) {
                                                          for (int i = 0;
                                                              i <
                                                                  filterStatus
                                                                      .length;
                                                              i++) {
                                                            if (value)
                                                              filterStatus[i] =
                                                                  false;
                                                            else
                                                              filterStatus[i] =
                                                                  true;
                                                          }
                                                        } else {
                                                          // filterStatus[0] = false; // Set All false
                                                          if (filterStatus[
                                                              index]) {
                                                            filterStatus[
                                                                index] = false;
                                                          } else {
                                                            filterStatus[
                                                                index] = true;
                                                          }
                                                        }

                                                        // Refresh the All Check
                                                        int count = 0;
                                                        for (int i = 1;
                                                            i <
                                                                filterStatus
                                                                    .length;
                                                            i++) {
                                                          if (!filterStatus[i])
                                                            count++;
                                                        }

                                                        if (count > 0) {
                                                          filterStatus[0] =
                                                              false;
                                                        } else {
                                                          filterStatus[0] =
                                                              true;
                                                        }

                                                        setState(() {
                                                          filterStatus;
                                                        });
                                                        Navigator.pop(context);
                                                        selectSkillDialog();
                                                      },
                                                    ),
                                                     Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: <Widget>[
                                                         Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            15.0,
                                                            20.0,
                                                            0.0,
                                                            20.0,
                                                             InkWell(
                                                              child:  Text(
                                                                'Cancel',
                                                                style:  TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color:  ColorValues.GREY_TEXT_COLOR),
                                                              ),
                                                              onTap: () {
                                                                onCancelTap();
                                                              },
                                                            ),
                                                          ),
                                                          flex: 0,
                                                        ),
                                                         Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            0.0,
                                                            20.0,
                                                            20.0,
                                                            20.0,
                                                             InkWell(
                                                              child:  Text(
                                                                '',
                                                                style:  TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color:  ColorValues.GREY_TEXT_COLOR),
                                                              ),
                                                            ),
                                                          ),
                                                          flex: 1,
                                                        ),
                                                         Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            10.0,
                                                            20.0,
                                                            30.0,
                                                            20.0,
                                                             InkWell(
                                                              child:  Text(
                                                                'Done',
                                                                style:  TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                                                              ),
                                                              onTap: () {
                                                                onApplyClick();
                                                              },
                                                            ),
                                                          ),
                                                          flex: 0,
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                );
                                              } else {
                                                return  InkWell(
                                                  child:  Padding(
                                                      padding:  EdgeInsets
                                                              .fromLTRB(
                                                          0.0, 8.0, 0.0, 8.0),
                                                      child:  Row(
                                                        children: <Widget>[
                                                          filterStatus[index]
                                                              ?  Expanded(
                                                                  child:
                                                                       Padding(
                                                                          padding:  EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              5.0,
                                                                              8.0,
                                                                              5.0),
                                                                          child:  Image
                                                                              .asset(
                                                                            "assets/newDesignIcon/navigation/check.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                  flex: 0)
                                                              :  Expanded(
                                                                  child:
                                                                       Padding(
                                                                          padding:  EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              5.0,
                                                                              8.0,
                                                                              5.0),
                                                                          child:
                                                                               Image.asset(
                                                                            "assets/newDesignIcon/navigation/uncheck.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                  flex: 0),
                                                           Expanded(
                                                              child:  Text(
                                                            skillList[index]
                                                                .title,
                                                            maxLines: 3,
                                                            style:  TextStyle(
                                                                fontSize: 14.0,
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontWeight: skillList[index]
                                                                            .title ==
                                                                        "Select All"
                                                                    ? FontWeight
                                                                        .bold
                                                                    : FontWeight
                                                                        .normal,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                        ],
                                                      )),
                                                  onTap: () {
                                                    bool value =
                                                        filterStatus[index];
                                                    if (index == 0) {
                                                      for (int i = 0;
                                                          i <
                                                              filterStatus
                                                                  .length;
                                                          i++) {
                                                        if (value)
                                                          filterStatus[i] =
                                                              false;
                                                        else
                                                          filterStatus[i] =
                                                              true;
                                                      }
                                                    } else {
                                                      filterStatus[0] = false;
                                                      if (filterStatus[index]) {
                                                        filterStatus[index] =
                                                            false;
                                                      } else {
                                                        filterStatus[index] =
                                                            true;
                                                      }
                                                    }

                                                    // Refresh the All Check
                                                    int count = 0;
                                                    for (int i = 1;
                                                        i < filterStatus.length;
                                                        i++) {
                                                      if (!filterStatus[i])
                                                        count++;
                                                    }

                                                    if (count > 0) {
                                                      filterStatus[0] = false;
                                                    } else {
                                                      filterStatus[0] = true;
                                                    }

                                                    setState(() {
                                                      filterStatus;
                                                    });
                                                    Navigator.pop(context);
                                                    selectSkillDialog();
                                                  },
                                                );
                                              }
                                            }))
                                  ],
                                ))
                          ]))))));
    }

    void typeSelection() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child:  Container(
                                  height: 160.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child:  Text(
                                                            "Badge",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style:  TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: ()async {
                                                        Navigator.pop(context);
                                                        var status = await Permission.photos.status;
                                                        if (status.isGranted) {
                                                          getImage("badges");
                                                        }  else {
                                                          checkPermissionPhoto(context);
                                                        }

                                                      },
                                                    ),
                                                     Container(
                                                      color:  ColorValues.BORDER_COLOR,
                                                      height: 1.0,
                                                    ),
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child:  Text(
                                                            "Trophy",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style:  TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () async{
                                                        Navigator.pop(context);
                                                        var status = await Permission.photos.status;
                                                        if (status.isGranted) {
                                                          getImage("trophy");
                                                        }  else {
                                                          checkPermissionPhoto(context);
                                                        }

                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    rectangleDecoration() {
      return BoxDecoration(
          border: Border.all(color: Palette.dividerColor), color: Colors.white);
    }

    showMediaFileWidget(double width, File image) {
      return Container(
        height: 54,
        width: width,
        decoration: rectangleDecoration(),
        margin: EdgeInsets.only(left: 0, right: 0),
        child: Image.file(
          image,
          fit: BoxFit.contain,
        ),
      );
    }

    final videoListUi =  Container(
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.50,
          scrollDirection: Axis.vertical,
          crossAxisCount: 3,
          children: mediaVideosList.map((file) {
            if (file == null) {
              return  Stack(children: <Widget>[
                 InkWell(
                  child:  Container(
                      height: 54.0,
                      width: 80.0,
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  Image.asset(
                        "assets/newDesignIcon/userprofile/add.png",
                        height: 25.0,
                        width: 25.0,
                      )),
                  onTap: () {
                    if (mediaAndVideoList.length <= 9) {
                      onTapVideoAddButton();
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAX_10_IMAGE_VIDEO_UPLOADED_VAL, context);
                    }
                  },
                )
              ]);
            } else {
              return  Container(
                  child:  Stack(
                    children: <Widget>[
                      showMediaFileWidget(80, file.file),
                       Container(
                        height: 54.0,
                        width: 80.0,
                        color:  Color(0XFFC0C0C0).withOpacity(.4),
                      ),
                       Container(
                          height: 54.0,
                          width: 80.0,
                          child:  Center(
                              child:  Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                   InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                           Image.asset(
                                            "assets/newDesignIcon/achievment/remove.png",
                                            width: 35.0,
                                            height: 35.0,
                                          )),
                                      onTap: () {
                                        //conformationDialog("video", file);

                                        mediaVideosList.remove(file);
                                        //assestList.removeLast();
                                        setState(() {
                                        mediaVideosList;
                                        //assestList;
                                        });
                                        /*if (mediaVideosList.length == 1) {
                                                    selectedIndexCover = 0;
                                                    //mediaList.removeLast();
                                                    //mediaList.add(imageList[0]);
                                                    //mediaList.add("");
                                                    isPredefinedMediaSelected = true;
                                                  }*/

                                      })
                                ],
                              ))),
                    ],
                  ));
            }
          }).toList(),
        ));

    final mediaImageListUI =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaList.map((path) {
        if (path == "") {
          return  Stack(children: <Widget>[
             InkWell(
              child:  Container(
                  height: 54.0,
                  width: 80.0,
                  decoration:  BoxDecoration(
                      border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:  Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: ()async {
                if (assestList.length <= 9) {
                  var status = await Permission.photos.status;
                  if (status.isGranted) {
                    getImage("media");
                  }  else {
                    checkPermissionPhoto(context);
                  }

                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return  Container(
              child:  Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path,
                height: 54.0,
                width: 80.0,
              ),
               Container(
                height: 54.0,
                width: 80.0,
                color:  Color(0XFFC0C0C0).withOpacity(.4),
              ),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                         InkWell(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                 Image.asset(
                                  "assets/newDesignIcon/achievment/remove.png",
                                  width: 35.0,
                                  height: 35.0,
                                )),
                            onTap: () {
                              mediaList.remove(path);
                              assestList.removeLast();
                              setState(() {
                                mediaList;
                                assestList;
                              });
                            })
                      ]))),
            ],
          ));
        }
      }).toList(),
    ));

    final certificateListUI =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: certificateList.map((path) {
        if (path == "") {
          return  Stack(children: <Widget>[
             InkWell(
              child:  Container(
                  height: 54.0,
                  width: 80.0,
                  decoration:  BoxDecoration(
                      border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:  Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () async{
                if (assestList.length <= 9) {

                  var status = await Permission.photos.status;
                  if (status.isGranted) {
                    getImage("certificates");
                  }  else {
                    checkPermissionPhoto(context);
                  }
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return  Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path,
                height: 54.0,
                width: 80.0,
              ),
               Container(
                height: 54.0,
                width: 80.0,
                color:  Color(0XFFC0C0C0).withOpacity(.4),
              ),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                         InkWell(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                 Image.asset(
                                  "assets/newDesignIcon/achievment/remove.png",
                                  width: 35.0,
                                  height: 35.0,
                                )),
                            onTap: () {
                              certificateList.remove(path);
                              assestList.removeLast();
                              setState(() {
                                certificateList;
                                assestList;
                              });
                            })
                      ]))),
            ],
          );
        }
      }).toList(),
    ));

    /*  final badgeListUI =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: badgeList.map((path) {
        if (path == "") {
          return  Stack(children: <Widget>[
             InkWell(
              child:  Container(
                  height: 54.0,
                  width: 54.0,
                  decoration:  BoxDecoration(
                      border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:  Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                if (assestList.length <= 9) {
                  getImage("badges");
                } else {
                  ToastWrap.showToast("Maximum 10 images can be uploaded.");
                }
              },
            )
          ]);
        } else {
          return  Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path,
                height: 54.0,
                width: 62.0,
              ),
               Container(
                height: 54.0,
                width: 62.0,
                color:  Color(0XFFC0C0C0).withOpacity(.4),
              ),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              2.0,
                              2.0,
                               Image.asset(
                                "assets/newDesignIcon/achievment/remove.png",
                                width: 35.0,
                                height: 35.0,
                              )),
                          onTap: () {
                            badgeList.remove(path);
                            assestList.removeLast();
                            setState(() {
                              badgeList;
                              assestList;
                            });
                          }))),
            ],
          );
        }
      }).toList(),
    ));*/

    final trophyListUi =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: badgeAndTrophyList.map((path) {
        if (path.file == "") {
          return  Stack(children: <Widget>[
             InkWell(
              child:  Container(
                  height: 54.0,
                  width: 54.0,
                  decoration:  BoxDecoration(
                      border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:  Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                if (assestList.length <= 9) {
                  typeSelection();
                  // getImage("trophy");
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return  Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path.file,
                height: 54.0,
                width: 62.0,
              ),
               Container(
                height: 54.0,
                width: 62.0,
                color:  Color(0XFFC0C0C0).withOpacity(.4),
              ),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                         InkWell(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                 Image.asset(
                                  "assets/newDesignIcon/achievment/remove.png",
                                  width: 35.0,
                                  height: 35.0,
                                )),
                            onTap: () {
                              badgeAndTrophyList.remove(path);
                              assestList.removeLast();
                              setState(() {
                                badgeAndTrophyList;
                                assestList;
                              });
                            })
                      ]))),
            ],
          );
        }
      }).toList(),
    ));

    // Build a Form widget using the _formKey we created above

    Row getUpperDots() {
      return  Row(
        children: <Widget>[
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
        ],
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
      );
    }

    Container getBottomBar() {
      return  Container(
          child:  Row(
        children: <Widget>[
           InkWell(
            child:  Padding(
                padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                child: Image.asset(
                  'assets/newDesignIcon/parentProfile/backword.png',
                  height: 45.0,
                  width: 45.0,
                )),
            onTap: () {
              onBackwordClick();
            },
          ),
           Expanded(
            child:  InkWell(
              child:  Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                  child:  Text(
                    "SKIP",
                    style: TextStyle(
                        fontSize: 16.0,
                        fontFamily: Constant.customRegular,
                        color: ColorValues.GREY_TEXT_COLOR),
                    textAlign: TextAlign.center,
                  )),
              onTap: () {
                skipOnClick();
              },
            ),
            flex: 1,
          ),
          !true
              ?  InkWell(
                  child:  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                      child: Image.asset(
                        'assets/newDesignIcon/parentProfile/next.png',
                        height: 45.0,
                        width: 45.0,
                      )),
                  onTap: () {
                    onNextClick();
                  },
                )
              :  Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                  child: Image.asset(
                    'assets/newDesignIcon/parentProfile/next_gray.png',
                    height: 45.0,
                    width: 45.0,
                  ))
        ],
      ));
    }

    Center getAddButtton() {
      return  Center(
          child: Container(
        height: 35.0,
        width: 150.0,
        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
        child:  InkWell(
          child:  Padding(
            padding: EdgeInsets.fromLTRB(0.0, 8.0, 0.0, 0.0),
            child: TextViewWrap.textView("ADD", TextAlign.center,
                 ColorValues.WHITE, 14.0, FontWeight.normal),
          ),
          onTap: () {
            final form = _formKey.currentState;
            /* if (titleController.text == "" ||
                                descController.text == "" ||
                                strCompetencyValue == "" ||
                                appliedFilter == "" ||
                                strLevelValue == "") {
                              scrollTop();
                            } else {
                              if (strCoachFirstName != "" ||
                                  strCoachLastName != "" ||
                                  strCoachEmail != "") {
                                scrollBottom();
                              }
                            }*/

            form.save();
            if (form.validate()) {
              if (validationCheck()) {
                apiCalling();
              }
            } else {
              ToastWrap.showToast(
                  "A field(s) value has been left blank. Enter the value in Accomplishment field(s) before proceeding.",
                  context);
            }
          },
        ),
      ));
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  GestureDetector(
            onTap: () {
              // FocusScope.of(context).requestFocus(new FocusNode());
            },
            child:  Scaffold(
                body:  Column(
              children: <Widget>[
                 Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 100.0, 0.0, 0.0),
                    child: getUpperDots()),
                 Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 0.0),
                    child:  Text(
                      "Add Accomplishment",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontFamily: Constant.customRegular,
                          fontSize: 28.0,
                          fontWeight: FontWeight.normal,
                          color: ColorValues.HEADING_COLOR_EDUCATION),
                    )),
                 Expanded(
                  child: ListView(
                    controller: _controller,
                    children: <Widget>[
                      Form(
                        key: _formKey,
                        child:  Column(
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                22.0,
                                19.0,
                                22.0,
                                0.0,
                                 Text(
                                  "Add a memorable moment, activity, an experience, or an achievement"
                                  /*widget.level1Name == "Life Experiences"
                                      ? "Please provide details in the sections below to add a  experience"
                                      : "Please provide details in the sections below to add a  accomplishment"*/,
                                  style:  TextStyle(
                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                      fontSize: 12.0,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                )),
                             Container(
                                color:  ColorValues.SCREEN_BG_COLOR,
                                child: PaddingWrap.paddingfromLTRB(
                                    12.0,
                                    12.0,
                                    12.0,
                                    10.0,
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                         Card(
                                          elevation: 1.0,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(0.0)),
                                          child: PaddingWrap.paddingfromLTRB(
                                              14.0,
                                              0.0,
                                              5.0,
                                              10.0,
                                               Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                   Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            15.0,
                                                            15.0,
                                                            0.0,
                                                             Image.asset(
                                                              "assets/newDesignIcon/achievment/title.png",
                                                              width: 25.0,
                                                              height: 25.0,
                                                            )),
                                                    flex: 0,
                                                  ),
                                                   Expanded(
                                                    child:  Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        titleUi,
                                                        descriptrionUi,
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  )
                                                ],
                                              )),
                                        ),
                                        PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            10.0,
                                            0.0,
                                            0.0,
                                             Card(
                                              elevation: 1.0,
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          0.0)),
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      14.0,
                                                      10.0,
                                                      5.0,
                                                      10.0,
                                                       Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child: PaddingWrap
                                                                .paddingfromLTRB(
                                                                    0.0,
                                                                    10.0,
                                                                    15.0,
                                                                    0.0,
                                                                     Image
                                                                        .asset(
                                                                      "assets/newDesignIcon/achievment/competency.png",
                                                                      width:
                                                                          25.0,
                                                                      height:
                                                                          25.0,
                                                                    )),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child:  Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                competencySelected ==
                                                                        null
                                                                    ?  Container(
                                                                        height:
                                                                            10.0,
                                                                      )
                                                                    : PaddingWrap.paddingfromLTRB(
                                                                        0.0,
                                                                        10.0,
                                                                        0.0,
                                                                        0.0,
                                                                        getTextLabel(
                                                                            "Competency",
                                                                            11.0,
                                                                             ColorValues.GREY_TEXT_COLOR,
                                                                            FontWeight.normal)),
                                                                competencyDropDownUi,
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    20.0,
                                                                    0.0,
                                                                    5.0,
                                                                    Row(
                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      children: <Widget>[
                                                                        Expanded(
                                                                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
                                                                            InkWell(

                                                                                child: TextViewWrap.textView(skillsSelectedList.length == 0 ? "Add Skills" : "Skills", TextAlign.start, skillsSelectedList.length == 0 ? ColorValues.BLUE_COLOR_BOTTOMBAR : ColorValues.GREY_TEXT_COLOR, skillsSelectedList.length == 0 ? 16.0 : 13.0, FontWeight.normal),
                                                                                onTap: () {
                                                                                  setState(() {
                                                                                    addSkillsError= false;
                                                                                  });
                                                                                  if (skillsSelectedList.length == 0) selectSkillDialog();
                                                                                }),

                                                                            addSkillsError ?
                                                                            PaddingWrap.paddingfromLTRB(
                                                                                0.0,
                                                                                5.0,
                                                                                0.0,
                                                                                0.0,  Text(

                                                                              MessageConstant.SELECT_SKILLS_VAL,
                                                                              maxLines: 1,
                                                                              style: TextStyle(fontSize: 12.0, color: ColorValues.ERROR_COLOR),
                                                                            )):Container(height: 0,),

                                                                          ]),
                                                                          flex: 1,
                                                                        )
                                                                      ],
                                                                    )),
                                                                /*PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        20.0,
                                                                        0.0,
                                                                        5.0,
                                                                         Row(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: <
                                                                              Widget>[
                                                                             Expanded(
                                                                              child:  InkWell(
                                                                                  child: TextViewWrap.textView(skillsSelectedList.length == 0 ? "Add Skills" : "Skills", TextAlign.start, skillsSelectedList.length == 0 ?  ColorValues.BLUE_COLOR_BOTTOMBAR :  ColorValues.GREY_TEXT_COLOR, skillsSelectedList.length == 0 ? 16.0 : 12.0, FontWeight.normal),
                                                                                  onTap: () {
                                                                                    if (skillsSelectedList.length == 0) selectSkillDialog();
                                                                                  }),
                                                                              flex: 1,
                                                                            )
                                                                          ],
                                                                        )),*/
                                                                 Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .end,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                     Expanded(
                                                                      child:
                                                                          Wrap(
                                                                        children:
                                                                            _buildChoiceList(),
                                                                      ),
                                                                      flex: 1,
                                                                    ),
                                                                     Expanded(
                                                                      child: skillsSelectedList.length ==
                                                                              0
                                                                          ?  Container(
                                                                              height: 0.0,
                                                                            )
                                                                          :  InkWell(
                                                                              child:  Container(
                                                                                  height: 20.0,
                                                                                  width: 40.0,
                                                                                  child: Icon(
                                                                                    Icons.add,
                                                                                    color: Colors.black,
                                                                                    size: 20.0,
                                                                                  )),
                                                                              onTap: () {
                                                                                selectSkillDialog();
                                                                              },
                                                                            ),
                                                                      flex: 0,
                                                                    )
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            flex: 1,
                                                          )
                                                        ],
                                                      )),
                                            )),
                                        PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            10.0,
                                            0.0,
                                            0.0,
                                             Card(
                                              elevation: 1.0,
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          0.0)),
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      14.0,
                                                      10.0,
                                                      5.0,
                                                      10.0,
                                                       Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child: PaddingWrap
                                                                .paddingfromLTRB(
                                                                    0.0,
                                                                    10.0,
                                                                    15.0,
                                                                    0.0,
                                                                     Image
                                                                        .asset(
                                                                      "assets/newDesignIcon/achievment/achiewvement_level.png",
                                                                      width:
                                                                          25.0,
                                                                      height:
                                                                          25.0,
                                                                    )),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child:  Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                /*skillUi,*/
                                                                levelSelected ==
                                                                        null
                                                                    ?  Container(
                                                                        height:
                                                                            10.0,
                                                                      )
                                                                    : PaddingWrap.paddingfromLTRB(
                                                                        0.0,
                                                                        10.0,
                                                                        0.0,
                                                                        0.0,
                                                                        getTextLabel(
                                                                            widget.level1Name == "Life Experiences"
                                                                                ? "Experiences Level"
                                                                                : "Achievement Level",
                                                                            12.0,
                                                                             ColorValues.GREY_TEXT_COLOR,
                                                                            FontWeight.normal)),
                                                                competencyDropLevel,

                                                                selectAchivmentLevel ?
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    5.0,
                                                                    0.0,
                                                                    0.0,  Text(

                                                                  MessageConstant.SELECT_ACHIEVEMENT_LEVEL_VAL,
                                                                  maxLines: 1,
                                                                  style: TextStyle(fontSize: 12.0, color: ColorValues.ERROR_COLOR),
                                                                )):Container(height: 0,),



                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        10.0,
                                                                        0.0,
                                                                        0.0,
                                                                         Row(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: <
                                                                              Widget>[
                                                                             Expanded(
                                                                              child:  Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: <Widget>[
                                                                                  fromDateUi
                                                                                ],
                                                                              ),
                                                                              flex: 5,
                                                                            ),
                                                                             Expanded(
                                                                              child:  Container(),
                                                                              flex: 1,
                                                                            ),
                                                                             Expanded(
                                                                              child:  Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: <Widget>[
                                                                                  toDateUi
                                                                                ],
                                                                              ),
                                                                              flex: 5,
                                                                            ),
                                                                          ],
                                                                        )),
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        8.0,
                                                                        0.0,
                                                                        8.0,
                                                                         Row(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.end,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.end,
                                                                          children: <
                                                                              Widget>[
                                                                             Expanded(
                                                                              child:  Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: <Widget>[],
                                                                              ),
                                                                              flex: 5,
                                                                            ),
                                                                             Expanded(
                                                                              child:  Container(),
                                                                              flex: 1,
                                                                            ),
                                                                             Expanded(
                                                                              child:  Row(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: <Widget>[
                                                                                   Expanded(
                                                                                    child:  InkWell(
                                                                                      child:  Image.asset(
                                                                                        isPresent ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                                        width: 25.0,
                                                                                        height: 25.0,
                                                                                      ),
                                                                                      onTap: () {
                                                                                        if (isPresent)
                                                                                          isPresent = false;
                                                                                        else
                                                                                          isPresent = true;
                                                                                        setState(() {
                                                                                          isPresent;
                                                                                          toDate = null;
                                                                                          strToDate = "";
                                                                                          toDateController =  TextEditingController(text: "");
                                                                                        });
                                                                                      },
                                                                                    ),
                                                                                    flex: 0,
                                                                                  ),
                                                                                   Expanded(
                                                                                    child: Container(
                                                                                      padding:  EdgeInsets.fromLTRB(5.0, 3.0, 0.0, 0.0),
                                                                                      child:  Container(child: TextViewWrap.textView("Ongoing   ", TextAlign.start,  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontWeight.normal)),
                                                                                    ),
                                                                                    flex: 0,
                                                                                  )
                                                                                ],
                                                                              ),
                                                                              flex: 5,
                                                                            )
                                                                          ],
                                                                        )),
                                                              ],
                                                            ),
                                                            flex: 1,
                                                          )
                                                        ],
                                                      )),
                                            )),
                                        PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            10.0,
                                            0.0,
                                            0.0,
                                             Card(
                                              elevation: 1.0,
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          0.0)),
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      14.0,
                                                      10.0,
                                                      5.0,
                                                      10.0,
                                                       InkWell(
                                                        child:  Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                             Expanded(
                                                              child: PaddingWrap
                                                                  .paddingfromLTRB(
                                                                      0.0,
                                                                      10.0,
                                                                      15.0,
                                                                      0.0,
                                                                       Image
                                                                          .asset(
                                                                        "assets/newDesignIcon/achievment/media.png",
                                                                        width:
                                                                            25.0,
                                                                        height:
                                                                            25.0,
                                                                      )),
                                                              flex: 0,
                                                            ),
                                                             Expanded(
                                                              child:  Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: <
                                                                    Widget>[
                                                                  PaddingWrap.paddingfromLTRB(
                                                                      0.0,
                                                                      10.0,
                                                                      0.0,
                                                                      10.0,
                                                                      TextViewWrap.textView(
                                                                          "Add media",
                                                                          TextAlign
                                                                              .start,
                                                                           ColorValues.HEADING_COLOR_EDUCATION,
                                                                          16.0,
                                                                          FontWeight
                                                                              .normal)),
                                                                  PaddingWrap.paddingfromLTRB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      TextViewWrap.textViewMultiLine(
                                                                          "Please Add media (Photos, Certificates, Trophies & Badges)",
                                                                          TextAlign
                                                                              .start,
                                                                           ColorValues.GREY_TEXT_COLOR,
                                                                          14.0,
                                                                          FontWeight
                                                                              .normal,
                                                                          2)),
                                                                  isShowMedia
                                                                      ?  Column(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          children: <
                                                                              Widget>[
                                                                            PaddingWrap.paddingfromLTRB(
                                                                                0.0,
                                                                                17.0,
                                                                                0.0,
                                                                                10.0,
                                                                                 Text(
                                                                                  "Photos",
                                                                                  style:  TextStyle(color:  ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                )),
                                                                            mediaImageListUI,
                                                                            PaddingWrap.paddingfromLTRB(
                                                                                0.0,
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                 Text(
                                                                                  "Videos",
                                                                                  style:  TextStyle(color:  ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                )),
                                                                            videoListUi,
                                                                            PaddingWrap.paddingfromLTRB(
                                                                                0.0,
                                                                                17.0,
                                                                                0.0,
                                                                                10.0,
                                                                                 Text(
                                                                                  "Certificates",
                                                                                  style:  TextStyle(color:  ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                )),
                                                                            certificateListUI,
                                                                            PaddingWrap.paddingfromLTRB(
                                                                                0.0,
                                                                                17.0,
                                                                                0.0,
                                                                                10.0,
                                                                                 Text(
                                                                                  "Trophies & Badges",
                                                                                  style:  TextStyle(color:  ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                )),
                                                                            trophyListUi
                                                                          ],
                                                                        )
                                                                      :  Container(
                                                                          height:
                                                                              0.0,
                                                                        ),
                                                                ],
                                                              ),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                        onTap: () {
                                                          setState(() {
                                                            isShowMedia = true;
                                                          });
                                                        },
                                                      )),
                                            )),
                                      ],
                                    ))),
                             Container(
                                color:  ColorValues.SCREEN_BG_COLOR,
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    20.0,
                                    0.0,
                                    0.0,
                                     Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          isPrompt
                                              ? PaddingWrap.paddingfromLTRB(
                                                  13.0,
                                                  0.0,
                                                  13.0,
                                                  10.0,
                                                   Row(
                                                    children: <Widget>[
                                                      PaddingWrap.paddingAll(
                                                          0.0,
                                                           InkWell(
                                                            child:
                                                                 Image.asset(
                                                              "assets/newDesignIcon/login/check.png",
                                                              width: 25.0,
                                                              height: 25.0,
                                                            ),
                                                            onTap: () {
                                                              if (isPrompt)
                                                                isPrompt =
                                                                    false;
                                                              else
                                                                isPrompt = true;
                                                              setState(() {
                                                                isPrompt;
                                                              });
                                                            },
                                                          )),
                                                       Text(
                                                        "  Ask for recommendation",
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 16.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                    ],
                                                  ))
                                              : PaddingWrap.paddingfromLTRB(
                                                  13.0,
                                                  0.0,
                                                  13.0,
                                                  10.0,
                                                   Row(
                                                    children: <Widget>[
                                                      PaddingWrap.paddingAll(
                                                          0.0,
                                                          PaddingWrap
                                                              .paddingAll(
                                                                  0.0,
                                                                   InkWell(
                                                                    child:  Image
                                                                        .asset(
                                                                      isPrompt
                                                                          ? "assets/newDesignIcon/login/check.png"
                                                                          : "assets/newDesignIcon/login/uncheck.png",
                                                                      width:
                                                                          25.0,
                                                                      height:
                                                                          25.0,
                                                                    ),
                                                                    onTap: () {
                                                                      if (isPrompt)
                                                                        isPrompt =
                                                                            false;
                                                                      else
                                                                        isPrompt =
                                                                            true;
                                                                      setState(
                                                                          () {
                                                                        isPrompt;
                                                                      });
                                                                    },
                                                                  ))),
                                                       Text(
                                                        "  Ask for recommendation",
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 16.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                    ],
                                                  )),
                                          isPrompt
                                              ?  Card(
                                                  elevation: 0.0,
                                                  child:  Container(
                                                      decoration:  BoxDecoration(
                                                          border:  Border(
                                                              bottom: BorderSide(
                                                                  color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
                                                                  width: 1.0),
                                                              top: BorderSide(
                                                                  color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
                                                                  width: 1.0))),
                                                      child:
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  13.0,
                                                                  0.0,
                                                                  13.0,
                                                                  20.0,
                                                                   Column(
                                                                    children: <
                                                                        Widget>[
                                                                      recommendationTitle,
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          30.0,
                                                                          0.0,
                                                                          0.0,
                                                                           Container(
                                                                              padding:  EdgeInsets.all(5.0),
                                                                              color:  Color(0XFFE9E9E9),
                                                                              width: double.infinity,
                                                                              child:  Text(
                                                                                "RECOMMENDER DETAILS",
                                                                                style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 12.0, fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                                              ))),
                                                                      recommenderTitle,
                                                                      coachFirstName,
                                                                      coachLastName,
                                                                      coachEmail,
                                                                    ],
                                                                  ))))
                                              :  Container(
                                                  height: 0.0,
                                                )
                                        ]))),
                          ],
                        ),
                      ),
                       Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 30.0, 0.0, 20.0),
                          child: getAddButtton())
                    ],
                  ),
                  flex: 1,
                ),
                 Container(
                  child: getBottomBar(),
                )
              ],
            ))));
  }

  void skipOnClick() {
    if (widget.pageName == "all") {
      Navigator.pop(context);
    } else {
      apiCallWizardCompleted();
    }
  }

  void onNextClick() {
    if (widget.pageName == "all") {
      Navigator.pop(context);
    } else {
      apiCallWizardCompleted();
    }

    // make Api Call

    //Move to Accomplishment Page
  }

  void onBackwordClick() {
    Navigator.pop(context);
  }
}
