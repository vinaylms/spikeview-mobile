import 'dart:async';

import 'package:adhara_socket_io/manager.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/OpportunityViewOnNotificationClick.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/notification/model/NotificationModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parentProfile/RecommendationListForParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';

import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';

import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:url_launcher/url_launcher.dart';

class ParticipateInLeaderBoardWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  ParticipateInLeaderBoardWidgetState();
  }
}

class ParticipateInLeaderBoardWidgetState
    extends State<ParticipateInLeaderBoardWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isPreLoginSetting = false;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    isPreLoginSetting = prefs.getBool(UserPreference.IS_PRE_LOGIN);
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getSharedPreferences();
  }

  Future apiCallingForPreLogin(value) async {
    try {
      Response response;
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "isLeaderboardDisplay": value
      };
      print("map:-" + map.toString());

      response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_LEADERBOARD_SETTING, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setBool(UserPreference.IS_PRE_LOGIN, value);
            isPreLoginSetting = value;
            setState(() {});
          }
        }
      }
    } catch (e) {
      print("Errorr:-" + e.toString());
      e.toString();
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorValues.WHITE,
        appBar:  AppBar(
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          brightness: Brightness.light,
          leading:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               InkWell(
                child:  SizedBox(
                  height: 40.0,
                  width: 40.0,
                  child: PaddingWrap.paddingfromLTRB(
                      10.0,
                      5.0,
                      0.0,
                      3.0,
                       Center(
                          child:  Image.asset(
                              "assets/newDesignIcon/navigation/back.png",
                              height: 20.0,
                              width: 10.0,
                              fit: BoxFit.fitHeight))),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              )
            ],
          ),
          backgroundColor:  ColorValues.WHITE,
          elevation: 0.0,
        ),
        body: Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration:
                    BoxDecoration(
                        //color: Color.fromRGBO(193, 227, 252, 1)
                      color: ColorValues.SEARCH_CATEGORY_BOX_BG.withOpacity(0.3),
                    ),
                margin: const EdgeInsets.only(left: 25, top: 26,right: 25.0),
                child: Padding(
                  padding: const EdgeInsets.only(left: 13, top: 19,bottom: 20.0,right: 13),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(

                        child: Row(
                          children: [
                             Expanded(
                              child: Text('Participate in Leaderboard',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontFamily: 'Nunito',
                                      fontWeight: FontWeight.w600)),
                              flex: 1,
                            ),
                             Expanded(
                                child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 0, top: 0, right: 10),
                                    child: isPreLoginSetting
                                        ?  GestureDetector(
                                        onHorizontalDragEnd:
                                            (DragEndDetails
                                        details) {
                                          print("click++++++");
                                          apiCallingForPreLogin(
                                              false);
                                        },
                                        onTap: () {
                                          print("click++++++");
                                          apiCallingForPreLogin(
                                              false);
                                        },
                                        child:  Center(
                                            child:  Padding(
                                                padding:
                                                 EdgeInsets
                                                    .fromLTRB(
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                    0.0),
                                                child:
                                                 Image.asset(
                                                  "assets/newDesignIcon/active.png",
                                                  width: 42.0,
                                                  height: 35.0,
                                                ))))
                                        :  GestureDetector(
                                        onHorizontalDragEnd:
                                            (DragEndDetails
                                        details) {
                                          print("click++++++");
                                          apiCallingForPreLogin(
                                              true);
                                        },
                                        onTap: () {
                                          print("click++++++");
                                          apiCallingForPreLogin(
                                              true);
                                        },
                                        child:  Center(
                                            child:  Padding(
                                                padding:
                                                 EdgeInsets
                                                    .fromLTRB(
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                    0.0),
                                                child:
                                                 Image.asset(
                                                  "assets/newDesignIcon/inactive.png",
                                                  width: 42.0,
                                                  height: 35.0,
                                                ))))),
                                flex: 0)
                          ],
                        ),
                      ),
                      SizedBox(height: 6),
                      Container(


                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                  text: TextSpan(
                                text: 'Gain visibility and perks as a spikeview power user.  Disable toggle to not be featured in the leaderboard.',
                                style: TextStyle(
                                    fontSize: 14,
                                    fontFamily: 'Nunito',
                                    color: Colors.black),
                              )),
                              SizedBox(height: 15),
                              RichText(
                                  text: TextSpan(
                                    text: 'You will be showcased as a spikeview power user in our leaderboard.'
                                        ' Your profile image, your first name and first letter of your'
                                        ' last name and your reward points will be showcased on our '
                                        'leaderboard. If you do not want to participate, use the toggle '
                                        'to turn this off. You can enable this later from the menu.',
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontFamily: 'Nunito',
                                        color: Colors.black),
                                  )),
                            ],
                          ))
                    ],
                  ),
                ),
              ),
            ],
          ),
        ));
  }
}
