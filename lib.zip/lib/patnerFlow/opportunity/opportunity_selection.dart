import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/linkPreview/whatsapp/index.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/advisor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/mentor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/tutor_opportunity_view.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:flutter/rendering.dart';
import 'package:spike_view_project/modal/patner/OpportunityTypeModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/opportunity_view.dart';
import 'package:spike_view_project/modal/patner/opportunity_category_model.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:dio/dio.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:metadata_fetch/metadata_fetch.dart';
import 'package:spike_view_project/widgets/stepper_widget.dart';

class OpportunitySelection extends StatefulWidget {
  CompanyProfileModel companyModel;
  String link;
  OpportunitySelection(this.companyModel, {this.link});

  //String userId;
  //OpportunitySelection(this.userId);

  @override
  State<StatefulWidget> createState() => OpportunitySelectionState();
}

class OpportunitySelectionState extends State<OpportunitySelection>
    with BaseCommonWidget {
  List<OpportunityTypeObj> opportunityTypeObjList = [];
 // List<OpportunityCategoriesResult> opportunityCategoryList = [];
  SharedPreferences prefs;

  int _selectedIndex = 0;
  String title;

  int currentStep = 0;


  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return SafeArea(
      child:  WillPopScope(
        onWillPop: () async {
          if(widget.link!=null&&widget.link!=""){
            Navigator.pushReplacement(
                context,
                 MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) =>  DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));
          }else {
            goToPrevious();
          }
          return false;
        },
        child: Scaffold(
          // appBar:  AppBar(
          //   elevation: 0.0,
          //   automaticallyImplyLeading: false,
          //   titleSpacing: 2.0,
          //   brightness: Brightness.light,
          //   leading:  Row(
          //     crossAxisAlignment: CrossAxisAlignment.center,
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: <Widget>[
          //        InkWell(
          //         child:  SizedBox(
          //           height: 40.0,
          //           width: 40.0,
          //           child: PaddingWrap.paddingfromLTRB(
          //               0.0,
          //               5.0,
          //               0.0,
          //               3.0,
          //                Center(
          //                   child:  Image.asset(
          //                       "assets/newDesignIcon/navigation/back.png",
          //                       height: 20.0,
          //                       width: 10.0,
          //                       fit: BoxFit.fitHeight))),
          //         ),
          //         onTap: () {
          //           if(widget.link!=null&&widget.link!=""){
          //             Navigator.pushReplacement(
          //                 context,
          //                  MaterialPageRoute(
          //                   //   builder: (context) =>  DashBoardWidget()));
          //                     builder: (context) =>  DashBoardWidgetPartner(
          //                         prefs.getString(UserPreference.IS_PARENT_ROLE),
          //                         prefs.getString(UserPreference.IS_PARTNER_ROLE),
          //                         prefs.getString(UserPreference.IS_USER_ROLE),
          //                         currentPage: Constant.PROFILE_TYPE)));
          //           }else{  Navigator.pop(context);}
          //         },
          //       )
          //     ],
          //   ),
          //   actions: <Widget>[
          //      InkWell(
          //       child: PaddingWrap.paddingfromLTRB(
          //           5.0,
          //           7.0,
          //           10.0,
          //           5.0,
          //            Row(
          //             crossAxisAlignment: CrossAxisAlignment.center,
          //             mainAxisAlignment: MainAxisAlignment.center,
          //             children: <Widget>[
          //                Text("Proceed",
          //                   //"",
          //                   style:  TextStyle(
          //                     fontSize: 16.0,
          //                     fontFamily: Constant.customRegular,
          //                     color: Colors.transparent,
          //                   ))
          //             ],
          //           )),
          //       /*onTap: () {
          //         //_navigateToOpportunity(_selectedIndex);
          //       },*/
          //     )
          //   ],
          //   title:  Row(
          //     crossAxisAlignment: CrossAxisAlignment.center,
          //     mainAxisAlignment: MainAxisAlignment.center,
          //     children: <Widget>[
          //        Text(
          //         "Create",
          //         style:  TextStyle(
          //             fontSize: 18.0,
          //             fontFamily: Constant.customRegular,
          //             color:  ColorValues.HEADING_COLOR_EDUCATION),
          //       )
          //     ],
          //   ),
          //   backgroundColor: Colors.white,
          // ),

          body:
          WillPopScope(
            onWillPop: () {
             // _onBackPressed();
              return Future.value(false);
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.fromLTRB(20, 50, 20, 14),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          BaseText(
                            text: 'Create opportunity',
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w700,
                            fontSize: 28,
                            maxLines: 1,
                          ),
                          InkWell(
                            child: SizedBox(
                              height: 32.0,
                              width: 32.0,
                              child: Center(
                                child: Image.asset(
                                  "assets/new_onboarding/help_icon.png",
                                  height: 32.0,
                                  width: 32.0,
                                  fit: BoxFit.fitHeight,
                                ),
                              ),
                            ),
                            onTap: () {},
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      BaseText(
                        text: 'Share an opportunity with the community',
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                      ),
                      const SizedBox(height: 14),
                      StepperWidget(length: 4, currentStep: currentStep),
                    ],
                  ),
                ),

                Expanded(

                  child: FormKeyboardActions(
                      nextFocus: false,
                      keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                      //optional
                      keyboardBarColor: Colors.grey[200],
                      //optional
                      actions: [
                        /*KeyboardAction(
                  focusNode: phoneFocus,
                ),
                KeyboardAction(
                  focusNode: parentZipcodeFocusNode,
                ),
                KeyboardAction(
                  focusNode: companyPhoneFocus,
                ),*/
                      ],
                      child:  Column(
                        children: <Widget>[
                          //CustomViews.getSepratorLine(),
                          Expanded(
                            child: SingleChildScrollView(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      child: Padding(
                                        padding:
                                        const EdgeInsets.fromLTRB(13, 13, 13, 16.0),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: <Widget>[
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 6.0, bottom: 10.0),
                                              child: Text(
                                                "Please select a category",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                                  fontFamily: Constant.latoRegular,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                            getGridWidget(),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                )),
                          )
                        ],
                      )),
                ),
              ],
            ),
          ),

          bottomNavigationBar:  Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 40),
            child: _negativeButton(title: 'Cancel'),
          ),




        ),
      ),
    );
  }




  getData() async {
    print("before data++");
    Metadata data = await extract(
        widget.link); // Use the extract() function to fetch data from the url
    title = data.title.toString();
    if (title == "null") {
      title = "";
    }
  }

  @override
  void initState() {
    super.initState();

    //initOpporunityType();
    if (widget.link != null && widget.link != "") {
      getData();
    }
    getSharedPreferences();
  }

  void goToPrevious() async {
    Navigator.pop(context, "pop");
  }




  Widget _negativeButton({@required String title}) {
    return InkWell(
      onTap: () {
        if(widget.link!=null&&widget.link!=""){
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) =>  DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));
        }else{  Navigator.pop(context);}
      },
      child: Container(
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          border: Border.all(color: Color(0xffB2BDDB)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: AppConstants.colorStyle.lightPurple,
            fontFamily: AppConstants.stringConstant.latoRegular,
            fontSize: 18,
          ),
        ),
      ),
    );
  }


  getGridWidgetold() {
    return Padding(
      padding: const EdgeInsets.only(left: 0.0, right: 0.0, bottom: 65.0),
      child:  Container(
        child:  GridView.count(
          crossAxisCount: 2,
          childAspectRatio: (153 / 50),
          controller:  ScrollController(keepScrollOffset: false),
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          children: opportunityTypeObjList.map((OpportunityTypeObj value) {
            return InkWell(
              child:  Container(
                color: value.isSelected
                    ? ColorValues.BLUE_COLOR
                    : ColorValues.SELECTION_GRAY,
                margin:  EdgeInsets.all(8.0),
                child:  Center(
                  child:  Text(
                    value.OpportunityType,
                    style:  TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                      color: value.isSelected
                          ? ColorValues.WHITE
                          : ColorValues.GREY_TEXT_COLOR,
                    ),
                  ),
                ),
              ),
              onTap: () {
                selectOpportunity(value.index);
                //_selectedIndex = value.index;
                //_selectedIndex = widget.companyModel.offers[value.index].offerId;
                //_navigateToOpportunity(value.index);
                _navigateToOpportunity(value.index);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  String getIcon(String name) {
    switch (name) {

      case 'Internship':
        return 'assets/newDesignIcon/patner/internshipOpportunity.png';
      case 'Job':
        return 'assets/newDesignIcon/patner/jobOpportunity.png';
      case 'Volunteering':
        return 'assets/newDesignIcon/patner/volunteeringOpportunity.png';
      case 'Programs':
        return 'assets/newDesignIcon/patner/programOpportunity.png';
      case 'Services':
        return 'assets/newDesignIcon/patner/serviceOpportunity.png';
      case 'Tutors':
        return 'assets/newDesignIcon/patner/tutorOpportunity.png';
      case 'Mentors':
        return 'assets/newDesignIcon/patner/mentorOpportunity.png';
      case 'Advisors':
        return 'assets/newDesignIcon/patner/AdvisorsOpportunity.png';

      default:
        return 'assets/experience/ic_academic.png';
    }
  }



  getGridWidget() {
    return Padding(
      padding:
      const EdgeInsets.only(left: 0.0, right: 0.0, bottom: 0.0, top: 0.0),
      child: Container(

        child: SingleChildScrollView(
          child: Column(
            children: opportunityTypeObjList.map((OpportunityTypeObj value) {
              return InkWell(
                child: Container(
                    height: 70,
                    margin: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                        color: Color(0xffE9ECFD),
                        borderRadius: BorderRadius.circular(10)
                    ),

                    child:

                    Row(
                      children: [

                        Container(
                          width:  value.OpportunityType == "Volunteering" ? 17 :value.OpportunityType == "Programs" || value.OpportunityType == "Services"? 22 : 20 ,
                        ),
                        Image.asset(
                          getIcon(value.OpportunityType),
                          height: value.OpportunityType == "Volunteering" ? 45 : value.OpportunityType == "Programs" || value.OpportunityType == "Services" ? 24 :30,
                          width: value.OpportunityType == "Volunteering" ? 40 :value.OpportunityType == "Programs" || value.OpportunityType == "Services"? 24 :30,
                        ),
                        SizedBox(width: value.OpportunityType == "Volunteering" ? 5 :value.OpportunityType == "Programs" || value.OpportunityType == "Services"? 18 : 14 ,),

                        Expanded(
                          child: Text(
                            value.OpportunityType,
                            style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.w500,
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily: Constant.latoRegular
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(right: 15),
                          child: Image.asset(
                            'assets/newDesignIcon/patner/leftnavigateArrow.png',
                            width: 33.0,
                            height: 33.0,
                          ),
                        ),
                      ],
                    )

                ),
                onTap: () {
                  selectOpportunity(value.index);
                  //_selectedIndex = value.index;
                  //_selectedIndex = widget.companyModel.offers[value.index].offerId;
                  //_navigateToOpportunity(value.index);
                  _navigateToOpportunity(value.index);;
                },
              );
            }).toList(),
          ),
        ),

        // GridView.count(
        //   crossAxisCount: 2,
        //   childAspectRatio: (153 / 50),
        //   controller: ScrollController(keepScrollOffset: false),
        //   shrinkWrap: true,
        //   scrollDirection: Axis.vertical,
        //   children: opportunityTypeObjList.map((OpportunityTypeObj value) {
        //     return InkWell(
        //       child: Container(
        //         color: value.isSelected
        //             ? ColorValues.BLUE_COLOR
        //             : ColorValues.SELECTION_GRAY,
        //         margin: EdgeInsets.all(8.0),
        //         child: Center(
        //           child: Text(
        //             value.OpportunityType,
        //             style: TextStyle(
        //               fontSize: 16.0,
        //               fontWeight: FontWeight.w600,
        //               color: value.isSelected
        //                   ? ColorValues.WHITE
        //                   : ColorValues.GREY_TEXT_COLOR,
        //             ),
        //           ),
        //         ),
        //       ),
        //       onTap: () {
        //         selectOpportunity(value.index);
        //         _navigateToOpportunity(value.index);
        //       },
        //     );
        //   }).toList(),
        // ),
      ),
    );
  }


  void selectOpportunity(int index) {
    for (int i = 0; i < opportunityTypeObjList.length; i++) {
      setState(() {
        if (i != index) {
          opportunityTypeObjList[i].isSelected = false;
        } else {
          opportunityTypeObjList[i].isSelected = true;
        }
      });
    }
  }

  void _navigateToOpportunity(int index) {
    print('inside _navigateToOpportunity index;:: $index');
    switch (opportunityTypeObjList[index].offerId) {
      case 1:
        onTapOpportunity(0, index);
        break;
      case 2:
        onTapOpportunity(0, index);
        break;
      case 3:
        onTapOpportunity(0, index);
        break;
      case 4:
        onTapOpportunity(1, index);
        break;
      case 5:
        onTapOpportunity(1, index);
        break;
      case 6:
        onTapTutorOpportunity(index);
        break;
      case 7:
        onTapMentorOpportunity(index);
        break;
      case 8:
        onTapAdvisorOpportunity(index);
        break;
    }
  }

  onTapOpportunity(indexType, int index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  Opportunity(
            widget.companyModel.companyId,
            widget.companyModel.offers[indexType].offerId.toString(),
            opportunityTypeObjList[index].offerId.toString(),
            opportunityTypeObjList[index].OpportunityType.toString(),title: title,link: widget.link,dob:widget.companyModel.dob,)));
    if (result == "push") {
      print('onTapMentorOpportunity push()');
      if(widget.link!=null&&widget.link!=""){
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: Constant.PROFILE_TYPE)));
      }else
      Navigator.pop(context, "push");
    }
  }

  onTapTutorOpportunity(int index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  TutorOpportunity(
            widget.companyModel.companyId,
            opportunityTypeObjList[index].offerId.toString(),title: title,link: widget.link,)));

    if (result == "push") {
      if(widget.link!=null&&widget.link!=""){
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: Constant.PROFILE_TYPE)));
      }else
      Navigator.pop(context, "push");
    }
  }



  onTapMentorOpportunity(int index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  MentorOpportunity(
            widget.companyModel.companyId,
            opportunityTypeObjList[index].offerId.toString(),title: title,link: widget.link,)));

    if (result == "push") {
      if(widget.link!=null&&widget.link!=""){
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: Constant.PROFILE_TYPE)));
      }else
      Navigator.pop(context, "push");
    }
  }

  onTapAdvisorOpportunity(int index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  AdvisorOpportunity(
            widget.companyModel.companyId,
            opportunityTypeObjList[index].offerId.toString(),title: title,link: widget.link,)));

    if (result == "push") {
      if(widget.link!=null&&widget.link!=""){
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: Constant.PROFILE_TYPE)));
      }else
      Navigator.pop(context, "push");
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    //callApiOpporunityCategory();
    initOpporunityTypeSelected(widget.companyModel);
    setState(() {

    });

   //anaylytics.setCurrentSreen(ScreenNameConstant.create_opp_activity);

  }

  void initOpporunityTypeSelected(CompanyProfileModel companyModel) {
    print("offer+++"+companyModel.offers.length.toString());
    for (int i = 0; i < companyModel.offers.length; i++) {
      print("data+++"+ companyModel.offers[i].name+"  "+companyModel.offers[i].offerId.toString());
      opportunityTypeObjList.add(new OpportunityTypeObj(false,
          companyModel.offers[i].name, i, companyModel.offers[i].offerId));

    }
  }
}
