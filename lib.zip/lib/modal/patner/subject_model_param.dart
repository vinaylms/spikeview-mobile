class SubjectModelParam {
  bool isOther;
  String name;
  int subjectId;

  SubjectModelParam({this.name, this.subjectId,this.isOther});

  static Map<String, dynamic> toMap(SubjectModelParam categoryObject) {
    Map<String, dynamic> categoryMap = Map();
    categoryMap['name'] = categoryObject.name;
    categoryMap['subjectId'] = categoryObject.subjectId;
    categoryMap['isOther'] = categoryObject.isOther;
    return categoryMap;
  }

  String toMapString() {
    String data = "";

    data = data + this.name;

    return data;
  }

  static List<Map<String, dynamic>> mapList(List<SubjectModelParam> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
              "name": category.name,
              "subjectId": category.subjectId,
              "isOther": category.isOther,
            })
        .toList();
    return listOfCategory;
  }
}


