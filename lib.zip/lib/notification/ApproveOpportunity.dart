import 'dart:async';
import 'package:dio/dio.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/notification/OpportunityForBoat.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_advisor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_mentor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_opportunity_view.dart';

import 'package:flutter/material.dart';

import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';

import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

import 'package:spike_view_project/notification/model/NotificationModel.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';

import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_tutor_opportunity_view.dart';

import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';


class Approveopportunity extends StatefulWidget {
  String opportunityId, pageName;


  Approveopportunity(this.pageName, this.opportunityId);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  ApproveopportunityState();
  }
}

class ApproveopportunityState extends State<Approveopportunity> {
  SharedPreferences prefs;
  String userIdPref, roleId;



  getSharedPreferences() async {


    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getSharedPreferences();
    print("==================== INIT STATE");
  }



  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;









    return  WillPopScope(
        onWillPop: () {

            Navigator.pop(context);

        },
        child:  Scaffold(
            backgroundColor: Colors.white,
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,

              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    flex: 0,
                    child:  InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Center(
                      child:  Image.asset(
                        "assets/newDesignIcon/blue_spike_logo.png",
                        width: 114.0,
                        height: 29.0,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 0,
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),),
                  ),
                ],
              ),

              backgroundColor: Colors.white,
              elevation: 0.0,
            ),
            body:  Center(
                child:  Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(30.0, 0, 30, 0),
                      child: RichText(
                        maxLines: 8,
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          text: "Partner account successfully approved. Review partner opportunities and approve.",
                          style:  TextStyle(
                              color:   ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 16.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),

                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(15, 40.0, 15, 50),
                      child:  InkWell(
                        child:  Container(
                            color:
                             ColorValues.BLUE_COLOR_BOTTOMBAR,
                            width: double.infinity,
                            height: 40.0,
                            child: Center(
                              child:  Text(
                                "Review Opportunity",
                                textAlign: TextAlign.center,
                                style:  TextStyle(
                                    color: Colors.white,
                                    fontSize: 16.0,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                              ),
                            )),
                        onTap: () {
                          Navigator.of(context).pushReplacement(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                               OpportunityForBoat(
                                  widget.opportunityId, "4", widget.pageName)));
                        },
                      ),
                    )
                  ],
                ))));
  }




}
