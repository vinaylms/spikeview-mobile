import 'package:flutter/cupertino.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class SkillBarModel {
  String name;
  double value;
  Color color;
  int skillId;

  SkillBarModel(this.name,this.color,this.value,this.skillId);
}


