// Updated COde

import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/more_data.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:http/http.dart' as http;
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/gateway/ReferalCodeResponse.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
class SignupParentPageNew extends StatefulWidget {
  static String tag = 'login-page';
  bool isRedirectToRecommendation, isValid;
  String pageName,
      firstName = "",
      lastName = "",
      email = "",
      signupType,
      image = "";

  SignupParentPageNew(
      this.isRedirectToRecommendation, this.pageName, this.signupType,
      {this.firstName, this.lastName, this.email, this.image, this.isValid});

  @override
  SignupPageState createState() =>
       SignupPageState(this.firstName, this.lastName, this.email);
}

class SignupPageState extends State<SignupParentPageNew> {
  SignupPageState(this.strFirstName, this.strLastName, this.strEmail);

  final formKey = GlobalKey<FormState>();
  final formKeyReferal = GlobalKey<FormState>();
  String strFirstName = "",
      strLastName = "",
      strEmail = "",
      strStudentyEmail = "",
      strStudentFirstName = "",
      strStudentLastName = "";
  Color borderColor = Colors.amber;
  BuildContext context;
  bool isAgree = false;
  bool isParentAge = false;
  String token = "", linkUrl, referalUserId = "", referalUserRoleId = "";
  SharedPreferences prefs;

  bool isValid = true;

  final FocusNode firstNameFocus = FocusNode();
  final FocusNode lastNameFocus = FocusNode();
  final FocusNode emailFocus = FocusNode();
  ShareProfileModal shareProfileModal;

  static const platform = const MethodChannel('samples.flutter.io/battery');
  TextEditingController referalController =  TextEditingController();

  bool isValidateReferal = false;

  ReferalCodeResponse referalCodeResponse;
  FocusNode referalFocusNode = FocusNode();

  bool password_error_lenght = false;
  bool password_error_number = false;
  bool password_error_lower = false;
  bool password_error_upper = false;
  bool password_error_specile = false;

  goto() {
    if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>  MoreData()));
    } else {
      prefs.setString(UserPreference.PATHURL, "");
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => DashBoardWidgetParent(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE))));
    }
  }

  showSucessMsgLong(msg, context) {
    Timer _timer;
    _timer =  Timer(const Duration(milliseconds: 5000), () async {
      Navigator.pop(context);
      if (widget.pageName == "Login") {
        Navigator.of(context).popUntil((route) => route.isFirst);
      } else {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>  LoginPage(null)));
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  onTapPresoView() async {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await Navigator.pushReplacement(
        Constant.applicationContext,
         MaterialPageRoute(
            //   builder: (context) =>  DashBoardWidget()));
            builder: (context) =>  SharePresoView23(
                shareProfileModal.profileOwner, shareProfileModal, "main")));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  processForUri(result, email) async {
    if (result.toString().toLowerCase().contains(email)) {
      if (result.contains("previewprofile")) {

        Navigator.of(context).popUntil((route) => route.isFirst);
        goto();
      } else if (result.contains("joingroup")) {
        List<String> mesagelist = result.split("=");

        String groupId = mesagelist[2].replaceAll("&email", "");
        String email = mesagelist[3].replaceAll("&pass", "");
        String pass = mesagelist[4];
        prefs.setString(UserPreference.ROLE_ID, "2");
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
             MaterialPageRoute(
                builder: (BuildContext context) =>
                     GroupDetailWidget(groupId, "login", "", "", "")));
      } else {
        Navigator.of(context).popUntil((route) => route.isFirst);
        goto();
      }/*else if (result.contains("recommendation")) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidgetParent(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
      }*/
    } else {
      Navigator.of(context).popUntil((route) => route.isFirst);
      goto();
    }
    prefs.setString(UserPreference.PATHURL, "");
  }

  loginServiceCall() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);

        String encryptedstrNewPassword = "";
        if (widget.isRedirectToRecommendation) {
          encryptedstrNewPassword = await platform.invokeMethod('encryption', {
            "password": strNewPassword,
          });
        }
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token};
        // Prepare Data

        Map map = {
          "firstName": strFirstName,
          "deviceId": prefs.getString("deviceId"),
          "lastName": strLastName,
          "email": strEmail.toLowerCase(),
          "zipCode": "",
          "gender": "",
          "roleId": 2,
          "dob": "",
          // "recommendationFlag": widget.isRedirectToRecommendation,
          "recommendationWebFlag": widget.isRedirectToRecommendation,
          "password": encryptedstrNewPassword,
          "state": "",
          "city": "",
          "country": "",
          "referralUserId": referalUserId,
          "referralUserRoleId": referalUserRoleId,
          "referCode": referalController.text.toString().trim(),
          "signupType": widget.signupType,
          "socialId": "",
          "platformType": "mobile",
          "isUnderAge": true,
          "isAcceptedTermCon": true,
        };
        print("map+++++" + map.toString());
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_PARENT_SIGNUP,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);

        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            prefs.setString(UserPreference.chat_skip_count, "0");
            prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, false);
            prefs.setBool(UserPreference.isEducationAdded, false);
            // Api call for get setting data
            bloc.fetchSetting('', context, prefs);
            String path = prefs.getString(UserPreference.PATHURL);
            if (widget.signupType == "apple" || widget.signupType == "google") {
              Constant.isAlreadyLoggedIn = true;
              prefs.setBool(UserPreference.IS_ADDED_DOB, false);
              prefs.setBool(UserPreference.IS_UNDER_AGE, true);
              prefs.setString(UserPreference.IS_USER_ROLE, "false");
              prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
              prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");

              var companyMap = response.data['result']['company'];
              Company company =  Company('', '', false);
              if (companyMap != null) {
                print('Apurva companyMap:: $companyMap not null');
                company =  Company(
                    companyMap['name'].toString(),
                    companyMap['partnerStatus'].toString(),
                    companyMap['isActive']);

                if (company.partnerStatus.toString() == 'Decline')
                  prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP, true);
                else
                  prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP, false);
              }

              print(
                  'Apurva UserPreference.IS_SHOW_REJECTION_POPUP:: ${prefs.getBool(UserPreference.IS_SHOW_REJECTION_POPUP)}');

              String userId = response.data['result']['userId'].toString();

              String firstName =
                  response.data['result']['firstName'].toString();
              String lastName = response.data['result']['lastName'].toString();
              String email = response.data['result']['email'].toString();
              String salt = response.data['result']['salt'].toString();
              String mobileNo = response.data['result']['mobileNo'].toString();
              String profilePicture =
                  response.data['result']['profilePicture'].toString();
              String roleId = response.data['result']['roleId'].toString();
              String dob = response.data['result']['dob'].toString();
              if (dob == null || dob == "null" || dob == "") {
                dob = "0";
              }
              String companyName =
                  response.data['result']['companyName'].toString();
              String companyProfilePicture =
                  response.data['result']['companyProfilePicture'].toString();
              bool ProfileCreatedByParent =
                  response.data['result']['profileCreatedByParent'];
              if (ProfileCreatedByParent == null) {
                ProfileCreatedByParent = false;
              }

              bool userLoginFirstTime =
                  response.data['result']['userLoginFirstTime'];
              if (userLoginFirstTime == null) {
                userLoginFirstTime = false;
              }

              prefs.setBool(
                  UserPreference.SHOW_BOT_DEFAULT_COUNT, userLoginFirstTime);

              print(
                  "userLoginFirstTime+++++++" + userLoginFirstTime.toString());
              prefs.setBool(
                  UserPreference.IS_USER_LOGIN_FIRST_TIME, userLoginFirstTime);

              prefs.setString(UserPreference.DOB, dob);

              roleId = "2";
              String token = response.data['result']['token'].toString();
              bool isPasswordChanged =
                  response.data['result']['isPasswordChanged'];
              if (widget.signupType == "apple" ||
                  widget.signupType == "google") {
                isPasswordChanged = true;
              }
              userList.add(new UserData(userId, firstName, lastName, email,
                  salt, mobileNo, profilePicture, roleId));
              print("user Login id" + userId);

              prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
              String isActive = response.data['result']['isActive'].toString();
              String isHide = response.data['result']['isHide'].toString();
              prefs.setString(UserPreference.ISHide, isHide);
              prefs.setString(UserPreference.ISACTIVE, isActive);
              prefs.setString(UserPreference.chat_skip_count, "0");
              prefs.setBool(UserPreference.LOGIN_STATUS, true);
              prefs.setString(UserPreference.ROLE_ID, roleId);
              print("user RoleId test+++" + roleId);
              Constant.ROLE_ID = roleId;

              prefs.setBool(
                  UserPreference.IS_PASSWORD_CHANGED, isPasswordChanged);
              prefs.setBool(UserPreference.IS_PROFILECRETED_BY_PARENT,
                  ProfileCreatedByParent);

              prefs.setString(UserPreference.USER_ID, userId);
              prefs.setBool(
                  UserPreference.IS_PARENT, roleId == "2" ? true : false);
              prefs.setString(UserPreference.PARENT_ID, userId);
              if(strFirstName==null||strFirstName=="null"||strFirstName==""){
                prefs.setString(UserPreference.NAME, "");
              }else {
                prefs.setString(UserPreference.NAME, firstName + " " + lastName);
              }


              prefs.setString(UserPreference.EMAIL, email);
              prefs.setString(UserPreference.MOBILE, mobileNo);
              prefs.setString(UserPreference.PASSWORD, "");

              prefs.setString(
                  UserPreference.PROFILE_IMAGE_PATH, profilePicture);
              prefs.setString(
                  UserPreference.COMPANY_IMAGE_PATH, companyProfilePicture);

              prefs.setString(UserPreference.COMPANY_NAME_PATH, companyName);

              prefs.setString(UserPreference.USER_TOKEN, "Spike " + token);
              String path = "";
              try {
                path = prefs.getString(UserPreference.PATHURL);
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(e,"parentSignup",context);
              }

              String requireParentApproval =
                  response.data['result']['requireParentApproval'].toString();
              String isPasswordChanged1 =
                  response.data['result']['isPasswordChanged'].toString();
              if (widget.signupType == "apple" ||
                  widget.signupType == "google") {
                isPasswordChanged1 = "true";
              }
              String ccToParents =
                  response.data['result']['ccToParents'].toString();
              String lastAccess =
                  response.data['result']['lastAccess'].toString();
              String organizationId =
                  response.data['result']['organizationId'].toString();
              String gender = response.data['result']['gender'].toString();
              if (gender == "Non-binary" || gender == "NonBinary") {
                gender = "Non-Binary";
              }
              String genderAtBirth =
                  response.data['result']['genderAtBirth'].toString();
              String usCitizenOrPR =
                  response.data['result']['usCitizenOrPR'].toString();
              String summary = response.data['result']['summary'].toString();
              String coverImage =
                  response.data['result']['coverImage'].toString();
              String tagline = response.data['result']['tagline'].toString();
              String title = response.data['result']['title'].toString();
              String tempPassword =
                  response.data['result']['tempPassword'].toString();
              String isArchived =
                  response.data['result']['isArchived'].toString();
              String groupId = response.data['result']['groupId'].toString();
              String groupName =
                  response.data['result']['groupName'].toString();
              String groupImage =
                  response.data['result']['groupImage'].toString();
              String zipCode = response.data['result']['zipCode'].toString();
              bool referralPopup = response.data['result']['referralPopup'];
              String stage = response.data['result']['stage'].toString();
              String creationTime = "0";
              creationTime = response.data['result']['creationTime'].toString();
              if (creationTime == "null") {
                creationTime = "0";
              }

              bool isPublicUrlActive =
                  response.data['result']['isPublicUrlActive'];
              if (isPublicUrlActive == "null") {
                isPublicUrlActive = false;
              }

              bool isPublicProfileGlobalyActive =
                  response.data['result']['isPublicProfileGlobalyActive'];
              if (isPublicProfileGlobalyActive == null ||
                  isPublicProfileGlobalyActive == "null") {
                isPublicProfileGlobalyActive = false;
              }

              String publicUrl =
                  response.data['result']['publicUrl'].toString().trim();
              if (publicUrl == "null") {
                publicUrl = "";
              }

              String referCode =
                  response.data['result']['referCode'].toString();
              String schoolCode = response.data['result']['schoolCode'].toString();
              if (schoolCode == "null" || schoolCode == "") {
                schoolCode = "";
              }
              bool isPreLoginSetting =
                  response.data["result"]["isLeaderboardDisplay"];
              if (isPreLoginSetting == null) {
                isPreLoginSetting = false;
              }
              prefs.setBool(UserPreference.IS_PRE_LOGIN, isPreLoginSetting);

              String badgeImage =
                  response.data['result']['badgeImage'].toString();
              if (badgeImage == null ||
                  badgeImage == "null" ||
                  badgeImage == "") {
                badgeImage = "";
              }
              String badge = response.data['result']['badge'].toString();
              if (badge == null || badge == "null" || badge == "") {
                badge = "";
              }
              String gamification =
                  response.data['result']['gamificationPoints'].toString();
              int gamificationPoints;
              if (gamification == null ||
                  gamification == "" ||
                  gamification == "null") {
                gamificationPoints = 0;
              } else {
                gamificationPoints = int.parse(gamification);
              }

              prefs.setString(UserPreference.referCode, referCode);
              prefs.setString(UserPreference.badgeType, badge);
              prefs.setInt(
                  UserPreference.gamificationPoints, gamificationPoints);
              prefs.setString(UserPreference.badgeImage, badgeImage);

              if (referralPopup == null || referralPopup == "null") {
                referralPopup = false;
              }

              List<SocialLinkData> socialLinkList =  List();
              var socalLinkMap = response.data['result']['socialLinks'];
              if (socalLinkMap != null && socalLinkMap.length > 0) {
                for (int i = 0; i < socalLinkMap.length; i++) {
                  String image = socalLinkMap[i]['image'].toString();
                  String socialName = socalLinkMap[i]['socialName'].toString();
                  String socialUrl = socalLinkMap[i]['socialUrl'].toString();
                  int socialId = socalLinkMap[i]['socialId'];

                  socialLinkList.add(new SocialLinkData(
                      image: image,
                      socialName: socialName,
                      socialUrl: socialUrl,
                      socialId: socialId));
                }
              }

              ProfileInfoModal profileInfoModal =  ProfileInfoModal(
                  userId,
                  firstName,
                  lastName,
                  email,
                  mobileNo,
                  profilePicture,
                  roleId,
                  isActive,
                  requireParentApproval,
                  ccToParents,
                  lastAccess,
                  isPasswordChanged1,
                  organizationId,
                  gender,
                  dob,
                  genderAtBirth,
                  usCitizenOrPR,
                  null,
                  summary,
                  coverImage,
                  tagline,
                  title,
                  tempPassword,
                  isArchived,
                  null,
                  false,
                  groupId,
                  groupName,
                  groupImage,
                  "",
                  "",
                  zipCode,
                  isHide,
                  referralPopup,
                  userLoginFirstTime,
                  stage,
                  creationTime,
                  badge,
                  gamificationPoints,
                  badgeImage,
                  referCode,
                  socialLinkList,
                  publicUrl,
                  isPublicUrlActive,
                  isPublicProfileGlobalyActive,
                  null,
                  company,
                  false,
                  false,
                  null,schoolCode,'',"",false,false);

              prefs.setString(
                  UserPreference.CREATION_TIME, profileInfoModal.creationTime);
              prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
              prefs.setString(UserPreference.ZIPCODE, profileInfoModal.zipCode);
              prefs.setString(UserPreference.NAME,
                  profileInfoModal.firstName + " " + profileInfoModal.lastName);
              prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                  profileInfoModal.profilePicture);

              prefs.setString(UserPreference.TAGLINE, profileInfoModal.tagline);
              prefs.setString(
                  UserPreference.ISACTIVE, profileInfoModal.isActive);

              Navigator.of(context).popUntil((route) => route.isFirst);
              goto();
            }
            else if (widget.isRedirectToRecommendation) {
              prefs.setBool(UserPreference.LOGIN_STATUS, true);
              prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
              prefs.setBool(UserPreference.IS_USER_LOGIN_FIRST_TIME, true);
              prefs.setBool(UserPreference.IS_PARENT, true);
              prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");
              prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
              prefs.setString(UserPreference.IS_USER_ROLE, "false");
              prefs.setString(UserPreference.ROLE_ID, "2");

              prefs.setBool(UserPreference.IS_ADDED_DOB, false);
              prefs.setBool(UserPreference.IS_UNDER_AGE, true);
              // Api call for get setting data

              Constant.ROLE_ID = "2";
              prefs.setString(UserPreference.NAME,
                  firstNameController.text + " " + lastNameController.text);
              prefs.setString(UserPreference.EMAIL, emailController.text);
              prefs.setString(UserPreference.PASSWORD, strNewPassword);
              processForUri(path, strEmail.toLowerCase());
            } else {
              prefs.setString(UserPreference.PATHURL, "");
              showSucessMsgLong(message, context);
            }
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e,"parentSignup",context);
        if (mounted) CustomProgressLoader.cancelLoader(context);

        print(e);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  bool isShowConformationDialog() {
    if (firstNameController.text.length > 0 ||
        lastNameController.text.length > 0 ||
        emailController.text.length > 0) {
      return true;
    }
    return false;
  }

  void _checkValidation() async {
    try {
      final form = formKey.currentState;
      form.save();

      if (form.validate()) {
        setState(() {
          isValid = true;
        });
        if (!isParentAge) {
          ToastWrap.showToast(MessageConstant.OVER_18_CONFORM_ERROR, context);
        } else {
          if (widget.isRedirectToRecommendation) {
            if (strNewPassword.length >= 8) {
              if (ValidationWidget.NumberChara(strNewPassword)) {
                if (ValidationWidget.upper_case(strNewPassword)) {
                  if (ValidationWidget.lower_case(strNewPassword)) {
                    if (ValidationWidget.specialCha(strNewPassword)) {
                      loginServiceCall();
                    }
                  }
                }
              }
            }
          } else {
            loginServiceCall();
          }
        }
        //     loginServiceCall();

      }
    } catch (e) {
      print("error+++" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e,"parentSignup",context);
    }
  }

  bool _newPassObscureText = true;

  String strNewPassword = "";

  TextEditingController firstNameController =
       TextEditingController(text: "");
  TextEditingController lastNameController =
       TextEditingController(text: "");
  TextEditingController emailController =  TextEditingController(text: "");

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    token = prefs.getString(UserPreference.USER_TOKEN);
    String roleId = prefs.getString(UserPreference.ROLE_ID);
    String name = prefs.getString(UserPreference.NAME);
    String email = prefs.getString(UserPreference.EMAIL);
    if(MediaQuery.of(context).size.height<=750){
      setRecommendationPadding();
    }
    if (email != null && email != "notdelete@gmail.com") {
      emailController =  TextEditingController(text: email);
      firstNameController =  TextEditingController(text: name.split(" ")[0]);
      lastNameController =  TextEditingController(text: name.split(" ")[1]);
      setState(() {
        emailController;
        firstNameController;
        lastNameController;
      });
    }
  }

  linkPreferences() async {
    prefs = await SharedPreferences.getInstance();
    linkUrl = prefs.getString(UserPreference.PATHURL);

    if (linkUrl == null) {
      linkUrl = "";
    }

    if (linkUrl == "" || linkUrl == " ") {
    } else {
      if (linkUrl.contains("referNow")) {
        // https://spikeview.com/referNow?userId=1830&roleId=1&email=sk1213@yopmail.com&pass=null
        List<String> mesagelist = linkUrl.split("=");

        referalUserId = mesagelist[1].replaceAll("&roleId", "");
        referalUserRoleId = mesagelist[2].replaceAll("&email", "");
        String email = mesagelist[3].replaceAll("&pass", "");

        emailController =  TextEditingController(text: email);
      }

      setState(() {
        //  prefs.setString(UserPreference.PATHURL, "");
        emailController;
      });
    }
  }

  void conformationDialogForBackNavigation(back) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.fromLTRB(
                                                15.0, 10.0, 15.0, 10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    MessageConstant.PARENT_DISCARD_ALL_CHANGES,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                             MessageConstant.CANCEL,
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              MessageConstant.PARENT_OK,
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              if (back == "back") {
                                                Navigator.pop(context);
                                              } else {
                                                if (widget.pageName ==
                                                    "Login") {
                                                  Navigator.of(context)
                                                      .popUntil((route) =>
                                                          route.isFirst);
                                                } else {
                                                  Navigator.of(context)
                                                      .popUntil((route) =>
                                                          route.isFirst);
                                                  Navigator.of(context)
                                                      .pushReplacement(
                                                           MaterialPageRoute(
                                                              builder: (BuildContext
                                                                      context) =>
                                                                   LoginPage(
                                                                      null)));
                                                }
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  double padding0=10.0,padding1=30.0,padding2=25.0,padding3=15.0,padding4=25.0,padding5=30.0;
  double padding6=30.0;

  setRecommendationPadding(){
    padding0=5.0; padding1=20.0;padding2=20.0;padding3=10.0;padding4=20.0;padding5=9.0;
    setState(() {

    });

  }


bool isSetPadding=false;
  @override
  void initState() {
    // genderList.add("Gender");
    if ((widget.isRedirectToRecommendation)) {
      getSharedPreferences();
      isSetPadding=true;
      setRecommendationPadding();
      print("data++++getSharedPreferences");
    } else {
      print("data++++linkPreferences");
      linkPreferences();
    }
    if (widget.email != "") {
      emailController.text = widget.email;
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;

    final upperLogo =  Image(
      image:  AssetImage("assets/logo.png"),
      color: null,
      width: 130.0,
      height: 70.0,
      fit: BoxFit.contain,
    );

    final newPasswordUI =  Padding(
      padding:
           EdgeInsets.only(left: 13.0, top: padding3, right: 13.0, bottom: 0.0),
      child:  Theme(
          data:  ThemeData(
              backgroundColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor:  ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor:  ColorValues.LIGHT_GREY_TEXT_COLOR),
          child:  TextFormField(
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_PASSWORD_VAL
                : null,
            onSaved: (val) => strNewPassword = val,
            cursorColor: Constant.CURSOR_COLOR,
            textInputAction: TextInputAction.done,
            obscureText: _newPassObscureText,
            style:  TextStyle(
                color: ColorValues.HEADING_COLOR_EDUCATION,
                fontSize: 16.0,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            autofocus: false,
            decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 7.0, 5.0, 10.0),
              focusedBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              suffixIcon:  GestureDetector(
                child:  Padding(
                  padding:  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                  child: _newPassObscureText
                      ?  Image.asset(
                          "assets/newDesignIcon/login/hide.png",
                          width: 30.0,
                          height: 30.0,
                        )
                      :  Image.asset(
                    "assets/newDesignIcon/login/unhide.png",
                    width: 30.0,
                    height: 30.0,color: AppConstants.colorStyle.lightPurple,
                  ),
                ),
                onTap: () {
                  if (_newPassObscureText)
                    _newPassObscureText = false;
                  else
                    _newPassObscureText = true;

                  setState(() {
                    _newPassObscureText;
                  });
                },
              ),
              labelText: MessageConstant.PARENT_PASSWORD,
              errorStyle: Util.errorTextStyle,
              errorMaxLines: 3,
              labelStyle:  TextStyle(
                  color: Colors.grey, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    final referalCodeField =  Padding(
      padding: EdgeInsets.only(left: 13.0, top: 0.0, right: 13.0, bottom: 0.0),
      child:  Theme(
          data:  ThemeData(
              backgroundColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor:  ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor:  ColorValues.LIGHT_GREY_TEXT_COLOR),
          child:  TextFormField(
            keyboardType: TextInputType.text,
            controller: referalController,
            focusNode: referalFocusNode,
            textInputAction: TextInputAction.done,
            cursorColor: Constant.CURSOR_COLOR,

            style:  TextStyle(
                color:  ColorValues.HEADING_COLOR_EDUCATION,
                fontSize: 22.0,
                fontFamily: Constant.TYPE_CUSTOMBOLD),
            decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              counterText: "",
              focusedBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),

              labelText: "",
              errorStyle: Util.errorTextStyle,
              labelStyle:  TextStyle(
                  color:  ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    final userFirstNameUi =  Padding(
      padding:
           EdgeInsets.only(left: 13.0, top: 0.0, right: 13.0, bottom: 0.0),
      child:  Theme(
          data:  ThemeData(
              backgroundColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor:  ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor:  ColorValues.LIGHT_GREY_TEXT_COLOR),
          child:  TextFormField(
            keyboardType: TextInputType.text,
            controller: firstNameController,
            textInputAction: TextInputAction.next,
            focusNode: firstNameFocus,
            onFieldSubmitted: (term) {
              _fieldFocusChange(context, firstNameFocus, lastNameFocus);
            },
            textCapitalization: TextCapitalization.sentences,
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_FIRST_NAME_VAL
                : !ValidationWidget.isName(val)
                ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                : null
            /*

            val.trim().length == 0
                ? MessageConstant.ENTER_FIRST_NAME_VAL
                : !ValidationWidget.isName(val.trim())
                    ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                    : null*/,
            onSaved: (val) => strFirstName = val.trim(),
            cursorColor: Constant.CURSOR_COLOR,
            style:
                 TextStyle(color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
            decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 7.0, 5.0, 10.0),

              focusedBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              labelText: MessageConstant.PARENT_FIRST_NAME,
              errorStyle: Util.errorTextStyle,
              counterText: "",
              labelStyle:  TextStyle(
                  color:  ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    final lastNameUi =  Padding(
      padding:
           EdgeInsets.only(left: 13.0, top: padding3, right: 13.0, bottom: 0.0),
      child:  Theme(
          data:  ThemeData(
              backgroundColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor:  ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor:  ColorValues.LIGHT_GREY_TEXT_COLOR),
          child:  TextFormField(
            keyboardType: TextInputType.text,
            maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
            controller: lastNameController,
            textInputAction: TextInputAction.next,
            focusNode: lastNameFocus,
            onFieldSubmitted: (term) {
              _fieldFocusChange(context, lastNameFocus, emailFocus);
            },
            cursorColor: Constant.CURSOR_COLOR,
            textCapitalization: TextCapitalization.sentences,
            validator: (val) =>val.trim().length == 0
                ? MessageConstant.ENTER_LAST_NAME_VAL
                : !ValidationWidget.isName(val.trim())
                ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                : null



           /* val.trim().length == 0
                ? MessageConstant.ENTER_LAST_NAME_VAL
                :
                null*/,
            onSaved: (val) => strLastName = val.trim(),
            style:
                 TextStyle(color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 7.0, 5.0, 10.0),

              focusedBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              labelText: MessageConstant.PARENT_LAST_NAME,
              errorStyle: Util.errorTextStyle,
              counterText: "",
              labelStyle:  TextStyle(
                  color:  ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    Text getTextLab(txt, size, color, fontWeight) {
      return  Text(
        txt,
        textAlign: TextAlign.start,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final emailUi =  Padding(
      padding:
           EdgeInsets.only(left: 13.0, top: padding3, right: 13.0, bottom: 0.0),
      child:  Theme(
          data:  ThemeData(
              backgroundColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor:  ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor:  ColorValues.LIGHT_GREY_TEXT_COLOR),
          child:  TextFormField(
            controller: emailController,
            textInputAction: TextInputAction.done,
            focusNode: emailFocus,
            onFieldSubmitted: (term) {},
            keyboardType: TextInputType.emailAddress,
            cursorColor: Constant.CURSOR_COLOR,
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_EMAIL_VAL
                : !ValidationWidget.isEmail(val)
                    ? MessageConstant.VALID_EMAIL_VAL
                    : null,
            onSaved: (val) => strEmail = val,
            enabled:
                widget.signupType == "apple" || widget.signupType == "google"
                    ? false
                    : widget.isRedirectToRecommendation
                        ? false
                        : referalUserId != "" ? false : true,
            style:
                 TextStyle(color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR,fontSize: 16.0),
            decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 7.0, 5.0, 10.0),

              focusedBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              labelText:MessageConstant.PARENT_EMAIL,
              errorStyle: Util.errorTextStyle,
              counterText: "",
              labelStyle:  TextStyle(
                  color:  ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    final studentEmailUi =  Padding(
      padding:
           EdgeInsets.only(left: 30.0, top: 5.0, right: 30.0, bottom: 10.0),
      child:  TextFormField(
        keyboardType: TextInputType.emailAddress,
        cursorColor: Constant.CURSOR_COLOR,
        validator: (val) => val.trim().length == 0
            ? MessageConstant.ENTER_EMAIL_VAL
            : !ValidationWidget.isEmail(val)
                ? MessageConstant.VALID_EMAIL_VAL
                : null,
        onSaved: (val) => strStudentyEmail = val,
        style:  TextStyle(color: Colors.white, fontFamily: Constant.TYPE_CUSTOMREGULAR),
        decoration:  InputDecoration(
          prefixIcon:  GestureDetector(
              child:  Padding(
            padding:  EdgeInsets.fromLTRB(10.0, 7.0, 10.0, 10.0),
            child:  Image.asset(
              "assets/login/email.png",
              width: 13.0,
              height: 13.0,
            ),
          )),
          focusedBorder:  UnderlineInputBorder(
              borderSide:  BorderSide(
                  color:  ColorValues.DARK_GREY, width: 1.0)),
          enabledBorder:  UnderlineInputBorder(
              borderSide:  BorderSide(
                  color:  ColorValues.DARK_GREY, width: 1.0)),
          border:  UnderlineInputBorder(
              borderSide:  BorderSide(
                  color:  ColorValues.DARK_GREY, width: 1.0)),
          hintText: MessageConstant.PARENT_STUDENT_EMAIL,
          labelStyle:
               TextStyle(color: Colors.white, fontFamily: Constant.TYPE_CUSTOMREGULAR),
        ),
      ),
    );

    final studentNameUi =  Padding(
      padding:
           EdgeInsets.only(left: 30.0, top: 5.0, right: 30.0, bottom: 10.0),
      child:  TextFormField(
        keyboardType: TextInputType.text,
        maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
        validator: (val) => val.trim().length == 0
            ? MessageConstant.ENTER_STUDENT_FIRST_NAME_VAL
            : !ValidationWidget.isName(val.trim())
                ? MessageConstant.STUDENT_FIRST_NAME_CONTAIN_ALPHABET_VAL
                : null,
        textCapitalization: TextCapitalization.sentences,
        cursorColor: Constant.CURSOR_COLOR,
        onSaved: (val) => strStudentFirstName = val.trim(),
        style:  TextStyle(color: Colors.white, fontFamily: Constant.TYPE_CUSTOMREGULAR),
        decoration:  InputDecoration(
            prefixIcon:  GestureDetector(
                child:  Padding(
              padding:  EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 10.0),
              child:  Image.asset(
                "assets/login/user.png",
                width: 13.0,
                height: 13.0,
              ),
            )),
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(color: Colors.white)),
            hintText: MessageConstant.PARENT_STUDENT_FIRST_NAME,
            counterText: "",
            labelStyle:
                 TextStyle(color: Colors.white, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            border:  UnderlineInputBorder(
                borderSide:  BorderSide(color: Colors.white))),
      ),
    );

    final studentLastName =  Padding(
      padding:
           EdgeInsets.only(left: 30.0, top: 5.0, right: 30.0, bottom: 10.0),
      child:  TextFormField(
        keyboardType: TextInputType.text,
        maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
        cursorColor: Constant.CURSOR_COLOR,
        textCapitalization: TextCapitalization.sentences,
        validator: (val) => val.trim().length == 0
            ? MessageConstant.ENTER_STUDENT_LAST_NAME_VAL
            : !ValidationWidget.isName(val.trim())
                ? MessageConstant.STUDENT_LAST_NAME_CONTAIN_ALPHABET_VAL
                : null,
        onSaved: (val) => strStudentLastName = val.trim(),
        style:  TextStyle(color: Colors.white, fontFamily: Constant.TYPE_CUSTOMREGULAR),
        decoration:  InputDecoration(
            prefixIcon:  GestureDetector(
                child:  Padding(
              padding:  EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 10.0),
              child:  Image.asset(
                "assets/login/user.png",
                width: 13.0,
                height: 13.0,
              ),
            )),
            focusedBorder:  UnderlineInputBorder(
                borderSide:  BorderSide(color: Colors.white)),
            hintText:MessageConstant.PARENT_STUDENT_LAST_NAME,
            counterText: "",
            labelStyle:
                 TextStyle(color: Colors.white, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            border:  UnderlineInputBorder(
                borderSide:  BorderSide(color: Colors.white))),
      ),
    );

    Text getTextLabel(txt, size, color, fontWeight) {
      return  Text(
        txt,
        style:
             TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final loginButton =  Container(
        child: Padding(
            padding:  EdgeInsets.only(
                left: 0.0, top: 0.0, right: 0.0, bottom: 13.0),
            child: Stack(
              children: <Widget>[
                 Container(
                    height: 44.0,
                    width: double.infinity,
                    child: FlatButton(
                      onPressed: () {
                        FocusScope.of(context).unfocus();
                        final form = formKey.currentState;
                        form.save();
                        if (widget.isRedirectToRecommendation) {
                          if (strNewPassword != null && strNewPassword.length > 0) {
                            if (strNewPassword.length < 8) {
                              setState(() {
                                password_error_lenght = true;
                              });
                            } else {
                              setState(() {
                                password_error_lenght = false;
                              });
                            }

                            if (!ValidationWidget.NumberChara(strNewPassword)) {
                              setState(() {
                                password_error_number = true;
                              });
                            } else {
                              setState(() {
                                password_error_number = false;
                              });
                            }

                            if (!ValidationWidget.upper_case(strNewPassword)) {
                              setState(() {
                                password_error_upper = true;
                              });
                            } else {
                              setState(() {
                                password_error_upper = false;
                              });
                            }

                            if (!ValidationWidget.lower_case(strNewPassword)) {
                              setState(() {
                                password_error_lower = true;
                              });
                            } else {
                              setState(() {
                                password_error_lower = false;
                              });
                            }

                            if (!ValidationWidget.specialCha(strNewPassword)) {
                              setState(() {
                                password_error_specile = true;
                              });
                            } else {
                              setState(() {
                                password_error_specile = false;
                              });
                            }
                          } else {
                            setState(() {
                              password_error_specile = false;
                              password_error_lower = false;
                              password_error_upper = false;
                              password_error_number = false;
                              password_error_lenght = false;
                            });
                          }

                          if (isAgree) _checkValidation();
                        } else {
                          if (isAgree) _checkValidation();
                        }
                      },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(0)),
                      color:   ColorValues.BLUE_COLOR_BOTTOMBAR
                         ,
                      child: Row(
                        // Replace with a Row for horizontal icon + text
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(MessageConstant.PARENT_CONTINUE,
                              style: TextStyle(
                                  fontSize: 16.0,
                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,fontWeight: FontWeight.w400,
                                  color: Colors.white)),
                        ],
                      ),
                    )),
                isAgree?new Container(height:0.0):  Container(height:44.0,color: Colors.white.withOpacity(.5),)
              ],
            )));

    Widget showReferelPopUp(context) {
      showModalBottomSheet(
          context: context,
          backgroundColor: Colors.white,

          isScrollControlled: true,
          builder: (BuildContext context) {
            return StatefulBuilder(
                builder: (BuildContext context, StateSetter myState
                    /*You can rename this!*/) {
              return Form(
                  key: formKeyReferal,
                  child: Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom,
                      left: 0, //11.0,
                      right: 0, // 11.0,
                    ),
                    child: Container(
                      height: 275.0,
                      //color: Colors.black.withOpacity(0.8),
                      color: Colors.white,
                      child:  Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                            child:  Container(
                                height: 4.0,
                                width: 58.0,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color:  ColorValues.GREY__COLOR,
                                )),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(15.0, 40, 35, 0),
                            child: TextViewWrap.textView(
                                MessageConstant.PARENT_REFERRAL_CODE,
                                TextAlign.start,
                                 ColorValues.HEADING_COLOR_EDUCATION,
                                20.0,
                                FontWeight.normal),
                          ),
                          referalCodeField,
                          Padding(
                              padding:  EdgeInsets.only(
                                  left: 20.0,
                                  top: 40.0,
                                  right: 20.0,
                                  bottom: 15.0),
                              child:  InkWell(
                                child:  Container(
                                    height: 44.0,
                                    //width: 226.0,
                                    color:  ColorValues.BLUE_COLOR,
                                    child:  Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                         Text(
                                          MessageConstant.PARENT_CONFIRM,
                                          style:  TextStyle(
                                            color: Colors.white,
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 20.0,
                                          ),
                                        )
                                      ],
                                    )),
                                onTap: () {

                                  callApiToValidateTheaReferalCode('');
                                  //   }
                                },
                              ))
                        ],
                      ),
                    ),
                  ));
            });
          }).then((value) => (value) {});
    }

    textFormFieldDecorationWithNoBorders(String name, {String helperText}) {
      return InputDecoration(
        contentPadding: const EdgeInsets.fromLTRB(
          0.0,
          5.0,
          5.0,
          5.0,
        ),
        labelText: name,
        errorStyle: TextStyle(
            fontFamily: AppTextStyle.getFont(FontType.Regular),
            color: Palette.redColor),
        helperText: helperText,
        helperStyle: AppTextStyle.getDynamicFontStyle(
            Palette.secondaryTextColor, 12, FontType.Regular),
        hintStyle: AppTextStyle.getDynamicFontStyle(
            ColorValues.hintColor, 14, FontType.Regular),
        labelStyle:  TextStyle(
            color:  ColorValues.GREY_TEXT_COLOR,
            fontFamily: Constant.TYPE_CUSTOMREGULAR),
        enabledBorder: InputBorder.none,
        focusedBorder: InputBorder.none,
        border: InputBorder.none,
      );
    }

    final bottomBarView =Container(
      // color:  ColorValues.HEADING_COLOR_EDUCATION,
        padding: EdgeInsets.only(left: 4.0, right: 4.0),
        height:50 + MediaQuery.of(context).padding.bottom,
        child:Column(
          children: <Widget>[

            Padding(
                padding:  EdgeInsets.only(
                    left: 0.0, right: 0.0, top: 0, bottom: 0),
                child: Container(
                  child: Column(
                    children: <Widget>[

                      Padding(
                          padding:  EdgeInsets.only(
                              left: 13.0, right: 13.0, top:15 , bottom: 15),
                          child:  Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15.0,
                                        right: 0.0,
                                        top: 0.0,
                                        bottom: 0),
                                    child: InkWell(
                                        onTap: (){
                                          Navigator.push(
                                              Constant
                                                  .applicationContext,
                                               MaterialPageRoute(
                                                  builder: (context) =>  WebViewWidget(
                                                      Constant
                                                          .CARRER,
                                                      MessageConstant.PARENT_CAREER)));
                                        },
                                        child:new Text(
                                          MessageConstant.PARENT_CAREERS,
                                          textAlign: TextAlign.start,
                                          style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 12.0,
                                              fontWeight: FontWeight.w400),
                                        )),
                                  ),
                                  flex: 0),
                              Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15.0,
                                        right: 0.0,
                                        top: 0.0,
                                        bottom: 0),
                                    child: InkWell(
                                        onTap: (){
                                          Navigator.push(
                                              Constant
                                                  .applicationContext,
                                               MaterialPageRoute(
                                                  builder: (context) =>  WebViewWidget(
                                                      Constant
                                                          .PRIVACY_POLICY,
                                                     MessageConstant.PARENT_PRIVACY_POLICY)));
                                        },
                                        child:new Text(
                                          MessageConstant.PARENT_PRIVACY_POLICY,
                                          textAlign: TextAlign.center,
                                          style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 12.0,
                                              fontWeight: FontWeight.w400),
                                        )),
                                  ),
                                  flex: 0),
                              Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15.0,
                                        right: 0.0,
                                        top: 0.0,
                                        bottom: 0),
                                    child: InkWell(
                                        onTap: (){
                                          Navigator.push(
                                              Constant
                                                  .applicationContext,
                                               MaterialPageRoute(
                                                  builder: (context) =>  WebViewWidget(
                                                      Constant
                                                          .FAQ,
                                                     MessageConstant.PARENT_FAQS)));
                                        },
                                        child:new Text(
                                         MessageConstant.PARENT_FAQS,
                                          textAlign: TextAlign.center,
                                          style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 12.0,
                                              fontWeight: FontWeight.w400),
                                        )),
                                  ),
                                  flex: 0),
                              Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15.0,
                                        right: 15.0,
                                        top: 0.0,
                                        bottom: 0),
                                    child: InkWell(
                                        onTap: (){
                                          Navigator.push(
                                              Constant
                                                  .applicationContext,
                                               MaterialPageRoute(
                                                  builder: (context) =>  WebViewWidget(
                                                      Constant
                                                          .TERMS,
                                                     MessageConstant.PARENT_TERMS_DATA)));
                                        },
                                        child:new Text(
                                         MessageConstant.PARENT_TERMS_SERVICE,
                                          textAlign: TextAlign.end,
                                          style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 12.0,
                                              fontWeight: FontWeight.w400),
                                        )),
                                  ),
                                  flex: 0),
                            ],
                          )),
                    ],
                  ),
                )),
          ],
        ));
    return  GestureDetector(
        child: WillPopScope(
            onWillPop: () {
              if (isShowConformationDialog()) {
                conformationDialogForBackNavigation("back");
              } else {
                Navigator.pop(context);
              }
            },
            child:  Scaffold(
                backgroundColor:  ColorValues.WHITE,

                bottomNavigationBar: bottomBarView,
                body: FormKeyboardActions(
                    nextFocus: false,
                    keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                    //optional
                    keyboardBarColor: Colors.grey[200],
                    //optional
                    actions: [],
                    child: Container(
                            color: Colors.white,
                            child: ListView(
                      children: <Widget>[
                         Container(
                          child: Form(
                              key: formKey,
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 0.0, 0.0, 0.0),
                                child: Column(
                                  children: <Widget>[
                                     Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[

                                        Padding(
                                            padding:
                                            EdgeInsets
                                                .only(
                                                left:
                                                0.0,
                                                right:
                                                0.0,
                                                top: 10,
                                                bottom:
                                                45),
                                            child:  Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              children: <Widget>[
                                                 Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.fromLTRB(
                                                        0.0, 0.0, 0.0, 0.0),
                                                    child:  InkWell(
                                                      child:  SizedBox(
                                                        height: 40.0,
                                                        width: 30.0,
                                                        child: PaddingWrap.paddingfromLTRB(
                                                            4.0,
                                                            0.0,
                                                            0.0,
                                                            3.0,
                                                             Center(
                                                                child:  Image.asset(
                                                                  "assets/newDesignIcon/navigation/back.png",
                                                                  height: 20.0,
                                                                  width: 10.0,
                                                                  fit: BoxFit.fitHeight,
                                                                  color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                                ))),
                                                      ),
                                                      onTap: () {
                                                        if (isShowConformationDialog()) {
                                                          conformationDialogForBackNavigation("back");
                                                        } else {
                                                          Navigator.pop(context);
                                                        }
                                                      },
                                                    ),
                                                  ),
                                                  flex: 0,
                                                ),
                                                 Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(top:5.0),
                                                    child:new Image
                                                      .asset(
                                                    "assets/newDesignIcon/navigation/spike_logo_login.png",
                                                    height:
                                                    32.0,
                                                    width:
                                                    116.0,
                                                  )),
                                                  flex: 1,
                                                ),
                                                 Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.fromLTRB(
                                                        0.0, 0.0, 0.0, 0.0),
                                                    child:  InkWell(
                                                      child:  SizedBox(
                                                        height: 40.0,
                                                        width: 30.0,
                                                        child:  Container(),
                                                      ),

                                                    ),
                                                  ),
                                                  flex: 0,
                                                ),
                                              ],
                                            )),


                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: <Widget>[

                                             Expanded(
                                              child:  Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Padding(
                                                    padding: const EdgeInsets.only(
                                                        left: 13.0,
                                                        right: 13.0,
                                                        top: 2.0,
                                                        bottom: 28),
                                                    child:  Text(
                                                      MessageConstant.PARENT_YOU_SIGNING_ASA_PARENT,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                          fontSize: 22.0,
                                                          fontWeight: FontWeight.w700),
                                                    ),
                                                  ),

                                                ],
                                              ),
                                              flex: 1,
                                            )
                                          ],
                                        ),
                                        widget.signupType == "apple" ||
                                                widget.signupType == "google"
                                            ? Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        13.0, 15.0, 13.0, 0.0),
                                                child:  Row(
                                                  children: <Widget>[
                                                     Expanded(
                                                      child:  InkWell(
                                                        child:  Container(
                                                          height: 50.0,
                                                          width: 50.0,
                                                          child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        100),
                                                            child: widget
                                                                        .image !=
                                                                    ""
                                                                ?  CachedNetworkImage(
                                                                    height:
                                                                        50.0,
                                                                    width: 50.0,
                                                                    imageUrl:
                                                                        widget
                                                                            .image,
                                                                    fit: BoxFit
                                                                        .cover,
                                                                    placeholder: (context,
                                                                            url) =>
                                                                         Image.asset(
                                                                            'assets/profile/user_on_user.png'),
                                                                    errorWidget: (context,
                                                                            url,
                                                                            error) =>
                                                                         Image.asset(
                                                                            'assets/profile/user_on_user.png'),
                                                                  )
                                                                :  Image
                                                                        .asset(
                                                                    'assets/profile/user_on_user.png'),
                                                          ),
                                                        ),
                                                        onTap: () {},
                                                      ),
                                                      flex: 0,
                                                    ),
                                                     Expanded(
                                                      child:
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  10.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                   Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: <
                                                                        Widget>[
                                                                      widget.firstName ==
                                                                              ""
                                                                          ?  Container(
                                                                              height:
                                                                                  0.0)
                                                                          : TextViewWrap.textView(
                                                                              widget.firstName + " " + widget.lastName,
                                                                              TextAlign.start,
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                              14.0,
                                                                              FontWeight.bold),
                                                                      TextViewWrap.textView(
                                                                          widget
                                                                              .email,
                                                                          TextAlign
                                                                              .start,
                                                                           Color(
                                                                              0xff9a9c9c),
                                                                          14.0,
                                                                          FontWeight
                                                                              .normal),
                                                                    ],
                                                                  )),
                                                      flex: 1,
                                                    ),
                                                     Expanded(
                                                      child:
                                                          widget.signupType ==
                                                                  "google"
                                                              ?  InkWell(
                                                                  child: TextViewWrap.textView(
                                                                      "Not You?",
                                                                      TextAlign
                                                                          .start,
                                                                       ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                      14.0,
                                                                      FontWeight
                                                                          .normal),
                                                                  onTap: () {
                                                                    Navigator.pop(
                                                                        context,
                                                                        "notYou");
                                                                  },
                                                                )
                                                              :  Container(
                                                                  height: 0.0,
                                                                ),
                                                      flex: 0,
                                                    ),
                                                  ],
                                                ))
                                            :  Container(height: 0.0),
                                        widget.signupType == "apple" ||
                                                widget.signupType == "google"
                                            ?  Container(height: 0.0)
                                            : userFirstNameUi,
                                        widget.signupType == "apple" ||
                                                widget.signupType == "google"
                                            ?  Container(height: 0.0)
                                            : lastNameUi,
                                        widget.signupType == "apple" ||
                                                widget.signupType == "google"
                                            ?  Container(height: 0.0)
                                            : emailUi,
                                        widget.isRedirectToRecommendation
                                            ? newPasswordUI
                                            :  Container(
                                                height: 0.0,
                                              ),
                                        widget.isRedirectToRecommendation
                                            ? password_error_lenght
                                                ? PaddingWrap.paddingfromLTRB(
                                                    13.0,
                                                    1.0,
                                                    13.0,
                                                    0.0,
                                                     Row(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Image.asset(
                                                          "assets/profile/red_cross.png",
                                                          width: 14.0,
                                                          height: 14.0,
                                                          color:
                                                              Colors.red[600],
                                                        ),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        TextViewWrap
                                                            .textViewMultiLine(
                                                               MessageConstant.PARENT_MINIMUM_8_CHA,
                                                                TextAlign.start,
                                                                Colors.red[600],
                                                                12.0,
                                                                FontWeight
                                                                    .normal,
                                                                1)
                                                      ],
                                                    ))
                                                :  Container(
                                                    height: 0.0,
                                                  )
                                            :  Container(
                                                height: 0.0,
                                              ),
                                        widget.isRedirectToRecommendation
                                            ? password_error_specile
                                                ? PaddingWrap.paddingfromLTRB(
                                                    13.0,
                                                    1.0,
                                                    13.0,
                                                    0.0,
                                                     Row(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [

                                                        Image.asset(
                                                          "assets/profile/red_cross.png",
                                                          width: 14.0,
                                                          height: 14.0,
                                                          color:
                                                              Colors.red[600],
                                                        ),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        TextViewWrap
                                                            .textViewMultiLine(
                                                              MessageConstant.PARENT_SPECIAL_CHARACTER,
                                                                TextAlign.start,
                                                                Colors.red[600],
                                                                12.0,
                                                                FontWeight
                                                                    .normal,
                                                                1)
                                                      ],
                                                    ))
                                                :  Container(
                                                    height: 0.0,
                                                  )
                                            :  Container(
                                                height: 0.0,
                                              ),
                                        widget.isRedirectToRecommendation
                                            ? password_error_upper ||
                                                    password_error_lower
                                                ? PaddingWrap.paddingfromLTRB(
                                                    13.0,
                                                    1.0,
                                                    13.0,
                                                    0.0,
                                                     Row(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Image.asset(
                                                          "assets/profile/red_cross.png",
                                                          width: 14.0,
                                                          height: 14.0,
                                                          color:
                                                              Colors.red[600],
                                                        ),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        TextViewWrap
                                                            .textViewMultiLine(
                                                               MessageConstant.PARENT_LOWER_UPPER_LETTER,
                                                                TextAlign.start,
                                                                Colors.red[600],
                                                                12.0,
                                                                FontWeight
                                                                    .normal,
                                                                1)
                                                      ],
                                                    ))
                                                :  Container(
                                                    height: 0.0,
                                                  )
                                            :  Container(
                                                height: 0.0,
                                              ),
                                        widget.isRedirectToRecommendation
                                            ? password_error_number
                                                ? PaddingWrap.paddingfromLTRB(
                                                    13.0,
                                                    1.0,
                                                    13.0,
                                                    0.0,
                                                     Row(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Image.asset(
                                                          "assets/profile/red_cross.png",
                                                          width: 14.0,
                                                          height: 14.0,
                                                          color:
                                                              Colors.red[600],
                                                        ),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        TextViewWrap
                                                            .textViewMultiLine(
                                                               MessageConstant.PARENT_ONE_NUMBER,
                                                                TextAlign.start,
                                                                Colors.red[600],
                                                                12.0,
                                                                FontWeight
                                                                    .normal,
                                                                1)
                                                      ],
                                                    ))
                                                :  Container(
                                                    height: 0.0,
                                                  )
                                            :  Container(
                                                height: 0.0,
                                              ),
                                         Padding(
                                            padding:  EdgeInsets.only(
                                                left: 8.0,
                                                top: 20.0,
                                                right: 13.0,
                                                bottom: 0.0),
                                            child:  Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                 Expanded(
                                                  child:  InkWell(
                                                    child:  Image.asset(
                                                      isParentAge
                                                          ? "assets/newDesignIcon/login/check.png"
                                                          : "assets/newDesignIcon/login/uncheck.png",
                                                      width: 25.0,
                                                      height: 25.0,
                                                    ),
                                                    onTap: () {
                                                      if (isParentAge)
                                                        isParentAge = false;
                                                      else
                                                        isParentAge = true;
                                                      setState(() {
                                                        isParentAge;
                                                      });
                                                    },
                                                  ),
                                                  flex: 0,
                                                ),
                                                 Expanded(
                                                  child: Container(
                                                    padding: EdgeInsets.only(
                                                        left: 4.0,
                                                        right: 4.0,
                                                        top: 3.0),
                                                    child:  Container(
                                                        child: RichText(
                                                      maxLines: 2,
                                                      textAlign:
                                                          TextAlign.start,
                                                      text: TextSpan(
                                                        text:
                                                           MessageConstant.PARENT_CONFIRM_ABOVE_18_YEAR,
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 14.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                    )),
                                                  ),
                                                  flex: 1,
                                                )
                                              ],
                                            )),

                                        Padding(
                                          padding:  EdgeInsets.fromLTRB(13.0, 15.0, 13, 20.0),
                                          child:  InkWell(
                                            child: TextViewWrap.textView(
                                                MessageConstant.PARENT_HAVE_REFERRAL_CODE,
                                                TextAlign.start,
                                                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                16.0,
                                                FontWeight.normal),
                                            onTap: () {
                                              showReferelPopUp(context);
                                            },
                                          ),
                                        ),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          mainAxisAlignment: MainAxisAlignment.end,
                                          children: <Widget>[
                                             Padding(
                                                padding:  EdgeInsets.only(
                                                    left: 8.0,
                                                    top: 0.0,
                                                    right: 13.0,
                                                    bottom: 0.0),
                                                child:  Row(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                                  children: <Widget>[
                                                     Expanded(
                                                      child:  InkWell(
                                                        child:  Image.asset(
                                                          isAgree
                                                              ? "assets/newDesignIcon/login/check.png"
                                                              : "assets/newDesignIcon/login/uncheck.png",
                                                          width: 25.0,
                                                          height: 25.0,
                                                        ),
                                                        onTap: () {
                                                          if (isAgree)
                                                            isAgree = false;
                                                          else
                                                            isAgree = true;
                                                          setState(() {
                                                            isAgree;
                                                          });
                                                        },
                                                      ),
                                                      flex: 0,
                                                    ),
                                                     Expanded(
                                                      child: Container(
                                                        padding: EdgeInsets.only(
                                                            left: 4.0, right: 4.0),
                                                        height: 55.0,
                                                        child:  Container(
                                                            child: RichText(
                                                              maxLines: 3,
                                                              textAlign: TextAlign.start,
                                                              text: TextSpan(
                                                                text:
                                                                MessageConstant.PARENT_SIGNINGUP_AGREE,
                                                                style:  TextStyle(
                                                                    color:   ColorValues.GREY_TEXT_COLOR,
                                                                    fontSize: 14.0,
                                                                    fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                                children: <TextSpan>[
                                                                  TextSpan(
                                                                      text: MessageConstant.PARENT_TERMS_DATA,
                                                                      recognizer:
                                                                      TapGestureRecognizer()
                                                                        ..onTap = () {
                                                                          Navigator.push(
                                                                              Constant
                                                                                  .applicationContext,
                                                                               MaterialPageRoute(
                                                                                  builder: (context) =>  WebViewWidget(
                                                                                      Constant
                                                                                          .TERMS,
                                                                                      MessageConstant.PARENT_TERMS_DATA)));
                                                                        },
                                                                      style:  TextStyle(
                                                                          color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                          fontSize: 14.0,
                                                                          fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                                  TextSpan(
                                                                    text: " & ",
                                                                    style:  TextStyle(
                                                                        color: ColorValues.GREY_TEXT_COLOR,
                                                                        fontSize: 14.0,
                                                                        fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                                  TextSpan(
                                                                    text: MessageConstant.PARENT_PRIVACY_POLICY,
                                                                    recognizer:
                                                                    TapGestureRecognizer()
                                                                      ..onTap = () {
                                                                        Navigator.push(
                                                                            Constant
                                                                                .applicationContext,
                                                                             MaterialPageRoute(
                                                                                builder: (context) =>  WebViewWidget(
                                                                                    Constant
                                                                                        .PRIVACY_POLICY,
                                                                                    MessageConstant.PARENT_PRIVACY_POLICY)));
                                                                      },
                                                                    style:  TextStyle(
                                                                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                        fontSize: 14.0,
                                                                        fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                                  TextSpan(
                                                                      text:
                                                                      MessageConstant.PARENT_CONFIRM_SELECTED_AGE,
                                                                      recognizer:
                                                                       TapGestureRecognizer()
                                                                        ..onTap = () {
                                                                          Navigator.push(
                                                                              Constant
                                                                                  .applicationContext,
                                                                               MaterialPageRoute(
                                                                                  builder: (context) =>  WebViewWidget(
                                                                                      Constant
                                                                                          .TERMS,
                                                                                      MessageConstant.PARENT_TERMS_DATA)));
                                                                        },
                                                                      style:  TextStyle(
                                                                          color: ColorValues.GREY_TEXT_COLOR,
                                                                          fontSize: 14.0,
                                                                          fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR))
                                                                ],
                                                              ),
                                                            )),
                                                      ),
                                                      flex: 1,
                                                    )
                                                  ],
                                                )),
                                             Container(
                                                padding:  EdgeInsets.fromLTRB(
                                                    13.0, 11.0, 13.0, 0.0),
                                                child: Column(
                                                  children: <Widget>[
                                                    loginButton,
                                                     Row(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                      mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                      children: <Widget>[
                                                         Expanded(
                                                          child:  Text(
                                                             MessageConstant.PARENT_ALREADY_HAVE_ACCOUNT,
                                                              style:  TextStyle(
                                                                  color:   ColorValues.GREY_TEXT_COLOR,
                                                                  fontSize: 14.0,
                                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                          flex: 0,
                                                        ),
                                                         Expanded(
                                                          child:  InkWell(
                                                            child:  Text(MessageConstant.PARENT_SIGNIN,
                                                                style:  TextStyle(
                                                                    color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    fontSize: 14.0,
                                                                    fontWeight: FontWeight.w700,
                                                                    fontFamily: Constant.TYPE_CUSTOMBOLD)),
                                                            onTap: () {
                                                              if (isShowConformationDialog()) {
                                                                conformationDialogForBackNavigation(
                                                                    "");
                                                              } else {
                                                                if (widget.pageName ==
                                                                    "Login") {
                                                                  Navigator.of(context)
                                                                      .pop('SignIn');
                                                                } else {
                                                                  Navigator.of(context)
                                                                      .pop('SignIn');
                                                                }
                                                              }
                                                            },
                                                          ),
                                                          flex: 0,
                                                        )
                                                      ],
                                                    ),
                                                  ],
                                                )),
                                          ],
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              )),
                        ),
                      ],
                    ))))));
  }

  _fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }

  Future callApiToValidateTheaReferalCode(String from) async {
    print('inside callApiToValidateTheaReferalCode() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {

        print('URL Referal:: ${Constant.ENDPOINT_VALIDATE_REFERAL_CODE_API + referalController.text.trim()}');

        Response response = await  ApiCalling().apiCallWithouAuth(
            context,
            Constant.ENDPOINT_VALIDATE_REFERAL_CODE_API +
                referalController.text.trim(),
            "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String message = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              ReferalCodeResponse apiResponse =
                   ReferalCodeResponse.fromJson(response.data);
              referalCodeResponse = apiResponse; //apiResponse.result;

              Navigator.of(context).pop();
              if (from == 'continue') {
                if (widget.isValid) {
                  loginServiceCall();
                } else {
                  ToastWrap.showToastLong(
                      MessageConstant.PRIVATE_EMAIL_MSG, context);
                }
              } else {

                ToastWrap.showToastGreen(message, context);
              }
            } else {
              //if(from == 'continue'){
              //ToastWrap.showToast(MessageConstant.INVALID_REFERRAL_CODE, context);
              ToastWrap.showToast(message, context);
              //}
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e,"parentSignup",context);
    }
  }
}
