class EducationCollegeInfoModel {
  String status;
  List<CollegeResult> message;

  EducationCollegeInfoModel({this.status, this.message});

  EducationCollegeInfoModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['message'] != null) {
      message =  List<CollegeResult>();
      json['message'].forEach((v) {
        message.add(new CollegeResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.message != null) {
      data['message'] = this.message.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CollegeResult {
  String sId;
  int educationId;
  int userId;
  String institute;
  String city;
  String logo;
  String fromYear;
  String toYear;
  String description;
  bool isActive;
  int gpa;
  String degree;
  String major;
  String minor;
  String graduationYear;
  String certifications;
  String year;
  String isWeighted;
  int outOfGpa;
  int iV;
  String type;

  CollegeResult(
      {this.sId,
        this.educationId,
        this.userId,
        this.institute,
        this.city,
        this.logo,
        this.fromYear,
        this.toYear,
        this.description,
        this.isActive,
        this.gpa,
        this.degree,
        this.major,
        this.minor,
        this.graduationYear,
        this.certifications,
        this.year,
        this.isWeighted,
        this.outOfGpa,
        this.iV,
        this.type});

  CollegeResult.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    educationId = json['educationId'];
    userId = json['userId'];
    institute = json['institute'];
    city = json['city'];
    logo = json['logo'];
    fromYear = json['fromYear'];
    toYear = json['toYear'];
    description = json['description'];
    isActive = json['isActive'];
    gpa = json['gpa'];
    degree = json['degree'].toString().trim();
    major = json['major'].toString().trim();
    minor = json['minor'].toString().trim();
    graduationYear = json['graduationYear'];
    certifications = json['certifications'].toString().trim();
    year = json['year'];
    isWeighted = json['isWeighted'];
    outOfGpa = json['outOfGpa'];
    iV = json['__v'];
    type = json['type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['educationId'] = this.educationId;
    data['userId'] = this.userId;
    data['institute'] = this.institute;
    data['city'] = this.city;
    data['logo'] = this.logo;
    data['fromYear'] = this.fromYear;
    data['toYear'] = this.toYear;
    data['description'] = this.description;
    data['isActive'] = this.isActive;
    data['gpa'] = this.gpa;
    data['degree'] = this.degree;
    data['major'] = this.major;
    data['minor'] = this.minor;
    data['graduationYear'] = this.graduationYear;
    data['certifications'] = this.certifications;
    data['year'] = this.year;
    data['isWeighted'] = this.isWeighted;
    data['outOfGpa'] = this.outOfGpa;
    data['__v'] = this.iV;
    data['type'] = this.type;
    return data;
  }
}
