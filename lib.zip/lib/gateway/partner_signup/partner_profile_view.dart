import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/component/CustomDropdownButtonNew.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/CustomFormFieldWithPrefix.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_multiline_text_form.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/experiences/uploaded_file.dart';
import 'package:spike_view_project/gateway/BusinessCategoryResponse.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/gateway/partner_signup/other_link_view.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/video_player_offline.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';
import 'package:spike_view_project/modal/patner/opportunity_category_model.dart';
import 'package:spike_view_project/modal/patner/user_signup_model.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/list_image_view.dart';
import 'package:spike_view_project/widgets/list_video_item.dart';
import 'package:spike_view_project/widgets/positive_button.dart';
import 'package:spike_view_project/widgets/remove_button.dart';
import 'package:spike_view_project/widgets/stepper_widget.dart';
import 'package:video_compress/video_compress.dart';

enum MediaType { image, video, doc, link, profile }
enum SignUpUsing { email, apple, google }
enum PartnerProfileAction { add, edit }

class PartnerProfileView extends StatefulWidget {
  final SignUpUsing signUpUsing;
  final UserModel personalInfoObject;
  final String firstName;
  final String lastName;
  final String email;
  final bool isRedirectToRecommendation;
  final String pageName;
  final PartnerProfileAction action;

  const PartnerProfileView({
    @required this.signUpUsing,
    @required this.action,
    this.email,
    this.firstName,
    this.lastName,
    this.personalInfoObject,
    this.isRedirectToRecommendation,
    this.pageName,
  });

  @override
  State<PartnerProfileView> createState() => _PartnerProfileViewState();
}

class _PartnerProfileViewState extends State<PartnerProfileView> {
  static const platform = const MethodChannel('samples.flutter.io/battery');
  static StreamController syncDoneController = StreamController.broadcast();
  int currentStep = 0;
  PageController _pageController = PageController();
  bool _isProcessEnable = false;
  File profileImageFile;
  String userProfileUrl = '';
  final companyNameCtrl = TextEditingController();
  final yourNameCtrl = TextEditingController();
  final addressCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final websiteUrlCtrl = TextEditingController();
  final aboutCtrl = TextEditingController();
  final otherCtrl = TextEditingController();
  final companyNameNode = FocusNode();
  final yourNameNode = FocusNode();
  final addressNode = FocusNode();
  final phoneNode = FocusNode();
  final emailNode = FocusNode();
  final websiteUrlNode = FocusNode();
  final aboutNode = FocusNode();
  final otherNode = FocusNode();
  List<CategoryResult> mainBusinessCatList = [];
  List<CategoryResult> businessCategoryList = [];
  List<CategoryResult> selectedCategoryList = [];
  CountryCode _selectedCountry = CountryCode.US;
  final _formKey = GlobalKey<FormState>();
  CategoryResult _selectedCategory;

  String userIdPref,
      token,
      sasToken = '',
      containerName = '',
      strPrefixPathForPhoto = '';
  SharedPreferences prefs;
  CompanyProfileModel partnerProfile;

  ///Step two fields and variables
  List<UploadedFile> imagesList = [];
  List<UploadedFile> videoList = [];
  List<UploadedFile> docList = [];
  List<String> linkList = [];
  List<OpportunityCategoriesResult> opportunityCategoryList = List();
  List<OfferModel> offers = [];

  @override
  void initState() {
    _callApiForSaas();
    callApiOpporunityCategory();
    _callApiGetCategory();
    _getSharedPreferences();
    super.initState();
  }

  Future callApiOpporunityCategory() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCallWithouAuth(
            context, Constant.ENDPOINT_OPPORTUNITY_CATEGORY, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              OpportunityCategoriesModel apiResponse =
                  OpportunityCategoriesModel.fromJson(response.data);
              setState(() {
                opportunityCategoryList = apiResponse.result;
              });
              setOfferList();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "partnerSignup", context);
      e.toString();
    }
  }

  void setOfferList() {
    setState(() {
      for (var item in opportunityCategoryList) {
        //personalInfoObject.offers.add(OfferModel(offerId: item.oppCategoryId, name: item.name, isSelected: true));
        offers.add(OfferModel(offerId: item.oppCategoryId, name: item.name));
      }
    });
  }

  Future<void> _getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    strPrefixPathForPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
    emailCtrl.text = widget.email ?? '';
    yourNameCtrl.text =
        "${widget?.firstName ?? ''} ${widget?.lastName ?? ''}".trim();
    if (widget.action == PartnerProfileAction.edit) {
      _getProfileApi();
    }
  }

  Future<void> _getProfileApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=4", "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              partnerProfile =
                  ParseJson.parseCompanyInfoData(response.data['result']);
              _setupData(partnerProfile);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditParentProfile", context);
      e.toString();
    }
  }

  Future<void> _callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        final response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null && response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
    }
  }

  Future<void> onTapSignOut() async {
    // setState(() {
    Constant.isAlreadyLoggedIn = false;
    //});

    Map map = {
      "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
      "deviceId": prefs.getString("deviceId")
    };
    GlobalSocketConnection.socket
        .emitWithAck("disconnect1", [map]).then((data) {
      print("chat-login++++" + data.toString());
    });
    GlobalSocketConnection.socket.emit("disconnect2", []);
    prefs.setString(UserPreference.NAME, "");
    prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
    prefs.setBool(UserPreference.IS_USER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
    prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
    bloc.resetData(prefs);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage(null)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: WillPopScope(
        onWillPop: () {
          _onBackPressed();
          return Future.value(false);
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(20, 50, 20, 14),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  widget.action == PartnerProfileAction.edit
                      ? Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  child: Image.asset(
                                    "assets/new_onboarding/back_blue_icon.png",
                                    height: 32,
                                    width: 32,
                                    fit: BoxFit.fitHeight,
                                  ),
                                  onTap: () => Navigator.pop(context),
                                ),
                                const HelpButtonWidget(),
                              ],
                            ),
                            const SizedBox(height: 11),
                            BaseText(
                              text: "Profile details",
                              style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily: Constant.latoRegular,
                                fontWeight: FontWeight.w700,
                                fontSize: 28,
                              ),
                            ),
                            const SizedBox(height: 11),
                            BaseText(
                              text: "View full profile details!",
                              textColor: const Color(0xff666B9A),
                              fontFamily: Constant.latoMedium,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                          ],
                        )
                      : Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: BaseText(
                                    text: "Profile",
                                    textColor:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 28,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                InkWell(
                                  child: Image.asset(
                                    "assets/partner_profile/ic_skip.png",
                                    height: 32,
                                    width: 32,
                                    fit: BoxFit.fitHeight,
                                  ),
                                  onTap: () => onTapSignOut(),
                                ),
                                const SizedBox(width: 10),
                                const HelpButtonWidget(),
                              ],
                            ),
                            const SizedBox(height: 11),
                            BaseText(
                              text:
                                  'Please provide details about your business. If you are offering the services as an individual, you can share your details.',
                              textColor: const Color(0xff666B9A),
                              fontFamily: Constant.latoMedium,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                          ],
                        ),
                  const SizedBox(height: 14),
                  StepperWidget(length: 2, currentStep: currentStep),
                ],
              ),
            ),
            Expanded(
              child: FormKeyboardActions(
                nextFocus: false,
                keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                keyboardBarColor: Colors.grey[200],
                actions: [
                  //KeyboardAction(focusNode: workHourNode),
                ],
                child: PageView(
                  controller: _pageController,
                  physics: const NeverScrollableScrollPhysics(),
                  onPageChanged: (value) {
                    currentStep = value;
                    setState(() {});
                  },
                  children: [
                    _stepOne(),
                    _stepTwo(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 23, 20, 23),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromRGBO(204, 220, 247, 0.46),
                blurRadius: 13,
                spreadRadius: 10,
              ),
            ],
          ),
          child: SizedBox(
            height: 44,
            child: Row(
              children: [
                Visibility(
                  visible: currentStep == 1,
                  child: Expanded(
                    flex: 30,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 13),
                      child: _negativeButton(title: 'Back'),
                    ),
                  ),
                ),
                Expanded(
                  flex: currentStep == 0 ? 1 : 66,
                  child: PositiveButton(
                    onTap: () => _positiveTap(),
                    isEnable: _isProcessEnable,
                    title: "Proceed",
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _stepOne() {
    return Form(
      key: _formKey,
      child: FormKeyboardActions(
        nextFocus: false,
        keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
        keyboardBarColor: Colors.grey[200],
        actions: [
          KeyboardAction(
            focusNode: phoneNode,
          ),
        ],
        child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: SizedBox(
                height: 115,
                width: 115,
                child: Stack(
                  children: [
                    Container(
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                          color: const Color(0xff666B9A),
                          borderRadius: BorderRadius.circular(35),
                          border: Border.all(color: Colors.white, width: 2),
                          boxShadow: [
                            BoxShadow(
                                color: Color.fromRGBO(98, 175, 226, 0.15),
                                blurRadius: 20,
                                spreadRadius: 8,
                                offset: Offset(0, 1.0))
                          ]),
                      child: profileImageFile != null
                          ? Image.file(
                              profileImageFile,
                              height: 115,
                              width: 115,
                              fit: BoxFit.cover,
                            )
                          : userProfileUrl?.isNotEmpty ?? false
                              ? CachedNetworkImage(
                                  height: 115,
                                  width: 115,
                                  fit: BoxFit.cover,
                                  imageUrl:
                                      Constant.IMAGE_PATH + userProfileUrl,
                                  placeholder: (_, str) {
                                    return Center(
                                      child: SizedBox(
                                        width: 30.0,
                                        height: 30.0,
                                        child: CircularProgressIndicator(
                                          valueColor: AlwaysStoppedAnimation(
                                            Colors.black54,
                                          ),
                                          strokeWidth: 2.0,
                                        ),
                                      ),
                                    );
                                  },
                                  errorWidget: (_, str, e) {
                                    return _errorOrEmptyProfile();
                                  },
                                )
                              : _errorOrEmptyProfile(),
                    ),
                    Positioned(
                      right: 12,
                      bottom: 12,
                      child: InkWell(
                        onTap: () => _chooseImageVideo(MediaType.profile),
                        child: Image.asset(
                          'assets/partner_profile/ic_edit.png',
                          height: 24,
                          width: 24,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            CustomFormField(
              textInputAction: TextInputAction.next,
              maxLength: TextLength.COMAPNY_NAME_MAX_LENGTH,
              textInputType: TextInputType.text,
              label: "Company / Display Name",
              hint: MessageConstant.PARTNER_DISPLAYED_HOMEPAGE,
              alignLabelWithHint: true,
              onType: (val) => _checkValidation(),
              controller: companyNameCtrl,
              focusNode: companyNameNode,
              validation: (val) => ValidationChecks.validateCompanyName(val),
            ),
            const SizedBox(height: 24),
            CustomFormField(
              textInputAction: TextInputAction.next,
              maxLength: TextLength.YOUR_NAME_MAX_LENGTH,
              textInputType: TextInputType.text,
              label: "Your name",
              hint: MessageConstant.PARTNER_FIRST_LAST_NAME,
              alignLabelWithHint: true,
              onType: (val) => _checkValidation(),
              controller: yourNameCtrl,
              focusNode: yourNameNode,
              suffixWidget: Padding(
                padding: const EdgeInsets.only(top: 6),
                child: _optionalLabel(),
              ),
              validation: (val) => val.trim().length == 0
                  ? null
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.NAME_CONTAIN_ALPHABT_VAL
                      : null,
            ),
            const SizedBox(height: 24),
            CustomDropdownButtonFormFieldNew(
              icon: Image.asset(
                'assets/recommendation/ic_arrow_down.png',
                height: 24,
                width: 24,
              ),
              items: businessCategoryList
                  .map((item) => CustomDropdownMenuItem<CategoryResult>(
                      value: item,
                      child: Text(
                        item.name,
                        style: AppConstants.txtStyle.txtStyleTextForm,
                      )))
                  .toList(),
              onChanged: (value) => _categorySelection(value),
              value: _selectedCategory,
              labelText: "Business category",
            ),
            const SizedBox(height: 10),
            Wrap(
              children: List.generate(selectedCategoryList.length, (index) {
                return Container(
                  padding: EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                  // Adjusted padding here
                  decoration: BoxDecoration(
                    color: const Color(0xffF48808),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        selectedCategoryList[index].name,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: ColorValues.WHITE,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          fontFamily: AppConstants.stringConstant.latoRegular,
                        ),
                      ),
                      const SizedBox(width: 5),
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: InkWell(
                          onTap: () => _removeCategory(index),
                          child: Icon(
                            Icons.close,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
              runSpacing: 10,
              spacing: 10,
            ),
            Visibility(
              visible: selectedCategoryList
                  .any((element) => element.name.toLowerCase() == 'other'),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: CustomFormField(
                  controller: otherCtrl,
                  focusNode: otherNode,
                  alignLabelWithHint: true,
                  label: "Other business category",

                  //  hint: "Other business category",
                  textInputType: TextInputType.text,
                  validation: (val) => val.trim().isEmpty
                      ? "Please enter the other business category"
                      : null,
                ),
              ),
            ),
            const SizedBox(height: 24),
            CustomFormField(
              textInputAction: TextInputAction.next,
              maxLength: TextLength.COMAPNY_ADDRESS_MAX_LENGTH,
              textInputType: TextInputType.text,
              label: "Company / Your Address",
              //hint: "Company / Your Address",
              alignLabelWithHint: true,
              onType: (val) => _checkValidation(),
              controller: addressCtrl,
              focusNode: addressNode,
              validation: (value) {
                return ValidationChecks.validateCompanyAddress(value);
              },
            ),
            const SizedBox(height: 24),
            CustomFormFieldWithPrefix(
              prefixWidget: Padding(
                padding: const EdgeInsets.only(right: 5.0),
                child: Container(
                  width: 55,
                  child: CountryCodePicker(
                    dense: false,
                    showFlag: true,
                    isNew: true,
                    showDialingCode: false,
                    showUnderLine: false,
                    showName: false,
                    onChanged: (country) {
                      _selectedCountry = country;
                      setState(() {});
                    },
                    selectedCountryCode: _selectedCountry?.dialingCode ?? '1',
                  ),
                ),
              ),
              baseAlign: true,
              autoValidate: false,
              autoValidateMode: AutovalidateMode.disabled,
              label: "Phone number",
              textInputAction: TextInputAction.next,
              textInputType: TextInputType.number,
              onType: (val) => _checkValidation(),
              focusNode: phoneNode,
              controller: phoneCtrl,
              validation: (value) {
                if (value.trim().isNotEmpty) {
                  return ValidationChecks.validatePhone(value);
                } else {
                  return null;
                }
              },
              suffixWidget: Padding(
                padding: const EdgeInsets.only(top: 6),
                child: _optionalLabel(),
              ),
              inputFormatter: [
                LengthLimitingTextInputFormatter(20),
                FilteringTextInputFormatter.digitsOnly,
              ],
            ),
            /*Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: CountryCodePicker(
                    dense: false,
                    showFlag: true,
                    showDialingCode: false,
                    showName: false,
                    onChanged: (country) {
                      _selectedCountry = country;
                      setState(() {});
                    },
                    selectedCountryCode: _selectedCountry?.dialingCode ?? '1',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: CustomFormField(
                    textInputAction: TextInputAction.next,
                    textInputType: TextInputType.number,
                    label: "Phone number",
                    hint: "Phone number",
                    alignLabelWithHint: true,
                    onType: (val) => _checkValidation(),
                    controller: phoneCtrl,
                    focusNode: phoneNode,
                    validation: (value) {
                      if (value.trim().isNotEmpty) {
                        return ValidationChecks.validatePhone(value);
                      } else {
                        return null;
                      }
                    },
                    suffixWidget: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: _optionalLabel(),
                    ),
                    maxLength: 20,
                  ),
                ),
              ],
            ),*/
            const SizedBox(height: 24),
            CustomFormField(
              textInputAction: TextInputAction.next,
              maxLength: TextLength.YOUR_NAME_MAX_LENGTH,
              textInputType: TextInputType.emailAddress,
              label: "Email",
              //hint: "Email",
              enable: false,
              alignLabelWithHint: true,
              onType: (val) => _checkValidation(),
              controller: emailCtrl,
              focusNode: emailNode,
              validation: (value) {
                return ValidationChecks.validateEmail(value);
              },
            ),
            const SizedBox(height: 24),
            CustomFormField(
              textInputAction: TextInputAction.next,
              maxLength: TextLength.YOUR_NAME_MAX_LENGTH,
              textInputType: TextInputType.text,
              label: "Website URL",
              hint: "https://www.example.com",
              alignLabelWithHint: true,
              onType: (val) => _checkValidation(),
              controller: websiteUrlCtrl,
              focusNode: websiteUrlNode,
              validation: (value) {
                return value.trim().length == 0
                    ? null
                    : ValidationChecks.validateWebUrl(value);
              },
            ),
            const SizedBox(height: 24),
            CustomMultilineTextForm(
              autoValidate: false,
              textInputType: TextInputType.text,
              label: "About your company service",
              hint:
                  MessageConstant.PARTNER_PREMIER_TUTORING_SERVICE_SPECIALIZING,
              onType: (value) => _checkValidation(),
              maxLength: 500,
              maxLines: 3,
              alignLabelWithHint: true,
              focusNode: aboutNode,
              controller: aboutCtrl,
              helperText:
                  "Make your message compelling and don't forget to include how the user can contact you and apply to your opportunity.",
              helperTextStyle: TextStyle(
                color: const Color(0xff828282),
                fontFamily: Constant.latoRegular,
                fontWeight: FontWeight.w400,
                fontSize: 10,
                fontStyle: FontStyle.italic,
              ),
              validation: (val) =>
                  val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
            ),
            const SizedBox(height: 50),
          ],
        ),
      ),
    )

    );
  }

  Widget _stepTwo() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BaseText(
            text: 'Add media',
            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
            fontFamily: AppConstants.stringConstant.latoRegular,
            fontWeight: FontWeight.w400,
            fontSize: 16,
          ),
          const SizedBox(height: 7),
          SizedBox(
            width: double.maxFinite,
            height: 110,
            child: InkWell(
              onTap: () => _chooseImageVideo(MediaType.image),
              child: Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 14,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: imagesList.isNotEmpty
                          ? SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                children: List.generate(
                                  imagesList.length,
                                  (index) {
                                    return ListImageView(
                                      onRemoveTap: () => _showRemoveDialog(
                                          index, MediaType.image),
                                      imageUrl: imagesList[index].url,
                                    );
                                  },
                                ),
                              ),
                            )
                          : Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Image.asset(
                                    "assets/recommendation/ic_camera.png",
                                    height: 26,
                                    width: 25,
                                  ),
                                  const SizedBox(height: 3),
                                  BaseText(
                                    text:
                                        'Add compelling photos of your company, logos or products',
                                    maxLines: 2,
                                    textAlign: TextAlign.center,
                                    style: AppConstants.txtStyle
                                        .heading14400LatoItalicLightPurple,
                                  ),
                                ],
                              ),
                            ),
                      decoration: BoxDecoration(
                        color: AppConstants.colorStyle.tabBg,
                        border: Border.all(
                          color: AppConstants.colorStyle.borderGenerateScript,
                        ),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(7),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: Image.asset(
                      "assets/generateScript/plus_icon.png",
                      height: 28,
                      width: 28,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.maxFinite,
            height: 110,
            child: InkWell(
              onTap: () => _chooseImageVideo(MediaType.video),
              child: Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 14,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: videoList.isNotEmpty
                          ? SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                children: List.generate(
                                  videoList.length,
                                  (index) {
                                    return ListVideoItem(
                                      onRemoveTap: () => _showRemoveDialog(
                                          index, MediaType.video),
                                      videoUrl: videoList[index].url,
                                      onPlayTap: () => _videoPlayPopUp(
                                          videoList[index].file.path),
                                      thumbnailFile:
                                          videoList[index].thumbnailFile,
                                    );
                                  },
                                ),
                              ),
                            )
                          : Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Image.asset(
                                    "assets/experience/ic_video.png",
                                    height: 26,
                                    width: 25,
                                  ),
                                  const SizedBox(height: 3),
                                  BaseText(
                                    text: 'Tell the users about your company',
                                    maxLines: 2,
                                    textAlign: TextAlign.center,
                                    style: AppConstants.txtStyle
                                        .heading14400LatoItalicLightPurple,
                                  ),
                                ],
                              ),
                            ),
                      decoration: BoxDecoration(
                        color: AppConstants.colorStyle.tabBg,
                        border: Border.all(
                          color: AppConstants.colorStyle.borderGenerateScript,
                        ),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(7),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: Image.asset(
                      "assets/generateScript/plus_icon.png",
                      height: 28,
                      width: 28,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.maxFinite,
            height: 110,
            child: InkWell(
              onTap: () => _pickDocs(MediaType.doc),
              child: Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 14,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      child: docList.isNotEmpty
                          ? SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              padding: const EdgeInsets.only(left: 10),
                              child: Row(
                                children: List.generate(
                                  docList.length,
                                  (index) {
                                    return _docItem(index);
                                  },
                                ),
                              ),
                            )
                          : Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(height: 18),
                                Image.asset(
                                  "assets/resume/ic_resume.png",
                                  height: 20,
                                  width: 16,
                                ),
                                const SizedBox(height: 4),
                                BaseText(
                                  text:
                                      'Upload documents with additional details',
                                  maxLines: 2,
                                  textAlign: TextAlign.center,
                                  style: AppConstants.txtStyle
                                      .heading14400LatoItalicLightPurple,
                                ),
                              ],
                            ),
                      decoration: BoxDecoration(
                        color: const Color(0xffF3F5FF),
                        border: Border.all(color: const Color(0xffD4E4FF)),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(7)),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: Image.asset(
                      "assets/generateScript/plus_icon.png",
                      height: 28,
                      width: 28,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          BaseText(
            text: 'Upload document link',
            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
            fontFamily: AppConstants.stringConstant.latoRegular,
            fontWeight: FontWeight.w400,
            fontSize: 16,
          ),
          const SizedBox(height: 5),
          Visibility(
              visible: linkList.isNotEmpty,
              child: ListView.separated(
                itemBuilder: (_, index) {
                  return InkWell(
                    onTap: () {
                      Util.launchUrl("Url", linkList[index]);
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppConstants.colorStyle.tabBg,
                        border: Border.all(
                            color:
                                AppConstants.colorStyle.borderGenerateScript),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(7),
                        ),
                      ),
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Expanded(
                            child: BaseText(
                              text: linkList[index],
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(width: 12),
                          InkWell(
                            child: Image.asset(
                              'assets/experience/ic_remove.png',
                              height: 14,
                              width: 14,
                            ),
                            onTap: () =>
                                _showRemoveDialog(index, MediaType.link),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                separatorBuilder: (_, index) => const SizedBox(height: 14),
                itemCount: linkList.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(vertical: 12),
              )),
          SizedBox(
            width: double.maxFinite,
            height: 110,
            child: InkWell(
              onTap: () => _linkAddTap(),
              child: Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 14,
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(height: 18),
                          Image.asset(
                            "assets/experience/ic_badges.png",
                            height: 26,
                            width: 25,
                          ),
                          const SizedBox(height: 5),
                          Text(
                            'Copy or type the link of your document folder',
                            maxLines: 2,
                            textAlign: TextAlign.center,
                            style: AppConstants
                                .txtStyle.heading14400LatoItalicLightPurple,
                          ),
                        ],
                      ),
                      decoration: BoxDecoration(
                        color: AppConstants.colorStyle.tabBg,
                        border: Border.all(
                            color:
                                AppConstants.colorStyle.borderGenerateScript),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(7),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    child: Image.asset(
                      "assets/generateScript/plus_icon.png",
                      height: 28,
                      width: 28,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 60),
        ],
      ),
    );
  }

  Widget _optionalLabel() {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0),
      child: BaseText(
        text: 'Optional  ',
        textColor: const Color(0xff27275A),
        fontSize: 14,
        fontFamily: Constant.latoRegular,
        fontStyle: FontStyle.italic,
        fontWeight: FontWeight.w400,
      ),
    );
  }

  void _videoPlayPopUp(String filePath) {
    if (filePath?.isNotEmpty ?? false) {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => SafeArea(
          child: Scaffold(
            backgroundColor: Colors.black38,
            body: Center(
              child: Container(
                margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(10),
                ),
                height: 215.50,
                width: double.infinity,
                child: Stack(
                  overflow: Overflow.visible,
                  children: [
                    VideoPlayPauseOffline(filePath, "", true,
                        pageName: "profile"),
                    Align(
                      alignment: Alignment(1.12, -1.10),
                      child: InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(right: 5),
                          child: Image.asset(
                            "assets/generateScript/cross_close.png",
                            height: 40.0,
                            width: 40.0,
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }
  }

  Widget _docItem(int index) {
    final item = docList[index];
    return Container(
      width: 120,
      height: 78,
      margin: EdgeInsets.only(right: 12),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        color: Colors.white,
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Image.asset(
            "assets/resume/pdf_outside.png",
            height: 78,
            fit: BoxFit.fill,
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 0),
            decoration: BoxDecoration(
              color: const Color(0x50000000),
            ),
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () {
                    Util.launchUrl("Url", Constant.IMAGE_PATH + item.url);
                  },
                  child: Image.asset(
                    "assets/experience/ic_play.png",
                    height: 26,
                    width: 26,
                  ),
                ),
                RemoveButton(
                    onTap: () => _showRemoveDialog(index, MediaType.doc)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _removeCategory(int index) {
    /*if(businessCategoryList.isEmpty){
      businessCategoryList.insert(0, CategoryResult(
          businessCategoryId: -1,
          name: 'Select All',
          description: 'Select All'));
    }*/
    //businessCategoryList.add(selectedCategoryList[index]);
    selectedCategoryList.removeAt(index);
    _selectedCategory = null;
    _checkValidation();
  }

  void _categorySelection(CategoryResult value) {
    print('____-- -- cate ${value.businessCategoryId}');
    _selectedCategory = value;
    if (value.businessCategoryId == -1) {
      selectedCategoryList.clear();
      selectedCategoryList.addAll(mainBusinessCatList);
      selectedCategoryList
          .removeWhere((element) => element.businessCategoryId == -1);
      //businessCategoryList.clear();
    } else {
      final isContains = selectedCategoryList.any((element) =>
          element.businessCategoryId.toString() ==
          value.businessCategoryId.toString());
      if (!isContains) {
        selectedCategoryList.add(value);
        //businessCategoryList.remove(value);
      }
    }
    _checkValidation();
  }

  Widget _errorOrEmptyProfile() {
    return Center(
      child: Image.asset(
        'assets/partner_profile/default_profile.png',
        width: 60,
        height: 64,
      ),
    );
  }

  Future<void> _onBackPressed() async {
    if (currentStep == 1) {
      _goToPreviousStep();
    } else {
      /*final prefs = await SharedPreferences.getInstance();
      Util.onTapSignOut(context, prefs);*/
      if (widget.action == PartnerProfileAction.edit) {
        Navigator.pop(context);
      }
    }
  }

  void _positiveTap() {
    if (currentStep == 1) {
      _apiCall();
    } else {
      _goToNextStep();
    }
  }

  Future<void> _chooseImageVideo(MediaType type) async {
    var status = await Permission.photos.status;
    if (status.isGranted) {
      _pickImageVideo(type);
    } else {
      checkPermissionPhoto(context, type);
    }
  }

  void _checkValidation() {
    if (_formKey?.currentState?.validate() ?? false) {
      /*if (userProfileUrl.trim().isEmpty) {
        _isProcessEnable = false;
      } else */
      if (selectedCategoryList.isEmpty) {
        _isProcessEnable = false;
      } else {
        _isProcessEnable = true;
      }
    } else {
      _isProcessEnable = false;
    }

    setState(() {});
  }

  Future<void> _callApiGetCategory() async {
    try {
      if (await ConectionDetecter.isConnected()) {
        final response = await ApiCalling2().apiCallWithouAuth(
            context, Constant.ENDPOINT_GET_BUSINESS_CATEGORY_API, "get");
        if (response != null && response.statusCode == 200) {
          if (response.data[LoginResponseConstant.STATUS] == "Success") {
            final apiResponse =
                BusinessCategoryResponse.fromJson(response.data);
            mainBusinessCatList.clear();
            businessCategoryList.clear();
            mainBusinessCatList.addAll(apiResponse.result ?? []);
            if (mainBusinessCatList.isNotEmpty) {
              mainBusinessCatList.insert(
                  0,
                  CategoryResult(
                      businessCategoryId: -1,
                      name: 'Select All',
                      description: 'Select All'));
              businessCategoryList.addAll(mainBusinessCatList);
            }
          }
        }
        setState(() {});
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "partnerSignup", context);
      e.toString();
    }
  }

  void _showRemoveDialog(int index, MediaType mediaType) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: 'Are you sure you want to remove this?',
          onPositiveTap: () {
            switch (mediaType) {
              case MediaType.image:
                imagesList.removeAt(index);
                break;
              case MediaType.video:
                videoList.removeAt(index);
                break;
              case MediaType.doc:
                docList.removeAt(index);
                break;
              case MediaType.link:
                linkList.removeAt(index);
                break;
              case MediaType.profile:
                break;
            }
            setState(() {});
          },
        );
      },
    );
  }

  void _goToNextStep() {
    _pageController.nextPage(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  void _goToPreviousStep() {
    _pageController.previousPage(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  Widget _negativeButton({@required String title}) {
    return InkWell(
      onTap: () => _onBackPressed(),
      child: Container(
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          border: Border.all(color: const Color(0xffB2BDDB)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: AppConstants.colorStyle.lightPurple,
            fontFamily: Constant.latoRegular,
            fontSize: 16,
          ),
        ),
      ),
    );
  }

  Future<void> _pickImageVideo(MediaType mediaType) async {
    if (mediaType == MediaType.video) {
      final pickFile = await FilePicker.getFile(
        type: FileType.video,
        allowCompression: true,
      );
      if (pickFile != null && pickFile.path.isNotEmpty) {
        CustomProgressLoader.showLoader(context);
        Future.delayed(Duration(seconds: 1), () {
          _fileUploading(mediaType, pickFile.path);
        });
      }
    } else {
      final result = await ImagePicker().getImage(source: ImageSource.gallery);
      if (result != null && result.path.isNotEmpty) {
        String strPath = result.path
            .substring(result.path.lastIndexOf("/") + 1, result.path.length);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          /*if (mediaType == MediaType.profile) {
            final cropFile = await _cropImage(File(result.path));
            if (cropFile != null) {
              CustomProgressLoader.showLoader(context);
              _fileUploading(mediaType, cropFile.path);
            } else {
              CustomProgressLoader.showLoader(context);
              _fileUploading(mediaType, result.path);
            }
          } else {*/
          CustomProgressLoader.showLoader(context);
          Future.delayed(Duration(seconds: 1), () {
            _fileUploading(mediaType, result.path);
          });

          // }
        }
      }
    }
  }

  Future<void> _pickDocs(MediaType type) async {
    try {
      FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
        allowedFileExtensions: ['pdf'],
        allowedMimeTypes: ['application/pdf'],
        invalidFileNameSymbols: ['/'],
      );
      final path = await FlutterDocumentPicker.openDocument(params: params);
      if (path != null && path.isNotEmpty) {
        if (Util.getFileExtension(path) == ".pdf") {
          CustomProgressLoader.showLoader(context);
          setState(() {});
          Future.delayed(Duration(seconds: 1), () {
            _fileUploading(type, path);
          });
        } else {
          ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddResume", context);
      setState(() {});
    }
  }

  Future<void> checkPermissionPhoto(
    BuildContext context,
    MediaType assetsType,
  ) async {
    showDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: Text('Please allow access'),
        content: RichText(
          maxLines: 2,
          textAlign: TextAlign.center,
          text: TextSpan(
            text: '',
            style: TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontSize: 16.0,
              fontWeight: FontWeight.bold,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
            children: <TextSpan>[
              TextSpan(
                text: assetsType == MediaType.image
                    ? 'This app needs access to photos and camera roll'
                    : assetsType == MediaType.video
                        ? "This app need the permission for access videos."
                        : 'This app needs to this permission',
                style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                  fontSize: 15.0,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          CupertinoDialogAction(
            child: Text('Deny'),
            onPressed: () => Navigator.of(context).pop(),
          ),
          CupertinoDialogAction(
            child: Text('Settings'),
            onPressed: () {
              Navigator.of(context).pop();
              openAppSettings();
            },
          ),
        ],
      ),
    );
  }

/*  int _checkTotalAssetsLength() {
    return imagesList.length +
        videosList.length +
        certificatesList.length +
        badgesList.length;
  }*/

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod(
            'getBatteryLevel',
            {
              "sasToken": sasToken,
              "imagePath": imagePath,
              "uploadPath": Constant.IMAGE_PATH + prefixPath
            },
          );
          return result;
        } else {
          return "";
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return "";
      }
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      return "";
    }
  }

  Future<void> _fileUploading(MediaType assetsType, String filePath) async {
    try {
      if (filePath.isNotEmpty) {
        String strAzureImageUploadPath = await uploadImgOnAzure(
            filePath.replaceAll("File: ", "").replaceAll("'", "").trim(),
            strPrefixPathForPhoto);
        CustomProgressLoader.cancelLoader(context);
        if (strAzureImageUploadPath != null ||
            strAzureImageUploadPath != "false") {
          final url = strPrefixPathForPhoto + strAzureImageUploadPath;
          UploadedFile uploaded = UploadedFile(
            fileType: UploadedFileType.url,
            isUploaded: true,
            url: url,
          );
          switch (assetsType) {
            case MediaType.image:
              imagesList.add(uploaded);
              break;
            case MediaType.video:
              uploaded.file = File(filePath);
              uploaded.thumbnailFile = await VideoCompress.getFileThumbnail(
                filePath,
                quality: 50,
              );
              videoList.add(uploaded);
              break;
            case MediaType.profile:
              userProfileUrl = url;
              _checkValidation();
              break;
            case MediaType.doc:
              docList.add(uploaded);
              break;
            case MediaType.link:
              // TODO: Handle this case.
              break;
          }
          setState(() {});
        }
      } else {
        debugPrint("------ _fileUploading file path empty");
        setState(() {});
      }
    } catch (e) {
      debugPrint("------ _fileUploading error ${e.toString()}");
      setState(() {});
    }
  }

  Future<void> _linkAddTap() async {
    final result = await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => OtherLinkView(
          action: OtherLinkAction.add,
        ),
      ),
    );
    if (result != null) {
      linkList.add(result);
      setState(() {});
    }
  }

  Future apiCallingUpdate(responseData) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {"userId": userIdPref, "stage": "2"};
        Response response1 = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);

        CustomProgressLoader.cancelLoader(context);
        if (response1 != null) {
          if (response1.statusCode == 200) {
            String status = response1.data[LoginResponseConstant.STATUS];
            String msg = response1.data[LoginResponseConstant.MESSAGE];
            print("update data+++ apiCallingUpdate");
            if (status == "Success") {
              bloc.fetchSetting('', context, prefs);
              String path = prefs.getString(UserPreference.PATHURL);
              if (widget.signUpUsing == SignUpUsing.apple ||
                  widget.signUpUsing == SignUpUsing.google) {
                _onSuccess(responseData);
              } else if (widget?.isRedirectToRecommendation ?? false) {
                prefs.setString(UserPreference.NAME, "");
                prefs.setString(UserPreference.EMAIL,
                    widget?.personalInfoObject?.email ?? '');
                prefs.setString(UserPreference.PASSWORD,
                    widget?.personalInfoObject?.password ?? '');
                prefs.setString(UserPreference.PROFILE_IMAGE_PATH, "");
                prefs.setString(UserPreference.COMPANY_IMAGE_PATH, "");
                prefs.setString(UserPreference.COMPANY_NAME_PATH,
                    widget?.personalInfoObject?.companyName ?? '');
                Navigator.of(context).popUntil((route) => route.isFirst);
                processForUri(path, widget?.personalInfoObject?.email ?? '');
              } else {
                _onSuccess(responseData);
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future<void> _apiCall() async {
    try {
      if (await ConectionDetecter.isConnected()) {
        CustomProgressLoader.showLoader(context);
        List<AssetModel> asset = List();
        for (var file in imagesList) {
          asset.add(AssetModel(file: file.url, tag: 'media', type: "image"));
        }
        for (var file in docList) {
          asset.add(AssetModel(file: file.url, tag: 'media', type: "doc"));
        }

        for (var file in videoList) {
          asset.add(AssetModel(file: file.url, tag: 'media', type: "video"));
        }

        for (var file in linkList) {
          asset.add(AssetModel(file: file, tag: 'media', type: "google"));
        }


        Map<String, dynamic> request = Map();
        if (widget.action == PartnerProfileAction.edit) {
          request = {
            "userId": "$userIdPref",
            "roleId": 4,
            "firstName": yourNameCtrl.text.trim(),
            "name": companyNameCtrl.text.trim(),
            "businessCategory": selectedCategoryList.map((e) {
              if (e.businessCategoryId.toString() == '10') {
                return {
                  "name": otherCtrl.text.trim(),
                  "businessCategoryId": e.businessCategoryId,
                  "isOther": true,
                };
              } else {
                return {
                  "name": e.name,
                  "businessCategoryId": e.businessCategoryId,
                  "isOther": false,
                };
              }
            }).toList(),
            "address": addressCtrl.text.trim(),
            "countryCode": _selectedCountry.dialingCode,
            "isActive": true,
            "phone": phoneCtrl.text.trim(),
            "email": emailCtrl.text.trim(),
            "url": websiteUrlCtrl.text.trim(),
            "about": aboutCtrl.text.trim(),
            "offer": OfferModel.mapList(offers),
            "asset": asset.map((item) => item.toJson()).toList(),
          };
          log('----- ${request.toString()}');
          final response = await ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_UPDATE_PARTNER_PROFILE, request);
          CustomProgressLoader.cancelLoader(context);
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                Navigator.pop(context, 'push');
                syncDoneController.add("msg");
              } else {
                ToastWrap.showToastLongNew(msg, context);
              }
            }
          }
        } else {
          request['userId'] = "$userIdPref";
          request['roleId'] = 4;
          request['firstName'] = yourNameCtrl.text.trim();
          request['name'] = companyNameCtrl.text.trim();
          request['address'] = addressCtrl.text.trim();
          request['phone'] = phoneCtrl.text.trim();
          request['url'] = websiteUrlCtrl.text.trim();
          request['about'] = aboutCtrl.text.trim();
          request['profilePicture'] = userProfileUrl;
          request['coverPicture'] = '';
          request['businessCategory'] = selectedCategoryList.map((e) {
            if (e.businessCategoryId.toString() == '10') {
              return {
                "name": otherCtrl.text.trim(),
                "businessCategoryId": e.businessCategoryId,
                "isOther": true,
              };
            } else {
              return {
                "name": e.name,
                "businessCategoryId": e.businessCategoryId,
                "isOther": false,
              };
            }
          }).toList();
          request['isActive'] = true;
          request['password'] = '';
          request['recommendationWebFlag'] = false;
          request['offer'] = OfferModel.mapList(offers);
          request['countryCode'] = _selectedCountry.dialingCode;
          request['asset'] = asset.map((item) => item.toJson()).toList();
          request['signupType'] = signupType(widget.signUpUsing);
          request['socialId'] = "";
          request['platformType'] = "mobile";
          log('----- ${request.toString()}');
          final response = await ApiCalling().apiCallPostWithMapData(
              context, Constant.ENDPOINT_COMPANY_DATA, request);
          log('----- ${response.data.toString()}');
          CustomProgressLoader.cancelLoader(context);
          if (response != null) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              apiCallingUpdate(response);
            } else {
              ToastWrap.showToastLongNew(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "partnerSignup", context);
    }
  }

  void _onSuccess(Response<dynamic> response) {
    try {
      Constant.isAlreadyLoggedIn = true;
      prefs.setString(UserPreference.ROLE_ID, "4");
      Constant.ROLE_ID = "4";
      prefs.setString(UserPreference.chat_skip_count, "0");
      prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, false);
      prefs.setBool(UserPreference.isEducationAdded, false);
      prefs.setString(UserPreference.IS_USER_ROLE, "false");
      prefs.setString(UserPreference.IS_PARENT_ROLE, "false");
      prefs.setString(UserPreference.IS_PARTNER_ROLE, "true");
      var companyMap = response.data['result']['company'];
      Company company = Company('', '', false);
      if (companyMap != null) {
        company = Company(companyMap['name'].toString(),
            companyMap['partnerStatus'].toString(), companyMap['isActive']);
        prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP,
            company.partnerStatus.toString() == 'Decline');
      }
      String dob = response.data['result']['dob'].toString();
      if (dob == null || dob == "null" || dob == "") {
        dob = "0";
      }
      String companyName = response.data['result']['companyName'].toString();
      String companyProfilePicture =
          response.data['result']['companyProfilePicture'].toString();
      bool profileCreatedByParent =
          response.data['result']['profileCreatedByParent'] ?? false;
      String schoolCode = response.data['result']['schoolCode'].toString();
      if (schoolCode == "null" || schoolCode == "") {
        schoolCode = "";
      }
      bool userLoginFirstTime =
          response.data['result']['userLoginFirstTime'] ?? false;
      if (userLoginFirstTime == null) {
        userLoginFirstTime = false;
      }
      prefs.setBool(UserPreference.SHOW_BOT_DEFAULT_COUNT, userLoginFirstTime);
      prefs.setBool(
          UserPreference.IS_USER_LOGIN_FIRST_TIME, userLoginFirstTime);
      prefs.setString(UserPreference.DOB, dob);
      // String token = response.data['result']['token'].toString();
      final user = UserData(
        response.data['result']['userId'].toString(),
        response.data['result']['firstName'].toString(),
        response.data['result']['lastName'].toString(),
        response.data['result']['email'].toString(),
        response.data['result']['salt'].toString(),
        response.data['result']['mobileNo'].toString(),
        response.data['result']['profilePicture'].toString(),
        response.data['result']['roleId'].toString(),
      );
      userList.add(user);
      prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
      String isActive = response.data['result']['isActive'].toString();
      String isHide = response.data['result']['isHide'].toString();
      prefs.setString(UserPreference.ISHide, isHide);
      prefs.setString(UserPreference.ISACTIVE, isActive);
      prefs.setBool(UserPreference.LOGIN_STATUS, true);
      prefs.setString(
          UserPreference.ROLE_ID, response.data['result']['roleId'].toString());
      Constant.ROLE_ID = response.data['result']['roleId'].toString();
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
      prefs.setBool(
          UserPreference.IS_PROFILECRETED_BY_PARENT, profileCreatedByParent);
      prefs.setString(UserPreference.USER_ID, user.userId);
      prefs.setBool(
          UserPreference.IS_PARENT, user.roleId == "2" ? true : false);
      prefs.setString(UserPreference.PARENT_ID, user.userId);
      prefs.setString(
          UserPreference.NAME, user.firstName + " " + user.lastName);
      prefs.setString(UserPreference.EMAIL, user.email);
      prefs.setString(UserPreference.MOBILE, user.mobileNo);
      prefs.setString(UserPreference.PASSWORD, "");
      prefs.setString(UserPreference.chat_skip_count, "0");
      prefs.setString(UserPreference.PROFILE_IMAGE_PATH, user.profilePicture);
      prefs.setString(UserPreference.COMPANY_IMAGE_PATH, companyProfilePicture);
      prefs.setString(UserPreference.COMPANY_NAME_PATH, companyName);
      // prefs.setString(UserPreference.USER_TOKEN, "Spike " + token);
      /*String path = "";
    try {
      path = prefs.getString(UserPreference.PATHURL);
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "partnerSignup", context);
    }*/

      String gender = response.data['result']['gender'].toString();
      if (gender == "Non-binary" || gender == "NonBinary") {
        gender = "Non-Binary";
      }
      String stage = response.data['result']['stage'].toString();
      String creationTime = "0";
      creationTime = response.data['result']['creationTime'].toString();
      if (creationTime == "null") {
        creationTime = "0";
      }
      bool isPublicUrlActive =
          response.data['result']['isPublicUrlActive'] ?? false;
      bool isPublicProfileGlobalyActive =
          response.data['result']['isPublicProfileGlobalyActive'];
      if (isPublicProfileGlobalyActive == null) {
        isPublicProfileGlobalyActive = false;
      }
      String publicUrl = response.data['result']['publicUrl'].toString().trim();
      if (publicUrl == "null") {
        publicUrl = "";
      }
      String referCode = response.data['result']['referCode'].toString();
      bool isPreLoginSetting = response.data["result"]["isLeaderboardDisplay"];
      if (isPreLoginSetting == null) {
        isPreLoginSetting = false;
      }
      prefs.setBool(UserPreference.IS_PRE_LOGIN, isPreLoginSetting);
      String badgeImage = response.data['result']['badgeImage'].toString();
      if (badgeImage == null || badgeImage == "null" || badgeImage == "") {
        badgeImage = "";
      }
      String badge = response.data['result']['badge'].toString();
      if (badge == null || badge == "null" || badge == "") {
        badge = "";
      }
      String gamification =
          response.data['result']['gamificationPoints'].toString();
      int gamificationPoints;
      if (gamification == null ||
          gamification == "" ||
          gamification == "null") {
        gamificationPoints = 0;
      } else {
        gamificationPoints = int.parse(gamification);
      }
      prefs.setString(UserPreference.referCode, referCode);
      prefs.setString(UserPreference.badgeType, badge);
      prefs.setInt(UserPreference.gamificationPoints, gamificationPoints);
      prefs.setString(UserPreference.badgeImage, badgeImage);
      List<SocialLinkData> socialLinkList = List();
      var socalLinkMap = response.data['result']['socialLinks'];
      if (socalLinkMap != null && socalLinkMap.length > 0) {
        for (int i = 0; i < socalLinkMap.length; i++) {
          socialLinkList.add(new SocialLinkData(
              image: socalLinkMap[i]['image'].toString(),
              socialName: socalLinkMap[i]['socialName'].toString(),
              socialUrl: socalLinkMap[i]['socialUrl'].toString(),
              socialId: socalLinkMap[i]['socialId']));
        }
      }
      ProfileInfoModal profileInfoModal = ProfileInfoModal(
          user.userId,
          user.firstName,
          user.lastName,
          user.email,
          user.mobileNo,
          user.profilePicture,
          user.roleId,
          isActive,
          response.data['result']['requireParentApproval'].toString(),
          response.data['result']['ccToParents'].toString(),
          response.data['result']['lastAccess'].toString(),
          "true",
          response.data['result']['organizationId'].toString(),
          gender,
          dob,
          response.data['result']['genderAtBirth'].toString(),
          response.data['result']['usCitizenOrPR'].toString(),
          null,
          response.data['result']['summary'].toString(),
          response.data['result']['coverImage'].toString(),
          response.data['result']['tagline'].toString(),
          response.data['result']['title'].toString(),
          response.data['result']['tempPassword'].toString(),
          response.data['result']['isArchived'].toString(),
          null,
          false,
          response.data['result']['groupId'].toString(),
          response.data['result']['groupName'].toString(),
          response.data['result']['groupImage'].toString(),
          "",
          "",
          response.data['result']['zipCode'].toString(),
          isHide,
          response.data['result']['referralPopup'].toString() != "null"
              ? response.data['result']['referralPopup']
              : false,
          userLoginFirstTime,
          stage,
          creationTime,
          badge,
          gamificationPoints,
          badgeImage,
          referCode,
          socialLinkList,
          publicUrl,
          isPublicUrlActive,
          isPublicProfileGlobalyActive,
          null,
          company,
          false,
          false,
          null,
          schoolCode,
          '',
          "",
          false,
          false);
      prefs.setString(
          UserPreference.CREATION_TIME, profileInfoModal.creationTime);
      prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
      prefs.setString(UserPreference.ZIPCODE, profileInfoModal.zipCode);
      prefs.setString(UserPreference.NAME,
          profileInfoModal.firstName + " " + profileInfoModal.lastName);
      prefs.setString(
          UserPreference.PROFILE_IMAGE_PATH, profileInfoModal.profilePicture);
      prefs.setString(UserPreference.TAGLINE, profileInfoModal.tagline);
      prefs.setString(UserPreference.ISACTIVE, profileInfoModal.isActive);

      goto();
    } catch (e) {
      print('error++++00++' + e.toString());
    }
  }

  Future<void> processForUri(result, email) async {
    if (result.toString().toLowerCase().contains(email)) {
      if (result.contains("previewprofile")) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        goto();
      } else if (result.contains("joingroup")) {
        List<String> mesagelist = result.split("=");

        String groupId = mesagelist[2].replaceAll("&email", "");
        //String email = mesagelist[3].replaceAll("&pass", "");
        //String pass = mesagelist[4];
        prefs.setString(UserPreference.ROLE_ID, "4");
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(
          context,
        ).pushReplacement(new MaterialPageRoute(
            builder: (context) =>
                GroupDetailWidget(groupId, "login", "", "", "")));
      } else if (result.contains("recommendation") ||
          result.contains("badges")) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE)),
          ),
        );
      }
    } else {
      goto();
    }
    prefs.setString(UserPreference.PATHURL, "");
  }

  void goto() {
    prefs.setString(UserPreference.PATHURL, "");
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => DashBoardWidgetPartner(
            prefs.getString(UserPreference.IS_PARENT_ROLE),
            prefs.getString(UserPreference.IS_PARTNER_ROLE),
            prefs.getString(UserPreference.IS_USER_ROLE)),
      ),
    );
  }

  String signupType(SignUpUsing type) {
    switch (type) {
      case SignUpUsing.email:
        return 'spikeview';
      case SignUpUsing.apple:
        return 'apple';
      case SignUpUsing.google:
        return 'google';
      default:
        return 'spikeview';
    }
  }

  void _setupData(CompanyProfileModel partnerProfile) {
    if (partnerProfile != null) {
      userProfileUrl = partnerProfile.profilePicture;
      if (partnerProfile.countryCode != null &&
          partnerProfile.countryCode != "null" &&
          partnerProfile.countryCode != "") {
        final index = CountryCode.ALL.indexWhere(
            (element) => element.dialingCode == partnerProfile?.countryCode);
        if (index > -1) {
          _selectedCountry = CountryCode.ALL[index];
        }
      }
      if(partnerProfile.firstName != null && partnerProfile.firstName != "null") {
        yourNameCtrl.text =
            "${partnerProfile?.firstName ?? ''} ${partnerProfile?.lastName != null && partnerProfile?.lastName != 'null' ? partnerProfile?.lastName : '' }"
                .trim();
      }
      emailCtrl.text = partnerProfile.email ?? '';
      if (partnerProfile.mobileNo != null &&
          partnerProfile.mobileNo != '0' &&
          partnerProfile.mobileNo != 'null') {
        phoneCtrl.text = partnerProfile.mobileNo;
      }
      if (partnerProfile.name != null && partnerProfile.name != "null") {
        companyNameCtrl.text = partnerProfile.name;
      }
      if (partnerProfile.address != null && partnerProfile.address != "null") {
        addressCtrl.text = partnerProfile.address;
      }
      if (partnerProfile.url.toString() != "null") {
        websiteUrlCtrl.text = partnerProfile.url;
      }
      if (partnerProfile.about.toString() != 'null') {
        aboutCtrl.text = partnerProfile.about;
      }
      if (partnerProfile?.assestList?.isNotEmpty ?? false) {
        for (final asset in partnerProfile.assestList) {
          final item = UploadedFile(
            fileType: UploadedFileType.url,
            url: asset.file,
            isUploaded: true,
          );
          if (asset.type == 'image') {
            imagesList.add(item);
          }
          if (asset.type == 'doc' && asset.tag == 'link') {
            linkList.add(asset.file);
          }
          if (asset.type == 'doc' && asset.tag == 'media') {
            docList.add(item);
          }
          if (asset.type == 'video') {
            videoList.add(item);
          }
          if (asset.type == 'video') {
            videoList.add(item);
          }
        }
      }
      if (partnerProfile.categoryModel?.isNotEmpty ?? false) {
        selectedCategoryList.clear();
        for (var category in partnerProfile.categoryModel) {
          if (category.businessCategoryId.toString() == '10') {
            otherCtrl.text = category?.name ?? '';
          }
          selectedCategoryList.add(CategoryResult(
            businessCategoryId: category.businessCategoryId,
            name: category.name,
          ));
        }
      }
      _checkValidation();
    }
  }
}
