import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/UserProfileDashBoard.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class AccomplishmentDetailWidget extends StatefulWidget {

  Achivment achievment;
  AccomplishmentDetailWidget(this.achievment);
  @override
  State<StatefulWidget> createState() => ChooseAccomplishmentState(achievment);
}

class ChooseAccomplishmentState extends State<AccomplishmentDetailWidget>{
  Achivment achievment;


  ChooseAccomplishmentState(this.achievment);

  @override
  void initState() {

    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    // TODO: implement build


    String getConvertedDateStamp2(String time) {
      if (time != "null") {
        int millis = int.tryParse(time);
        var now =  DateTime.fromMillisecondsSinceEpoch(millis);
        var formatter =  DateFormat('MMM dd, yyyy');
        String formatted = formatter.format(now);
        return formatted;
      } else {
        //  var formatter =  DateFormat('MMM dd, yyyy');
        //return formatter.format(new DateTime.now());
        return "Ongoing";
      }
    }

    Widget _loader(BuildContext context, String placeHolderImage) => Center(
        child: Container(
          child:  Image.asset(
            placeHolderImage,
            fit: BoxFit.cover,
          ),
        ));

    Widget _error(String placeHolderImage) {
      return Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.fill,
        ),
      );
    }

    Container getgridBadges() {
      return achievment
          .allCer_Badge_Trophy !=
          null &&
          achievment
              .allCer_Badge_Trophy
              .length >
              0
          ?  Container(
          padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
          child: Column(
            children: <Widget>[
               Row(
                children: <Widget>[
                   Expanded(
                    child:  Image.asset(
                      "assets/newDesignIcon/userprofile/certificate.png",
                      width: 12.0,
                      height: 10.0,
                    ),
                    flex: 0,
                  ),
                   Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        20.0,
                        0.0,
                        TextViewWrap.textView(
                            "  CERTIFICATES, TROPHIES & BADGES",
                            TextAlign.start,
                             ColorValues.HEADING_COLOR_EDUCATION,
                            12.0,
                            FontWeight.w400)),
                    flex: 0,
                  ),
                   Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        10.0,
                        0.0,
                         Container(
                          child: CustomViews.getSepratorLine(),
                        )),
                    flex: 1,
                  )
                ],
              ),
              PaddingWrap.paddingfromLTRB(
                  0.0,
                  10.0,
                  0.0,
                  10.0,
                   Container(
                      height: 48.0,
                      child:  GridView.count(
                        primary: true,
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.all(5.0),
                        crossAxisCount: 1,
                        childAspectRatio: .98,
                        mainAxisSpacing: 5.0,
                        crossAxisSpacing: 4.0,
                        children: achievment
                            .allCer_Badge_Trophy
                            .map((String uri) {
                          return  Container(
                              decoration:  BoxDecoration(
                                  border:  Border.all(
                                      color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                              child:  InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,

                                     CachedNetworkImage(
                                      height: 45.0,
                                      width: 48.0,
                                      imageUrl: Constant.IMAGE_PATH + uri,
                                      fit: BoxFit.cover,
                                      placeholder:(context, url) => _loader(context,
                                          "assets/profile/default_achievement.png"),
                                      errorWidget:(context, url, error) => _error(
                                          "assets/profile/default_achievement.png"),
                                    )),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                     HeroDialogRoute(
                                      builder: (BuildContext context) {
                                        return  Center(
                                          child:  AlertDialog(
                                            content:  Container(
                                              child:  Hero(
                                                tag: 'developer-hero',
                                                child:  Container(
                                                  height: 200.0,
                                                  width: 200.0,
                                                  child: Image.network(
                                                    Constant.IMAGE_PATH_SMALL +
                                                        ParseJson
                                                            .getMediumImage(
                                                            uri),
                                                    fit: BoxFit.fitHeight,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            actions: <Widget>[
                                               FlatButton(
                                                child:  Text('Close'),
                                                onPressed:
                                                Navigator.of(context)
                                                    .pop,
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  );
                                },
                              ));
                        }).toList(),
                      ))),
            ],
          ))
          :  Container(
        height: 1.0,
      );
    }


    return SafeArea(
      child: Scaffold(
          appBar:  AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                 InkWell(
                  child:  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "assets/newDesignIcon/navigation/back.png",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  },
                )
              ],
            ),
            title:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                 Text(
                  "Accomplishment",
                  style:  TextStyle(
                      fontSize: 18.0,
                      fontFamily: Constant.customRegular,
                      color:  ColorValues.HEADING_COLOR_EDUCATION),
                )
              ],
            ),
            actions: <Widget>[
               Container(
                width: 35.0,
              ),
            ],
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
        backgroundColor: ColorValues.singin_bg_color,
        body:new Column(children: <Widget>[
           Expanded(child:CustomViews.getSepratorLine(),flex: 0,),
           Expanded(child:     Column(
            children: <Widget>[
               InkWell(
                child:  Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        13.0,
                        21.0,
                        13.0,
                        0.0,
                        //
                        achievment
                            .mediaAndVideoList
                            .length >
                            0
                            ?  SizedBox(
                          // Pager view
                            height: 215.50,
                            child: PageIndicatorContainer(
                              pageView:
                               PageView.builder(
                                itemCount: achievment
                                    .mediaAndVideoList
                                    .length
                                    ,
                                controller:
                                 PageController(),
                                itemBuilder:
                                    (context, index2) {


                                  return  InkWell(
                                    child:  Stack(
                                        children: <
                                            Widget>[
                                          achievment
                                              .mediaAndVideoList[index2]
                                              .type ==
                                              "image"
                                              ?  CachedNetworkImage(
                                            width:
                                            double.infinity,
                                            height: 215.50,
                                            imageUrl:Constant
                                                .IMAGE_PATH +
                                                achievment
                                                    .mediaAndVideoList
                                                    [index2].file,
                                            fit: BoxFit.fill,
                                            placeholder: (context,
                                                url) =>
                                                _loader(context,
                                                    "assets/aerial/default_img.png"),
                                            errorWidget: (context,
                                                url,
                                                error) =>
                                                _error(
                                                    "assets/aerial/default_img.png"),
                                          )
                                              :  InkWell(
                                              child:
                                               Container(
                                                height: 215.50,
                                                color: Colors.black,
                                                child:  Center(
                                                  child:  VideoPlayPause(
                                                      achievment
                                                          .mediaAndVideoList[index2].file,
                                                      "",true),
                                                ),
                                              )),
                                          achievment
                                              .mediaAndVideoList
                                              .length ==
                                              1 ||
                                              achievment
                                                  .mediaAndVideoList[index2]
                                                  .type ==
                                                  "video"
                                              ?  Container(
                                            height:
                                            0.0,
                                          )
                                              :  Container(
                                            height:
                                            215.50,
                                            width: double
                                                .infinity,
                                            child:  Image
                                                .asset(
                                              "assets/newDesignIcon/navigation/layer_image.png",
                                              fit: BoxFit
                                                  .fill,
                                            ),
                                          )
                                        ]),
                                    onTap: () {},
                                  );




                                },
                                onPageChanged: (index) {},
                              ),
                              align:
                              IndicatorAlign.bottom,
                              length: achievment
                                  .mediaAndVideoList
                                  .length,
                              indicatorSpace: 10.0,
                              indicatorColor: achievment
                                  .mediaAndVideoList
                                  .length ==
                                  1
                                  ? Colors.transparent
                                  :  Color(0xffc4c4c4),
                              indicatorSelectorColor:
                              achievment
                                  .mediaAndVideoList
                                  .length ==
                                  1
                                  ? Colors.transparent
                                  :  Color(
                                  0XFFFFFFFF),
                              shape:
                              IndicatorShape.circle(
                                  size: 5.0),
                            ))
                            :  Stack(children: <Widget>[
                           Image.asset(
                            "assets/profile/default_achievement.png",
                            fit: BoxFit.cover,
                            height: 215.50,
                            width: double.infinity,
                          ),

                        ])),
                    PaddingWrap.paddingfromLTRB(
                        17.0,
                        10.0,
                        17.0,
                        0.0,
                         Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.start,
                          children: <Widget>[
                             Row(
                              children: <Widget>[
                                 Expanded(
                                  child:  Text(
                                    achievment
                                        .title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.start,
                                    style:  TextStyle(
                                        color:   ColorValues.HEADING_COLOR_EDUCATION,
                                        fontSize: 16.0,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                  ),
                                  flex: 1,
                                ),

                              ],
                            ),

                             Row(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    5.0,
                                     Text(
                                      getConvertedDateStamp2(
                                          achievment
                                              .fromDate) +
                                          " - " +
                                          getConvertedDateStamp2(
                                              achievment
                                                  .toDate),
                                      textAlign:
                                      TextAlign.left,
                                      maxLines: null,
                                      style:  TextStyle(
                                          color:  Color(
                                              0xFF404040),
                                          fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                          fontSize: 14.0),
                                    )),
                              ],
                            ),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                5.0,
                                0.0,
                                5.0,
                                 Text(
                                  achievment
                                      .description,
                                  maxLines:achievment
                                      .isShowMore
                                      ? 25
                                      : 3,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  style:  TextStyle(
                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                      fontSize: 14.0,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                )),
                             Row(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              mainAxisAlignment:
                              MainAxisAlignment.start,
                              children: <Widget>[
                                 Expanded(
                                  child: achievment
                                      .description
                                      .length >
                                      130
                                      ?  InkWell(
                                    child:
                                    PaddingWrap
                                        .paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        15.0,
                                        10.0,
                                         Text(
                                          achievment
                                              .isShowMore
                                              ? "Less"
                                              : "More",
                                          maxLines: 1,
                                          overflow:
                                          TextOverflow
                                              .ellipsis,
                                          textAlign:
                                          TextAlign
                                              .start,
                                          style:  TextStyle(
                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                              fontSize: 14.0,
                                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                    onTap: () {
                                      if (achievment
                                          .isShowMore)
                                        achievment
                                            .isShowMore =
                                        false;
                                      else
                                        achievment
                                            .isShowMore = true;
                                      setState(() {
                                        achievment
                                            .isShowMore;
                                      });
                                    },
                                  )
                                      :  Container(
                                    height: 0.0,
                                  ),
                                  flex: 0,
                                ),
                              ],
                            ),
                            getgridBadges(),
                          ],
                        )),

                  ],
                ),
                onTap: () {},
              )
            ],
          ),flex: 1,),

        ],)
      ),
    );
  }


}
class ModelData {
  String name, date;
  bool isSelected=false;
  ModelData(this.name, this.date);
}