import 'dart:io';

import 'package:flutter/cupertino.dart';

class TestDataModel {
  String testName;
  int testId, userTestId;
  String dateTaken;
  String longDate;
  int dateTakenInt;
  List<String> docList;
  List<String> imgList;
  List<SubjectListModel> subjectListModel;
  bool isShowMore = false;

  TestDataModel(
      this.testName,
      this.testId,
      this.userTestId,
      this.dateTaken,
      this.dateTakenInt,
      this.docList,
      this.subjectListModel,
      this.imgList,
      this.longDate);

  Map<String, dynamic> toJson() => {
        "testId": testId,
        "userTestId": userTestId,
        "dateTaken": longDate,
        "docUrl": docList.map((item) => item).toList(),
        "imageUrl": imgList.map((item) => item).toList(),
        "score": subjectListModel.map((item) => item.toJson()).toList(),
      };
}

class MainScoreModel {
  List<TestDataModel> mainTestList;
  String testName;
  int testId;
  bool isShowMore = false;
  bool isSelected = false;

  MainScoreModel(
      this.mainTestList, this.testName, this.testId, this.isSelected);
}

class SubjectListModel {
  String subjectName,score;
  int  minScore, maxScore, testSubId;
  TextEditingController textEditingController;
bool isOptional;
  SubjectListModel(this.subjectName, this.score, this.minScore, this.maxScore,
      this.testSubId, this.textEditingController,this.isOptional);

  Map<String, dynamic> toJson() => {
        "testSubId": this.testSubId,
        "score": (this.textEditingController.text.toString())
      };
}
