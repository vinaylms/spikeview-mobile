import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class GroupListForPost extends StatefulWidget {
  List<String> groupidList;
  String groupId;

  GroupListForPost(this.groupidList, this.groupId);

  @override
  State<StatefulWidget> createState() => GroupListForPostState();
}

class GroupListForPostState extends State<GroupListForPost>
    with BaseCommonWidget {
  List<GroupModel> groups = [];
  List<GroupModel> subList = [];

  List<bool> selectedCheckedList = List();
  bool isSelectAll = false;
  var isButtonEnable = false;
  List<String> groupIdList = List();
  String userIdPref, token;
  SharedPreferences prefs;
  int selectedIndex = -1;
  GroupListModel groupListModel;
  final TextEditingController _searchQuery = TextEditingController();
  bool _IsSearching;
  bool isLoading;
  String roleId;
  String _searchText = "";

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    await fetchGroupList();

    if (widget.groupidList.length > 0) {
      for (int i = 0; i < widget.groupidList.length; i++) {
        for (int j = 0; j < subList.length; j++) {
          if ((widget.groupidList[i].toString() ==
              subList[j].groupId.toString())) {
            groupIdList.add(widget.groupidList[i]);
            subList[j].isSelected = true;
          }
        }
      }
      isButtonEnable = true;
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    _IsSearching = false;
    _searchQuery.addListener(() {
      if (_searchQuery.text.isEmpty) {
        print("sss name string sss1");
        subList.clear();
        subList.addAll(groups);
        setState(() {
          _IsSearching = false;
          _searchText = "";
        });
      } else {
        print("sss name string sss2");
        if (_searchQuery.text.trim().length > 0) {
          setState(() {
            _IsSearching = true;
            _searchText = _searchQuery.text;
          });

          subList.clear();
          for (int i = 0; i < groups.length; i++) {
            String name = groups[i].groupName;
            print(
                "sss name string ${name.substring(0, name.length).toLowerCase()}");
            if (name
                .substring(0, name.length)
                .toLowerCase()
                .contains(_searchText.toLowerCase())) {
              subList.add(groups[i]);
            }
          }

          setState(() {});
        }
      }
    });

    super.initState();
  }

  Future fetchGroupList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {

        });
        Response response;
        response = await ApiCalling().apiCall(context,
            Constant.ENDPOINT_GROUPS_ALL + userIdPref + "/" + roleId, "get");

        print(response.toString());
        isLoading = false;
        setState(() {

        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groups.clear();
              groupListModel = ParseJson.parseGroupData2(
                  response.data['result'], userIdPref, roleId, widget.groupId);
              if (groupListModel.groupList.length > 0) {
                setState(() {
                  groups.addAll(groupListModel.groupList);
                  subList.addAll(groupListModel.groupList);
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
      });
    }
  }

  Widget addButton() {
    return Padding(
        padding: EdgeInsets.only(top: 30.0),
        child: Container(
            margin: EdgeInsets.only(left: 20, right: 20, bottom: 20),
            height: 44.0,
            child: FlatButton(
              onPressed: () {
                if (groupIdList.length > 0 || subList.length > 0) {
                  Navigator.pop(context, groupIdList);
                } else {
                  ToastWrap.showToast(MessageConstant.ENTER_GROUP, context);
                }
              },
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              color: isButtonEnable
                  ? AppConstants.colorStyle.lightBlue
                  : AppConstants.colorStyle.lightBlueButtonDisableColor,
              child: Row(
                // Replace with a Row for horizontal icon + text
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text('Add',
                      style: AppConstants
                          .txtStyle.heading18600LatoRegularWhite),
                ],
              ),
            ),
        ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      bottomNavigationBar: addButton(),
      backgroundColor: ColorValues.WHITE,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/generateScript/script_background.png"),
            fit: BoxFit.fill,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 50, 20, 22),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Image.asset(
                      "assets/generateScript/back.png",
                      height: 32.0,
                      width: 32.0,
                    ),
                  ),
                  const HelpButtonWidget(),
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 25),
                    Text(
                      "Select group",
                      style:
                          AppConstants.txtStyle.heading28700LatoRegularDarkBlue,
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: Column(
                        //padding: EdgeInsets.zero,
                        //shrinkWrap: true,
                        children: <Widget>[
                          const SizedBox(height: 10),
                          isLoading
                              ? const SizedBox.shrink()
                              :groups.length > 0
                              ? Expanded(
                                child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Container(
                                        height: 45.0,
                                        decoration: BoxDecoration(
                                          color: AppConstants.colorStyle.tabBg,
                                          border: Border.all(
                                              color:
                                                  AppConstants.colorStyle.btnBg),
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(10)),
                                        ),
                                        child: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 15),
                                          child: TextFormField(
                                              controller: _searchQuery,
                                              cursorColor: Constant.CURSOR_COLOR,
                                              textCapitalization:
                                                  TextCapitalization.sentences,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontSize: 16.0,
                                                  fontFamily:
                                                      Constant.latoRegular),
                                              validator: (val) => val
                                                      .trim()
                                                      .isEmpty
                                                  ? MessageConstant
                                                      .ENTER_INSTITUTE_NAME_VAL
                                                  : null,
                                              decoration: InputDecoration(
                                                hintText: 'Search in your groups',
                                                suffixIcon: Padding(
                                                  padding: EdgeInsets.all(12.0),
                                                  child: Image.asset(
                                                    "assets/feed/search.png",
                                                  ),
                                                ),
                                                contentPadding:
                                                    const EdgeInsets.fromLTRB(
                                                        0.0, 6.0, 5.0, 3.0),
                                                enabledBorder: InputBorder.none,
                                                hintStyle: TextStyle(
                                                    fontSize: 14,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    fontWeight: FontWeight.w400,
                                                    color:
                                                        ColorValues.labelColor),
                                                focusedBorder: InputBorder.none,
                                                labelStyle: TextStyle(
                                                    color: ColorValues.labelColor,
                                                    fontFamily:
                                                        Constant.latoRegular),
                                                counterText: "",
                                                fillColor:
                                                    ColorValues.BORDER_COLOR_NEW,
                                              )),
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          InkWell(
                                            onTap: () {
                                              setState(() {
                                                if (!isSelectAll) {
                                                  for (int i = 0;
                                                      i < subList.length;
                                                      i++) {
                                                    subList[i].isSelected = true;
                                                    groupIdList
                                                        .add(subList[i].groupId);
                                                    selectedCheckedList.add(true);
                                                  }
                                                } else {
                                                  for (int i = 0;
                                                      i < subList.length;
                                                      i++) {
                                                    subList[i].isSelected = false;
                                                    groupIdList.remove(
                                                        subList[i].groupId);
                                                    selectedCheckedList
                                                        .remove(true);
                                                  }
                                                }
                                                isSelectAll = !isSelectAll;
                                                if (groupIdList.length > 0) {
                                                  isButtonEnable = true;
                                                } else {
                                                  isButtonEnable = false;
                                                }
                                              });
                                            },
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.only(top: 10),
                                              child: Text(
                                                subList.length > 0
                                                    ? isSelectAll
                                                        ? "Clear all"
                                                        : "Select all"
                                                    : "",
                                                style: AppConstants.txtStyle
                                                    .heading14500LatoRegularDarkBlue,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 12),
                                      subList.length > 0
                                          ? Expanded(
                                            child: ListView.builder(
                                                padding: EdgeInsets.zero,
                                                itemCount: subList.length,
                                                shrinkWrap: true,
                                                itemBuilder: (context, index) {
                                                  return InkWell(
                                                    child: itemWidget(index),
                                                    onTap: () {},
                                                  );
                                                },
                                              ),
                                          )
                                          : Center(
                                              child: PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  30.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap.textViewMultiLine(
                                                      "No Data Found.",
                                                      TextAlign.center,
                                                      ColorValues.GREY_TEXT_COLOR,
                                                      16.0,
                                                      FontWeight.normal,
                                                      2))),
                                    ],
                                  ),
                              )
                              : groups.length == 0
                                  ? Container(
                            width: double.infinity,
                            child: Column(
                              children: <Widget>[
                                Padding(
                                    padding:
                                    const EdgeInsets.fromLTRB(
                                        30, 50, 30, 7),
                                    child: Image.asset(
                                      "assets/no_group.png",
                                      height: 150.0,
                                      width: 300.0,
                                    )),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      13, 0, 13, 2),
                                  child: Text(
                                    "It looks like you haven’t created or joined a group.",
                                    style: TextStyle(
                                        color: ColorValues
                                            .GREY_TEXT_COLOR,
                                        fontFamily: Constant
                                            .TYPE_CUSTOMREGULAR,
                                        fontSize: 14),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ],
                            ),
                          )
                                  : PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      30.0,
                                      0.0,
                                      0.0,
                                      TextViewWrap.textViewMultiLine(
                                          "No Data Found.",
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          16.0,
                                          FontWeight.normal,
                                          2)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget itemWidget(int index) {
    GroupModel model = subList[index];
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  ParseJson.getSmallImage(model.groupImage),
              placeHolderImage:
                  'assets/newDesignIcon/group/default_circle_bg.png',
              height: 48,
              width: 48,
              onTap: () {},
              withoutShadow: true,
            ),
            flex: 0,
          ),
          Expanded(
            child: PaddingWrap.paddingfromLTRB(
                5.0,
                0.0,
                5.0,
                10.0,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        7.0,
                        0.0,
                        2.0,
                        0.0,
                        RichText(
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.start,
                          text: TextSpan(
                            text: model.groupName + " ",
                            style: TextStyle(
                              fontStyle: FontStyle.normal,
                              color: AppConstants.colorStyle.darkBlue,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                            ),
                            children: (!model.isAdmin)
                                ? null
                                : <TextSpan>[
                                    TextSpan(
                                        text: '(Owner)',
                                        style: TextStyle(
                                          fontStyle: FontStyle.normal,
                                          color:
                                              AppConstants.colorStyle.darkBlue,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                        ))
                                  ],
                          ),
                        )),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Row(
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                7.0,
                                6.0,
                                0.0,
                                0.0,
                                Image.asset(
                                  model.type == "private"
                                      ? "assets/png/private_group.png"
                                      : "assets/png/public_group.png",
                                  height: 15.0,
                                  width: 15.0,
                                ),
                              ),
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  5.0,
                                  0.0,
                                  0.0,
                                  BaseText(
                                    text: model.type ==
                                            MessageConstant.ABOUT_GROUP_PRIVATE
                                        ? MessageConstant
                                            .ABOUT_GROUP_PRIVATE_GROUP
                                        : MessageConstant
                                            .ABOUT_GROUP_PUBLIC_GROUP,
                                    textColor: ColorValues.labelColor,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                    textAlign: TextAlign.start,
                                    maxLines: 3,
                                  ))
                            ],
                          ),
                          flex: 1,
                        ),
                      ],
                    )
                  ],
                )),
            flex: 1,
          ),
          Expanded(
              child: PaddingWrap.paddingfromLTRB(
                  10.0,
                  0.0,
                  0.0,
                  0.0,
                  SizedBox(
                      width: 40.0,
                      height: 40.0,
                      child: Theme(
                        data: ThemeData(
                          unselectedWidgetColor: Colors.transparent,
                        ),
                        child: InkWell(
                          child: Padding(
                              padding: EdgeInsets.fromLTRB(8.0, 0.0, 0.0, 0.0),
                              child: Row(
                                children: <Widget>[
                                  subList[index].isSelected
                                      ? Expanded(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 0.0, 0.0),
                                              child: Image.asset(
                                                "assets/feed/checkedBox.png",
                                                height: 24.0,
                                                width: 24.0,
                                              )),
                                          flex: 0)
                                      : Expanded(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 0.0, 0.0),
                                              child: Image.asset(
                                                "assets/feed/unCheckedBox.png",
                                                height: 24.0,
                                                width: 24.0,
                                              )),
                                          flex: 0),
                                ],
                              )),
                          onTap: () {
                            bool value = subList[index].isSelected;

                            if (groupIdList.contains(subList[index].groupId)) {
                              subList[index].isSelected = false;
                              groupIdList.remove(subList[index].groupId);
                              selectedCheckedList.remove(true);
                            } else {
                              subList[index].isSelected = true;
                              groupIdList.add(subList[index].groupId);
                              selectedCheckedList.add(true);
                            }

                            // setState(() {});
                            // if (value) {
                            //    subList[index].isSelected = false;
                            //   selectedCheckedList.remove(true);
                            // } else {
                            //    subList[index].isSelected = true;
                            //   selectedCheckedList.add(true);
                            // }

                            setState(() {
                              subList[index].isSelected;
                              if (groupIdList.length > 0) {
                                isButtonEnable = true;
                              } else {
                                isButtonEnable = false;
                              }

                              if (groupIdList.length == subList.length) {
                                isSelectAll = true;
                              }
                              if (groupIdList.length == 0) {
                                isSelectAll = false;
                              }
                            });
                          },
                        ),
                      ))),
              flex: 0),
        ],
      ),
    );
  }
}
