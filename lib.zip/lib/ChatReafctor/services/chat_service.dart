import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:injectable/injectable.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ChatReafctor/model/ChatModel.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/constant/Constant.dart';

@lazySingleton
class ChatService {
  SharedPreferences prefs;
  String userIdPref, roleId;
  List<ChatData> _posts =  List();

  List<ChatData> get posts => _posts;

  bool get hasPosts => _posts != null;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
  }

  Future<List<ChatData>> getPosts(
      Friends model, skip, bool loader, BuildContext mContext) async {
    try {
      if (loader) {
        CustomProgressLoader.showLoader(mContext);
      }
      ChatModel.previousDateStamp = "";
      await getSharedPreferences();
      print('chatApi+by chat service...++++++++==' + ChatModel.previousDateStamp);
      _posts.clear();
// 103.21.53.11:3004/ui/allMessage?connectorId=991&userId=1&roleId=1
      print(Constant.ENDPOINT_CHAT_HISTORY +
          model.connectId.toString() +
          "&userId=" +
          userIdPref.toString() +
          "&roleId=" +
          roleId.toString() +
          "&skip=" +
          skip.toString());

      Response response= await  ApiCalling2().apiCall(
          null,
          Constant.ENDPOINT_CHAT_HISTORY +
              model.connectId.toString() +
              "&userId=" +
              userIdPref.toString() +
              "&skip=" +
              skip.toString() +
              "&roleId=" +
              roleId.toString(),
          "get");

      _posts.clear();
      print('response+++++++++==' + response.toString());
      String convertedDateString = "";
      if (userIdPref == 1) {
        if (model.creationTime != null &&
            model.creationTime != "null" &&
            model.creationTime != "") {
          int millis = int.tryParse(model.creationTime.toString());
          var now =  DateTime.fromMillisecondsSinceEpoch(millis);
          var formatter =  DateFormat('MMM dd, yyyy');
          String formatted = formatter.format(now);
          ChatModel.previousDateStamp = formatted;
          convertedDateString = formatted;
        }
      } else {
        if (model.partnerId.toString() == "1") {
          String creationTime = prefs.getString(UserPreference.CREATION_TIME);
          if (creationTime != null &&
              creationTime != "null" &&
              creationTime != "") {
            int millis = int.tryParse(creationTime.toString());
            var now =  DateTime.fromMillisecondsSinceEpoch(millis);
            var formatter =  DateFormat('MMM dd, yyyy');
            String formatted = formatter.format(now);

            ChatModel.previousDateStamp = formatted;
            convertedDateString = formatted;
          }
        }
      }

      ChatModel _mFrienndListModel = await ChatModel.fromJson(response.data);

      if (loader) {
        CustomProgressLoader.cancelLoader(mContext);
      }

      if (userIdPref == "1") {
        _posts.add(new ChatData(
            messageId: 010,
            connectorId: 0,
            sender: 1,
            receiver: 0,
            deletedBy: 0,
            time: model.creationTime,
            text:
                "Welcome to spikeview! Look around, invite your friends and let us know how we can help.",
            type: 1,
            status: 0,
            convertedDateString: convertedDateString));
      } else {
        String creationTime = prefs.getString(UserPreference.CREATION_TIME);
        if (creationTime == null ||
            creationTime == "null" ||
            creationTime == "") {
          creationTime = "0";
          if (model.partnerId.toString() == "1") {
            _posts.add(new ChatData(
                messageId: 010,
                connectorId: 0,
                sender: 1,
                receiver: 0,
                deletedBy: 0,
                time: int.parse(creationTime),
                text:
                "Welcome to spikeview! Look around, invite your friends and let us know how we can help.",
                type: 1,
                status: 0,
                convertedDateString: convertedDateString));
          }
        }else{
          if (model.partnerId.toString() == "1") {
            _posts.add(new ChatData(
                messageId: 010,
                connectorId: 0,
                sender: 1,
                receiver: 0,
                deletedBy: 0,
                time:int.parse(creationTime),
                text:
                "Welcome to spikeview! Look around, invite your friends and let us know how we can help.",
                type: 1,
                status: 0,
                convertedDateString: convertedDateString));
          }
        }



      }
      _posts.addAll(_mFrienndListModel.mChatDataList);
    } catch (e) {
      if (loader) {
        CustomProgressLoader.cancelLoader(mContext);
      }
    }
    return _posts;
  }
}
