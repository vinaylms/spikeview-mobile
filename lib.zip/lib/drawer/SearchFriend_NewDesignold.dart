import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/image_utils.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/OpportunityDetaill.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/accomplishment/AddAchievment.dart';
import 'package:spike_view_project/gateway/ChangePassword.dart';
import 'package:spike_view_project/Connection/Connections.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

import 'OpportunitySearch.dart';

class SearchFriendNewDesign extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return SearchFriendState();
  }
}

class SearchFriendState extends State<SearchFriendNewDesign>
    with BaseCommonWidget {
  bool isHome = true;
  bool isConnection = false;
  bool isMessage = false;
  bool isMore = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  static StreamController syncDoneController = StreamController.broadcast();
  TextEditingController _searchQuery = TextEditingController(text: "");
  bool _IsSearching;
  String _searchText = "", previousText = "";
  SharedPreferences prefs;
  String userIdPref, token, roleId;
  bool isParent = false;
  int previousLength = 0;
  List<ProfileInfoModal> friendList = List();

  List<GroupInfoModel> groupList = List();

  List<ProfileInfoModal> parentList = List();

  List<ProfileInfoModal> partnerList = List();
  List<OpportunityModelForFeed> _mOpportunityModelList = List();
  int offset = 0;
  int groupCount = 0;
  int parentCount = 0;
  int studentCount = 0;
  int partnerCount = 0;
  int opportunityCount = 0;

  bool isApiCalling = false;
  bool isApiCallingLoader = false;

  String doubleCodeForSearchHint = "\"";

  List<String> searchFilterNameList = List();
  bool isStudentFilterSelected = false;
  bool isPartnerFilterSelected = false;
  bool isParentFilterSelected = false;
  bool isGroupFilterSelected = false;
  UploadMedia uploadMedia;

  void deSelectAllFilters() {
    isStudentFilterSelected = false;
    isPartnerFilterSelected = false;
    isParentFilterSelected = false;
    isGroupFilterSelected = false;
  }

  //--------------------------My Narratives Info api ------------------
  Future apiCallingForFrindList() async {
    try {
      Response response = await ApiCalling()
          .apiCall(context, Constant.ENDPOINT_FRIEND_LIST + userIdPref, "get");
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            friendList.clear();
            groupList.clear();
            parentList.clear();
            partnerList.clear();

            var result = response.data['result'];

            friendList = ParseJson.parseUserFriendList(
                result.data['userList'], userIdPref);

            groupList =
                ParseJson.parseGroupList(result.data['groupList'], userIdPref);

            if (friendList.length > 0) {
              setState(() {
                friendList;
                groupList;
              });
            }
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------My Narratives Info api ------------------
  Future apiCallingForFrindList2() async {
    print("Alok Tiwari API called");
    try {
      if (_searchQuery.text.toString().length >= 1) {
        previousText = _searchQuery.text;
        print("load datta+++++" + Constant.ENDPOINT_SEARCH_RESKIN +
            _searchQuery.text.toString() +
            "&like=true" +
            "&userId=" +
            userIdPref +
            "&roleId=" +
            roleId);
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_SEARCH_RESKIN +
                _searchQuery.text.toString() +
                "&like=true" +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");
        isApiCalling = false;
        setState(() {
          isApiCalling;
        });

        print("AUTH" + token);
        print("Response " + response.data.toString());
        print("Reqest here" +
            Constant.ENDPOINT_SEARCH_RESKIN +
            _searchQuery.text.toString() +
            "&like=true" +
            "&userId=" +
            userIdPref);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              friendList.clear();
              groupList.clear();
              parentList.clear();
              partnerList.clear();
              _mOpportunityModelList.clear();
              groupCount = 0;
              studentCount = 0;
              parentCount = 0;
              partnerCount = 0;
              opportunityCount = 0;

              var result = response.data['result'];
              groupCount = result['groupCount'];
              studentCount = result['studentCount'];
              parentCount = result['parentCount'];
              partnerCount = result['partnerCount'];
              opportunityCount = result['opportunityCount'];

              var userListMap = result['studentList'] as List;
              if (userListMap.length > 0) {
                friendList =
                    ParseJson.parseUserFriendList(userListMap, userIdPref);
              }
              // if(!isParent){
              var groupListMap = result['groupList'] as List;
              if (groupListMap.length > 0) {
                groupList = ParseJson.parseGroupList(groupListMap, userIdPref);
              }
              //   }

              var parentListMap = result['parentList'] as List;
              if (parentListMap.length > 0) {
                parentList =
                    ParseJson.parseUserFriendList(parentListMap, userIdPref);
              }

              var partnerListMap = result['partnerList'] as List;
              if (partnerListMap.length > 0) {
                partnerList =
                    ParseJson.parseUserFriendList(partnerListMap, userIdPref);
              }

              print("opportunityList+++++" +
                  result['opportunityList'].toString());
              var opportunityListMap = result['opportunityList'] as List;
              if (opportunityListMap.length > 0) {
                _mOpportunityModelList =
                    ParseJson.parseOpportunity(opportunityListMap, userIdPref);
              }

              if (friendList.length > 0 ||
                  groupList.length > 0 ||
                  partnerList.length > 0 ||
                  parentList.length > 0) {
                setState(() {
                  groupCount;
                  studentCount;
                  parentCount;
                  partnerCount;
                  opportunityCount;

                  friendList;
                  groupList;
                  parentList;
                  partnerList;
                  _mOpportunityModelList;
                });
              }
            }
          }
        }
      }
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
    } catch (e) {
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
      e.toString();
    }
  }

  Future apiCallingForFrindFullList3(s, status1) async {
    print(s);
    friendList.clear();
    groupList.clear();
    parentList.clear();
    partnerList.clear();
    try {
      if (s.length >= 1) {
        previousText = _searchQuery.text;
        CustomProgressLoader.showLoader(context);
        isApiCallingLoader = true;
        setState(() {
          isApiCallingLoader;
        });
        print(
          "Response here" +
              Constant.ENDPOINT_SEARCH_RESKIN_BY_STATUS +
              s +
              "&userId=" +
              userIdPref +
              "&roleId=" +
              roleId +
              "&status=" +
              status1 +
              "&like=true",
        );

        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_SEARCH_RESKIN_BY_STATUS +
                s +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId +
                "&status=" +
                status1 +
                "&like=true",
            "get");
        isApiCalling = false;
        setState(() {
          isApiCalling;
        });
        CustomProgressLoader.cancelLoader(context);
        print(
          "Response here" + response.toString(),
        );
        isApiCallingLoader = false;
        setState(() {
          isApiCallingLoader;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var result = response.data['result'];
              print(result);

              if (status1 == "1") {
                var userListMap = result['dataList'] as List;
                print("Length+++" + userListMap.length.toString());
                friendList.clear();
                if (userListMap.length > 0) {
                  friendList =
                      ParseJson.parseUserFriendList(userListMap, userIdPref);
                }
              } else if (status1 == "2") {
                var parentListMap = result['dataList'] as List;
                print("datatlength+++" + parentListMap.length.toString());
                if (parentListMap.length > 0) {
                  parentList =
                      ParseJson.parseUserFriendList(parentListMap, userIdPref);
                }
              } else if ((status1 == "10")) {
                var groupListMap = result['groupList'] as List;
                if (groupListMap.length > 0) {
                  groupList =
                      ParseJson.parseGroupList(groupListMap, userIdPref);
                }
              } else if (status1 == "4") {
                var partnerListMap = result['dataList'] as List;
                if (partnerListMap.length > 0) {
                  partnerList =
                      ParseJson.parseUserFriendList(partnerListMap, userIdPref);
                }
              }

              // if(!isParent){

              //   }

              if (friendList.length > 0 ||
                  groupList.length > 0 ||
                  partnerList.length > 0 ||
                  parentList.length > 0) {
                setState(() {
                  friendList;
                  groupList;
                  parentList;
                  partnerList;
                });
              }
            }
          }
        }
      }
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
    } catch (e) {
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
      e.toString();
    }
  }

  Future apiLoadMore(s, status1) async {
    try {
      if (s.length >= 1) {
        previousText = _searchQuery.text;

        isApiCallingLoader = true;
        setState(() {
          isApiCallingLoader;
        });
        print(
          "Response here" +
              Constant.ENDPOINT_SEARCH_RESKIN_BY_STATUS +
              s +
              "&userId=" +
              userIdPref +
              "&roleId=" +
              roleId +
              "&status=" +
              status1 +
              "&like=true" +
              "&skip=" +
              offset.toString(),
        );

        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_SEARCH_RESKIN_BY_STATUS +
                s +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId +
                "&status=" +
                status1 +
                "&like=true" +
                "&skip=" +
                offset.toString(),
            "get");
        isApiCalling = false;
        setState(() {
          isApiCalling;
        });

        print(
          "Response here" + response.toString(),
        );
        isApiCallingLoader = false;
        setState(() {
          isApiCallingLoader;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var result = response.data['result'];
              print(result);

              if (status1 == "1") {
                var userListMap = result['dataList'] as List;
                print("Length+++" + userListMap.length.toString());

                if (userListMap.length > 0) {
                  var _friendList =
                  ParseJson.parseUserFriendList(userListMap, userIdPref);
                  friendList.addAll(_friendList);
                }
              } else if (status1 == "2") {
                var parentListMap = result['dataList'] as List;
                print("datatlength+++" + parentListMap.length.toString());
                if (parentListMap.length > 0) {
                  var _parentList =
                  ParseJson.parseUserFriendList(parentListMap, userIdPref);
                  parentList.addAll(_parentList);
                }
              } else if ((status1 == "")) {
                var groupListMap = result['groupList'] as List;
                if (groupListMap.length > 0) {
                  var _groupList =
                  ParseJson.parseGroupList(groupListMap, userIdPref);
                  groupList.addAll(_groupList);
                }
              } else if (status1 == "4") {
                var partnerListMap = result['dataList'] as List;
                if (partnerListMap.length > 0) {
                  var _partnerList =
                  ParseJson.parseUserFriendList(partnerListMap, userIdPref);
                  partnerList.addAll(_partnerList);
                }
              }

              // if(!isParent){

              //   }

              if (friendList.length > 0 ||
                  groupList.length > 0 ||
                  partnerList.length > 0 ||
                  parentList.length > 0) {
                setState(() {
                  friendList;
                  groupList;
                  parentList;
                  partnerList;
                });
              }
            }
          }
        }
      }
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
    } catch (e) {
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
      e.toString();
    }
  }

  Timer _timer;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    isParent = prefs.getBool("isParent");

    if (isParent == null) {
      isParent = false;
    }
    // anaylytics.setCurrentSreen(ScreenNameConstant.search_activity);
  }

  ScrollController _controller = ScrollController();

  _scrollListener() {
    if (isStudentFilterSelected ||
        isPartnerFilterSelected ||
        isParentFilterSelected ||
        isGroupFilterSelected) {
      if (_controller.offset >= _controller.position.maxScrollExtent &&
          !_controller.position.outOfRange) {
        offset++;

        if (isStudentFilterSelected)
          apiLoadMore(_searchQuery.text, "1");
        else if (isParentFilterSelected)
          apiLoadMore(_searchQuery.text, "2");
        else if (isGroupFilterSelected)
          apiLoadMore(_searchQuery.text, "");
        else if (isPartnerFilterSelected) apiLoadMore(_searchQuery.text, "4");
      }
    }
  }

  int searchingTime = 2000;

  @override
  void initState() {
    _controller = ScrollController();
    uploadMedia = UploadMedia(context);
    _controller.addListener(_scrollListener);
    searchFilterNameList.add("STUDENTS");
    searchFilterNameList.add("PARENTS");
    searchFilterNameList.add("GROUPS");
    searchFilterNameList.add("PARTNERS");

    getSharedPreferences();

    // TODO: implement initState
    _IsSearching = false;
    _searchQuery.addListener(() {
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
      if (_searchQuery.text.isEmpty) {
        searchingTime = 2000;
        setState(() {
          print("is empty++++++");
          isApiCalling = false;
          friendList.clear();
          groupList.clear();
          parentList.clear();
          partnerList.clear();
          isApiCalling;
          _IsSearching = false;
          _searchText = "";
        });
      } else {
        if (_searchQuery.text.trim().length >= 1) {
          print("+++++++Shubh++++++" + _searchQuery.text);
          searchingTime = searchingTime + 1500;

          if (previousText != _searchQuery.text) {
            if (_timer != null) {
              _timer.cancel();
            }

            _timer = Timer(Duration(milliseconds: 1500), () {
              print("++++Shubh+++Api++" + _searchQuery.text);
              print("++++Shubh+++Api++" + searchingTime.toString());

              previousText = _searchQuery.text;
              isApiCalling = true;
              setState(() {
                friendList.clear();
                isApiCalling;
              });
              friendList.clear();
              groupList.clear();
              parentList.clear();
              partnerList.clear();
              _mOpportunityModelList.clear();
              setState(() {});

              if (!isStudentFilterSelected &&
                  !isParentFilterSelected &&
                  !isGroupFilterSelected &&
                  !isPartnerFilterSelected) {
                searchingTime = 2000;
                _timer.cancel();
                apiCallingForFrindList2();
              } else {
                searchingTime = 2000;
                _timer.cancel();
                if (isStudentFilterSelected)
                  apiCallingForFrindFullList3(_searchQuery.text, "1");
                else if (isParentFilterSelected)
                  apiCallingForFrindFullList3(_searchQuery.text, "2");
                else if (isGroupFilterSelected)
                  apiCallingForFrindFullList3(_searchQuery.text, "10");
                else if (isPartnerFilterSelected)
                  apiCallingForFrindFullList3(_searchQuery.text, "4");
              }

              setState(() {
                _IsSearching = true;
                _searchText = _searchQuery.text;
              });
            });
          }
        } else {
          print("is searching null++++++");
          isApiCalling = false;
          setState(() {
            friendList.clear();
            groupList.clear();
            parentList.clear();
            partnerList.clear();
            isApiCalling;
          });
        }
      }
    });
    super.initState();
  }

  Future apiCallForConnect(userID, index, partnerRoleId) async {
    try {
      if (roleId == "4") {
        ToastWrap.showToast(
            MessageConstant
                .PARTNER_NOT_ALLOWED_CONNECTON_REQUEST_SPIKEVIEW_USERS_ERROR,
            context);
      } else {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          bool ageStatus = false;
          if (prefs.getString(UserPreference.DOB) != null &&
              prefs.getString(UserPreference.DOB) != 'null') {
            ageStatus = Util.currentAge(
                DateTime.fromMillisecondsSinceEpoch(
                    int.tryParse(prefs.getString(UserPreference.DOB))),
                13) <
                13;
          }
          Map map = {
            "userId": userIdPref,
            "partnerId": userID,
            "dateTime": DateTime.now().millisecondsSinceEpoch,
            "status": ageStatus ? "Pending" : "Requested",
            "userRoleId": int.parse(roleId),
            "partnerRoleId": int.parse(partnerRoleId),
            "isActive": true
          };

          print("Map+++" + map.toString());
          Response response = await ApiCalling().apiCallPostWithMapData(
              context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

          print("response:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                //ToastWrap.showToast(msg);

                String connectId =
                response.data["result"]["connectId"].toString();

                if (partnerRoleId == "1") {
                  friendList[index].status = "2";
                  friendList[index].statusVal = "Requested";
                  setState(() {
                    friendList;
                  });
                } else if (partnerRoleId == "2") {
                  parentList[index].status = "2";
                  parentList[index].statusVal = "Requested";
                  setState(() {
                    parentList;
                  });
                } else if (partnerRoleId == "4") {
                  partnerList[index].status = "2";
                  partnerList[index].statusVal = "Requested";
                  setState(() {
                    partnerList;
                  });
                }
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    List<InkWell> _buildGroupSearchList() {
      //    if (_searchText.isEmpty) {
      return List.generate(
          isGroupFilterSelected
              ? groupList.length
              : groupList.length > 3 ? 3 : groupList.length, (int index) {
        return InkWell(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                20.0,
                13.0,
                0.0,
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[



                    Expanded(
                      child: Center(
                        child:  ProfileImageView(
                          imagePath: groupList[index].groupImage != "null" &&
                              groupList[index].groupImage != ""
                              ?'':  Constant.IMAGE_PATH_SMALL +
                              ParseJson.getSmallImage(
                                  groupList[index].groupImage),
                          placeHolderImage: 'assets/newDesignIcon/group/default_circle_bg.png',
                          height: 50.0,
                          width: 50.0,
                          onTap: () async{

                          },
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          0.0,
                          0.0,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Expanded(
                                    child: TextViewWrap.textView(
                                        groupList[index].groupId != "null" &&
                                            groupList[index].groupId != ""
                                            ? groupList[index].groupName
                                            : groupList[index].groupName,
                                        TextAlign.left,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                        14.0,
                                        FontWeight.bold),
                                    flex: 1,
                                  ),
                                ],
                              ),
                              Row(
                                children: <Widget>[
                                  Image.asset(
                                    groupList[index].type ==
                                        Constant.GROUP_TYPE_PUBLIC
                                        ? "assets/newDesignIcon/connections/public.png"
                                        : "assets/newDesignIcon/connections/private.png",
                                    height: 20.0,
                                    width: 20.0,
                                    color: ColorValues.GREY_TEXT_COLOR,
                                  ),
                                  TextViewWrap.textView(
                                    groupList[index].type == null ||
                                        groupList[index].type == "null" ||
                                        groupList[index].type == ""
                                        ? ""
                                        : groupList[index].type + " Group",
                                    TextAlign.right,
                                    ColorValues.GREY_TEXT_COLOR,
                                    12.0,
                                    FontWeight.normal,
                                  ),
                                ],
                              ),
                            ],
                          )),
                      flex: 1,
                    ),
                  ],
                )),
            onTap: () {
              print("group clicked");
              setState(() {
                print("list");
                _IsSearching = false;
              });
              print("groupid");
              print("groupid" + groupList[index].groupId.toString());
              Navigator.of(context).pop();
              if (groupList[index].groupId != "null" &&
                  groupList[index].groupId != "") {
                Navigator.of(context).push(new MaterialPageRoute(
                    builder: (BuildContext context) => GroupDetailWidget(
                        groupList[index].groupId, "search", "", "", "")));
              }
            });
      });
    }

    List<InkWell> _buildFriendSearchList() {
      //    if (_searchText.isEmpty) {
      return List.generate(
          isStudentFilterSelected
              ? friendList.length
              : friendList.length > 3 ? 3 : friendList.length, (int index) {
        return InkWell(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                20.0,
                13.0,
                0.0,
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[



                    Expanded(
                      child: Center(
                        child: ProfileImageView(
                          imagePath: friendList[index].profilePicture != "null"
                              ?'':   Constant.IMAGE_PATH_SMALL +
                              ParseJson.getSmallImage(
                                  friendList[index]
                                      .profilePicture),
                          placeHolderImage: 'assets/profile/user_on_user.png',
                          height: 50.0,
                          width: 50.0,
                          onTap: () async{

                          },
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          0.0,
                          0.0,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Expanded(
                                    child: TextViewWrap.textView(
                                        friendList[index].groupId != "null" &&
                                            friendList[index].groupId != ""
                                            ? friendList[index].groupName
                                            : friendList[index].lastName ==
                                            "null"
                                            ? friendList[index].firstName
                                            : friendList[index].firstName +
                                            " " +
                                            friendList[index].lastName,
                                        TextAlign.left,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                        14.0,
                                        FontWeight.bold),
                                    flex: 0,
                                  ),
                                  Expanded(
                                    child: friendList[index].roleId == "1"
                                        ? Util.getStudentBadge12(
                                        friendList[index].badge,
                                        friendList[index].badgeImage)
                                        : Container(),
                                    flex: 0,
                                  ),
                                ],
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.fromLTRB(0.0, 0, 12, 8),
                                child: friendList[index].tagline == null ||
                                    friendList[index].tagline == "null" ||
                                    friendList[index].tagline == ""
                                    ? Container(
                                  height: 0.0,
                                )
                                    : TextViewWrap.textViewMultiLine(
                                    friendList[index].tagline == null ||
                                        friendList[index].tagline ==
                                            "null" ||
                                        friendList[index].tagline == ""
                                        ? ""
                                        : friendList[index].tagline,
                                    TextAlign.start,
                                    ColorValues.GREY_TEXT_COLOR,
                                    12.0,
                                    FontWeight.normal,
                                    2),
                              ),
                            ],
                          )),
                      flex: 1,
                    ),
                    Expanded(
                      child: InkWell(
                        child: Column(
                          children: <Widget>[
                          /*  Padding(
                                padding:
                                EdgeInsets.fromLTRB(0.0, 0.0, 20.0, 0.0),
                                child: Container(
                                    height: friendList[index].status ==
                                        Constant.ACCEPTED
                                        ? 20.0
                                        : 30.0,
                                    width: friendList[index].status ==
                                        Constant.ACCEPTED
                                        ? 20.0
                                        : 30.0,
                                    child: Image.asset(
                                      friendList[index].status ==
                                          Constant.ACCEPTED
                                          ? 'assets/newDesignIcon/connections/connected_right.png'
                                          : friendList[index].status ==
                                          Constant.REQUESTED ||
                                          friendList[index].status ==
                                              Constant.PENDING
                                          ? 'assets/newDesignIcon/requested_new.png'
                                          : 'assets/newDesignIcon/connections/send_repquest_gray.png',
                                    ))),*/
                            Padding(
                                padding:
                                EdgeInsets.fromLTRB(0.0, 2.0, 22.0, 0.0),
                                child: ButtonView(
                                  btnName: friendList[index].userId ==
                                      "1" //for spikevie bot always connected
                                      ? "Connected"
                                      : friendList[index].status ==
                                      Constant.PENDING
                                      ? "Requested"
                                      : friendList[index].statusVal,
                                  borderColor: AppConstants.colorStyle.lightBlue,
                                  bgColor: AppConstants.colorStyle.box_bg_color,
                                  txtColor: AppConstants.colorStyle.lightBlue,
                                  onButtonTap: () {
                                    if (friendList[index].status ==
                                        Constant.NON_CONNECTION) {
                                      apiCallForConnect(friendList[index].userId, index,
                                          friendList[index].roleId);
                                    }
                                  },
                                )



                               )
                          ],
                        ),
                        onTap: () {
                          if (friendList[index].status ==
                              Constant.NON_CONNECTION) {
                            apiCallForConnect(friendList[index].userId, index,
                                friendList[index].roleId);
                          }
                        },
                      ),
                      flex: 0,
                    ),
                  ],
                )),
            onTap: () {
              print(friendList[index].firstName);
              setState(() {
                print("list");
                _IsSearching = false;
              });

              if (friendList[index].userId == userIdPref) {
              } else {
                Util.onTapImageTile(
                    tapedUserRole: "1",
                    partnerUserId: friendList[index].userId,
                    pageName: "search",
                    context: context);
              }
            });
      });
    }

    List<InkWell> _buildParentsList() {
      //    if (_searchText.isEmpty) {
      return List.generate(
          isParentFilterSelected
              ? parentList.length
              : parentList.length > 3 ? 3 : parentList.length, (int index) {
        return InkWell(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                20.0,
                13.0,
                0.0,
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[



                    Expanded(
                      child: Center(
                        child: ProfileImageView(
                          imagePath: parentList[index].profilePicture != "null"
                              ?'':   Constant.IMAGE_PATH_SMALL +
                              ParseJson.getSmallImage(
                                  parentList[index]
                                      .profilePicture),
                          placeHolderImage: 'assets/profile/user_on_user.png',
                          height: 50.0,
                          width: 50.0,
                          onTap: () async{

                          },
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          0.0,
                          0.0,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              TextViewWrap.textView(
                                  parentList[index].groupId != "null" &&
                                      parentList[index].groupId != ""
                                      ? parentList[index].groupName
                                      : parentList[index].lastName == "null"
                                      ? parentList[index].firstName
                                      : parentList[index].firstName +
                                      " " +
                                      parentList[index].lastName,
                                  TextAlign.left,
                                  ColorValues.HEADING_COLOR_EDUCATION,
                                  14.0,
                                  FontWeight.bold),
                              parentList[index].tagline == null ||
                                  parentList[index].tagline == "null" ||
                                  parentList[index].tagline == ""
                                  ? Container(
                                height: 0.0,
                              )
                                  : TextViewWrap.textView(
                                parentList[index].tagline == null ||
                                    parentList[index].tagline ==
                                        "null" ||
                                    parentList[index].tagline == ""
                                    ? ""
                                    : parentList[index].tagline,
                                TextAlign.right,
                                ColorValues.GREY_TEXT_COLOR,
                                12.0,
                                FontWeight.normal,
                              ),
                            ],
                          )),
                      flex: 1,
                    ),
                    Expanded(
                      child: InkWell(
                        child: Column(
                          children: <Widget>[
                     /*       Padding(
                                padding:
                                EdgeInsets.fromLTRB(0.0, 0.0, 20.0, 0.0),
                                child: Container(
                                    height: parentList[index].status ==
                                        Constant.ACCEPTED
                                        ? 20.0
                                        : 30.0,
                                    width: parentList[index].status ==
                                        Constant.ACCEPTED
                                        ? 20.0
                                        : 30.0,
                                    child: Image.asset(
                                      parentList[index].status ==
                                          Constant.ACCEPTED
                                          ? 'assets/newDesignIcon/connections/connected_right.png'
                                          : parentList[index].status ==
                                          Constant.REQUESTED ||
                                          parentList[index].status ==
                                              Constant.PENDING
                                          ? 'assets/newDesignIcon/requested_new.png'
                                          : 'assets/newDesignIcon/connections/send_repquest_gray.png',
                                    ))),*/



                            Padding(
                                padding:
                                EdgeInsets.fromLTRB(0.0, 2.0, 22.0, 0.0),
                                child: ButtonView(
                                  btnName:   parentList[index].userId == "1"
                                      ? "Connected"
                                      : parentList[index].status ==
                                      Constant.PENDING
                                      ? "Requested"
                                      : parentList[index].statusVal,
                                  borderColor: AppConstants.colorStyle.lightBlue,
                                  bgColor: AppConstants.colorStyle.box_bg_color,
                                  txtColor: AppConstants.colorStyle.lightBlue,
                                  onButtonTap: () {
                                    if (parentList[index].status ==
                                        Constant.NON_CONNECTION) {
                                      apiCallForConnect(parentList[index].userId, index,
                                          parentList[index].roleId);
                                    }
                                  },
                                )

                                )
                          ],
                        ),
                        onTap: () {
                          if (parentList[index].status ==
                              Constant.NON_CONNECTION) {
                            apiCallForConnect(parentList[index].userId, index,
                                parentList[index].roleId);
                          }
                        },
                      ),
                      flex: 0,
                    ),
                  ],
                )),
            onTap: () {
              print(parentList[index].firstName);
              setState(() {
                print("list");
                _IsSearching = false;
              });

              if (parentList[index].userId == userIdPref) {
              } else {
                Util.onTapImageTile(
                    tapedUserRole: "2",
                    partnerUserId: parentList[index].userId,
                    pageName: "search",
                    context: context);
              }
            });
      });
    }

    List<InkWell> _buildPartnerList() {
      //    if (_searchText.isEmpty) {
      return List.generate(
          isPartnerFilterSelected
              ? partnerList.length
              : partnerList.length > 3 ? 3 : partnerList.length, (int index) {
        return InkWell(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                20.0,
                13.0,
                0.0,
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[



                    Expanded(
                      child: Center(
                        child:  ProfileImageView(
                          imagePath: partnerList[index].profilePicture != "null"
                              ?'':   Constant.IMAGE_PATH_SMALL +
                              ParseJson.getSmallImage(
                                  partnerList[index]
                                      .profilePicture),
                          placeHolderImage: 'assets/profile/partner_img.png',
                          height: 50.0,
                          width: 50.0,
                          onTap: () async{

                          },
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          0.0,
                          0.0,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              TextViewWrap.textView(
                                  partnerList[index].groupId != "null" &&
                                      partnerList[index].groupId != ""
                                      ? partnerList[index].groupName
                                      : partnerList[index].lastName == "null"
                                      ? partnerList[index].firstName
                                      : partnerList[index].firstName +
                                      " " +
                                      partnerList[index].lastName,
                                  TextAlign.left,
                                  ColorValues.HEADING_COLOR_EDUCATION,
                                  14.0,
                                  FontWeight.bold),
                              /* partnerList[index].tagline == null ||
                                      partnerList[index].tagline == "null" ||
                                      partnerList[index].tagline == ""
                                  ?  Container(
                                      height: 0.0,
                                    )
                                  : TextViewWrap.textView(
                                      partnerList[index].tagline == null ||
                                              partnerList[index].tagline ==
                                                  "null" ||
                                              partnerList[index].tagline == ""
                                          ? ""
                                          : partnerList[index].tagline,
                                      TextAlign.right,
                                       ColorValues.GREY_TEXT_COLOR,
                                      12.0,
                                      FontWeight.normal,
                                    ),*/
                              TextViewWrap.textView(
                                "",
                                TextAlign.right,
                                ColorValues.GREY_TEXT_COLOR,
                                12.0,
                                FontWeight.normal,
                              )
                            ],
                          )),
                      flex: 1,
                    ),
                    Expanded(
                      child: InkWell(
                        child: Column(
                          children: <Widget>[
                            Padding(
                                padding:
                                EdgeInsets.fromLTRB(0.0, 0.0, 20.0, 0.0),
                                child: Container(
                                    height: partnerList[index].status ==
                                        Constant.ACCEPTED
                                        ? 20.0
                                        : 30.0,
                                    width: partnerList[index].status ==
                                        Constant.ACCEPTED
                                        ? 20.0
                                        : 30.0,
                                    child: Image.asset(
                                      partnerList[index].status ==
                                          Constant.ACCEPTED
                                          ? 'assets/newDesignIcon/connections/connected_right.png'
                                          : partnerList[index].status ==
                                          Constant.REQUESTED ||
                                          partnerList[index].status ==
                                              Constant.PENDING
                                          ? 'assets/newDesignIcon/requested_new.png'
                                          : 'assets/newDesignIcon/connections/send_repquest_gray.png',
                                    ))),
                            Padding(
                                padding:
                                EdgeInsets.fromLTRB(0.0, 2.0, 22.0, 0.0),
                                child:ButtonView(
                                  btnName:   partnerList[index].userId == "1"
                                      ? "Connected"
                                      : partnerList[index].status ==
                                      Constant.PENDING
                                      ? "Requested"
                                      : partnerList[index].statusVal,
                                  borderColor: AppConstants.colorStyle.lightBlue,
                                  bgColor: AppConstants.colorStyle.box_bg_color,
                                  txtColor: AppConstants.colorStyle.lightBlue,
                                  onButtonTap: () {
                                    if (partnerList[index].status ==
                                        Constant.NON_CONNECTION) {
                                      apiCallForConnect(partnerList[index].userId, index,
                                          partnerList[index].roleId);
                                    }
                                  },
                                )

)
                          ],
                        ),
                        onTap: () {
                          if (partnerList[index].status ==
                              Constant.NON_CONNECTION) {
                            apiCallForConnect(partnerList[index].userId, index,
                                partnerList[index].roleId);
                          }
                        },
                      ),
                      flex: 0,
                    ),
                  ],
                )),
            onTap: () {
              print(partnerList[index].firstName);
              setState(() {
                print("list");
                _IsSearching = false;
              });
              print("PartnerRole++++" + partnerList[index].roleId);
              if (partnerList[index].userId == userIdPref) {
              } else {
                Util.onTapImageTile(
                    tapedUserRole: "4",
                    partnerUserId: partnerList[index].userId,
                    pageName: "search",
                    context: context);
              }
            });
      });
    }

    Widget _loader(BuildContext context, String placeHolderImage) => Center(
        child: SizedBox(
          width: 140.0,
          height: 80.0,
          child: Image.asset(
            placeHolderImage,
            fit: BoxFit.cover,
          ),
        ));

    Widget _error(String placeHolderImage) {
      return SizedBox(
        width: 140.0,
        height: 80.0,
        child: Center(
          child: Image.asset(
            placeHolderImage,
            fit: BoxFit.cover,
          ),
        ),
      );
    }

    getData(path) async {
      final thumbnailFile = await uploadMedia
          .getVideoThumbnailFromUrl(Constant.IMAGE_PATH + path);

      return Image.file(
        thumbnailFile,
        fit: BoxFit.contain,
      );
    }

    List<InkWell> _buildOpportunityList() {
      //    if (_searchText.isEmpty) {
      return List.generate(
          _mOpportunityModelList.length > 3 ? 3 : _mOpportunityModelList.length,
              (int index) {
            return InkWell(
                child: PaddingWrap.paddingfromLTRB(
                    13.0,
                    20.0,
                    13.0,
                    0.0,
                    Container(
                      color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                      child: Padding(
                          padding: const EdgeInsets.fromLTRB(7.0, 7, 7, 7),
                          child: InkWell(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Stack(
                                    children: [
                                      _mOpportunityModelList[index]
                                          .assestVideoAndImage
                                          .length >
                                          0
                                          ? _mOpportunityModelList[index]
                                          .assestVideoAndImage[0]
                                          .type ==
                                          "video" ||
                                          _mOpportunityModelList[index]
                                              .assestVideoAndImage[0]
                                              .tag ==
                                              "video"
                                          ? Container(
                                        width: 140.0,
                                        height: 80.0,
                                        child: FutureBuilder(
                                            future: getData(
                                                _mOpportunityModelList[
                                                index]
                                                    .assestVideoAndImage[
                                                0]
                                                    .file),
                                            builder:
                                                (BuildContext context,
                                                AsyncSnapshot<Image>
                                                image) {
                                              if (image.hasData) {
                                                return Container(
                                                    width: 140.0,
                                                    height: 80.0,
                                                    child: image
                                                        .data); // image is ready
                                              } else {
                                                return CachedNetworkImage(
                                                  width: 140.0,
                                                  height: 80.0,
                                                  imageUrl: "",
                                                  fit: BoxFit.fill,
                                                  placeholder: (context,
                                                      url) =>
                                                      _loader(context,
                                                          "assets/aerial/default_img.png"),
                                                  errorWidget: (context,
                                                      url, error) =>
                                                      _error(
                                                          "assets/aerial/default_img.png"),
                                                ); // placeholder
                                              }
                                            }),
                                      )
                                          : CachedNetworkImage(
                                        width: 140.0,
                                        height: 80.0,
                                        imageUrl: Constant.IMAGE_PATH +
                                            _mOpportunityModelList[index]
                                                .assestVideoAndImage[0]
                                                .file,
                                        fit: BoxFit.fill,
                                        placeholder: (context, url) =>
                                            _loader(context,
                                                "assets/aerial/default_img.png"),
                                        errorWidget: (context, url,
                                            error) =>
                                            _error(
                                                "assets/aerial/default_img.png"),
                                      )
                                          : CachedNetworkImage(
                                        width: 140.0,
                                        height: 80.0,
                                        imageUrl: "",
                                        fit: BoxFit.fill,
                                        placeholder: (context, url) => _loader(
                                            context,
                                            "assets/aerial/default_img.png"),
                                        errorWidget: (context, url, error) =>
                                            _error(
                                                "assets/aerial/default_img.png"),
                                      ),
                                      Container(
                                        width: 140.0,
                                        height: 80.0,
                                        color: Colors.black.withOpacity(.2),
                                      ),
                                      Positioned(
                                        bottom: 0.0,
                                        left: 0.0,
                                        right: 0.0,
                                        child: _mOpportunityModelList[index]
                                            .assestVideoAndImage
                                            .length >
                                            1
                                            ? Center(
                                            child: Image.asset(
                                              "assets/newDesignIcon/three_dots.png",
                                              height: 20,
                                              width: 30.0,
                                              color: Colors.white,
                                            ))
                                            : Container(
                                          height: 0.0,
                                        ),
                                      )
                                    ],
                                  ),
                                  flex: 0,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding:
                                    const EdgeInsets.fromLTRB(10.0, 0, 0, 0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        TextViewWrap.textView(
                                          _mOpportunityModelList[index].category ==
                                              "Services" ||
                                              _mOpportunityModelList[index]
                                                  .category ==
                                                  "Programs"
                                              ? _mOpportunityModelList[index].name +
                                              " | " +
                                              _mOpportunityModelList[index]
                                                  .serviceTitle
                                                  .replaceAll("null", "")
                                              : _mOpportunityModelList[index].name +
                                              " | " +
                                              _mOpportunityModelList[index]
                                                  .jobTitle
                                                  .replaceAll("null", ""),
                                          TextAlign.start,
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.bold,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              0.0, 4.0, 0, 0),
                                          child: TextViewWrap.textViewMultiLine(
                                              _mOpportunityModelList[index]
                                                  .offerId ==
                                                  "1" ||
                                                  _mOpportunityModelList[
                                                  index]
                                                      .offerId ==
                                                      "2" ||
                                                  _mOpportunityModelList[
                                                  index]
                                                      .offerId ==
                                                      "3"
                                                  ? _mOpportunityModelList[
                                              index]
                                                  .project
                                                  : _mOpportunityModelList[
                                              index]
                                                  .offerId ==
                                                  "5" ||
                                                  _mOpportunityModelList[
                                                  index]
                                                      .offerId ==
                                                      "4"
                                                  ? _mOpportunityModelList[
                                              index]
                                                  .serviceDesc
                                                  : _mOpportunityModelList[
                                              index]
                                                  .description,
                                              TextAlign.start,
                                              ColorValues.GREY_TEXT_COLOR,
                                              10.0,
                                              FontWeight.normal,
                                              3),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              0.0, 6.0, 0, 0),
                                          child: TextViewWrap.textViewMultiLine(
                                              _mOpportunityModelList[index]
                                                  .category,
                                              TextAlign.start,
                                              ColorValues.GREY__COLOR,
                                              10.0,
                                              FontWeight.normal,
                                              1),
                                        )
                                      ],
                                    ),
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                            onTap: () {
                              print("Opportunityid+++++Search");
                              print("Opportunityid+++++" +
                                  _mOpportunityModelList[index].opportunityId);
                              print("Opportunityid+++++Search2");
                              Navigator.of(context).push(new MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      OpportunityDetaill(
                                          _mOpportunityModelList[index]
                                              .opportunityId,
                                          roleId,
                                          _searchQuery.text.toString(),
                                          "")));
                            },
                          )),
                    )));
          });
    }

    final searchView1 = PaddingWrap.paddingAll(
        0.0,
        TextField(
            controller: _searchQuery,
            autocorrect: false,
            autofocus: true,
            onChanged: (s){
              if(s.toString()==""){
                setState(() {
                  _searchQuery.clear();
                });

              }
            },
            style: new TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.only(top:5.0,bottom: 5),

              border: InputBorder.none,
              errorStyle: Util.errorTextStyle,

              hintText: 'Search here...',
              hintStyle: TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
              labelStyle: TextStyle(
                  fontSize: 16.0,
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )));

    final searchView =  CustomFormField(
      // maxLength: 35,
      controller: _searchQuery,
      onType: (s) {
        if(s.toString()==""){
          setState(() {
            _searchQuery.clear();
          });

        }
      },
      label: "Search here",
      contentPadding:
      EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
      suffixWidget: GestureDetector(
        child:  Padding(
            padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
            child: IconButton(
              onPressed: () {

              },
              icon: Image.asset(
                "assets/newDesignIcon/connections/new_search.png",
                height: 20,
                width: 20,
              ),
            )),
        onTap: () {

        },
      ),

    );

    Widget getButtonOpportunity() {
      return Padding(
        padding: const EdgeInsets.only(
            left: 5.0, right: 5.0, top: 20.0, bottom: 15.0),
        child: InkWell(
          child: Container(
            width: 175.0,
            height: 38.0,
            child: Image.asset(
              "assets/newDesignIcon/explore_opp.png",
              width: 175.0,
              height: 38.0,
            ),
          ),
          onTap: () {
            Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) =>
                    OpportunitySearch(_searchQuery.text)));
          },
        ),
      );
    }

    Widget getSearchFilterView() {
      return Padding(
        padding: const EdgeInsets.only(top: 12.0, left: 5.0, right: 5.0),
        child: Center(
          child: Container(
            height: 32.0,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: List.generate(4, (int index) {
                return Padding(
                  padding: const EdgeInsets.only(left: 5.0, right: 5.0),
                  child: Container(
                    width: 100.0,
                    height: 32.0,
                    color: getBgColor(index),
                    child: InkWell(
                      child: Center(
                        child: Text(
                          searchFilterNameList[index],
                          style: TextStyle(
                              fontSize: 12.0,
                              color: getSelectedTextColor(index),
                              fontFamily: Constant.customRegular),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      onTap: () {
                        onFilterClick(index);
                      },
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      );
    }


    return  WillPopScope(
        onWillPop: () {},
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              Navigator.pop(context);
            },
            child: customAppbar(
                context,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20, top: 24, bottom: 0),
                        child: searchView,
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          getSearchFilterView(),
                          getButtonOpportunity(),

                          friendList.length > 0 ||
                              groupList.length > 0 ||
                              parentList.length > 0 ||
                              partnerList.length > 0 ||
                              _mOpportunityModelList.length > 0
                              ? isStudentFilterSelected ||
                              isParentFilterSelected ||
                              isPartnerFilterSelected ||
                              isGroupFilterSelected
                              ? Container(
                            child: ListView(
                              controller: _controller,
                              children: <Widget>[

                                isStudentFilterSelected
                                    ? friendList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              friendList.length > 0
                                                  ? _searchQuery.text
                                                  .length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery
                                                      .text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN STUDENTS"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color: ColorValues
                                              .GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    friendList.length > 0
                                        ? Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children:
                                      _buildFriendSearchList(),
                                    )
                                        : Container(
                                      height: 0.0,
                                    ),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Container(
                                  height: 0.0,
                                )
                                    : Container(
                                  height: 0.0,
                                ),
                                isParentFilterSelected
                                    ? parentList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              parentList.length > 0
                                                  ? _searchQuery.text
                                                  .length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery
                                                      .text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN PARENTS"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color: ColorValues
                                              .GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    parentList.length > 0
                                        ? Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: _buildParentsList())
                                        : Container(
                                      height: 0.0,
                                    ),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Container(
                                  height: 0.0,
                                )
                                    : Container(
                                  height: 0.0,
                                ),
                                isGroupFilterSelected
                                    ? groupList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              groupList.length > 0
                                                  ? _searchQuery.text
                                                  .length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery
                                                      .text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN GROUPS"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color: ColorValues
                                              .GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    groupList.length > 0
                                        ? Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children:
                                        _buildGroupSearchList())
                                        : Container(
                                      height: 0.0,
                                    ),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Container(
                                  height: 0.0,
                                )
                                    : Container(
                                  height: 0.0,
                                ),
                                isPartnerFilterSelected
                                    ? partnerList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              partnerList.length > 0
                                                  ? _searchQuery.text
                                                  .length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery
                                                      .text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN PARTNERS"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color: ColorValues
                                              .GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    partnerList.length > 0
                                        ? Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: _buildPartnerList())
                                        : Container(
                                      height: 0.0,
                                    ),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Container(
                                  height: 0.0,
                                )
                                    : Container(
                                  height: 0.0,
                                ),
                              ],
                            ),
                            color: ColorValues.LIGHT_GRAY_BG,
                          )
                              : Container(
                            child: ListView(
                              controller: _controller,
                              children: <Widget>[
                                CustomViews.getSepratorLine(),
                                getSearchFilterView(),
                                getButtonOpportunity(),
                                friendList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              friendList.length > 0
                                                  ? _searchQuery.text.length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN STUDENTS"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    friendList.length > 0
                                        ? Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children:
                                      _buildFriendSearchList(),
                                    )
                                        : Container(
                                      height: 0.0,
                                    ),
                                    studentCount > 3
                                        ? Center(
                                      child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            isStudentFilterSelected =
                                            true;
                                          });

                                          apiCallingForFrindFullList3(
                                              _searchQuery.text, "1");
                                        },
                                        child: Container(
                                          child: Padding(
                                            padding: const EdgeInsets
                                                .fromLTRB(
                                                0.0, 30.0, 0.0, 20.0),
                                            child: Text(
                                              "View More",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR,
                                                  fontSize: 14,
                                                  fontFamily: Constant
                                                      .customRegular),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        : Text(""),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 20.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              _searchQuery.text.length > 0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN STUDENTS"
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Center(
                                            child: Padding(
                                              padding: const EdgeInsets.fromLTRB(
                                                  0.0, 16.0, 0.0, 16.0),
                                              child: Text(
                                                "No Result Found",
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold),
                                              ),
                                            )),
                                      ],
                                    )

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                ),
                                parentList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              parentList.length > 0
                                                  ? _searchQuery.text.length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN PARENTS"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    parentList.length > 0
                                        ? Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: _buildParentsList())
                                        : Container(
                                      height: 0.0,
                                    ),
                                    parentCount > 3
                                        ? Center(
                                      child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            isParentFilterSelected =
                                            true;
                                          });

                                          apiCallingForFrindFullList3(
                                              _searchQuery.text, "2");
                                        },
                                        child: Container(
                                          child: Padding(
                                            padding: const EdgeInsets
                                                .fromLTRB(
                                                0.0, 30.0, 0.0, 20.0),
                                            child: Text(
                                              "View More",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR,
                                                  fontSize: 14,
                                                  fontFamily: Constant
                                                      .customRegular),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        : Text(""),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              _searchQuery.text.length > 0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN PARENTS"
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Center(
                                            child: Padding(
                                              padding: const EdgeInsets.fromLTRB(
                                                  0.0, 16.0, 0.0, 16.0),
                                              child: Text(
                                                "No Result Found",
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold),
                                              ),
                                            )),
                                      ],
                                    )
                                  ],
                                ),
                                groupList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              groupList.length > 0
                                                  ? _searchQuery.text.length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN GROUPS"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    groupList.length > 0
                                        ? Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: _buildGroupSearchList())
                                        : Container(
                                      height: 0.0,
                                    ),
                                    groupCount > 3
                                        ? Center(
                                      child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            isGroupFilterSelected =
                                            true;
                                          });

                                          apiCallingForFrindFullList3(
                                              _searchQuery.text, "10");
                                        },
                                        child: Container(
                                          child: Padding(
                                            padding: const EdgeInsets
                                                .fromLTRB(
                                                0.0, 30.0, 0.0, 20.0),
                                            child: Text(
                                              "View More",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR,
                                                  fontSize: 14,
                                                  fontFamily: Constant
                                                      .customRegular),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        : Text(""),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              _searchQuery.text.length > 0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN GROUPS"
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Center(
                                            child: Padding(
                                              padding: const EdgeInsets.fromLTRB(
                                                  0.0, 16.0, 0.0, 16.0),
                                              child: Text(
                                                "No Result Found",
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold),
                                              ),
                                            )),
                                      ],
                                    )
                                  ],
                                ),
                                partnerList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              partnerList.length > 0
                                                  ? _searchQuery.text.length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN PARTNERS"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    partnerList.length > 0
                                        ? Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: _buildPartnerList())
                                        : Container(
                                      height: 0.0,
                                    ),
                                    partnerCount > 3
                                        ? Center(
                                      child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            isPartnerFilterSelected =
                                            true;
                                          });

                                          apiCallingForFrindFullList3(
                                              _searchQuery.text, "4");
                                        },
                                        child: Container(
                                          child: Padding(
                                            padding: const EdgeInsets
                                                .fromLTRB(
                                                0.0, 30.0, 0.0, 20.0),
                                            child: Text(
                                              "View More",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR,
                                                  fontSize: 14,
                                                  fontFamily: Constant
                                                      .customRegular),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        : Text(""),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              _searchQuery.text.length > 0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN PARTNERS"
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Center(
                                            child: Padding(
                                              padding: const EdgeInsets.fromLTRB(
                                                  0.0, 16.0, 0.0, 16.0),
                                              child: Text(
                                                "No Result Found",
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold),
                                              ),
                                            )),
                                      ],
                                    )

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                ),
                                _mOpportunityModelList.length > 0
                                    ? Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              _mOpportunityModelList.length >
                                                  0
                                                  ? _searchQuery.text.length >
                                                  0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN OPPORTUNITIES"
                                                  : ""
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    _mOpportunityModelList.length > 0
                                        ? Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: _buildOpportunityList())
                                        : Container(
                                      height: 0.0,
                                    ),
                                    opportunityCount > 3
                                        ? Center(
                                      child: InkWell(
                                        onTap: () {
                                          Navigator.of(context).push(
                                              MaterialPageRoute(
                                                  builder: (BuildContext
                                                  context) =>
                                                      OpportunitySearch(
                                                          _searchQuery
                                                              .text)));
                                        },
                                        child: Container(
                                          child: Padding(
                                            padding: const EdgeInsets
                                                .fromLTRB(
                                                0.0, 10.0, 0.0, 20.0),
                                            child: Text(
                                              "View More",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR,
                                                  fontSize: 14,
                                                  fontFamily: Constant
                                                      .customRegular),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                        : Text(""),

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                )
                                    : Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                          width: double.infinity,
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 5.0, 0.0, 0.0),
                                          child: TextViewWrap.textViewMultiLine(
                                              _searchQuery.text.length > 0
                                                  ? doubleCodeForSearchHint +
                                                  _searchQuery.text
                                                      .toUpperCase() +
                                                  doubleCodeForSearchHint +
                                                  " IN OPPORTUNITIES"
                                                  : "",
                                              TextAlign.left,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              1),
                                          color:
                                          ColorValues.GREY__COLOR_DIVIDER,
                                          height: 25.0,
                                        )),
                                    Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Center(
                                            child: Padding(
                                              padding: const EdgeInsets.fromLTRB(
                                                  0.0, 16.0, 0.0, 16.0),
                                              child: Text(
                                                "No Result Found",
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold),
                                              ),
                                            )),
                                      ],
                                    )

                                    /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                                  ],
                                ),
                              ],
                            ),
                            color: ColorValues.LIGHT_GRAY_BG,
                          )
                              : isApiCalling
                              ? Column(
                            children: <Widget>[
                              CustomViews.getSepratorLine(),

                              PaddingWrap.paddingAll(
                                  10.0,
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      CircularProgressIndicator(
                                        valueColor:
                                        AlwaysStoppedAnimation(Colors.black54),
                                        strokeWidth: 2.0,
                                      )
                                    ],
                                  ))
                            ],
                          )
                              : Column(children: <Widget>[

                            !isApiCallingLoader
                                ? Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    50.0,
                                    10.0,
                                    0.0,
                                    TextViewWrap.textViewMultiLine(
                                        "Enter a few words to search in spikeview",
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        16.0,
                                        FontWeight.normal,
                                        2))
                              ],
                            )
                                : isApiCallingLoader
                                ? Container()
                                : Center(
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.center,
                                mainAxisAlignment:
                                MainAxisAlignment.center,
                                children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                      Image.asset(
                                        "assets/no_search.png",
                                        width: double.infinity,
                                        height: 151.0,
                                      )),
                                  PaddingWrap.paddingfromLTRB(
                                      40.0,
                                      20.0,
                                      40.0,
                                      5.0,
                                      TextViewWrap.textViewMultiLine(
                                          "Hmm, No results found!",
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          16.0,
                                          FontWeight.bold,
                                          2)),
                                  PaddingWrap.paddingfromLTRB(
                                      40.0,
                                      7.0,
                                      40.0,
                                      40.0,
                                      TextViewWrap.textViewMultiLine(
                                          "We did not find what you were looking for. Try again.",
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          14.0,
                                          FontWeight.normal,
                                          4)),
                                ],
                              ),
                            ),
                          ])
                        ],
                      ),
                      flex: 1,
                    )
                  ],
                ), () {

              FocusScope.of(context).requestFocus(new FocusNode());
              Navigator.pop(context);

            },
                isShowIcon: false,
             )));


    return WillPopScope(
        onWillPop: () {
          FocusScope.of(context).requestFocus(new FocusNode());
          Navigator.pop(context);
        },
        child: Scaffold(
            key: _scaffoldKey,
            resizeToAvoidBottomInset: false,
            backgroundColor: ColorValues.SCREEN_BG_COLOR,
            appBar: AppBar(
                automaticallyImplyLeading: false,
                titleSpacing: 0.0,
                elevation: 0.0,
                brightness: Brightness.light,
                leading: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: InkWell(
                        child: SizedBox(
                          height: 40.0,
                          width: 40.0,
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              5.0,
                              0.0,
                              3.0,
                              Center(
                                  child: Image.asset(
                                      "assets/newDesignIcon/navigation/back.png",
                                      height: 20.0,
                                      width: 10.0,
                                      fit: BoxFit.fitHeight))),
                        ),
                        onTap: () {
                          Navigator.pop(context);
                        },
                      ),
                      flex: 0,
                    ),
                  ],
                ),
                backgroundColor: Colors.white,
                title: searchView),
            body: friendList.length > 0 ||
                groupList.length > 0 ||
                parentList.length > 0 ||
                partnerList.length > 0 ||
                _mOpportunityModelList.length > 0
                ? isStudentFilterSelected ||
                isParentFilterSelected ||
                isPartnerFilterSelected ||
                isGroupFilterSelected
                ? Container(
              child: ListView(
                controller: _controller,
                children: <Widget>[
                  CustomViews.getSepratorLine(),
                  getSearchFilterView(),
                  getButtonOpportunity(),
                  isStudentFilterSelected
                      ? friendList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment:
                    MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                friendList.length > 0
                                    ? _searchQuery.text
                                    .length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery
                                        .text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN STUDENTS"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color: ColorValues
                                .GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      friendList.length > 0
                          ? Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children:
                        _buildFriendSearchList(),
                      )
                          : Container(
                        height: 0.0,
                      ),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Container(
                    height: 0.0,
                  )
                      : Container(
                    height: 0.0,
                  ),
                  isParentFilterSelected
                      ? parentList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment:
                    MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                parentList.length > 0
                                    ? _searchQuery.text
                                    .length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery
                                        .text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN PARENTS"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color: ColorValues
                                .GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      parentList.length > 0
                          ? Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: _buildParentsList())
                          : Container(
                        height: 0.0,
                      ),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Container(
                    height: 0.0,
                  )
                      : Container(
                    height: 0.0,
                  ),
                  isGroupFilterSelected
                      ? groupList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment:
                    MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                groupList.length > 0
                                    ? _searchQuery.text
                                    .length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery
                                        .text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN GROUPS"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color: ColorValues
                                .GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      groupList.length > 0
                          ? Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children:
                          _buildGroupSearchList())
                          : Container(
                        height: 0.0,
                      ),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Container(
                    height: 0.0,
                  )
                      : Container(
                    height: 0.0,
                  ),
                  isPartnerFilterSelected
                      ? partnerList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment:
                    MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                partnerList.length > 0
                                    ? _searchQuery.text
                                    .length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery
                                        .text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN PARTNERS"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color: ColorValues
                                .GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      partnerList.length > 0
                          ? Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: _buildPartnerList())
                          : Container(
                        height: 0.0,
                      ),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Container(
                    height: 0.0,
                  )
                      : Container(
                    height: 0.0,
                  ),
                ],
              ),
              color: ColorValues.LIGHT_GRAY_BG,
            )
                : Container(
              child: ListView(
                controller: _controller,
                children: <Widget>[
                  CustomViews.getSepratorLine(),
                  getSearchFilterView(),
                  getButtonOpportunity(),
                  friendList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                friendList.length > 0
                                    ? _searchQuery.text.length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN STUDENTS"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      friendList.length > 0
                          ? Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children:
                        _buildFriendSearchList(),
                      )
                          : Container(
                        height: 0.0,
                      ),
                      studentCount > 3
                          ? Center(
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              isStudentFilterSelected =
                              true;
                            });

                            apiCallingForFrindFullList3(
                                _searchQuery.text, "1");
                          },
                          child: Container(
                            child: Padding(
                              padding: const EdgeInsets
                                  .fromLTRB(
                                  0.0, 30.0, 0.0, 20.0),
                              child: Text(
                                "View More",
                                style: TextStyle(
                                    color: ColorValues
                                        .BLUE_COLOR,
                                    fontSize: 14,
                                    fontFamily: Constant
                                        .customRegular),
                              ),
                            ),
                          ),
                        ),
                      )
                          : Text(""),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 20.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                _searchQuery.text.length > 0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN STUDENTS"
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: <Widget>[
                          Center(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 16.0, 0.0, 16.0),
                                child: Text(
                                  "No Result Found",
                                  style: TextStyle(
                                      color: ColorValues
                                          .GREY_TEXT_COLOR,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              )),
                        ],
                      )

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  ),
                  parentList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                parentList.length > 0
                                    ? _searchQuery.text.length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN PARENTS"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      parentList.length > 0
                          ? Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: _buildParentsList())
                          : Container(
                        height: 0.0,
                      ),
                      parentCount > 3
                          ? Center(
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              isParentFilterSelected =
                              true;
                            });

                            apiCallingForFrindFullList3(
                                _searchQuery.text, "2");
                          },
                          child: Container(
                            child: Padding(
                              padding: const EdgeInsets
                                  .fromLTRB(
                                  0.0, 30.0, 0.0, 20.0),
                              child: Text(
                                "View More",
                                style: TextStyle(
                                    color: ColorValues
                                        .BLUE_COLOR,
                                    fontSize: 14,
                                    fontFamily: Constant
                                        .customRegular),
                              ),
                            ),
                          ),
                        ),
                      )
                          : Text(""),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                _searchQuery.text.length > 0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN PARENTS"
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: <Widget>[
                          Center(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 16.0, 0.0, 16.0),
                                child: Text(
                                  "No Result Found",
                                  style: TextStyle(
                                      color: ColorValues
                                          .GREY_TEXT_COLOR,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              )),
                        ],
                      )
                    ],
                  ),
                  groupList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                groupList.length > 0
                                    ? _searchQuery.text.length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN GROUPS"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      groupList.length > 0
                          ? Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: _buildGroupSearchList())
                          : Container(
                        height: 0.0,
                      ),
                      groupCount > 3
                          ? Center(
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              isGroupFilterSelected =
                              true;
                            });

                            apiCallingForFrindFullList3(
                                _searchQuery.text, "10");
                          },
                          child: Container(
                            child: Padding(
                              padding: const EdgeInsets
                                  .fromLTRB(
                                  0.0, 30.0, 0.0, 20.0),
                              child: Text(
                                "View More",
                                style: TextStyle(
                                    color: ColorValues
                                        .BLUE_COLOR,
                                    fontSize: 14,
                                    fontFamily: Constant
                                        .customRegular),
                              ),
                            ),
                          ),
                        ),
                      )
                          : Text(""),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                _searchQuery.text.length > 0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN GROUPS"
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: <Widget>[
                          Center(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 16.0, 0.0, 16.0),
                                child: Text(
                                  "No Result Found",
                                  style: TextStyle(
                                      color: ColorValues
                                          .GREY_TEXT_COLOR,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              )),
                        ],
                      )
                    ],
                  ),
                  partnerList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                partnerList.length > 0
                                    ? _searchQuery.text.length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN PARTNERS"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      partnerList.length > 0
                          ? Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: _buildPartnerList())
                          : Container(
                        height: 0.0,
                      ),
                      partnerCount > 3
                          ? Center(
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              isPartnerFilterSelected =
                              true;
                            });

                            apiCallingForFrindFullList3(
                                _searchQuery.text, "4");
                          },
                          child: Container(
                            child: Padding(
                              padding: const EdgeInsets
                                  .fromLTRB(
                                  0.0, 30.0, 0.0, 20.0),
                              child: Text(
                                "View More",
                                style: TextStyle(
                                    color: ColorValues
                                        .BLUE_COLOR,
                                    fontSize: 14,
                                    fontFamily: Constant
                                        .customRegular),
                              ),
                            ),
                          ),
                        ),
                      )
                          : Text(""),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                _searchQuery.text.length > 0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN PARTNERS"
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: <Widget>[
                          Center(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 16.0, 0.0, 16.0),
                                child: Text(
                                  "No Result Found",
                                  style: TextStyle(
                                      color: ColorValues
                                          .GREY_TEXT_COLOR,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              )),
                        ],
                      )

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  ),
                  _mOpportunityModelList.length > 0
                      ? Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                _mOpportunityModelList.length >
                                    0
                                    ? _searchQuery.text.length >
                                    0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN OPPORTUNITIES"
                                    : ""
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      _mOpportunityModelList.length > 0
                          ? Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: _buildOpportunityList())
                          : Container(
                        height: 0.0,
                      ),
                      opportunityCount > 3
                          ? Center(
                        child: InkWell(
                          onTap: () {
                            Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (BuildContext
                                    context) =>
                                        OpportunitySearch(
                                            _searchQuery
                                                .text)));
                          },
                          child: Container(
                            child: Padding(
                              padding: const EdgeInsets
                                  .fromLTRB(
                                  0.0, 10.0, 0.0, 20.0),
                              child: Text(
                                "View More",
                                style: TextStyle(
                                    color: ColorValues
                                        .BLUE_COLOR,
                                    fontSize: 14,
                                    fontFamily: Constant
                                        .customRegular),
                              ),
                            ),
                          ),
                        ),
                      )
                          : Text(""),

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  )
                      : Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.fromLTRB(
                                13.0, 5.0, 0.0, 0.0),
                            child: TextViewWrap.textViewMultiLine(
                                _searchQuery.text.length > 0
                                    ? doubleCodeForSearchHint +
                                    _searchQuery.text
                                        .toUpperCase() +
                                    doubleCodeForSearchHint +
                                    " IN OPPORTUNITIES"
                                    : "",
                                TextAlign.left,
                                ColorValues
                                    .HEADING_COLOR_EDUCATION,
                                12.0,
                                FontWeight.normal,
                                1),
                            color:
                            ColorValues.GREY__COLOR_DIVIDER,
                            height: 25.0,
                          )),
                      Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: <Widget>[
                          Center(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 16.0, 0.0, 16.0),
                                child: Text(
                                  "No Result Found",
                                  style: TextStyle(
                                      color: ColorValues
                                          .GREY_TEXT_COLOR,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              )),
                        ],
                      )

                      /*    Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 20.0, 0.0, 10.0),
                                      child: Divider(
                                        color: Colors.black38,
                                        height: 10.0,
                                      )),*/
                    ],
                  ),
                ],
              ),
              color: ColorValues.LIGHT_GRAY_BG,
            )
                : isApiCalling
                ? Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                getSearchFilterView(),
                getButtonOpportunity(),
                PaddingWrap.paddingAll(
                    10.0,
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        CircularProgressIndicator(
                          valueColor:
                          AlwaysStoppedAnimation(Colors.black54),
                          strokeWidth: 2.0,
                        )
                      ],
                    ))
              ],
            )
                : Column(children: <Widget>[
              CustomViews.getSepratorLine(),
              getSearchFilterView(),
              getButtonOpportunity(),
              !isApiCallingLoader
                  ? Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                      10.0,
                      50.0,
                      10.0,
                      0.0,
                      TextViewWrap.textViewMultiLine(
                          "Enter a few words to search in spikeview",
                          TextAlign.center,
                          ColorValues.GREY_TEXT_COLOR,
                          16.0,
                          FontWeight.normal,
                          2))
                ],
              )
                  : isApiCallingLoader
                  ? Container()
                  : Center(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.center,
                  mainAxisAlignment:
                  MainAxisAlignment.center,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        Image.asset(
                          "assets/no_search.png",
                          width: double.infinity,
                          height: 151.0,
                        )),
                    PaddingWrap.paddingfromLTRB(
                        40.0,
                        20.0,
                        40.0,
                        5.0,
                        TextViewWrap.textViewMultiLine(
                            "Hmm, No results found!",
                            TextAlign.center,
                            ColorValues.GREY_TEXT_COLOR,
                            16.0,
                            FontWeight.bold,
                            2)),
                    PaddingWrap.paddingfromLTRB(
                        40.0,
                        7.0,
                        40.0,
                        40.0,
                        TextViewWrap.textViewMultiLine(
                            "We did not find what you were looking for. Try again.",
                            TextAlign.center,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                  ],
                ),
              ),
            ])));
  }

  void onFilterClick(int index) {
    // deSelectAllFilters();

    switch (index) {
      case 0:
      // isStudentFilterSelected = isStudentFilterSelected ? false : true;
      /*  if (isStudentFilterSelected) {
          isStudentFilterSelected = false;
          apiCallingForFrindList2();
        } else {*/
        offset = 0;
        if (isStudentFilterSelected) {
          isApiCalling = true;
          friendList.clear();
          groupList.clear();
          parentList.clear();
          partnerList.clear();
          _mOpportunityModelList.clear();
          setState(() {});
          isStudentFilterSelected = false;
          isGroupFilterSelected = false;
          isParentFilterSelected = false;
          isPartnerFilterSelected = false;
          apiCallingForFrindList2();
        } else {
          isStudentFilterSelected = true;
          isGroupFilterSelected = false;
          isParentFilterSelected = false;
          isPartnerFilterSelected = false;
          apiCallingForFrindFullList3(_searchQuery.text, "1");
        }


        //}
        break;
      case 1:
      //isParentFilterSelected = isParentFilterSelected ? false : true;
      /* if (isParentFilterSelected) {
          isParentFilterSelected = false;
          apiCallingForFrindList2();
        } else {*/
        offset = 0;
        if (isParentFilterSelected) {
          isApiCalling = true;
          friendList.clear();
          groupList.clear();
          parentList.clear();
          partnerList.clear();
          _mOpportunityModelList.clear();
          setState(() {});
          isParentFilterSelected = false;
          isStudentFilterSelected = false;
          isGroupFilterSelected = false;

          isPartnerFilterSelected = false;
          apiCallingForFrindList2();
        } else {
          isParentFilterSelected = true;
          isStudentFilterSelected = false;
          isGroupFilterSelected = false;

          isPartnerFilterSelected = false;
          apiCallingForFrindFullList3(_searchQuery.text, "2");
        }


        //}
        break;
      case 2:
      // isGroupFilterSelected = isGroupFilterSelected ? false : true;
      /* if (isGroupFilterSelected) {
          isGroupFilterSelected = false;
          apiCallingForFrindList2();
        } else {*/
        offset = 0;
        if (isGroupFilterSelected) {
          isApiCalling = true;
          friendList.clear();
          groupList.clear();
          parentList.clear();
          partnerList.clear();
          _mOpportunityModelList.clear();
          setState(() {});
          isGroupFilterSelected = false;
          isStudentFilterSelected = false;

          isParentFilterSelected = false;
          isPartnerFilterSelected = false;
          apiCallingForFrindList2();
        } else {
          isGroupFilterSelected = true;
          isStudentFilterSelected = false;

          isParentFilterSelected = false;
          isPartnerFilterSelected = false;
          apiCallingForFrindFullList3(_searchQuery.text, "10");
        }



        /// }
        break;
      case 3:
      // isPartnerFilterSelected = isPartnerFilterSelected ? false : true;
      /*   if (isPartnerFilterSelected) {
          isPartnerFilterSelected = false;
          apiCallingForFrindList2();
        } else {*/
        offset = 0;
        if (isPartnerFilterSelected) {
          isApiCalling = true;
          friendList.clear();
          groupList.clear();
          parentList.clear();
          partnerList.clear();
          _mOpportunityModelList.clear();
          setState(() {});
          isPartnerFilterSelected = false;
          isStudentFilterSelected = false;
          isGroupFilterSelected = false;
          isParentFilterSelected = false;
          apiCallingForFrindList2();
        } else {
          isPartnerFilterSelected = true;
          isStudentFilterSelected = false;
          isGroupFilterSelected = false;
          isParentFilterSelected = false;

          apiCallingForFrindFullList3(_searchQuery.text, "4");
        }

        //  }
        break;
    }

    setState(() {});
  }

  Color getBgColor(int index) {
    Color color;
    switch (index) {
      case 0:
        color = isStudentFilterSelected
            ? ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED
            : ColorValues.SEARCH_CATEGORY_BOX_BG;

        break;
      case 1:
        color = isParentFilterSelected
            ? ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED
            : ColorValues.SEARCH_CATEGORY_BOX_BG;

        break;
      case 2:
        color = isGroupFilterSelected
            ? ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED
            : ColorValues.SEARCH_CATEGORY_BOX_BG;

        break;
      case 3:
        color = isPartnerFilterSelected
            ? ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED
            : ColorValues.SEARCH_CATEGORY_BOX_BG;
        break;
    }

    return color;
  }

  Color getSelectedTextColor(int index) {
    Color color;
    switch (index) {
      case 0:
        color = isStudentFilterSelected
            ? ColorValues.WHITE
            : ColorValues.BLUE_COLOR_BOTTOMBAR;

        break;
      case 1:
        color = isParentFilterSelected
            ? ColorValues.WHITE
            : ColorValues.BLUE_COLOR_BOTTOMBAR;

        break;
      case 2:
        color = isGroupFilterSelected
            ? ColorValues.WHITE
            : ColorValues.BLUE_COLOR_BOTTOMBAR;

        break;
      case 3:
        color = isPartnerFilterSelected
            ? ColorValues.WHITE
            : ColorValues.BLUE_COLOR_BOTTOMBAR;
        break;
    }

    return color;
  }
}