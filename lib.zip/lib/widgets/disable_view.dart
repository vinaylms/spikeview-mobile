import 'package:flutter/material.dart';

class DisableView extends StatelessWidget {
  final bool isEnable;
  final Widget child;
  const DisableView({
    @required this.isEnable,
    @required this.child,
});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        child,
        isEnable
        ?const SizedBox.shrink()
        :Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xffF5F6FA).withOpacity(0.74),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(10)),
            ),
          ),
        ),
      ],
    );
  }
}
