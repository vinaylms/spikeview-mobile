import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';

class ProfileImageView extends StatelessWidget {
  final String placeHolderImage;
  final String imagePath;
  final VoidCallback onTap;
  final double height,width,borderRadius;
  final bool showShadow; // New variable to control shadow visibility

  const ProfileImageView({
    @required this.imagePath,
    @required this.placeHolderImage,
    @required this.onTap,
    @required this.height,
  @required this.width,

  this.borderRadius,
    this.showShadow = true, // Default to true if not provided

  });

  @override
  Widget build(BuildContext context) {
    return  InkWell(
      onTap: (){
        if (onTap != null) {
          onTap();
        }
      },
        child:Container(
            height:height?? 48.0,
            width: width??48.0,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(borderRadius??15),
                border: Border.all(
                    color: Colors.white,
                    width: 1),
              boxShadow: showShadow
                  ? [
                BoxShadow(
                  spreadRadius: 3,
                  blurRadius: 3,
                  offset: Offset(0, 2),
                  color: Color.fromRGBO(98, 175, 226, 0.09),
                )
              ]
                  : [],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(borderRadius??15.0),
              child:FadeInImage(
                fit: BoxFit.cover,
                placeholder: AssetImage(
                  placeHolderImage?? 'assets/profile/user_on_user.png',
                ),
                image: NetworkImage(imagePath??''),
              ),
            )));
  }
}
