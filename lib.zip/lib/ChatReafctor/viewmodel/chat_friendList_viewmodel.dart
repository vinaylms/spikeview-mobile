import 'dart:async';

import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/ChatReafctor/services/posts_service.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/chat/modal/ChatRoomModel.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:stacked/stacked.dart';

import '../app/locator.dart';

class ChatFriendListViewModel extends FutureViewModel<List<Friends>>
    with WidgetsBindingObserver {
  final _postsService = locator<PostsService>();
  List<Friends> friendList =  List();
  String userIdPref, roleId;
  SharedPreferences prefs;
  bool isLoading = true;
  StreamSubscription<dynamic> _streamSubscription;
  //static StreamController syncDoneController = StreamController.broadcast();
  BuildContext context;
  ChatFriendListViewModel(this.context);


  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    // GlobalSocketConnection.initSocket();
    try {

      ProfileBloc.chatListController.stream.listen((map) async{
        try {
          print("map Chat Data"+map.toString());
          if (map != null)  {

            friendList.clear();
            FrienndListModel _mFrienndListModel= await FrienndListModel.fromJson(map);
            if (_mFrienndListModel.friendsList.length > 0) {
              friendList.addAll(_mFrienndListModel.friendsList);
              notifyListeners();
            }
          }
        } catch (e) {
          print("stream+++" + e.toString());
          crashlytics_bloc.recordCrashlyticsError(e,"chat_friendlist_model",context);
        }

      });



      _streamSubscription =
          GlobalSocketConnection.updateChatController.stream.listen((data) {
            try {
              for (Friends model in friendList) {
                if ((model.partnerId == data['sender'] &&
                    model.partnerRoleId == data['senderRoleId']) ||
                    (model.partnerId == data['receiver'] &&
                        model.partnerRoleId == data['receiverRoleId'])) {
                  model.lastMessage = data["chat_object"]['lastMessage'];
                  model.textSentBy = data["sender"];

                  if (data["sender"] != model.userId)
                    model.unreadMessages = data["chat_object"]['unreadMsgs'];

                  friendList.remove(model);
                  if (userIdPref == "1"||model.partnerId==1) {
                    friendList.insert(0, model);
                    notifyListeners();
                    break;
                  } else {
                    friendList.insert(1, model);
                    notifyListeners();
                    break;
                  }

                  break;
                }
              }
            }catch(e){
              print("Errorchat+++++++"+e.toString());
              crashlytics_bloc.recordCrashlyticsError(e,"chat_friendlist_model",context);
            }
          });


      _streamSubscription =
          GlobalSocketConnection.startTypingController.stream.listen((data) {
            for (Friends model in friendList) {
              if ((model.partnerId == data['sender'] &&
                  model.partnerRoleId == data['senderRoleId'])) {
                model.isTyping = true;
                notifyListeners();
              }
            }
          });

      _streamSubscription =
          GlobalSocketConnection.stopTypingController.stream.listen((data) {
            for (Friends model in friendList) {
              if ((model.partnerId == data['sender'] &&
                  model.partnerRoleId == data['senderRoleId'])) {
                 Timer(Duration(milliseconds: 100), () {
                  model.isTyping = false;
                  notifyListeners();
                });
              }
            }
          });

      _streamSubscription =
          GlobalSocketConnection.onlineStatusController.stream.listen((data) {
            for (Friends model in friendList) {
              if (model.partnerId == data['userId']) {
                if (data['presence_status'] == "online") {
                  model.online = 1;
                } else if (data['presence_status'] == "offline") {
                  model.online = 0;
                }
              }
            }
            notifyListeners();
          });


      isLoading = false;
      print("friendList length++++" + friendList.length.toString());
      notifyListeners();
    } catch (e) {
      print("Error+++" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e,"chat_friendlist_model",context);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // fetchMessages();

      print("onresume viewModel++++++++++++++");
    }
  }

  @override
  Future initialise() {
    WidgetsBinding.instance.addObserver(this);
    
    


    getSharedPreferences();
    // TODO: implement initialise
    return super.initialise();
  }

  @override
  Future<List<Friends>> futureToRun() {
    return null;
  }

  onTapItem(context, Friends model) async {
    if (model.isActive) {
      ChatRoomModel _mChatRoomModel = await Navigator.of(context).push(
           MaterialPageRoute(
              builder: (BuildContext context) =>
               ChatRoomWidget(model, "", "")));
      //getSharedPreferences();
      //syncDoneController.add(0);

      if (_mChatRoomModel != null) {
        model.lastMessage = _mChatRoomModel.text;
        model.textSentBy = int.parse(_mChatRoomModel.sender);
        model.unreadMessages = 0;
        notifyListeners();
      }
    } else {
      ToastWrap.showToast(MessageConstant.CONNECTION_INACTIVE_ERROR, context);
    }
  }

  Future<Null> onRefresh() async {
    print("refreshpage+++++++++");
    friendList.clear();
    notifyListeners();
    isLoading = true;
    bloc.fetchChatList(userIdPref, context, prefs, true, "0");
    //  friendList = await _postsService.getPosts();
    isLoading = false;
    print("friendlist+++++" + friendList.length.toString());
    notifyListeners();
    return null;
  }
}