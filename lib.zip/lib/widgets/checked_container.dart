import 'package:flutter/material.dart';
import 'package:spike_view_project/widgets/dotted_border/dotted_border.dart';

class CheckContainer extends StatelessWidget {
  const CheckContainer();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: const Color(0x38000000),
      ),
      child: DottedBorder(
        color: const Color(0xA34684EB),
        strokeWidth: 1,
        padding: EdgeInsets.zero, child: Center(),
      ),
    );
  }
}
