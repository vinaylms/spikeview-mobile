class Student {
  int id;
  int connectId;
  int userId;
  String firstName;
  String lastName;
  String profilePicture;
  int partnerId;
  String partnerFirstName;
  String partnerLastName;
  int partnerRoleId;
  String partnerProfilePicture;
  int dateTime;
  int creationTime;
  String lastMessage;
  int online;
  String isActive;
  int unreadMessages;
  int lastTime;
  int lastSeen;
  int textSentBy;

  String badge;
  String badgeImage;
  int gamificationPoints;
  Student (
      this.id,
      this.connectId,
        this.userId,
        this.firstName,
        this.lastName,
        this.profilePicture,
        this.partnerId,
        this.partnerFirstName,
        this.partnerLastName,
        this.partnerRoleId,
        this.partnerProfilePicture,
        this.dateTime,
        this.creationTime,
        this.online,
        this.isActive,
        this.lastMessage,
        this.unreadMessages,
        this.lastTime,
        this.lastSeen,
        this.textSentBy,
        this.badge,
        this.badgeImage,
        this.gamificationPoints

      );

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'id': id,
      'connectId': connectId,
    'userId': userId,
    'firstName': firstName,
    'lastName': lastName,
    'profilePicture': profilePicture,
    'partnerId': partnerId,
    'partnerFirstName': partnerFirstName,
    'partnerLastName': partnerLastName,
    'partnerRoleId': partnerRoleId,
    'partnerProfilePicture': partnerProfilePicture,
    'dateTime': dateTime,
    'creationTime': creationTime,
    'online': online,
      'isActive' :isActive,
    'lastMessage': lastMessage,
    'unreadMessages': unreadMessages,
    'lastTime': lastTime,
    'lastSeen': lastSeen,
    'textSentBy': textSentBy,
    'badge': badge,
    'gamificationPoints': gamificationPoints,
    'badgeImage': badgeImage,

    };
    return map;
  }

  Student.fromMap(Map<String, dynamic> map) {
    id = map['id'];
    connectId = map['connectId'];
    userId = map['userId'];
    firstName = map['firstName'];
    lastName = map['lastName'];
    profilePicture = map['profilePicture'];
    partnerId = map['partnerId'];
    partnerFirstName = map['partnerFirstName'];
    partnerLastName = map['partnerLastName'];
    partnerRoleId = map['partnerRoleId'];
    partnerProfilePicture = map['partnerProfilePicture'];
    dateTime = map['dateTime'];
    creationTime = map['creationTime'];
    online = map['online'];
    isActive = map['isActive'];
    lastMessage = map['lastMessage'];
    unreadMessages = map['unreadMessages'];
    lastTime = map['lastTime'];
    lastSeen = map['lastSeen'];
    textSentBy = map['textSentBy'];
    badge = map['badge'];
    gamificationPoints = map['gamificationPoints'];
    badgeImage = map['badgeImage'];

  }
}
