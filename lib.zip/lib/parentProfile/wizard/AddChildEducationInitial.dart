import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfile.dart';
import 'package:spike_view_project/parentProfile/wizard/ACCompetenciesWidget.dart';
import 'package:spike_view_project/parentProfile/wizard/AllAccomplishmentListWidget.dart';
import 'package:spike_view_project/parentProfile/wizard/AllEducationListWidget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:spike_view_project/common/Util.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/UserProfileDashBoard.dart';
import 'package:spike_view_project/profile/studentWizard/AddEducationWidget.dart';
import 'package:spike_view_project/profile/studentWizard/AddStudentSummary.dart';
import 'package:spike_view_project/parentProfile/wizard/AddEducation_Widget.dart';
import 'package:spike_view_project/profile/studentWizard/StudentAllEducationList.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class AddChildEducationInitial extends StatefulWidget {
  //ProfileInfoModal profileInfoModal;
  StudentDataModel studModel;
  String isActive, page;

  bool isCalledFromEducationList;
  //String pageName;
  //String sasToken;
  //int stage;
  AddChildEducationInitial(this.studModel, this.isActive,
      this.page);

  @override
  AddChildEducationInitialState createState() {
    return  AddChildEducationInitialState();
  }
}

class AddChildEducationInitialState extends State<AddChildEducationInitial> {
  final _formKey = GlobalKey<FormState>();
  String isActive;

  AddChildEducationInitialState();

  String strAchievement,
      strFromDate,
      strToDate,
      strName,
      strEmail,
      strCity,
      strDeascription = "",
      grade1,
      strGrade1 = "",
      grade2,
      strGrade2 = "",
      year1,
      stryear1 = "",
      year2,
      stryear2 = "";
  double searchListHeight = 200.0;
  int searchListLength = 0;
  bool isReadyForApiCall = false;
  SharedPreferences prefs;
  String strAzureUploadPath = "";
 // List<OrganizationModal> organizationLst = List<OrganizationModal>();
  TextEditingController fromDateController, toDateController;
  TextEditingController cityController =  TextEditingController(text: "");
  TextEditingController descController =  TextEditingController(text: "");
  bool showCollege=true;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String userIdPref, token;
  final TextEditingController _searchQuery =  TextEditingController();
  List<String> yearList =  List();
  List<String> toYearList =  List();
  String sasToken, containerName;
  bool _IsSearching;
  File imagePath;
  String _searchText = "",
      strOrganizationId = "",
      strInstiute = "",
      strOrganizationType = "School",
      strPrefixPathOrganization;
  final List<String> _items = [
    'Select Grade',
    '1st',
    '2nd',
    '3rd',
    '4th',
    '5th',
    '6th',
    '7th',
    '8th',
    '9th',
    '10th',
    '11th',
    '12th',
  ].toList();
  String selectedText = "";
  String isPerformChnges = "pop";
  bool isPresent = true;



//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
   // recommendationApi();
    callApiForSaas();
    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_ORGANIZATION +
        "/";
  }

  //=========================================================Api Calling =======================================
  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await  ApiCalling().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + strPrefixPathOrganization
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      CustomProgressLoader.cancelLoader(context);
      return "";
    }
  }




  @override
  void initState() {
    // TODO: implement initState

    getSharedPreferences();

    DateTime date =  DateTime.fromMillisecondsSinceEpoch(
        int.parse(widget.studModel.dob));

    if(widget.studModel.dob.toString() != 'null' && widget.studModel.dob.toString() != '') {
      DateTime date =  DateTime.fromMillisecondsSinceEpoch(int.tryParse(widget.studModel.dob));

      //print('Apurva user age:: ${DateTime.now().year - date.year}');
      if (Util.currentAge(date, 13) < 13) {
        setState(() {
          showCollege = false;
        });
      }
    }

    for (int i = date.year; i <=  DateTime.now().year; i++) {
      yearList.add(i.toString());
    }
    yearList.add("Select Year");
    setState(() {
      yearList = yearList.reversed.toList();
    });

    for (int i = date.year; i <= (new DateTime.now().year + 10); i++) {
      toYearList.add(i.toString());
    }
    toYearList.add("Select Year");
    setState(() {
      toYearList = toYearList.reversed.toList();
    });

    try {
      int gradeToCalculate =  DateTime.now().year - (date.year + 5);
      print("gradeToCalculate++++" + gradeToCalculate.toString());
      int garde = 0;
      if (gradeToCalculate > 0 && gradeToCalculate <= 12) {
        garde = gradeToCalculate;
      } else if (gradeToCalculate > 12) {
        garde = 12;
      }

      if (garde > 0) {
        if (garde == 1) {
          strGrade2 = garde.toString() + "st";
          grade2 = garde.toString() + "st";
        } else if (garde == 2) {
          strGrade2 = garde.toString() + "nd";
          grade2 = garde.toString() + "nd";
        } else if (garde == 3) {
          strGrade2 = garde.toString() + "rd";
          grade2 = garde.toString() + "rd";
        } else {
          strGrade2 = garde.toString() + "th";
          grade2 = garde.toString() + "th";
        }
      }
    } catch (e) {}
    _IsSearching = false;
    _searchQuery.addListener(() {
      if (_searchQuery.text.isEmpty) {
        setState(() {
          _IsSearching = false;
          _searchText = "";
        });
      } else {
        if (selectedText.trim() != _searchQuery.text.trim()) {
          setState(() {
            _IsSearching = true;
            _searchText = _searchQuery.text.trim();
          });
        }
      }
    });

    super.initState();
  }

  Future<Null> _cropImage(File imageFile) async {
    imagePath = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      ratioX: 2.0,
      ratioY: 2.0,
    );
  }

  @override
  Widget build(BuildContext context) {
    //-----------------------------------Image Selectio Ui nd core logic-------------------------------
    Constant.applicationContext = context;
    Container getBottomBar() {
      return  Container(

          child:  Row(
            children: <Widget>[
               InkWell(
                child:  Padding(
                    padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                    child: Image.asset(
                      'assets/newDesignIcon/parentProfile/backword.png',
                      height: 45.0,
                      width: 45.0,
                    )),
                onTap: () {
                  Navigator.pop(context);
                  /*if (widget.isCalledFromEducationList) {
                    Navigator.pop(context,"push");

                  } else {
                    Navigator.of(context).pushReplacement(new MaterialPageRoute(
                        builder: (BuildContext context) =>
                         AddStudentSummary(
                            " EDIT SUMMARY",
                            widget.profileInfoModal.summary,
                            widget.profileInfoModal,
                            widget.sasToken,
                            "education", 2)));
                  }*/
                },
              ),
               Expanded(
                child:  InkWell(
                  child:  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                      child:  Text(
                        "",
                        style: TextStyle(
                            fontSize: 16.0,
                            fontFamily: Constant.customRegular,
                            color: ColorValues.GREY_TEXT_COLOR),
                        textAlign: TextAlign.center,
                      )),
                  onTap: () {
                    //  skipOnClick();
                  },
                ),
                flex: 1,
              ),
              /*new InkWell(
                child:  Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                    child: Image.asset(
                      'assets/newDesignIcon/parentProfile/next.png',
                      height: 45.0,
                      width: 45.0,
                    )),
                onTap: () {
                  onTapAddEducation();
                },
              )*/
               Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                  child: Image.asset(
                    'assets/newDesignIcon/parentProfile/next_gray.png',
                    height: 45.0,
                    width: 45.0,
                  )),
            ],
          ));
    }
    final double statusBarHeight = MediaQuery.of(context).padding.top;
    return  WillPopScope(
        onWillPop: () {
          if (widget.page == "all") {
            Navigator.pop(context);
          }
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            body:  Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                /*Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 80.0, 0, 10),
                  child:  Image.asset("assets/profile/student/st13.png",
                      height: 10.0, width: 100.0, fit: BoxFit.fitHeight),
                ),*/
                /*Padding(
                  padding:  EdgeInsets.only(top:statusBarHeight+20,right: 13.0,left: 13.0),
                  child:  Text(
                    //"Step 3 of 7",
                    "",
                    style:  TextStyle(
                        fontSize: 15.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  ),
                ),*/

                Padding(
                  padding:  EdgeInsets.only(top:statusBarHeight+20,left: 13.0,right: 13.0,bottom: 7),
                  child: Center(
                    child:  Image.asset(
                        "assets/progress_indecator/indicator_step3.png",
                        height: 26.0,
                        width: 300.0,
                        fit: BoxFit.fitWidth
                    ),
                  ),
                ),


                 Expanded(
                  child:  ListView(
                    children: <Widget>[
                       Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                          child:  Image.asset(
                            "assets/profile/student/add_education.png",
                            height: 45.0,
                            width: 35.0,
                          )),
                       Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 20.0),
                          child:  Text(
                            "Add Education",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontFamily: Constant.customRegular,
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                                color:
                                ColorValues.HEADING_COLOR_EDUCATION),
                          )),


                      getAddEducationButton(),
                    ],
                  ),
                  flex: 1,
                ),
                 Expanded(
                  child: getBottomBar(),
                  flex: 0,
                ),
              ],
            )));
  }

  void onBackwordClick() {
    Navigator.pop(context);
  }

  getAddEducationButton() {
    return PaddingWrap.paddingfromLTRB(
        13.0,
        20.0,
        13.0,
        20.0,
         Container(
            decoration:  BoxDecoration(
                color: ColorValues.WHITE,
                border:  Border.all(
                    color:  ColorValues.BORDER_COLOR, width: 1.0)),
            child: InkWell(
              onTap: () {
                onTapAddEducation();
              },
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 13.0, top: 13.0, bottom: 13.0, right: 13.0),
                //padding: const EdgeInsets.only(left:0.0,top: 13.0,bottom: 13.0,right: 0.0),
                child:  Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          15.0,
                          0.0,
                           Image.asset(
                            "assets/story_new/cap_edu.png",
                            height: 41.0,
                            width: 50.0,
                          )),
                      flex: 0,
                    ),
                    Expanded(
                      flex: 1,
                      child:  Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              5.0,
                              TextViewWrap.textView(
                                  showCollege ? "Add School or College" : "Add School",
                                  TextAlign.start,
                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  16.0,
                                  FontWeight.normal)),
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              TextViewWrap.textViewMultiLine(
                                  showCollege ? "Share your school and college details." : "Share your school details.",
                                  TextAlign.start,
                                   ColorValues.GREY__COLOR,
                                  14.0,
                                  FontWeight.normal,
                                  3)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )));
  }

  void onTapAddEducation() {
    /*Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>  AddEducationWidget(
            widget.profileInfoModal, false, "education", sasToken, 2)));*/
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
         AddEducation_Widget(widget.studModel, widget.isActive,'')));
  }
}
