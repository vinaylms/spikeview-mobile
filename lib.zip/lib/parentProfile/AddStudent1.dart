import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geocoder/geocoder.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/CustomFormFieldWithPrefix.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart' as studentModel;
import 'package:spike_view_project/parentProfile/ParentProfile.dart';
import 'package:spike_view_project/parentProfile/wizard/CongratulationMobileParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

// Create a Form Widget
class AddStudent extends StatefulWidget {
  String title;
  ProfileInfoModal profileInfoModal;
  String page;

  AddStudent(this.title, this.profileInfoModal, this.page);

  @override
  AddStudentState createState() {
    return AddStudentState();
  }
}

final homeScaffoldKey = GlobalKey<ScaffoldState>();

class AddStudentState extends State<AddStudent> {
  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: Constant.kGoogleApiKey);
  SharedPreferences prefs;
  String userIdPref, token;
  final _formKey = GlobalKey<FormState>();
  TextEditingController fromDateController;
  String selectedCountryCode = '';
  String strFirstName = "",
      strLastName = "",
      strEmail = "",
      strAdd = "",
      strMobile;
  File imagePath;
  String profileImagePath = "";
  String isParentGender, emailId;
  String strParentZip = "";
  TextEditingController parentZipController = TextEditingController(text: "");
  FocusNode zipcodeFocusNode = FocusNode();
  DateTime startDate;
  bool isGenderSelected = true;
  FocusNode mobileFocusNode = FocusNode();
  final add1Controller = TextEditingController();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    emailId = prefs.getString(UserPreference.EMAIL);
    token = prefs.getString(UserPreference.USER_TOKEN);
    if (widget.profileInfoModal.dob != null &&
        widget.profileInfoModal.dob != "null") {
      startDate = DateTime.fromMillisecondsSinceEpoch(
          int.parse(widget.profileInfoModal.dob));
    }
  }

  String strCountryName = "";
  bool isStudentCountrySelected = true;
  CountryList _mCountryItem;
  CountryListModel _mCountryListModel;
  List<CountryList> countryList = List();
  final searchCountryController = TextEditingController();
  List<Item> countries = List();
  Item selectedCityItem;
  bool isShowStudentCitySelectionError = true;
  bool showList = false;

  List<String> genderList = [
    "NA",
    "Non-Binary",
    "Female",
    "Male",
  ].toList();

  DateTime pickedDate;
  int strDateOfBirth = 0;
  int diffrenceInDob = 14;
  TextEditingController dobController;
  bool isValid = true;
  String isMostCloselyIdentified = "Male";
  String dob, strDate;

  onTapNavigate(userIdNew, profilePicture) async {
    ParentProfilePageState.isEducationAdded = "false";
    ParentProfilePageState.isAchivmentAdded = "false";
    prefs.setString(UserPreference.PARENT_WIZARD_USERID, userIdNew);
    await Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) => CongratulationMobileParent(
            studentModel.StudentDataModel(
                userIdNew,
                strFirstName,
                strLastName,
                strEmail.toLowerCase(),
                "",
                profilePicture,
                "1",
                "false",
                "",
                "",
                "",
                "",
                "",
                "",
                strDateOfBirth.toString(),
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                null,
                null,
                "false",
                "false",
                "false",
                null,
                "false",
                "0",
                true,
                false,
                '',
                0,
                ''))));
    //Navigator.pop(context, "push");
  }

  //--------------------------Api Calling ------------------

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;
        studentModel.Address address2;
        if (selectedCityItem == null) {
          try {
            Response response1 = await Util.getDetailUsingZipCodeNew(
                false, context, parentZipController.text);

            //apurva added for zip code validation start
            if (response1 == null) {
              print('apurva address2.country:: response:: $response1');
              CustomProgressLoader.cancelLoader(context);
              ToastWrap.showToast2Sec(
                  MessageConstant.ENTER_VALID_ZIP_CODE_VAL, context);
              return;
            } else {
              print('apurva address2.country:: response:: elseee $response1');
            }


            final data = response1.data['results'][0]["address_components"];

            String city = "", state = "", country = "";
            if (data.length > 3) {
              city = data[data.length - 3]['long_name'];
              state = data[data.length - 2]['long_name'];
              country = data[data.length - 1]['long_name'];
            } else if (data.length > 0) {
              //city=json[1]['long_name'];
              state = data[data.length - 2]['long_name'];
              country = data[data.length - 1]['long_name'];
            }
            if (country.toString().trim() !=
                _mCountryItem.name.toString().trim()) {
             CustomProgressLoader.cancelLoader(context);
              ToastWrap.showToast2Sec(
                  MessageConstant.ENTER_VALID_COUNTRY_ZIP_CODE_VAL, context);
              return;
            }
            address2 =  studentModel.Address("", "", city, state, country, "", "");
          } catch (e) {
            crashlytics_bloc.recordCrashlyticsError(e, "AddStudent", context);
          }
        }

        Map map = {
          "userId": int.parse(userIdPref),
          "firstName": widget.profileInfoModal.firstName,
          "lastName": widget.profileInfoModal.lastName,
          "students": [
            {
              "firstName": strFirstName,
              "lastName": strLastName,
              "email": strEmail.toLowerCase(),
              "dob": strDateOfBirth,
              "zipCode": parentZipController.text,
              "gender":
                  isParentGender == "Non-Binary" ? "NonBinary" : isParentGender,
              "state": selectedCityItem != null
                  ? selectedCityItem.state
                  : address2 != null
                      ? address2.state.trim()
                      : "",
              "city": selectedCityItem != null
                  ? selectedCityItem.city
                  : address2 != null
                      ? address2.city.trim()
                      : "",
              "country": _mCountryItem == null ? "" : _mCountryItem.name,

            }
          ],
          "roleId": 2,
          "isActive": true,
          "address": {
            "street1": "",
            "street2": "",
            "city": "",
            "state": "",
            "country": "",
            "zip": ""
          }
        };
        log(" request :-" + map.toString());
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_PARENT_PERSONAL_INFO, map);
        CustomProgressLoader.cancelLoader(context);
        print("response shubh:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              String userIdNew =
                  response.data["result"]['studentId'].toString();
              String profilePicture =
                  response.data["result"]['profilePicture'].toString();
              onTapNavigate(userIdNew, profilePicture);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddStudent", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future getCountry() async {
    print('inside getPreLoginData() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCallWithouAuth(context, Constant.ENDPOINT_GET_COUNTRY, "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mCountryListModel = CountryListModel.fromJson(response.data);
              setState(() {
                countryList.addAll(_mCountryListModel.countryList);
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddStudent", context);
      e.toString();
    }
  }

  initCountryList(text, sortname) async {
    countries.clear();
    countries = await API.fetchCountryListForSignup(text, 'cities', sortname);
    if (countries.length > 0) {
      setState(() {});
    }
  }

  Widget imageSelectionView() {
    return Container(
      width: 118.0,
      height: 118.0,
      child: InkWell(
          child: Stack(
            children: <Widget>[
              Positioned(
                  bottom: 5.0,
                  left: 0.0,
                  top: 0.0,
                  right: 0.0,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(35), // Image border
                    child: SizedBox.fromSize(
                        size: Size.fromRadius(44), // Image radius
                        child: FadeInImage.assetNetwork(
                          fit: BoxFit.cover,
                          placeholder: 'assets/png/user.png',
                          image: Constant.IMAGE_PATH_SMALL +
                              ParseJson.getMediumImage(profileImagePath),
                        ))

                    /*
                        Image.asset('assets/png/user.png',
                            fit: BoxFit.fill))*/
                    ,
                  )),
              Positioned(
                  bottom: 12.0,
                  right: 12.0,
                  child: profileImagePath != null &&
                          profileImagePath != 'null' &&
                          profileImagePath != ''
                      ? InkWell(
                          child: Container(
                            //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                            child: Image.asset("assets/png/edit.png"),
                            height: 24.0,
                            width: 24,
                          ),
                        )
                      : SizedBox())
            ],
          ),
          onTap: () async {
            var status = await Permission.photos.status;
            if (status.isGranted) {
              getImage(ImageSource.gallery);
            } else {
              checkPermissionPhoto(context);
            }
          }),
    );
  }

  Future getImage(type) async {
    imagePath = await UploadMedia(context).pickImageFromGallery();
    // imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
    if (imagePath != null) {
      String strPath = imagePath.toString().substring(
          imagePath.toString().lastIndexOf("/") + 1,
          imagePath.toString().length);

      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        print("img   :-" +
            imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim());
        if (imagePath != null) {
          //   await _cropImage(imagePath);
          setState(() {
            imagePath = imagePath;
          });
          //checkAllFieldSubmitter();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  Widget isImageSelectedView() {
    return Container(
        width: 113.0,
        height: 118.0,
        child: InkWell(
          child: Stack(children: <Widget>[
            Positioned(
                bottom: 5.0,
                left: 0.0,
                top: 0.0,
                right: 0.0,
                child: LimitedBox(
                  maxWidth: 113,
                  maxHeight: 113,
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(35), // Image border
                      child: SizedBox.fromSize(
                          size: Size.fromRadius(30), // Image radius
                          child: Image.file(
                            imagePath,
                            fit: BoxFit.cover,
                          ))),
                )),
            Positioned(
                bottom: 12.0,
                right: 12.0,
                child: InkWell(
                  child: Container(
                    //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                    child: Image.asset("assets/png/edit.png"),
                    height: 24.0,
                    width: 24,
                  ),
                ))
          ]),
          onTap: () async {
            var status = await Permission.photos.status;
            if (status.isGranted) {
              getImage(ImageSource.gallery);
            } else {
              checkPermissionPhoto(context);
            }
          },
        ));
  }

  @override
  void initState() {
    dobController = TextEditingController(text: '');
    // genderList.add("Gender");

    searchCountryController.addListener(() {
      if (searchCountryController.text.isEmpty) {
        setState(() {
          countries.clear();
        });
      } else {
        if (searchCountryController.text.trim().length >= 1) {
          initCountryList(
              searchCountryController.text.trim(), _mCountryItem.sortname);
        }
      }
    });

    setState(() {
      genderList = genderList.reversed.toList();
    });
    getSharedPreferences();
    getCountry();
    super.initState();
  }

  void _checkValidation() async {
    final form = _formKey.currentState;
    form.save();
    if (strDateOfBirth == 0) {
      setState(() {
        isValid = false;
      });
    } else {
      setState(() {
        isValid = true;
      });
    }
    if (isParentGender == "") {
      setState(() {
        isGenderSelected = false;
      });
    } else {
      setState(() {
        isGenderSelected = true;
      });
    }

    if (_mCountryItem == null) {
      setState(() {
        isStudentCountrySelected = false;
      });
    } else {
      setState(() {
        isStudentCountrySelected = true;
      });
    }

    if (_mCountryItem != null &&
        (!_mCountryItem.isZipcode) &&
        selectedCityItem == null) {
      isShowStudentCitySelectionError = false;
    } else {
      isShowStudentCitySelectionError = true;
    }

    if (form.validate()) {
      if (strDateOfBirth == 0) {
        setState(() {
          isValid = false;
        });
      }
      if (isParentGender == null || isParentGender == "") {
        /* setState(() {
            isGenderSelected = false;
          });*/
        ToastWrap.showToast(MessageConstant.SELECT_GENDER_VAL, context);
      } else if (!isStudentCountrySelected) {
        setState(() {
          isGenderSelected = false;
        });
      } else if (!isShowStudentCitySelectionError) {
      } else {
        try {
          setState(() {
            isValid = true;
          });

          if (emailId.toLowerCase().trim() != strEmail.toLowerCase().trim())
            apiCalling();
          else
            ToastWrap.showToast(MessageConstant.EMAIL_VALIDATION, context);
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "AddStudent", context);
          CustomProgressLoader.cancelLoader(context);
        }
      }
    } else {
      print("Failure 00");
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(new FocusNode());
      },
      child: Scaffold(
        backgroundColor: ColorValues.SCREEN_BG_COLOR,
        key: homeScaffoldKey,
        bottomNavigationBar: Container(
          height: 90,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          decoration: BoxDecoration(
            color: AppConstants.colorStyle.white,
            boxShadow: [
              BoxShadow(
                color: const Color(0x75CCDCF7),
                blurRadius: 13,
                spreadRadius: 13,
              )
            ],
          ),
          child: Row(
            children: [
              Expanded(
                flex: 2,
                child: InkWell(
                  child: Container(
                    height: 45,
                    padding: EdgeInsets.symmetric(vertical: 11),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: ColorValues.WHITE,
                      border: Border.all(color: Color(0xffB2BDDB)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "Back",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: AppConstants.colorStyle.lightPurple,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  onTap: () async {
                    Navigator.pop(context, "push");
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 3,
                child: Stack(
                  children: [
                    InkWell(
                      child: Container(
                        height: 45,
                        padding: EdgeInsets.symmetric(vertical: 11),
                        decoration: BoxDecoration(
                          color: AppConstants.colorStyle.lightBlue,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'Proceed',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: ColorValues.WHITE,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontSize: 18,
                          ),
                        ),
                      ),
                      onTap: () {
                        _checkValidation();
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        body: FormKeyboardActions(
          nextFocus: false,
          keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
          keyboardBarColor: Colors.grey[200],
          actions: [
            KeyboardAction(
              focusNode: zipcodeFocusNode,
            ),
          ],
          child: Theme(
            data: ThemeData(hintColor: Colors.grey[300]),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 50, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      BaseText(
                        text: widget.title,
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        maxLines: 1,
                      ),
                      const HelpButtonWidget(),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    flex: 1,
                    child: Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            BaseText(
                              text: "Provide profile details",
                              textColor: const Color(0xff666B9A),
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                            const SizedBox(height: 24),
                            Align(
                              alignment: Alignment.center,
                              child: imagePath == null
                                  ? imageSelectionView()
                                  : isImageSelectedView(),
                            ),
                            const SizedBox(height: 24),
                            CustomFormField(
                              alignLabelWithHint: true,
                              autovalidateMode: AutovalidateMode.disabled,
                              textInputType: TextInputType.text,
                              maxLength:
                                  TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
                              onType: (val) {},
                              onSaved: (val) => strFirstName = val,
                              label: 'Child\'s First Name',
                              validation: (val) => val.trim().length == 0
                                  ? MessageConstant.ENTER_FIRST_NAME_VAL
                                  : !ValidationWidget.isName(val)
                                      ? MessageConstant
                                          .FIRST_NAME_CONTAINS_ALPHABET_VAL
                                      : null,
                            ),
                            const SizedBox(height: 24),
                            CustomFormField(
                              alignLabelWithHint: true,
                              autovalidateMode: AutovalidateMode.disabled,
                              textInputType: TextInputType.text,
                              maxLength:
                                  TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
                              onType: (val) {},
                              label: 'Child\'s  Last Name',
                              validation: (val) => val.trim().length == 0
                                  ? MessageConstant.ENTER_LAST_NAME_VAL
                                  : !ValidationWidget.isName(val)
                                      ? MessageConstant
                                          .LAST_NAME_CONTAINS_ALPHABET_VAL
                                      : null,
                              onSaved: (val) => strLastName = val,
                            ),
                            const SizedBox(height: 24),
                            CustomFormField(
                                alignLabelWithHint: true,
                                onSaved: (val) => strDate = val,
                                readOnly: true,
                                controller: dobController,
                                label: "Child\'s date of birth",
                                onClick: () async {
                                  DateTime pickedDate1 = await showDatePicker(
                                    context: context,
                                    initialDate: pickedDate == null
                                        ? DateTime.now()
                                        : pickedDate,
                                    firstDate: DateTime(1900),
                                    lastDate: DateTime.now(),
                                    confirmText: 'Apply',
                                    cancelText: 'Cancel',
                                  );
                                  if (pickedDate1 != null) {
                                    pickedDate = pickedDate1;
                                    strDateOfBirth =
                                        pickedDate1.millisecondsSinceEpoch;
                                    String date = Util.getDate(pickedDate1);
                                    setState(() {
                                      dobController =
                                          TextEditingController(text: date);
                                    });
                                  }
                                  // selectDob(context);
                                },
                                validation: (value) {
                                  return value.length == 0
                                      ? MessageConstant.SELECT_DATE_TAKEN_VAL
                                      : null;
                                }),
                            const SizedBox(height: 24),
                            CustomFormField(
                                onSaved: (val) => strAdd = val,
                                readOnly: true,
                                alignLabelWithHint: true,
                                autovalidateMode: AutovalidateMode.disabled,
                                textInputType: TextInputType.text,
                                label: "Child\'s Address",
                                controller: add1Controller,
                                onType: (v) {},
                                onClick: () {
                                  _handlePressButton();
                                },
                                validation: (value) {
                                  return value.length == 0
                                      ? 'Please enter valid address'
                                      : null;
                                }),
                           /* CustomFormField(
                                alignLabelWithHint: true,
                                autovalidateMode: AutovalidateMode.disabled,
                                textInputType: TextInputType.text,
                                onSaved: (val) => strAdd = val,
                                label: "Child\'s Address",
                                controller: add1Controller,
                                onType: (val) {},
                                validation: (value) {
                                  return value.length == 0
                                      ? 'Please enter valid address'
                                      : null;
                                }),*/
                            const SizedBox(height: 24),
                            CustomFormFieldWithPrefix(
                                // maxLength: 35,
                                prefixWidget: Padding(
                                  padding: const EdgeInsets.only(right: 5.0),
                                  child: Container(
                                    width: 57,
                                    child: CountryCodePicker(
                                      dense: false,
                                      showFlag: true,
                                      isNew: true,
                                      //displays flag, true by default
                                      showDialingCode: false,
                                      showUnderLine: false,
                                      //displays dialing code, false by default
                                      showName: false,
                                      //displays country name, true by default
                                      onChanged: (CountryCode country) {
                                        setState(() {
                                          selectedCountryCode =
                                              country.dialingCode;
                                        });
                                      },
                                      selectedCountryCode: selectedCountryCode,
                                    ),
                                  ),
                                ),
                                focusNode: mobileFocusNode,
                                baseAlign: true,
                                onSaved: (val) => strMobile = val,
                                textInputType: TextInputType.number,
                                maxLength: TextLength.MOBILE_NUMBER_MAX_LENGTH,
                                label: "Phone number",
                                suffixWidget: Padding(
                                  padding: const EdgeInsets.only(top: 20.0),
                                  child: BaseText(
                                    textAlign: TextAlign.center,
                                    text: 'Optional  ',
                                    textColor: AppConstants.colorStyle.darkBlue,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                    fontStyle: FontStyle.italic,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                  ),
                                ),
                                validation: (value) {
                                  return value.length > 0
                                      ? ValidationChecks.validatePhone(value)
                                      : null;
                                }),
                            /*      countryUi,
                                            isStudentCountrySelected
                                                ?  Container(
                                              height: 0.0,
                                            )
                                                : PaddingWrap
                                                .paddingfromLTRB(
                                                20.0,
                                                5.0,
                                                20.0,
                                                0.0,
                                                Text(
                                                  "Please select country",
                                                  style:  TextStyle(
                                                      color: Colors
                                                          .red[
                                                      600],
                                                      fontSize:
                                                      12.0),
                                                )),
                                            _mCountryItem == null
                                                ? parentZipUi
                                                : _mCountryItem
                                                .isZipcode
                                                ? parentZipUi
                                                : PaddingWrap
                                                .paddingfromLTRB(
                                              20.0,
                                              5.0,
                                              20.0,
                                              0.0,
                                              Container(
                                                  decoration:
                                                  BoxDecoration(
                                                      border:
                                                      Border(bottom: BorderSide(color: isShowStudentCitySelectionError ? Palette.dividerColor : Colors.red[600]))),
                                                  child: Column(
                                                    mainAxisSize:
                                                    MainAxisSize
                                                        .min,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: <
                                                        Widget>[
                                                      Row(
                                                        mainAxisSize:
                                                        MainAxisSize.max,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment.spaceBetween,
                                                        children: <
                                                            Widget>[
                                                          Expanded(
                                                            flex: 1,
                                                            child: selectCountryCityTextField(),
                                                          ),
                                                          searchCountryController.text.length>0?     IconButton(
                                                            onPressed: () {
                                                              showList =
                                                              !showList;
                                                              setState(() {});
                                                            },
                                                            icon: Padding(
                                                              padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left:
                                                                  15.0),
                                                              child: Icon(showList
                                                                  ? Icons
                                                                  .arrow_drop_up
                                                                  : Icons
                                                                  .arrow_drop_down),
                                                            ),
                                                          ):new Container(height:0.0),
                                                        ],
                                                      ),
                                                    ],
                                                  )),
                                            ),
                                            isShowStudentCitySelectionError
                                                ?  Container(
                                              height: 0.0,
                                            )
                                                : PaddingWrap
                                                .paddingfromLTRB(
                                                20.0,
                                                5.0,
                                                20.0,
                                                0.0,
                                                Text(
                                                  "Please select city",
                                                  style:  TextStyle(
                                                      color: Colors
                                                          .red[
                                                      600],
                                                      fontSize:
                                                      12.0),
                                                )),
                                            countryOrCityListWidget(),*/
                            const SizedBox(height: 24),
                            _genderView(),
                            const SizedBox(height: 24),
                            /*
                                            PaddingWrap.paddingfromLTRB(
                                                20.0,
                                                40.0,
                                                20.0,
                                                20.0,
                                                InkWell(
                                                  child: Container(
                                                    width: MediaQuery.of(context).size.width,
                                                    padding: const EdgeInsets.fromLTRB(34, 8, 34, 8),
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(10),
                                                      color: ColorValues.HEADING_COLOR_EDUCATION_2,
                                                    ),
                                                    child: BaseText(
                                                      text: 'Save',
                                                      textColor: ColorValues.WHITE,
                                                      fontFamily: AppConstants.stringConstant.latoMedium,
                                                      fontWeight: FontWeight.w600,
                                                      textAlign: TextAlign.center,
                                                      fontSize: 18,
                                                    ),
                                                  ),
                                                  onTap: (){
                                                    _checkValidation();
                                                  },
                                                )),*/
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _handlePressButton() async {
    Prediction p = await PlacesAutocomplete.show(
      context: context,
      apiKey: Constant.kGoogleApiKey,
      onError: onError,
      hint: "Search here..",
      logo: Image.asset("assets/logo"),
      mode: Mode.fullscreen,
      components: [
        Component(Component.country, "ind"),
        Component(Component.country, "uk"),
        Component(Component.country, "usa"),
      ],
    );

    displayPrediction(p);
  }

  void onError(PlacesAutocompleteResponse response) {
    homeScaffoldKey.currentState.showSnackBar(
      SnackBar(content: Text(response.errorMessage)),
    );
  }

  Future<Null> displayPrediction(Prediction p) async {
    if (p != null) {
      PlacesDetailsResponse detail =
      await _places.getDetailsByPlaceId(p.placeId);
      final lat = detail.result.geometry.location.lat;
      final lng = detail.result.geometry.location.lng;
      //List<String> s = p.description.split(",");
      try {
        final coordinates = Coordinates(lat, lng);
        var addresses =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
        var first = addresses.first;
        setState(() {
          add1Controller.text =
          first.addressLine != null && p.description != "null"
              ? p.description
              : "";
        });
      } catch (e) {
        setState(() {
          add1Controller.text = p.description;
        });
      }
    }
  }

  Widget _genderView() {
    return Row(
      children: <Widget>[
        Flexible(
          child: InkWell(
            onTap: () {
              isMostCloselyIdentified = "Male";
              FocusScope.of(context).requestFocus(new FocusNode());
              setState(() {});
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Male"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Male"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10.0),
                    bottomLeft: Radius.circular(10.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'Male',
                  textColor: isMostCloselyIdentified == "Male"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "Female";
              setState(() {});
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Female"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Female"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(0.0),
                    bottomLeft: Radius.circular(0.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'Female',
                  textColor: isMostCloselyIdentified == "Female"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "Non-Binary";
              setState(() {});
            },
            child: Container(
              height: 35,
              width: 96,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Non-Binary"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Non-Binary"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(0.0),
                    bottomLeft: Radius.circular(0.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: ' Non-binary ',
                  textColor: isMostCloselyIdentified == "Non-Binary"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "NA";
              setState(() {});
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "NA"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "NA"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10.0),
                  topRight: Radius.circular(10.0),
                ),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'NA',
                  textColor: isMostCloselyIdentified == "NA"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 1,
        ),
      ],
    );
  }
}

Future<void> checkPermissionPhoto(BuildContext context) async {
  showDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
            title: Text('Please allow access'),
            content: RichText(
              maxLines: 2,
              textAlign: TextAlign.center,
              text: TextSpan(
                text: '',
                style: TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                children: <TextSpan>[
                  TextSpan(
                      text: 'This app needs access to photos and camera roll',
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          fontSize: 15.0,
                          fontWeight: FontWeight.normal)),
                ],
              ),
            ),
            actions: <Widget>[
              CupertinoDialogAction(
                child: Text('Deny'),
                onPressed: () => Navigator.of(context).pop(),
              ),
              CupertinoDialogAction(
                  child: Text('Settings'),
                  onPressed: () {
                    Navigator.of(context).pop();
                    openAppSettings();
                  }),
            ],
          ));
}
