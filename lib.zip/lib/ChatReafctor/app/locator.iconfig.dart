// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

import 'package:get_it/get_it.dart';
import 'package:spike_view_project/ChatReafctor/services/chat_service.dart';
import 'package:spike_view_project/ChatReafctor/services/opportunity_data_service.dart';
import 'package:spike_view_project/ChatReafctor/services/posts_service.dart';
import 'package:spike_view_project/ChatReafctor/services/shared_data_service.dart';
import 'package:spike_view_project/ChatReafctor/services/third_party_services_module.dart';
import 'package:stacked_services/stacked_services.dart';


void $initGetIt(GetIt g, {String environment}) {
  final thirdPartyServicesModule = _$ThirdPartyServicesModule();
  g.registerLazySingleton<DialogService>(
      () => thirdPartyServicesModule.dialogService);
  g.registerLazySingleton<NavigationService>(
      () => thirdPartyServicesModule.navigationService);
  g.registerLazySingleton<PostsService>(() => PostsService());
  g.registerLazySingleton<ChatService>(() => ChatService());
  g.registerLazySingleton<SharedService>(() => SharedService());
  g.registerLazySingleton<OpportunityService>(() => OpportunityService());

}

class _$ThirdPartyServicesModule extends ThirdPartyServicesModule {
  @override
  DialogService get dialogService => DialogService();
  @override
  NavigationService get navigationService => NavigationService();
}
