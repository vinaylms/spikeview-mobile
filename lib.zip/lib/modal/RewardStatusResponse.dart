class RewardStatusResponse {
  String status;
  String message;
  int result;
  RewardStatus rewardStatus;

  RewardStatusResponse(
      {this.status, this.message, this.result, this.rewardStatus});

  RewardStatusResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    result = json['result'];
    rewardStatus = json['rewardStatus'] != null
        ?  RewardStatus.fromJson(json['rewardStatus'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    data['result'] = this.result;
    if (this.rewardStatus != null) {
      data['rewardStatus'] = this.rewardStatus.toJson();
    }
    return data;
  }
}

class RewardStatus {
  int gamificationPoints;
  String badge;
  bool display;
  String type;
  String msg;
  String badgeImage;

  RewardStatus(
      {this.gamificationPoints, this.badge, this.display, this.type, this.msg,this.badgeImage});

  RewardStatus.fromJson(Map<String, dynamic> json) {

    gamificationPoints = json['gamificationPoints'];
    badge = json['badge'];
    display = json['display'];
    type = json['type'];
    msg = json['msg'];
    badgeImage = json['badgeImage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['gamificationPoints'] = this.gamificationPoints;
    data['badge'] = this.badge;
    data['display'] = this.display;
    data['type'] = this.type;
    data['msg'] = this.msg;
    data['badgeImage'] = this.badgeImage;
    return data;
  }
}
