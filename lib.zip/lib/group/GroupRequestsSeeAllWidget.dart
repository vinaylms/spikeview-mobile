import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';

class GroupRequestsSeeAllWidget extends StatefulWidget {

  String groupId;
  GroupDetailModel modell;
  GroupRequestsSeeAllWidget(
      this.groupId,this.modell);


  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    // ignore: return_of_invalid_type
    return  MainView(
    );
  }
}

class MainView extends State<GroupRequestsSeeAllWidget> {


  BuildContext context;
  SharedPreferences prefs;
  String userIdPref,roleId, userProfilePath;
  String isPerformChanges="pop";


  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }


  Future apiCallingReject(memberId, index) async {
    try {
      print("memberId" + memberId);
      print("groupid" + widget.groupId);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(memberId),
          "status": "Rejected", "isAdmin": true,
          "roleId": int.parse(roleId)
        };

        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADMIN_UPDATED_GROUP_REQUEST, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg);
              widget.modell.requestedList.removeAt(index);
              isPerformChanges="push";
              setState(() {
                widget.modell.requestedList;
              });
              //apiCallForGet();
            } else {
              ToastWrap.showToast(msg,context);
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR,context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCalling(memberId, index) async {
    try {
      print("memberId" + memberId);
      print("groupid" + widget.groupId);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(memberId),
          "status": "Accepted", "isAdmin": true,
          "roleId": int.parse(roleId)
        };

        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADMIN_UPDATED_GROUP_REQUEST, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              isPerformChanges="push";
              widget.modell.requestedList.removeAt(index);
              setState(() {
                widget.modell.requestedList;
              });
            } else {
              ToastWrap.showToast(msg,context);
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR,context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }
  // -------------------  API ------------------------------

  @override
  Widget build(BuildContext context) {
    this.context = context;
    onTapImageTile(tapedUserId,roleId) {
      if (tapedUserId == userIdPref) {

      }   else {
        Util.onTapImageTile(
            tapedUserRole:roleId
            , partnerUserId: tapedUserId,
            context: context
        );
      }
    }
    Container getListview(MemberModelDetail memberModelDetail, index, bool isSentRequest) {
      return  Container(
          color: Colors.transparent,
          padding:  EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 0.0),
          child:  Card(
              color: Colors.transparent,
              elevation: 0.0,
              child:  Column(
                children: <Widget>[
                   Row(
                    children: <Widget>[
                       Expanded(
                        child:  InkWell(
                          child:  Container(
                            height: 50.0,
                            width: 50.0,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(100),
                              child: FadeInImage(
                                fit: BoxFit.cover,
                                placeholder: AssetImage(
                                  'assets/profile/user_on_user.png',
                                ),
                                image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                                    ParseJson.getSmallImage(
                                        memberModelDetail.profilePicture)),
                              ),
                            ),
                          ),
                          onTap: () {
                            onTapImageTile(memberModelDetail.userId,memberModelDetail.roleId);
                          },
                        ),
                        flex: 0,
                      ),
                       Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            10.0,
                            0.0,
                            0.0,
                             Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                 Row(
                                  children: <Widget>[
                                     Expanded(
                                      child: TextViewWrap.textView(
                                          memberModelDetail.lastName == null ||
                                              memberModelDetail.lastName ==
                                                  "null" ||
                                              memberModelDetail.lastName ==
                                                  ""
                                              ? memberModelDetail.firstName
                                              : memberModelDetail.firstName +
                                              " " +
                                              memberModelDetail.lastName,
                                          TextAlign.left,
                                           ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.bold),
                                      flex: 0,
                                    ),
                                    Expanded(
                                      flex: 0,
                                      child: memberModelDetail.roleId == "1"
                                          ? Util.getStudentBadge12(memberModelDetail.badge,memberModelDetail.badgeImage):Container(),
                                    ),
                                  ],
                                ),
                                 Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Flexible(
                                        child: TextViewWrap.textView(
                                          memberModelDetail.tagline == null ||
                                              memberModelDetail.tagline ==
                                                  "null" ||
                                              memberModelDetail.tagline == ""
                                              ? ""
                                              : memberModelDetail.tagline,
                                          TextAlign.start,
                                           ColorValues.GREY_TEXT_COLOR,
                                          12.0,
                                          FontWeight.normal,
                                        )),
                                  ],
                                ),
                              ],
                            )),
                        flex: 1,
                      ),
                       Expanded(
                        child: Row(
                          children: <Widget>[
                             InkWell(
                              child:  Padding(
                                  padding: EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 0.0),
                                  child:  Container(
                                      height: 40.0,
                                      width: 40.0,
                                      child: Image.asset(
                                        'assets/newDesignIcon/connections/tick_blue.png',
                                      ))),
                              onTap: () {
                                apiCalling(
                                    memberModelDetail.userId, index);
                              },
                            ),
                             InkWell(
                              child:  Padding(
                                  padding:
                                  EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                                  child:  Container(
                                      height: 30.0,
                                      width: 30.0,
                                      child: Image.asset(
                                        'assets/newDesignIcon/connections/cancel.png',
                                      ))),
                              onTap: () {
                                apiCallingReject(
                                    memberModelDetail.userId, index);
                              },
                            )
                          ],
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                ],
              )));
    }


    return  MaterialApp(
      home:  WillPopScope( onWillPop: (){
        Navigator.pop(context, isPerformChanges);
      },child: Scaffold(
        appBar: AppBar(
            backgroundColor: Colors.white,
            automaticallyImplyLeading: true,
            centerTitle: true,
            title: Text(MessageConstant.ABOUT_GROUP_GROUP_REQUESTs,

                style: TextStyle(
                    color:   ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16.0,
                    fontFamily: Constant.customBold)),
            leading:   InkWell(
              child: PaddingWrap.paddingfromLTRB(
                  0.0, 0.0, 15.0, 0.0, CustomViews.getBackButton()),
              onTap: () {
                Navigator.pop(context, isPerformChanges);
              },
            )),
        body:  Container(
            color: ColorValues.LIGHT_GRAY_BG,
            child:  Column(children: <Widget>[
              CustomViews.getSepratorLine(),
               Expanded(child: ListView(
                children: <Widget>[
                   Column(
                    children:  List.generate(
                        widget.modell.requestedList.length, (int index) {
                      return getListview(
                          widget.modell.requestedList[index], index, false);
                    }),
                  )
                ],
              ))
            ],)),
      )),
    );
  }

}
