import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:spike_view_project/component/app_constants.dart';

import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';

import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/component/CustomFormFieldWithPrefix.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class AddPhoneNumberView extends StatefulWidget {
  final String number;

  AddPhoneNumberView({@required this.number});

  @override
  AddPhoneNumberViewState createState() => AddPhoneNumberViewState();
}

class AddPhoneNumberViewState extends State<AddPhoneNumberView>
    with BaseCommonWidget {
  final numberController = TextEditingController();
  final numberFormKey = GlobalKey<FormState>();
  final FocusNode numberFocus = FocusNode();

  String selectedCountryCode = '1';

  @override
  void initState() {
    if (widget.number != null && widget.number.isNotEmpty) {
      numberController.text = widget.number;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    /*return SafeArea(
      child: Scaffold(
        appBar:  AppBar(
          elevation: 0.0,
          backgroundColor: Colors.white,
          centerTitle: true,
          title: Text('Call Now',
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.primaryTextColor, 18, FontType.Regular)),
          leading: backIcon(context),
          actions: <Widget>[
            InkWell(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(right: 14.0),
                  child: Text(
                    'Done  ',
                    textAlign: TextAlign.center,
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 16, FontType.Regular),
                  ),
                ),
              ),
              onTap: () {
                if (numberFormKey.currentState.validate()) {
                  Navigator.of(context).pop("+" +
                      selectedCountryCode +
                      numberController.text.toString());
                }
              },
            )
          ],
        ),
        body: Container(
          color: Palette.webColor,
          child: ListView(
            children: <Widget>[
              CustomViews.getSepratorLine(),
              Form(
                key: numberFormKey,
                child: Container(
                  padding: EdgeInsets.all(UIHelper.screenPadding),
                  child:  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      jobWidget(),
                      UIHelper.verticalGapBetweenBox,
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );*/

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image:
            AssetImage("assets/new_onboarding/background_screen.png"),
            fit: BoxFit.cover,
          ),
        ),
        child:
    FormKeyboardActions(
    nextFocus: false,
    keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
    keyboardBarColor: Colors.grey[200],
    actions: [
    KeyboardAction(
    focusNode: numberFocus,
    ),


    ],
      child:Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 54, 20, 18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  child: SizedBox(
                    height: 32.0,
                    width: 32.0,
                    child: Center(
                      child: Image.asset(
                        "assets/new_onboarding/back_blue_icon.png",
                        height: 32.0,
                        width: 32.0,
                        fit: BoxFit.fitHeight,
                      ),
                    ),
                  ),
                  onTap: () => Navigator.pop(context),
                ),
                const HelpButtonWidget(),
              ],
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(35),
                ),
              ),
              padding: EdgeInsets.fromLTRB(20, 25, 20, 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Call now',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontSize: 28,
                      fontWeight: FontWeight.w700,
                      fontFamily: Constant.latoRegular,
                    ),
                  ),
                  const SizedBox(height: 12),
                  SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 12),
                        Form(
                          key: numberFormKey,
                          child:  CustomFormFieldWithPrefix(
                            prefixWidget: Padding(
                              padding: const EdgeInsets.only(right: 5.0),
                              child: Container(
                                width: 55,
                                child: CountryCodePicker(
                                  dense: false,
                                  showFlag: true,
                                  isNew: true,
                                  showDialingCode: false,
                                  showUnderLine: false,
                                  showName: false,
                                  onChanged: (CountryCode country) {
                                    setState(() {
                                      selectedCountryCode = country.dialingCode;
                                    });
                                  },
                                  selectedCountryCode: selectedCountryCode,
                                ),
                              ),
                            ),
                            baseAlign: true,
                            autoValidate: false,
                            autoValidateMode: AutovalidateMode.disabled,
                            label: "Phone number",
                            controller: numberController,
                            focusNode: numberFocus,
                            textInputAction: TextInputAction.done,
                            textInputType: TextInputType.number,
                            validation: (value) {
                              return ValidationChecks.validatePhone(value);
                            },
                            inputFormatter: [
                              LengthLimitingTextInputFormatter(20),
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          'Enter the phone number to be dialed when users click this button',
                          style: TextStyle(
                            color: Color(0xff666B9A),
                            fontWeight: FontWeight.w400,
                            fontFamily: Constant.latoRegular,
                            fontSize: 12,
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),

    )





      ),
      bottomNavigationBar: Container(
        padding:  EdgeInsets.fromLTRB(20, 40, 20, 40),
        color: Colors.white,
        child: ElevatedButton(
          onPressed: () {
            if (numberFormKey.currentState.validate()) {
              Navigator.of(context).pop("+" +
                  selectedCountryCode +
                  numberController.text.toString());
            }
          },
          style: ElevatedButton.styleFrom(
            elevation: 0,
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            padding: EdgeInsets.symmetric(vertical: 10),
            primary: const Color(0xff4684EB),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          child: Text(
            'Done',
            textAlign: TextAlign.center,
             style: AppConstants.txtStyle.heading18600LatoRegularWhite,
          ),
        ),
      ),
    );
  }

  jobWidget() {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(
              right: UIHelper.screenPadding,
              top: 5,
              /* bottom: UIHelper.screenPadding */
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                CountryCodePicker(
                  dense: false,
                  showFlag: true,
                  //displays flag, true by default
                  showDialingCode: true,
                  //displays dialing code, false by default
                  showName: false,
                  //displays country name, true by default
                  onChanged: (CountryCode country) {
                    setState(() {
                      selectedCountryCode = country.dialingCode;
                    });
                  },
                  selectedCountryCode: selectedCountryCode,
                ),
                SizedBox(
                  width: 12,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0,4.0,0.0,0.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        TextFormField(
                          focusNode: numberFocus,
                          controller: numberController,
                          decoration:
                              textFormFieldDecorationWithLabel('Phone Number'),
                          style: textFormFieldValueStyle(),
                          keyboardType: TextInputType.number,
                          textCapitalization: TextCapitalization.none,
                          onFieldSubmitted: (term) {
                            numberFocus.unfocus();
                          },
                          validator: (value) {
                            return ValidationChecks.validatePhone(value);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Text(
            'Enter the phone number to be dialed when users click this button',
            style: AppTextStyle.getDynamicFontStyle(
                Palette.secondaryTextColor, 12, FontType.Regular),
          )
        ],
      ),
    );
  }
}
