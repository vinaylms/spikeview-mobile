import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/education/model/UniversityModel.dart';
import 'package:spike_view_project/intrest/EditFutureGoalsWidget.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/studentWizard/SkillSelectionWiget.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';
import 'package:spike_view_project/skill/model/SkillModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
//import 'package:spike_view_project/modal/SavedInterestListModel.dart';

// Create a Form Widget
class EditStudentGoalInterestWidget extends StatefulWidget {
  SkillIntrestDataModel _mSkillModel;
  bool isFirstTimeCalling;
  ProfileInfoModal profileInfoModal;

  EditStudentGoalInterestWidget(
      this._mSkillModel, this.isFirstTimeCalling, this.profileInfoModal);

  @override
  EditStudentGoalInterestWidgetState createState() {
    return  EditStudentGoalInterestWidgetState();
  }
}

class EditStudentGoalInterestWidgetState
    extends State<EditStudentGoalInterestWidget> with BaseCommonWidget {
  final _formKey = GlobalKey<FormState>();
  SharedPreferences prefs;
  String userIdPref, roleId, token;
  ScrollController _scrollController = ScrollController();
  SkillModel _skillModel =  SkillModel();

  List<SkillData> selectedLoveInterestsList =  List<SkillData>();

  String strInstitute = '';
  int optionCount = 0;

  TextEditingController instituteController =
       TextEditingController(text: "");
  String popString = '';
  SkillIntrestDataModel widgetSkillModel;

  final FocusNode _otherInterestFocus = FocusNode();

  UniversityModel _universityModel =  UniversityModel();

  List<UniversityResult> _universityList;
  List<UniversityResult> _searchedUniversityList =  List<UniversityResult>();
  List<GoalUniversity> selectedUniversityOption =  List<GoalUniversity>();
  List<UniversityResult> removedUniversiyList =  List<UniversityResult>();
  List<UniversityResult> selectedUniversityList =  List<UniversityResult>();
  List<UniversityResult> origanalUniversiyList =  List<UniversityResult>();

  Color bottomViewColor = Palette.dividerColor;
  bool showList = false;
  bool isScroled = true;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();

  TextEditingController _textFieldController =
       TextEditingController(text: "");
   FocusNode _textFieldFocus = FocusNode();

  ScrollController controller;

  int listIndexFrom = 0;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    roleId = widget.profileInfoModal.roleId;
    token = prefs.getString(UserPreference.USER_TOKEN);
    print('inside getSharedPreferences() EditInterest');
    setState(() {
      if (widget._mSkillModel != null) {
        if (widget._mSkillModel.result[0].goalInterestInstitute != null &&
            widget._mSkillModel.result[0].goalInterestInstitute != "" &&
            widget._mSkillModel.result[0].goalInterestInstitute != "null") {
          instituteController.text =
              widget._mSkillModel.result[0].goalInterestInstitute;
          strInstitute = widget._mSkillModel.result[0].goalInterestInstitute;
        }
      }
    });
    callLoveInterestApi();
    //callCollegeListApi();
    getSaveDataForUniversity();
  }

//get universityList from shared pref
  void getSaveDataForUniversity() {
    // Fetch already saved and decode data
    print('inside getSaveDataForUniversity() Student');
    final String universityString =
        prefs.getString(UserPreference.UNIVERSITY_LIST);
    if (universityString != '' && universityString != null)
      _universityList = UniversityResult.decode(universityString);

    setUniversityData();
  }

  void setUniversityData() {
    try {
      _searchedUniversityList.clear();
      _searchedUniversityList.addAll(_universityList.sublist(0, 10));
      listIndexFrom = 10;

      for (GoalUniversity goalUniversities
          in widgetSkillModel.result[0].goalUniversities) {
        selectedUniversityOption.add(goalUniversities);
        selectedUniversityList.add(UniversityResult(
            name: goalUniversities.name,
            universityId: goalUniversities.universityId));
      }

      //selectedUniversityOption.addAll(widgetSkillModel.result[0].goalUniversities);

      if (_universityList != null && _universityList.isNotEmpty) {
        print('_universityList length 111:: ${_universityList.length}');
        origanalUniversiyList.addAll(_universityList);
        for (var selectedOption in selectedUniversityOption) {
          for (var universityResultModel in origanalUniversiyList) {
            print('universityResultModel:::::: ${universityResultModel.name}');
            if (selectedOption.universityId.toString() ==
                universityResultModel.universityId.toString()) {
              removedUniversiyList.add(UniversityResult(
                  //sId: universityResultModel.sId,
                  name: universityResultModel.name,
                  universityId: universityResultModel.universityId));

          /*    selectedUniversityList.add(UniversityResult(
                  name: universityResultModel.name,
                  universityId: universityResultModel.universityId));*/
            }
          }
        }
      }

      print(
          'selectedUniversityOption length:: ${selectedUniversityOption.length}');
      print('_universityList length:: ${_universityList.length}');
      print('origanalUniversiyList length:: ${origanalUniversiyList.length}');
      print('removedUniversiyList length:: ${removedUniversiyList.length}');

      //if (removedUniversiyList.length > 0) {
      _universityList.clear();
      //}
      print('_universityList length 111:: ${_universityList.length}');
      for (final e in origanalUniversiyList) {
        bool found = false;
        for (final f in removedUniversiyList) {
          if (e.universityId.toString() == f.universityId.toString()) {
            found = true;
            break;
          }
        }
        if (!found) {
          _universityList.add(e);
        }
      }
      print('_universityList length 222:: ${_universityList.length}');
      //add data to re

      setState(() {
        _universityList;
        _searchedUniversityList;
        removedUniversiyList;
        origanalUniversiyList;
        selectedUniversityOption;
      });
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
      print('inside ENDPOINT_universities_list catch error:: ${e.toString()}');
    }
  }

  //=========================================================Api Calling =======================================

  Future<String> callLoveInterestApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await  ApiCalling().apiCall(context,
            Constant.ENDPOINT_GET_HOBBY_TYPE_API + "goal_interests", "get");
        print("Love Skill Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _skillModel =  SkillModel.fromJson(response.data);
              //====================================
              //_skillModel =  SkillModel.fromJson(response.data);
              if (widgetSkillModel != null) {
                try {
                  if (widgetSkillModel.result.length > 0) {
                    for (Skills _mSkills
                        in widgetSkillModel.result[0].goalInterests) {
                      if (_mSkills.hobbyId.toString() == 'null' ||
                          _mSkills.hobbyId.toString() == "") {
                        selectedLoveInterestsList.add(new SkillData(
                          name: _mSkills.name,
                        ));
                      } else {
                        for (int i = 0; i < _skillModel.skillList.length; i++) {
                          try {
                            if (_mSkills.hobbyId.toString() ==
                                _skillModel.skillList[i].hobbyId.toString()) {
                              print('Apurva 555 if');
                              _skillModel.skillList[i].isSelected = true;
                              selectedLoveInterestsList.add(new SkillData(
                                  hobbyId: _skillModel.skillList[i].hobbyId,
                                  name: _skillModel.skillList[i].name,
                                  type: i.toString()));
                            }
                          } catch (e) {
                            crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
                            print(
                                'Apurva 555 if catch error:: ${e.toString()}');
                          }
                        }
                      }
                    }
                  }
                } catch (e) {
                  crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
                  print(
                      'inside love interest parent catch error:: ${e.toString()}');
                }
              }
              setState(() {
                _skillModel;
                selectedLoveInterestsList;
                optionCount = selectedLoveInterestsList.length;
              });

              //====================================
              //await getUnSelectedList();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
      e.toString();
    }
  }

  Future<String> callCollegeListApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_universities_list, "get");
        print("ENDPOINT_universities_list Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _universityModel =  UniversityModel.fromJson(response.data);
              try {
                _universityList = _universityModel.result;
                //_searchedUniversityList = _universityModel.result;
                _searchedUniversityList.clear();
                _searchedUniversityList.addAll(_universityList.sublist(0, 10));
                listIndexFrom = 10;

                for (GoalUniversity goalUniversities
                    in widgetSkillModel.result[0].goalUniversities) {
                  selectedUniversityOption.add(goalUniversities);
                  selectedUniversityList.add(UniversityResult(
                      name: goalUniversities.name,
                      universityId: goalUniversities.universityId));
                }
                //selectedUniversityOption.addAll(widgetSkillModel.result[0].goalUniversities);

                if (_universityList != null && _universityList.isNotEmpty) {
                  print(
                      '_universityList length 111:: ${_universityList.length}');
                  origanalUniversiyList.addAll(_universityList);
                  for (var selectedOption in selectedUniversityOption) {
                    for (var universityResultModel in origanalUniversiyList) {
                      print(
                          'universityResultModel:::::: ${universityResultModel.name}');
                      if (selectedOption.toString() ==
                          universityResultModel.name) {
                        removedUniversiyList.add(UniversityResult(
                            //sId: universityResultModel.sId,
                            name: universityResultModel.name,
                            universityId: universityResultModel.universityId));


                      }
                    }
                  }
                }

                print(
                    'selectedUniversityOption length:: ${selectedUniversityOption.length}');
                print('_universityList length:: ${_universityList.length}');
                print(
                    'origanalUniversiyList length:: ${origanalUniversiyList.length}');
                print(
                    'removedUniversiyList length:: ${removedUniversiyList.length}');

                //if (removedUniversiyList.length > 0) {
                _universityList.clear();
                //}
                print('_universityList length 111:: ${_universityList.length}');
                for (final e in origanalUniversiyList) {
                  bool found = false;
                  for (final f in removedUniversiyList) {
                    if (e.universityId.toString() ==
                        f.universityId.toString()) {
                      found = true;
                      break;
                    }
                  }
                  if (!found) {
                    _universityList.add(e);
                  }
                }
                print('_universityList length 222:: ${_universityList.length}');
                //add data to re

                setState(() {
                  _universityList;
                  _searchedUniversityList;
                  removedUniversiyList;
                  origanalUniversiyList;
                  selectedUniversityOption;
                });
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
                print(
                    'inside ENDPOINT_universities_list catch error:: ${e.toString()}');
              }
              //}
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
      e.toString();
    }
  }

  //--------------------------Edit Data ------------------

  void conformationDialogForAddIntoProfile() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    "Do you want to publish this interest to your public profile?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              editInterest('', false);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              editInterest('', true);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void _checkValidation() async {
    FocusScope.of(context).requestFocus(new FocusNode());
    final form = _formKey.currentState;

    form.save();
    if (form.validate()) {
      if (widget.isFirstTimeCalling) {
        if (Util.dobCheck(widget.profileInfoModal.dob) &&
            widget.profileInfoModal.publicUrl != null &&
            widget.profileInfoModal.publicUrl != "null" &&
            widget.profileInfoModal.publicUrl != "") {
          conformationDialogForAddIntoProfile();
        } else {
          editInterest('', false);
        }
      } else {
        editInterest('', false);
      }
    } else {
      print("Failure 00");
    }
  }

  Future editInterest(String from, addIntoProfile) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //  CustomProgressLoader.showLoader(context);

        //await getSelectedData();

        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": 1, //int.parse(roleId),
          //"userHobbyId":widget._mSkillModel.result[0].userHobbyId,
          "goal_interests":
              selectedLoveInterestsList.map((item) => item.toJson()).toList(),
          //"goalInterestInstitute" : instituteController.text.toString(),
          "goalUniversities":
              selectedUniversityList.map((item) => item.toJson()).toList(),
          "addIntoProfile": addIntoProfile
        };

        print("map+++" + map.toString());
        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_SKILL_API, map);
        print("response:-" + response.toString());
        try {
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];

              if (status == "Success") {
                popString = "push";
                if (from == 'next') {
                  onTapNextPage();
                } else {
                  Navigator.pop(context, popString);
                }
                print('Data updated successfully');
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  void _listener(){
    if(!_textFieldFocus.hasFocus){
      isScroled = true;
    }
  }


  @override
  void initState() {
    // TODO: implement initState
    try {
      widgetSkillModel = widget._mSkillModel;
      controller =  ScrollController()..addListener(_scrollListener);
      _textFieldFocus =  FocusNode()..addListener(_listener);
      //initSearchListener();
      getSharedPreferences();
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
      print(e.toString());
    }
    super.initState();
  }

  void _scrollListener() {
    print(controller.position.extentAfter);
    /*
      var colors = ["red", "green", "blue", "orange", "pink"];
      print(colors.sublist(1, 3)); // [green, blue]
     */
    if (controller.position.extentAfter < 500) {
      print('inside _scrollListener listIndexFrom:: $listIndexFrom');
      if (_textFieldController.text == "" &&
          listIndexFrom < _universityList.length) {
        setState(() {
          int listIndexFromEnd = listIndexFrom + 10;
          if (listIndexFromEnd >= _universityList.length) {
            listIndexFromEnd = _universityList.length - 1;
          } //_universityList length 111:: 9772
          print(
              'inside _scrollListener listIndexFrom:: $listIndexFrom, listIndexFromEnd:: $listIndexFromEnd');
          _searchedUniversityList
              .addAll(_universityList.sublist(listIndexFrom, listIndexFromEnd));
          listIndexFrom = listIndexFrom + 10;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    //-------------------------------------Main Ui ------------------------------------------
    return  WillPopScope(
      onWillPop: () {
        Navigator.pop(context, popString);
      },
      child:  GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child:  Scaffold(
              backgroundColor:  ColorValues.SCREEN_BG_COLOR,
              appBar:  AppBar(
                elevation: 0.0,
                automaticallyImplyLeading: false,
                titleSpacing: 2.0,
                brightness: Brightness.light,
                leading:  Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                     InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context, 'back');
                      },
                    )
                  ],
                ),
                actions: <Widget>[
                   InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        7.0,
                        10.0,
                        5.0,
                         Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                             Text(
                              "Save ",
                              style:  TextStyle(
                                  fontSize: 16.0,
                                  fontFamily: Constant.customRegular,
                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                            )
                          ],
                        )),
                    onTap: () {
                      //editInterest();
                      _checkValidation();
                      //if (!isApiCalling) _validateCardDetail();
                    },
                  )
                ],
                title:  Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                     Text(
                      "Future Goals",
                      style:  TextStyle(
                          fontSize: 18.0,
                          fontFamily: Constant.customRegular,
                          color:
                               ColorValues.HEADING_COLOR_EDUCATION),
                    )
                  ],
                ),
                backgroundColor: Colors.white,
              ),
              body: Column(
                children: <Widget>[
                  CustomViews.getSepratorLine(),
                  Expanded(
                    child: Stack(
                      children: <Widget>[
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 65,
                          child: ListView(
                            controller: _scrollController,
                            children: <Widget>[
                              Form(
                                key: _formKey,
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10.0, left: 0.0),
                                  child:  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(left: 13.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: <Widget>[
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                5.0,
                                                TextViewWrap.textViewMultiLine(
                                                    "What's next after high school?",
                                                    TextAlign.start,
                                                     ColorValues.HEADING_COLOR_EDUCATION,
                                                    18.0,
                                                    FontWeight.bold,
                                                    3)),
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                20.0,
                                                TextViewWrap.textViewMultiLine(
                                                    "Select what you would like to do after high school.",
                                                    TextAlign.start,
                                                     ColorValues.HEADING_COLOR_EDUCATION,
                                                    14.0,
                                                    FontWeight.normal,
                                                    4)),
                                            Container(
                                              height: 5.0,
                                            ),
                                            getUserInterestSelectedChips(
                                                selectedLoveInterestsList,
                                                true),
                                            _skillModel != null
                                                ? getUserInterestChips(
                                                    _skillModel.skillList,
                                                    false)
                                                : Container(
                                                    height: 0.0,
                                                  ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: 15.0,
                                      ),
                                       Divider(
                                        color:  ColorValues.GREY__COLOR_DIVIDER,
                                      ),
                                      selectedLoveInterestsList.any((item) =>
                                              item.name.contains('Year'))
                                          ? Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 13.0),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      20.0,
                                                      0.0,
                                                      5.0,
                                                      TextViewWrap.textViewMultiLine(
                                                          "Select College(s)",
                                                          TextAlign.start,
                                                           ColorValues.HEADING_COLOR_EDUCATION,
                                                          16.0,
                                                          FontWeight.bold,
                                                          3)),
                                                  /*  PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                TextViewWrap.textViewMultiLine(
                                                    "Add colleges of your interest in which you want to go in future",
                                                    TextAlign.start,
                                                     ColorValues.HEADING_COLOR_EDUCATION,
                                                    12.0,
                                                    FontWeight.normal,
                                                    3)),*/
                                                  collegeDropdownView(),
                                                  selectedUniversityOption !=
                                                              null &&
                                                          selectedUniversityOption
                                                                  .length >
                                                              0
                                                      ? Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  top: 5.0),
                                                          child: getUniversitySelectedChips(
                                                              selectedUniversityList,
                                                              true))
                                                      : Container(
                                                          width: 0,
                                                          height: 0,
                                                        ),
                                                ],
                                              ),
                                            )
                                          :  Container(height: 0.0),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        selectedLoveInterestsList
                                .any((item) => item.name.contains('Year'))
                            ? Align(
                                //bottom: 20,
                                //right: 13,
                                alignment: Alignment.bottomRight,
                                child:  InkWell(
                                  child:  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          0.0, 0.0, 13.0, 20.0),
                                      child: Image.asset(
                                        'assets/newDesignIcon/parentProfile/next.png',
                                        height: 45.0,
                                        width: 45.0,
                                      )),
                                  onTap: () {
                                    editInterest('next', false);
                                    //onTapNextPage();
                                  },
                                ),
                              )
                            : Container(
                                width: 0,
                                height: 0,
                              ),
                        Align(
                          //bottom: 20,
                          //right: 13,
                          alignment: Alignment.bottomLeft,
                          child:  InkWell(
                            child:  Padding(
                                padding:
                                    EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                                child: Image.asset(
                                  'assets/newDesignIcon/parentProfile/backword.png',
                                  height: 45.0,
                                  width: 45.0,
                                )),
                            onTap: () {
                              Navigator.of(context).pop(popString);
                            },
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ))),
    );
  }

  getUserInterestSelectedChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
            context: context,
            removeTop: true,
            removeBottom: true,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              primary: true,
              shrinkWrap: true,
              children: <Widget>[
                Wrap(
                  spacing: 5.0,
                  runSpacing: 0.0,
                  children: List<Widget>.generate(
                      _items.length, // place the length of the array here
                      (int index) {
                    return InputChip(
                      label: Text(
                        '${_items[index].name}',
                        maxLines: 4,
                        softWrap: true,
                        style: TextStyle(
                          fontSize: 14.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                        ),
                      ),
                      backgroundColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
                      shape: StadiumBorder(
                        side: BorderSide(
                            color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                      ),
                      onSelected: (bool value) {},
                      deleteIcon: Icon(
                        Icons.clear,
                        color:  ColorValues.WHITE,
                        size: 16.0,
                      ),
                      onDeleted: () {
                        print("selected index:: $index");
                        toggalSelection(isSelected, index);
                      },
                      labelStyle: TextStyle(
                        color: ColorValues.WHITE,
                        fontSize: 16,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12.0, vertical: 3.0),
                    );
                  }).toList(),
                ),
              ],
            ),
          )
        : Container(
            height: 0,
            width: 0,
          );
  }

  getUniversitySelectedChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
            context: context,
            removeTop: true,
            removeBottom: true,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              primary: true,
              shrinkWrap: true,
              children: <Widget>[
                Wrap(
                  spacing: 5.0,
                  runSpacing: 0.0,
                  children: List<Widget>.generate(
                      _items.length, // place the length of the array here
                      (int index) {
                    return Padding(
                        padding: const EdgeInsets.only(top:5.0),
                        child: InputChip(
                      label:
                          //soln 1 start
                          /*Flex(
                        direction: Axis.horizontal,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.all(0.0),
                            //color: Colors.red,
                            constraints: BoxConstraints(
                              maxWidth: MediaQuery.of(context).size.width - 113,
                            ),

                            child: Text(
                              '${_items[index].name}',
                              maxLines: 4,
                              softWrap: true,
                            ),
                          ),
                        ],
                      ),*/ //soln 1 end
                          Container(
                        padding: const EdgeInsets.all(0.0),
                        //color: Colors.red,
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width - 113,
                        ),

                        child: Text(
                          '${_items[index].name}',
                          maxLines: 4,
                          softWrap: true,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      /*Expanded(
                        child: Text(
                          '${_items[index].name}',
                          maxLines: 14,
                          softWrap: true,
                          overflow: TextOverflow.visible,

                        ),
                      ),*/

                      /*Text(
                        '${_items[index].name}',
                        maxLines: 4,
                        softWrap: true,
                      ),*/
                      backgroundColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
                      shape: StadiumBorder(
                        side: BorderSide(
                            color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                      ),
                      onSelected: (bool value) {},
                      deleteIcon: Icon(
                        Icons.clear,
                        color:  ColorValues.WHITE,
                        size: 16.0,
                      ),
                      onDeleted: () {
                        print("selected index:: $index");
                        updateList(_items[index], index);
                      },
                      labelStyle: TextStyle(
                        color: ColorValues.WHITE,
                        fontSize: 16,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12.0, vertical: 3.0),
                    ));
                  }).toList(),
                ),
              ],
            ),
          )
        : Container(
            height: 0,
            width: 0,
          );
  }

  getUserInterestChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
            context: context,
            removeTop: true,
            removeBottom: true,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              primary: true,
              shrinkWrap: true,
              children: <Widget>[
                Wrap(
                  spacing: 0.0,
                  runSpacing: 0.0,
                  children: List<Widget>.generate(
                      _items.length, // place the length of the array here
                      (int index) {
                    return _items[index].isSelected && !isSelected
                        ?  Container(
                            height: 0.0,
                            width: 0.0,
                          )
                        : Padding(
                            padding: const EdgeInsets.only(right: 5.0),
                            child: InputChip(
                              label: Text(
                                '${_items[index].name}',
                                softWrap: true,
                              ),
                              backgroundColor: ColorValues.WHITE,
                              shape: StadiumBorder(
                                side: BorderSide(
                                    color: ColorValues.BORDER_COLOR),
                              ),
                              onSelected: (bool value) {
                                if (!isSelected) {
                                  //print("selected index:: $index");
                                  toggalSelection(isSelected, index);
                                }
                              },
                              labelStyle: TextStyle(
                                color:
                                    ColorValues.HEADING_COLOR_EDUCATION,
                                fontSize: 16,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              ),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12.0, vertical: 3.0),
                            ),
                          );
                  }).toList(),
                ),
              ],
            ),
          )
        : Container(
            height: 0,
            width: 0,
          );
  }

  void toggalSelection(bool isSelected, int index) {
    if (isSelected) {
      //add item to unselected list and remove from selected list
      SkillData item = selectedLoveInterestsList[index];
      if (item.type != null && item.type != "") {
        _skillModel.skillList[int.parse(item.type)].isSelected = false;
      }
      selectedLoveInterestsList.removeAt(index);
      setState(() {
        _skillModel;
        selectedLoveInterestsList;
      });
    } else {
      //add item to selected list and remove from unselected list
      _skillModel.skillList[index].isSelected = true;
      selectedLoveInterestsList.add(new SkillData(
          hobbyId: _skillModel.skillList[index].hobbyId,
          name: _skillModel.skillList[index].name,
          type: index.toString()));

      setState(() {
        _skillModel;
        selectedLoveInterestsList;
      });
    }
    setState(() {
      optionCount = selectedLoveInterestsList.length;
      if (optionCount == 0) instituteController.text = '';
    });
  }

  void updateList(UniversityResult item, int index) {
    print('inside updateList');
    for (UniversityResult removeitem in removedUniversiyList) {
      print('inside updateList removeitem name:: ${removeitem.name}');
      if (item.name == removeitem.name && item.universityId != "") {
        print('update this inside name:: ${removeitem.name}');
        _universityList.add(removeitem);
      }
    }
    removedUniversiyList.removeAt(index);
    selectedUniversityList.removeAt(index);
    selectedUniversityOption.removeAt(index);
    setState(() {
      _universityList;
      removedUniversiyList;
      selectedUniversityList;
      selectedUniversityOption;
      if (showList) showList = !showList;
    });
  }

  Future<void> onTapNextPage() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  EditFutureGoalsWidget(
            widget._mSkillModel,
            selectedLoveInterestsList.length > 0
                ? false
                : widget.isFirstTimeCalling,
            widget.profileInfoModal)
    ));
    if (result == "push") {
      popString = "push";
      //apiCallForSkill(context);
      Navigator.pop(context, popString);
    } else if (result == 'back') {
      apiCallForSkill(context);
    }
  }

  Future<String> apiCallForSkill(context) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await  ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_GET_SKILL_API + userIdPref + "&roleId=" + roleId,
            "get");
        print("Skill Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              widgetSkillModel =
                   SkillIntrestDataModel.fromJson(response.data);
              setState(() {
                _skillModel;
                widgetSkillModel;
                selectedLoveInterestsList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditGoalsinterestWidget",context);
      e.toString();
    }
  }

  collegeDropdownView() {
    return Padding(
      padding: const EdgeInsets.only(right: 13.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: bottomBorderDynamic(bottomViewColor),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[

                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            showList = !showList;
                          });
                        },
                        child: Container(
                            padding: const EdgeInsets.only(bottom: 0.0),
                            child: TextField(
                                controller: _textFieldController,
                                style:
                                     TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                //autofocus: true,
                                onChanged: (value) {
                                  //print('onChanged called... text:: ${_textFieldController.text}');

                                  callListSearch();
                                },
                                onEditingComplete: () {
                                  setState(() {});
                                },
                                textInputAction: TextInputAction.done,
                                focusNode: _textFieldFocus,
                                autocorrect: false,
                                onSubmitted: (term) {
                                  _textFieldFocus.unfocus();
                                  if (_textFieldController.text != null &&
                                      _textFieldController.text.trim() != "") {
                                    //if (!findPersonUsingWhere(_textFieldController.text)) {

                                    List<UniversityResult> _searched = _universityList
                                        .where((food) => food.name
                                        .toLowerCase()
                                        .startsWith(_textFieldController.text.toLowerCase()))
                                        .toList();

                                    List<UniversityResult> _searchedSelected  = selectedUniversityList
                                        .where((food) => food.name
                                        .toLowerCase()
                                        .startsWith(_textFieldController.text.toLowerCase()))
                                        .toList();


                                  //  if (_searched.length==0){

                                      if (_searchedSelected.length==0||_searchedSelected.isEmpty){
                                        selectedUniversityOption.add(
                                            GoalUniversity(
                                                name: _textFieldController.text,
                                                universityId: ''));
                                        selectedUniversityList.add(
                                            UniversityResult(
                                                universityId: '',
                                                name: _textFieldController.text
                                                    .trim()));
                                        removedUniversiyList.add(UniversityResult(
                                            universityId: '',
                                            name: _textFieldController.text
                                                .trim()));
                                      }else {
                                        _textFieldController.clear();
                                      }
                                   /* }else {
                                      ToastWrap.showToast(MessageConstant.ALREADY_ORGANIZATION_ADDEDD, context);
                                    }*/


                                  }

                                //  }

                                  _textFieldController.clear();
                                  setState(() {
                                    selectedUniversityOption;
                                    selectedUniversityList;
                                    _universityList;
                                    //_searchedUniversityList = _universityList;
                                    _searchedUniversityList.clear();
                                    _searchedUniversityList
                                        .addAll(_universityList.sublist(0, 10));
                                    listIndexFrom = 10;
                                    showList = false;
                                  });
                                },
                                cursorColor: Constant.CURSOR_COLOR,
                                decoration:  InputDecoration(
                                  contentPadding: const EdgeInsets.fromLTRB(
                                      0.0, 5.0, 5.0, 5.0),
                                  border: InputBorder.none,
                                  /*hintText:
                                      selectedUniversityOption //spikeViewUserList //selectedUniversityOption
                                                  .length ==
                                              0
                                          ? 'Add colleges'
                                          //: "",
                                  : '${selectedUniversityOption[selectedUniversityOption.length - 1]}',*/

                                  labelText: "Add colleges",
                                  labelStyle:  TextStyle(
                                      fontSize: 16.0,
                                      color:  ColorValues.GREY__COLOR,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                ))),
                      ),
                    ),
                    /*IconButton(
                      onPressed: () {
                        showList = !showList;
                        setState(() {});
                      },
                      icon: Padding(
                        padding: const EdgeInsets.only(left: 15.0, top: 0),
                        child: Icon(showList
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down),
                      ),
                    ),*/
                  ],
                ),
                /*selectedUniversityOption.length > 0
                              ? selectOtherCategoryTextField()
                              : Container(),*/
              ],
            ),
          ),
          _universityList != null && _universityList.length > 0
              ? universityListWidget()
              : Container(),
        ],
      ),
    );
  }

  universityListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? _searchedUniversityList.length > 0
                ? Card(
                    child: Container(
                      height: _searchedUniversityList.length == 1
                          ? 50.0
                          : _searchedUniversityList.length == 2
                              ? 90.0
                              : _searchedUniversityList.length == 3
                                  ? 130
                                  : 200.0,
                      padding: _searchedUniversityList.length > 0
                          ? EdgeInsets.all(10)
                          : EdgeInsets.all(0),
                      child: ListView.builder(
                        padding: EdgeInsets.zero,
                        controller: controller,
                        key: _listKey,
                        //initialItemCount: _searchedUniversityList.length,
                        shrinkWrap: true,
                        itemCount: _searchedUniversityList.length,
                        itemBuilder: (context, index) {
                          return _searchedUniversityList.length >= index
                              ? _buildAddedItem(
                                  _searchedUniversityList[index], index)
                              : Container(
                                  width: 0,
                                  height: 0,
                                );
                        },
                      ),
                    ),
                  )
                : Container()
            : Container(),
      ],
    );
  }

  Widget _buildAddedItem(UniversityResult item, int index) {
    return item.name != null
        ? Container(
            child: InkWell(
              onTap: () {
                print("item++++" + item.name);
                onListItemTap(item);
              },
              child: AnimatedContainer(
                curve: Curves.easeIn,
                duration: Duration(milliseconds: 500),
                width: MediaQuery.of(context).size.width,
                child: Text(item.name,
                    style: TextStyle(fontFamily: Constant.customRegular)),
                padding: EdgeInsets.all(8),
              ),
            ),
          )
        : Container(
            width: 0,
            height: 0,
          );
  }

  void initSearchListener() {
    _textFieldController.addListener(() {
      if (_textFieldController.text.isEmpty) {

      } else {
        print("search caling =========");
        Timer _timer =  Timer(const Duration(milliseconds: 200), () {
          callListSearch();
        });
        //  }
      }
    });
  }

  List<UniversityResult> callListSearch() {
    print(
        'inside callListSearch() search text::: ${_textFieldController.text.trim()}');

    showList = false;

    if (_textFieldController.text.trim() != '') {

      /*var prefix = _textFieldController.text.trim();
      var restRegExp = RegExp(r'[a-zA-Z0-9]');

      var string = 'Dart';
      var startsWith =
          string.startsWith(prefix) &&
              string.substring(prefix.length).startsWith(restRegExp);*/

      _searchedUniversityList = _universityList
          .where((food) => food.name
              .toLowerCase()
          .startsWith(_textFieldController.text.toLowerCase()))
          .toList();

      /*_searchedUniversityList = _universityList
          .where((food) => food.name
              .toLowerCase()
              .contains(_textFieldController.text.toLowerCase()))
          .toList();*/
    } else {
      isScroled=true;
      _searchedUniversityList.clear();
     // _searchedUniversityList.addAll(_universityList.sublist(0, 10));
     // listIndexFrom = 10;
    }

    setState(() {
      _searchedUniversityList;
      showList = true;
    });
    print("shubh text++");
    if(isScroled&&_searchedUniversityList.length>0) {
      isScroled=false;
      _scrollController.jumpTo((_scrollController.offset + 200.0));
    }else{
     // isScroled=true;
    }
    print(
        'inside callListSearch() _searchedUniversityList size:; ${_searchedUniversityList.length}');
    return _searchedUniversityList;
  }

  bool findPersonUsingWhere(String personName) {
    // Return list of people matching the condition
    final foundPeople =
        _universityList.where((element) => element.name == personName);

    if (foundPeople.isNotEmpty) {
      print('Using where: ${foundPeople.first}');
      return true;
    } else
      return false;
  }

  void onListItemTap(UniversityResult item) {
    _textFieldFocus.unfocus();
    removedUniversiyList.add(item);
    selectedUniversityList.add(
        UniversityResult(name: item.name, universityId: item.universityId));

    selectedUniversityOption
        .add(GoalUniversity(name: item.name, universityId: item.universityId));
    if (_universityList.length > 0) {
      _searchedUniversityList.remove(item);
      _universityList.remove(item);
    }
    showList = !showList;
    _textFieldController.text = '';
    //_searchedUniversityList = _universityList;
    _searchedUniversityList.clear();
    _searchedUniversityList.addAll(_universityList.sublist(0, 10));
    listIndexFrom = 10;
    setState(() {
      bottomViewColor = Palette.dividerColor;
      _textFieldController;
      _searchedUniversityList;
      _universityList;
      listIndexFrom;
    });
  }
}
