import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';


enum VideoType { file, network, assets }

class VideoPlayerView extends StatefulWidget {
  final String videoPath;
  final VideoType videoType;
  final VoidCallback onPlayEnd;
  final bool hideController;

  const VideoPlayerView({
    @required this.videoPath,
    @required this.videoType,
     this.onPlayEnd,
     this.hideController,
    Key key,
  }) : super(key: key);

  @override
  State createState() => _VideoPlayerViewState();
}

class _VideoPlayerViewState extends State<VideoPlayerView> {
  VideoPlayerController controller;
  int _videoDuration = 0;

  @override
  void initState() {
    switch (widget.videoType) {
      case VideoType.file:
        controller = VideoPlayerController.file(File(widget.videoPath))
          ..addListener(() => _playerReset())
          ..setLooping(false)
          ..setVolume(1)
          ..initialize().then((_) => setState(() {
                _videoDuration = controller?.value?.duration?.inSeconds ?? 0;
              }));
        break;
      case VideoType.network:
        controller = VideoPlayerController.network(widget.videoPath)
          ..addListener(() => _playerReset())
          ..setLooping(false)
          ..setVolume(1)
          ..initialize().then((_) => setState(() {
                _videoDuration = controller?.value?.duration?.inSeconds ?? 0;
              }));
        break;
      case VideoType.assets:
        controller = VideoPlayerController.asset(widget.videoPath)
          ..addListener(() => _playerReset())
          ..setLooping(false)
          ..setVolume(1)
          ..initialize().then((_) => setState(() {
                _videoDuration = controller?.value?.duration?.inSeconds ?? 0;
              }));
        break;
    }
    super.initState();
  }

  void _playerReset() async {
    if(controller != null && _videoDuration > 0){
      final position = await controller?.position;
      if (position != null && position.inSeconds == _videoDuration) {
        controller?.pause();
        controller?.seekTo(Duration(seconds: 0));
        if(widget?.onPlayEnd != null){
          widget.onPlayEnd();
        }
        setState(() {});
      }
    }
  }

  @override
  void dispose() async {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: controller?.value?.initialized ?? false
            ? Container(alignment: Alignment.topCenter, child: buildVideo())
            : const Center(
          child: SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(
                Colors.white,
              ),
              strokeWidth: 2.0,
            ),
          ),
        ),
      );

  Widget buildVideo() => OrientationBuilder(builder: (context, orientation) {
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            //buildVideoPlayer(),
            Chewie(
              controller: ChewieController(
                videoPlayerController: controller,
                autoPlay: false,
                allowFullScreen: false,
                aspectRatio: controller.value.aspectRatio,
                looping: false,
                showControls: (widget?.hideController ?? false) ? false : true,
                placeholder: Container(
                  color: Colors.black,
                ),
              ),
            ),
            /*widget?.hideController ?? false
            ?const SizedBox.shrink()
            :_basicOverlayWidget(controller),*/
          ],
        );
      });

  Widget buildVideoPlayer() => buildFullScreen(
        AspectRatio(
          aspectRatio: controller?.value?.aspectRatio ?? 0,
          child: VideoPlayer(controller),
        ),
      );

  Widget buildFullScreen(Widget child) {
    final size = controller?.value?.size;
    final width = size?.width;
    final height = size?.height;

    return FittedBox(
      fit: BoxFit.contain,
      child: SizedBox(width: width, height: height, child: child),
    );
  }

  Widget _basicOverlayWidget(VideoPlayerController controller) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        controller?.value?.isPlaying ?? false
            ? controller?.pause()
            : controller?.play();
        setState(() {});
      },
      child: Stack(
        children: <Widget>[
          _buildPlay(),
          Positioned(
            bottom: 0,
            left: 16,
            right: 16,
            child: Container(
              alignment: Alignment.center,
              //color: Colors.black12,
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: _buildIndicator(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIndicator() => Row(
        children: [
          Icon(
            controller?.value?.isPlaying ?? false
                ? Icons.pause
                : Icons.play_arrow,
            color: Colors.white,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: VideoProgressIndicator(
              controller,
              allowScrubbing: true,
              colors: VideoProgressColors(
                  backgroundColor: Colors.white38,
                  bufferedColor: Colors.white,
                  playedColor: const Color(0xffF48808)),
            ),
          ),
        ],
      );

  Widget _buildPlay() => controller?.value?.isPlaying ?? false
      ? const SizedBox.shrink()
      : Container(
          alignment: Alignment.center,
          color: Colors.black26,
          height: Get.height,
          width: Get.width,
          child: Stack(
            children: [
              Center(
                child: Image.asset(
                  'assets/ic_intro_play.png',
                  height: 40,
                  width: 40,
                ),
              ),
            ],
          ),
        );
}
