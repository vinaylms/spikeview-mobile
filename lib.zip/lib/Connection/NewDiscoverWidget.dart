import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/Connection/RefferalModel.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class NewDiscoverWidget extends StatefulWidget {
  @override
  State<NewDiscoverWidget> createState() => _NewDiscoverWidgetState();
}

class _NewDiscoverWidgetState extends State<NewDiscoverWidget>
    with AutomaticKeepAliveClientMixin {
  List<PeopleYouMayKnow> peopleYouMayKnowList = List();
  ScrollController _scrollController = ScrollController();
  TextEditingController edtController = TextEditingController();
  int skip = 0;
  int searchCount = 0;
  String userIdPref, roleId, userProfilePath;
  String title;
  int listType;
  String statusIndex, searchName = "";
  BuildContext context;
  SharedPreferences prefs;
  List<RefferalModel> refferList = List();
  List<RequestedTagModel> tagList = List();
  List<RequestedTagModel> sendRequestList = List();
  List<PeopleYouMayKnow> searchtagList = List();
  Map<String, String> dataExist = Map();
  List<RequestedTagModel> pendingRequestList = List();
  List<RequestedTagModel> recievedRequestList = List();
  int PeopleYouMayKnowCount = 0;

  Timer _timer;

  void _onSearch() {
    if(edtController.text.trim().isNotEmpty) {
      if (_timer?.isActive ?? false) {
        _timer?.cancel();
      }
      _timer = Timer(Duration(seconds: 1), () {
        skip = 0;
        isLoading = true;
        setState(() {});
        apiToGetDetail();
      });
    }
  }

  @override
  void initState() {
    getSharedPreferences();

    // TODO: implement initState
    super.initState();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        skip = skip + 1;

        print("sss  _scrollController skip" + skip.toString());
        apiToGetDetail();
      }
    });
  }

  Future apiToGetDetail() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        searchCount = 0;
        listType = 2;

        print(Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
            userIdPref +
            "&status=" +
            statusIndex.toString() +
            "&roleId=" +
            roleId +
            "&skip=" +
            skip.toString());

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
                userIdPref +
                "&status=" +
                statusIndex.toString() +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString() +
                "&name=" +
                searchName +
                "&limit=" +
                "10",
            "get");
        isLoading = false;
        if (searchName.isEmpty) {
          searchtagList.clear();
        } else {
          if (searchCount == 0) {
            searchtagList.clear();
            searchCount = 1;
          }
        }
        setState(() {
          isLoading;
        });

        print("-=------------ skip.toString()++++ " + skip.toString());
        print(response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              List<PeopleYouMayKnow> peopleYouMayKnowListLocal = List();

              peopleYouMayKnowListLocal =
                  ParseJson.parsePeopleMayYouKnow(response.data['result']);
              print("Local List Size sss 1--------->" +
                  peopleYouMayKnowListLocal.length.toString());
              for (int i = 0; i < searchtagList.length; i++) {
                for (int j = 0; j < peopleYouMayKnowListLocal.length; j++) {
                  if (searchtagList[i].userId ==
                      peopleYouMayKnowListLocal[j].userId) {
                    peopleYouMayKnowListLocal.removeAt(j);
                  }
                }
              }
              if (searchName.isEmpty) {
                peopleYouMayKnowList.addAll(peopleYouMayKnowListLocal);
                searchtagList.addAll(peopleYouMayKnowList);
                print("SSS 111 ${searchtagList.length}");
              } else {
                searchtagList.addAll(peopleYouMayKnowListLocal);
                print("SSS 222 ${searchtagList.length}");
              }

              setState(() {
                peopleYouMayKnowList;
                searchtagList;
              });

              if (tagList != null) {
                if (tagList.length > 0) {
                  prefs.setString(
                      UserPreference.ISACTIVE, tagList[0].userIsActive);
                }
                print("Local List Size sss 4--------->" +
                    peopleYouMayKnowList.length.toString());
                setState(() {
                  print("After Success Response");
                  tagList;
                  sendRequestList;
                  pendingRequestList;
                  recievedRequestList;
                  peopleYouMayKnowList;
                  searchtagList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);

    statusIndex = Constant.DISCOVER;
    apiToGetDetail();
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;



    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 10.0),
          child: SizedBox(
            height: 40,
            child: TextField(
              textAlign: TextAlign.left,
              controller: edtController,
              onChanged: (value) {
                searchName = value;
                _onSearch();
                // if (value.isNotEmpty) {
                //   searchCount = 0;
                //   apiToGetDetail();
                // }
              },
              decoration: InputDecoration(
                filled: true,
                fillColor: ColorValues.TAB_BACKGROUND_COLOR,
                hintText: "Search connections",
                hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: Constant.latoRegular,
                    color: ColorValues.hintColor,
                    fontWeight: FontWeight.w400),
                contentPadding: EdgeInsets.fromLTRB(15.0, 10.0, 20.0, 10.0),
                suffixIcon: IconButton(
                  onPressed: () {
                    if (edtController.text.trim() != "") {
                      apiToGetDetail();
                    }
                    // apiToGetDetail();
                  },
                  icon: Image.asset(
                    "assets/newDesignIcon/connections/new_search.png",
                    height: 20,
                    width: 20,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(10.0),
                  ),
                  borderSide: BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(10.0),
                  ),
                  borderSide: BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                ),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    borderSide:
                        new BorderSide(color: ColorValues.BORDER_COLOR_NEW)),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 10.0),
          child: Container(
              height: 40,
              decoration: BoxDecoration(
                color: ColorValues.TAB_BACKGROUND_COLOR,
                border: Border.all(
                  color: ColorValues.BORDER_COLOR_NEW,
                ),
                borderRadius: BorderRadius.all(
                  Radius.circular(10.0),
                ),
              ),
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 0.0),
                    child: RichText(
                      text: TextSpan(
                          text: "Can't find your friends?",
                          style: TextStyle(
                              color: ColorValues.labelColor,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              fontFamily: Constant.latoMedium),
                          children: <TextSpan>[
                            TextSpan(
                                text: ' Invite now',
                                style: TextStyle(
                                    color: ColorValues.BLUE_COLOR,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: Constant.latoMedium),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    onTapRefer();
                                  })
                          ]),
                    ),
                  ),
                ],
              )),
        ),
        Expanded(
          child: searchtagList.length > 0
              ? ListView.builder(
                  controller: _scrollController,
                  itemCount: searchtagList.length,
                  padding: EdgeInsets.zero,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        getListViewForPeopleMayKnow(
                            searchtagList[index], index),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: const Divider(
                            thickness: 1,
                            height: 0,
                            color: Color(0xffE5EBF0),
                          ),
                        ),
                      ],
                    );
                  },
                )
              : isLoading
                  ? const SizedBox.shrink()
                  : Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Image.asset(
                            "assets/newDesignIcon/icon/no_user_found.png",
                            height: 111.0,
                          ),
                          const SizedBox(height: 10),
                          BaseText(
                            text: 'No user found',
                            textColor: ColorValues.HEADING_COLOR_CHAT_1,
                            fontFamily:
                            AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w600,
                            fontSize: 18,
                            textAlign: TextAlign.center,
                            maxLines: 1,
                          ),
                        ],
                      ),
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  onTapRefer() async {
    print("refer now Clicked====================");
    String referCode = prefs.getString(UserPreference.referCode);
    if (roleId == "1")
      Util.shareAppLinkViaOtherApp(
          context, referCode, prefs.getString(UserPreference.NAME));
    else
      Util.shareAppLinkViaOtherAppParent(
          context,
          referCode,
          roleId == "4"
              ? prefs.getString(UserPreference.COMPANY_NAME_PATH)
              : prefs.getString(UserPreference.NAME));
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  bool isNeedToRefresh = false;
  bool isLoading = true;

  Widget getListViewForPeopleMayKnow(PeopleYouMayKnow, index) {
    return InkWell(
      child: Padding(
        padding:  EdgeInsets.fromLTRB(20, index==0?6:16, 20, 16),
        child: Row(
          children: <Widget>[



            Expanded(
              child: ProfileImageView(
                imagePath:Constant.IMAGE_PATH_SMALL +
                    ParseJson.getSmallImage(
                        PeopleYouMayKnow.profilePicture),
                placeHolderImage: PeopleYouMayKnow.roleId == "4"
                    ? "assets/profile/partner_img.png"
                    : 'assets/profile/user_on_user.png',
                height: 48.0,
                width: 48.0,
                onTap: () async{
                  if (PeopleYouMayKnow.userId == userIdPref) {
                  } else {
                    Util.onTapImageTile(
                        tapedUserRole: PeopleYouMayKnow.roleId,
                        partnerUserId: PeopleYouMayKnow.userId,
                        context: context);
                  }
                },
              ),
              flex: 0,
            ),
            Expanded(
              child: PaddingWrap.paddingfromLTRB(
                  10.0,
                  0.0,
                  0.0,
                  0.0,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: BaseText(
                              text: getName(PeopleYouMayKnow, null),
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              maxLines: 1,
                              textAlign: TextAlign.start,
                            ),
                            flex: 0,
                          ),
                          Expanded(
                            flex: 0,
                            child: PeopleYouMayKnow.roleId == "1"
                                ? Util.getStudentBadge12New(
                                    PeopleYouMayKnow.badge,
                                    PeopleYouMayKnow.badgeImage)
                                : Container(),
                          ),
                        ],
                      ),
                      PeopleYouMayKnow.tagline == null ||
                              PeopleYouMayKnow.tagline == "null" ||
                              PeopleYouMayKnow.tagline == ""
                          ? SizedBox()
                          : Padding(
                              padding:
                                  const EdgeInsets.only(top: 4.0, bottom: 5),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: TextViewWrap.textView(
                                      PeopleYouMayKnow.tagline == null ||
                                              PeopleYouMayKnow.tagline ==
                                                  "null" ||
                                              PeopleYouMayKnow.tagline == ""
                                          ? ""
                                          : PeopleYouMayKnow.tagline,
                                      TextAlign.start,
                                      ColorValues.GREY_TEXT_COLOR,
                                      12.0,
                                      FontWeight.normal,
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                    ],
                  )),
              flex: 1,
            ),
            ButtonView(
              btnName: 'Connect',
              borderColor: AppConstants.colorStyle.lightBlue,
              bgColor: AppConstants.colorStyle.box_bg_color,
              txtColor: AppConstants.colorStyle.lightBlue,
              onButtonTap: () {
                if (!PeopleYouMayKnow.isRequested) {
                  apiCallForConnectForPeopleMayKnow(
                      index,
                      PeopleYouMayKnow.userId,
                      PeopleYouMayKnow.roleId,
                      PeopleYouMayKnow.isActive);
                }
              },
            )
          ],
        ),
      ),
      onTap: () {},
    );
  }

  Future apiCallForPending() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });

        print(Constant.ENDPOINT_PENDING +
            "/" +
            userIdPref +
            "/" +
            roleId +
            "/pending");

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_PENDING +
                "/" +
                userIdPref +
                "/" +
                roleId +
                "/pending",
            "get");
        isLoading = false;
        setState(() {
          isLoading;
        });

        print("-=------------ skip.toString()++++ " + skip.toString());
        print(response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              List<RefferalModel> referLocalList = List();

              referLocalList = ParseJson.parseRefferal(response.data['result']);

              refferList.addAll(referLocalList);

              setState(() {
                refferList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  // -------------------  API ------------------------------

  getName(PeopleYouMayKnow, requestedTagModel) {
    String firstName, lastName;

    if (PeopleYouMayKnow != null) {
      if (PeopleYouMayKnow.lastName == null ||
          PeopleYouMayKnow.lastName == "null" ||
          PeopleYouMayKnow.lastName == "") {
        lastName = "";
      } else {
        lastName = PeopleYouMayKnow.lastName;
      }

      if (PeopleYouMayKnow.firstName == null ||
          PeopleYouMayKnow.firstName == "null" ||
          PeopleYouMayKnow.firstName == "") {
        firstName = PeopleYouMayKnow.email;
      } else {
        firstName = PeopleYouMayKnow.firstName;
      }

      return firstName + " " + lastName;
    } else {
      if (requestedTagModel.patner.lastName == null ||
          requestedTagModel.patner.lastName == "null" ||
          requestedTagModel.patner.lastName == "") {
        lastName = "";
      } else {
        lastName = requestedTagModel.patner.lastName;
      }

      if (requestedTagModel.patner.firstName == null ||
          requestedTagModel.patner.firstName == "null" ||
          requestedTagModel.patner.firstName == "") {
        firstName = requestedTagModel.patner.email;
      } else {
        firstName = requestedTagModel.patner.firstName;
      }

      return firstName + " " + lastName;
    }
  }
  void showSucessDialog(name) {

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            headingText: 'Your request has been sent successfully!',
            negativeText: 'OK',
            isSucessPopup: true,
            positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
            },

          );
        });


  }
  Future apiCallForConnectForPeopleMayKnow(
      int index, String partnerId, String partnerRoleId, bool isActive) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": prefs.getString(UserPreference.USER_ID),
          "partnerId": int.parse(partnerId),
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "status": Util.currentAge(
                      DateTime.fromMillisecondsSinceEpoch(
                          int.tryParse(prefs.getString(UserPreference.DOB))),
                      13) <
                  13
              ? "Pending"
              : "Requested",
          "isActive": isActive,
          "userRoleId": int.parse(roleId),
          "partnerRoleId": int.parse(partnerRoleId)
        };
        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg);
              searchtagList.clear();
              String name=peopleYouMayKnowList[index].lastName=='null'?peopleYouMayKnowList[index].firstName:peopleYouMayKnowList[index].firstName+" "+peopleYouMayKnowList[index].lastName;
              peopleYouMayKnowList.removeAt(index);
              searchtagList.addAll(peopleYouMayKnowList);

              setState(() {
                // Remove from current List

                peopleYouMayKnowList;
                searchtagList;
                isNeedToRefresh = true;
              });
              showSucessDialog(name);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
