import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:injectable/injectable.dart';

import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/constant/Constant.dart';

@lazySingleton
class SharedService {




  Future<Response> getPosts(shareId) async {
    Response  response;
    try {

      print('chatApi+++++++++=='+Constant.ENDPOINT_SHARE_ID + shareId);
      response = await  ApiCalling2().apiCall(
          null, Constant.ENDPOINT_SHARE_ID + shareId+  "&publickey=1",

          "get");


    } catch (e) {
    }
    return response;
  }
}
