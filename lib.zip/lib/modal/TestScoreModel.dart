import 'dart:io';

class TestScoreModel {
  String testName;
  int testId;
  bool isSubCategory,isSelected=false;
  List<SebjectDetailModel> subjectListModel;

  TestScoreModel(this.testName, this.testId, this.isSubCategory,
      this.subjectListModel);


}

class SebjectDetailModel {
  int testSubId,testId,minScore,maxScore,sequence;
  String  subjectName;
bool isSelected=false;
bool isOptional=false;
  SebjectDetailModel(this.testSubId, this.testId, this.minScore, this.maxScore,
      this.sequence, this.subjectName,this.isOptional);


}

class ScoreModel {
  String score;
  int  testSubId;

  ScoreModel(this.score, this.testSubId);
  Map<String, dynamic> toJson() => {
    'testSubId': testSubId,
    'score': score==null?"":score,
  };

}