import 'dart:async';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:adhara_socket_io/manager.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/home/OpportunityView.dart';
import 'package:spike_view_project/home/TagDetailWidget.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/linkPreview/whatsapp/view.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';

class FeedReportWidgetBoat extends StatefulWidget {
  String feedId, pageName;

  FeedReportWidgetBoat(this.feedId, this.pageName);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  FeedReportWidgetBoatState();
  }
}

class FeedReportWidgetBoatState extends State<FeedReportWidgetBoat> {
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isLoading = true;
  List<UserPostModal> userPostList =  List<UserPostModal>();
  String dob;
  RegExp exp =  RegExp(
      r"(http|ftp|https|Https|Http)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");

  showSucessMsg(msg, context, duration, maxLine) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(Duration(milliseconds: duration), () async {
      print("timer off");
      Navigator.pop(context);
     onBack();
    });

    showDialog(
        context: context,
        builder: (_) =>
         WillPopScope(
            onWillPop: () {
            },
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: maxLine == 2 ? 65.0 : 85.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: maxLine,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }


  void conformationDialogForCommunityPost(msg,value) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    msg,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.GREY_TEXT_COLOR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "OK",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallingForUpdate();
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  showErrorMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: 'ERROR: ',
                                    style:  TextStyle(
                                      color:  Color(0xffFF0101),
                                      height: 1.2,
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: msg,
                                        style:  TextStyle(
                                            color:  Color(0xffFF0101),
                                            fontSize: 13.0,
                                            fontWeight: FontWeight.normal,
                                            fontFamily: Constant.customRegular),
                                      )
                                    ],
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCallingForUserPost() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        userPostList.clear();
        print("userId" + userIdPref);
        print("feed boat++++"+ "ui/feed/detail?userId=" + userIdPref + "&roleId=" + roleId +
            "&feedId=" + widget.feedId);
        Response response = await  ApiCalling().apiCall(
            context,
            "ui/feed/detail?userId=" + userIdPref + "&roleId=" + roleId +
                "&feedId=" + widget.feedId,
            "get");
        isLoading = false;
        setState(() {
          isLoading;
        });
        print("feed response++++"+widget.feedId+"  "+response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              if (response.data['result'] == null) {
             /*   ToastWrap.showToastWithPush(
                    MessageConstant.AUTHOR_DELETED_POST, context);*/
                showErrorMsg(MessageConstant.AUTHOR_DELETED_POST, context);
              }else{
              userPostList.clear();
              userPostList.addAll(ParseJson.parseFeedForReport(
                  response.data['result'], userIdPref, roleId));

              print("userpostlenght " + userPostList.length.toString());
            }
            }
          }
        }
      } else {
        isLoading = false;
        setState(() {
          isLoading;
        });
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallingForUpdate() async {
    try {
      Response response;

      Map map = {
        "userId": userIdPref,
        "roleId": roleId,
        "id": widget.feedId,
        "reportType": "Feed",
      };
      print("map:-" + map.toString());

      response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.REPORT_FEED_UNBLOCK, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    apiCallingForUserPost();
  }

  onBack() async {
    if (widget.pageName == "") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);

      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
             DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
             DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>
             DashBoardWidget(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    getSharedPreferences();
    print("==================== INIT STATE");
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Widget _loader(BuildContext context) =>
        Center(
            child: Container(
              child:  Image.asset(
                "assets/aerial/feed_default_img.png",
                fit: BoxFit.cover,
              ),
            ));

    Widget _error() {
      return Center(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.fill,
        ),
      );
    }

    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {} else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }

    Padding getListViewPostForOpportuntiy(userPostModal, index) {
      return PaddingWrap.paddingAll(
          0.0,
           Card(
              elevation: 0.0,
              color: Colors.white,
              child:  Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    // getEvent(userPostModal),
                    PaddingWrap.paddingfromLTRB(
                        11.0,
                        10.0,
                        11.0,
                        10.0,
                         Row(
                          children: <Widget>[
                             Expanded(
                              child:  InkWell(
                                child:  Center(
                                    child:  Container(
                                        width: 50.0,
                                        height: 50.0,
                                        child: ClipOval(
                                            child: FadeInImage.assetNetwork(
                                              fit: BoxFit.cover,
                                              width: double.infinity,
                                              placeholder: userPostModal
                                                  .postOwnerRoleId ==
                                                  "4"
                                                  ? "assets/profile/partner_img.png"
                                                  : 'assets/profile/user_on_user.png',
                                              image: Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getSmallImage(
                                                      userPostModal
                                                          .profilePicture),
                                            )))),
                                onTap: () {
                                  print("postedBy " +
                                      userPostModal.postOwner +
                                      "  " +
                                      userPostModal.postOwnerRoleId);
                                  onTapImageTile(userPostModal.postOwner,
                                      userPostModal.postOwnerRoleId);
                                },
                              ),
                              flex: 0,
                            ),
                             Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  8.0,
                                  0.0,
                                  15.0,
                                  0.0,
                                   Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                       InkWell(
                                        child:  Container(
                                            child: RichText(
                                              maxLines: 2,
                                              textAlign: TextAlign.start,
                                              text: TextSpan(
                                                text: userPostModal.lastName ==
                                                    null ||
                                                    userPostModal.lastName ==
                                                        "null"
                                                    ? userPostModal.firstName
                                                    : userPostModal.firstName +
                                                    " " +
                                                    userPostModal.lastName,
                                                style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 15.0,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                                children: <TextSpan>[
                                                  TextSpan(
                                                      text: ' shared ',
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                          FontWeight.normal,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                  TextSpan(
                                                    text: userPostModal
                                                        .postOwnerLastName ==
                                                        ""
                                                        ? userPostModal
                                                        .postOwnerFirstName
                                                        .trim() +
                                                        "'s"
                                                        : userPostModal
                                                        .postOwnerFirstName +
                                                        " " +
                                                        userPostModal
                                                            .postOwnerLastName
                                                            .toString()
                                                            .trim() +
                                                        "'s",
                                                    style:  TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 14.0,
                                                      fontWeight: FontWeight
                                                          .bold,
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: " post",
                                                    style:  TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 14.0,
                                                      fontWeight: FontWeight
                                                          .normal,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            )),
                                        onTap: () {
                                          onTapImageTile(userPostModal.postedBy,
                                              userPostModal.roleId);

                                          /* Navigator.of(context).push(new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                           TagDetailWidget(
                                              userPostModal.tagList)));*/
                                        },
                                      ),
                                      TextViewWrap.textView(
                                          userPostModal.dateTime,
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          12.0,
                                          FontWeight.normal),
                                    ],
                                  )),
                              flex: 4,
                            ),
                             Expanded(
                              child: userIdPref == userPostModal.postedBy
                                  ?  Container(
                                  padding:  EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 30.0),
                                  child:  InkWell(
                                    child:  Image.asset(
                                      "assets/profile/post/user_more1.png",
                                      width: 25.0,
                                      height: 25.0,
                                    ),
                                    onTap: () {
                                      //optionMenu(userPostModal, index);
                                    },
                                  ))
                                  :  Container(
                                  padding:  EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 30.0),
                                  child:  InkWell(
                                    child:  Image.asset(
                                      "assets/profile/post/user_more1.png",
                                      width: 25.0,
                                      height: 25.0,
                                    ),
                                    onTap: () {
                                      //  optionForReport(userPostModal, index);
                                    },
                                  )),
                              flex: 0,
                            )
                          ],
                        )),
                    userPostModal.shareText == "null" ||
                        userPostModal.shareText == ""
                        ?  Container(
                      height: 0.0,
                    )
                        :  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                          0.0,
                          10.0,
                          10.0,
                          0.0,
                          userPostModal.shareText == "" ||
                              userPostModal.shareText == "null" ||
                              userPostModal.shareText == "\n"
                              ?  Container(
                            height: 0.0,
                          )
                              : PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              userPostModal.isShareMore
                                  ? /*new Text(userPostModal.shareText,
                                                textAlign: TextAlign.left,
                                                maxLines: null,
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0))*/

                               Container(
                                child: Linkify(
                                  onOpen: (link) async {
                                    print("onclick +++");

                                    Navigator.push(
                                        context,
                                         MaterialPageRoute(
                                          //   builder: (context) =>  DashBoardWidget()));
                                            builder: (context) =>
                                             WebViewWidget(
                                                link.url,
                                                "spikeview")));
                                  },
                                  text: userPostModal.shareText,
                                  style:  TextStyle(
                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                      fontFamily:
                                      Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                  linkStyle:  TextStyle(
                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                      fontFamily:
                                      Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                ),
                              )
                                  :  Container(
                                child: Linkify(
                                  onOpen: (link) async {
                                    print("onclick +++");

                                    Navigator.push(
                                        context,
                                         MaterialPageRoute(
                                          //   builder: (context) =>  DashBoardWidget()));
                                            builder: (context) =>
                                             WebViewWidget(
                                                link.url,
                                                "spikeview")));
                                  },
                                  text:
                                  /*userPostModal.shareText
                                                              .length >=
                                                          105
                                                      ? userPostModal.shareText
                                                          .toString()
                                                          .substring(0, 105)
                                                      :*/
                                  userPostModal.shareText,
                                  style:  TextStyle(
                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                      fontFamily:
                                      Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                  linkStyle:  TextStyle(
                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                      fontFamily:
                                      Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                ),
                              ) /*TextViewWrap.textViewMultiLine(
                                                userPostModal.shareText,
                                                TextAlign.left,
                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                14.0,
                                                FontWeight.normal,
                                                2)*/
                          ),
                        ),
                      ],
                    ),
                    userPostModal.postOwnerDeleted
                        ? PaddingWrap.paddingfromLTRB(
                        11.0,
                        5.0,
                        11.0,
                        5.0,
                         Container(
                          width: double.infinity,
                          decoration:  BoxDecoration(
                              color:  ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                              border:  Border.all(
                                  width: 0.5,
                                  color:  ColorValues.GREY__COLOR_DIVIDER)),
                          child: PaddingWrap.paddingfromLTRB(
                              11.0,
                              17.0,
                              11.0,
                              16.0,
                               Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  TextViewWrap.textView(
                                      "You can’t see this post",
                                      TextAlign.start,
                                       ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight.bold),
                                  TextViewWrap.textView(
                                      MessageConstant.AUTHOR_DELETED_POST,
                                      TextAlign.start,
                                       ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight.normal)
                                ],
                              )),
                        ))
                        : PaddingWrap.paddingfromLTRB(
                        11.0,
                        5.0,
                        11.0,
                        5.0,
                         Container(
                            decoration:  BoxDecoration(
                                border:  Border.all(
                                    width: 0.1, color: Colors.black)),
                            child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    17.0,
                                    10.0,
                                    10.0,
                                    10.0,
                                     Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Center(
                                                    child:  Container(
                                                        width: 50.0,
                                                        height: 50.0,
                                                        child:  ClipOval(
                                                            child: FadeInImage
                                                                .assetNetwork(
                                                              fit: BoxFit.cover,
                                                              width: double
                                                                  .infinity,
                                                              placeholder: userPostModal
                                                                  .postOwnerRoleId ==
                                                                  "4"
                                                                  ? "assets/profile/partner_img.png"
                                                                  : 'assets/profile/user_on_user.png',
                                                              image: Constant
                                                                  .IMAGE_PATH_SMALL +
                                                                  ParseJson
                                                                      .getSmallImage(
                                                                      userPostModal
                                                                          .postOwnerProfilePicture),
                                                            ))))),
                                            onTap: () {
                                              onTapImageTile(
                                                  userPostModal.postOwner,
                                                  userPostModal
                                                      .postOwnerRoleId);
                                            },
                                          ),
                                          flex: 0,
                                        ),
                                         Expanded(
                                          child:
                                          PaddingWrap.paddingfromLTRB(
                                              8.0,
                                              0.0,
                                              15.0,
                                              0.0,
                                               Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .start,
                                                mainAxisAlignment:
                                                MainAxisAlignment
                                                    .start,
                                                children: <Widget>[
                                                   InkWell(
                                                    child:  Container(
                                                        child: RichText(
                                                          maxLines: 2,
                                                          textAlign:
                                                          TextAlign
                                                              .start,
                                                          text: TextSpan(
                                                            text: userPostModal
                                                                .postOwnerLastName ==
                                                                "null"
                                                                ? userPostModal
                                                                .postOwnerFirstName
                                                                : userPostModal
                                                                .postOwnerFirstName +
                                                                " " +
                                                                userPostModal
                                                                    .postOwnerLastName,
                                                            style:
                                                             TextStyle(
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontSize:
                                                              15.0,
                                                              fontWeight:
                                                              FontWeight
                                                                  .bold,
                                                            ),
                                                            children: userPostModal
                                                                .tagList
                                                                .length ==
                                                                0
                                                                ? null
                                                                : <TextSpan>[
                                                              TextSpan(
                                                                  text:
                                                                  ' with ',
                                                                  style:  TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize: 14.0,
                                                                      fontWeight: FontWeight
                                                                          .normal,
                                                                      fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                              TextSpan(
                                                                text: userPostModal
                                                                    .tagList[0]
                                                                    .name ==
                                                                    null ||
                                                                    userPostModal
                                                                        .tagList[0]
                                                                        .name ==
                                                                        "null"
                                                                    ? ""
                                                                    : userPostModal
                                                                    .tagList[0]
                                                                    .name,
                                                                style:
                                                                 TextStyle(
                                                                  color:
                                                                   ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontSize:
                                                                  14.0,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                                ),
                                                              ),
                                                              userPostModal
                                                                  .tagList
                                                                  .length >
                                                                  1
                                                                  ? TextSpan(
                                                                text: ' and ',
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize: 14.0,
                                                                    fontWeight: FontWeight
                                                                        .normal,
                                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                              )
                                                                  : TextSpan(
                                                                text: "",
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize: 14.0,
                                                                    fontWeight: FontWeight
                                                                        .normal,
                                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                              ),
                                                              userPostModal
                                                                  .tagList
                                                                  .length >
                                                                  1
                                                                  ? TextSpan(
                                                                text: (userPostModal
                                                                    .tagList
                                                                    .length - 1)
                                                                    .toString(),
                                                                style:  TextStyle(
                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontSize: 14.0,
                                                                  fontWeight: FontWeight
                                                                      .bold,
                                                                ),
                                                              )
                                                                  : TextSpan(
                                                                text: "",
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize: 14.0,
                                                                    fontWeight: FontWeight
                                                                        .normal,
                                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                              ),
                                                              userPostModal
                                                                  .tagList
                                                                  .length >
                                                                  1
                                                                  ? TextSpan(
                                                                text: " others ",
                                                                style:  TextStyle(
                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontSize: 14.0,
                                                                  fontWeight: FontWeight
                                                                      .bold,
                                                                ),
                                                              )
                                                                  : TextSpan(
                                                                text: "",
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize: 14.0,
                                                                    fontWeight: FontWeight
                                                                        .normal,
                                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                              ),
                                                            ],
                                                          ),
                                                        )),
                                                    onTap: () {
                                                      if (userPostModal
                                                          .tagList
                                                          .length >
                                                          0) {
                                                        Navigator.of(
                                                            context)
                                                            .push(
                                                             MaterialPageRoute(
                                                                builder:
                                                                    (
                                                                    BuildContext context) =>
                                                                 TagDetailWidget(
                                                                    userPostModal
                                                                        .tagList)));
                                                      } else {
                                                        print(
                                                            "clicked");
                                                        onTapImageTile(
                                                            userPostModal
                                                                .postOwner,
                                                            userPostModal
                                                                .postOwnerRoleId);
                                                      }
                                                    },
                                                  ),
                                                  TextViewWrap.textView(
                                                      userPostModal
                                                          .shareTime,
                                                      TextAlign.center,
                                                      ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight
                                                          .normal),
                                                ],
                                              )),
                                          flex: 4,
                                        )
                                      ],
                                    )),
                                 InkWell(
                                  child: Container(
                                    width: double.infinity,
                                    child: Card(
                                      elevation: 0.0,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(0.0)),
                                      color: ColorValues.WHITE,
                                      child: Column(
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              10.0,
                                              0.0,
                                              0.0,
                                              //
                                              userPostModal
                                                  .opportunityModelForFeed
                                                  .assestVideoAndImage
                                                  .length >
                                                  0
                                                  ?  SizedBox(
                                                // Pager view
                                                  height: 215.50,
                                                  child:
                                                  PageIndicatorContainer(
                                                    pageView:
                                                     PageView
                                                        .builder(
                                                      itemCount: userPostModal
                                                          .opportunityModelForFeed
                                                          .assestVideoAndImage
                                                          .length,
                                                      controller:
                                                       PageController(),
                                                      itemBuilder:
                                                          (context,
                                                          index2) {
                                                        return  Stack(
                                                          children: <
                                                              Widget>[
                                                            userPostModal
                                                                .opportunityModelForFeed
                                                                .assestVideoAndImage[index2]
                                                                .type ==
                                                                "image"
                                                                ?Container(
                                                          color: Colors.black, child:new CachedNetworkImage(
                                                              width:
                                                              double.infinity,
                                                              height:
                                                              215.50,
                                                              imageUrl:
                                                              Constant
                                                                  .IMAGE_PATH +
                                                                  userPostModal
                                                                      .opportunityModelForFeed
                                                                      .assestVideoAndImage[index2]
                                                                      .file,
                                                              fit:
                                                              BoxFit.contain,
                                                              placeholder: (
                                                                  context,
                                                                  url) =>
                                                                  _loader(
                                                                      context),
                                                              errorWidget: (
                                                                  context, url,
                                                                  error) =>
                                                                  _error(),
                                                            ))
                                                                :  InkWell(
                                                                child:
                                                                 Container(
                                                                  height:
                                                                  215.50,
                                                                  color: Colors.black,
                                                                  child:
                                                                   Center(
                                                                    child:  VideoPlayPause(
                                                                        userPostModal
                                                                            .opportunityModelForFeed
                                                                            .assestVideoAndImage[index2]
                                                                            .file,
                                                                        "",true),
                                                                  ),
                                                                )),
                                                            userPostModal
                                                                .opportunityModelForFeed
                                                                .assestVideoAndImage
                                                                .length ==
                                                                1 ||
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .assestVideoAndImage[index2]
                                                                    .type ==
                                                                    "video"
                                                                ?  Container(
                                                              height:
                                                              0.0,
                                                            )
                                                                :new InkWell(
                                                              onTap: () {


                                                            Navigator.of(context).push(new MaterialPageRoute(
                                                            builder: (BuildContext
                                                            context) =>
                                                             CommonFullViewWidget(
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .assestVideoAndImage,
                                                            MessageConstant
                                                                .HOME_OPPORTUNITY_HEDING,
                                                            index2,
                                                            MessageConstant
                                                                .COMPANY_PROFILE_HEDING)));
                                                            },
                                                            child:  Container(
                                                              height:
                                                              215.50,
                                                              width:
                                                              double.infinity,
                                                              child:
                                                               Image.asset(
                                                                "assets/newDesignIcon/navigation/layer_image.png",
                                                                fit: BoxFit
                                                                    .fill,
                                                              ),
                                                            ))
                                                          ],
                                                        );
                                                      },
                                                      onPageChanged:
                                                          (index) {},
                                                    ),
                                                    align:
                                                    IndicatorAlign
                                                        .bottom,
                                                    length: userPostModal
                                                        .opportunityModelForFeed
                                                        .assestVideoAndImage
                                                        .length,
                                                    indicatorSpace:
                                                    10.0,
                                                    indicatorColor: userPostModal
                                                        .opportunityModelForFeed
                                                        .assestVideoAndImage
                                                        .length ==
                                                        1
                                                        ? Colors
                                                        .transparent
                                                        :  Color(
                                                        0xffc4c4c4),
                                                    indicatorSelectorColor: userPostModal
                                                        .opportunityModelForFeed
                                                        .assestVideoAndImage
                                                        .length ==
                                                        1
                                                        ? Colors
                                                        .transparent
                                                        :  Color(
                                                        0XFFFFFFFF),
                                                    shape: IndicatorShape
                                                        .circle(
                                                        size: 5.0),
                                                  ))
                                                  :  Stack(
                                                  children: <Widget>[
                                                     Image.asset(
                                                      "assets/profile/default_achievement.png",
                                                      fit: BoxFit
                                                          .cover,
                                                      height: 215.50,
                                                      width: double
                                                          .infinity,
                                                    ),
                                                     Container(
                                                      height: 215.50,
                                                      color: Colors
                                                          .black54
                                                          .withOpacity(
                                                          .4),
                                                    )
                                                  ])),
                                          Container(
                                            height: 85,
                                            color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                            child: Column(
                                              children: <Widget>[
                                                Row(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: <Widget>[
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .only(
                                                          left: 13,
                                                          top: 16.0),
                                                      child: Image.asset(
                                                        "assets/newDesignIcon/patner/spike_grey.png",
                                                        height: 12.0,
                                                        width: 12.0,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .only(
                                                          left: 3.0,
                                                          top: 16.0),
                                                      child: Text(
                                                        "OPPORTUNITY",
                                                        style: TextStyle(
                                                            color: Color(
                                                                0xFF404040),
                                                            fontSize: 12),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                Row(
                                                  children: <Widget>[
                                                     Expanded(
                                                      child: Container(
                                                        child: Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .fromLTRB(
                                                              13.0,
                                                              2.0,
                                                              10.0,
                                                              10.0),
                                                          child: Text(
                                                            userPostModal
                                                                .opportunityModelForFeed
                                                                .offerId ==
                                                                "4" ||
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .offerId ==
                                                                    "5"
                                                                ? userPostModal
                                                                .opportunityModelForFeed
                                                                .serviceTitle
                                                                : userPostModal
                                                                .opportunityModelForFeed
                                                                .jobTitle,
                                                            style:  TextStyle(
                                                                color: Colors
                                                                    .black,
                                                                fontSize:
                                                                14.0,
                                                                fontFamily:
                                                                Constant.TYPE_CUSTOMBOLD,
                                                                fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                            maxLines: 2,
                                                            overflow:
                                                            TextOverflow
                                                                .ellipsis,
                                                          ),
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                )
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  onTap: () {
                                      Navigator.of(context).push(
                                         MaterialPageRoute(
                                            builder: (BuildContext
                                            context) =>
                                             OpportunityViewWidget(
                                                userPostModal
                                                    .opportunityModelForFeed,
                                                userPostModal.feedId,
                                                userIdPref,
                                                roleId,
                                                20,
                                                "")));
                                  },
                                ),
                              ],
                            ))),
                  ])));
    }

    Padding getListViewForOpportunity(userPostModal, index) {
      return PaddingWrap.paddingAll(
          0.0,
           Container(
              color: Colors.white,
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  //  getEvent(userPostModal),
                  PaddingWrap.paddingfromLTRB(
                      15.0,
                      15.0,
                      13.0,
                      10.0,
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  InkWell(
                              child:  Center(
                                child:  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    child: ClipOval(
                                        child: FadeInImage.assetNetwork(
                                          fit: BoxFit.cover,
                                          width: double.infinity,
                                          placeholder: userPostModal.roleId ==
                                              "4"
                                              ? "assets/profile/partner_img.png"
                                              : 'assets/profile/user_on_user.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getSmallImage(
                                                  userPostModal
                                                      .opportunityModelForFeed
                                                      .profilePicture),
                                        ))),
                              ),
                              onTap: () {
                                print("postedBy " +
                                    userPostModal.postedBy +
                                    "  " +
                                    userPostModal.roleId);

                                // ToastWrap.showToast(userPostModal.postedBy);
                                onTapImageTile(userPostModal.postedBy,
                                    userPostModal.roleId);
                              },
                            ),
                            flex: 0,
                          ),
                           Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                8.0,
                                0.0,
                                15.0,
                                0.0,
                                 Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                     InkWell(
                                      child:  Container(
                                          child: RichText(
                                            maxLines: 2,
                                            textAlign: TextAlign.start,
                                            text: TextSpan(
                                              text: userPostModal
                                                  .opportunityModelForFeed
                                                  .companyName,
                                              style:  TextStyle(
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontSize: 15.0,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          )),
                                      onTap: () {
                                        onTapImageTile(userPostModal.postedBy,
                                            userPostModal.roleId);
                                      },
                                    ),
                                    TextViewWrap.textView(
                                        userPostModal.dateTime,
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        12.0,
                                        FontWeight.normal),
                                  ],
                                )),
                            flex: 4,
                          ),
                        ],
                      )),

                   InkWell(
                    child: Container(
                      width: double.infinity,
                      child: Card(
                        elevation: 0.0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(0.0)),
                        color: ColorValues.WHITE,
                        child: Column(
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                0.0,
                                //
                                userPostModal.opportunityModelForFeed
                                    .assestVideoAndImage.length >
                                    0
                                    ?  SizedBox(
                                  // Pager view
                                    height: 215.50,
                                    child: PageIndicatorContainer(
                                      pageView:  PageView.builder(
                                        itemCount: userPostModal
                                            .opportunityModelForFeed
                                            .assestVideoAndImage
                                            .length,
                                        controller:  PageController(),
                                        itemBuilder: (context, index2) {
                                          return  Stack(
                                            children: <Widget>[
                                              userPostModal
                                                  .opportunityModelForFeed
                                                  .assestVideoAndImage[
                                              index2]
                                                  .type ==
                                                  "image"
                                                  ?  Container(
                                                height: 215.50,
                                                color: Colors.black,
                                                    child:  CachedNetworkImage(
                                                width:
                                                double.infinity,
                                                height: 215.50,
                                                imageUrl: Constant
                                                      .IMAGE_PATH +
                                                      userPostModal
                                                          .opportunityModelForFeed
                                                          .assestVideoAndImage[
                                                      index2]
                                                          .file,
                                                fit: BoxFit.contain,
                                                placeholder: (context,
                                                      url) =>
                                                      _loader(context),
                                                errorWidget: (context,
                                                      url, error) =>
                                                      _error(),
                                              ),
                                                  )
                                                  :  InkWell(
                                                  child:  Container(
                                                    height: 215.50,
                                                    color: Colors.black,
                                                    child:  Center(
                                                      child:  VideoPlayPause(
                                                          userPostModal
                                                              .opportunityModelForFeed
                                                              .assestVideoAndImage[
                                                          index2]
                                                              .file,
                                                          "",true),
                                                    ),
                                                  )),
                                              userPostModal
                                                  .opportunityModelForFeed
                                                  .assestVideoAndImage
                                                  .length ==
                                                  1 ||
                                                  userPostModal
                                                      .opportunityModelForFeed
                                                      .assestVideoAndImage[
                                                  index2]
                                                      .type ==
                                                      "video"
                                                  ?  Container(
                                                height: 0.0,
                                              )
                                                  :  InkWell(
                                          onTap: () {


                                          Navigator.of(context).push(new MaterialPageRoute(
                                          builder: (BuildContext
                                          context) =>
                                           CommonFullViewWidget(
                                              userPostModal
                                                  .opportunityModelForFeed
                                                  .assestVideoAndImage,
                                          MessageConstant
                                              .HOME_OPPORTUNITY_HEDING,
                                          index2,
                                          MessageConstant
                                              .COMPANY_PROFILE_HEDING)));
                                          },
                                          child:  Container(
                                                height: 215.50,
                                                width:
                                                double.infinity,
                                                child:
                                                 Image.asset(
                                                  "assets/newDesignIcon/navigation/layer_image.png",
                                                  fit: BoxFit.fill,
                                                ),
                                              ))
                                            ],
                                          );
                                        },
                                        onPageChanged: (index) {},
                                      ),
                                      align: IndicatorAlign.bottom,
                                      length: userPostModal
                                          .opportunityModelForFeed
                                          .assestVideoAndImage
                                          .length,
                                      indicatorSpace: 10.0,
                                      indicatorColor: userPostModal
                                          .opportunityModelForFeed
                                          .assestVideoAndImage
                                          .length ==
                                          1
                                          ? Colors.transparent
                                          :  Color(0xffc4c4c4),
                                      indicatorSelectorColor: userPostModal
                                          .opportunityModelForFeed
                                          .assestVideoAndImage
                                          .length ==
                                          1
                                          ? Colors.transparent
                                          :  ColorValues.WHITE,
                                      shape:
                                      IndicatorShape.circle(size: 5.0),
                                    ))
                                    :  Stack(children: <Widget>[
                                   Image.asset(
                                    "assets/profile/default_achievement.png",
                                    fit: BoxFit.cover,
                                    height: 215.50,
                                    width: double.infinity,
                                  ),
                                   Container(
                                    height: 215.50,
                                    color: Colors.black54.withOpacity(.4),
                                  )
                                ])),
                            Container(
                              height: 85,
                              color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 13, top: 16.0),
                                        child: Image.asset(
                                          "assets/newDesignIcon/patner/spike_grey.png",
                                          height: 12.0,
                                          width: 12.0,
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 3.0, top: 16.0),
                                        child: Text(
                                          "OPPORTUNITY",
                                          style: TextStyle(
                                              color: ColorValues.GREY_TEXT_COLOR,
                                              fontSize: 12),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: Container(
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                13.0, 2.0, 10.0, 10.0),
                                            child: Text(
                                              userPostModal
                                                  .opportunityModelForFeed
                                                  .offerId ==
                                                  "4" ||
                                                  userPostModal
                                                      .opportunityModelForFeed
                                                      .offerId ==
                                                      "5"
                                                  ? userPostModal
                                                  .opportunityModelForFeed
                                                  .serviceTitle
                                                  : userPostModal
                                                  .opportunityModelForFeed
                                                  .jobTitle,
                                              style:  TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 14.0,
                                                  fontFamily: Constant.TYPE_CUSTOMBOLD,
                                                  fontWeight: FontWeight.bold),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ),
                                        flex: 1,
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    onTap: () {
                           Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                           OpportunityViewWidget(
                              userPostModal.opportunityModelForFeed,
                              userPostModal.feedId,
                              userIdPref,
                              roleId,
                              20,
                              "")));
                    },
                  ),
                ],
              )));
    }

    Padding getListView(userPostModal, index) {
      return PaddingWrap.paddingAll(
          0.0,
           Container(
              color: Colors.white,
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  //  getEvent(userPostModal),
                  PaddingWrap.paddingfromLTRB(
                      15.0,
                      15.0,
                      13.0,
                      10.0,
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  InkWell(
                              child:  Center(
                                child:  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    child: ClipOval(
                                        child: FadeInImage.assetNetwork(
                                          fit: BoxFit.cover,
                                          width: double.infinity,
                                          placeholder: userPostModal.roleId ==
                                              "4"
                                              ? "assets/profile/partner_img.png"
                                              : 'assets/profile/user_on_user.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getSmallImage(
                                                  userPostModal.profilePicture),
                                        ))),
                              ),
                              onTap: () {
                                // ToastWrap.showToast(userPostModal.postedBy);
                                onTapImageTile(userPostModal.postedBy,
                                    userPostModal.roleId);
                              },
                            ),
                            flex: 0,
                          ),
                           Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                8.0,
                                0.0,
                                15.0,
                                0.0,
                                 Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child: RichText(
                                                  maxLines: 2,
                                                  textAlign: TextAlign.start,
                                                  text: TextSpan(
                                                    text: userPostModal
                                                        .lastName ==
                                                        null ||
                                                        userPostModal
                                                            .lastName ==
                                                            "null"
                                                        ? userPostModal
                                                        .firstName
                                                        : userPostModal
                                                        .firstName +
                                                        " " +
                                                        userPostModal.lastName,
                                                    style:  TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 15.0,
                                                      fontWeight: FontWeight
                                                          .bold,
                                                    ),
                                                    children: userPostModal
                                                        .tagList.length ==
                                                        0
                                                        ? userPostModal
                                                        .postedGroupName !=
                                                        null &&
                                                        userPostModal
                                                            .postedGroupName !=
                                                            "null" &&
                                                        userPostModal
                                                            .postedGroupName !=
                                                            ""
                                                        ? <TextSpan>[
                                                      TextSpan(
                                                          text: " > ",
                                                          style:
                                                           TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            18.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                          )),
                                                      TextSpan(
                                                          recognizer:
                                                           TapGestureRecognizer()
                                                            ..onTap =
                                                                () {},
                                                          text: userPostModal
                                                              .postedGroupName,
                                                          style:
                                                           TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            15.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .bold,
                                                          ))
                                                    ]
                                                        : null
                                                        : <TextSpan>[
                                                      userPostModal
                                                          .postedGroupName !=
                                                          null &&
                                                          userPostModal
                                                              .postedGroupName !=
                                                              "null" &&
                                                          userPostModal
                                                              .postedGroupName !=
                                                              ""
                                                          ? TextSpan(
                                                          text: " > ",
                                                          style:
                                                           TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            18.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                          ))
                                                          : TextSpan(
                                                        text: "",
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                            fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                      userPostModal
                                                          .postedGroupName !=
                                                          null &&
                                                          userPostModal
                                                              .postedGroupName !=
                                                              "null" &&
                                                          userPostModal
                                                              .postedGroupName !=
                                                              ""
                                                          ? TextSpan(
                                                          recognizer:
                                                           TapGestureRecognizer()
                                                            ..onTap =
                                                                () {},
                                                          text: userPostModal
                                                              .postedGroupName,
                                                          style:
                                                           TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            15.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .bold,
                                                          ))
                                                          : TextSpan(
                                                        text: "",
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                            fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                      TextSpan(
                                                          text: ' with ',
                                                          style:  TextStyle(
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                              FontWeight
                                                                  .normal,
                                                              fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR)),
                                                      TextSpan(
                                                        text: userPostModal
                                                            .tagList[
                                                        0]
                                                            .name ==
                                                            null ||
                                                            userPostModal
                                                                .tagList[
                                                            0]
                                                                .name ==
                                                                "null"
                                                            ? ""
                                                            : userPostModal
                                                            .tagList[0]
                                                            .name,
                                                        style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                          FontWeight.bold,
                                                        ),
                                                      ),
                                                      userPostModal.tagList
                                                          .length >
                                                          1
                                                          ? TextSpan(
                                                        text: ' and ',
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                            fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                      )
                                                          : TextSpan(
                                                        text: "",
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                            fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                      userPostModal.tagList
                                                          .length >
                                                          1
                                                          ? TextSpan(
                                                        text: (userPostModal
                                                            .tagList
                                                            .length -
                                                            1)
                                                            .toString(),
                                                        style:
                                                         TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize:
                                                          14.0,
                                                          fontWeight:
                                                          FontWeight
                                                              .bold,
                                                        ),
                                                      )
                                                          : TextSpan(
                                                        text: "",
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                            fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                      userPostModal.tagList
                                                          .length >
                                                          1
                                                          ? TextSpan(
                                                        text:
                                                        " others ",
                                                        style:
                                                         TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize:
                                                          14.0,
                                                          fontWeight:
                                                          FontWeight
                                                              .bold,
                                                        ),
                                                      )
                                                          : TextSpan(
                                                        text: "",
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize:
                                                            14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                            fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                    ],
                                                  ),
                                                )),
                                            onTap: () {
                                              if (userPostModal.tagList.length >
                                                  0) {
                                                Navigator.of(context).push(
                                                     MaterialPageRoute(
                                                        builder: (BuildContext
                                                        context) =>
                                                         TagDetailWidget(
                                                            userPostModal
                                                                .tagList)));
                                              } else {
                                                onTapImageTile(
                                                    userPostModal.postedBy,
                                                    userPostModal.roleId);
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ),
                                    TextViewWrap.textView(
                                        userPostModal.dateTime,
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        12.0,
                                        FontWeight.normal),
                                  ],
                                )),
                            flex: 4,
                          ),
                        ],
                      )),

                  userPostModal.postdata == null ||
                      userPostModal.postdata.text == null ||
                      userPostModal.postdata.text == "null"
                      ?  Container(
                    height: 0.0,
                  )
                      : PaddingWrap.paddingfromLTRB(
                      15.0,
                      0.0,
                      15.0,
                      0.0,
                       Container(
                          color: Colors.transparent,
                          child:  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                userPostModal.postdata.text == "" ||
                                    userPostModal.postdata.text ==
                                        "null" ||
                                    userPostModal.postdata.text == "\n"
                                    ?  Container(
                                  height: 1.0,
                                )
                                    : userPostModal.postdata.imageList.length ==
                                    0 &&
                                    (userPostModal.postdata.media ==
                                        null ||
                                        userPostModal
                                            .postdata.media ==
                                            "" ||
                                        userPostModal
                                            .postdata.media ==
                                            "null") &&
                                    (userPostModal
                                        .postdata.metaUrl !=
                                        "" &&
                                        userPostModal.postdata
                                            .metaImage !=
                                            "")
                                    ? exp
                                    .allMatches(
                                    userPostModal
                                        .postdata
                                        .text)
                                    .length ==
                                    1 &&
                                    userPostModal.postdata.text
                                        .toString()
                                        .replaceAll(exp, '')
                                        .length ==
                                        0
                                    ?  Container(
                                  height: 0.0,
                                )
                                    : PaddingWrap.paddingfromLTRB(
                                    4.0,
                                    10.0,
                                    13.0,
                                    0.0,
                                     Container(
                                      child: Linkify(
                                        onOpen: (link) async {
                                          print("onclick +++" +
                                              link.url
                                                  .toLowerCase());

                                          Navigator.push(
                                              context,
                                               MaterialPageRoute(
                                                //   builder: (context) =>  DashBoardWidget()));
                                                  builder: (context) =>
                                                   WebViewWidget(
                                                      link.url,
                                                      "spikeview")));
                                        },
                                        text: exp
                                            .allMatches(
                                            userPostModal
                                                .postdata
                                                .text)
                                            .length >
                                            1
                                            ? userPostModal
                                            .postdata.text
                                            : userPostModal
                                            .postdata.text
                                            .toString()
                                            .replaceAll(
                                            exp, ''),
                                        style:  TextStyle(
                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0),
                                        linkStyle:  TextStyle(
                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0),
                                      ),
                                    ))
                                    :  Container(
                                  child: Linkify(
                                    onOpen: (link) async {
                                      print("onclick +++" +
                                          link.url.toLowerCase());

                                      Navigator.push(
                                          context,
                                           MaterialPageRoute(
                                            //   builder: (context) =>  DashBoardWidget()));
                                              builder: (context) =>
                                               WebViewWidget(
                                                  link.url,
                                                  "spikeview")));
                                    },
                                    text: userPostModal
                                        .postdata.text,
                                    style:  TextStyle(
                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                        fontFamily:
                                        Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                    linkStyle:  TextStyle(
                                        color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontFamily:
                                        Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  ),
                                ),
                              ),
                            ],
                          ))),

                  userPostModal.postdata.imageList.length == 0
                      ?  Container(
                    height: 0.0,
                  )
                      : PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      0.0,
                       Container(
                          height: 215.50,
                          child:  SizedBox(
                            // Pager view
                              height: 215.50,
                              child: PageIndicatorContainer(
                                pageView:  PageView.builder(
                                  itemCount: userPostModal
                                      .postdata.imageList.length,
                                  controller:  PageController(),
                                  itemBuilder: (context, index2) {
                                    return  InkWell(
                                      child:  Stack(children: <Widget>[
                                         Container(
                                            height: 215.50,
                                            color: Colors.black,
                                            child:  CachedNetworkImage(
                                              width: double.infinity,
                                              height: 215.50,
                                              imageUrl: Constant
                                                  .IMAGE_PATH_SMALL +
                                                  ParseJson.getMediumImage(
                                                      userPostModal.postdata
                                                          .imageList[
                                                      index2]),
                                              fit: BoxFit.contain,
                                              placeholder: (context, url) =>
                                                  _loader(context),
                                              errorWidget:
                                                  (context, url, error) =>
                                                  _error(),
                                            )),
                                        userPostModal.postdata.imageList
                                            .length ==
                                            1
                                            ?  Container(
                                          height: 0.0,
                                        )
                                            :  Container(
                                          height: 215.50,
                                          width: double.infinity,
                                          child:  Image.asset(
                                            "assets/newDesignIcon/navigation/layer_image.png",
                                            fit: BoxFit.fill,
                                          ),
                                        )
                                      ]),
                                      onTap: () {
                                        Navigator.of(context).push(new MaterialPageRoute(
                                            builder: (BuildContext
                                            context) =>
                                             CommonFullViewWidget(
                                                userPostModal.postdata
                                                    .imageList,
                                                MessageConstant
                                                    .HOME_FEED,
                                                index2,
                                                MessageConstant
                                                    .COMPANY_PROFILE_HEDING)));
                                      },
                                    );
                                  },
                                  onPageChanged: (index) {},
                                ),
                                align: IndicatorAlign.bottom,
                                length:
                                userPostModal.postdata.imageList.length,
                                indicatorSpace: 10.0,
                                indicatorColor: userPostModal
                                    .postdata.imageList.length ==
                                    1
                                    ? Colors.transparent
                                    :  Color(0xffc4c4c4),
                                indicatorSelectorColor: userPostModal
                                    .postdata.imageList.length ==
                                    1
                                    ? Colors.transparent
                                    :  ColorValues.WHITE,
                                shape: IndicatorShape.circle(size: 5.0),
                              )))),

                  userPostModal.postdata.imageList.length > 0 ||
                      userPostModal.postdata.media == null ||
                      userPostModal.postdata.media == "" ||
                      userPostModal.postdata.media == "null"
                      ?  Container(
                    height: 0.0,
                  )
                      : PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      0.0,
                       InkWell(
                        child:  Container(
                          color: Colors.black,
                            height: 215.50,
                            width: double.infinity,
                            child:  Center(
                                child:  Center(
                                  child:  Center(
                                    child:  VideoPlayPause(
                                        userPostModal.postdata.media,
                                        userPostModal.feedId,true),
                                  ),
                                ))),
                        onTap: () {},
                      )),

                  userPostModal.postdata.imageList.length == 0 &&
                      (userPostModal.postdata.media == null ||
                          userPostModal.postdata.media == "" ||
                          userPostModal.postdata.media == "null")
                      ? userPostModal.postdata == null ||
                      userPostModal.postdata.text == null ||
                      userPostModal.postdata.text == "null"
                      ?  Container(
                    height: 0.0,
                  )
                      : userPostModal.postdata.metaUrl != ""
                      ? Container(
                      margin: EdgeInsets.symmetric(vertical: 4.0),
//                                  child: userPostModal.webLinkModel.imageUrl ==
//                                          ""
//                                      ?new WhatsAppLinkPreview().build(
//                                          getLinkUrl(
//                                              userPostModal.postdata.text),
//                                          userPostModal)
//                                      :

                      child:  WhatsAppView(
                        imageUrl: userPostModal.postdata.metaImage,
                        feedId: userPostModal.feedId,
                        title: userPostModal.postdata.metaTitle,
                        url: userPostModal.postdata.metaUrl,
                        metaSource:
                        userPostModal.postdata.metaSource,
                        metaHeight:
                        userPostModal.postdata.metaHeight,
                        metaWidth: userPostModal.postdata.metaWidth,
                        description:
                        userPostModal.postdata.metaDescription,
                      ))
                      :  Container(
                    height: 0.0,
                  )
                      :  Container(
                    height: 0.0,
                  ),


                ],
              )));
    }

    Padding getListViewPost(userPostModal, index) {
      return PaddingWrap.paddingAll(
          0.0,
           Card(
              elevation: 0.0,
              color: Colors.white,
              child:  Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    // getEvent(userPostModal),
                    PaddingWrap.paddingfromLTRB(
                        11.0,
                        10.0,
                        11.0,
                        10.0,
                         Row(
                          children: <Widget>[
                             Expanded(
                              child:  InkWell(
                                child:  Center(
                                    child:  Container(
                                        width: 50.0,
                                        height: 50.0,
                                        child: ClipOval(
                                            child: FadeInImage.assetNetwork(
                                              fit: BoxFit.cover,
                                              width: double.infinity,
                                              placeholder: userPostModal
                                                  .roleId ==
                                                  "4"
                                                  ? "assets/profile/partner_img.png"
                                                  : 'assets/profile/user_on_user.png',
                                              image: Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getSmallImage(
                                                      userPostModal
                                                          .profilePicture),
                                            )))),
                                onTap: () {
                                  onTapImageTile(userPostModal.postedBy,
                                      userPostModal.roleId);
                                },
                              ),
                              flex: 0,
                            ),
                             Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  8.0,
                                  0.0,
                                  15.0,
                                  0.0,
                                   Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                       InkWell(
                                        child:  Container(
                                            child: RichText(
                                              maxLines: 2,
                                              textAlign: TextAlign.start,
                                              text: TextSpan(
                                                text: userPostModal.lastName ==
                                                    null ||
                                                    userPostModal.lastName ==
                                                        "null"
                                                    ? userPostModal.firstName
                                                    : userPostModal.firstName +
                                                    " " +
                                                    userPostModal.lastName,
                                                style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 15.0,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                                children: <TextSpan>[
                                                  TextSpan(
                                                      text: ' shared ',
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                          FontWeight.normal,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                  TextSpan(
                                                    text: userPostModal
                                                        .postedGroupName !=
                                                        null &&
                                                        userPostModal
                                                            .postedGroupName !=
                                                            "null" &&
                                                        userPostModal
                                                            .postedGroupName !=
                                                            ""
                                                        ? userPostModal
                                                        .postedGroupName
                                                        : userPostModal
                                                        .postOwnerLastName ==
                                                        ""
                                                        ? userPostModal
                                                        .postOwnerFirstName
                                                        .trim() +
                                                        "'s"
                                                        : userPostModal
                                                        .postOwnerFirstName +
                                                        " " +
                                                        userPostModal
                                                            .postOwnerLastName
                                                            .toString()
                                                            .trim() +
                                                        "'s",
                                                    recognizer:
                                                     TapGestureRecognizer()
                                                      ..onTap = () {},
                                                    style:  TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 14.0,
                                                      fontWeight: FontWeight
                                                          .bold,
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: " post",
                                                    style:  TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 14.0,
                                                      fontWeight: FontWeight
                                                          .normal,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            )),
                                        onTap: () {
                                          onTapImageTile(userPostModal.postedBy,
                                              userPostModal.roleId);

                                          /* Navigator.of(context).push(new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                           TagDetailWidget(
                                              userPostModal.tagList)));*/
                                        },
                                      ),
                                      TextViewWrap.textView(
                                          userPostModal.dateTime,
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          12.0,
                                          FontWeight.normal),
                                    ],
                                  )),
                              flex: 4,
                            ),
                          ],
                        )),
                    userPostModal.shareText == "null" ||
                        userPostModal.shareText == ""
                        ?  Container(
                      height: 0.0,
                    )
                        :  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                          0.0,
                          10.0,
                          10.0,
                          0.0,
                          userPostModal.shareText == "" ||
                              userPostModal.shareText == "null" ||
                              userPostModal.shareText == "\n"
                              ?  Container(
                            height: 0.0,
                          )
                              : PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              userPostModal.isShareMore
                                  ? /*new Text(userPostModal.shareText,
                                                textAlign: TextAlign.left,
                                                maxLines: null,
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0))*/

                               Container(
                                child: Linkify(
                                  onOpen: (link) async {
                                    print("onclick +++");

                                    Navigator.push(
                                        context,
                                         MaterialPageRoute(
                                          //   builder: (context) =>  DashBoardWidget()));
                                            builder: (context) =>
                                             WebViewWidget(
                                                link.url,
                                                "spikeview")));
                                  },
                                  text: userPostModal.shareText,
                                  style:  TextStyle(
                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                      fontFamily:
                                      Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                  linkStyle:  TextStyle(
                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                      fontFamily:
                                      Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                ),
                              )
                                  :  Container(
                                child: Linkify(
                                  onOpen: (link) async {
                                    Navigator.push(
                                        context,
                                         MaterialPageRoute(
                                          //   builder: (context) =>  DashBoardWidget()));
                                            builder: (context) =>
                                             WebViewWidget(
                                                link.url,
                                                "spikeview")));
                                  },
                                  text:
                                  /*userPostModal.shareText
                                                              .length >=
                                                          105
                                                      ? userPostModal.shareText
                                                          .toString()
                                                          .substring(0, 105)
                                                      : */
                                  userPostModal.shareText,
                                  style:  TextStyle(
                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                      fontFamily:
                                      Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                  linkStyle:  TextStyle(
                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                      fontFamily:
                                      Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                ),
                              ) /*TextViewWrap.textViewMultiLine(
                                                userPostModal.shareText,
                                                TextAlign.left,
                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                14.0,
                                                FontWeight.normal,
                                                2)*/
                          ),
                        ),
                      ],
                    ),
                    userPostModal.postOwnerDeleted
                        ? PaddingWrap.paddingfromLTRB(
                        11.0,
                        5.0,
                        11.0,
                        5.0,
                         Container(
                          width: double.infinity,
                          decoration:  BoxDecoration(
                              color:  ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                              border:  Border.all(
                                  width: 0.5,
                                  color:  ColorValues.GREY__COLOR_DIVIDER)),
                          child: PaddingWrap.paddingfromLTRB(
                              11.0,
                              17.0,
                              11.0,
                              16.0,
                               Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  TextViewWrap.textView(
                                      "You can’t see this post",
                                      TextAlign.start,
                                       ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight.bold),
                                  TextViewWrap.textView(
                                      MessageConstant.AUTHOR_DELETED_POST,
                                      TextAlign.start,
                                       ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight.normal)
                                ],
                              )),
                        ))
                        : PaddingWrap.paddingfromLTRB(
                        11.0,
                        5.0,
                        11.0,
                        5.0,
                         Container(
                            decoration:  BoxDecoration(
                                border:  Border.all(
                                    width: 0.1, color: Colors.black)),
                            child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    17.0,
                                    10.0,
                                    10.0,
                                    10.0,
                                     Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Center(
                                                    child:  Container(
                                                        width: 50.0,
                                                        height: 50.0,
                                                        child:  ClipOval(
                                                            child: FadeInImage
                                                                .assetNetwork(
                                                              fit: BoxFit.cover,
                                                              width: double
                                                                  .infinity,
                                                              placeholder: userPostModal
                                                                  .postOwnerRoleId ==
                                                                  "4"
                                                                  ? "assets/profile/partner_img.png"
                                                                  : 'assets/profile/user_on_user.png',
                                                              image: Constant
                                                                  .IMAGE_PATH_SMALL +
                                                                  ParseJson
                                                                      .getSmallImage(
                                                                      userPostModal
                                                                          .postOwnerProfilePicture),
                                                            ))))),
                                            onTap: () {
                                              onTapImageTile(
                                                  userPostModal.postOwner,
                                                  userPostModal
                                                      .postOwnerRoleId);
                                            },
                                          ),
                                          flex: 0,
                                        ),
                                         Expanded(
                                          child:
                                          PaddingWrap.paddingfromLTRB(
                                              8.0,
                                              0.0,
                                              15.0,
                                              0.0,
                                               Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .start,
                                                mainAxisAlignment:
                                                MainAxisAlignment
                                                    .start,
                                                children: <Widget>[
                                                  Row(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: <Widget>[
                                                       Expanded(
                                                        child:
                                                         InkWell(
                                                          child:
                                                           Container(
                                                              child:
                                                              RichText(
                                                                maxLines: 2,
                                                                textAlign:
                                                                TextAlign
                                                                    .start,
                                                                text:
                                                                TextSpan(
                                                                  text: userPostModal
                                                                      .postOwnerLastName ==
                                                                      "null"
                                                                      ? userPostModal
                                                                      .postOwnerFirstName
                                                                      : userPostModal
                                                                      .postOwnerFirstName +
                                                                      " " +
                                                                      userPostModal
                                                                          .postOwnerLastName,
                                                                  style:
                                                                   TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                    15.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                  ),
                                                                  children: userPostModal
                                                                      .tagList
                                                                      .length ==
                                                                      0
                                                                      ? null
                                                                      : <
                                                                      TextSpan>[
                                                                    TextSpan(
                                                                        text: ' with ',
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize: 14.0,
                                                                            fontWeight: FontWeight
                                                                                .normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                    TextSpan(
                                                                      text: userPostModal
                                                                          .tagList[0]
                                                                          .name ==
                                                                          null ||
                                                                          userPostModal
                                                                              .tagList[0]
                                                                              .name ==
                                                                              "null"
                                                                          ? ""
                                                                          : userPostModal
                                                                          .tagList[0]
                                                                          .name,
                                                                      style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize: 14.0,
                                                                        fontWeight: FontWeight
                                                                            .bold,
                                                                      ),
                                                                    ),
                                                                    userPostModal
                                                                        .tagList
                                                                        .length >
                                                                        1
                                                                        ? TextSpan(
                                                                      text: ' and ',
                                                                      style:  TextStyle(
                                                                          color:
                                                                              ColorValues
                                                                                  .HEADING_COLOR_EDUCATION,
                                                                          fontSize: 14.0,
                                                                          fontWeight: FontWeight
                                                                              .normal,
                                                                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                    )
                                                                        : TextSpan(
                                                                      text: "",
                                                                      style:  TextStyle(
                                                                          color:
                                                                              ColorValues
                                                                                  .HEADING_COLOR_EDUCATION,
                                                                          fontSize: 14.0,
                                                                          fontWeight: FontWeight
                                                                              .normal,
                                                                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                    ),
                                                                    userPostModal
                                                                        .tagList
                                                                        .length >
                                                                        1
                                                                        ? TextSpan(
                                                                      text: (userPostModal
                                                                          .tagList
                                                                          .length -
                                                                          1)
                                                                          .toString(),
                                                                      style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize: 14.0,
                                                                        fontWeight: FontWeight
                                                                            .bold,
                                                                      ),
                                                                    )
                                                                        : TextSpan(
                                                                      text: "",
                                                                      style:  TextStyle(
                                                                          color:
                                                                              ColorValues
                                                                                  .HEADING_COLOR_EDUCATION,
                                                                          fontSize: 14.0,
                                                                          fontWeight: FontWeight
                                                                              .normal,
                                                                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                    ),
                                                                    userPostModal
                                                                        .tagList
                                                                        .length >
                                                                        1
                                                                        ? TextSpan(
                                                                      text: " others ",
                                                                      style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize: 14.0,
                                                                        fontWeight: FontWeight
                                                                            .bold,
                                                                      ),
                                                                    )
                                                                        : TextSpan(
                                                                      text: "",
                                                                      style:  TextStyle(
                                                                          color:
                                                                              ColorValues
                                                                                  .HEADING_COLOR_EDUCATION,
                                                                          fontSize: 14.0,
                                                                          fontWeight: FontWeight
                                                                              .normal,
                                                                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                    ),
                                                                  ],
                                                                ),
                                                              )),
                                                          onTap: () {
                                                            if (userPostModal
                                                                .tagList
                                                                .length >
                                                                0) {
                                                              Navigator.of(
                                                                  context)
                                                                  .push(
                                                                   MaterialPageRoute(
                                                                      builder: (
                                                                          BuildContext context) =>
                                                                       TagDetailWidget(
                                                                          userPostModal
                                                                              .tagList)));
                                                            } else {
                                                              print(
                                                                  "clicked");
                                                              onTapImageTile(
                                                                  userPostModal
                                                                      .postOwner,
                                                                  userPostModal
                                                                      .postOwnerRoleId);
                                                            }
                                                          },
                                                        ),
                                                        flex: 0,
                                                      ),
                                                    ],
                                                  ),
                                                  TextViewWrap.textView(
                                                      userPostModal
                                                          .shareTime,
                                                      TextAlign.center,
                                                      ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight
                                                          .normal),
                                                ],
                                              )),
                                          flex: 4,
                                        )
                                      ],
                                    )),
                                userPostModal.postdata == null ||
                                    userPostModal.postdata.text ==
                                        null ||
                                    userPostModal.postdata.text ==
                                        "null"
                                    ?  Container(
                                  height: 0.0,
                                )
                                    : PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    10.0,
                                    0.0,
                                     Container(
                                        color: Colors.transparent,
                                        child:  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              0.0,
                                              0.0,
                                              0.0,
                                              userPostModal.postdata.text ==
                                                  "" ||
                                                  userPostModal
                                                      .postdata
                                                      .text ==
                                                      "null" ||
                                                  userPostModal
                                                      .postdata
                                                      .text ==
                                                      "\n"
                                                  ?  Container(
                                                height: 1.0,
                                              )
                                                  : userPostModal
                                                  .postdata
                                                  .imageList
                                                  .length ==
                                                  0 &&
                                                  (userPostModal.postdata
                                                      .media ==
                                                      null ||
                                                      userPostModal.postdata
                                                          .media ==
                                                          "" ||
                                                      userPostModal.postdata
                                                          .media ==
                                                          "null") &&
                                                  (userPostModal
                                                      .postdata
                                                      .metaUrl !=
                                                      "" &&
                                                      userPostModal
                                                          .postdata
                                                          .metaImage !=
                                                          "")
                                                  ? exp
                                                  .allMatches(
                                                  userPostModal.postdata.text)
                                                  .length ==
                                                  1 &&
                                                  userPostModal
                                                      .postdata
                                                      .text
                                                      .toString()
                                                      .replaceAll(exp, '')
                                                      .length ==
                                                      0
                                                  ?  Container(
                                                height:
                                                0.0,
                                              )
                                                  : PaddingWrap.paddingfromLTRB(
                                                  4.0,
                                                  10.0,
                                                  13.0,
                                                  0.0,
                                                   Container(
                                                    child:
                                                    Linkify(
                                                      onOpen:
                                                          (link) async {
                                                        Navigator.push(
                                                            context,
                                                             MaterialPageRoute(
                                                              //   builder: (context) =>  DashBoardWidget()));
                                                                builder: (
                                                                    context) =>
                                                                 WebViewWidget(
                                                                    link.url,
                                                                    "spikeview")));
                                                      },
                                                      text: exp
                                                          .allMatches(
                                                          userPostModal.postdata
                                                              .text)
                                                          .length > 1
                                                          ? userPostModal
                                                          .postdata.text
                                                          : userPostModal
                                                          .postdata.text
                                                          .toString()
                                                          .replaceAll(exp, ''),
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                          fontSize: 14.0),
                                                      linkStyle:  TextStyle(
                                                          color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                          fontSize: 14.0),
                                                    ),
                                                  ))
                                                  :  Container(
                                                child:
                                                Linkify(
                                                  onOpen:
                                                      (link) async {
                                                    print("onclick +++" +
                                                        link.url
                                                            .toLowerCase());

                                                    Navigator.push(
                                                        context,
                                                         MaterialPageRoute(
                                                          //   builder: (context) =>  DashBoardWidget()));
                                                            builder: (
                                                                context) =>
                                                             WebViewWidget(
                                                                link.url,
                                                                "spikeview")));
                                                  },
                                                  text: userPostModal
                                                      .postdata
                                                      .text,
                                                  style:  TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize:
                                                      14.0),
                                                  linkStyle:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize:
                                                      14.0),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ))),
                                userPostModal.postdata.imageList.length == 0
                                    ?  Container(
                                  height: 0.0,
                                )
                                    : PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    10.0,
                                    0.0,
                                     Container(
                                        height: 180.0,
                                        child:  SizedBox(
                                          // Pager view
                                            height: 180.0,
                                            child:
                                            PageIndicatorContainer(
                                              pageView:
                                               PageView.builder(
                                                itemCount: userPostModal
                                                    .postdata
                                                    .imageList
                                                    .length,
                                                controller:
                                                 PageController(),
                                                itemBuilder:
                                                    (context, index2) {
                                                  return  InkWell(
                                                    child:  Stack(
                                                        children: <
                                                            Widget>[
                                                           Container(
                                                              color: Colors.black,
                                                              height:
                                                              180.0,
                                                              child:
                                                              /*FadeInImage
                                                                          .assetNetwork(
                                                                        fit: BoxFit
                                                                            .fill,
                                                                        width: double
                                                                            .infinity,
                                                                        height:
                                                                            180.0,
                                                                        placeholder:
                                                                            'assets/aerial/feed_default_img.png',
                                                                        image: Constant.IMAGE_PATH_SMALL +
                                                                            ParseJson.getMediumImage(userPostModal.postdata.imageList[index2]),
                                                                      )*/

                                                               CachedNetworkImage(
                                                                width: double
                                                                    .infinity,
                                                                height:
                                                                180.0,
                                                                imageUrl:
                                                                Constant
                                                                    .IMAGE_PATH_SMALL +
                                                                    ParseJson
                                                                        .getMediumImage(
                                                                        userPostModal
                                                                            .postdata
                                                                            .imageList[index2]),
                                                                fit: BoxFit
                                                                    .contain,
                                                                placeholder:
                                                                    (context,
                                                                    url) =>
                                                                    _loader(
                                                                        context),
                                                                errorWidget: (
                                                                    context,
                                                                    url,
                                                                    error) =>
                                                                    _error(),
                                                              )),
                                                          userPostModal
                                                              .postdata
                                                              .imageList
                                                              .length ==
                                                              1
                                                              ?  Container(
                                                            height:
                                                            0.0,
                                                          )
                                                              :  Container(
                                                            height:
                                                            180.0,
                                                            width:
                                                            double.infinity,
                                                            child:
                                                             Image.asset(
                                                              "assets/newDesignIcon/navigation/layer_image.png",
                                                              fit:
                                                              BoxFit.fill,
                                                            ),
                                                          )
                                                        ]),
                                                    onTap: () {
                                                      Navigator.of(context).push(new MaterialPageRoute(
                                                          builder: (BuildContext
                                                          context) =>
                                                           CommonFullViewWidget(
                                                              userPostModal.postdata
                                                                  .imageList,
                                                              MessageConstant
                                                                  .HOME_FEED,
                                                              index2,
                                                              MessageConstant
                                                                  .COMPANY_PROFILE_HEDING)));
                                                    },
                                                  );
                                                },
                                                onPageChanged:
                                                    (index) {},
                                              ),
                                              align:
                                              IndicatorAlign.bottom,
                                              length: userPostModal
                                                  .postdata
                                                  .imageList
                                                  .length,
                                              indicatorSpace: 10.0,
                                              indicatorColor:
                                              userPostModal
                                                  .postdata
                                                  .imageList
                                                  .length ==
                                                  1
                                                  ? Colors
                                                  .transparent
                                                  :  Color(
                                                  0xffc4c4c4),
                                              indicatorSelectorColor:
                                              userPostModal
                                                  .postdata
                                                  .imageList
                                                  .length ==
                                                  1
                                                  ? Colors
                                                  .transparent
                                                  :  Color(
                                                  0XFFFFFFFF),
                                              shape:
                                              IndicatorShape.circle(
                                                  size: 5.0),
                                            )))),
                                userPostModal.postdata.imageList.length >
                                    0 ||
                                    userPostModal.postdata.media ==
                                        null ||
                                    userPostModal.postdata.media ==
                                        "" ||
                                    userPostModal.postdata.media ==
                                        "null"
                                    ?  Container(
                                  height: 1.0,
                                )
                                    : PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    10.0,
                                    0.0,
                                     InkWell(
                                      child:  Container(
                                        height: 180.0,
                                        color: Colors.black,
                                        width: double.infinity,
                                        child:  Center(
                                          child:  Center(
                                            child:  VideoPlayPause(
                                                userPostModal
                                                    .postdata.media,
                                                userPostModal.feedId,true),
                                          ),
                                        ),
                                      ),
                                      onTap: () {},
                                    )),
                                userPostModal.postdata.imageList.length ==
                                    0 &&
                                    (userPostModal.postdata.media ==
                                        null ||
                                        userPostModal.postdata.media ==
                                            "" ||
                                        userPostModal.postdata.media ==
                                            "null")
                                    ? userPostModal.postdata == null ||
                                    userPostModal.postdata.text ==
                                        null ||
                                    userPostModal.postdata.text ==
                                        "null"
                                    ?  Container(
                                  height: 0.0,
                                )
                                //: getLinkUrl(userPostModal.postdata.text) !=
                                    : userPostModal.postdata.metaUrl !=
                                    ""
                                        ""
                                    ? Container(
                                    margin:
                                    EdgeInsets.symmetric(
                                        vertical: 4.0),
//                                  child: userPostModal.webLinkModel.imageUrl ==
//                                          ""
//                                      ?new WhatsAppLinkPreview().build(
//                                          getLinkUrl(
//                                              userPostModal.postdata.text),
//                                          userPostModal)
//                                      :

                                    child:  WhatsAppView(
                                      imageUrl: userPostModal
                                          .postdata.metaImage,
                                      feedId:
                                      userPostModal.feedId,
                                      title: userPostModal
                                          .postdata.metaTitle,
                                      url: userPostModal
                                          .postdata.metaUrl,
                                      metaHeight: userPostModal
                                          .postdata.metaHeight,
                                      metaWidth: userPostModal
                                          .postdata.metaWidth,
                                      metaSource: userPostModal
                                          .postdata.metaSource,
                                      description: userPostModal
                                          .postdata
                                          .metaDescription,
                                    ))
                                    :  Container(
                                  height: 0.0,
                                )
                                    :  Container(
                                  height: 0.0,
                                ),
                              ],
                            ))),

                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Divider(
                          height: 1.0, color: ColorValues.DARK_GREY),
                    ),
                  ])));
    }


    Container getSelectedWidgets() {


      return  Container(
        //color: Colors.redAccent,
        child: MediaQuery.removePadding(
          context: context,
          removeTop: true,
          removeBottom: true,
          child: ListView(
            physics: const NeverScrollableScrollPhysics(),
            primary: true,
            shrinkWrap: true,
            children: <Widget>[
              Wrap(
                spacing: 5.0,
                runSpacing: 0.0,
                children: List<Widget>.generate(
                    userPostList[0].reasonList.length,
                    // place the length of the array here
                        (int index) {
                      //int h = _items[index].name.toString().length % 36;
                      //print('Height h:::: $h');
                      return InputChip(
                        shape: RoundedRectangleBorder(borderRadius:
                        BorderRadius.all(Radius.circular(0))),


                        label: Text(
                          '${userPostList[0].reasonList[index]}',
                          overflow: TextOverflow.clip,
                          style: TextStyle(
                            fontSize: 14.0,fontFamily:
                          Constant.TYPE_CUSTOMREGULAR,
                          ),
                        ),
                        // softWrap: true,maxLines: 100,
                        //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        backgroundColor:    Color(0xffC1E3FC),

                        onSelected: (bool value) {},


                        labelStyle: AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,16.0,FontType.Regular),/*TextStyle(
                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 16,fontFamily:
                        Constant.TYPE_CUSTOMREGULAR,
                        ),*/
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5.0, vertical: 3.0),
                      );
                    }).toList(),
              ),
            ],
          ),
        ),
      );


    }

    return  customAppbar(
        context,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 20.0, right: 20, top: 24, bottom: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    BaseText(
                      text: 'Feed report',
                      textColor:
                      ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily:
                      AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      textAlign: TextAlign.start,
                      maxLines: 3,
                    ),


                  ],
                ),
              ),
              flex: 0,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Column(
                        children:    List.generate(
                            userPostList.length, (int position) {
                          if (userPostList[position].isOpportunity) {
                            if (userPostList[position].postOwner == "null") {
                              return getListViewForOpportunity(
                                  userPostList[position], position);
                            } else {
                              return getListViewPostForOpportuntiy(
                                  userPostList[position], position);
                            }
                          } else {
                            if (userPostList[position].postOwner == "null")
                              return getListView(
                                  userPostList[position], position);
                            else
                              return SizedBox();
                          }
                        }),
                      ),

                      Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  InkWell(
                                    child: TextViewWrap.textView(
                                        userPostList[0].likeList.length == 0
                                            ? "0 Like":
                                        userPostList[0].likeList.length == 1?
                                        userPostList[0].likeList.length
                                            .toString() +
                                            " Like":
                                        userPostList[0].likeList.length
                                            .toString() +
                                            " Likes",
                                        TextAlign.end,
                                        ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal),
                                    onTap: () {
                                    },
                                  ))
                              ,
                              flex: 0,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 6.0),
                              child:  Text(
                                ".",
                                style: TextStyle(
                                    fontSize: 16.0,
                                    color: ColorValues.GREY_TEXT_COLOR),
                              ),
                            ),
                            InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                0.0,
                                0.0,
                                TextViewWrap.textView(
                                    userPostList[0].commentList.length == 0
                                        ? "0 Comment"
                                        :userPostList[0].commentList.length == 1
                                        ? "1 Comment":
                                    userPostList[0].commentList.length
                                        .toString() +
                                        " Comments",
                                    TextAlign.left,
                                    ColorValues.GREY_TEXT_COLOR,
                                    14.0,
                                    FontWeight.normal),
                              ),
                              onTap: () {

                              },
                            )
                          ],
                        ),
                      ),

                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Divider(height: 1.0, color: ColorValues.DARK_GREY),
                      ),
                      userPostList[0].reasonList != null &&
                          userPostList[0].reasonList.length > 0
                          ?
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap
                              .paddingfromLTRB(
                              20.0,
                              5.0,
                              20.0,
                              8.0,  Text(
                            "Reason Category",
                            textAlign: TextAlign.start,
                            style:  TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                                fontFamily:Constant.TYPE_CUSTOMREGULAR),
                          )),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  20.0, 0, 20, 0),child: getSelectedWidgets()),


                          PaddingWrap.paddingfromLTRB(
                              20.0,
                              15.0,
                              20.0,
                              0.0,
                              Container(
                                  child: Container(
                                      width: double.infinity,
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          border: Border.all(
                                              color: ColorValues.BORDER_COLOR, width: 0.5)),
                                      child: Container(
                                          color: Colors.white,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: <Widget>[

                                              PaddingWrap.paddingfromLTRB(
                                                  13.0,
                                                  13.0,
                                                  13.0,
                                                  13.0,
                                                  Text(
                                                      userPostList[0].reasonText,
                                                      overflow: TextOverflow.ellipsis,
                                                      maxLines: null,
                                                      style: TextStyle(
                                                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                          color: ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 14.0))),

                                            ],
                                          ))))),
                        ],
                      )   :     Container(
                        height: 0.0,
                      )
                    ],
                  ),
                ),
              ),
              flex: 1,
            ),
            Expanded(
              child:  userPostList.length != 0 &&userPostList[0].isReported=="true"?      Container(
                color: Colors.white,
                child: PaddingWrap
                    .paddingfromLTRB(
                    0.0,
                    10.0,
                    0.0,
                    10.0,   InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      20.0,
                      20.0,
                      20.0,
                      20.0,
                      Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color:
                            AppConstants.colorStyle.lightBlue,
                            border: Border.all(
                                color: AppConstants
                                    .colorStyle.lightBlue),
                            borderRadius:
                            BorderRadius.circular(10),
                          ),
                          child: Align(
                              alignment: Alignment.center,
                              // Align however you like (i.e .centerRight, centerLeft)
                              child: Text(
                                "Unblock",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.WHITE,
                                  fontFamily: AppConstants
                                      .stringConstant.latoMedium,
                                  fontSize: 18.0,
                                ),
                              )))),
                  onTap: () async {
                    apiCallingForUpdate();
                  },
                )),
              ):SizedBox(),
              flex: 0,
            )
          ],
        ), () {
      Navigator.pop(context);
    }, isShowIcon: false,isShowExplanation: false);



    return  WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:  Scaffold(
            backgroundColor: Colors.white,
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      onBack();
                    },
                  )
                ],
              ),
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Feed Report",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              actions: <Widget>[
                 Container(
                  width: 35.0,
                ),
              ],
              backgroundColor: Colors.white,
              elevation: 1.0,
            ),bottomNavigationBar:

        userPostList.length != 0 &&userPostList[0].isReported=="true"?      Container(
          color: Colors.white,
          child: PaddingWrap
              .paddingfromLTRB(
              0.0,
              10.0,
              0.0,
              10.0,   InkWell(
            child: PaddingWrap.paddingfromLTRB(
                20.0,
                20.0,
                20.0,
                20.0,
                Container(
                    height: 44,
                    decoration: BoxDecoration(
                      color:
                      AppConstants.colorStyle.lightBlue,
                      border: Border.all(
                          color: AppConstants
                              .colorStyle.lightBlue),
                      borderRadius:
                      BorderRadius.circular(10),
                    ),
                    child: Align(
                        alignment: Alignment.center,
                        // Align however you like (i.e .centerRight, centerLeft)
                        child: Text(
                          "Unblock",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: ColorValues.WHITE,
                            fontFamily: AppConstants
                                .stringConstant.latoMedium,
                            fontSize: 18.0,
                          ),
                        )))),
            onTap: () async {
              apiCallingForUpdate();
            },
          )),
        ):SizedBox(),
            body:userPostList.length>0?ListView(
              children: <Widget>[
                Column(
                  children:    List.generate(
                      userPostList.length, (int position) {
                    if (userPostList[position].isOpportunity) {
                      if (userPostList[position].postOwner == "null") {
                        return getListViewForOpportunity(
                            userPostList[position], position);
                      } else {
                        return getListViewPostForOpportuntiy(
                            userPostList[position], position);
                      }
                    } else {
                      if (userPostList[position].postOwner == "null")
                        return getListView(
                            userPostList[position], position);
                      else
                        return SizedBox();
                    }
                  }),
                ),

                Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            InkWell(
                              child: TextViewWrap.textView(
                                  userPostList[0].likeList.length == 0
                                      ? "0 Like":
                                  userPostList[0].likeList.length == 1?
                                  userPostList[0].likeList.length
                                      .toString() +
                                      " Like":
                                  userPostList[0].likeList.length
                                      .toString() +
                                      " Likes",
                                  TextAlign.end,
                                  ColorValues.GREY_TEXT_COLOR,
                                  14.0,
                                  FontWeight.normal),
                              onTap: () {
                              },
                            ))
                        ,
                        flex: 0,
                      ),
                      Padding(
                          padding: const EdgeInsets.only(bottom: 6.0),
                          child:  Text(
                            ".",
                            style: TextStyle(
                                fontSize: 16.0,
                                color: ColorValues.GREY_TEXT_COLOR),
                          ),
                        ),
                      InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                          13.0,
                          0.0,
                          0.0,
                          0.0,
                          TextViewWrap.textView(
                              userPostList[0].commentList.length == 0
                                  ? "0 Comment"
                                  :userPostList[0].commentList.length == 1
                                  ? "1 Comment":
                                  userPostList[0].commentList.length
                                      .toString() +
                                  " Comments",
                              TextAlign.left,
                              ColorValues.GREY_TEXT_COLOR,
                              14.0,
                              FontWeight.normal),
                        ),
                        onTap: () {

                        },
                      )
                    ],
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Divider(height: 1.0, color: ColorValues.DARK_GREY),
                ),

                userPostList[0].reasonList != null &&
                    userPostList[0].reasonList.length > 0
                    ?
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap
                        .paddingfromLTRB(
                        13.0,
                        5.0,
                        13.0,
                        8.0,  Text(
                      "Reason Category",
                      textAlign: TextAlign.start,
                      style:  TextStyle(
                          color: Colors.black,
                          fontSize: 16.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    )),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(
                            13.0, 0, 13, 0),child: getSelectedWidgets()),


                    PaddingWrap.paddingfromLTRB(
                        13.0,
                        15.0,
                        13.0,
                        0.0,
                        Container(
                            child: Container(
                                width: double.infinity,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(
                                        color: ColorValues.BORDER_COLOR, width: 0.5)),
                                child: Container(
                                    color: Colors.white,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[

                                        PaddingWrap.paddingfromLTRB(
                                            13.0,
                                            13.0,
                                            13.0,
                                            13.0,
                                            Text(
                                                userPostList[0].reasonText,
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: null,
                                                style: TextStyle(
                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                    color: ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontSize: 14.0))),

                                      ],
                                    ))))),
                  ],
                )   :     Container(
                  height: 0.0,
                )
              ],
            ):SizedBox()





    ));
  }

  Widget getText(String s, int color) {
    return Padding(
      padding: const EdgeInsets.only(left: 0.0),
      child:  Text(s,
          style: TextStyle(
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: Color(color),
              fontSize: 14.0)),
    );
  }
}
