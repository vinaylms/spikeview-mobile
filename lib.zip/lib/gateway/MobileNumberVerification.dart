// Updated COde

import 'dart:async';

import 'package:flutter/gestures.dart';
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';
import 'dart:convert';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/gateway/parent_add_more.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/new_onboarding/onboarding_add_education.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';

import 'Login_Widget.dart';

class MobileNumberVerification extends StatefulWidget {
  static String tag = 'login-page';
  String sasToken = '';
  String number = '';
  String countryCode = '';
  ProfileInfoModal profileInfoModal;
  final LoginRole loginRole;
  MobileNumberVerification(
      @required this.loginRole,
      this.profileInfoModal, this.sasToken, this.number, this.countryCode);

  @override
  MobileNumberVerificationState createState() =>
      MobileNumberVerificationState();
}

final formKey = GlobalKey<FormState>();

class MobileNumberVerificationState extends State<MobileNumberVerification> {
  Color borderColor = Colors.amber;
  SharedPreferences prefs;
  String roleId, userId, email;

  void _checkValidation() {
    final form = formKey.currentState;
    setState(() {});
    form.save();
    if (form.validate()) {
      forgotpassworApiCalling();
    } else {
      setState(() => {});
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userId = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    email = prefs.getString(UserPreference.EMAIL);
  }

  int diffrenceInDob = 14;
  DateTime date;

  @override
  void initState() {
    date = DateTime.fromMillisecondsSinceEpoch(
        int.tryParse(widget.profileInfoModal.dob));

    try {
      diffrenceInDob = Util.currentAge(date, 13);
    } catch (e) {}
    getSharedPreferences();
    _timerStart();
    super.initState();
  }

  onBack() {
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginPage(null)));
  }

  showSucessMsg(msg, context, push) {
    Timer _timer = Timer(const Duration(milliseconds: 1000), () async {
      Navigator.pop(context);
      if (push) {
        int endYar = DateTime.now().year + 10;
        Navigator.of(context).popUntil((route) => route.isFirst);
        if (diffrenceInDob < 13 &&
            widget.profileInfoModal.parentList.length == 0) {
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => ParentAddData(
                  widget.profileInfoModal, 'mobileVerification')));
        } else {
          String result =
              await Navigator.of(context).push(new MaterialPageRoute(
                  builder: (BuildContext context) => AddEducationWeight(
                        profileInfoModal: widget.profileInfoModal,
                        startYear: date.year,
                        endYear: endYar,
                        screenName: "onBaording",
                      )));
          if (result == "push") {}
        }
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            ));
  }

  forgotpassworApiCalling() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data

        var map = {
          "userId": userId,
          "verificationType": "phoneOTP",
          "otp": _code
        };
        Response response = await dio.post(Constant.ENDPOINT_OTP_VERIFICATION,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() {});
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {

            if(widget.loginRole==LoginRole.parent){
              Navigator.of(context).popUntil((route) => route.isFirst);
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      DashBoardWidgetParent(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                      ),
                ),
              );
            }else {
              int endYar = DateTime
                  .now()
                  .year + 10;
              Navigator.of(context).popUntil((route) => route.isFirst);
              if (diffrenceInDob < 13 &&
                  widget.profileInfoModal.parentList.length == 0) {
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                        ParentAddData(
                            widget.profileInfoModal, 'mobileVerification')));
              } else {
                String result =
                await Navigator.of(context).push(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                        AddEducationWeight(
                          profileInfoModal: widget.profileInfoModal,
                          startYear: date.year,
                          endYear: endYar,
                          screenName: "onBaording",
                        )));
                if (result == "push") {}
              }
            }
          //  showSucessMsg(message, context, true);
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          setState(() {});
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      setState(() => {});
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  resendOtpApi() async {
    if (_second == 0) {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        try {
          CustomProgressLoader.showLoader(context);
          var dio = Dio();
          dio.onHttpClientCreate = (HttpClient client) {
            client.badCertificateCallback =
                (X509Certificate cert, String host, int port) {
              return true;
            };
          };
          dio.options.baseUrl = Constant.BASE_URL;
          dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
          dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
          dio.options.headers = {'user-agent': 'dio'};
          dio.options.headers = {'Accept': 'application/json'};
          dio.options.headers = {'Content-Type': 'application/json'};
          // Prepare Data

          var map = {
            "userId": userId,
            "type": "phoneOTP",
            "mobileNo": widget.number,
            "countryCode": "+" + widget.countryCode,
            "actionType": "resend",
          };
          Response response = await dio.post(Constant.ENDPOINT_OTP_RESEND,
              data: json.encode(map));
          CustomProgressLoader.cancelLoader(context);
          setState(() {});
          print(response.toString());
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String message = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              _timerStart();
              showSucessMsg(message, context, false);
            } else {
              ToastWrap.showToastLongNew(message, context);
            }
          } else {
            //  CustomProgressLoader.cancelLoader(context);
            setState(() => {});
            // If that call was not successful, throw an error.
            throw Exception('Something went wrong!!');
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
          CustomProgressLoader.cancelLoader(context);
          print(e);
          ToastWrap.showToast(e.toString(), context);
        }
      } else {
        setState(() {});
        // CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    }
  }

  Future apiCallingUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {"userId": userId, "stage": "1"};
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            print("update data+++ apiCallingUpdate");
            if (status == "Success") {
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  TextEditingController textController = TextEditingController();

  bool _onEditing = true;
  String _code = '';
  int _second = 120;
  Timer _timer;

  void _timerStart() {
    if (_timer?.isActive ?? false) {
      _timer?.cancel();
    }
    _second = 120;
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_second > 0) {
        _second--;
        setState(() {});
      } else {
        _timer?.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _printDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "$twoDigitMinutes:$twoDigitSeconds minutes";
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: customAppbar(
          context,
          Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20.0, top: 25.0, bottom: 20),
                      child: RichText(
                        maxLines: 2,
                        textAlign: TextAlign.start,
                        text: TextSpan(
                          text: 'Phone number',
                          style: AppConstants
                              .txtStyle.heading400LatoRegularDarkBlue
                              .copyWith(
                              fontSize: 28,
                              fontWeight: FontWeight.w700),
                          children: [
                            TextSpan(
                                text: ' verification',
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {},
                                style: AppConstants.txtStyle
                                    .heading40018LatoRegularDarkBlue
                                    .copyWith(
                                    fontSize: 28,
                                    fontWeight: FontWeight.w700)),
                          ],
                        ),
                      )),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(height: 10),
                          Center(
                            child: SizedBox(
                              width: 230,
                              child: PinCodeTextField(
                                length: 4,
                                obscureText: true,
                                animationType: AnimationType.fade,
                                keyboardType: TextInputType.number,
                                pinTheme: PinTheme(
                                    shape: PinCodeFieldShape.underline,
                                    activeColor: Color(0xffE5EBF0),
                                    inactiveColor: Color(0xffE5EBF0),
                                    disabledColor: Color(0xffE5EBF0),
                                    activeFillColor: Color(0xffE5EBF0),
                                    selectedFillColor: Color(0xffE5EBF0),
                                    inactiveFillColor: Color(0xffE5EBF0),
                                    fieldWidth: 49),
                                textStyle: TextStyle(
                                    fontSize: 16.0,
                                    color: AppConstants.colorStyle.darkBlue),
                                animationDuration: Duration(milliseconds: 300),
                                backgroundColor: Colors.transparent,
                                enableActiveFill: false,
                                controller: textController,
                                onCompleted: (v) {
                                  setState(() {
                                    _code = v;
                                  });
                                },
                                onChanged: (value) {
                                  setState(() {
                                    _code = value;
                                  });
                                },
                                beforeTextPaste: (text) {
                                  print("Allowing to paste $text");
                                  //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                                  //but you can show anything you want here, like your pop up saying wrong paste format or etc
                                  return true;
                                },
                                appContext: context,
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.fromLTRB(20.0, 10, 20.0, 0.0),
                            child: InkWell(
                              child: Center(
                                child: BaseText(
                                  text:
                                      'Enter verification code sent to ******${widget.number.substring(widget.number.length - 4)} this phone number',
                                  textColor: AppConstants.colorStyle.lightPurple,
                                  textAlign: TextAlign.center,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                              onTap: () {},
                            ),
                          ),
                          Container(
                              child: Padding(
                                  padding: EdgeInsets.only(
                                      left: 20.0, top: 50.0, right: 20.0),
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          height: 44.0,
                                          width: double.infinity,
                                          child: FlatButton(
                                            onPressed: () async {
                                              _checkValidation();
                                            },
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(10)),
                                            color:
                                                AppConstants.colorStyle.lightBlue,
                                            child: Row(
                                              // Replace with a Row for horizontal icon + text
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: <Widget>[
                                                Text('Proceed',
                                                    style: AppConstants.txtStyle
                                                        .heading18600LatoRegularWhite),
                                              ],
                                            ),
                                          )),
                                      _code.length == 4
                                          ? SizedBox(
                                              height: 0,
                                            )
                                          : Container(
                                              height: 44.0,
                                              width: double.infinity,
                                              color:
                                                  Colors.white.withOpacity(0.75),
                                            )
                                    ],
                                  )))
                        ],
                      ),
                    ),
                  ),
                ],
              )),
          () {
            Navigator.pop(context);
          },
          bottomNavigation: Container(
            margin: const EdgeInsets.fromLTRB(20, 0, 20, 50),
            color: Colors.white,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Visibility(
                    visible: _second != 0,
                    child: BaseText(
                      text: _printDuration(Duration(seconds: _second)),
                      textAlign: TextAlign.center,
                      textColor: const Color(0xff27275A),
                      fontWeight: FontWeight.w400,
                      fontSize: 18,
                      fontFamily: Constant.latoRegular,
                    )),
                const SizedBox(height: 14),
                RichText(
                  maxLines: 1,
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    text: 'Didn’t receive verification code? ',
                    style: AppConstants.txtStyle.heading400LatoRegularDarkBlue,
                    children: [
                      TextSpan(
                          text: 'Resend',
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              resendOtpApi();
                            },
                          style: AppConstants
                              .txtStyle.heading400LatoRegularLightBlue
                              .copyWith(
                                  color: _second != 0
                                      ? const Color(0x304684EB)
                                      : AppConstants.colorStyle.lightBlue))
                    ],
                  ),
                )
              ],
            ),
          ),
          isShowExplanation: false,
            signupType:  widget.loginRole == LoginRole.parent
                ? 'parent'
                : widget.loginRole == LoginRole.partner
                ? 'partner'
                : ''
        ));
  }
}
