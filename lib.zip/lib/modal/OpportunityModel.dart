import 'dart:io';

import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/CategoryFormModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/designation_model_param.dart';
import 'package:spike_view_project/modal/patner/qualification_model_param.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/modal/patner/subject_model_param.dart';
import 'package:spike_view_project/modal/patner/user_image_model_param.dart';

class OpportunityModelForFeed {
  String opportunityId,
      userId,
      roleId,
      jobTitle,
      jobType,
      jobLocation,
      project,
      duration,
      status,
      fromDate,
      toDate,
      groupId,
      targetAudience,
      title,
      gender,
      companyId,
      offerId,
      serviceTitle,
      serviceDesc,
      expiresOn,
      coverPicture,
      companyName,
      profilePicture,
      actionType,
      url,
      groupIdAction,
      callingNumber,
      formId,
      linkUrlPosition,
      studentJoinId,
      name,declineReason,partnerStatus,schoolCode;
  String opportunityCretedUserName, opportunityCretedUserImage;
  List<Address> locationList;
  List<IntrestModel> interestTypeList;
  List<AgeModel> ageList;
  List<Assest> googleLinkList;

  bool groupIsPublic = true;

  List<Assest> assestList;
  List<Assest> assestVideoAndImage;
  List<Assest> videoList;
  List<Assest> docList;
  List<Assest> mediaList;

  String fees;
  String description;
  String bio;
  String menteeSupport;
  String advisorSupportOffered;
  String projectAreas;
  String userImagepath, category, supportedOffer,timeZone;

  String qualification;
  List<QualificationModelParam> qualificationModelParam;
  List<MainCategory> designationModelParam;
  List<SubCategory> subjectModelParam;
  List<ScheduleModelParam> scheduleModelParam;
  List<UserImageModelParam> userImageModelParam;

  List<String> selectedDesignationCareerOption;
  List<String> selectedDesignationOtherOption;
  List<String> selectedSubjectOtherOption;


  String toMapStringForDesignation() {
    String data = "";
    if (this.designationModelParam != null) {
      /*data = this.designationModelParam.map((v) {
        print('v::: ${v.name}');
        return v.toMapString();
      }).toString();*/
      for(int i=0; i< this.designationModelParam.length; i++){
        if(i != 0)
          data = data + " | " +this.designationModelParam[i].name;
        else
          data = this.designationModelParam[i].name;
      }
    }else{
      return "";
    }
 if(data==null){
   return "";
 }
    return data;
  }
  String toMapStringForDesignationOther() {
    String data = "";
    if (this.selectedDesignationOtherOption != null) {
      //data = this.selectedDesignationOtherOption.map((v) => v).toString();
      for(int i=0; i< this.selectedDesignationOtherOption.length; i++){
        if(i != 0)
          data = data + " | " +this.selectedDesignationOtherOption[i];
        else
          data = this.selectedDesignationOtherOption[i];
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }
  String toMapStringForDesignationCareer() {
    String data = "";
    if (this.selectedDesignationCareerOption != null) {
      //data = this.selectedDesignationCareerOption.map((v) => v).toString();
      for(int i=0; i< this.selectedDesignationCareerOption.length; i++){
        if(i != 0)
          data = data + " | " +this.selectedDesignationCareerOption[i];
        else
          data = this.selectedDesignationCareerOption[i];
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }

  String toMapStringForQualification() {
    String data = "";
    if (this.qualificationModelParam != null) {
      //data = this.qualificationModelParam.map((v) => v.toMapString()).toString();
      for(int i=0; i< this.qualificationModelParam.length; i++){
        if(i != 0)
          data = data + " | " +this.qualificationModelParam[i].name;
        else
          data = this.qualificationModelParam[i].name;
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }

  String toMapStringSubject() {
    String data = "";
    if (this.subjectModelParam != null) {
      //data = this.subjectModelParam.map((v) => v.toMapString()).toString();
      print('Subject length::: ${this.subjectModelParam.length}');
      for(int i=0; i< this.subjectModelParam.length; i++){
        if(i != 0)
          data = data + " | " +this.subjectModelParam[i].name;
        else
          data = this.subjectModelParam[i].name;
        print('Subject i::: ${i}');
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }
  String toMapStringSubjectOther() {
    String data = "";
    if (this.selectedSubjectOtherOption != null) {
      //data = this.selectedSubjectOtherOption.map((v) => v).toString();
      for(int i=0; i< this.selectedSubjectOtherOption.length; i++){
        if(i != 0)
          data = data + " | " +this.selectedSubjectOtherOption[i];
        else
          data = this.selectedSubjectOtherOption[i];
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }

  String toMapStringQualification() {
    String data = "";
    if (this.qualificationModelParam != null) {
      //data = this.qualificationModelParam.map((v) => v.toMapString()).toString();
      for(int i=0; i< this.qualificationModelParam.length; i++){
        if(i != 0)
          data = data + " | " +this.qualificationModelParam[i].name;
        else
          data = this.qualificationModelParam[i].name;
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }

  OpportunityModelForFeed(
      this.opportunityId,
      this.userId,
      this.roleId,
      this.jobTitle,
      this.jobType,
      this.jobLocation,
      this.project,
      this.duration,
      this.status,
      this.fromDate,
      this.toDate,
      this.groupId,
      this.targetAudience,
      this.title,
      this.gender,
      this.companyId,
      this.offerId,
      this.serviceTitle,
      this.serviceDesc,
      this.expiresOn,
      this.coverPicture,
      this.companyName,
      this.profilePicture,
      this.locationList,
      this.interestTypeList,
      this.ageList,
      this.assestList,
      this.assestVideoAndImage,
      this.videoList,
      this.docList,
      this.mediaList,
      this.googleLinkList,
      this.actionType,
      this.url,
      this.groupIdAction,
      this.callingNumber,
      this.formId,
      this.linkUrlPosition,
      this.groupIsPublic,
      this.studentJoinId,
      this.fees,
      this.description,
      this.bio,
      this.menteeSupport,
      this.advisorSupportOffered,
      this.projectAreas,
      this.userImageModelParam,
      this.qualification,
      this.qualificationModelParam,
      this.designationModelParam,
      this.subjectModelParam,
      this.scheduleModelParam,
      this.category,
      this.name,
      this.supportedOffer,
      this.opportunityCretedUserName,
      this.opportunityCretedUserImage,this.selectedSubjectOtherOption,this.selectedDesignationOtherOption,this.selectedDesignationCareerOption,this.timeZone,this.declineReason,this.partnerStatus,this.schoolCode);
}
