import 'package:spike_view_project/modal/patner/offer_model.dart';

class ResumeModel {
  String displayName;
  String uploadType;
  String resumeUrl;
  String creationTime;

  ResumeModel({this.displayName, this.uploadType, this.resumeUrl, this.creationTime});

  ResumeModel.fromJson(Map<String, dynamic> json) {
    displayName = json['displayName'].toString();
    uploadType = json['uploadType'].toString();
    resumeUrl = json['resumeUrl'].toString();
    creationTime = json['creationTime'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['displayName'] = this.displayName;
    data['uploadType'] = this.uploadType;
    data['resumeUrl'] = this.resumeUrl;
    data['creationTime'] = this.creationTime;
    return data;
  }
}
