class CallToActionModel {
  int groupId;
  int id;

  CallToActionModel({
    this.groupId,
    this.id,
  });

  static Map<String, dynamic> toMap(CallToActionModel callToActionObject) {
    Map<String, dynamic> callToActionMap = Map();
    callToActionMap['id'] = callToActionObject.id;
    callToActionMap['groupId'] = callToActionObject.groupId;

    return callToActionMap;
  }

  static List<Map<String, dynamic>> mapList(List<CallToActionModel> list) {
    List<Map<String, dynamic>> listOfCallToAction = list
        .map((asset) => {
              "id": asset.id,
              "groupId": asset.groupId,
            })
        .toList();
    return listOfCallToAction;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> assetMap = Map<String, dynamic>();
    assetMap['id'] = this.id;
    assetMap['groupId'] = this.groupId;

    return assetMap;
  }

  CallToActionModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    groupId = json['groupId'];
  }

  static List<CallToActionModel> mapToList(Map<int, CallToActionModel> assets) {
    List<CallToActionModel> listOfAsset = [];

    assets.forEach((key, model) {
      listOfAsset.add(model);
    });

    return listOfAsset;
  }
}
