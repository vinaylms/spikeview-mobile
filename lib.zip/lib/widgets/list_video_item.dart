import 'dart:io';

import 'package:flutter/material.dart';
import 'package:spike_view_project/widgets/remove_button.dart';

class ListVideoItem extends StatelessWidget {
  final String videoUrl;
  final File thumbnailFile;
  final VoidCallback onPlayTap;
  final VoidCallback onRemoveTap;
  final double height;

  const ListVideoItem({
    @required this.videoUrl,
    this.thumbnailFile,
    this.height,
    @required this.onRemoveTap,
    @required this.onPlayTap,
  });

  @override
  Widget build(BuildContext context) {
    double width = 140;
    double height = this.height ??  75;
    return Container(
      height: height,
      width: width,
      margin: EdgeInsets.only(right: 10),
      child: Stack(
        children: [
          Row(
            children: [
              Image.asset(
                "assets/generateScript/wall_frame_video.png",
                height: height,
                width: 20,
                fit: BoxFit.fitHeight,
              ),
              Container(
                color: Colors.black,
                child: thumbnailFile != null
                        ? Image.file(
                            thumbnailFile,
                            height: height,
                            width: 100,
                          )
                        : Image.asset(
                            "assets/newIcon/add_img.png",
                            height: height,
                            width: 100,
                          ),
              ),
              Image.asset(
                "assets/generateScript/wall_frame_video.png",
                height: height,
                width: 20,
                fit: BoxFit.fitHeight,
              ),
            ],
          ),
          Positioned(
            left: 20,
            right: 20,
            top: 0,
            bottom: 0,
            child: Container(
              color: Colors.black12,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    child: Image.asset(
                      'assets/experience/ic_play.png',
                      width: 24,
                      height: 26,
                    ),
                    onTap: onPlayTap,
                  ),
                  RemoveButton(onTap: onRemoveTap),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
