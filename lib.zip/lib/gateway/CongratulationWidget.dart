import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/group/AddTagGroupWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class CongratulationWidget extends StatefulWidget {
  String userId;

  CongratulationWidget(this.userId);

  @override
  CongratulationWidgetState createState() {
    return  CongratulationWidgetState();
  }
}

class CongratulationWidgetState extends State<CongratulationWidget> {
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  String userIdPref;

  getSharedPrefrence() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
  }

  @override
  void initState() {
    getSharedPrefrence();
    super.initState();
  }

  Future apiForUpdateRole(roleID) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "userId": int.parse(widget.userId),
          "roleId": int.parse(roleID),
        };

        print("map+++" + map.toString());

        response = await  ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_UPDATE_ROLE, map);

        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            prefs.setString(UserPreference.ROLE_ID, roleID.toString());
            Constant.ROLE_ID = roleID;
            if (status == "Success") {
              prefs.setString(UserPreference.IS_PARTNER_ROLE, "true");
              Navigator.of(context).popUntil((route) => route.isFirst);
              Navigator.of(context).pushReplacement(new MaterialPageRoute(
                  builder: (BuildContext context) => DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE))));

              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return  WillPopScope(
        onWillPop: () {
          SystemChannels.platform.invokeMethod('SystemNavigator.pop');
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.singin_bg_color,
            body:  Stack(
              children: <Widget>[
                 Positioned(
                    left: 0.0,
                    right: 0.0,
                    top: 0.0,
                    bottom: 0.0,
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                         Image.asset(
                          "assets/newDesignIcon/sucess.png",
                          height: 84.0,
                          width: 84.0,
                        ),
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            25.0,
                            0.0,
                            0.0,
                            TextViewWrap.textView(
                                "Congratulations!!!",
                                TextAlign.center,
                                 ColorValues.HEADING_COLOR_EDUCATION,
                                28.0,
                                FontWeight.normal)),
                        PaddingWrap.paddingfromLTRB(
                            16.0,
                            0.0,
                            16.0,
                            5.0,
                            RichText(
                              maxLines: 10,
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                text:
                                    'You are now a partner on spikeview. Next create some opportunities for your target audience and start earning money!',
                                style:  TextStyle(
                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                    fontSize: 14.0,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              ),
                            )),
                        PaddingWrap.paddingfromLTRB(
                            16.0,
                            15.0,
                            16.0,
                            5.0,
                             InkWell(
                              child: TextViewWrap.textView(
                                  "Let’s Go",
                                  TextAlign.center,
                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  16.0,
                                  FontWeight.normal),
                              onTap: () {
                                apiForUpdateRole("4");
                                // Join Now button click
                              },
                            ))
                      ],
                    )),
              ],
            )));
  }

// Updated View for POST TYPE

}
