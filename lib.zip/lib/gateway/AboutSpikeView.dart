import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class  AboutSpikeView extends StatefulWidget {
  @override
  SpikeViewState createState() =>  SpikeViewState();
}

class SpikeViewState extends State<AboutSpikeView> {
  var style = TextStyle(
       fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD,fontWeight: FontWeight.bold);
  var styleblack =
  TextStyle(color: Colors.black, fontSize: 14, fontFamily: Constant.TYPE_CUSTOMREGULAR);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return   Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(243.0),
        child: AppBar(
          automaticallyImplyLeading: true,
          backgroundColor: Colors.transparent,
          titleSpacing: 2.0,
          elevation: 0.0,
          brightness: Brightness.light,
          flexibleSpace: Image(
            image: AssetImage('assets/newDesignIcon/appbackground.png',),
            height: 280,
            fit: BoxFit.cover,
          ),
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios, size: 20, color: Colors.white),
            onPressed: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              Navigator.of(context).pop();
            },
          ),
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 10.0, 50.0, 0.0),
                  child: Image.asset("assets/logo_white.png",height: 36,width: 136,)),
             ],
          ),
        ),
      ),
      backgroundColor: ColorValues.singin_bg_color,
      body: SingleChildScrollView(
        child: Container(
          child: Padding(
            padding: const EdgeInsets.only(left: 14.0, top: 32.0,right: 15.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 0.0),
                  child: Text("OWN YOUR NARRATIVE",
                    style: style,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: Text("spikeview enables Parents and Children to build out compelling views into a shareable, customizable, online profile.",
                    style: styleblack,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: Text('A '+'"LinkedIn for Kids"' +', spikeview addresses the challenge of organizing the fragmented data in your increasingly complex and competitive world, securely manages your ever-shifting connections and activities, and provides a venue to relevant businesses to reach you while allowing you full control over your data and privacy.',
                   style: styleblack,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
     );
  }
}
