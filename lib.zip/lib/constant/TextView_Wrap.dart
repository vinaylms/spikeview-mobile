import 'package:flutter/painting.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Constant.dart';
class TextViewWrap {

 static Text textView(text,txtAlign,txtColour,txtSize,txtFontWeight){
   String fontFamily=Constant.TYPE_CUSTOMREGULAR;
   if(txtFontWeight==FontWeight.normal){
     fontFamily=Constant.TYPE_CUSTOMREGULAR;
   }else{
     fontFamily=Constant.TYPE_CUSTOMBOLD;
   }
   return  Text(
     text,overflow: TextOverflow.ellipsis,maxLines: 1,
     textAlign: txtAlign,

     style:  TextStyle(
         color: txtColour,
         fontSize: txtSize,

         fontFamily: fontFamily),
   );
  }

 static Text textViewMultiLinelato(text,txtAlign,txtColour,txtSize,txtFontWeight,line){
   String fontFamily=Constant.latoRegular;
   if(txtFontWeight==FontWeight.normal){
     fontFamily=Constant.latoRegular;
   }else{
     fontFamily=Constant.latoSemibold;
   }
   return  Text(
     text,overflow: TextOverflow.ellipsis,maxLines:line,
     textAlign: txtAlign,
     style:  TextStyle(
         color: txtColour,
         fontSize: txtSize,
         fontFamily: fontFamily),
   );
 }

 static Text textViewSingleLine(text,txtAlign,txtColour,txtSize,txtFontWeight){
   String fontFamily=Constant.TYPE_CUSTOMREGULAR;
   if(txtFontWeight==FontWeight.normal){
     fontFamily=Constant.TYPE_CUSTOMREGULAR;
   }else{
     fontFamily=Constant.TYPE_CUSTOMBOLD;
   }
   return  Text(
     text,overflow: TextOverflow.ellipsis,maxLines:1 ,
     textAlign: txtAlign,
     style:  TextStyle(
         color: txtColour,
         fontSize: txtSize,
         fontFamily: fontFamily),
   );
 }

 static Text textViewMultiLine(text,txtAlign,txtColour,txtSize,txtFontWeight,line){
   String fontFamily=Constant.TYPE_CUSTOMREGULAR;
   if(txtFontWeight==FontWeight.normal){
     fontFamily=Constant.TYPE_CUSTOMREGULAR;
   }else{
     fontFamily=Constant.TYPE_CUSTOMBOLD;
   }
   return  Text(
     text,overflow: TextOverflow.ellipsis,maxLines:line,
     textAlign: txtAlign,
     style:  TextStyle(
         color: txtColour,
         fontSize: txtSize,
         fontFamily: fontFamily),
   );
 }

 static Text textViewMultiLineWeight(text,txtAlign,txtColour,txtSize,txtFontWeight,line){
   String fontFamily=Constant.TYPE_CUSTOMREGULAR;
   if(txtFontWeight==FontWeight.normal){
     fontFamily=Constant.TYPE_CUSTOMREGULAR;
   }else{
     fontFamily=Constant.TYPE_CUSTOMBOLD;
   }
   return  Text(
     text,overflow: TextOverflow.ellipsis,maxLines:line,
     textAlign: txtAlign,
     style:  TextStyle(
         color: txtColour,
         fontSize: txtSize,fontWeight: FontWeight.w600,
         fontFamily: fontFamily),
   );
 }

 static Text textViewMultiLineItalic(text,txtAlign,txtColour,txtSize,txtFontWeight,line){

   return  Text(
     text,overflow: TextOverflow.ellipsis,maxLines:line,
     textAlign: txtAlign,
     style:  TextStyle(
         color: txtColour,
         fontSize: txtSize,
         fontFamily:Constant.TYPE_CUSTOMITALIC, fontWeight: txtFontWeight,
         fontStyle: FontStyle.italic),
   );
 }

 static Text textViewMultiLineShadow(text,txtAlign,txtColour,txtSize,txtFontWeight,line){
   String fontFamily=Constant.TYPE_CUSTOMREGULAR;
   if(txtFontWeight==FontWeight.normal){
     fontFamily=Constant.TYPE_CUSTOMREGULAR;
   }else{
     fontFamily=Constant.TYPE_CUSTOMBOLD;
   }
   return  Text(
     text,overflow: TextOverflow.ellipsis,maxLines:line,
     textAlign: txtAlign,
     style:  TextStyle(
       color: txtColour,
       fontSize: txtSize,
       fontFamily: fontFamily,
       shadows: [

         Shadow(
           offset: Offset(0.0, 4.0),
           blurRadius: 5.0,
           color: Colors.black.withOpacity(0.5),
         ),
       ],
     ),
   );
 }
}
