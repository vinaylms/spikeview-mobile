import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class BadgeListModel {

List<BadgeModel> requestedBadgeList;
List<BadgeModel> collectionBadgeList;
List<BadgeModel> presentBadgeList;

BadgeListModel(this.requestedBadgeList, this.collectionBadgeList,
    this.presentBadgeList);


}


class BadgeModel{
  int badgeReqId,badgeId;
  String message,badgeName,status,createdAt,badgeImage,userName,userImage,userTagline,companyName;
  int userId,userRoleId;
bool isMore=false;
  BadgeModel(this.badgeReqId, this.badgeId, this.message,
      this.badgeName, this.status, this.createdAt, this.badgeImage,this.userName,this.userImage,this.userTagline,this.companyName,this.userId, this.userRoleId);


}

