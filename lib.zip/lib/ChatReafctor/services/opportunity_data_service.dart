import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:injectable/injectable.dart';

import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/constant/Constant.dart';

@lazySingleton
class OpportunityService {




  Future<Response> getPosts(opportunityId) async {
    Response  response;
    try {

      print('chatApi+++++++++=='+Constant.BASE_URL +
          "ui/opportunity/opportunityDetails?opportunityId=" +
          opportunityId);
       response = await  ApiCalling2().apiCall(
          null,Constant.BASE_URL +
           "ui/opportunity/opportunityDetails?opportunityId=" +
           opportunityId,

          "get");


    } catch (e) {
      print("Error+++" + e.toString());
    }
    return response;
  }
}
