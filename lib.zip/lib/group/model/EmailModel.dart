import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';




class EmailModel {
  String email;
String roleId;
  EmailModel(this.email,this.roleId);

  Map<String, dynamic> toJson() => {
    'email': email.toLowerCase().toString(),
    'roleId': roleId,
    'firstName': "",
    'lastName': ""
  };

}
