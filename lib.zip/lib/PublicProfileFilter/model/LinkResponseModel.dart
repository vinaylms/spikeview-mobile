import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';

class LinkResponseModel {
  String status;
  String message;
  LinkData result;

  LinkResponseModel({this.status, this.message, this.result});

  LinkResponseModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    result =
    json['result'] != null ?   LinkData.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class LinkData {
  String title;
  String image;
  String url;
  String description;
  String width;
  String height;
  String source;

  LinkData(
      {this.title,
        this.image,
        this.url,
        this.description,
        this.width,
        this.height,
        this.source});

  LinkData.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    image = json['image'];
    url = json['url'];
    description = json['description'];
    width = json['width'];
    height = json['height'];
    source = json['source'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['title'] = this.title;
    data['image'] = this.image;
    data['url'] = this.url;
    data['description'] = this.description;
    data['width'] = this.width;
    data['height'] = this.height;
    data['source'] = this.source;
    return data;
  }
}