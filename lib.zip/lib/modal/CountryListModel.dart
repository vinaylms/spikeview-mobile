import 'dart:io';


class CountryListModel{
  String status;
  List<CountryList> countryList;

  CountryListModel({this.status, this.countryList});

  CountryListModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      countryList =  List<CountryList>();
      json['result'].forEach((v) {
        countryList.add(new CountryList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.countryList != null) {
      data['result'] = this.countryList.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CountryList {
  int id;
  String name;
  int phoneCode;
  String sortname;
  bool isZipcode;

  CountryList({this.id, this.name, this.phoneCode, this.sortname, this.isZipcode});

  CountryList.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    phoneCode = json['phoneCode'];
    sortname = json['sortname'];
    isZipcode = json['isZipcode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['phoneCode'] = this.phoneCode;
    data['sortname'] = this.sortname;
    data['isZipcode'] = this.isZipcode;
    return data;
  }
}