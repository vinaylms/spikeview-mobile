import 'dart:io';

import 'package:spike_view_project/modal/IntroDuctioVideoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';

class ProfileInfoModal {
  Address address;

  String userId,
      groupId,
      groupName,
      groupImage,
      firstName,
      lastName,
      email,
      mobileNo,
      profilePicture,
      roleId,
      isActive,isHide,
      requireParentApproval,
      ccToParents,
      lastAccess,
      isPasswordChanged,
      organizationId,
      gender,
      dob,
      genderAtBirth,
      usCitizenOrPR,
      summary,
      coverImage,
      tagline,
      title,
      tempPassword,
      isArchived,
      status,
      statusVal,
      creationTime,
      zipCode,
      stage,publicUrl;
  bool isSelected = false;
  bool isPublicUrlActive = false;
  bool isExistingUser = false;
  bool isCollegeAdded = false;
  bool referralPopup = false;
  bool userLoginFirstTime = false;
  bool isPublicProfileGlobalyActive = false;
  List<ParentModal> parentList;
  List<SocialLinkData> socialLinkDataList;
  IntroVideo introVideo;
  Company company;

  String badge;
  String badgeImage;
  int gamificationPoints;
  String refferalCode;
  ProfileInfoModal(
      this.userId,
      this.firstName,
      this.lastName,
      this.email,
      this.mobileNo,
      this.profilePicture,
      this.roleId,
      this.isActive,
      this.requireParentApproval,
      this.ccToParents,
      this.lastAccess,
      this.isPasswordChanged,
      this.organizationId,
      this.gender,
      this.dob,
      this.genderAtBirth,
      this.usCitizenOrPR,
      this.address,
      this.summary,
      this.coverImage,
      this.tagline,
      this.title,
      this.tempPassword,
      this.isArchived,
      this.parentList,
      this.isSelected,
      this.groupId,
      this.groupName,
      this.groupImage,
      this.status,
      this.statusVal,
      this.zipCode,this.isHide,this.referralPopup,this.userLoginFirstTime,this.stage,this.creationTime,this.badge,this.gamificationPoints,this.badgeImage,this.refferalCode,this.socialLinkDataList,this.publicUrl,this.isPublicUrlActive,this.isPublicProfileGlobalyActive,this.introVideo,this.company
      ,this.isExistingUser,this.isCollegeAdded);

  Map<String, dynamic> toJson() => {
        'userId': int.parse(userId),
      };
}

class ParentModal {
  String email, userId;
  String firstName, lastName, zipCode = "", gender = "", dob,state,city,country;

  ParentModal(this.email, this.userId, this.firstName, this.lastName,
      this.zipCode, this.gender, this.dob,this.country, this.state, this.city);

  Map<String, dynamic> toJson() => {
        'email': email,
        'firstName': firstName,
        'lastName': lastName,
        'dob': dob,
        'gender':  gender=="Non-Binary"?"NonBinary":gender,
        'zipCode': zipCode,
        'country': country,
        'state': state,
        'city': city,
        'userId': userId != "" ? int.parse(userId) : "",
      };
}

class GroupInfoModel {
  String groupId,
      groupName,
      type,
      creationDate,
      createdBy,
      isActive,
      aboutGroup,
      otherInfo,
      groupImage;

  GroupInfoModel(
      this.groupId,
      this.groupName,
      this.type,
      this.creationDate,
      this.createdBy,
      this.isActive,
      this.aboutGroup,
      this.otherInfo,
      this.groupImage);
}


/*
"company": {
            "name": "RTECH",
            "isActive": false
        }
* */

class Company{
  String name, partnerStatus;

  bool isActive;

  Company(this.name,this.partnerStatus,this.isActive);

}

