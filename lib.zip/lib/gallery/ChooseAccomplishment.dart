import 'dart:async';
import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gallery/AccomplishmentDetailWidget.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ChooseAccomplishment extends StatefulWidget {
  String userId;
  List<Assest> assestList;

  ChooseAccomplishment(this.userId, this.assestList);

  @override
  State<StatefulWidget> createState() => ChooseAccomplishmentState();
}

class ChooseAccomplishmentState extends State<ChooseAccomplishment> {
  List<NarrativeModel> narrativeList =  List<NarrativeModel>();
  List<Achivment> achivmentList =  List();
  int selected = 0;
  String userIdPref, token;
  SharedPreferences prefs;
  String selectedAchievmentId = "";
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String strPrefixPathforPhoto = "";
  Future narrativeApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        Response response = await  ApiCalling2().apiCall(
            context, Constant.ENDPOINT_NARRATIVE + widget.userId, "get");

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];

            if (status == "Success") {
              narrativeList =
                  ParseJson.parseMapNarrativeForOusideAccomplishment(response.data['result'], true);
              if (narrativeList.length > 0) {
                setState(() {
                  for (int i = 0; i < narrativeList.length; i++) {
                    if (narrativeList[i].achivmentList.length > 0) {
                      achivmentList.addAll(narrativeList[i].achivmentList);
                    }
                  }
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }
  List<Assest2> finalList =  List();
  String sasToken = "", containerName = "";
  getData() async {
    prefs = await SharedPreferences.getInstance();
    await narrativeApi(true);
  }

  @override
  void initState() {
    getData();

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        widget.userId +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
    callApiForSaas(false);
    super.initState();
  }

  onBack() async {
    String roleId = prefs.getString(UserPreference.ROLE_ID);
    if (roleId == "2") {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => DashBoardWidgetParent(
              prefs.getString(UserPreference.IS_PARENT_ROLE),
              prefs.getString(UserPreference.IS_PARTNER_ROLE),
              prefs.getString(UserPreference.IS_USER_ROLE))));
    } else {
      bloc.loadData(widget.userId, context, prefs);
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>  DashBoardWidget(
              prefs.getString(UserPreference.IS_PARENT_ROLE),
              prefs.getString(UserPreference.IS_PARTNER_ROLE),
              prefs.getString(UserPreference.IS_USER_ROLE))));
    }
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    _timer =  Timer(const Duration(milliseconds: 2000), () async {

      Navigator.pop(context);
      Navigator.of(context).popUntil((route) => route.isFirst);
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //assestList.removeAt(0);
        Map map = {
          "achievementId": achivmentList[selected].achievementId,
          "asset": finalList.map((item) => item.toJson()).toList(),
        };
        Response response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_ADDED_ACHEVMENT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              showSucessMsg("Accomplishment added successfully.", context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future callApiForSaas(isShowLoader) async {
    try {
      Response response = await  ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR,context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    String getConvertedDateStamp2(String time) {
      if (time != "null") {
        int millis = int.tryParse(time);
        var now =  DateTime.fromMillisecondsSinceEpoch(millis);
        var formatter =  DateFormat('MMM dd, yyyy');
        String formatted = formatter.format(now);
        return formatted;
      } else {
        //  var formatter =  DateFormat('MMM dd, yyyy');
        //return formatter.format(new DateTime.now());
        return "Ongoing";
      }
    }

    return SafeArea(
      child: Scaffold(
          appBar:  AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                 InkWell(
                  child:  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "assets/newDesignIcon/navigation/back.png",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  },
                )
              ],
            ),
            title:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                 Text(
                  "Accomplishment",
                  style:  TextStyle(
                      fontSize: 18.0,
                      fontFamily: Constant.customRegular,
                      color:  ColorValues.HEADING_COLOR_EDUCATION),
                )
              ],
            ),
            actions: <Widget>[
              achivmentList.length == 0
                  ?  Container(
                      width: 30.0,
                    )
                  : Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 20.0, 15.0, 0.0),
                      child: InkWell(
                        child:  Text(
                          "Done",
                          style: TextStyle(
                            color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                            fontSize: 16.0,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        onTap: () {
                          if ((achivmentList[selected].assestList.length +
                                  widget.assestList.length) <=
                              10) {

                            CustomProgressLoader.showLoader(context);
                            Timer _timer =  Timer(const Duration(milliseconds: 400), () async {
                              var isConnect = await ConectionDetecter.isConnected();
                              if (isConnect) {
                                for (int i = 0; i < widget.assestList.length; i++) {
                                  String strAzureImageUploadPath = await uploadImgOnAzure(
                                      widget.assestList[i]
                                          .file
                                          .toString()
                                          .replaceAll("File: ", "")
                                          .replaceAll("'", "")
                                          .trim(),
                                      strPrefixPathforPhoto);
                                  // finalList[i].file = strAzureImageUploadPath;

                                  finalList.add(new Assest2(
                                      "image",
                                      widget.assestList[i].tag,
                                      strPrefixPathforPhoto + strAzureImageUploadPath,
                                      true));
                                }
                                setState(() {
                                  finalList;
                                });
                                apiCalling();
                              } else {
                                CustomProgressLoader.cancelLoader(context);
                                ToastWrap.showToast(
                                    MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
                              }
                            });


                          } else {
                            ToastWrap.showToast(
                                MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL,
                                context);
                          }
                        },
                      ))
            ],
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
          backgroundColor: ColorValues.singin_bg_color,
          body:  Column(
            children: <Widget>[
               Expanded(
                child: CustomViews.getSepratorLine(),
                flex: 0,
              ),
               Expanded(
                child: ListView(
                  children: <Widget>[
                    Container(
                      padding:
                          EdgeInsets.only(left: 15, top: 19.5, right: 13.0),
                      child: Text(
                          'Please select from the below list of previously added accomplishment',
                          style: TextStyle(
                              fontSize: 12, color: ColorValues.GREY_TEXT_COLOR)),
                    ),
     Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children:  List.generate(
        achivmentList.length, (int index) {
      return Padding(
        padding: const EdgeInsets.only(
            left: 13, top: 8, right: 13.0),
        child: InkWell(
          child: Container(
            padding: EdgeInsets.only(top: 5, right: 0),
            child: Row(
              children: <Widget>[
                Image.asset(
                    selected == index
                        ? "assets/newDesignIcon/group/check_radio.png"
                        : "assets/newDesignIcon/group/uncheck_radio.png",
                    height: 22,
                    width: 22),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 11,
                      right: 12,
                    ),
                    child: Row(
                      children: <Widget>[
                        Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 12),
                              child: Text(
                                  achivmentList[index].title,
                                  style: TextStyle(
                                      fontSize: 16)),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                                getConvertedDateStamp2(
                                    achivmentList[index]
                                        .fromDate) +
                                    " - " +
                                    getConvertedDateStamp2(
                                        achivmentList[index]
                                            .toDate),
                                style: TextStyle(
                                    fontSize: 14,
                                    color:
                                    ColorValues.GREY_TEXT_COLOR)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: Text('View',
                        style: TextStyle(
                            fontSize: 12,
                            color:   ColorValues.BLUE_COLOR)),
                  ),
                  onTap: () async {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                AccomplishmentDetailWidget(
                                    achivmentList[index])));
                  },
                )
              ],
            ),
          ),
          onTap: () {
            setState(() {
              selected = index;
            });
          },
        ),
      );
    }))



                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }
}

class ModelData {
  String name, date;
  bool isSelected = false;

  ModelData(this.name, this.date);
}
