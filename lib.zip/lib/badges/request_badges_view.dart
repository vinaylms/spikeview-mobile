import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/badges/model/SelfBadgeModel.dart';

import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/badges/custom_appbar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/style.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestFromParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/recommendation/AddRecommendationPerformance.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:url_launcher/url_launcher.dart';

class BadgeRequest extends StatefulWidget {
  //const BadgeRequest({Key key}) : super(key: key);

  String badgeId, screenName;

  BadgeRequest(this.badgeId, this.screenName);

  @override
  State<BadgeRequest> createState() => _BadgeRequestState();
}

class _BadgeRequestState extends State<BadgeRequest> {
  SelfBadgeModel badgeModel;

  onBack() async {
    print('onback() roleId:: $roleId');

    if (prefs.getBool("loginStatus")) {
      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        StudentOnBoarding()
            .getStudentOnBoardingInit(context, null, null, userIdPref);
      }
    } else {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => LoginPage(null)));
    }
  }

  Future recommendationApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2()
            .apiCall6(context, 'ui/badge?badgeReqId=${widget.badgeId}', "get");
        print('id +++ui/badge?badgeReqId=${widget.badgeId} ');

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);
        String status = response.data[LoginResponseConstant.STATUS];

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              badgeModel = SelfBadgeModel.fromJson(response.data);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  SharedPreferences prefs;
  String userIdPref, token, roleId;
  String path;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    path = prefs.getString(UserPreference.PATHURL);
    print('path+++$path ');

    await recommendationApi(true);
  }

  @override
  void initState() {
    try {
      getSharedPreferences();
      // TODO: implement initState

    } catch (e) {
      e.toString();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () {
          if (widget.screenName == "notification") {
            Navigator.pop(context);
          } else {
            onBack();
          }
        },
        child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,
              leading: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    child: SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          0.0,
                          3.0,
                          Center(
                              child: Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      if (widget.screenName == "notification") {
                        Navigator.pop(context);
                      } else {
                        onBack();
                      }
                    },
                  )
                ],
              ),
              title: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "Badge review",
                    style: TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color: ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              actions: <Widget>[
                path==""||path==null||path=="null"?Container(child: TextViewWrap.textView(
                    "   ",
                    TextAlign.center,
                    ColorValues.WHITE,
                    12.0,
                    FontWeight.normal),):
                (path.contains("/5/") ||
                    path.contains("/0/") ||
                    path.contains("/1/") ||
                    path.contains("/2/") ||
                    path.contains("/4/") ||
                    path.contains("/6/") ||
                    path.contains("/7/") ||
                    path.contains("/8/") ||
                    path.contains("/9/"))?
                Container(child: TextViewWrap.textView(
                    "   ",
                    TextAlign.center,
                    ColorValues.WHITE,
                    12.0,
                    FontWeight.normal),):     Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              16.0,
                              5.0,
                              8.0,
                              5.0,
                              InkWell(
                                child: Container(
                                  width: 70.0,
                                  height: 35.0,
                                  color: ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                  child: new Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      TextViewWrap.textView(
                                          "Join Now",
                                          TextAlign.center,
                                          ColorValues.WHITE,
                                          12.0,
                                          FontWeight.normal)
                                    ],
                                  ),
                                ),
                                onTap: () {

                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginPage(
                                                null,
                                                isRedirectToRecommendation:
                                                    true,
                                                pageName: "recomendation",
                                                showSignup: true,
                                              )));

                                  // Join Now button click
                                },
                              ))
                        ],
                      )
              ],
              backgroundColor: Colors.white,
              elevation: 0.0,
            ),
            body: badgeModel == null
                ? Container()

                :

                  Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                  ListView(
                  children: <Widget>[ Container(
                        color: const Color(0xffF7F7F7),
                        padding: const EdgeInsets.symmetric(
                            vertical: 20, horizontal: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Text(
                              badgeModel
                                  .result[0].user.firstName+ " "+ badgeModel
                                  .result[0].user.lastName+" has added the following badge to their profile on your behalf. Please review.",
                              textAlign: TextAlign.start,
                              style:
                              TxtStyle.nunito_14_400Grey,
                            ),

                            Container(
                              margin: const EdgeInsets.only(top: 20),
                              width: MediaQuery.of(context).size.width,
                              height: 1,
                              color: const Color(0xFFDEDEDE),
                            ),

                            Container(
                              margin: const EdgeInsets.only(top: 15),
                              child: Row(
                                children: [
                                  InkWell(
                                    child: ClipOval(
                                        child: FadeInImage.assetNetwork(
                                          fit: BoxFit.cover,
                                          width: 50.0,
                                          height: 50.0,
                                          placeholder:
                                          'assets/profile/user_on_user.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getMediumImage(badgeModel
                                                  .result[0].user.profilePicture),
                                        )),
                                    onTap: () {},
                                  ),
                                  const SizedBox(width: 10),
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            'From: ',
                                            textAlign: TextAlign.start,
                                            style:
                                            TxtStyle.nunito_14_400Black,
                                          ),
                                          Text(
                                            badgeModel
                                                .result[0].user.firstName+ " "+ badgeModel
                                                .result[0].user.lastName,
                                            textAlign: TextAlign.start,
                                            style:
                                            TxtStyle.nunito_14_700Black,
                                          ),
                                        ],
                                      ),

                                      Text(
                                          badgeModel
                                              .result[0].user.tagline,
                                          textAlign: TextAlign.start,
                                          style:
                                          TextStyle(
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 12,
                                              color: ColorValues.riminderColor,
                                              fontWeight: FontWeight.w400
                                          )
                                      ),
                                      /*  Text(
                                      'Soccer Lover',
                                      textAlign: TextAlign.start,
                                      style: TxtStyle.nunito_14_400Grey,
                                    ),*/
                                    ],
                                  )
                                ],
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 20),
                              width: MediaQuery.of(context).size.width,
                              height: 1,
                              color: const Color(0xFFDEDEDE),
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Issuer name',
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_14_400Grey,
                                  ),
                                  Padding(
                                      padding: const EdgeInsets.only(top:4.0),
                                      child:Text(
                                        badgeModel.result[0].partner.lastName ==
                                            null
                                            ? badgeModel
                                            .result[0].partner.firstName
                                            : '${badgeModel.result[0].partner.firstName} ${badgeModel.result[0].partner.lastName}',
                                        textAlign: TextAlign.start,
                                        style: TxtStyle.nunito_16_400Black,
                                      )),
                                ],
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Issuer Email',
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_14_400Grey,
                                  ),
                                  Padding(
                                      padding: const EdgeInsets.only(top: 4.0),
                                      child: Text(
                                        badgeModel.result[0].partner.email,
                                        textAlign: TextAlign.start,
                                        style: TxtStyle.nunito_16_400Black,
                                      )),
                                ],
                              ),
                            ),
                            badgeModel.result[0].issuerLogo == null ||
                                badgeModel.result[0].issuerLogo == ''
                                ? Container()
                                : Container(
                              margin: const EdgeInsets.only(top: 20),
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Issuer Logo Image',
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_14_400Grey,
                                  ),
                              InkWell(
                                onTap: (){
                                  if(badgeModel
                                      .result!=null&&badgeModel
                                      .result.length>0&& badgeModel
                                      .result[0].issuerLogo!=null) {
                                    Navigator.push(
                                      context,
                                      HeroDialogRoute(
                                        builder: (BuildContext context) {
                                          return Center(
                                            child: AlertDialog(
                                              content: Container(
                                                child: Hero(
                                                  tag: 'developer-hero',
                                                  child: Container(
                                                    height: 200.0,
                                                    width: 200.0,
                                                    child: Image.network(
                                                      Constant
                                                          .IMAGE_PATH_SMALL +
                                                          ParseJson
                                                              .getMediumImage(
                                                              badgeModel
                                                                  .result[0]
                                                                  .issuerLogo),
                                                      fit: BoxFit.fitHeight,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              actions: <Widget>[
                                                FlatButton(
                                                  child: Text('Close'),
                                                  onPressed: Navigator
                                                      .of(context)
                                                      .pop,
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    );
                                  }
                                },
                                child:   Container(
                                      margin:
                                      const EdgeInsets.only(top: 5),
                                      padding:
                                      const EdgeInsets.all(5.0),
                                      width: 50,
                                      height: 48,
                                      decoration: BoxDecoration(
                                          color:
                                          const Color(0xFFFFFFFF),
                                          border: Border.all(
                                              color: const Color(
                                                  0xffE9E9EC))),
                                      child: FadeInImage.assetNetwork(
                                        fit: BoxFit.cover,
                                        width: 50,
                                        height: 48,
                                        placeholder:
                                        'assets/badges/national_pic.png',
                                        image: Constant
                                            .IMAGE_PATH_SMALL +
                                            ParseJson.getMediumImage(
                                                badgeModel.result[0]
                                                    .issuerLogo),
                                      )))
                                ],
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Issue Date',
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_14_400Grey,
                                  ),
                                  Padding(
                                      padding: const EdgeInsets.only(top: 4.0),
                                      child:Text(
                                        Util.getConvertedDateStamp(badgeModel
                                            .result[0].issueDate
                                            .toString()),
                                        textAlign: TextAlign.start,
                                        style: TxtStyle.nunito_16_400Black,
                                      )),
                                ],
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Badge Title',
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_14_400Grey,
                                  ),
                                  Padding(
                                      padding: const EdgeInsets.only(top: 4.0),
                                      child:  Text(
                                        badgeModel.result[0].badgeName.toString(),
                                        textAlign: TextAlign.start,
                                        style: TxtStyle.nunito_16_400Black,
                                      )),
                                ],
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Badge Image',
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_14_400Grey,
                                  ),
                                  InkWell(
                                    onTap: (){
                                      if(badgeModel
                                          .result!=null&&badgeModel
                                          .result.length>0&& badgeModel
                                          .result[0].badgeImage!=null) {
                                        Navigator.push(
                                          context,
                                          HeroDialogRoute(
                                            builder: (BuildContext context) {
                                              return Center(
                                                child: AlertDialog(
                                                  content: Container(
                                                    child: Hero(
                                                      tag: 'developer-hero',
                                                      child: Container(
                                                        height: 200.0,
                                                        width: 200.0,
                                                        child: Image.network(
                                                          Constant
                                                              .IMAGE_PATH_SMALL +
                                                              ParseJson
                                                                  .getMediumImage(
                                                                  badgeModel
                                                                      .result[0]
                                                                      .badgeImage),
                                                          fit: BoxFit.fitHeight,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  actions: <Widget>[
                                                    FlatButton(
                                                      child: Text('Close'),
                                                      onPressed: Navigator
                                                          .of(context)
                                                          .pop,
                                                    ),
                                                  ],
                                                ),
                                              );
                                            },
                                          ),
                                        );
                                      }
                                    },
                                    child: Container(
                                        margin: const EdgeInsets.only(top: 5),
                                        padding: const EdgeInsets.all(5.0),
                                        width: 50,
                                        height: 48,
                                        decoration: BoxDecoration(
                                            color: const Color(0xFFFFFFFF),
                                            border: Border.all(
                                                color:
                                                const Color(0xffE9E9EC))),
                                        child: FadeInImage.assetNetwork(
                                          fit: BoxFit.cover,
                                          width: 50,
                                          height: 48,
                                          placeholder:
                                          'assets/badges/national_pic.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getMediumImage(
                                                  badgeModel
                                                      .result[0].badgeImage),
                                        )),
                                  )
                                ],
                              ),
                            ),

                            SizedBox(height: 50,)
                          ],
                        ))]),




                    GestureDetector(
                      onTap: () {
                        final String subject = "";
                        final String stringText = "";
                        String uri =
                            'mailto:team@spikeview.com?subject=${Uri.encodeComponent(subject)}&body=${Uri.encodeComponent(stringText)}';
                        launch(uri);
                      },
                      child: Container(
                          margin: const EdgeInsets.all(20),
                          padding: const EdgeInsets.all(5.0),
                          width: MediaQuery.of(context).size.width,
                          height: 60,
                          decoration: BoxDecoration(
                              color: const Color(0xFFF3F7FC),
                              border:
                              Border.all(color: const Color(0xffE9E9EC))),
                          child: Column(
                            children: [
                              RichText(
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'Note: ',
                                  style: TxtStyle.nunito_italic_16_400Black,
                                  /*defining default style is optional */
                                  children: <TextSpan>[
                                    TextSpan(


                                        text: 'If this badge detail are not correct, you can contact to ',
                                        style:
                                        TxtStyle.nunito_italic_16_400Black),
                                    TextSpan(
                                        text: 'team@spikeview.com.',
                                        style: TxtStyle
                                            .nunito_italic_14_400Blue),
                                  ],
                                ),
                              ),
                            ],
                          )),
                    )
                  ],
                )
          ));
  }
}
