import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/group/AddGroupWidget.dart';
import 'package:spike_view_project/group/AddGroupWidgetForParent.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'GroupConnectedWidget.dart';
import 'GroupDiscoverWidgetNew.dart';
import 'GroupRequestSentWidgetNew.dart';
import 'GroupStudentRequestWidget.dart';

// Create a Form Widget
class GroupBaseWidgetNew extends StatefulWidget {
  String userId;
  final GlobalKey<ScaffoldState> _scaffoldKey;
  int notificationCount = 0;

  GroupBaseWidgetNew(this.userId, this._scaffoldKey, this.notificationCount);

  @override
  GroupBaseWidgetNewState createState() {
    return GroupBaseWidgetNewState(notificationCount);
  }
}

class GroupBaseWidgetNewState extends State<GroupBaseWidgetNew>
    with SingleTickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  TabController _controller;
  int _currentIndex = 2;

  GroupBaseWidgetNewState(this.notificationCount);

  int notificationCount = 0;
  StreamSubscription<dynamic> _streamSubscription;
  SharedPreferences prefs;
  String userIdPref, roleId, token;

  getSharedPrefrence() async {
    prefs = await SharedPreferences.getInstance();
    roleId = prefs.getString(UserPreference.ROLE_ID);
  }

  @override
  void initState() {
    getSharedPrefrence();
    _controller = TabController(vsync: this, length: 3, initialIndex: 2);
    _controller.addListener(handleTabSelection);
    _streamSubscription =
        DashBoardState.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        setState(() {});
      }
    });

    DashBoardStateParent.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted) setState(() {});
      }
    });
    DashBoardStatePartner.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted) setState(() {});
      }
    });

    super.initState();
  }

  handleTabSelection() {
    setState(() {
      _currentIndex = _controller.index;
    });
  }

  onTapAddGroup() async {
    print("isParent++++" + isParent.toString());
    if (roleId == '2') {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => AddGroupWidgetForParent("", "")));

      if (result == "push") {
        setState(() {});
      }
    } else {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => AddGroupWidget("", "", "")));

      if (result == "push") {
        setState(() {});
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    Constant.applicationContext = context;

    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: CustomViews.getAppBar(
            "", widget._scaffoldKey, context, prefs, notificationCount),
        body: Container(
          color: ColorValues.WHITE, //ColorValues.GRAY_BG,

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.fromLTRB(20.0, 5.0, 16.0, 10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Groups",
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          fontSize: 28.0,
                          fontWeight: FontWeight.w700,
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                    InkWell(
                        onTap: () {
                          onTapAddGroup();
                        },
                        child: Center(
                          child: Icon(
                            Icons.add,
                            color: AppConstants.colorStyle.lightBlue,
                            size: 28,
                          ),
                        ))
                  ],
                ),
              ),
              roleId == '2'
                  ? Padding(
                      padding: EdgeInsets.fromLTRB(20.0, 5.0, 15.0, 10.0),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  GroupStudentRequestWidget()));
                        },
                        child: Text(
                          "View student group",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                              fontSize: 16.0,
                              fontWeight: FontWeight.w600,
                              color: ColorValues.MY_MSG_BORDER_COLOR,
                              fontFamily: Constant.latoRegular),
                        ),
                      ),
                    )
                  : SizedBox(
                      height: 0,
                    ),
              Padding(
                padding: EdgeInsets.fromLTRB(20.0, 5.0, 19.0, 15.0),
                child: Container(
                  height: 35,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    //  color: ColorValues.TAB_BACKGROUND_COLOR,
                    /*   border: Border.all(
                              color: ColorValues.BORDER_GENERATE_SCRIPT,
                              width: 1,
                            )*/
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              _currentIndex = 0;
                            });
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: ColorValues.TAB_BACKGROUND_COLOR,
                                borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(10.0),
                                    topLeft: Radius.circular(10.0)),
                                border: Border.all(
                                  color: ColorValues.BORDER_GENERATE_SCRIPT,
                                  width: 1,
                                )),
                            child: Container(
                              width: double.infinity,
                              child: Center(
                                  child: BaseText(
                                text: "Discover",
                                textColor: _currentIndex == 0
                                    ? Colors.white
                                    : ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w400,
                                fontSize: 14,
                                textAlign: TextAlign.center,
                                maxLines: 1,
                              )),
                              decoration: BoxDecoration(
                                color: _currentIndex == 0
                                    ? ColorValues.DARK_YELLOW
                                    : ColorValues.TAB_BACKGROUND_COLOR,
                                borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(10.0),
                                    topLeft: Radius.circular(10.0)),
                              ),
                            ),
                          ),
                        ),
                        flex: 1,
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              _currentIndex = 1;
                            });
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: ColorValues.TAB_BACKGROUND_COLOR,
                                borderRadius: BorderRadius.circular(0.0),
                                border: Border.all(
                                  color: ColorValues.BORDER_GENERATE_SCRIPT,
                                  width: 1,
                                )),
                            child: Container(
                              width: double.infinity,
                              child: Center(
                                  child: BaseText(
                                text: "Sent",
                                textColor: _currentIndex == 1
                                    ? Colors.white
                                    : ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w400,
                                fontSize: 14,
                                textAlign: TextAlign.center,
                                maxLines: 1,
                              )),
                              decoration: BoxDecoration(
                                color: _currentIndex == 1
                                    ? ColorValues.DARK_YELLOW
                                    : ColorValues.TAB_BACKGROUND_COLOR,
                                borderRadius: BorderRadius.circular(0.0),
                              ),
                            ),
                          ),
                        ),
                        flex: 1,
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              _currentIndex = 2;
                            });
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: ColorValues.TAB_BACKGROUND_COLOR,
                                borderRadius: BorderRadius.only(
                                    bottomRight: Radius.circular(10.0),
                                    topRight: Radius.circular(10.0)),
                                border: Border.all(
                                  color: ColorValues.BORDER_GENERATE_SCRIPT,
                                  width: 1,
                                )),
                            child: Container(
                              width: double.infinity,
                              child: Center(
                                  child: BaseText(
                                text: "My groups",
                                textColor: _currentIndex == 2
                                    ? Colors.white
                                    : ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w400,
                                fontSize: 14,
                                textAlign: TextAlign.center,
                                maxLines: 1,
                              )),
                              decoration: BoxDecoration(
                                color: _currentIndex == 2
                                    ? ColorValues.DARK_YELLOW
                                    : ColorValues.TAB_BACKGROUND_COLOR,
                                borderRadius: BorderRadius.only(
                                    bottomRight: Radius.circular(10.0),
                                    topRight: Radius.circular(10.0)),
                              ),
                            ),
                          ),
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: _currentIndex == 0
                    ? GroupDiscoverWidgetNew() //ConnectionRequests()//

                    : _currentIndex == 1
                        ? GroupRequestSentWidgetNew()
                        : GroupConnectedWidget(), //,NewDiscoverWidget(),

                flex: 1,
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  // TODO: implement wantKeepAlive

  bool get wantKeepAlive => true;
}
