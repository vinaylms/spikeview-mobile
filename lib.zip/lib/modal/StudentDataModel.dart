import 'dart:io';

class StudentDataModel {

  List<Parents> parentList;
  List<ActivityLog> activityLogList;
  Address address;
  String userId,firstName,lastName,email,mobileNo,profilePicture,roleId,isActive,isHide,stage,
      requireParentApproval,ccToParents,lastAccess,isPasswordChanged,organizationId,gender,dob,
      genderAtBirth,usCitizenOrPR,summary,coverImage,tagline,title,tempPassword,isArchived,isAchievement,isEducation,isWizardCompleted;
  bool isSelected=false;
  bool isSubScribeCommunityPost=false;
  bool isLeaderboardDisplay=false;
  bool isMore=false;

  String badge;
  String badgeImage;
  int gamificationPoints;

  StudentDataModel( this.userId, this.firstName,
      this.lastName, this.email, this.mobileNo, this.profilePicture, this.roleId,
      this.isActive, this.requireParentApproval, this.ccToParents,
      this.lastAccess, this.isPasswordChanged, this.organizationId, this.gender,
      this.dob, this.genderAtBirth, this.usCitizenOrPR, this.summary,
      this.coverImage, this.tagline, this.title, this.tempPassword,
      this.isArchived,this.parentList, this.address,this.isAchievement,this.isEducation,this.isWizardCompleted,this.activityLogList,this.isHide,this.stage,this.isSubScribeCommunityPost,this.isLeaderboardDisplay,this.badge,this.gamificationPoints,this.badgeImage);


}
class Address{

  String street1,street2,city,state,country,zip,target;

  Address(this.street1, this.street2, this.city, this.state, this.country,
      this.zip,this.target);

}

class Parents{
  String email,userId,profilePicture,firstName,lastName;

  Parents(this.email, this.userId,this.profilePicture,this.firstName,this.lastName);

}

class ActivityLog{
  String categoryId,title,count,image;

  ActivityLog(this.categoryId, this.title,this.count,this.image);

}
