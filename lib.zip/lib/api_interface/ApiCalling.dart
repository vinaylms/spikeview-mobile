import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'dart:async';
import 'dart:io';
import 'dart:ui';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';

class ApiCalling {
  String userIdPref, token;
  Response response;
  BuildContext context;
  String uri;
  String type;

  call() async {
    var dio = Dio();
    FormData formData =  FormData.from({
      "name": "wendux",
      "age": 25,
      "file1":  UploadFileInfo(new File("./upload.txt"), "upload1.txt"),
      "file2":  UploadFileInfo(new File("./upload.txt"), "upload2.txt"),
      // Pass multiple files within an Array
      "files": [
         UploadFileInfo(new File("./example/upload.txt"), "upload.txt"),
         UploadFileInfo(new File("./example/upload.txt"), "upload.txt")
      ]
    });
    response = await dio.post("/info", data: formData);
  }

  Future<Response> azureUploading(
      context1, filePath, uploadPath, sasToken) async {
    context = context1;
    var accountName = '<account name>';
    var containerName = '<container name>';
    var blobName = '<blob name>';
    var sasTokenContainerLevel =
        '<container level sas token copied from Azure Storage Explorer, such as `st=2019-12-31T07%3A17%3A31Z&se=2020-01-01T07%3A17%3A31Z&sp=racwdl&sv=2018-03-28&sr=c&sig=xxxxxxxxxxxxxxxxxxxxxxxxxx`';

    // var url = 'https://$accountName.blob.core.windows.net/$containerName/$blobName?$sasTokenContainerLevel';
    File file =  File(filePath);
    var data = file.readAsBytesSync();

    String type = "image_profile.jpg";
    String uniqueID = type;

    String sasUrl2 = uploadPath + uniqueID + "?";
    // Log.e("sasurl", "path:-" + sasUrl2);
    String sasUrl = sasUrl2 + sasToken;

    print("sasURL++++++++++++++" + sasUrl.replaceAll("\"", ""));
    var dio = Dio();
    try {
      final response = await dio.put(sasUrl.replaceAll("\"", ""),
          data: data,

          options: Options(headers: {
            'x-ms-blob-type': 'BlockBlob',
            'Content-Type': 'text/plain',
          }));
      print(response.data);
    } catch (e) {
      print(e);
    }
    Response response = await dio.get(sasUrl.replaceAll("\"", ""));
    print(response.data);
  }
  Future<Response> apiCallWithAuthTokenBoolStatus(context1, url, type) async {
    context = context1;
    response = await apiCallingAuthTokenBoolStatus(url, type);
    return response;
  }

  Future<Response> apiCallingAuthTokenBoolStatus(url, type) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        print("Apurva token::::: " + token.toString());
        print("LoaderShow+++" + response.toString());
        print("LoaderShow+++" + url.toString());
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        // Make API call
        if (type == 'get') {
          response = await dio.get(url);
        } else {
          response = await dio.post(url);
        }
        CustomProgressLoader.cancelLoader(context);
        print("LoaderCancel+++" + response.toString());
        if (response.statusCode == 200) {
          bool status = response.data[LoginResponseConstant.STATUS];

          if (status) {
            return response;
          } else {
            return response;
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          print("LoaderCancel+++ false");
          return response;
        }
      } catch (e) {
        print("LoaderCancel+++" + e.toString());
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //  CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }


  Future<Response> apiCallWithAuthToken(context1, url, type) async {
    context = context1;
    response = await apiCallingAuthToken(url, type);
    return response;
  }

  Future<Response> apiCallingAuthToken(url, type) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        print("Apurva token::::: " + token.toString());
        print("LoaderShow+++" + response.toString());
        print("LoaderShow+++" + url.toString());
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        // Make API call
        if (type == 'get') {
          response = await dio.get(url);
        } else {
          response = await dio.post(url);
        }
        CustomProgressLoader.cancelLoader(context);
        print("LoaderCancel+++" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          print("LoaderCancel+++ false");
          return response;
        }
      } catch (e) {
        print("LoaderCancel+++" + e.toString());
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //  CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }

  //========================================= Api Calling ============================
  Future<Response> apiCall2(context1, url, type) async {
    context = context1;
    response = await apiCallForUserProfile2(url, type);
    return response;
  }

  Future<Response> apiCallForUserProfile2(url, type) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);

        var dio =  Dio();

        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        // Make API call
        if (type == 'get') {
          response = await dio.get(url);
        } else {
          response = await dio.post(url);
        }
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);

          return response;
        }
      } catch (e) {
        // CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }
  //========================================= Api Calling ============================
  Future<Response> apiCallForVideo(context1, url, formData)async {
    context = context1;
    response = await apiCallForVideoUpload(url, formData);
    return response;
  }

  Future<Response> apiCallForVideoUpload(url, formData) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data


        response = await dio.post(url, data: formData);



        CustomProgressLoader.cancelLoader(context);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //CustomProgressLoader.cancelLoader(context);

          return response;
        }
      } catch (e) {
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }
  //========================================= Api Calling ============================
  Future<Response> apiCall(context1, url, type) async {
    context = context1;
    response = await apiCallForUserProfile(url, type);
    return response;
  }

  Future<Response> apiCallwithouLoader(context1, url, type) async {
    context = context1;
    response = await apiCallForUserProfileThoutLoader(url, type);
    return response;
  }



  Future<Response> apiCallForUserProfile(url, type) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        print("LoaderShow+++" + response.toString());
        print("LoaderShow+++" + url.toString());
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        // Make API call
        if (type == 'get') {
          response = await dio.get(url);
        } else {
          response = await dio.post(url);
        }
        CustomProgressLoader.cancelLoader(context);
        print("LoaderCancel+++" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          print("LoaderCancel+++ false");
          return response;
        }
      } catch (e) {
        print("LoaderCancel+++" + e.toString());
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //  CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }


  Future<Response> apiCallForUserProfileThoutLoader(url, type) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);

        print("LoaderShow+++" + response.toString());
        print("LoaderShow+++" + url.toString());
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        // Make API call
        if (type == 'get') {
          response = await dio.get(url);
        } else {
          response = await dio.post(url);
        }

        print("LoaderCancel+++" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          print("LoaderCancel+++ false");
          return response;
        }
      } catch (e) {
        print("LoaderCancel+++" + e.toString());

        print(e);
        return response;
      }
    } else {
      //  CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }


  Future<Response> apiCallWithouAuth(context1, url, type) async {
    context = context1;
    response = await apiCallingWithoutAuth(url, type);
    return response;
  }

  Future<Response> apiCallingWithoutAuth(url, type) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        print("LoaderShow+++" + response.toString());
        print("LoaderShow+++" + url.toString());
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        //   dio.options.headers = {'Authorization': token}; // Prepare Data

        // Make API call
        if (type == 'get') {
          response = await dio.get(url);
        } else {
          response = await dio.post(url);
        }
        CustomProgressLoader.cancelLoader(context);
        print("LoaderCancel+++" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          print("LoaderCancel+++ false");
          return response;
        }
      } catch (e) {
        print("LoaderCancel+++" + e.toString());
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //  CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }

  Future<Response> apiCallWithouAuthWhiteLoader(context1, url, type) async {
    context = context1;
    response = await apiCallingWithoutAuthWhiteLoader(url, type);
    return response;
  }

  Future<Response> apiCallingWithoutAuthWhiteLoader(url, type) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoaderWhite(context);
        print("LoaderShow+++" + response.toString());
        print("LoaderShow+++" + url.toString());
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        //   dio.options.headers = {'Authorization': token}; // Prepare Data

        // Make API call
        if (type == 'get') {
          response = await dio.get(url);
        } else {
          response = await dio.post(url);
        }
        CustomProgressLoader.cancelLoader(context);
        print("LoaderCancel+++" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          print("LoaderCancel+++ false");
          return response;
        }
      } catch (e) {
        print("LoaderCancel+++" + e.toString());
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //  CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }

  //============================================Api Calling post with Param ===============================

  Future<Response> apiCallPostWithMapData(context1, url, map) async {
    context = context1;
    response = await apiCallPost(url, map);
    return response;
  }

  Future<Response> apiCallPost(url, map) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        response = await dio.post(url, data: json.encode(map));
print("post uri......."+map.toString());
        CustomProgressLoader.cancelLoader(context);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //CustomProgressLoader.cancelLoader(context);

          return response;
        }
      } catch (e) {
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }

  Future<Response> apiCallPostWithMapDataWithout(context1, url, map) async {
    context = context1;
    response = await apiCallPostWithoutLoader(url, map);
    return response;
  }


  Future<Response> apiCallPostWithoutLoader(url, map) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);

        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        response = await dio.post(url, data: json.encode(map));
        print("post uri......."+map.toString());

        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //CustomProgressLoader.cancelLoader(context);

          return response;
        }
      } catch (e) {

        print(e);
        return response;
      }
    } else {
      //CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }


  Future<Response> apiCallPutWithMapDataWithoutToken(context1, url, map) async {
    context = context1;
    response = await apiCallPutWithoutToken(url, map);
    return response;
  }

  Future<Response> apiCallPutWithoutToken(url, map) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
       // dio.options.headers = {'Authorization': token}; // Prepare Data

        response = await dio.put(url, data: json.encode(map));

        print("response:-" + response.toString());
        CustomProgressLoader.cancelLoader(context);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          // CustomProgressLoader.cancelLoader(context);

          return response;
        }
      } catch (e) {
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      // CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }

  //============================================Api Calling put with Param ===============================

  Future<Response> apiCallPutWithMapData(context1, url, map) async {
    context = context1;
    response = await apiCallPut(url, map);
    return response;
  }

  Future<Response> apiCallPut(url, map) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        response = await dio.put(url, data: json.encode(map));

        print("response:-" + response.toString());
        CustomProgressLoader.cancelLoader(context);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          // CustomProgressLoader.cancelLoader(context);

          return response;
        }
      } catch (e) {
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      // CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }

  //============================================Api Calling Delete with Param ===============================

  Future<Response> apiCallDeleteWithMapData(context1, url, map) async {
    context = context1;
    response = await apiCallDelete(url, map);
    return response;
  }

  Future<Response> apiCallDelete(url, map) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        userIdPref = prefs.getString(UserPreference.USER_ID);
        token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };

        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token}; // Prepare Data

        response = await dio.delete(url, data: json.encode(map));

        print("response:-" + response.toString());
        CustomProgressLoader.cancelLoader(context);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            return response;
          } else {
            return response;
          }
        } else {
          //   CustomProgressLoader.cancelLoader(context);

          return response;
        }
      } catch (e) {
        CustomProgressLoader.cancelLoader(context);
        print(e);
        return response;
      }
    } else {
      //  CustomProgressLoader.cancelLoader(context);

      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      return response;
    }
  }
}
