import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestFromParent.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestRepliedParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/recommendation/AddRecommendationNew.dart';
import 'package:spike_view_project/recommendation/AddRecommendationPerformance.dart';
import 'package:spike_view_project/recommendation/EditRecommendationNew.dart';
import 'package:spike_view_project/recommendation/EditRecommendationPerformance.dart';


import 'package:spike_view_project/values/ColorValues.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';

class ManageStudentBadges extends StatefulWidget {
  ProfileData profileInfoModal;
  bool isEditable;
  String userId;
  bool isShare = false;
  String sasToken;
  String recommendationId;
  String screenName;
  ProfileInfoModal profileModel;
  ManageStudentBadges(this.profileInfoModal, this.isEditable, this.isShare,
      this.userId, this.sasToken, this.screenName, this.recommendationId,{this.profileModel});

  @override
  ManageStudentBadgesTabList createState() {
    return ManageStudentBadgesTabList(profileInfoModal);
  }
}

class ManageStudentBadgesTabList extends State<ManageStudentBadges> {
  ProfileData profileInfoModal;

  ManageStudentBadgesTabList(this.profileInfoModal);

  SharedPreferences prefs;
  String userIdPref, token;
  String isPerformChanges = "pop";
  bool isDataLoadingRequest = false;
  bool isDataLoadingPending = false;
  bool isDataLoadingReplied = false;
  bool notificationLoader = true;
  List<Recomdation> recommendationtList = List();
  List<Recomdation> approvedRecommendationtList = List();
  List<Recomdation> requestedRecommendationtList = List();
  List<Recomdation> addedrecommendationtList = List();

  bool isViewAllForSentRequest = false;
  bool isViewAllForApprovedRequest = false;
  bool isViewAllRequested = false;
  String strRequestCount = "";
  String strRepliedCount = "";
  String strPendingRCount = "";
  int positionOfChild = 0;
  int positionOfReplied = 0;
  int positionOfPending = 0;

  String roleId = "";

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    _scrollController.addListener(() {
      if (recommendationtList.length - 1 == positionOfChild) {
        if (_scrollController.position.pixels ==
            _scrollController.position.maxScrollExtent) {
          setState(() {
            skip = skip + 1;
            recommendationApi();
          });
        }
      }
    });

    _scrollControllerReplie.addListener(() {
      if (approvedRecommendationtList.length - 1 == positionOfReplied) {
        if (_scrollControllerReplie.position.pixels ==
            _scrollControllerReplie.position.maxScrollExtent) {
          setState(() {
            skipReplie = skipReplie + 1;
            recommendationReplideApi();
          });
        }
      }
    });

    _scrollControllerPending.addListener(() {
      if (requestedRecommendationtList.length - 1 == positionOfPending) {
        if (_scrollControllerPending.position.pixels ==
            _scrollControllerPending.position.maxScrollExtent) {
          setState(() {
            skipPending = skipPending + 1;
            recommendationPendingApi();
          });
        }
      }
    });

    super.initState();
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    token = prefs.getString(UserPreference.USER_TOKEN);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    setState(() {
      notificationLoader = true;
    });

    recommendationApi();
    recommendationReplideApi();
    recommendationPendingApi();
    apiRecommendationCount();

  }

  int skip = 0;
  int skipPending = 0;
  int skipReplie = 0;
  ScrollController _scrollController = ScrollController();
  ScrollController _scrollControllerReplie = ScrollController();
  ScrollController _scrollControllerPending = ScrollController();

  Future<Null> onRefresh() async {
    setState(() {
      skip = 0;
      recommendationtList.clear();
    });
    recommendationApi();
  }

  Future<Null> onRefreshReplie() async {
    setState(() {
      skipReplie = 0;
      approvedRecommendationtList.clear();
    });
    recommendationReplideApi();
  }

  Future<Null> onRefreshPending() async {
    setState(() {
      skipPending = 0;
      requestedRecommendationtList.clear();
    });
    recommendationPendingApi();
  }

  onBack() async {

      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        StudentOnBoarding().getStudentOnBoardingInit(
            context, widget.profileModel, widget.sasToken, userIdPref);

      }

  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return WillPopScope(
        onWillPop: () {
          if(widget.screenName=='main'){
            onBack();
          }else {
            Navigator.pop(context, isPerformChanges);
          }
        },
        child: DefaultTabController(
          length: 2,
          child: Scaffold(
              appBar: AppBar(
                elevation: 0.0,
                automaticallyImplyLeading: false,
                titleSpacing: 2.0,
                brightness: Brightness.light,
                leading: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    InkWell(
                      child: SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                            Center(
                                child: Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        if(widget.screenName=='main'){
                          onBack();
                        }else {
                          Navigator.pop(context, isPerformChanges);
                        }
                      },
                    )
                  ],
                ),
                bottom: TabBar(
                  labelPadding:
                      EdgeInsets.only(top: 10, bottom: 10, left: 5, right: 5),
                  isScrollable: false,
                  indicatorColor: ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED,
                  labelColor: ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED,
                  //<-- selected text color
                  unselectedLabelColor: ColorValues.search_error_text,
                  //<-- Unselected text color
                  tabs: [
                    Tab(
                        child: FittedBox(
                            child: Text(
                      '  My Recommendation' + " (" + strRequestCount + ")",
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      style: TextStyle(
                          fontSize: 16,
                          fontFamily: Constant.customRegular,
                          fontWeight: FontWeight.w400),
                    ))),
                    /*    Tab(
                        child: FittedBox(
                            child: Text(
                      'Recommendations Replied' + "(" + strRepliedCount + ")",
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      style: TextStyle(
                          fontSize: 14,
                          fontFamily: Constant.customRegular,
                          fontWeight: FontWeight.w400),
                    ))),*/
                    Tab(
                        child: FittedBox(
                            child: Text(
                      'Pending' + " (" + strPendingRCount + ")",
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      style: TextStyle(
                          fontSize: 16,
                          fontFamily: Constant.customRegular,
                          fontWeight: FontWeight.w400),
                    ))),
                  ],
                ),
                actions: <Widget>[
                  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        0.0,
                        10.0,
                        0.0,
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                                "assets/newDesignIcon/navigation/add.png",
                                height: 20.0,
                                width: 20.0,
                                fit: BoxFit.fitHeight)
                          ],
                        )),
                    onTap: () async {
                      final result = await Navigator.of(context).push(
                          new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  AddRecommendationPerformance(
                                      widget.sasToken,
                                      profileInfoModal.email,
                                      profileInfoModal.lastName +
                                          profileInfoModal.firstName,
                                      profileInfoModal)));
                      if (result == "push") {
                        dataReresh();
                      }
                    },
                  )
                ],
                title: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text(
                      "Manage Recommendations",
                      style: TextStyle(
                          fontSize: 18.0,
                          fontFamily: Constant.customRegular,
                          color: ColorValues.HEADING_COLOR_EDUCATION),
                    )
                  ],
                ),
                backgroundColor: Colors.white,
              ),
              body: TabBarView(
                children: <Widget>[
                  RefreshIndicator(
                  onRefresh: onRefresh,
                  displacement: 0.0,
                  child:
                  isDataLoadingRequest
                      ?Padding(
                    padding: const EdgeInsets.only(top:20.0),
                    child: Container(
                      // width: 349,
                      height: 336,

                      margin: const EdgeInsets.only(left:16.0, right: 16.0,),
                      padding: const EdgeInsets.only(left:16.0, right: 16.0),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: ColorValues.GREY__COLOR_DIVIDER,),
                      ),
                      child: Center(
                        child:  Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                                width: 200.0,
                                height: 180.0,
                                child:  PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    Image.asset(
                                      "assets/recommendation/request_rc.png",
                                    ))),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                15.0,
                                0.0,
                                0.0, Text(
                              MessageConstant
                                  .RECOMMENDATION_REQUEST_NO_DATA,
                              textAlign: TextAlign.center,
                              maxLines: 1,
                              style: TextStyle(
                                  fontWeight: FontWeight.w400,
                                  fontFamily:
                                  Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 16,
                                  color: ColorValues.GREY__COLOR),
                            )),
                          ],

                        ),
                      ),
                    ),
                  )
                          : Container(
                              padding:
                                  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 10.0),
                              child: ListView.builder(
                                  physics: AlwaysScrollableScrollPhysics(),
                                  controller: _scrollController,
                                  itemCount: recommendationtList.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    positionOfChild = index;



                                    return Container(
                                      color: Colors.transparent,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              10.0,
                                              0.0,
                                              0.0,
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            0.0,
                                                            Wrap(
                                                              children: _buildChoiceList(
                                                                  recommendationtList[
                                                                          index]
                                                                      .stage),
                                                            )),
                                                    flex: 1,
                                                  ),
                                                  recommendationtList[index]
                                                              .stage ==
                                                          "Requested"
                                                      ? Expanded(
                                                          child: InkWell(
                                                            child: Row(
                                                              children: [
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        8.0,
                                                                        0.0,
                                                                        3.0,
                                                                        Image
                                                                            .asset(
                                                                          recommendationtList[index].isReminderEnable == "true"
                                                                              ? "assets/recommendation/reminder_blue.png"
                                                                              : "assets/recommendation/reminder_grey.png",
                                                                          height:
                                                                              25.0,
                                                                          width:
                                                                              25.0,
                                                                        )),
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        4.0,
                                                                        5.0,
                                                                        8.0,
                                                                        0.0,
                                                                        Text(
                                                                          MessageConstant
                                                                              .RECOMMENDATION_REMINDER,
                                                                          style: TextStyle(
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 16,
                                                                              color: recommendationtList[index].isReminderEnable == "true" ? ColorValues.BLUE_COLOR : ColorValues.search_error_text),
                                                                        )),
                                                              ],
                                                            ),
                                                            onTap: () {
                                                              if (recommendationtList[
                                                                          index]
                                                                      .isReminderEnable ==
                                                                  "true") {
                                                                apiForReminder(
                                                                    recommendationtList[
                                                                            index]
                                                                        .recommendationId
                                                                        .toString(),
                                                                    index);
                                                              } else {
                                                                showSucessMsg(Util.getConvertedDateStampNewSlash(
                                                                    recommendationtList[
                                                                            index]
                                                                        .reminderDay
                                                                        .toString()));
                                                              }
                                                            },
                                                          ),
                                                          flex: 0,
                                                        )
                                                      : Container(
                                                          height: 0,
                                                        ),
                                                  Expanded(
                                                    child: Row(
                                                      children: [
                                                        InkWell(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  3.0,
                                                                  0.0,
                                                                  0.0,
                                                                  Image.asset(
                                                                    recommendationtList[index].stage ==
                                                                            "Requested"
                                                                        ? "assets/newDesignIcon/navigation/edit_circle.png"
                                                                        : recommendationtList[index].stage ==
                                                                                "Replied"
                                                                            ? "assets/newDesignIcon/navigation/right_circle.png"
                                                                            : recommendationtList[index].isActive == "true"
                                                                                ? "assets/newDesignIcon/navigation/unhide.png"
                                                                                : "assets/newDesignIcon/navigation/hide.png",
                                                                    height:
                                                                        35.0,
                                                                    width: 35.0,
                                                                  )),
                                                          onTap: () {
                                                            if (recommendationtList[
                                                                        index]
                                                                    .stage ==
                                                                "Replied") {
                                                              if (Util.dobCheck(widget
                                                                      .profileInfoModal
                                                                      .dob) &&
                                                                  widget.profileInfoModal
                                                                          .publicUrl !=
                                                                      null &&
                                                                  widget.profileInfoModal
                                                                          .publicUrl !=
                                                                      "null" &&
                                                                  widget.profileInfoModal
                                                                          .publicUrl !=
                                                                      "") {
                                                                conformationDialogForCommunityPost(
                                                                    recommendationtList[
                                                                        index]);
                                                              } else {
                                                                apiCallForAddRecommendation(
                                                                    recommendationtList[
                                                                        index],
                                                                    false);
                                                              }
                                                            } else if (recommendationtList[
                                                                        index]
                                                                    .stage ==
                                                                "Requested") {
                                                              onTapEditRecommendation(
                                                                  recommendationtList[
                                                                      index]);
                                                            } else if (recommendationtList[
                                                                        index]
                                                                    .isActive ==
                                                                "true") {
                                                              apiCallForUpdateRecommendationStatus(
                                                                  recommendationtList[
                                                                      index],
                                                                  false,
                                                                  index);
                                                            } else {
                                                              apiCallForUpdateRecommendationStatus(
                                                                  recommendationtList[
                                                                      index],
                                                                  true,
                                                                  index);
                                                            }
                                                          },
                                                        ),
                                                        recommendationtList[
                                                                        index]
                                                                    .stage ==
                                                                "Added"
                                                            ? InkWell(
                                                                child: PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        4.0,
                                                                        3.0,
                                                                        8.0,
                                                                        0.0,
                                                                        Text(
                                                                          recommendationtList[index].isActive == "true"
                                                                              ? "Hide"
                                                                              : "Unhide",
                                                                          style: TextStyle(
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 16,
                                                                              color: ColorValues.search_error_text),
                                                                        )),
                                                                onTap: () {
                                                                  apiCallForUpdateRecommendationStatus(
                                                                      recommendationtList[
                                                                          index],
                                                                      false,
                                                                      index);
                                                                },
                                                              )
                                                            : recommendationtList[
                                                                            index]
                                                                        .stage ==
                                                                    "Replied"
                                                                ? InkWell(
                                                                    child: PaddingWrap
                                                                        .paddingfromLTRB(
                                                                            4.0,
                                                                            3.0,
                                                                            8.0,
                                                                            0.0,
                                                                            Text(
                                                                              "Publish",
                                                                              style: TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR, fontWeight: FontWeight.w400, fontSize: 16, color: ColorValues.BLUE_COLOR),
                                                                            )),
                                                                    onTap: () {
                                                                      apiCallForAddRecommendation(
                                                                          recommendationtList[
                                                                              index],
                                                                          false);
                                                                    },
                                                                  )
                                                                : Container(
                                                                    height: 0,
                                                                  ),
                                                      ],
                                                    ),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: InkWell(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                        0.0,
                                                        3.0,
                                                        0.0,
                                                        0.0,
                                                        Image.asset(
                                                          "assets/newDesignIcon/navigation/cancel_circle.png",
                                                          height: 35.0,
                                                          width: 35.0,
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        confromationDialog(
                                                            recommendationtList[
                                                                    index]
                                                                .recommendationId,
                                                            index);
                                                      },
                                                    ),
                                                    flex: 0,
                                                  )
                                                ],
                                              )),
                                          recommendationtList[index].stage ==
                                                  "Requested"
                                              ? recommendationtList[index]
                                                          .showReminderTimer ==
                                                      true
                                                  ? Container(
                                                      padding: EdgeInsets.only(
                                                          top: 8),
                                                      alignment:
                                                          Alignment.topLeft,

                                                      child: Text(
                                                        "Reminder sent. You can send another reminder on " +
                                                            Util.getConvertedDateStampNewSlash(
                                                                recommendationtList[
                                                                        index]
                                                                    .reminderDay
                                                                    .toString()),
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.start,
                                                        maxLines: 3,
                                                        style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          color: ColorValues
                                                              .circle4,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR,
                                                        ),
                                                      ),
                                                    )
                                                  : Container(
                                                      height: 0,
                                                    )
                                              : Container(
                                                  height: 0,
                                                ),
                                          recommendationtList[index].stage == "Added"||   recommendationtList[index].stage=="Replied"
                                              ? Expanded(
                                                  flex: 0,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 5,
                                                            left: 3.0,
                                                            right: 0),
                                                    child: Text(
                                                      recommendationtList[index]
                                                          .recommendation,
                                                      maxLines:
                                                          recommendationtList[
                                                                      index]
                                                                  .isMore
                                                              ? 25
                                                              : 3,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                        fontSize: 16,
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR,
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              : Expanded(
                                                  flex: 0,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 5,
                                                            left: 3.0,
                                                            right: 0),
                                                    child: Text(
                                                      recommendationtList[index].request,
                                                      maxLines:
                                                          recommendationtList[
                                                                      index]
                                                                  .isMore
                                                              ? 35
                                                              : 3,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 15,
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                          recommendationtList[index].stage ==
                                                  "Added"
                                              ? recommendationtList[index]
                                                          .recommendation
                                                          .length >
                                                      100
                                                  ? InkWell(
                                                      child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  top: 0.0,
                                                                  left: 3.0,
                                                                  right: 0),
                                                          child: Text(
                                                            recommendationtList[
                                                                        index]
                                                                    .isMore
                                                                ? "Less"
                                                                : "More",
                                                            maxLines: 1,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontSize: 16,
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR,
                                                            ),
                                                          )),
                                                      onTap: () {
                                                        if (recommendationtList[
                                                                index]
                                                            .isMore)
                                                          recommendationtList[
                                                                  index]
                                                              .isMore = false;
                                                        else
                                                          recommendationtList[
                                                                  index]
                                                              .isMore = true;

                                                        setState(() {
                                                          recommendationtList[
                                                                  index]
                                                              .isMore;
                                                        });
                                                      },
                                                    )
                                                  : Container(
                                                      height: 0.0,
                                                    )
                                              : recommendationtList[index]
                                                          .request
                                                          .length >
                                                      100
                                                  ? InkWell(
                                                      child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  top: 0.0,
                                                                  left: 3.0,
                                                                  right: 0),
                                                          child: Text(
                                                            recommendationtList[
                                                                        index]
                                                                    .isMore
                                                                ? "Less"
                                                                : "More",
                                                            maxLines: 1,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontSize: 16,
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR,
                                                            ),
                                                          )),
                                                      onTap: () {
                                                        if (recommendationtList[
                                                                index]
                                                            .isMore)
                                                          recommendationtList[
                                                                  index]
                                                              .isMore = false;
                                                        else
                                                          recommendationtList[
                                                                  index]
                                                              .isMore = true;

                                                        setState(() {
                                                          recommendationtList[
                                                                  index]
                                                              .isMore;
                                                        });
                                                      },
                                                    )
                                                  : Container(
                                                      height: 0.0,
                                                    ),
                                          recommendationtList[index]
                                                          .recommenderFile !=
                                                      "null" &&
                                                  recommendationtList[index]
                                                          .recommenderFile !=
                                                      ""
                                              ? PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  18.0,
                                                  8.0,
                                                  5.0,
                                                  InkWell(
                                                      onTap: () {
                                                        launch(Constant
                                                                .IMAGE_PATH +
                                                            recommendationtList[
                                                                    index]
                                                                .recommenderFile);
                                                      },
                                                      child: Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          Expanded(
                                                              child: Image.asset(
                                                                  "assets/added_pdf.png",
                                                                  height: 56,
                                                                  width: 56),
                                                              flex: 0),
                                                          Expanded(
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            10.0,
                                                                        bottom:
                                                                            8.0),
                                                                child: TextViewWrap.textViewMultiLine(
                                                                    recommendationtList[
                                                                            index]
                                                                        .recommenderFileName,
                                                                    TextAlign
                                                                        .start,
                                                                    ColorValues
                                                                        .BLUE_COLOR_BOTTOMBAR,
                                                                    14.0,
                                                                    FontWeight
                                                                        .normal,
                                                                    1),
                                                              ),
                                                              flex: 1)
                                                        ],
                                                      )))
                                              : Container(
                                                  height: 0.0,
                                                ),


                                          PaddingWrap.paddingfromLTRB(
                                              3.0,
                                             0.0,
                                              0.0,
                                              0.0,
                                              Row(
                                                children: <Widget>[
                                                  recommendationtList[index]
                                                                  .recommender
                                                                  .firstName !=
                                                              "null" ||
                                                          recommendationtList[
                                                                      index]
                                                                  .recommender
                                                                  .firstName !=
                                                              ""
                                                      ? Text(
                                                          recommendationtList[
                                                                      index]
                                                                  .recommender
                                                                  .firstName .trim()+
                                                              " " +
                                                              recommendationtList[
                                                                      index]
                                                                  .recommender
                                                                  .lastName.trim(),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.start,
                                                          style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontSize: 14.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMBOLD),
                                                        )
                                                      : Container(
                                                          height: 0,
                                                        ),
                                                ],
                                              )),
                                          recommendationtList[index]
                                                          .level3Competency ==
                                                      "null" ||
                                                  recommendationtList[index]
                                                          .level3Competency ==
                                                      ""
                                              ? PaddingWrap.paddingfromLTRB(
                                                  3.0,
                                                  0.0,
                                                  8.0,
                                                  10.0,
                                                  Row(
                                                    children: <Widget>[
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              0.0,
                                                              0.0,
                                                              8.0,
                                                              2.0,
                                                              Text(
                                                                recommendationtList[
                                                                        index]
                                                                    .recommender
                                                                    .title,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        12.0,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              )),
                                                      recommendationtList[index]
                                                                      .stage ==
                                                                  "Replied" ||
                                                              recommendationtList[
                                                                          index]
                                                                      .stage ==
                                                                  "Requested"
                                                          ? Expanded(
                                                              child: Text(
                                                                "Sent On: " +
                                                                    Util.getConvertedDateStampNew(
                                                                        recommendationtList[index]
                                                                            .requestedDate),
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .end,
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR,
                                                                    fontSize:
                                                                        12.0,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              ),
                                                              flex: 1,
                                                            )
                                                          : Expanded(
                                                              child: Text(
                                                                recommendationtList[index]
                                                                            .type ==
                                                                        "self"
                                                                    ? "" +
                                                                        Util.getConvertedDateStampNew(recommendationtList[index]
                                                                            .requestedDate)
                                                                    : "Sent On: " +
                                                                        Util.getConvertedDateStampNew(
                                                                            recommendationtList[index].requestedDate),
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .end,
                                                                maxLines: 2,
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR,
                                                                    fontSize:
                                                                        12.0,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              ),
                                                              flex: 1,
                                                            )
                                                    ],
                                                  ))
                                              : PaddingWrap.paddingfromLTRB(
                                                  3.0,
                                                  0.0,
                                                  8.0,
                                                  2.0,
                                                  Text(
                                                    recommendationtList[index]
                                                        .recommender
                                                        .title,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.start,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        fontSize: 12.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  )),
                                          recommendationtList[index]
                                                          .level3Competency ==
                                                      "null" ||
                                                  recommendationtList[index]
                                                          .level3Competency ==
                                                      ""
                                              ? Container(
                                                  height: 0,
                                                )
                                              : PaddingWrap.paddingfromLTRB(
                                                  3.0,
                                                  0.0,
                                                  8.0,
                                                  10.0,
                                                  Row(
                                                    children: <Widget>[
                                                      Expanded(
                                                        child: Text(
                                                          "For: ",
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.start,
                                                          style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontSize: 12.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                        ),
                                                        flex: 0,
                                                      ),
                                                      Expanded(
                                                        child: Text(
                                                          recommendationtList[
                                                                  index]
                                                              .level3Competency,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.start,
                                                          style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontSize: 12.0,
                                                              fontFamily: Constant
                                                                  .customBold),
                                                        ),
                                                        flex: 0,
                                                      ),
                                                      recommendationtList[index]
                                                                      .stage ==
                                                                  "Replied" ||
                                                              recommendationtList[
                                                                          index]
                                                                      .stage ==
                                                                  "Requested"
                                                          ? Expanded(
                                                              child: Text(
                                                                "Sent On: " +
                                                                    Util.getConvertedDateStampNew(
                                                                        recommendationtList[index]
                                                                            .requestedDate),
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .end,
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR,
                                                                    fontSize:
                                                                        12.0,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              ),
                                                              flex: 1,
                                                            )
                                                          : Expanded(
                                                              child: Text(
                                                                recommendationtList[index]
                                                                            .type ==
                                                                        "self"
                                                                    ? "" +
                                                                        Util.getConvertedDateStampNew(recommendationtList[index]
                                                                            .requestedDate)
                                                                    : "Sent On: " +
                                                                        Util.getConvertedDateStampNew(
                                                                            recommendationtList[index].requestedDate),
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .end,
                                                                maxLines: 2,
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR,
                                                                    fontSize:
                                                                        12.0,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              ),
                                                              flex: 1,
                                                            )
                                                    ],
                                                  )),
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              10.0,
                                              8.0,
                                              0.0,
                                              Container(
                                                height: 1.0,
                                                color: ColorValues
                                                    .GREY__COLOR_DIVIDER,
                                              ))
                                        ],
                                      ),
                                    );
                                  }),
                            )),

              RefreshIndicator(
                onRefresh: onRefreshPending,
                displacement: 0.0,
                child:  isDataLoadingPending
                    ? Padding(
                  padding: const EdgeInsets.only(top:20.0),
                  child: Container(
                    // width: 349,
                    height: 336,

                    margin: const EdgeInsets.only(left:16.0, right: 16.0,),
                    padding: const EdgeInsets.only(left:16.0, right: 16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: ColorValues.GREY__COLOR_DIVIDER,),
                    ),
                    child: Center(
                      child:  Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                              width: 250.0,
                              height: 180.0,
                              child:  PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Image.asset(
                                    "assets/recommendation/pending_re.png",
                                  ))),
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              15.0,
                              0.0,
                              0.0, Text(
                            MessageConstant
                                .RECOMMENDATION_PENDING_NO_DATA,
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            style: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontFamily:
                                Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 16,
                                color: ColorValues.GREY__COLOR),
                          )),
                        ],

                      ),
                    ),
                  ),
                ): getRequestedUi())
                ],
              )),
        ));
  }

  dataReresh() async {
    setState(() {
      skip = 0;
      skipPending = 0;
      skipReplie = 0;
      recommendationtList.clear();
      approvedRecommendationtList.clear();
      requestedRecommendationtList.clear();
    });
    recommendationApi();
    recommendationReplideApi();
    recommendationPendingApi();
    apiRecommendationCount();
  }

  //--------------------------Recommendation Info api ------------------

  Future recommendationApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;


          response = await ApiCalling().apiCall(
              context,
              Constant.RECOMMENDATIONBYTYPE +
                  "userId=" +
                  widget.userId +
                  "&type=request&skip=" +
                  skip.toString(),
              "get");


        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              bloc.fetcprofileData(userIdPref, context, prefs, true);
              if (widget.screenName == "notification") {
                setState(() {
                  recommendationtList.clear();
                });
              }

              try {
                recommendationtList.addAll(ParseJson.parseMapRecommdation(
                    response.data['result'], widget.isEditable));


                if (!recommendationtList.isEmpty) {
                  setState(() {
                    isDataLoadingRequest = false;
                  });
                } else {
                  setState(() {
                    isDataLoadingRequest = true;
                  });
                }

                setState(() {
                  recommendationtList;
                });
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AllRecommendationListPerformance", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future recommendationReplideApi() async {
    try {
      print("userId rec" + widget.userId);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            Constant.RECOMMENDATIONBYTYPE +
                "userId=" +
                widget.userId +
                "&type=replied&skip=" +
                skipReplie.toString(),
            "get");
        if (response != null) {
          if (response.statusCode == 200) {
            // MessageConstant.printWrapped("recommendationReplideApi..." + response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              try {
                approvedRecommendationtList.addAll(
                    ParseJson.parseMapRecommdation(
                        response.data['result'], true));

                if (!approvedRecommendationtList.isEmpty) {
                  setState(() {
                    isDataLoadingReplied = false;
                  });
                } else {
                  setState(() {
                    isDataLoadingReplied = true;
                  });
                }
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AllRecommendationListPerformance", context);
              }

              setState(() {
                approvedRecommendationtList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future recommendationPendingApi() async {
    try {
      print("userId rec" + widget.userId);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            Constant.RECOMMENDATIONBYTYPE +
                "userId=" +
                widget.userId +
                "&type=pending&skip=" +
                skipPending.toString(),
            "get");
        if (response != null) {
          if (response.statusCode == 200) {
            MessageConstant.printWrapped(
                "recommendationPendingApi..." + response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              try {
                requestedRecommendationtList.addAll(
                    ParseJson.parseMapRecommdation(
                        response.data['result'], true));

                if (!requestedRecommendationtList.isEmpty) {
                  setState(() {
                    isDataLoadingPending = false;
                  });
                } else {
                  setState(() {
                    isDataLoadingPending = true;
                  });
                }
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AllRecommendationListPerformance", context);
              }

              setState(() {
                requestedRecommendationtList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  void conformationDialogForCommunityPost(recommendation) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    MessageConstant
                                                        .ADD_RECOMMENDATION_PUBLISH_RECOMMENDATION,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.NO,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallForAddRecommendation(
                                                  recommendation, false);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.YES,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallForAddRecommendation(
                                                  recommendation, true);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallForAddRecommendation(recommendation, addIntoProfile) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "recommendationId": int.parse(recommendation.recommendationId),
          "stage": "Added",
          "isActive": true,
          "addIntoProfile": addIntoProfile
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_RECOMMENDATION, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              isPerformChanges = "push";

              dataReresh();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiForReminder(String recommendationId, int index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": userIdPref,
          "roleId": roleId,
          "recommendationId": recommendationId,
          "notificationId": ""
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_SEND_REMINDER, map);
        print("apiForReminder:----------" +
            Constant.ENDPOINT_SEND_REMINDER +
            map.toString());
        print("apiForReminder:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              String reminderDay =
                  response.data['result']['reminderDay'].toString();
              print("result/////////////:-" + reminderDay.toString());
              setState(() {
                setState(() {
                  recommendationtList[index].isReminderEnable = "false";
                  recommendationtList[index].showReminderTimer = true;
                  recommendationtList[index].reminderDay = reminderDay;
                });

                Future.delayed(Duration(seconds: 20), () {
                  setState(() {
                    recommendationtList[index].showReminderTimer = false;
                  });
                });
              });
            }else {
              ToastWrap.showToasSucess(
                  msg,
                  context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

/*  {"status":"Success","result":{"requestedCount":7,"myRepliedReq":0,"myPendingReq":2}}*/
  Future apiRecommendationCount() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_RECOMMENDATIONCount +
                "userId=" +
                widget.userId +
                "&roleId=" +
                roleId,
            "get");

        print("requestedCount//////" + response.toString());
        print("requestedCount//////" + response.data['result'].toString());
        if (response != null) {
          if (response.statusCode == 200) {
            setState(() {
              strRequestCount =
                  response.data['result']['requestedCount'].toString();
              strRepliedCount =
                  response.data['result']['myRepliedReq'].toString();
              strPendingRCount =
                  response.data['result']['myPendingReq'].toString();
            });

            print("strRequestCount//////" +
                strRequestCount +
                strRepliedCount +
                strPendingRCount);
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForUpdateRecommendationStatus(
      recommendation, isHide, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "recommendationId": int.parse(recommendation.recommendationId),
          "isActive": isHide
        };
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_RECOMMENDATION, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast("Recommendation Added Successfully");
              // recommendation.stag = "Added";
              print("called");

              bloc.fetcprofileData(userIdPref, context, prefs, true);
              if (recommendationtList[index].isActive == "true") {
                setState(() {
                  recommendationtList[index].isActive = "false";
                });
              } else {
                setState(() {
                  recommendationtList[index].isActive = "true";
                });
              }

              isPerformChanges = "push";
              setState(() {
                recommendationtList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  _buildChoiceList(type) {
    List<Widget> choices = List();

    choices.add(Container(
        padding: const EdgeInsets.all(0.0),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15.0),
            color: type == MessageConstant.ABOUT_GROUP_REQUESTED
                ? Color(0xFFDDD74A)
                : type == "Replied"
                    ? ColorValues.BUTTON_PENDING
                    : Color(0xFF3D9B6E),
          ),
          padding: EdgeInsets.fromLTRB(15.0, 5.0, 15.0, 5.0),
          child: Text(
            type == MessageConstant.ABOUT_GROUP_REQUESTED
                ? "REQUESTED"
                : type == "Replied"
                    ? "PENDING"
                    : "ACTIVE",
            style: TextStyle(
                color: Colors.white,
                fontSize: 12.0,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
          ),
        )));

    return choices;
  }

  onTapAddRecommendation() async {
    final result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => AddRecommendationPerformance(
            widget.sasToken,
            profileInfoModal.email,
            profileInfoModal.lastName == "" ||
                    profileInfoModal.lastName == "null"
                ? profileInfoModal.firstName
                : profileInfoModal.firstName + " " + profileInfoModal.lastName,
            profileInfoModal)));
    if (result == "push") {
      isPerformChanges = "push";
      dataReresh();
    }
  }

  onTapEditRecommendation(recommendation) async {
    final result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => EditRecommendationPerformance(
            widget.sasToken,
            recommendation,
            profileInfoModal.email,
            profileInfoModal.lastName == "" ||
                    profileInfoModal.lastName == "null"
                ? profileInfoModal.firstName
                : profileInfoModal.firstName + " " + profileInfoModal.lastName,
            profileInfoModal)));
    if (result == "push") {
      isPerformChanges = "push";
      dataReresh();
    }
  }

  onTapRecommendation(recommendation) async {
    final result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            RecommendationReuest(recommendation)));
    if (result == "push") {
      isPerformChanges = "push";
      dataReresh();
    }
  }

  onTapRecommendationRepilied(Recomdation recommendation) async {
    print("recommendation///////////" + recommendation.user.tagline);
    final result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            RecommendationReuestReplied(recommendation)));
    if (result == "push") isPerformChanges = "push";
  }

  Widget getApprovedUi() {
    return RefreshIndicator(
        onRefresh: onRefreshReplie,
        displacement: 0.0,
        child: Container(

            /*Padding(
            padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 10.0),
            child: Column(
                children:

            ListView.builder(
    physics: AlwaysScrollableScrollPhysics(),
    controller: _scrollController,
    itemCount: approvedRecommendationtList.length,
    itemBuilder:
    (BuildContext context, int index) {
    positionOfChild = index;


    )))*/
            child: ListView.builder(
                physics: AlwaysScrollableScrollPhysics(),
                controller: _scrollControllerReplie,
                itemCount: approvedRecommendationtList.length,
                itemBuilder: (BuildContext context, int index) {
                  positionOfReplied = index;
                  return InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        0.0,
                        Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                    color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                                    width: 0.5)),
                            child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        11.0,
                                        0.0,
                                        10.0,
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Row(
                                              children: <Widget>[
                                                Expanded(
                                                  child: Stack(
                                                    children: <Widget>[
                                                      InkWell(
                                                        child: ClipOval(
                                                            child: FadeInImage
                                                                .assetNetwork(
                                                          fit: BoxFit.cover,
                                                          width: 50.0,
                                                          height: 50.0,
                                                          placeholder:
                                                              'assets/profile/user_on_user.png',
                                                          image: Constant
                                                                  .IMAGE_PATH_SMALL +
                                                              ParseJson.getMediumImage(
                                                                  approvedRecommendationtList[
                                                                          index]
                                                                      .user
                                                                      .profilePicture),
                                                        )),
                                                        onTap: () {
                                                          if (approvedRecommendationtList[
                                                                      index]
                                                                  .userId ==
                                                              userIdPref) {
                                                          } else {
                                                            Util.onTapImageTile(
                                                                tapedUserRole:
                                                                    approvedRecommendationtList[
                                                                            index]
                                                                        .recomendedRoleId,
                                                                partnerUserId:
                                                                    approvedRecommendationtList[
                                                                            index]
                                                                        .userId,
                                                                context:
                                                                    context);
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: <Widget>[
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                                8.0,
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                RichText(
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  text:
                                                                      TextSpan(
                                                                    text: MessageConstant
                                                                        .ADD_RECOMMENDATION_FROM,
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                    children: <
                                                                        TextSpan>[
                                                                      TextSpan(
                                                                        text: approvedRecommendationtList[index].user.lastName ==
                                                                                "null"
                                                                            ? approvedRecommendationtList[index]
                                                                                .user
                                                                                .firstName
                                                                            : approvedRecommendationtList[index].user.firstName +
                                                                                " " +
                                                                                approvedRecommendationtList[index].user.lastName,
                                                                        style: TextStyle(
                                                                            color: ColorValues
                                                                                .HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            fontFamily: Constant.customBold),
                                                                      )
                                                                    ],
                                                                  ),
                                                                )),
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                                7.0,
                                                                3.0,
                                                                0.0,
                                                                0.0,
                                                                PaddingWrap
                                                                    .paddingAll(
                                                                  2.0,
                                                                  TextViewWrap.textView(
                                                                      "View Request",
                                                                      TextAlign
                                                                          .start,
                                                                      ColorValues
                                                                          .BLUE_COLOR_BOTTOMBAR,
                                                                      12.0,
                                                                      FontWeight
                                                                          .normal),
                                                                )),
                                                      ],
                                                    ),
                                                    flex: 1),
                                              ],
                                            ),
                                          ],
                                        )),
                                  ),
                                ]))),
                    onTap: () {
                      print(approvedRecommendationtList[index].user.tagline);
                      onTapRecommendationRepilied(
                          approvedRecommendationtList[index]);
                    },
                  );
                })));
  }

  Future apiCallingForDeleteRecommendation(recommendationId, index) async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "recommendationId": recommendationId,
      };

      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_DELETE_RECOMMENDATION_New, map);
      CustomProgressLoader.cancelLoader(context);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isPerformChanges = "push";
            recommendationtList.removeAt(index);

            setState(() {
              recommendationtList;
            });

            if (recommendationtList.length == 0) {
              setState(() {
                isDataLoadingRequest = true;
              });
            }

            apiRecommendationCount();
            bloc.fetcprofileData(userIdPref, context, prefs, true);
            /*if (recommendationtList.length == 0) {
              Navigator.pop(context, "push");
            }*/
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Widget getRequestedUi() {
    return  Container(
            child: ListView.builder(
                physics: AlwaysScrollableScrollPhysics(),
                controller: _scrollControllerPending,
                itemCount: requestedRecommendationtList.length,
                itemBuilder: (BuildContext context, int index) {
                  positionOfPending = index;
                  return InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        0.0,
                        Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                    color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                                    width: 0.5)),
                            child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        11.0,
                                        0.0,
                                        10.0,
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Row(
                                              children: <Widget>[
                                                Expanded(
                                                  child: Stack(
                                                    children: <Widget>[
                                                      InkWell(
                                                        child: ClipOval(
                                                            child: FadeInImage
                                                                .assetNetwork(
                                                          fit: BoxFit.cover,
                                                          width: 50.0,
                                                          height: 50.0,
                                                          placeholder:
                                                              'assets/profile/user_on_user.png',
                                                          image: Constant
                                                                  .IMAGE_PATH_SMALL +
                                                              ParseJson.getMediumImage(
                                                                  requestedRecommendationtList[
                                                                          index]
                                                                      .user
                                                                      .profilePicture),
                                                        )),
                                                        onTap: () {
                                                          print("approvedRecommendationtList............" +
                                                              requestedRecommendationtList[
                                                                      index]
                                                                  .userId);
                                                          if (requestedRecommendationtList[
                                                                      index]
                                                                  .userId ==
                                                              userIdPref) {
                                                          } else {
                                                            Util.onTapImageTile(
                                                                tapedUserRole:
                                                                    requestedRecommendationtList[
                                                                            index]
                                                                        .recomendedRoleId,
                                                                partnerUserId:
                                                                    requestedRecommendationtList[
                                                                            index]
                                                                        .userId,
                                                                context:
                                                                    context);
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: <Widget>[
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                          8.0,
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          RichText(
                                                            textAlign: TextAlign
                                                                .center,
                                                            text: TextSpan(
                                                              text: MessageConstant
                                                                  .ADD_RECOMMENDATION_FROM,
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .HEADING_COLOR_EDUCATION,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      14.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                              children: <
                                                                  TextSpan>[
                                                                TextSpan(
                                                                  text: requestedRecommendationtList[index]
                                                                              .user
                                                                              .lastName ==
                                                                          "null"
                                                                      ? requestedRecommendationtList[
                                                                              index]
                                                                          .user
                                                                          .firstName
                                                                      : requestedRecommendationtList[index]
                                                                              .user
                                                                              .firstName +
                                                                          " " +
                                                                          requestedRecommendationtList[index]
                                                                              .user
                                                                              .lastName,
                                                                  style: TextStyle(
                                                                      color: ColorValues
                                                                          .HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                      fontFamily:
                                                                          Constant
                                                                              .customBold),
                                                                )
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                                7.0,
                                                                3.0,
                                                                0.0,
                                                                0.0,
                                                                PaddingWrap
                                                                    .paddingAll(
                                                                  2.0,
                                                                  TextViewWrap.textView(
                                                                      "View Request",
                                                                      TextAlign
                                                                          .start,
                                                                      ColorValues
                                                                          .BLUE_COLOR_BOTTOMBAR,
                                                                      12.0,
                                                                      FontWeight
                                                                          .normal),
                                                                )),
                                                      ],
                                                    ),
                                                    flex: 1),
                                              ],
                                            ),
                                          ],
                                        )),
                                  ),
                                ]))),
                    onTap: () {
                      onTapRecommendation(requestedRecommendationtList[index]);
                    },
                  );
                }) /*Padding(
            padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 10.0),
            child: Column(
                children: )*/
            );
  }

  void confromationDialog(id, index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    bottomNavigationBar: Container(
                      height: 0.0,
                    ),
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    MessageConstant
                                                        .ADD_RECOMMENDATION_REMOVE_RECOMMENDATION,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.only(
                                        top: 10.0, left: 10.0, right: 10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.CANCEL,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.REMOVE,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallingForDeleteRecommendation(
                                                  id, index);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  showSucessMsg(String date) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Image.asset(
                "assets/recommendation/reminder_info.png",
                height: 80.0,
                width: 79.0,
              ),
              SizedBox(height: 12.0),
              Text(
                "You can send another reminder on " + date,
                textAlign: TextAlign.center,
                maxLines: 3,
                style: TextStyle(
                    fontSize: 16.0,
                    color: ColorValues.riminderColor,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontWeight: FontWeight.w400),
              ),
              Padding(
                  padding: EdgeInsets.only(
                      left: 20.0, top: 20.0, right: 20.0, bottom: 15.0),
                  child: InkWell(
                    child: Container(
                        height: 40.0,
                        width: 60.0,
                        color: ColorValues.BLUE_COLOR,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              MessageConstant.OK,
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 20.0,
                              ),
                            )
                          ],
                        )),
                    onTap: () {
                      Navigator.of(context).pop(true);
                    },
                  ))
            ],
          ),
        );
      },
    );
  }


}
