import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

class AllParentList extends StatefulWidget {
  List<Parents> friendList;
  String studentId;
  ProfileInfoModal profileInfoModal;

  AllParentList(this.friendList, this.profileInfoModal, this.studentId);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return AllParentListState(friendList);
  }
}

class AllParentListState extends State<AllParentList> {
  List<Parents> friendList;

  AllParentListState(this.friendList);

  List<InkWell> _buildSearchList2() {
    return List.generate(friendList.length, (int index) {
      return InkWell(
          child: PaddingWrap.paddingfromLTRB(
              20.0,
              10.0,
              13.0,
              10.0,
              Row(
                children: <Widget>[
                  Expanded(
                    child: ProfileImageView(
                      imagePath: Constant.IMAGE_PATH_SMALL +
                          ParseJson.getSmallImage(
                              friendList[index].profilePicture),
                      placeHolderImage: 'assets/profile/user_on_user.png',
                      height: 50.0,
                      width: 50.0,
                      onTap: () async {},
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        0.0,
                        0.0,
                        0.0,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            BaseText(
                              text: friendList[index].email != "null"
                                  ? friendList[index].lastName != "null"
                                      ? friendList[index].firstName +
                                          " " +
                                          friendList[index].lastName
                                      : friendList[index].firstName
                                  : "",
                              textColor:
                                  ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                              textAlign: TextAlign.start,
                              maxLines: 1,
                            ),
                          ],
                        )),
                    flex: 1,
                  ),
                ],
              ),
          ),
          onTap: () {},
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return customAppbar(
      context,
      Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 20.0, right: 20, top: 24, bottom: 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    BaseText(
                      text: 'Authorized parent(s)',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      textAlign: TextAlign.start,
                      maxLines: 3,
                    ),
                  ],
                ),
              ),
              flex: 0,
            ),
            Expanded(
              child: friendList.length > 0
                  ? ListView(
                      children: <Widget>[
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: _buildSearchList2())
                      ],
                    )
                  : SizedBox(),
              flex: 1,
            ),
          ],
        ),
      ),
      () {
        Navigator.pop(context);
      },
      isShowIcon: false,
    );
  }
}
