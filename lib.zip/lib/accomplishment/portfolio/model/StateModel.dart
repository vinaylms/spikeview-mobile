import 'package:flutter/material.dart';
class StateModel {
  //TimeBetween toFromTime;
  String position = "";
  String lable = "";
  String value = "";
  TextEditingController positionController, lableController,valueController;

  StateModel({this.position, this.lable, this.value, this.positionController,
      this.lableController, this.valueController});

  Map<String, dynamic> toJson() => {
    "playingPosition": this.positionController.text==null?"":this.positionController.text,
    "label": this.lableController.text==null?"":this.lableController.text,
    "value": this.valueController.text==null?"":this.valueController.text,

  };

}