import 'dart:async';
import 'package:flutter/material.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/badges/new_badges/badges_manage_student_notification.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges_notification.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/ProfileVisibilitySetting.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/OpportunityViewOnNotificationClick.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/notification/boat_report/FeedReportWidgetBoat.dart';
import 'package:spike_view_project/notification/OpportunityForBoat.dart';
import 'package:spike_view_project/notification/boat_report/StudentProfileReportWidgetBoat.dart';
import 'package:spike_view_project/notification/model/NotificationModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicViewForUser.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PartnerRejectionReason.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForBoatReview.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/recommendation/SharedRecoomendAtion.dart';
import 'package:spike_view_project/recommendation/manageRecommendation/Manage_Recommendation_dashbaord.dart';
import 'package:spike_view_project/recommendation/manageRecommendation/notification_manage_recommendation.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';

import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/notification/opportunityRejected.dart';

import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:url_launcher/url_launcher.dart';

import 'FeedDetailWidget.dart';
import 'FeedDetailWidgetForBoat.dart';
import 'NotificationSetting.dart';

import 'boat_report/GroupReportWidgetBoat.dart';

class NotificationWidget extends StatefulWidget {
  String isActive = "false";
  bool isPartnerApprovedByAdmin = false;

  NotificationWidget({this.isActive, this.isPartnerApprovedByAdmin});

  @override
  State<StatefulWidget> createState() => NotificationWidgetState();
}

class NotificationWidgetState extends State<NotificationWidget> {
  List<NotificationModel> dataList = List();
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isLoading = true;
  bool isDataLoading = false;
  ShareProfileModal shareProfileModal;
  bool isLoadMore = true;
  int offset = 0;

  bool isPartnerApprovedByAdmin = false;
  ProfileDataModel itemModel1;


  bool isFeed_AccessControl = true;
  bool isGroup_AccessControl = true;
  bool isChat_AccessControl = true;
  bool isConnection_AccessControl = true;
  bool isProfileVisible = true;

  getSharedPreferences() async {
    setState(() {
      isDataLoading = true;
    });
    isUserRepoted = UserPreference.getIsUserReported();
    prefs = await SharedPreferences.getInstance();
    if (prefs.getBool(UserPreference.IS_PARTNER_ACTIVE) != null &&
        prefs.getBool(UserPreference.IS_PARTNER_ACTIVE)) {
      isPartnerApprovedByAdmin = true;
    } else
      isPartnerApprovedByAdmin = false;
    print(
        'inside initState isPartnerApprovedByAdmin::: $isPartnerApprovedByAdmin');
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    try {
      isFeed_AccessControl = prefs
          .getString(UserPreference.ACCESS_CONTROL_FEED_STATUS)
          .toLowerCase() ==
          "true";
      isGroup_AccessControl =
          prefs.getString(UserPreference.ACCESS_CONTROL_GROUP).toLowerCase() ==
              "true";
      isChat_AccessControl =
      prefs.getString(UserPreference.ACCESS_CONTROL_CHAT).toLowerCase() ==
          "disable"
          ? false
          : true;
      isConnection_AccessControl = prefs
          .getString(UserPreference.ACCESS_CONTROL_CONNECTION)
          .toLowerCase() ==
          "disable"
          ? false
          : true;
      isProfileVisible =
      prefs.getString(UserPreference.ACCESS_CONTROL_PROFILE_VISIBILITY) ==
          "enable"
          ? true
          : false;
    } catch (e) {
      isChat_AccessControl = true;
      isGroup_AccessControl = true;
      isFeed_AccessControl = true;
      isConnection_AccessControl = true;
      isProfileVisible = true;
    }

    await fetchPost();
    callApiForSaas(false);

    setState(() {
      isDataLoading = false;
    });
  }

  String sasToken, containerName;
  bool isUserRepoted = true;

  @override
  void initState() {
    if (widget.isActive == null) {
      widget.isActive = "false";
    }
    super.initState();
    _controller = ScrollController();
    _controller.addListener(_scrollListener);
    getSharedPreferences();
    print("==================== INIT STATE");
  }

  onTapPresoView() async {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await Navigator.pushReplacement(
        Constant.applicationContext,
        MaterialPageRoute(
            //   builder: (context) =>  DashBoardWidget()));
            builder: (context) => SharePresoView23(
                shareProfileModal.profileOwner, shareProfileModal, "main")));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  Future shareIDData(shareId) async {
    try {
      Response response = await ApiCalling()
          .apiCall(context, Constant.ENDPOINT_SHARE_ID + shareId, "get");
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data['message'];
          print(response.toString());
          if (status == "Success") {
            shareProfileModal =
                ParseJson.parseShareProfile(response.data['result']);
            if (shareProfileModal.isActive == "true") {
              if (shareProfileModal.profileOwner != "") {
                if (shareProfileModal.sharedView == "linear") {
                  Navigator.pushReplacement(
                      Constant.applicationContext,
                      MaterialPageRoute(
                          //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) => ShareProfilePage(
                              shareProfileModal.profileOwner,
                              false,
                              "shareProfile",
                              shareProfileModal,
                              "main")));
                } else {
                  onTapPresoView();
                }
              }
            } else {
              ToastWrap.showToast("Your access on this profile has revoked.",
                  Constant.applicationContext);
            }
            return;
          } else {
            ToastWrap.showToast(message, Constant.applicationContext);
          }
        }
      }
    } catch (e) {
      e.toString();
      return;
    }
  }

//==========================================================
  Future apiLoadMode() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {});
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_NOTIFICATION_ALL_NEW +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=" +
                offset.toString(),
            "get");

        isLoading = false;
        setState(() {});
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var _dataList =
                  ParseJson.parseNotification(response.data['result']);
              if (dataList == null || _dataList.length == 0) {
                isLoadMore = false;
                setState(() {});
              }
              if (dataList != null) {
                if (_dataList.length == 0) {
                  isLoadMore = false;
                  setState(() {});
                }
                setState(() {
                  dataList.addAll(_dataList);
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;

      setState(() {});
      e.toString();
    }
  }

  ScrollController _controller = ScrollController();

  _scrollListener() {
    if (_controller.offset >= _controller.position.maxScrollExtent &&
        !_controller.position.outOfRange) {
      offset++;
      if (isLoadMore) {
        apiLoadMode();
      }
    }
  }

  Future fetchPost() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {});
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_NOTIFICATION_ALL_NEW +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=0",
            "get");
        MessageConstant.printWrapped(
            "response data++fetch" + response.toString());
        isLoading = false;
        setState(() {});
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              dataList.clear();
              dataList = ParseJson.parseNotification(response.data['result']);

              if (dataList != null) {
                setState(() {});
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {});
      e.toString();
    }
  }

  Future apiCallingForDeleteFeed(model, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "notificationId": int.parse(model.notificationId),
          "roleId": roleId
        };
        Response response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_NOTIFICATION_DELETE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
//            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              dataList.removeAt(index);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForAccept(groupId, index, type, model) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        /*  Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "status": type
        };*/

        Map map = {
          "groupId": int.parse(groupId),
          "userId": model.type == "ProfileScreen"
              ? int.parse(model.actedBy)
              : int.parse(userIdPref),
          "roleId": model.type == "ProfileScreen"
              ? int.parse(model.actedRoleId)
              : int.parse(roleId),
          "isAdmin": model.type == "ProfileScreen" ? true : false,
          "status": type
        };

        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              setState(() {
                model.reqActionStatus = "Performed";
              });

              ToastWrap.showToasSucess(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    onTapPartnerReview(
        tapedUserId, tapedUserRole, connectionId, String textMessage) {
      if (tapedUserId.toString() == userIdPref.toString()) {
        print(
            "onTapPartnerReview equal++++{$roleId}+++++++{$tapedUserId}++++++");
      } else {
        print("onTapPartnerReview ++++{$roleId}+++++++{$tapedUserId}++++++");
        if (tapedUserRole == "4") {
          Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  PatnerProfileWidgetForBoatReview(
                      tapedUserId, "notification")));
        } else if (roleId == "4" &&
            textMessage ==
                "Your account was not approved. See email for additional details.") {
          print("onTapPartnerReview role id 4");
          Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  PartnerRejectionReason('notification')));
        } else
          print("onTapPartnerReview role id is not 4");
      }
    }

    onTapPartnerResendAccountApproval(
        tapedUserId, tapedUserRole, connectionId, String textMessage) {
      print(
          "onTapPartnerResendAccountApproval roleId:: $roleId, userIdPref:: $userIdPref, tapedUserId::: " +
              tapedUserId +
              " tapedUserRole:::  " +
              tapedUserRole +
              " connectionId::: " +
              connectionId);

      print(
          "onTapPartnerResendAccountApproval ++++{$roleId}+++++++{$tapedUserId}++++++");
      if (roleId == "4") {
        print("onTapPartnerResendAccountApproval role id 4");
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                PartnerRejectionReason('notification')));
      } else
        print("onTapPartnerResendAccountApproval role id is not 4");
    }

    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {
      } else {
        print("onTapImageTile ++++{$roleId}+++++++{$tapedUserId}++++++");
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            pageName: "notification",
            context: context);
      }
    }

    onTapConnectionNotification(tapedUserId, tapedUserRole, connectionId) {
      print("onTapConnectionNotification tapedUserId::: " +
          tapedUserId +
          " tapedUserRole:::  " +
          tapedUserRole +
          " connectionId::: " +
          connectionId);
      if (tapedUserRole == "1") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => UserProfileDashBoardForOther(
                  tapedUserId,
                  false,
                  "notification",
                  "1",
                  connectionId: connectionId,
                )));
      } else if (tapedUserRole == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => ParentProfilePageWithHeader(
                  tapedUserId,
                  "notification",
                  connectionId: connectionId,
                )));
      } else if (tapedUserRole == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => PatnerProfileWidgetForOtherUser(
                  tapedUserId,
                  "notification",
                  connectionId: connectionId,
                )));
      }
    }

    Container getCellItem(NotificationModel model, int index1) {
      return Container(
        padding: EdgeInsets.fromLTRB(20, 16, 20, 16),
        color: model.isRead == "true" ? Colors.white : const Color(0xffF3F5FF),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[



            Expanded(
              child: InkWell(
                child:  ProfileImageView(
                  imagePath:   model.profilePicture == "" ||
                      model.profilePicture == "null"
                      ? ""
                      : Constant.IMAGE_PATH + model.profilePicture,
                  placeHolderImage:  model.actedRoleId  == '4'
                      ? "assets/profile/partner_img.png"
                      : 'assets/profile/user_on_user.png',
                  height: 48.0,
                  width: 48.0,
                  onTap: () async{

                  },
                ),
                onTap: () async {
                  if (widget.isActive == "false" && roleId == "1") {
                    ToastWrap.showToast(
                        MessageConstant
                            .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                        context);
                  } else if (model.type == Constant.UNDER_13_GROUP_SCREEN) {
                    if (!isPartnerApprovedByAdmin && roleId == "4") {
                      ToastWrap.showToastPending(
                          MessageConstant
                              .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                          context);
                    } else {
                      if (isGroup_AccessControl) {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => GroupDetailWidget(
                                model.values, "notification", "", "", "")));
                      } else {
                        ToastWrap.showToastForAccessDenied(
                            MessageConstant.JOIN_GROUP_DISABLE, context);
                      }

                    }
                    // syncDoneController.add("groupPage");
                  } else if (model.type.toString().trim() ==
                      Constant.OPPORTUNITY_DECLINE) {
                    Navigator.of(context).push(new MaterialPageRoute(
                        builder: (BuildContext context) =>
                            opportunityRejected('notification', model.values)));
                  } else if (model.type.toString().trim() ==
                          Constant.OPPORTUNITY_APPROVAL ||
                      model.type.toString().trim() ==
                          Constant.OPPORTUNITY_APPROVED) {
                    Navigator.of(context).push(new MaterialPageRoute(
                        builder: (BuildContext context) => OpportunityForBoat(
                            model.values, roleId, 'notification')));
                  } else if (model.type.toString().trim() ==
                      Constant.FEED_REPORTED) {
                    Navigator.of(context).push(new MaterialPageRoute(
                        builder: (BuildContext context) => FeedReportWidgetBoat(
                            model.values, "notification")));
                  } else if (model.type.toString().trim() ==
                      Constant.GROUP_REPORTED) {
                    if (model.requestId != "null" && model.requestId != "") {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              GroupReportWidgetBoat(model.values,
                                  "notification", model.requestId)));
                    }
                  } else if (model.type.toString().trim() ==
                          Constant.STUDENT_PROFILE_REPORTED ||
                      model.type.toString().trim() == "profileReported") {
                    if (model.requestId != "null" && model.requestId != "") {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              StudentProfileReportWidgetBoat(model.values,
                                  "notification", model.requestId, "1")));
                    }
                  } else if (model.type.toString().trim() ==
                      Constant.PARENT_PROFILE_REPORTED) {
                    if (model.requestId != "null" && model.requestId != "") {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              StudentProfileReportWidgetBoat(model.values,
                                  "notification", model.requestId, "2")));
                    }
                  } else if (model.type.toString().trim() ==
                      Constant.PARTNER_PROFILE_REPORTED) {
                    if (model.requestId != "null" && model.requestId != "") {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              StudentProfileReportWidgetBoat(model.values,
                                  "notification", model.requestId, "4")));
                    }
                  } else if (model.type.toString().trim() ==
                      Constant.UNDER_13_PROFILE_VISIBILITY) {
                    print("acted by ===================++++" +
                        model.actedBy +
                        "  " +
                        model.userId);
                    if (roleId == "2") {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                ProfileVisibilitySetting(model.values, true)),
                      );
                    } else {
                      if (isProfileVisible) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ProfileVisibilitySetting(model.values, false)),
                        );
                      } else {
                        ToastWrap.showToastForAccessDenied(
                            MessageConstant.FEATURE_DIABLED, context);
                      }



                    }
                  } else if (model.type.toString().trim() ==
                          Constant.UNDER_13_FILTER_PAGE &&
                      roleId == "2") {
                    print("roleId++++++" +
                        roleId +
                        "   " +
                        model.actedBy +
                        "   " +
                        model.userId);
                    if (roleId == "2") {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) => PublicViewForUser(
                                "",
                                "chat",
                                "Connected",
                                true,
                                actedUserId: model.actedBy,
                                acteRoleId: "2",
                                profileValue: model.values,
                              )));
                    } else {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) => PublicViewForUser(
                                "",
                                "chat",
                                "Connected",
                                true,
                                actedUserId: model.userId,
                                acteRoleId: "1",
                              )));
                    }
                  } else if (model.type.toString().trim() ==
                          Constant.UNDER_13_TYPE &&
                      roleId == "2") {
                    print("roleId++++++" +
                        roleId +
                        "   " +
                        model.actedBy +
                        "   " +
                        model.userId);
                    if (roleId == "2") {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) => PublicViewForUser(
                                "",
                                "chat",
                                "Connected",
                                true,
                                actedUserId: model.actedBy,
                                acteRoleId: "2",
                                profileValue: model.values,
                              )));
                    } else {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) => PublicViewForUser(
                                "",
                                "chat",
                                "Connected",
                                true,
                                actedUserId: model.userId,
                                acteRoleId: "1",
                              )));
                    }
                  } else if (model.actionValue == "Deleted" &&
                      model.type == "Group") {
                    ToastWrap.showToast(
                        'This group is no longer valid.', context);
                  } else if (model.type == Constant.BADGE_TYPE) {
                    if (roleId == "4") {
                      Navigator.of(Constant.applicationContext).push(
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  PartnerNotificationManageBadges(
                                      "notification",
                                      badgeId: model.values)));
                    } else {
                      if (isConnection_AccessControl) {
                        Navigator.of(context)
                            .popUntil((route) => route.isFirst);
                        syncDoneController.add("connectionPage");
                      } else {
                        ToastWrap.showToastForAccessDenied(
                            MessageConstant.FEATURE_DIABLED, context);
                      }
                    }
                  } else {
                    if (model.type == "SelfProfile") {
                      if (roleId == "2") {
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) =>
                                DashBoardWidgetParent(
                                    prefs.getString(
                                        UserPreference.IS_PARENT_ROLE),
                                    prefs.getString(
                                        UserPreference.IS_PARTNER_ROLE),
                                    prefs.getString(
                                        UserPreference.IS_USER_ROLE))));
                      }
                    } else if (model.type == "partner_approval") {
                      onTapPartnerReview(
                          model.actedBy,
                          model.actedRoleId,
                          model.values == null || model.values == 'null'
                              ? ""
                              : model.values,
                          model.textMessage);
                    } else if (model.type == "partner_decline") {
                      onTapPartnerResendAccountApproval(
                          model.actedBy,
                          model.actedRoleId,
                          model.values == null || model.values == 'null'
                              ? ""
                              : model.values,
                          model.textMessage);
                    }
                    /*else if (model.type == "partner_approved") {

                        }*/
                    else if (model.type == "Profile") {
                      onTapImageTile(model.actedBy, model.actedRoleId);
                    } else if (model.type == "ProfileScreen") {
                      String tapedUserRole = model.actedRoleId;
                      String partnerUserId = model.actedBy;
                      if (tapedUserRole == "1") {
                        String result = await Navigator.of(context).push(
                            new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    UserProfileDashBoardForOther(
                                      partnerUserId,
                                      false,
                                      model.reqActionStatus == "Performed"
                                          ? "ActionPerformed"
                                          : "notification",
                                      "1",
                                      groupId:
                                          model.reqActionStatus == "Performed"
                                              ? null
                                              : model.values,
                                    )));

                        if (result == "push") {
                          model.reqActionStatus = "Performed";
                          setState(() {});
                        }
                      } else if (tapedUserRole == "2") {
                        String result = await Navigator.of(context).push(
                            new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    ParentProfilePageWithHeader(
                                      partnerUserId,
                                      model.reqActionStatus == "Performed"
                                          ? "ActionPerformed"
                                          : "notification",
                                      groupId:
                                          model.reqActionStatus == "Performed"
                                              ? null
                                              : model.values,
                                    )));

                        if (result == "push") {
                          model.reqActionStatus = "Performed";
                          setState(() {});
                        }
                      } else if (tapedUserRole == "4") {
                        String result = await Navigator.of(context).push(
                            new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    PatnerProfileWidgetForOtherUser(
                                      partnerUserId,
                                      model.reqActionStatus == "Performed"
                                          ? "ActionPerformed"
                                          : "notification",
                                      groupId:
                                          model.reqActionStatus == "Performed"
                                              ? null
                                              : model.values,
                                    )));

                        if (result == "push") {
                          model.reqActionStatus = "Performed";
                          setState(() {});
                        }
                      }
                    } else if (model.type == Constant.FEED_TYPE_APPROVE) {
                      //FEED_TYPE
                      if (isFeed_AccessControl) {
                        Navigator.of(context).push(
                            new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    FeedDetailWidgetForBoat(
                                        model.values, "notification")));
                      } else {
                        ToastWrap.showToastForAccessDenied(
                            MessageConstant.FEATURE_DIABLED, context);
                      }
                    } else if (model.type == "Feed") {
                      //FEED_TYPE
                      if (isFeed_AccessControl) {
                        Navigator.pop(context);
                        syncDoneController.add("Feed");
                        Navigator.of(context).push(
                            new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    FeedDetailWidget(
                                        model.values, "notification")));
                      } else {
                        ToastWrap.showToastForAccessDenied(
                            MessageConstant.FEATURE_DIABLED, context);
                      }
                    } else if (model.type == "Opportunity") {
                      //shareIDData(model.values);
                      print('noti type Opportunity>>>>'); //FEED_TYPE
                      print('noti OpportunityId:: ${model.values}'); //FEED_TYPE
                      print('Apurva clicked Opportunity details');
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              OpportunityViewWidgetOnNotificationClick(
                                  model.values, roleId, 'notification')));
                    } else if (model.type == "ConnectionProfile") {
                      onTapConnectionNotification(
                          model.actedBy,
                          model.actedRoleId,
                          model.values == null || model.values == 'null'
                              ? ""
                              : model.values);
                    } else if (model.type == "Group") {
                      if (!isPartnerApprovedByAdmin && roleId == "4") {
                        ToastWrap.showToastPending(
                            MessageConstant
                                .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                            context);
                      } else {
                        if (isGroup_AccessControl) {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  GroupDetailWidget(
                                      model.values, "notification", "", "", "")));
                        } else {
                          ToastWrap.showToastForAccessDenied(
                              MessageConstant.JOIN_GROUP_DISABLE, context);
                        }


                      }
                      // syncDoneController.add("groupPage");
                    } else if (model.type == "GroupInvite") {
                      print('GroupInvite called');
                      print(
                          'GroupInvite called model.values::: ${model.values}');
                      if (!isPartnerApprovedByAdmin && roleId == "4") {
                        ToastWrap.showToastPending(
                            MessageConstant
                                .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                            context);
                      } else {
                        if (isGroup_AccessControl) {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  GroupDetailWidget(
                                      model.values, "", "", "", "")));
                        } else {
                          ToastWrap.showToastForAccessDenied(
                              MessageConstant.JOIN_GROUP_DISABLE, context);
                        }




                      }
                      // syncDoneController.add("groupPage");
                    } else if (model.type == Constant.GROUP_SCREEN) {
                      print('GroupInvite called');
                      print(
                          'GroupInvite called model.values::: ${model.values}');
                      if (!isPartnerApprovedByAdmin && roleId == "4") {
                        ToastWrap.showToastPending(
                            MessageConstant
                                .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                            context);
                      } else {
                        if (isGroup_AccessControl) {
                          String result = await Navigator.of(context).push(
                              new MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      GroupDetailWidget(
                                          model.values,
                                          model.reqActionStatus == "Performed"
                                              ? "ActionPerformed"
                                              : "notification",
                                          "",
                                          "",
                                          "")));
                          if (result == "push") {
                            model.reqActionStatus = "Performed";
                            setState(() {});
                          }
                        } else {
                          ToastWrap.showToastForAccessDenied(
                              MessageConstant.JOIN_GROUP_DISABLE, context);
                        }



                      }
                      // syncDoneController.add("groupPage");
                    } else if (model.type == "Shared") {
                      shareIDData(model.values);
                    }
                  }
                },
              ),
              flex: 0,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  InkWell(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        model.textName == "" || model.textName == "null"
                            ? RichText(
                                maxLines: 8,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: model.text.contains("groupId=")
                                      ? model.text.substring(
                                          0, model.text.indexOf("groupId="))
                                      : model.text.replaceAll("null", ""),
                                  style: TextStyle(
                                    color: const Color(0xff666B9A),
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                    fontFamily: Constant.latoRegular,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: model.type.toString().trim() ==
                                                  Constant
                                                      .OPPORTUNITY_DECLINE ||
                                              model.type.toString().trim() ==
                                                  "partner_decline"
                                          ? "Review comment(s)"
                                          : "",
                                      style: TextStyle(
                                        color: const Color(0xff666B9A),
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: Constant.latoRegular,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : RichText(
                                maxLines: 8,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: model.textName == "null"
                                      ? ""
                                      : model.textName + " ",
                                  style: TextStyle(
                                      color: const Color(0xff27275A),
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      fontFamily: Constant.latoRegular),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: model.textMessage,
                                      style: TextStyle(
                                        color: const Color(0xff666B9A),
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: Constant.latoRegular,
                                      ),
                                    ),
                                    TextSpan(
                                      text: model.type.toString().trim() ==
                                                  Constant
                                                      .OPPORTUNITY_DECLINE ||
                                              model.type.toString().trim() ==
                                                  "partner_decline"
                                          ? "Review comment(s)"
                                          : "",
                                      style: TextStyle(
                                        color: const Color(0xff666B9A),
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: Constant.latoRegular,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                        const SizedBox(height: 5),
                        BaseText(
                          text: model.dateTime,
                          textColor: const Color(0xff666B9A),
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.w500,
                          fontSize: 12,
                        ),
                      ],
                    ),
                    onTap: () async {
                      if (widget.isActive == "false" && roleId == "1") {
                        ToastWrap.showToast(
                            MessageConstant
                                .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                            context);
                      } else if (model.type == Constant.UNDER_13_GROUP_SCREEN) {
                        if (!isPartnerApprovedByAdmin && roleId == "4") {
                          ToastWrap.showToastPending(
                              MessageConstant
                                  .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                              context);
                        } else {
                          if (model.actionValue == "Deleted") {
                            ToastWrap.showToastPending(
                                MessageConstant.GROUP_DELETED, context);
                          } else {
                            if (isGroup_AccessControl) {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      GroupDetailWidget(model.values,
                                          "notification", "", "", "")));
                            } else {
                              ToastWrap.showToastForAccessDenied(
                                  MessageConstant.JOIN_GROUP_DISABLE, context);
                            }




                          }
                        }
                        // syncDoneController.add("groupPage");
                      } else if (model.type.toString().trim() ==
                          Constant.OPPORTUNITY_DECLINE) {
                        Navigator.of(context).push(new MaterialPageRoute(
                            builder: (BuildContext context) =>
                                opportunityRejected(
                                    'notification', model.values)));
                      } else if (model.type.toString().trim() ==
                              Constant.OPPORTUNITY_APPROVAL ||
                          model.type.toString().trim() ==
                              Constant.OPPORTUNITY_APPROVED) {
                        Navigator.of(context).push(new MaterialPageRoute(
                            builder: (BuildContext context) =>
                                OpportunityForBoat(
                                    model.values, roleId, 'notification')));
                      } else if (model.type.toString().trim() ==
                          Constant.FEED_REPORTED) {
                        Navigator.of(context).push(new MaterialPageRoute(
                            builder: (BuildContext context) =>
                                FeedReportWidgetBoat(
                                    model.values, "notification")));
                      } else if (model.type.toString().trim() ==
                          Constant.GROUP_REPORTED) {
                        if (model.requestId != "null" &&
                            model.requestId != "") {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  GroupReportWidgetBoat(
                                      model.values,
                                      "notification",
                                      model.requestId.toString())));
                        }
                      } else if (model.type.toString().trim() ==
                          Constant.STUDENT_PROFILE_REPORTED) {
                        if (model.requestId != "null" &&
                            model.requestId != "") {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  StudentProfileReportWidgetBoat(model.values,
                                      "notification", model.requestId, "1")));
                        }
                      } else if (model.type.toString().trim() ==
                          Constant.PARENT_PROFILE_REPORTED) {
                        if (model.requestId != "null" &&
                            model.requestId != "") {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  StudentProfileReportWidgetBoat(model.values,
                                      "notification", model.requestId, "2")));
                        }
                      } else if (model.type.toString().trim() ==
                          Constant.PARTNER_PROFILE_REPORTED) {
                        if (model.requestId != "null" &&
                            model.requestId != "") {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  StudentProfileReportWidgetBoat(model.values,
                                      "notification", model.requestId, "4")));
                        }
                      } else if (model.type.toString().trim() ==
                          Constant.UNDER_13_PROFILE_VISIBILITY) {
                        print("acted by++++" +
                            model.actedBy +
                            "  " +
                            model.userId);
                        if (roleId == "2") {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ProfileVisibilitySetting(
                                    model.values, true)),
                          );
                        } else {
                          if (isProfileVisible) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ProfileVisibilitySetting(
                                      model.values, false)),
                            );
                          } else {
                            ToastWrap.showToastForAccessDenied(
                                MessageConstant.FEATURE_DIABLED, context);
                          }



                        }
                      } else if (model.type.toString().trim() ==
                              Constant.UNDER_13_FILTER_PAGE &&
                          roleId == "2") {
                        print("roleId++++++" +
                            roleId +
                            "   " +
                            model.actedBy +
                            "   " +
                            model.userId);
                        if (roleId == "2") {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  PublicViewForUser(
                                    "",
                                    "chat",
                                    "Connected",
                                    true,
                                    actedUserId: model.actedBy,
                                    acteRoleId: "2",
                                    profileValue: model.values,
                                  )));
                        } else {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  PublicViewForUser(
                                    "",
                                    "chat",
                                    "Connected",
                                    true,
                                    actedUserId: model.userId,
                                    acteRoleId: "1",
                                  )));
                        }
                      } else if (model.type.toString().trim() ==
                              Constant.UNDER_13_TYPE &&
                          roleId == "2") {
                        print("roleId++++++" +
                            roleId +
                            "   " +
                            model.actedBy +
                            "   " +
                            model.userId);
                        if (roleId == "2") {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  PublicViewForUser(
                                    "",
                                    "chat",
                                    "Connected",
                                    true,
                                    actedUserId: model.actedBy,
                                    acteRoleId: "2",
                                    profileValue: model.values,
                                  )));
                        } else {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  PublicViewForUser(
                                    "",
                                    "chat",
                                    "Connected",
                                    true,
                                    actedUserId: model.userId,
                                    acteRoleId: "1",
                                  )));
                        }
                      } else if (model.actionValue == "Deleted" &&
                          model.type == "Group") {
                        ToastWrap.showToast(
                            'This group is no longer valid.', context);
                      } else {
                        if (model.type == "SelfProfile") {
                          if (roleId == "2") {
                            Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        DashBoardWidgetParent(
                                            prefs.getString(
                                                UserPreference.IS_PARENT_ROLE),
                                            prefs.getString(
                                                UserPreference.IS_PARTNER_ROLE),
                                            prefs.getString(
                                                UserPreference.IS_USER_ROLE))));
                          }
                        } else if (model.type == "partner_approval") {
                          onTapPartnerReview(
                              model.actedBy,
                              model.actedRoleId,
                              model.values == null || model.values == 'null'
                                  ? ""
                                  : model.values,
                              model.textMessage);
                        } else if (model.type == "partner_decline") {
                          onTapPartnerResendAccountApproval(
                              model.actedBy,
                              model.actedRoleId,
                              model.values == null || model.values == 'null'
                                  ? ""
                                  : model.values,
                              model.textMessage);
                        }
                        /*else if (model.type == "partner_approved") {

                            }*/
                        else if (model.type == "Profile") {
                          onTapImageTile(model.actedBy, model.actedRoleId);
                        } else if (model.type == "ProfileScreen") {
                          String tapedUserRole = model.actedRoleId;
                          String partnerUserId = model.actedBy;
                          if (tapedUserRole == "1") {
                            String result = await Navigator.of(context).push(
                                new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        UserProfileDashBoardForOther(
                                          partnerUserId,
                                          false,
                                          model.reqActionStatus == "Performed"
                                              ? "ActionPerformed"
                                              : "notification",
                                          "1",
                                          groupId: model.reqActionStatus ==
                                                  "Performed"
                                              ? null
                                              : model.values,
                                        )));

                            if (result == "push") {
                              model.reqActionStatus = "Performed";
                              setState(() {});
                            }
                          } else if (tapedUserRole == "2") {
                            String result = await Navigator.of(context).push(
                                new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        ParentProfilePageWithHeader(
                                          partnerUserId,
                                          model.reqActionStatus == "Performed"
                                              ? "ActionPerformed"
                                              : "notification",
                                          groupId: model.reqActionStatus ==
                                                  "Performed"
                                              ? null
                                              : model.values,
                                        )));

                            if (result == "push") {
                              model.reqActionStatus = "Performed";
                              setState(() {});
                            }
                          } else if (tapedUserRole == "4") {
                            String result = await Navigator.of(context).push(
                                new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        PatnerProfileWidgetForOtherUser(
                                          partnerUserId,
                                          model.reqActionStatus == "Performed"
                                              ? "ActionPerformed"
                                              : "notification",
                                          groupId: model.reqActionStatus ==
                                                  "Performed"
                                              ? null
                                              : model.values,
                                        )));

                            if (result == "push") {
                              model.reqActionStatus = "Performed";
                              setState(() {});
                            }
                          }
                        } else if (model.type == Constant.BADGE_TYPE) {
                          print('inside noti click type badge');
                          if (roleId == "4") {
                            Navigator.of(Constant.applicationContext).push(
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        PartnerNotificationManageBadges(
                                            "notification",
                                            badgeId: model.values)));
                          } else if (roleId == "1") {
                            print('inside noti click roleId=1 and type badge');
                            Navigator.of(context)
                                .popUntil((route) => route.isFirst);
                            syncDoneController.add("profile");
                          } else {
                            if (isConnection_AccessControl) {
                              Navigator.of(context)
                                  .popUntil((route) => route.isFirst);
                              syncDoneController.add("connectionPage");
                            } else {
                              ToastWrap.showToastForAccessDenied(
                                  MessageConstant.FEATURE_DIABLED, context);
                            }
                          }
                        } else if (model.type == Constant.FEED_TYPE_APPROVE) {

                          if (isFeed_AccessControl) {
                            Navigator.of(context).push(
                                new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        FeedDetailWidgetForBoat(
                                            model.values, "notification")));
                          } else {
                            ToastWrap.showToastForAccessDenied(
                                MessageConstant.FEATURE_DIABLED, context);
                          }


                        } else if (model.type == "Feed") {
                          if (isFeed_AccessControl) {
                            Navigator.pop(context);
                            syncDoneController.add("Feed");
                            Navigator.of(context).push(
                                new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        FeedDetailWidget(
                                            model.values, "notification")));
                          } else {
                            ToastWrap.showToastForAccessDenied(
                                MessageConstant.FEATURE_DIABLED, context);
                          }


                        } else if (model.type == "Opportunity") {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  OpportunityViewWidgetOnNotificationClick(
                                      model.values, roleId, 'notification')));
                        } else if (model.type == "ConnectionProfile") {
                          if (isConnection_AccessControl) {
                            Navigator.of(context)
                                .popUntil((route) => route.isFirst);
                            syncDoneController.add("connectionPage");

                            onTapConnectionNotification(
                                model.actedBy,
                                model.actedRoleId,
                                model.values == null ||
                                    model.values == 'null'
                                    ? ""
                                    : model.values);
                          } else {
                            ToastWrap.showToastForAccessDenied(
                                MessageConstant.FEATURE_DIABLED, context);
                          }

                        } else if (model.type == "Connection") {

                          if (isConnection_AccessControl) {
                            Navigator.of(context)
                                .popUntil((route) => route.isFirst);
                            syncDoneController.add("connectionPage");
                            print('in connection req');
                            Navigator.pop(context);
                            syncDoneController.add("connectionPage");
                          } else {
                            ToastWrap.showToastForAccessDenied(
                                MessageConstant.FEATURE_DIABLED, context);
                          }

                        } else if (model.type == "Group") {
                          if (!isPartnerApprovedByAdmin && roleId == "4") {
                            ToastWrap.showToastPending(
                                MessageConstant
                                    .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                                context);
                          } else {
                            if (isGroup_AccessControl) {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      GroupDetailWidget(model.values,
                                          "notification", "", "", "")));
                            } else {
                              ToastWrap.showToastForAccessDenied(
                                  MessageConstant.JOIN_GROUP_DISABLE, context);
                            }



                          }
                          // syncDoneController.add("groupPage");
                        } else if (model.type == Constant.GROUP_SCREEN) {
                          if (!isPartnerApprovedByAdmin && roleId == "4") {
                            ToastWrap.showToastPending(
                                MessageConstant
                                    .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                                context);
                          } else {
                            if (model.actionValue == "Deleted") {
                              ToastWrap.showToastPending(
                                  MessageConstant.GROUP_DELETED, context);
                            } else {
                              if (isGroup_AccessControl) {
                                String result = await Navigator.of(context).push(
                                    new MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            GroupDetailWidget(
                                                model.values,
                                                model.reqActionStatus ==
                                                    "Performed"
                                                    ? "ActionPerformed"
                                                    : "notification",
                                                "",
                                                "",
                                                "")));
                                if (result == "push") {
                                  model.reqActionStatus = "Performed";
                                  setState(() {});
                                }
                              } else {
                                ToastWrap.showToastForAccessDenied(
                                    MessageConstant.JOIN_GROUP_DISABLE, context);
                              }



                            }
                          }
                          // syncDoneController.add("groupPage");
                        } else if (model.type == "GroupInvite") {
                          print('GroupInvite called 111');
                          print(
                              'GroupInvite called 111 model.values::: ${model.values}');
                          if (!isPartnerApprovedByAdmin && roleId == "4") {
                            ToastWrap.showToastPending(
                                MessageConstant
                                    .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                                context);
                          } else {
                            if (isGroup_AccessControl) {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      GroupDetailWidget(
                                          model.values, "", "", "", "")));
                            } else {
                              ToastWrap.showToastForAccessDenied(
                                  MessageConstant.JOIN_GROUP_DISABLE, context);
                            }



                          }
                          // syncDoneController.add("groupPage");
                        } else if (model.type == "Shared") {
                          shareIDData(model.values);
                        } else if (model.type ==
                            MessageConstant.Recommendation_TYPE) {
                          if (roleId == "1") {
                            Navigator.of(context)
                                .popUntil((route) => route.isFirst);

                            Navigator.pushReplacement(
                                Constant.applicationContext,
                                MaterialPageRoute(
                                    builder: (context) => DashBoardWidget(
                                        prefs.getString(
                                            UserPreference.IS_PARENT_ROLE),
                                        prefs.getString(
                                            UserPreference.IS_PARTNER_ROLE),
                                        prefs.getString(
                                            UserPreference.IS_USER_ROLE),
                                        currentPage: Constant.PROFILE_TYPE)));
                          } else {
                            if (!isPartnerApprovedByAdmin && roleId == "4") {
                              ToastWrap.showToastPending(
                                  MessageConstant
                                      .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                                  context);
                            } else {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      ManageRequestDashBoard("")));
                            }
                          }
                        }
                      }
                    },
                  ),
                  model.type == Constant.ADMIN_TYPE && model.buttonText != ""
                      ? InkWell(
                          child: Container(
                              margin: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image: AssetImage("assets/bg_btn.png"),
                                  fit: BoxFit.cover,
                                ),
                              ),
                              child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(10.0, 5.0, 7.0, 5.0),
                                child: Wrap(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 2.0),
                                      child: Text(
                                        model.buttonText,
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 12.0,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR),
                                      ),
                                    ),
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            8.0, 1.0, 0.0, 0.0),
                                        child: Image.asset(
                                          "assets/circular_arrow.png",
                                          height: 15.0,
                                          width: 15.0,
                                        )),
                                  ],
                                ),
                              )),
                          onTap: () {
                            if (model.type == Constant.ADMIN_TYPE) {
                              if (model.linkType == "external") {
                                if (model.buttonUrl != null &&
                                    model.buttonUrl != "") {
                                  if (model.buttonUrl
                                      .toLowerCase()
                                      .contains("http")) {
                                    launch(model.buttonUrl);
                                  } else {
                                    String url = "http://" + model.buttonUrl;
                                    launch(url);
                                  }
                                }
                              } else if (model.linkType == "internal") {
                                if (model.appModule == "Profile") {
                                  Navigator.of(context)
                                      .popUntil((route) => route.isFirst);
                                  syncDoneController.add("profilePage");
                                } else if (model.appModule == "Feed") {
                                  if (model.values != null &&
                                      model.values != "null" &&
                                      model.values != "") {
                                    if (isFeed_AccessControl) {
                                      Navigator.of(context).push(
                                          MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  FeedDetailWidget(model.values,
                                                      "notification")));
                                    } else {
                                      ToastWrap.showToastForAccessDenied(
                                          MessageConstant.FEATURE_DIABLED, context);
                                    }



                                  } else {
                                    if (isFeed_AccessControl) {
                                      Navigator.of(context)
                                          .popUntil((route) => route.isFirst);
                                      syncDoneController.add("Feed");
                                    } else {
                                      ToastWrap.showToastForAccessDenied(
                                          MessageConstant.FEATURE_DIABLED, context);
                                    }
                                  }

                                  /* Navigator.of(context)
                              .popUntil((route) => route.isFirst);
                          syncDoneController.add("Feed");*/
                                } else if (model.appModule == "Connection") {

                                  if (isConnection_AccessControl) {
                                    Navigator.of(context)
                                        .popUntil((route) => route.isFirst);
                                    syncDoneController.add("connectionPage");
                                  } else {
                                    ToastWrap.showToastForAccessDenied(
                                        MessageConstant.FEATURE_DIABLED, context);
                                  }

                                } else if (model.appModule == "Chat") {
                                  if (isChat_AccessControl) {
                                    Navigator.of(context)
                                        .popUntil((route) => route.isFirst);
                                    syncDoneController.add("chatPage");
                                  } else {
                                    ToastWrap.showToastForAccessDenied(
                                        MessageConstant.FEATURE_DIABLED, context);
                                  }
                                } else if (model.appModule == "Group") {
                                  if (model.values != null &&
                                      model.values != "null" &&
                                      model.values != "") {
                                    if (!isPartnerApprovedByAdmin &&
                                        roleId == "4") {
                                      ToastWrap.showToastPending(
                                          MessageConstant
                                              .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
                                          context);
                                    } else {
                                      if (isGroup_AccessControl) {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (BuildContext context) =>
                                                    GroupDetailWidget(
                                                        model.values,
                                                        "notification",
                                                        "",
                                                        "",
                                                        "")));
                                      } else {
                                        ToastWrap.showToastForAccessDenied(
                                            MessageConstant.JOIN_GROUP_DISABLE, context);
                                      }



                                    }
                                  } else {
                                    Navigator.of(context)
                                        .popUntil((route) => route.isFirst);
                                    syncDoneController.add("groupPage");
                                  }

                                  /* Navigator.of(context)
                              .popUntil((route) => route.isFirst);
                          syncDoneController.add("groupPage");*/
                                } else if (model.appModule == "Opportunity") {
                                  //shareIDData(model.values);
                                  Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          OpportunityViewWidgetOnNotificationClick(
                                              model.values,
                                              roleId,
                                              'notification')));
                                }
                              } else {
                                //if (model.linkType == "text") {do nothing}
                              }
                            }
                          },
                        )
                      : model.reqActionStatus != "Performed" &&
                              (model.type == Constant.GROUP_SCREEN ||
                                  model.type ==
                                      Constant.UNDER_13_GROUP_SCREEN ||
                                  model.type == "ProfileScreen")
                          ? Padding(
                              padding: const EdgeInsets.only(top: 12),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  _negativeButton(
                                    title: 'Reject',
                                    onTap: () {
                                      if (widget.isActive == "false" &&
                                          roleId == "1") {
                                        ToastWrap.showToast(
                                            MessageConstant
                                                .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                            context);
                                      } else {
                                        apiCallingForAccept(
                                            model.values, 0, "Rejected", model);
                                      }
                                    },
                                  ),
                                  const SizedBox(width: 8),
                                  _positiveButton(
                                    title: "Accept",
                                    onTap: () {
                                      if (widget.isActive == "false" &&
                                          roleId == "1") {
                                        ToastWrap.showToast(
                                            MessageConstant
                                                .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                            context);
                                      } else {
                                        apiCallingForAccept(
                                            model.values, 0, "Accepted", model);
                                      }
                                    },
                                  ),
                                ],
                              ),
                            )
                          : const SizedBox.shrink(),
                  model.type == MessageConstant.Recommendation_TYPE ||
                          model.type ==
                              MessageConstant
                                  .Recommendation_RecommendationRequest
                      ? Padding(
                          padding: const EdgeInsets.fromLTRB(0, 12, 0, 0),
                          child: _negativeButton(
                            title:
                                model.requestType == "self" ? "Verify" : "View",
                            onTap: () {
                              onTapRecommendation(model.values);
                            },
                          ),
                        )
                      : const SizedBox.shrink(),
                  model.type == MessageConstant.Recommendation_Reminder ||
                          model.type == MessageConstant.BADGES_Reminder
                      ? Container(
                          padding: const EdgeInsets.only(top: 12),
                          child: model.reqActionStatus != "Performed"
                              ? Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    _negativeButton(
                                      title: MessageConstant
                                          .ADD_RECOMMENDATION_VIEW_REQUEST,
                                      onTap: () {
                                        if (model.type ==
                                            MessageConstant
                                                .Recommendation_Reminder) {
                                          onTapRecommendation(model.values);
                                        } else {
                                          onTapBadgesView(
                                              model.values, "Notification");
                                        }
                                      },
                                    ),
                                    const SizedBox(width: 8),
                                    _positiveButton(
                                      title: MessageConstant
                                          .ADD_RECOMMENDATION_REMINDER,
                                      onTap: () {
                                        if (model.type ==
                                            MessageConstant
                                                .Recommendation_Reminder) {
                                          apiForReminder(model.values, index1,
                                              model.notificationId);
                                        } else {
                                          apiForReminderBadges(model.values,
                                              index1, model.notificationId);
                                        }
                                      },
                                    ),
                                  ],
                                )
                              : Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    _negativeButton(
                                      title: MessageConstant
                                          .ADD_RECOMMENDATION_VIEW_REQUEST,
                                      onTap: () {
                                        if (model.type ==
                                            MessageConstant
                                                .Recommendation_Reminder) {
                                          onTapRecommendation(model.values);
                                        } else {
                                          onTapBadgesView(
                                              model.values, "Notification");
                                        }
                                      },
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      foregroundDecoration: BoxDecoration(
                                        color: Colors.white60,
                                      ),
                                      child: _positiveButton(
                                        title: MessageConstant
                                            .ADD_RECOMMENDATION_REMINDER,
                                        onTap: () {},
                                      ),
                                    ),
                                  ],
                                ),
                        )
                      : const SizedBox.shrink(),
                  model.type == MessageConstant.Recommendation_Pending ||
                          model.type == MessageConstant.Recommendation_Replied
                      ? Container(
                          padding: const EdgeInsets.fromLTRB(0, 12, 0, 0),
                          child: _negativeButton(
                            title:
                                model.requestType == "self" ? "Verify" : "View",
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      SharedRecommendationDetail(model.values,
                                          false, "notification", "existing"),
                                ),
                              );
                            },
                          ),
                        )
                      : const SizedBox.shrink(),
                  model.type == MessageConstant.BadgeRequest_Notification ||
                          model.type ==
                              MessageConstant.BadgeCollection_Notification
                      ? Container(
                          padding: const EdgeInsets.only(top: 12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              _negativeButton(
                                title: MessageConstant
                                    .ADD_RECOMMENDATION_VIEW_REQUEST,
                                onTap: () {
                                  if (model.roleId == "4") {
                                    Navigator.of(Constant.applicationContext)
                                        .push(
                                      MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            PartnerNotificationManageBadges(
                                                "notification",
                                                badgeId: model.values),
                                      ),
                                    );
                                  } else if (model.roleId == "1") {
                                    onTapBadgesView(
                                        model.values, "notificationCollection");
                                  }
                                },
                              ),
                            ],
                          ),
                        )
                      : model.type ==
                              MessageConstant.BadgePresented_Notification
                          ? Container(
                              padding: const EdgeInsets.only(top: 12),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  _negativeButton(
                                    title: "Verify",
                                    onTap: () {
                                      if (model.roleId == "4") {
                                        Navigator.of(
                                                Constant.applicationContext)
                                            .push(
                                          MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                PartnerNotificationManageBadges(
                                                    "notification",
                                                    badgeId: model.values),
                                          ),
                                        );
                                      }
                                    },
                                  ),
                                ],
                              ),
                            )
                          : const SizedBox.shrink(),
                ],
              ),
              flex: 1,
            ),
            /*      model.isRead == "true"
                    ? Container(
                        height: 0.0,
                      )
                    : Expanded(
                        child: Padding(
                            padding:
                                EdgeInsets.fromLTRB(10.0, 5.0, 0.0, 0.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Image.asset(
                                  "assets/newDesignIcon/dot.png",
                                  width: 9.0,
                                  height: 9.0,
                                )
                              ],
                            )),
                        flex: 0,
                      ),*/
          ],
        ),
      );
    }

    void onItemClick(int index) async {
      if (!isPartnerApprovedByAdmin && roleId == "4") {
        ToastWrap.showToastPending(
            MessageConstant.PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR, context);
      } else {
        if (dataList[index].actionValue == "Deleted") {
          ToastWrap.showToastPending(
              MessageConstant.ENTER_DELETE_GROUP_MSG, context);
        } else if (dataList[index].text.contains("groupId")) {
          if (isGroup_AccessControl) {
            List<String> list = dataList[index].text.split(" ");
            String groupId = list[list.length - 1].replaceAll("groupId=", "");
            Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) =>
                    GroupDetailWidget(groupId, "", "", "", "")));
          }else{
            ToastWrap.showToastForAccessDenied(
                MessageConstant.JOIN_GROUP_DISABLE, context);
          }
        } else {
          print('inside onItemClick else index:: $index');
        }
      }
    }

    return WillPopScope(
      onWillPop: () {
        if (!isDataLoading) {
          Navigator.pop(context);
          syncDoneController.add("refres");
        }
        return Future.value(false);
      },
      child: Scaffold(
        /* appBar: AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading: Padding(
              padding: const EdgeInsets.only(left: 9),
              child: IconButton(
                  icon: Image.asset("assets/newDesignIcon/icon/back_icon.png",
                      height: 32.0, width: 32.0, fit: BoxFit.fill),
                  onPressed: () {
                    Navigator.pop(context);
                    syncDoneController.add("refres");
                  }),
            ),
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),*/
        backgroundColor: Colors.white,
        body: Container(
          color: Colors.white,
          child: Column(
            children: <Widget>[
              const SizedBox(height: 50),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        InkWell(
                          child: Image.asset(
                            "assets/new_onboarding/back_blue_icon.png",
                            height: 32.0,
                            width: 32.0,
                            fit: BoxFit.fill,
                          ),
                          onTap: () {
                            Navigator.pop(context);
                            syncDoneController.add("refres");
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 21),
                    BaseText(
                      text: 'Notifications',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      textAlign: TextAlign.start,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 22),
                    isUserRepoted
                        ? _notificationSettingButton()
                        : const SizedBox.shrink(),
                  ],
                ),
              ),
              dataList.length > 0
                  ? Expanded(
                      child: ListView.separated(
                        controller: _controller,
                        itemBuilder: (_, index) {
                          return GestureDetector(
                            child: getCellItem(dataList[index], index),
                            onTap: () => onItemClick(index),
                          );
                        },
                        separatorBuilder: (_, index) => Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Divider(
                            height: 0,
                            thickness: 1,
                            color: const Color(0xffE5EBF0),
                          ),
                        ),
                        itemCount: dataList.length,
                        shrinkWrap: true,
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 20),
                      ),
                      flex: 1,
                    )
                  : Center(
                      child: isLoading
                          ? const SizedBox.shrink()
                          : Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Image.asset(
                                "assets/no_notification_new.png",
                                width: double.infinity,
                                height: 151.0,
                              ),
                              PaddingWrap.paddingfromLTRB(
                                40.0,
                                20.0,
                                40.0,
                                5.0,
                                TextViewWrap.textViewMultiLine(
                                  "No Notifications Yet!",
                                  TextAlign.center,
                                  ColorValues.GREY_TEXT_COLOR,
                                  16.0,
                                  FontWeight.bold,
                                  2,
                                ),
                              ),
                              PaddingWrap.paddingfromLTRB(
                                40.0,
                                7.0,
                                40.0,
                                40.0,
                                TextViewWrap.textViewMultiLine(
                                  "Come back and check again soon!",
                                  TextAlign.center,
                                  ColorValues.GREY_TEXT_COLOR,
                                  14.0,
                                  FontWeight.normal,
                                  4,
                                ),
                              ),
                            ],
                          ),
                    )
            ],
          ),
        ),
      ),
    );
  }

  Widget _negativeButton({
    @required String title,
    @required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 8),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xffBAC2D8), width: 1),
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        child: BaseText(
          text: title,
          textColor: const Color(0xff75809D),
          fontSize: 14,
          fontWeight: FontWeight.w600,
          fontFamily: Constant.latoRegular,
        ),
      ),
    );
  }

  Widget _positiveButton({
    @required String title,
    @required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.fromLTRB(23, 8, 22, 8),
        decoration: BoxDecoration(
          color: const Color(0xff3374DF),
          border: Border.all(color: const Color(0xff3374DF), width: 1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: BaseText(
          text: title,
          textColor: Colors.white,
          fontSize: 14,
          fontWeight: FontWeight.w600,
          fontFamily: Constant.latoRegular,
        ),
      ),
    );
  }

  void onTapSetting() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NotificationSetting()),
    );
    fetchPost();
  }

  Widget _notificationSettingButton() {
    return InkWell(
      onTap: () => onTapSetting(),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xffF5F6FA),
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.only(bottom: 25),
        padding: const EdgeInsets.fromLTRB(14, 15, 14, 15),
        child: Row(
          children: [
            Expanded(
              child: BaseText(
                text: "Notification settings",
                textColor: const Color(0xff3D4361),
                fontWeight: FontWeight.w500,
                fontSize: 14,
                fontFamily: Constant.latoRegular,
              ),
            ),
            const SizedBox(width: 14),
            Image.asset(
              'assets/experience/ic_more_arrow.png',
              color: const Color(0xff7C89AD),
              height: 24,
              width: 24,
            ),
          ],
        ),
      ),
    );
  }

  Future apiForReminder(
      String recommendationId, int index, String notificationId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": userIdPref,
          "roleId": roleId,
          "recommendationId": recommendationId,
          "notificationId": notificationId
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_SEND_REMINDER, map);
        print("apiForReminder:----------" +
            Constant.ENDPOINT_SEND_REMINDER +
            map.toString());
        print("apiForReminder:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            String date = '';
            try {
              date = Util.getConvertedDateStampNew(
                  response.data['result']['reminderDay'].toString());
            } catch (e) {
              print("error:-$e");
            }
            if (status == "Success") {
              getSharedPreferences();
              ToastWrap.showToastGreenDismissibleFalse(
                  "Reminder sent. You can send another reminder on $date" + ".",
                  context);
            } else {
              ToastWrap.showToasSucess(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiForReminderBadges(
      String badgeReqId, int index, String notificationId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": userIdPref,
          "roleId": roleId,
          "badgeReqId": badgeReqId,
        };

        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_SEND_REMINDER_BADGES, map);

        print("map.....response..........." + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            String date = '';
            try {
              date = Util.getConvertedDateStampNew(
                  response.data['result']['reminderDay'].toString());
            } catch (e) {
              print("error:-$e");
            }
            if (status == "Success") {
              getSharedPreferences();
              ToastWrap.showToastGreenDismissibleFalse(
                  "Reminder sent. You can send another reminder on $date",
                  context);
            } else {
              ToastWrap.showToasSucess(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  onTapRecommendation(String recommendationId) async {
    if (prefs.getString(UserPreference.ISACTIVE) == "true") {
      CustomProgressLoader.showLoader(context);
      callApiProfile(false, "recommendation", recommendationId);
    } else {
      ToastWrap.showToast(
          MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR, context);
    }
  }

  onTapBadgesView(String badgesId, String notificationCollection) async {
    print("notificationCollection////////" + notificationCollection.toString());
    if (prefs.getString(UserPreference.ISACTIVE) == "true") {
      CustomProgressLoader.showLoader(context);

      if (notificationCollection == "notificationCollection") {
        callApiProfile(false, "notificationCollection", badgesId);
      } else {
        callApiProfile(false, "Notification", badgesId);
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR, context);
    }
  }

  Future callApiForSaas(isShowLoader) async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future callApiProfile(isShowLoader, String type, String Id) async {
    try {
      final response = await ApiCalling2().apiCall(context,
          Constant.ENDPOINT_PROFILE_DATA + userIdPref + "&roleId=1", "get");
      CustomProgressLoader.cancelLoader(context);
      if (response.statusCode == 200) {
        setState(() {
          itemModel1 = ProfileDataModel.fromJson(response.data);
        });

        if (type == "Notification" || type == "notificationCollection") {
          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) =>
                  ManageBadgesStudentNotification(
                      itemModel1.profileDataModel.dob, userIdPref, type, Id)));
        } else {
          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) =>
                  NotificationManageRecommendation(itemModel1.profileDataModel,
                      true, false, userIdPref, sasToken, "notification", Id)));
        }
      } else {
        throw Exception('Failed to load post');
      }
    } catch (e) {
      if (e.toString().contains("401")) {
        Util.onTokenExpired(context);
      }
    }
  }
}
