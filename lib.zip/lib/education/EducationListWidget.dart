import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/education/AddEducation.dart';
import 'package:spike_view_project/education/EditEducationWidget.dart';

import 'package:spike_view_project/modal/ProfileInfoModel.dart';

import 'package:spike_view_project/common/FullImageView.dart';


import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/education/model/EducationDetailInfoModel.dart';

// Create a Form Widget
class EducationListWidget extends StatefulWidget {
  ProfileInfoModal profileInfoModal;

  //List<ProfileEducationModal> userEducationList;
  String isAllEducation;

  EducationDetailInfoModel educationDetailInfoModel;

  EducationListWidget(this.profileInfoModal, this.educationDetailInfoModel,
      this.isAllEducation);

  @override
  EducationListWidgetState createState() {
    return  EducationListWidgetState(educationDetailInfoModel);
  }
}

class EducationListWidgetState extends State<EducationListWidget> {
  String userIdPref, token;

  //List<ProfileEducationModal> userEducationList;
  EducationDetailInfoModel educationDetailInfoModel;
  List<Institute> schoolsInfoList =  List();
  List<Institute> collegesInfoList =  List();
  String isPerformChnges = "pop";
  SharedPreferences prefs;

  bool showCollege = true;

  EducationListWidgetState(this.educationDetailInfoModel);

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    token = prefs.getString(UserPreference.USER_TOKEN);

    schoolsInfoList.addAll(educationDetailInfoModel.result.schools);
    collegesInfoList.addAll(educationDetailInfoModel.result.colleges);
    setState(() {
      schoolsInfoList;
      collegesInfoList;
    });
    //eductionSchoolCollegeApi(true);
    // narrativeApi();
  }

  @override
  void initState() {

    
    


    // TODO: implement initState
    if (widget.profileInfoModal.dob.toString() != 'null' &&
        widget.profileInfoModal.dob.toString() != '') {
      DateTime date =  DateTime.fromMillisecondsSinceEpoch(
          int.tryParse(widget.profileInfoModal.dob));

      print('Apurva user age:: ${DateTime.now().year - date.year}');
      if (!Util.dobCheck(widget.profileInfoModal.dob)) {
        setState(() {
          showCollege = false;
        });
      }
    }
    getSharedPreferences();

    super.initState();
  }


  Future eductionSchoolCollegeApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        print(
            'Apurva eductionSchoolCollegeApi() url::: ${Constant.ENDPOINT_EDUCATION_SCHOOL_COLLEGE + widget.profileInfoModal.userId}');
        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_EDUCATION_SCHOOL_COLLEGE +
                widget.profileInfoModal.userId,
            "get");

        print(
            'Apurva eductionSchoolCollegeApi() response:: ${response.toString()}');

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              try {
                schoolsInfoList.clear();
                collegesInfoList.clear();
                educationDetailInfoModel =
                     EducationDetailInfoModel.fromJson(response.data);

                widget.isAllEducation =
                    educationDetailInfoModel.result.isAllEducation.toString();

                if (widget.isAllEducation == null ||
                    widget.isAllEducation == "null") {
                  widget.isAllEducation == "false";
                }


                schoolsInfoList.addAll(educationDetailInfoModel.result.schools);
                collegesInfoList
                    .addAll(educationDetailInfoModel.result.colleges);
                //collegeInfoList.insert(0,  CollegeInfoResult(degreeId: -1,name: "Degree"));

                if (mounted) {
                  setState(() {
                    schoolsInfoList;
                    collegesInfoList;
                    widget.isAllEducation;
                  });
                }

                print('schoolsInfoList size:: ${schoolsInfoList.length}');
                print('collegesInfoList size:: ${collegesInfoList.length}');
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(e,"EducationListWidget",context);
                print(
                    'inside eductionSchoolCollegeApi catch error:: ${e.toString()}');
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EducationListWidget",context);
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }


  Future deleteEducationSchool(educationId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "educationId": educationId,
        };
        Response response = await  ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_ADD_ORGANIZATION, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              schoolsInfoList.removeAt(index);
              setState(() {
                schoolsInfoList;
                isPerformChnges = "push";
                widget.isAllEducation = "false";
              });

              if (schoolsInfoList.length == 0 && collegesInfoList.length == 0) {
                print('list is empty::: ');
                Navigator.pop(context, "push");
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EducationListWidget",context);
      e.toString();
    }
  }

  Future deleteEducationCollege(educationId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "educationId": educationId,
        };
        Response response = await  ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_UPDATE_COLLEGE_INFO, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              collegesInfoList.removeAt(index);
              setState(() {
                collegesInfoList;
                isPerformChnges = "push";
                widget.isAllEducation = "false";
              });

              if (schoolsInfoList.length == 0 && collegesInfoList.length == 0) {
                Navigator.pop(context, "push");
              }
              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EducationListWidget",context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    void educationRemoveConfromationDialog(
        educationId, orgName, index, String deleteFrom) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 20.0,
                              child:  Container(
                                  height: 125.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 80.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to delete this education?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 45.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Remove",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 20.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (deleteFrom == 'School') {
                                                  deleteEducationSchool(
                                                      educationId, index);
                                                } else {
                                                  deleteEducationCollege(
                                                      educationId, index);
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    onTapEducationItemEditBtn(profileEducationModal, String editFrom) async {
      print("clicked edit");
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>  EditEducationWidget(
              widget.profileInfoModal.dob,
              widget.profileInfoModal.isActive,
              editFrom,
              profileEducationModal,widget.profileInfoModal.userId)));
      print(result);
      if (result == "push") {
        setState(() {
          isPerformChnges = "push";
        });
        //eductionApi(true);
        eductionSchoolCollegeApi(true);
      }
    }

//============================================ grid view achevements nd core logic =====================================

    onTapAddEducationBtn(String from) async {
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>  AddEducation(
              widget.profileInfoModal.dob,
              widget.profileInfoModal.isActive,
              from,widget.profileInfoModal)));

      print(result);
      if (result == "push") {
        setState(() {
          isPerformChnges = "push";
        });
        //eductionApi(true);
        eductionSchoolCollegeApi(true);
      }
    }

    void onAddEducation(String from) {
      if (widget.isAllEducation != "true") {
        onTapAddEducationBtn(from);
      } else {
        ToastWrap.showToast(
            MessageConstant.ALREADY_ADDED_ALL_GRADE_VAL, context);
      }
    }

    Container getSchoolEducationListItem(index) {
      return  Container(
          child:  InkWell(
        child: PaddingWrap.paddingfromLTRB(
            13.0,
            0.0,
            13.0,
            10.0,
             Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                 Expanded(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      10.0,
                      0.0,
                      schoolsInfoList[index].logo == "" ||
                              schoolsInfoList[index].logo == "null"
                          ? Image.asset(
                              "assets/profile/img_default.png",
                              height: 37.0,
                              width: 37.0,
                            )
                          :  InkWell(onTap: (){
                        Navigator.of(context).push(new MaterialPageRoute(
                            builder: (BuildContext context) =>  FullImageView(
                              schoolsInfoList[index].logo,
                              pageName: MessageConstant.EDUCATION_HEDING,
                            )));
                      },
                            child:  Container(
                                height: 37.0,
                                width: 37.0,
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  placeholder: 'assets/profile/img_default.png',
                                  image: Constant.IMAGE_PATH +
                                      schoolsInfoList[index].logo,
                                )),
                          )),
                  flex: 0,
                ),
                 Expanded(
                  child:  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                           Text(
                            schoolsInfoList[index].institute,
                            maxLines: 5,
                            style:  TextStyle(
                                fontWeight: FontWeight.normal,
                                color:  ColorValues.HEADING_COLOR_EDUCATION,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 16.0),
                          )),
                      RichText(
                        maxLines: 15,
                        textAlign: TextAlign.start,
                        text: TextSpan(
                          text: schoolsInfoList[index].toYear == null ||
                                  schoolsInfoList[index].toYear == "null" ||
                                  schoolsInfoList[index].toYear == ""
                              ? schoolsInfoList[index].fromYear +
                                  " - " +
                                  "Ongoing" +
                                  " | "
                              : schoolsInfoList[index].fromYear +
                                  " - " +
                                  schoolsInfoList[index].toYear +
                                  " | ",
                          style:  TextStyle(
                              color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 14.0),
                          children: [
                             TextSpan(
                                text: schoolsInfoList[index].fromGrade +
                                    " - " +
                                    schoolsInfoList[index].toGrade,
                                style:  TextStyle(
                                    color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 14.0)),
                             TextSpan(
                                text: schoolsInfoList[index].gpa != null &&
                                        schoolsInfoList[index].gpa != ''
                                    ? " | GPA: " +
                                        schoolsInfoList[index].gpa.toString()
                                    : '',
                                style:  TextStyle(
                                    color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 14.0)),
                          ],
                        ),
                      ),


                    ],
                  ),
                  flex: 1,
                ),
                 Expanded(
                  child:  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                         Image.asset(
                          "assets/newDesignIcon/edit_circl.png",
                          height: 37.0,
                          width: 37.0,
                        )),
                    onTap: () {
                      onTapEducationItemEditBtn(
                          schoolsInfoList[index], "School");
                    },
                  ),
                  flex: 0,
                ),
                 Expanded(
                  child:  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        0.0,
                        0.0,
                        0.0,
                         Image.asset(
                          "assets/newDesignIcon/cancel_circl.png",
                          height: 37.0,
                          width: 37.0,
                        )),
                    onTap: () {
                      educationRemoveConfromationDialog(
                          schoolsInfoList[index].educationId,
                          schoolsInfoList[index].institute,
                          index,
                          'School');

                    },
                  ),
                  flex: 0,
                )
              ],
            )),
        onTap: () {},

      ));
    }

    Container getCollegeEducationListItemOld(index) {
      return  Container(
          child:  InkWell(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                0.0,
                13.0,
                10.0,
                 Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                     Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          10.0,
                          0.0,
                          collegesInfoList[index].logo == "" ||
                              collegesInfoList[index].logo == "null"
                              ? Image.asset(
                            "assets/profile/img_default.png",
                            height: 37.0,
                            width: 37.0,
                          )
                              :   InkWell(onTap: (){
                            Navigator.of(context).push(new MaterialPageRoute(
                                builder: (BuildContext context) =>  FullImageView(
                                  collegesInfoList[index].logo,
                                  pageName: MessageConstant.EDUCATION_HEDING,
                                )));
                          },
                              child:new Container(
                                  height: 37.0,
                                  width: 37.0,
                                  child: FadeInImage.assetNetwork(
                                    fit: BoxFit.cover,
                                    placeholder: 'assets/profile/img_default.png',
                                    image: Constant.IMAGE_PATH +
                                        collegesInfoList[index].logo,
                                  )))),
                      flex: 0,
                    ),
                     Expanded(
                      child:  Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                               Text(
                                collegesInfoList[index].institute,
                                maxLines: 5,
                                style:  TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color:  ColorValues.HEADING_COLOR_EDUCATION,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 16.0),
                              )),
                          collegesInfoList[index].degree != null &&
                              collegesInfoList[index].degree != "null" &&
                              collegesInfoList[index].degree != ""
                              ? RichText(
                            maxLines: 15,
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              text: collegesInfoList[index].degree.trim() +
                                  ", ",
                              style:  TextStyle(
                                  color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 14.0),
                              children: [
                                 TextSpan(
                                    text: collegesInfoList[index].degree !=
                                        'Professional Certificate'
                                        ? "Major: " +
                                        collegesInfoList[index]
                                            .major
                                            .trim()

                                        : "Certification Name: " +
                                        collegesInfoList[index]
                                            .certifications
                                            .trim(),
                                    style:  TextStyle(
                                        color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0)),
                                 TextSpan(
                                    text: collegesInfoList[index].minor !=
                                        '' &&
                                        collegesInfoList[index].minor !=
                                            null &&
                                        collegesInfoList[index].minor !=
                                            'null' &&
                                        collegesInfoList[index].degree !=
                                            'Professional Certificate'
                                        ? ", Minor: " +
                                        collegesInfoList[index]
                                            .minor
                                            .trim()

                                        : '',
                                    style:  TextStyle(
                                        color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0)),
                              ],
                            ),
                          )
                              : Container(
                            width: 0,
                            height: 0,
                          ),

                           Row(
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                   Text(
                                    collegesInfoList[index].toYear == null ||
                                        collegesInfoList[index].toYear ==
                                            "null" ||
                                        collegesInfoList[index].toYear == ""
                                        ? collegesInfoList[index].fromYear +
                                        " - " +
                                        "Ongoing"
                                    //+ " | "
                                        : collegesInfoList[index].fromYear +
                                        " - " +
                                        collegesInfoList[index].toYear
                                    //+ " | "
                                    ,
                                    style:  TextStyle(
                                        color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  )),

                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                   Text(
                                    collegesInfoList[index].gpa != null &&
                                        collegesInfoList[index].gpa != ''
                                        ? " | GPA: " +
                                        collegesInfoList[index].gpa.toString()
                                        : '',
                                    style:  TextStyle(
                                        color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  )),
                            ],
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                     Expanded(
                      child:  InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                             Image.asset(
                              "assets/newDesignIcon/edit_circl.png",
                              height: 37.0,
                              width: 37.0,
                            )),
                        onTap: () {
                          onTapEducationItemEditBtn(
                              collegesInfoList[index], "College");
                        },
                      ),
                      flex: 0,
                    ),
                     Expanded(
                      child:  InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            0.0,
                             Image.asset(
                              "assets/newDesignIcon/cancel_circl.png",
                              height: 37.0,
                              width: 37.0,
                            )),
                        onTap: () {
                          educationRemoveConfromationDialog(
                              collegesInfoList[index].educationId,
                              collegesInfoList[index].institute,
                              index,
                              'College');

                        },
                      ),
                      flex: 0,
                    )
                  ],
                )),
            onTap: () {},

          ));
    }

    Container getCollegeEducationListItem(index) {
      return  Container(
          child:  InkWell(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                0.0,
                13.0,
                10.0,
                 Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                     Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          10.0,
                          0.0,
                          collegesInfoList[index].logo == "" ||
                              collegesInfoList[index].logo == "null"
                              ? Image.asset(
                            "assets/profile/img_default.png",
                            height: 37.0,
                            width: 37.0,
                          )
                              :  InkWell(onTap: (){
                            Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        FullImageView(
                                          collegesInfoList[index].logo,
                                          pageName: MessageConstant
                                              .EDUCATION_HEDING,
                                        )));
                          },
                              child:Container(
                              height: 37.0,
                              width: 37.0,
                              child: FadeInImage.assetNetwork(
                                fit: BoxFit.cover,
                                placeholder: 'assets/profile/img_default.png',
                                image: Constant.IMAGE_PATH +
                                    collegesInfoList[index].logo,
                              )))),
                      flex: 0,
                    ),
                     Expanded(
                      child:  Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                               Text(
                                collegesInfoList[index].institute,
                                maxLines: 5,
                                style:  TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color:  ColorValues.HEADING_COLOR_EDUCATION,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 16.0),
                              )),
                          collegesInfoList[index].degree != null &&
                              collegesInfoList[index].degree != "null" &&
                              collegesInfoList[index].degree != ""
                              ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              RichText(
                                maxLines: 15,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: collegesInfoList[index].degree.trim()
                                  //+ ", "
                                  ,
                                  style:  TextStyle(
                                      color:  ColorValues.GREY__COLOR,
                                      fontSize: 14.0),
                                  children: [

                                  ],
                                ),
                              ),
                               Text(
                                  collegesInfoList[index].degree !=
                                      'Professional Certificate'
                                      ? "Major: " +
                                      collegesInfoList[index]
                                          .major
                                          .trim()

                                      : "Certification Name: " +
                                      collegesInfoList[index]
                                          .certifications
                                          .trim(),
                                  style:  TextStyle(
                                      color: ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0)),

                              collegesInfoList[index].minor !=
                                  '' &&
                                  collegesInfoList[index].minor !=
                                      null &&
                                  collegesInfoList[index].minor !=
                                      'null' &&
                                  collegesInfoList[index].degree !=
                                      'Professional Certificate'
                                  ?  Text("Minor: " +
                                  collegesInfoList[index]
                                      .minor
                                      .trim(),


                                  style:  TextStyle(
                                      color: ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0)): Container(
                                width: 0,
                                height: 0,
                              ),
                            ],
                          )

                              : Container(
                            width: 0,
                            height: 0,
                          ),

                           Row(
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                   Text(
                                    collegesInfoList[index].toYear == null ||
                                        collegesInfoList[index].toYear ==
                                            "null" ||
                                        collegesInfoList[index].toYear == ""
                                        ? collegesInfoList[index].fromYear +
                                        " - " +
                                        "Ongoing"
                                    //+ " | "
                                        : collegesInfoList[index].fromYear +
                                        " - " +
                                        collegesInfoList[index].toYear
                                    //+ " | "
                                    ,
                                    style:  TextStyle(
                                        color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  )),

                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                   Text(
                                    collegesInfoList[index].gpa != null &&
                                        collegesInfoList[index].gpa != ''
                                        ? " | GPA: " +
                                        collegesInfoList[index].gpa.toString()
                                        : '',
                                    style:  TextStyle(
                                        color:  ColorValues.GREY__COLOR,fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  )),
                            ],
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                     Expanded(
                      child:  InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                             Image.asset(
                              "assets/newDesignIcon/edit_circl.png",
                              height: 37.0,
                              width: 37.0,
                            )),
                        onTap: () {
                          onTapEducationItemEditBtn(
                              collegesInfoList[index], "College");
                        },
                      ),
                      flex: 0,
                    ),
                     Expanded(
                      child:  InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            0.0,
                             Image.asset(
                              "assets/newDesignIcon/cancel_circl.png",
                              height: 37.0,
                              width: 37.0,
                            )),
                        onTap: () {
                          educationRemoveConfromationDialog(
                              collegesInfoList[index].educationId,
                              collegesInfoList[index].institute,
                              index,
                              'College');

                        },
                      ),
                      flex: 0,
                    )
                  ],
                )),
            onTap: () {},

          ));
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChnges);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            appBar:  AppBar(
              elevation: 0.0,
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Expanded(
                    child:  InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context, isPerformChnges);
                      },
                    ),
                    flex: 0,
                  ),
                   Expanded(
                    child:  Text(
                      "Education",
                      textAlign: TextAlign.center,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  )
                ],
              ),

              backgroundColor: Colors.white,
            ),
            body:  Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                 Expanded(
                    child:  ListView(
                  children: <Widget>[
                     Column(
                      children: <Widget>[
                        //College Data
                        showCollege
                            ? Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 0.0, 0.0, 0.0),
                                    child: Container(
                                      width: MediaQuery.of(context).size.width,
                                      color: ColorValues.DARK_GREY,
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 4.0, 13.0, 4.0),
                                          child:  Text(
                                            "COLLEGE (${collegesInfoList.length})",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                                fontFamily:
                                                    Constant.customRegular,
                                                fontSize: 12.0),
                                          )),
                                    ),
                                  ),
                                   Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          13.0, 10.0, 0.0, 13.0),
                                      child:  InkWell(
                                        child:  Row(
                                          children: <Widget>[
                                            Icon(
                                              Icons.add,
                                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                            ),
                                             Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    10.0, 0.0, 0.0, 0.0),
                                                child:  Text(
                                                  "ADD COLLEGE",
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(
                                                      color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily: Constant
                                                          .customRegular,
                                                      fontSize: 16.0),
                                                ))
                                          ],
                                        ),
                                        onTap: () {
                                          onAddEducation('College');
                                        },
                                      )),
                                  collegesInfoList.length > 0
                                      ?  Column(
                                          children:  List.generate(
                                              collegesInfoList.length,
                                              (int index) {
                                          return getCollegeEducationListItem(
                                              index);
                                        }))
                                      : Container(),
                                ],
                              )
                            : Container(),

                        //School Data
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: showCollege
                                  ? const EdgeInsets.fromLTRB(
                                      0.0, 13.0, 0.0, 0.0)
                                  : const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 0.0),
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                color: ColorValues.DARK_GREY,
                                child:  Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        13.0, 4.0, 13.0, 4.0),
                                    child:  Text(
                                      "SCHOOL (${schoolsInfoList.length})",
                                      textAlign: TextAlign.left,
                                      style: TextStyle(
                                          color: ColorValues.HEADING_COLOR_EDUCATION,
                                          fontFamily: Constant.customRegular,
                                          fontSize: 12.0),
                                    )),
                              ),
                            ),
                             Padding(
                                padding:
                                    EdgeInsets.fromLTRB(13.0, 10.0, 0.0, 13.0),
                                child:  InkWell(
                                  child:  Row(
                                    children: <Widget>[
                                      Icon(
                                        Icons.add,
                                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                      ),
                                       Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              10.0, 0.0, 0.0, 0.0),
                                          child:  Text(
                                            "ADD SCHOOL",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                fontFamily:
                                                    Constant.customRegular,
                                                fontSize: 16.0),
                                          ))
                                    ],
                                  ),
                                  onTap: () {
                                    onAddEducation('School');
                                  },
                                )),
                            schoolsInfoList.length > 0
                                ?  Column(
                                    children:  List.generate(
                                        schoolsInfoList.length, (int index) {
                                    return getSchoolEducationListItem(index);
                                  }))
                                : Container(),
                          ],
                        ),
                      ],
                    )
                  ],
                ))
              ],
            )));
  }
}
