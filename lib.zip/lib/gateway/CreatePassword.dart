// Updated COde

import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
//import 'package:flutter_verification_code/flutter_verification_code.dart';

import 'package:http/http.dart' as http;
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/image_utils.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/gateway/TakeATour.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';

import 'Login_Widget.dart';

class CreatePassword extends StatefulWidget {
  static String tag = 'login-page';
  String email;

  CreatePassword(this.email);

  @override
  CreatePasswordState createState() => CreatePasswordState();
}

final formKey = GlobalKey<FormState>();
String _email = "";
bool _isLoading = false;

class CreatePasswordState extends State<CreatePassword> {
  Color borderColor = Colors.amber;
  SharedPreferences prefs;
  TextEditingController paswordController = TextEditingController(text: "");
  bool allFieldCompleted = false;
  bool _newPassObscureText = true;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  bool _showApiError = false;
  String strError ;

  checkAllFieldSubmitter() {
    if (ValidationWidget.isPass(paswordController.text)) {
      allFieldCompleted = true;
      setState(() {});
    } else {
      allFieldCompleted = false;
      setState(() {});
    }
  }

  void _checkValidation() {


      forgotpassworApiCalling();

  }

  ontapCancel() {
    Navigator.pop(context);
  }

  @override
  void initState() {
    super.initState();
  }

  onBack() {
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginPage(null)));
  }

  showSucessMsg(msg, context, push) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");

      if (push) {
       // Navigator.pop(context);
        Navigator.pop(context,true);
      }else{
        Navigator.pop(context);
      }
    });

    // showDialog(
    //     barrierDismissible: false,
    //     context: context,
    //     builder: (_) => WillPopScope(
    //         onWillPop: () {},
    //         child: GestureDetector(
    //           child: Scaffold(
    //             backgroundColor: Colors.transparent,
    //             body: Stack(
    //               children: <Widget>[
    //                 Positioned(
    //                     right: 0.0,
    //                     top: 55.0,
    //                     left: 0.0,
    //                     child: Container(
    //                       height: 65.0,
    //                       padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
    //                       color: Color(0xffF1EDC3),
    //                       child: Column(
    //                           crossAxisAlignment: CrossAxisAlignment.start,
    //                           mainAxisAlignment: MainAxisAlignment.center,
    //                           children: <Widget>[
    //                             RichText(
    //                               maxLines: 2,
    //                               overflow: TextOverflow.ellipsis,
    //                               textAlign: TextAlign.start,
    //                               text: TextSpan(
    //                                 text: msg,
    //                                 style: TextStyle(
    //                                     color: Color(0xff408738),
    //                                     fontSize: 13.0,
    //                                     fontWeight: FontWeight.normal,
    //                                     fontFamily: Constant.customRegular),
    //                               ),
    //                             )
    //                           ]),
    //                     )),
    //               ],
    //             ),
    //           ),
    //           onTap: () {},
    //         )));
  }

  forgotpassworApiCalling() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        String encryptedstrNewPassword = "";

        encryptedstrNewPassword = await platform.invokeMethod('encryption', {
          "password": paswordController.text,
        });

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data

        var map = {"email" :widget.email,
          "password":encryptedstrNewPassword
        };
        print('map+++$map');
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_RESET_PASSWORD,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            showSucessMsg(message, context, true);
          } else {

            _showApiError = true;
            strError = message;
          //  ToastWrap.showToastLongNew(message, context);

          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          setState(() => _isLoading = false);
          // If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
        CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      setState(() => _isLoading = false);
      // CustomProgressLoader.cancelLoader(context);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  bool _onEditing = true;
  String _code = '';

  onTapSignOut() async {
    // setState(() {
    Constant.isAlreadyLoggedIn = false;
    //});

    Map map = {
      "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
      "deviceId": prefs.getString("deviceId")
    };
    GlobalSocketConnection.socket
        .emitWithAck("disconnect1", [map]).then((data) {
      print("chat-login++++" + data.toString());
    });

    GlobalSocketConnection.socket.emit("disconnect2", []);

    prefs.setString(UserPreference.NAME, "");
    prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
    prefs.setBool(UserPreference.IS_USER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
    prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
    bloc.resetData(prefs);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage(null)),
    );
  }


  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return WillPopScope(
        onWillPop: () {
         Navigator.pop(context);
        },
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: customAppbar(
              context,
              SingleChildScrollView(
                child: Form(
                    key: formKey,
                    child: Container(
                      padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom,
                        left: 0, //11.0,
                        right: 0, // 11.0,
                      ),
                      child: Container(
                        //color: Colors.black.withOpacity(0.8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                                padding: const EdgeInsets.only(
                                    left: 20.0,
                                    right: 0.0,
                                    top: 24.0,
                                    bottom: 0),
                                child: RichText(
                                  maxLines: 1,
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    text: 'Create ',
                                    style: AppConstants
                                        .txtStyle.heading400LatoRegularDarkBlue
                                        .copyWith(
                                            fontSize: 28,
                                            fontWeight: FontWeight.w700),
                                    children: [
                                      TextSpan(
                                          text: 'new password',
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {},
                                          style: AppConstants.txtStyle
                                              .heading40018LatoRegularDarkBlue
                                              .copyWith(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.w700)),
                                    ],
                                  ),
                                )),
                            Padding(
                              padding: EdgeInsets.fromLTRB(20.0, 10, 20.0, 45.0),
                              child:  InkWell(
                                child: BaseText(
                                  text: 'Your new password must be different from previously used password.',
                                  textColor:
                                  AppConstants.colorStyle.lightPurple,
                                  fontFamily: AppConstants
                                      .stringConstant.latoSemibold,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 18,
                                ),
                                onTap: () {

                                },

                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left:20.0,right: 20),
                              child: CustomFormField(
                                // maxLength: 35,
                                controller: paswordController,

                                prefixWidget: Image.asset(
                                  getAssetsPNGImg('password'),
                                  height: 20,
                                  width: 20,
                                ),
                                onType: (val) {
                                  checkAllFieldSubmitter();
                                },
                                label: "Create password",
                                isObsecure: _newPassObscureText,
                                suffixWidget: GestureDetector(
                                  child: _newPassObscureText
                                      ? Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 18.0, 0.0, 6.0),
                                      child: Image.asset(
                                        "assets/newDesignIcon/login/hide.png",
                                        width: 25.0,
                                        height: 25.0,
                                      ))
                                      : Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          10.0, 18.0, 0.0, 6.0),
                                      child: Image.asset(
                                        "assets/newDesignIcon/login/unhide.png",
                                        width: 25.0,
                                        height: 25.0,color: AppConstants.colorStyle.lightPurple,
                                      )),
                                  onTap: () {
                                    if (_newPassObscureText)
                                      _newPassObscureText = false;
                                    else
                                      _newPassObscureText = true;

                                    setState(() {
                                      _newPassObscureText;
                                    });
                                  },
                                ),
                                validation: (val) => val.trim().length == 0
                                    ? MessageConstant.ENTER_PASSWORD_VAL
                                    : !ValidationWidget.isPass(val)
                                        ? MessageConstant.ENTER_PASSWORD_MESSAGE
                                        : null,
                              ),

                            ),
                            _showApiError
                                ? Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: Text(
                                strError,
                                maxLines: 3,
                                style: TextStyle(
                                  fontSize: 12.0,
                                  color: ColorValues.ERROR_COLOR,
                                ),
                              ),
                            )
                                : const SizedBox.shrink(),


                          ],
                        ),
                      ),
                    )),
              ),
              () {
                Navigator.pop(context,false);
              },
                bottomNavigation: Container(
                    child: Padding(
                        padding: EdgeInsets.only(
                            left: 20.0, top: 0.0, right: 20.0, bottom: 50.0),
                        child: Stack(
                          children: <Widget>[
                            Container(
                                height: 44.0,
                                width: double.infinity,
                                child: FlatButton(
                                  onPressed: () async {
                                    _checkValidation();
                                  },
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10)),
                                  color: AppConstants.colorStyle.lightBlue,
                                  child: Row(
                                    // Replace with a Row for horizontal icon + text
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text('Save',
                                          style: AppConstants.txtStyle
                                              .heading18600LatoRegularWhite),
                                    ],
                                  ),
                                )),

                            allFieldCompleted?  SizedBox(
                              height: 0,
                            )
                                : Container(
                              height: 44.0,
                              width: double.infinity,
                              color: Colors.white.withOpacity(0.75),
                            )
                          ],
                        ))),
                isShowExplanation:false,
            )));
  }
}
