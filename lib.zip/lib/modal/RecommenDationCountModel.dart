import 'dart:io';

class AchievementImportanceModal {
 String recommendation,achievement,endorsement,userId;

 AchievementImportanceModal(this.recommendation, this.achievement,
     this.endorsement, this.userId);

}

