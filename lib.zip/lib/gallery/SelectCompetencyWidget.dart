import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/gallery/AddAchievmentOutSideTheApp.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/accomplishment/AddAchievment.dart';

import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class SelectCompetencyWidget extends StatefulWidget {
  String userId;
  List<Assest> assestList;

  SelectCompetencyWidget(this.userId, this.assestList);

  @override
  CompetenciesWidgetState createState() {
    return  CompetenciesWidgetState();
  }
}

class CompetenciesWidgetState extends State<SelectCompetencyWidget> {
  final _formKey = GlobalKey<FormState>();
  String userIdPref, token;

  ScrollController _controller = ScrollController();

  // List<NarrativeModel> narrativeList =  List<NarrativeModel>();
  String isPerformChanges = "pop";
  List<CompetencyModel> listCompetency =  List();
  SharedPreferences prefs;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    competencyApiCall();
    // narrativeApi();
  }

//------------------------------------Api Calling for get Commpetency -------------------------
  Future competencyApiCall() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_COMPENTENCY, "get");
        print(response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              listCompetency.clear();
              listCompetency =
                  ParseJson.parseMapCompetency(response.data['result']);
              if (listCompetency.length > 0) {
                setState(() {
                  listCompetency;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
//============================================ grid view achevements nd core logic =====================================

    Column getCompetencyItem(position) {
      return  Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          position == 0
              ? PaddingWrap.paddingfromLTRB(
                  13.0,
                  20.0,
                  13.0,
                  5.0,
                   Text(
                    "Select any from the list below to add your competency",
                    textAlign: TextAlign.start,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ))
              :  Container(
                  height: 0.0,
                ),
          PaddingWrap.paddingfromLTRB(
              13.0,
              10.0,
              13.0,
              0.0,
               Container(
                  decoration:  BoxDecoration(
                      color: Colors.white,
                      border:  Border.all(
                          color:   ColorValues.DEVIDER_COLOR,
                          width: 1.0)),
                  child:  InkWell(
                      child: ListTile(
                        trailing:  Container(
                            padding:  EdgeInsets.all(8.0),
                            height: 40.0,
                            width: 30.0,
                            child:  Image.asset(
                              listCompetency[position].isSelected
                                  ? "assets/newDesignIcon/competency/up_arrow.png"
                                  : "assets/newDesignIcon/competency/down_arrow.png",
                              height: 15.0,
                              width: 15.0,
                            )),
                        title:  Text(
                          listCompetency[position].level1,
                          style:  TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 16.0,
                              color:
                                   ColorValues.BLUE_COLOR_BOTTOMBAR),
                        ),
                      ),
                      onTap: () {
                        if (listCompetency[position].isSelected) {
                          listCompetency[position].isSelected = false;
                        } else {
                          listCompetency[position].isSelected = true;
                        }
                        setState(() {
                          if (position == (listCompetency.length - 1)) {
                            _controller.jumpTo(
                                _controller.position.maxScrollExtent + 80.0);
                          }

                          listCompetency[position].isSelected;
                        });
                      }))),
          listCompetency[position].isSelected
              ? PaddingWrap.paddingfromLTRB(
                  13.0,
                  10.0,
                  13.0,
                  5.0,
                   Container(
                      decoration:  BoxDecoration(
                          color: Colors.white,
                          border:  Border.all(
                              color:   ColorValues.DEVIDER_COLOR,
                              width: 1.0)),
                      child:  Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children:  List.generate(
                              listCompetency[position]
                                  .level2Competencylist
                                  .length, (int index) {
                            return PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                 Column(
                                  children: <Widget>[
                                     Container(

                                        child: ListTile(
                                      title:  Text(
                                        listCompetency[position]
                                            .level2Competencylist[index]
                                            .name,
                                        style:  TextStyle(
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 16.0,
                                            color:  ColorValues.HEADING_COLOR_EDUCATION),
                                      ),
                                      onTap: () {
                                        Navigator.of(context).pushReplacement(
                                             MaterialPageRoute(
                                                builder: (BuildContext context) =>
                                                     AddAchievmentOutSideTheAppWidget(
                                                         listCompetency[position].level1,
                                                        widget.userId,
                                                        widget.assestList,
                                                        listCompetency[position]
                                                            .level2Competencylist[
                                                        index]
                                                            .competencyTypeId,
                                                        listCompetency[position]
                                                            .level2Competencylist[
                                                        index]
                                                            .name,
                                                        listCompetency[position]
                                                            .level2Competencylist[index]
                                                            .level3Competencylist,
                                                         listCompetency[position]
                                                             .level2Competencylist
                                                     )));
                                      },
                                    )),
                                    (listCompetency[position]
                                                    .level2Competencylist
                                                    .length -
                                                1) ==
                                            index
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        :  Divider(
                                            color:   ColorValues.DEVIDER_COLOR,
                                            height: 1.0,
                                          )
                                  ],
                                ));
                          }))))
              :  Container(
                  height: 0.0,
                ),
        ],
      );
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            appBar:  AppBar(
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 3.0,
              elevation: 0.0,
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Expanded(
                    child:  InkWell(
                      child:  SizedBox(
              height: 40.0,
                width: 40.0,
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    5.0,
                    0.0,
                    3.0,
                     Center(
                        child:  Image.asset(
                            "assets/newDesignIcon/navigation/back.png",
                            height: 20.0,
                            width: 10.0,
                            fit: BoxFit.fitHeight))),
              ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                    flex: 0,
                  ),
                   Expanded(
                    child:  Text(
                      "Add to story",
                      textAlign: TextAlign.center,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                 Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                     InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          20.0,
                          0.0,
                          TextViewWrap.textView(
                              "",
                              TextAlign.start,
                               ColorValues.BLUE_COLOR_BOTTOMBAR,
                              16.0,
                              FontWeight.normal)),
                    )
                  ],
                )
              ],
              backgroundColor: Colors.white,
            ),
            body:  Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                 Container(),
                 Expanded(
                  child: listCompetency.length > 0
                      ?  ListView.builder(
                          controller: _controller,
                          itemCount: listCompetency.length,
                          itemBuilder: (BuildContext context, int position) {
                            return getCompetencyItem(position);
                          })
                      :  Container(),
                  flex: 1,
                )
              ],
            )));
  }
}
