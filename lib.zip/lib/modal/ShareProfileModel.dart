import 'dart:io';

class ShareProfileModal {
  String sharedId, profileOwner, sharedView, theme, shareTo, isActive, isViewed;

  List<FilterModel> filterList;

  ShareProfileModal(this.sharedId, this.profileOwner, this.sharedView,
      this.theme, this.shareTo, this.isActive, this.isViewed, this.filterList);
}

class FilterModel {
  String importance, competencyTypeId;

  FilterModel(this.importance,this.competencyTypeId);
}
