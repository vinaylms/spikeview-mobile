import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/accomplishment/VideoViewBlack.dart';
import 'package:spike_view_project/accomplishment/portfolio/EditPortFolio.dart';
import 'package:spike_view_project/accomplishment/portfolio/PortfolioViewWidget.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfile.dart';
import 'package:spike_view_project/parentProfile/wizard/ACCompetenciesWidget.dart';
import 'package:spike_view_project/parentProfile/wizard/AddAccomplishment_Widget.dart';
import 'package:spike_view_project/parentProfile/wizard/AddChildEducationInitial.dart';
import 'package:spike_view_project/parentProfile/wizard/AddEducation_Widget.dart';
import 'package:spike_view_project/parentProfile/wizard/AllEducationListWidget.dart';
import 'package:spike_view_project/parentProfile/wizard/CompetenciesParentStudent.dart';
import 'package:spike_view_project/parentProfile/wizard/CompletedWizard.dart';
import 'package:spike_view_project/parentProfile/wizard/EditAccomplishmentWidget.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/education/AddEducation.dart';
import 'package:spike_view_project/education/EditEducationWidget.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parentProfile/wizard/ProfilePic_Widget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/accomplishment/AddAchievment.dart';

import 'package:spike_view_project/accomplishment/EditAchievment.dart';
import 'package:spike_view_project/profile/UserProfileDashBoard.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/parentProfile/wizard/AddChildInterestWidget.dart';
import 'package:url_launcher/url_launcher.dart';

// Create a Form Widget
class AllAccomplishmentListWidget extends StatefulWidget {
  bool isEditable = true;

  AllAccomplishmentListWidget(this.studModel);

  StudentDataModel studModel;

  @override
  AllAccomplishmentListState createState() {
    return  AllAccomplishmentListState(studModel);
  }
}

class AllAccomplishmentListState extends State<AllAccomplishmentListWidget> {
  AllAccomplishmentListState(this.studModel);

  String userIdPref, token;
  List<ProfileEducationModal> userEducationList =  List();
  String isPerformChnges = "pop";
  SharedPreferences prefs;
  StudentDataModel studModel;
  String sasToken, containerName;
  StreamSubscription<dynamic> _streamSubscriptionWizard;
  ScrollController _scrollController =  ScrollController();

  bool hasIncompleteAchievement = false;
  List<NarrativeModel> narrativeList =  List<NarrativeModel>();
  List<int> indexRemoveList =  List<int>();
  List<NarrativeModel> mainNarrativeList =  List<NarrativeModel>();
  int achievmentCount = 0;
  int previousNaratiiveLisSize = 0;
  static StreamController syncDoneController = StreamController.broadcast();

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_WIZARD_USERID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    // narrativeApi();
    narrativeApi(true);
    callApiForSaas();
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    _streamSubscriptionWizard =
        AddAchievmentFormStateNEW.syncDoneController.stream.listen((value) {
      narrativeApi(true);
    });

    super.initState();
  }

  Future apiCallWizardCompleted() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_COMPLETED_WIZARD +
              prefs.getString(UserPreference.PARENT_WIZARD_USERID),
          "get",
        );
        print("wizardapi" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            widget.studModel.isWizardCompleted = "true";
            /*     Navigator.of(context)
                .popUntil((route) => route.isFirst);
            syncDoneController.add("suceess");*/
            Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) =>
                     CompletedWizard(widget.studModel.userId)));
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future narrativeApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_NARRATIVE +
                prefs.getString(UserPreference.PARENT_WIZARD_USERID),
            "get");

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            try {
              hasIncompleteAchievement =
                  response.data['hasIncompleteAchievement'];
            } catch (e) {
              hasIncompleteAchievement = false;
            }

            if (status == "Success") {
              narrativeList.clear();
              mainNarrativeList.clear();
              achievmentCount = 0;
              narrativeList = ParseJson.parseMapNarrative(
                  response.data['result'], widget.isEditable);
              if (narrativeList.length > 0) {
                try {
                  mainNarrativeList = await narrativeList
                      .map((item) =>  NarrativeModel.clone(item))
                      .toList();
                } catch (e) {
                  e.toString();
                }
                if (mounted) {
                  setState(() {
                    hasIncompleteAchievement;
                    if (!isShowLoader) {
                      previousNaratiiveLisSize = narrativeList.length;
                      print("length of narative list size :-" +
                          narrativeList.length.toString());
                    }
                    for (int i = 0; i < narrativeList.length; i++) {
                      achievmentCount = achievmentCount +
                          narrativeList[i].achivmentList.length;
                    }
                    achievmentCount;
                    narrativeList;
                    mainNarrativeList;
                  });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCallingForDeleteAchievment(achievementId, index1, index) async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "achievementId": achievementId,
      };

      Response response = await  ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
      CustomProgressLoader.cancelLoader(context);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            // Rtemove from List
            setState(() {
              narrativeList[index].achivmentList.removeAt(index);
              achievmentCount = achievmentCount - 1;
              if (achievmentCount == 0) {
                //UserProfileDashBoardState.isAchivmentAdded="false";
                ParentProfilePageState.isAchivmentAdded = "false";
                widget.studModel.isAchievement = "false";
                setState(() {
                  widget.studModel.isAchievement;
                });

                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                         CompetenciesParentStudent(
                            this.sasToken,
                            studModel.email,
                            studModel.lastName == "" ||
                                    studModel.lastName == "null"
                                ? studModel.firstName
                                : studModel.firstName +
                                    " " +
                                    studModel.lastName,
                            this.studModel,
                            "")));
              }
            });
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    void confromationDialog(index1, index) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to remove this Accomplishment?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Remove",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);

                                                apiCallingForDeleteAchievment(
                                                    narrativeList[index1]
                                                        .achivmentList[index]
                                                        .achievementId,
                                                    index1,
                                                    index);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

//============================================ grid view achevements nd core logic =====================================

    Row getUpperDots() {
      return  Row(
        children: <Widget>[
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
        ],
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
      );
    }

    Container getBottomBar() {
      return  Container(
          child:  Row(
        children: <Widget>[
           InkWell(
            child:  Padding(
                padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                child: Image.asset(
                  'assets/newDesignIcon/parentProfile/backword.png',
                  height: 45.0,
                  width: 45.0,
                )),
            onTap: () {
              onBackwordClick();
            },
          ),
           Expanded(
            child:  InkWell(
              child:  Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                  child:  Text(
                    "",
                    style: TextStyle(
                        fontSize: 16.0,
                        fontFamily: Constant.customRegular,
                        color: ColorValues.GREY_TEXT_COLOR),
                    textAlign: TextAlign.center,
                  )),
              onTap: () {
                // skipOnClick();
              },
            ),
            flex: 1,
          ),
          true
              ?  InkWell(
                  child:  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                      child: Image.asset(
                        'assets/newDesignIcon/parentProfile/next.png',
                        height: 45.0,
                        width: 45.0,
                      )),
                  onTap: () {
                    onNextClick();
                  },
                )
              :  Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
                  child: Image.asset(
                    'assets/newDesignIcon/parentProfile/next_gray.png',
                    height: 35.0,
                    width: 35.0,
                  ))
        ],
      ));
    }

    onTapDetailAchievment(achiv, String level1) async {
      print("---------CLICK ON EDIT");

      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>  EditAccomplishmentWidget(
              achiv, sasToken, studModel.dob, level1)));

      if (result == "push") {
        narrativeApi(true);
      }
    }

    String getConvertedDateStamp2(String time) {
      if (time != "null") {
        int millis = int.tryParse(time);
        var now =  DateTime.fromMillisecondsSinceEpoch(millis);
        var formatter =  DateFormat('MMM dd, yyyy');
        String formatted = formatter.format(now);
        return formatted;
      } else {
        //  strEnd = getConvertedDateStamp(new DateTime.now().millisecondsSinceEpoch.toString());
        return "Ongoing";
      }
    }

    Widget _loader(BuildContext context, String placeHolderImage) => Center(
            child: Container(
          child:  Image.asset(
            placeHolderImage,
            fit: BoxFit.cover,
          ),
        ));

    Widget _error(String placeHolderImage) {
      return Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.fill,
        ),
      );
    }

    Container getgridBadges(narativeListIndex, index) {
      return narrativeList[narativeListIndex]
                      .achivmentList[index]
                      .allCer_Badge_Trophy !=
                  null &&
              narrativeList[narativeListIndex]
                      .achivmentList[index]
                      .allCer_Badge_Trophy
                      .length >
                  0
          ?  Container(
              padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
              child: Column(
                children: <Widget>[
                   Row(
                    children: <Widget>[
                       Image.asset(
                        "assets/newDesignIcon/userprofile/certificate.png",
                        width: 12.0,
                        height: 10.0,
                      ),
                      TextViewWrap.textView(
                          "  CERTIFICATES, TROPHIES & BADGES",
                          TextAlign.start,
                           ColorValues.HEADING_COLOR_EDUCATION,
                          12.0,
                          FontWeight.w400)
                    ],
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      10.0,
                       Container(
                          height: 48.0,
                          child:  GridView.count(
                            primary: true,
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.all(5.0),
                            crossAxisCount: 1,
                            childAspectRatio: .98,
                            mainAxisSpacing: 5.0,
                            crossAxisSpacing: 4.0,
                            children:  List.generate(
                                narrativeList[narativeListIndex]
                                    .achivmentList[index]
                                    .allCer_Badge_Trophy
                                    .length, (int index2) {
                              return  Container(
                                  decoration:  BoxDecoration(
                                      border:  Border.all(
                                          color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                  child:  InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                         CachedNetworkImage(
                                          height: 45.0,
                                          width: 48.0,
                                          imageUrl: Constant.IMAGE_PATH +
                                              narrativeList[narativeListIndex]
                                                  .achivmentList[index]
                                                  .allCer_Badge_Trophy[index2],
                                          fit: BoxFit.cover,
                                          placeholder: (context, url) => _loader(
                                              context,
                                              "assets/profile/default_achievement.png"),
                                          errorWidget: (context, url, error) =>
                                              _error(
                                                  "assets/profile/default_achievement.png"),
                                        )),
                                    onTap: () {
                                      Navigator.of(context).push(new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                               CommonFullViewWidget(
                                                  narrativeList[
                                                          narativeListIndex]
                                                      .achivmentList[index]
                                                      .allCer_Badge_Trophy,
                                                  MessageConstant
                                                      .CERTIFICATES_TROPHIES_HEDING,
                                                  index2,
                                                  MessageConstant
                                                      .CERTIFICATES_TROPHIES_HEDING)));
                                    },
                                  ));
                            }),
                          ))),
                ],
              ))
          :  Container(
              height: 1.0,
            );
    }

    Container getPersonalReflection(narativeListIndex, index) {
      return narrativeList[narativeListIndex]
          .achivmentList[index]
          .personalReflection !=
          null && narrativeList[narativeListIndex]
          .achivmentList[index]
          .personalReflection !=
          'null' && narrativeList[narativeListIndex]
          .achivmentList[index]
          .personalReflection !=
          ''
          ? Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
        child: Container(
          decoration:
          BoxDecoration(
            borderRadius:
            BorderRadius.circular(
                0),
            color:  Color(
                0xFFFF3F7FC),
            border:
            Border
                .all(
              color: Color(
                  0xFFFF3F7FC),
              style: BorderStyle
                  .solid,
              width:
              1.0,
            ),
          ),
          child:  Padding(
            padding:  EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                 Row(
                  children: <Widget>[
                     Expanded(
                      child:  Image.asset(
                        "assets/newDesignIcon/ad_new/user_pr.png",
                        width: 15.0,
                        height: 15.0,
                      ),
                      flex: 0,
                    ),
                     Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          0.0,
                          0.0,
                          TextViewWrap.textView(
                              "Personal Reflection".toUpperCase(),
                              TextAlign.start,
                               ColorValues.HEADING_COLOR_EDUCATION,
                              12.0,
                              FontWeight.bold)),
                      flex: 0,
                    ),
                    /*new Expanded(
                        child:  Image.asset(
                          "assets/newDesignIcon/ad_new/info_icon.png",
                          width: 10.0,
                          height: 10.0,
                        ),
                        flex: 0,
                      ),
                       Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            20.0,
                            0.0,
                            10.0,
                            0.0,
                             Container(
                              child: CustomViews.getSepratorLine(),
                            )),
                        flex: 1,
                      )*/
                  ],
                ),
                /*PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      0.0,
                      TextViewWrap.textViewMultiLine(
                          "${narrativeList[narativeListIndex]
                              .achivmentList[index]
                              .personalReflection.trim()}",
                          TextAlign.start,
                           ColorValues.HEADING_COLOR_EDUCATION,
                          16.0,
                          FontWeight.normal,6)),*/

                //=========Show more / less ===========
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    10.0,
                    0.0,
                    5.0,
                     Text(
                      narrativeList[narativeListIndex]
                          .achivmentList[
                      index]
                          .personalReflection.trim(),
                      maxLines: narrativeList[
                      narativeListIndex]
                          .achivmentList[
                      index]
                          .isShowMorePersonalRef
                          ? 25
                          : 3,
                      overflow: TextOverflow
                          .ellipsis,
                      textAlign:
                      TextAlign.start,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 16.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    )),

                 Expanded(
                  child: narrativeList[
                  narativeListIndex]
                      .achivmentList[
                  index]
                      .personalReflection.trim()
                      .length >
                      130
                      ?  InkWell(
                    child: PaddingWrap
                        .paddingfromLTRB(
                        0.0,
                        0.0,
                        15.0,
                        0.0,
                         Text(
                          narrativeList[narativeListIndex].achivmentList[index].isShowMorePersonalRef
                              ? "Less"
                              : "More",
                          maxLines:
                          1,
                          overflow:
                          TextOverflow.ellipsis,
                          textAlign:
                          TextAlign.start,
                          style:  TextStyle(
                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                              fontSize: 14.0,
                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                        )),
                    onTap: () {
                      if (narrativeList[
                      narativeListIndex]
                          .achivmentList[
                      index]
                          .isShowMorePersonalRef)
                        narrativeList[narativeListIndex]
                            .achivmentList[
                        index]
                            .isShowMorePersonalRef = false;
                      else
                        narrativeList[narativeListIndex]
                            .achivmentList[
                        index]
                            .isShowMorePersonalRef = true;
                      setState(() {
                        narrativeList[
                        narativeListIndex]
                            .achivmentList[
                        index]
                            .isShowMorePersonalRef;
                      });
                    },
                  )
                      :  Container(
                    height: 0.0,
                  ),
                  flex: 0,
                ),
                //=====================
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    4.0,
                    0.0,
                    7.0,
                    TextViewWrap.textViewMultiLineItalic(
                        "Note: Personal reflection is a note to self and will not be shared with anyone.",
                        TextAlign.start,
                         ColorValues.ORANGE_TEXT_COLOR,
                        10.0,
                        FontWeight.normal,
                        4)),
              ],
            ),
          ),
        ),
      )
          :  Container(
        height: 1.0,
      );
    }

    Widget isImageOrVideo(Assest _mPortFolioAssest, heigt, type) {
      return _mPortFolioAssest.type == "image"
          ?  Container(
              height: heigt,
              child:  CachedNetworkImage(
                width: double.infinity,
                height: heigt,
                imageUrl: Constant.IMAGE_PATH + _mPortFolioAssest.file,
                fit: BoxFit.cover,
                placeholder: (context, url) => _loader(
                    context,
                    type == "Sports"
                        ? "assets/portfolio/sport_default.png"
                        : "assets/portfolio/arts_default.png"),
                errorWidget: (context, url, error) => _error(type == "Sports"
                    ? "assets/portfolio/sport_default.png"
                    : "assets/portfolio/arts_default.png"),
              ))
          :  Container(
              height: heigt,
              width: double.infinity,
              child: /*new VideoPlayPause(Constant.IMAGE_PATH + _mPortFolioAssest.file, "")*/

                   VideoView(Constant.IMAGE_PATH + _mPortFolioAssest.file,
                      "", false, type));
    }

    onTapEditPortFolio(achiv, String level1) async {
      ProfileInfoModal profileInfoModal =  ProfileInfoModal(
          studModel.userId,
          studModel.firstName,
          studModel.lastName,
          studModel.email,
          studModel.mobileNo,
          studModel.profilePicture,
          studModel.roleId,
          studModel.isActive,
          studModel.requireParentApproval,
          studModel.ccToParents,
          studModel.lastAccess,
          "true",
          studModel.organizationId,
          studModel.gender,
          studModel.dob,
          studModel.genderAtBirth,
          studModel.usCitizenOrPR,
          null,
          studModel.summary,
          studModel.coverImage,
          studModel.tagline,
          studModel.title,
          studModel.tempPassword,
          studModel.isArchived,
          null,
          false,
          "",
          "",
          "",
          "",
          "",
          "",
          studModel.isHide,
          false,
          false,
          studModel.stage,
          "",
          studModel.badge,
          studModel.gamificationPoints,
          studModel.badgeImage,
          "",
          null,
          "",
          false,
          false,
          null,null,false,false,null,"",'',"",false,false);
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               EditPortFolio(achiv, sasToken, level1,studModel.userId.toString(), pageName: "parent")));
      ;
      if (result == "push") {
        narrativeApi(true);
      }
    }

    Widget getgridAchivement(index1) {
      return narrativeList[index1].achivmentList != null &&
              narrativeList[index1].achivmentList.length > 0
          ?  Column(
              children: <Widget>[
                 Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:  List.generate(
                        narrativeList[index1].achivmentList.length > 2
                            ? narrativeList[index1].isShowAll
                                ? narrativeList[index1].achivmentList.length
                                : 2
                            : narrativeList[index1].achivmentList.length,
                        (int index) {
                      int size = narrativeList[index1]
                          .achivmentList[index]
                          .fileList
                          .length;

                      return narrativeList[index1].achivmentList[index].type ==
                              "portfolio"
                          ?  Column(
                              children: <Widget>[
                                 InkWell(
                                  child:  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          10.0,
                                          0.0,
                                          10.0,
                                          PaddingWrap.paddingfromLTRB(
                                              13.0,
                                              0.0,
                                              13.0,
                                              0.0,
                                              Column(
                                                children: [
                                                  Stack(
                                                    children: [
                                                      narrativeList[index1]
                                                                  .achivmentList[
                                                                      index]
                                                                  .fileList
                                                                  .length <
                                                              4
                                                          ? narrativeList[index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .fileList
                                                                      .length ==
                                                                  0
                                                              ?  Container(
                                                                  height: 165.0,
                                                                  width: double
                                                                      .infinity,
                                                                  child:
                                                                       Image
                                                                          .asset(
                                                                    narrativeList[index1].level1 ==
                                                                            "Sports"
                                                                        ? "assets/portfolio/sport_default.png"
                                                                        : "assets/portfolio/arts_default.png",
                                                                    fit: BoxFit
                                                                        .fill,
                                                                  ),
                                                                )
                                                              : Padding(
                                                                  padding:
                                                                      const EdgeInsets
                                                                              .fromLTRB(
                                                                          3.0,
                                                                          0,
                                                                          3,
                                                                          0),
                                                                  child: isImageOrVideo(
                                                                      narrativeList[index1]
                                                                              .achivmentList[
                                                                                  index]
                                                                              .fileList[
                                                                          size -
                                                                              1],
                                                                      160.0,
                                                                      narrativeList[
                                                                              index1]
                                                                          .level1))
                                                          :  Column(
                                                              children: [
                                                                 Row(
                                                                  children: [
                                                                     Expanded(
                                                                      child: isImageOrVideo(
                                                                          narrativeList[index1].achivmentList[index].fileList[size -
                                                                              1],
                                                                          80.0,
                                                                          narrativeList[index1]
                                                                              .level1),
                                                                      flex: 1,
                                                                    ),
                                                                     Expanded(
                                                                      child: isImageOrVideo(
                                                                          narrativeList[index1].achivmentList[index].fileList[size -
                                                                              2],
                                                                          80.0,
                                                                          narrativeList[index1]
                                                                              .level1),
                                                                      flex: 1,
                                                                    )
                                                                  ],
                                                                ),
                                                                 Row(
                                                                  children: [
                                                                     Expanded(
                                                                      child: isImageOrVideo(
                                                                          narrativeList[index1].achivmentList[index].fileList[size -
                                                                              3],
                                                                          80.0,
                                                                          narrativeList[index1]
                                                                              .level1),
                                                                      flex: 1,
                                                                    ),
                                                                     Expanded(
                                                                      child: isImageOrVideo(
                                                                          narrativeList[index1].achivmentList[index].fileList[size -
                                                                              4],
                                                                          80.0,
                                                                          narrativeList[index1]
                                                                              .level1),
                                                                      flex: 1,
                                                                    )
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                       Container(
                                                        height: 165.0,
                                                        width: double.infinity,
                                                        child:  Image.asset(
                                                          "assets/portfolio/bg.png",
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                       Positioned(
                                                          top: 13.0,
                                                          right: 15.0,
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                   InkWell(
                                                                    onTap: () {
                                                                      onTapEditPortFolio(
                                                                          narrativeList[index1].achivmentList[
                                                                              index],
                                                                          narrativeList[index1]
                                                                              .level1);
                                                                    },
                                                                    child:  Image
                                                                        .asset(
                                                                      "assets/newDesignIcon/userprofile/edit_grey.png",
                                                                      height:
                                                                          20.0,
                                                                      width:
                                                                          20.0,
                                                                    ),
                                                                  ))),
                                                       Positioned(
                                                        right: 13.0,
                                                        top: 45.0,
                                                        left: 0.0,
                                                        child:  Row(
                                                          children: [
                                                             Expanded(
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .fromLTRB(
                                                                        13.0,
                                                                        0,
                                                                        0,
                                                                        0),
                                                                child:
                                                                     Container(
                                                                  width: 60.0,
                                                                  height: 60.0,
                                                                  child:
                                                                       Stack(
                                                                    children: <
                                                                        Widget>[
                                                                       Center(
                                                                          child:
                                                                               Container(
                                                                        child:  ClipOval(
                                                                            child:  CachedNetworkImage(
                                                                          imageUrl:
                                                                              Constant.IMAGE_PATH + narrativeList[index1].achivmentList[index].userImage,
                                                                          fit: BoxFit
                                                                              .cover,
                                                                          placeholder: (context, url) => _loader(
                                                                              context,
                                                                              "assets/profile/user_on_user.png"),
                                                                          errorWidget: (context, url, error) =>
                                                                              _error("assets/profile/user_on_user.png"),
                                                                        )),
                                                                        width:
                                                                            60.0,
                                                                        height:
                                                                            60.0,
                                                                        padding:  EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                      )),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                              flex: 0,
                                                            ),
                                                             Expanded(
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .fromLTRB(
                                                                        13.0,
                                                                        0,
                                                                        13,
                                                                        0),
                                                                child: Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                     Text(
                                                                        narrativeList[index1]
                                                                            .achivmentList[
                                                                                index]
                                                                            .title,
                                                                        style:  TextStyle(
                                                                            fontSize:
                                                                                18.0,
                                                                            color:
                                                                                Colors.white,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                     Text(
                                                                        narrativeList[index1].achivmentList[index].city +
                                                                            ", " +
                                                                            narrativeList[index1]
                                                                                .achivmentList[
                                                                                    index]
                                                                                .state,
                                                                        style:  TextStyle(
                                                                            fontSize:
                                                                                14.0,
                                                                            color:
                                                                                Colors.white,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                  ],
                                                                ),
                                                              ),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                  /*   InkWell(
                                                      child:  Container(
                                                          height: 40.0,
                                                          color:  Color(
                                                              0xffFF9900),
                                                          child: Center(
                                                              child:  Text(
                                                            "View My Portfolio",
                                                            style:  TextStyle(
                                                                fontSize: 14.0,
                                                                color: Colors
                                                                    .white),
                                                            textAlign: TextAlign
                                                                .center,
                                                          ))),
                                                      onTap: () {
                                                        Navigator.of(context).push(new MaterialPageRoute(
                                                            builder: (BuildContext
                                                                    context) =>
                                                                 PortfolioViewWidget(
                                                                    narrativeList[index1]
                                                                            .achivmentList[
                                                                        index],
                                                                    narrativeList[
                                                                            index1]
                                                                        .level1)));
                                                      }),*/
                                                ],
                                              ))),
                                      narrativeList[index1]
                                                  .achivmentList
                                                  .length >
                                              1
                                          ? index == 1 &&
                                                  narrativeList[index1]
                                                          .achivmentList
                                                          .length ==
                                                      2
                                              ?  Container(
                                                  height: 0.0,
                                                )
                                              : PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  0.0,
                                                  0.0,
                                                   Container(
                                                    height: 1.0,
                                                    color:
                                                         ColorValues.GREY__COLOR_DIVIDER,
                                                  ))
                                          :  Container(
                                              height: 0.0,
                                            )
                                    ],
                                  ),
                                  onTap: () {},
                                )
                              ],
                            )
                          :  Column(
                              children: <Widget>[
                                 Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                        //
                                        narrativeList[index1]
                                                    .achivmentList[index]
                                                    .mediaAndVideoList
                                                    .length >
                                                0
                                            ?  SizedBox(
                                                // Pager view
                                                height: 215.50,
                                                child: PageIndicatorContainer(
                                                  pageView:
                                                       PageView.builder(
                                                    itemCount: narrativeList[
                                                            index1]
                                                        .achivmentList[index]
                                                        .mediaAndVideoList
                                                        .length,
                                                    controller:
                                                         PageController(),
                                                    itemBuilder:
                                                        (context, index2) {
                                                      return  InkWell(
                                                        child:  Stack(
                                                            children: <Widget>[
                                                              narrativeList[index1]
                                                                          .achivmentList[
                                                                              index]
                                                                          .mediaAndVideoList[
                                                                              index2]
                                                                          .type ==
                                                                      "image"
                                                                  ? Container(
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                      child:
                                                                           CachedNetworkImage(
                                                                        width: double
                                                                            .infinity,
                                                                        height:
                                                                            215.50,
                                                                        imageUrl:
                                                                            Constant.IMAGE_PATH +
                                                                                narrativeList[index1].achivmentList[index].mediaAndVideoList[index2].file,
                                                                        /*fit: BoxFit
                                                                    .contain,*/
                                                                        fit: BoxFit
                                                                            .fitHeight,
                                                                        placeholder: (context, url) => _loader(
                                                                            context,
                                                                            "assets/aerial/default_img.png"),
                                                                        errorWidget: (context,
                                                                                url,
                                                                                error) =>
                                                                            _error("assets/aerial/default_img.png"),
                                                                      ))
                                                                  :  InkWell(
                                                                      child:
                                                                           Container(
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Colors.black,
                                                                          borderRadius:
                                                                              BorderRadius.circular(0),
                                                                        ),
                                                                        height:
                                                                            215.0,
                                                                        child:
                                                                             Center(
                                                                          child:  VideoPlayPauseNew(
                                                                              narrativeList[index1].achivmentList[index].mediaAndVideoList[index2].file,
                                                                              "",
                                                                              true,
                                                                              _scrollController),
                                                                          /*new Container(
                                                                    child:  Stack(
                                                                      children: <Widget>[

                                                                        Container(
                                                                          height: 215.0,
                                                                          color: Colors.black,
                                                                          margin: EdgeInsets.only(left: 0, right: 0),
                                                                          child:  VideoViewBlack(
                                                                              Constant.IMAGE_PATH + narrativeList[index1].achivmentList[index].mediaAndVideoList[index2].file, "", false, ""),
                                                                        ),
                                                                        */ /*new Container(
                                                                                      height: 54.0,
                                                                                      width: 80.0,
                                                                                      color:  Color(0XFFC0C0C0).withOpacity(.4),
                                                                                    ),*/ /*
                                                                         Center(
                                                                            child:  Row(
                                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                                              mainAxisAlignment: MainAxisAlignment.center,
                                                                              children: <Widget>[
                                                                                 InkWell(
                                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                                      0.0,
                                                                                      0.0,
                                                                                      0.0,
                                                                                      0.0,
                                                                                       Image.asset(
                                                                                        //'assets/pre_login/video_play_button.png',
                                                                                        'assets/newDesignIcon/circle_play.png',
                                                                                        width: 50.0,
                                                                                        height: 50.0,
                                                                                      )),
                                                                                )
                                                                              ],
                                                                            )),
                                                                      ],
                                                                    )),*/
                                                                        ),
                                                                      ),
                                                                    ),
                                                              narrativeList[index1]
                                                                              .achivmentList[
                                                                                  index]
                                                                              .mediaAndVideoList
                                                                              .length ==
                                                                          1 ||
                                                                      narrativeList[index1]
                                                                              .achivmentList[index]
                                                                              .mediaAndVideoList[index2]
                                                                              .type ==
                                                                          "video"
                                                                  ?  Container(
                                                                      height:
                                                                          0.0,
                                                                    )
                                                                  :  InkWell(
                                                                      onTap: () {
                                                                        Navigator.of(context).push(new MaterialPageRoute(
                                                                            builder: (BuildContext context) =>  CommonFullViewWidget(
                                                                                narrativeList[index1].achivmentList[index].mediaAndVideoList,
                                                                                MessageConstant.ACCOMPLISHMENT_HEDING,
                                                                                index2,
                                                                                narrativeList[index1].achivmentList[index].title)));
                                                                      },
                                                                      child:  Container(
                                                                        height:
                                                                            215.50,
                                                                        width: double
                                                                            .infinity,
                                                                        child:  Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/navigation/layer_image.png",
                                                                          fit: BoxFit
                                                                              .fill,
                                                                        ),
                                                                      ))
                                                            ]),
                                                        onTap: () {
                                                          Navigator.of(context).push(new MaterialPageRoute(
                                                              builder: (BuildContext context) =>  CommonFullViewWidget(
                                                                  narrativeList[
                                                                          index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .mediaAndVideoList,
                                                                  MessageConstant
                                                                      .ACCOMPLISHMENT_HEDING,
                                                                  index2,
                                                                  narrativeList[
                                                                          index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .title)));
                                                          /* Navigator.of(context).push(
                                                                 MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                         FullImageView(
                                                                          narrativeList[index1]
                                                                              .achivmentList[index]
                                                                              .mediaAndVideoList[index2]
                                                                              .file,
                                                                          pageName:
                                                                              "Media",
                                                                        )));*/
                                                        },
                                                      );
                                                    },
                                                    onPageChanged: (index) {},
                                                  ),
                                                  align: IndicatorAlign.bottom,
                                                  length: narrativeList[index1]
                                                      .achivmentList[index]
                                                      .mediaAndVideoList
                                                      .length,
                                                  indicatorSpace: 10.0,
                                                  indicatorColor: narrativeList[
                                                                  index1]
                                                              .achivmentList[
                                                                  index]
                                                              .mediaAndVideoList
                                                              .length ==
                                                          1
                                                      ? Colors.transparent
                                                      :  Color(0xffc4c4c4),
                                                  indicatorSelectorColor:
                                                      narrativeList[index1]
                                                                  .achivmentList[
                                                                      index]
                                                                  .mediaAndVideoList
                                                                  .length ==
                                                              1
                                                          ? Colors.transparent
                                                          :  Color(
                                                              0XFFFFFFFF),
                                                  shape: IndicatorShape.circle(
                                                      size: 5.0),
                                                ))
                                            :  Stack(children: <Widget>[
                                                 Image.asset(
                                                  "assets/profile/default_achievement.png",
                                                  fit: BoxFit.cover,
                                                  height: 215.50,
                                                  width: double.infinity,
                                                ),
                                              ])),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        PaddingWrap.paddingfromLTRB(
                                            17.0,
                                            10.0,
                                            17.0,
                                            0.0,
                                             Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                 Row(
                                                  children: <Widget>[
                                                     Expanded(
                                                      child: RichText(
                                                        maxLines: 15,
                                                        textAlign:
                                                            TextAlign.start,
                                                        text: TextSpan(
                                                          text: narrativeList[index1]
                                                                          .achivmentList[
                                                                              index]
                                                                          .focusArea ==
                                                                      null ||
                                                                  narrativeList[
                                                                              index1]
                                                                          .achivmentList[
                                                                              index]
                                                                          .focusArea ==
                                                                      "null" ||
                                                                  narrativeList[
                                                                              index1]
                                                                          .achivmentList[
                                                                              index]
                                                                          .focusArea ==
                                                                      ""
                                                              ? narrativeList[
                                                                          index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .level3Competency +
                                                                  " | "
                                                              : narrativeList[
                                                                          index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .focusArea +
                                                                  " | ",
                                                          style:  TextStyle(
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontSize: 16.0,
                                                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                          children: [
                                                             TextSpan(
                                                                text: narrativeList[
                                                                        index1]
                                                                    .achivmentList[
                                                                        index]
                                                                    .title,
                                                                style:
                                                                     TextStyle(
                                                                        color:
                                                                             ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                        fontSize:
                                                                            16.0,
                                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR)),
                                                          ],
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                     Expanded(
                                                      child:  InkWell(
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                 Image.asset(
                                                                  "assets/newDesignIcon/navigation/edit_circle.png",
                                                                  height: 35.0,
                                                                  width: 35.0,
                                                                )),
                                                        onTap: () {
                                                          onTapDetailAchievment(
                                                              narrativeList[
                                                                          index1]
                                                                      .achivmentList[
                                                                  index],
                                                              narrativeList[
                                                                      index1]
                                                                  .level1);
                                                        },
                                                      ),
                                                      flex: 0,
                                                    ),
                                                     Expanded(
                                                      child:  InkWell(
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                 Image.asset(
                                                                  "assets/newDesignIcon/navigation/cancel_circle.png",
                                                                  height: 35.0,
                                                                  width: 35.0,
                                                                )),
                                                        onTap: () {
                                                          // DELETE DATA
                                                          confromationDialog(
                                                              index1, index);
                                                        },
                                                      ),
                                                      flex: 0,
                                                    )
                                                  ],
                                                ),
                                                narrativeList[index1]
                                                                .achivmentList[
                                                                    index]
                                                                .fromDate ==
                                                            null ||
                                                        narrativeList[index1]
                                                                .achivmentList[
                                                                    index]
                                                                .fromDate ==
                                                            "null" ||
                                                        narrativeList[index1]
                                                                .achivmentList[
                                                                    index]
                                                                .fromDate ==
                                                            ""
                                                    ?  Container(
                                                        height: 0.0,
                                                      )
                                                    : PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            5.0,
                                                            0.0,
                                                            15.0,
                                                             Text(
                                                              getConvertedDateStamp2(narrativeList[
                                                                          index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .fromDate) +
                                                                  " - " +
                                                                  getConvertedDateStamp2(narrativeList[
                                                                          index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .toDate),
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                              maxLines: null,
                                                              style:  TextStyle(
                                                                  color:  Color(
                                                                      0xFF404040),
                                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                                  fontSize:
                                                                      14.0),
                                                            )),
                                                PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    5.0,
                                                    0.0,
                                                    5.0,
                                                     Text(
                                                      narrativeList[index1]
                                                          .achivmentList[index]
                                                          .description,
                                                      maxLines: narrativeList[
                                                                  index1]
                                                              .achivmentList[
                                                                  index]
                                                              .isShowMore
                                                          ? 25
                                                          : 2,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign:
                                                          TextAlign.start,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 14.0,
                                                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                    )),
                                                 Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: <Widget>[
                                                     Expanded(
                                                      child: narrativeList[
                                                                      index1]
                                                                  .achivmentList[
                                                                      index]
                                                                  .description
                                                                  .length >
                                                              130
                                                          ?  InkWell(
                                                              child: PaddingWrap
                                                                  .paddingfromLTRB(
                                                                      0.0,
                                                                      0.0,
                                                                      15.0,
                                                                      10.0,
                                                                       Text(
                                                                        narrativeList[index1].achivmentList[index].isShowMore
                                                                            ? "Less"
                                                                            : "More",
                                                                        maxLines:
                                                                            1,
                                                                        overflow:
                                                                            TextOverflow.ellipsis,
                                                                        textAlign:
                                                                            TextAlign.start,
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                            fontSize: 14.0,
                                                                            fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                                      )),
                                                              onTap: () {
                                                                if (narrativeList[
                                                                        index1]
                                                                    .achivmentList[
                                                                        index]
                                                                    .isShowMore)
                                                                  narrativeList[index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .isShowMore = false;
                                                                else
                                                                  narrativeList[index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .isShowMore = true;
                                                                setState(() {
                                                                  narrativeList[
                                                                          index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .isShowMore;
                                                                });
                                                              },
                                                            )
                                                          :  Container(
                                                              height: 0.0,
                                                            ),
                                                      flex: 0,
                                                    ),
                                                  ],
                                                ),
                                                getgridBadges(index1, index),
                                                //getPersonalReflection(index1, index),
                                              ],
                                            )),
                                        narrativeList[index1]
                                                        .achivmentList[index]
                                                        .externalLinksList
                                                        .length >
                                                    1 ||
                                                (narrativeList[index1]
                                                            .achivmentList[
                                                                index]
                                                            .externalLinksList
                                                            .length ==
                                                        1 &&
                                                    narrativeList[index1]
                                                            .achivmentList[
                                                                index]
                                                            .externalLinksList[
                                                                0]
                                                            .url
                                                            .toString() !=
                                                        "null" &&
                                                    narrativeList[index1]
                                                            .achivmentList[
                                                                index]
                                                            .externalLinksList[
                                                                0]
                                                            .url
                                                            .toString() !=
                                                        "")
                                            ? Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        0.0, 0, 0, 13),
                                                child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                   /*  Divider(
                                                      color:  ColorValues.BORDER_COLOR,
                                                    ),*/
                                                    PaddingWrap.paddingfromLTRB(
                                                        17.0,
                                                        0.0,
                                                        17.0,
                                                        0.0,
                                                         Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: [
                                                             Row(
                                                              children: <Widget>[
                                                                 Expanded(
                                                                  child:  Image.asset(
                                                                    "assets/ic_link.png",
                                                                    width: 15.0,
                                                                    height: 15.0,
                                                                  ),
                                                                  flex: 0,
                                                                ),
                                                                 Expanded(child: PaddingWrap.paddingfromLTRB(7.0, 0.0, 5.0, 0.0, TextViewWrap.textView("EXTERNAL  LINKS", TextAlign.start,  ColorValues.HEADING_COLOR_EDUCATION, 12.0, FontWeight.w400)), flex: 0),
                                                                 Expanded(
                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                       Container(
                                                                        child: CustomViews.getSepratorLine(),
                                                                      )),
                                                                  flex: 1,
                                                                )
                                                              ],
                                                            ),
                                                             Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: List.generate(
                                                                  narrativeList[index1]
                                                                      .achivmentList[
                                                                          index]
                                                                      .externalLinksList
                                                                      .length,
                                                                  (index2) {
                                                                return narrativeList[index1].achivmentList[index].externalLinksList[index2].label.toString() !=
                                                                            "null" &&
                                                                        narrativeList[index1].achivmentList[index].externalLinksList[index2].label.toString() !=
                                                                            ""
                                                                    ?  Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: [
                                                                          Padding(
                                                                            padding: const EdgeInsets.fromLTRB(
                                                                                0.0,
                                                                                10,
                                                                                0,
                                                                                0),
                                                                            child:
                                                                                 InkWell(
                                                                              onTap: () {
                                                                                /*if (narrativeList[index1].achivmentList[index].externalLinksList[index2].url.toLowerCase().contains("http")) {
                                                                                  launch(narrativeList[index1].achivmentList[index].externalLinksList[index2].url);
                                                                                } else {
                                                                                  String url = "http://" + narrativeList[index1].achivmentList[index].externalLinksList[index2].url;
                                                                                  launch(url);
                                                                                }*/
                                                                                //apurva added
                                                                                if (narrativeList[index1].achivmentList[index].externalLinksList[index2].url.toLowerCase().contains("http")) {
                                                                                  print('apurva contain httpS ELSE');
                                                                                  launch(narrativeList[index1].achivmentList[index].externalLinksList[index2].url.trim());
                                                                                } else {
                                                                                  print('apurva contain http');
                                                                                  launch("http://" + narrativeList[index1].achivmentList[index].externalLinksList[index2].url.trim());
                                                                                }
                                                                              },
                                                                              child:  Text(narrativeList[index1].achivmentList[index].externalLinksList[index2].label, style:  TextStyle(fontSize: 14.0, color:  ColorValues.BLUE_COLOR_BOTTOMBAR, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                            ),
                                                                          ),
                                                                          narrativeList[index1].achivmentList[index].externalLinksList[index2].description.toString() == "null" || narrativeList[index1].achivmentList[index].externalLinksList[index2].description.toString() == ""
                                                                              ?  Container(
                                                                                  height: 0.0,
                                                                                )
                                                                              : Padding(
                                                                                  padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                                                                                  child:  Text(narrativeList[index1].achivmentList[index].externalLinksList[index2].description, style:  TextStyle(fontSize: 16.0, color:  ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                                ),
                                                                        ],
                                                                      )
                                                                    :  Container(
                                                                        height:
                                                                            0.0,
                                                                        width:
                                                                            0.0,
                                                                      );
                                                              }),
                                                            )
                                                          ],
                                                        ))
                                                  ],
                                                ),
                                              )
                                            :  Container(
                                                height: 0.0,
                                              )



                                      ],
                                    ),
                                    narrativeList[index1].achivmentList.length >
                                            1
                                        ? index == 1 &&
                                                narrativeList[index1]
                                                        .achivmentList
                                                        .length ==
                                                    2
                                            ?  Container(
                                                height: 0.0,
                                              )
                                            : PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                0.0,
                                                0.0,
                                                 Container(
                                                  height: 1.0,
                                                  color:  ColorValues.GREY__COLOR_DIVIDER,
                                                ))
                                        :  Container(
                                            height: 0.0,
                                          )
                                  ],
                                )
                              ],
                            );
                    })),
                narrativeList[index1].achivmentList.length > 2
                    ?  InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                            6.0,
                            6.0,
                            6.0,
                            10.0,
                            narrativeList[index1].isShowAll
                                ?  Text(
                                    "View Less" +
                                        narrativeList[index1].name +
                                        " Achievements",
                                    style:  TextStyle(
                                        color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontSize: 14.0,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                  )
                                :  Text(
                                    "View All " +
                                        narrativeList[index1]
                                            .achivmentList
                                            .length
                                            .toString() +
                                        " " +
                                        narrativeList[index1].name +
                                        " Achievements",
                                    style:  TextStyle(
                                        color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontSize: 14.0,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                  )),
                        onTap: () {
                          setState(() {
                            if (narrativeList[index1].isShowAll) {
                              narrativeList[index1].isShowAll = false;
                            } else {
                              narrativeList[index1].isShowAll = true;
                            }
                          });
                        },
                      )
                    :  Container(
                        height: 0.0,
                        color: Colors.black,
                      ),
              ],
            )
          : PaddingWrap.paddingfromLTRB(
              0.0,
              0.0,
              0.0,
              0.0,
               Container(
                height: 0.0,
              ));
    }

    final double statusBarHeight = MediaQuery.of(context).padding.top;
    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChnges);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            body:  Column(
              children: <Widget>[
                Padding(
                  padding:  EdgeInsets.only(top: statusBarHeight + 20,left: 13.0,right: 13.0,bottom: 7),
                  child: Center(
                    child:  Image.asset(
                        "assets/progress_indecator/indicator_step4.png",
                        height: 26.0,
                        width: 300.0,
                        fit: BoxFit.fitWidth
                    ),
                  ),
                ),
                 Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: 20, left: 13, right: 13),
                    child:  Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                         Text(
                          //"Step 4 of 7",
                          "",
                          style:  TextStyle(
                              fontSize: 15.0,
                              fontFamily: Constant.customRegular,
                              color:   ColorValues.HEADING_COLOR_EDUCATION),
                        ),
                        InkWell(
                          child:  Text(
                            "SKIP ",
                            style:  TextStyle(
                                fontSize: 14.0,
                                fontFamily: Constant.customRegular,
                                color:  ColorValues.GREY_TEXT_COLOR),
                          ),
                          onTap: () {
                            onNextClick();
                          },
                        ),
                      ],
                    ),
                  ),
                  flex: 0,
                ),

                 Expanded(
                  child:  ListView(
                    controller: _scrollController,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
                        child:  Image.asset(
                            "assets/profile/student/acc_student.png",
                            height: 50.0,
                            width: 50.0,
                            fit: BoxFit.fitHeight),
                      ),
                      PaddingWrap.paddingfromLTRB(
                          20.0,
                          0.0,
                          20.0,
                          5.0,
                          TextViewWrap.textViewMultiLine(
                              "Add Accomplishment",
                              TextAlign.center,
                               ColorValues.HEADING_COLOR_EDUCATION,
                              18.0,
                              FontWeight.bold,
                              6)),
                      PaddingWrap.paddingfromLTRB(
                          20.0,
                          0.0,
                          20.0,
                          11.0,
                          TextViewWrap.textViewMultiLine(
                              "Share some of your child’s experiences, achievements, and accomplishments. Include extracurricular activities, clubs, hobbies, work, internships, awards, projects, performance videos, blogs etc.",
                              TextAlign.center,
                               ColorValues.HEADING_COLOR_EDUCATION,
                              14.0,
                              FontWeight.normal,
                              6)),
                       Column(
                        children: <Widget>[
                           Container(
                              padding:
                                   EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                              child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:  List.generate(
                                      narrativeList.length, (int index) {
                                    return narrativeList[index]
                                                .achivmentList
                                                .length ==
                                            0
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        : PaddingWrap.paddingfromLTRB(
                                            13.0,
                                            10.0,
                                            13.0,
                                            0.0,
                                             Card(
                                                elevation: 0.0,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0.0)),
                                                child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    narrativeList[index]
                                                                    .achivmentList
                                                                    .length ==
                                                                0 &&
                                                            narrativeList[index]
                                                                    .recommendationtList
                                                                    .length ==
                                                                0
                                                        ?  Container(
                                                            height: 0.0,
                                                          )
                                                        :  Column(
                                                            children: <Widget>[
                                                                 Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    PaddingWrap.paddingfromLTRB(
                                                                        17.0,
                                                                        10.0,
                                                                        17.0,
                                                                        0.0,
                                                                        TextViewWrap.textViewSingleLine(
                                                                            narrativeList[index].name,
                                                                            TextAlign.start,
                                                                             ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                                            20.0,
                                                                            FontWeight.normal)),
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                            19.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                             Image.asset(
                                                                              "assets/newDesignIcon/userprofile/line.png",
                                                                              height: 3.0,
                                                                              width: 40.0,
                                                                            )),
                                                                  ],
                                                                )
                                                              ]),
                                                    narrativeList[index]
                                                            .isVisible
                                                        ?  Column(
                                                            children: <Widget>[
                                                              narrativeList[index]
                                                                          .achivmentList
                                                                          .length >
                                                                      0
                                                                  ?  InkWell(
                                                                      child: getgridAchivement(
                                                                          index),
                                                                    )
                                                                  :  Container(
                                                                      height:
                                                                          0.0,
                                                                    ),
                                                            ],
                                                          )
                                                        :  Container(
                                                            height: 0.0,
                                                          ),
                                                  ],
                                                )));
                                  }))),
                           Padding(
                              padding:
                                  EdgeInsets.fromLTRB(15.0, 10.0, 0.0, 0.0),
                              child:  InkWell(
                                child:  Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Icon(
                                      Icons.add,
                                      color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                      size: 30.0,
                                    ),
                                     Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            10.0, 10.0, 0.0, 10.0),
                                        child:  Text(
                                          "ADD MORE ACCOMPLISHMENT",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                              fontFamily:
                                                  Constant.customRegular,
                                              fontSize: 16.0),
                                        ))
                                  ],
                                ),
                                onTap: () {
                                  addMoreEducationOnClick();
                                },
                              ))
                        ],
                      )
                    ],
                  ),
                  flex: 1,
                ),
                 Container(
                  child: getBottomBar(),
                )
              ],
            )));
  }

  void skipOnClick() {
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
             CompletedWizard(widget.studModel.userId)));
  }

  void onNextClick() {
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  AddChildStudentInterestWidget(
            widget.studModel, '', sasToken, 4)));
    // make Api Call

    //Move to Accomplishment Page
  }

  void onBackwordClick() {
    Navigator.pop(context);
    /*if (ParentProfilePageState.isEducationAdded == "true") {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
           AllEducationListWidget(studModel)));
    } else {
      */ /*Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
             AddEducation_Widget(studModel, "yes","")));*/ /*

      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
           AddChildEducationInitial(studModel, "yes","")));
    }*/
  }

  void addMoreEducationOnClick() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  CompetenciesParentStudent(
            this.sasToken,
            studModel.email,
            studModel.lastName == "" || studModel.lastName == "null"
                ? studModel.firstName
                : studModel.firstName + " " + studModel.lastName,
            this.studModel,
            "all")));
    if (result == "push") narrativeApi(true);
    /*   Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  ACCompetenciesWidget(
            sasToken,
            studModel.email,
            studModel.lastName == "" || studModel.lastName == "null"
                ? studModel.firstName
                : studModel.firstName + " " + studModel.lastName,
            studModel,
            "all")));*/
  }
}
