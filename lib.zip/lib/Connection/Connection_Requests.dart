import 'dart:async';
import 'dart:convert';
import 'package:firebase_core/firebase_core.dart';

import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/Connection/RefferalModel.dart';
import 'package:spike_view_project/Connection/RequestsSeeAllWidget.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/patnerFlow/InviteNonSpikeViewMember.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';
import 'package:spike_view_project/profile/DiscoverWidget.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';

class ConnectionRequests extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  ConnectionRequestsState();
  }
}

class ConnectionRequestsState extends State<ConnectionRequests>
    with AutomaticKeepAliveClientMixin {
  SharedPreferences prefs;
  String userIdPref, roleId, userProfilePath, dob;
  int diffrenceInDob = 0;
  List<RequestedTagModel> tagList =  List();
  List<RequestedTagModel> sendRequestList =  List();
  List<RequestedTagModel> pendinForParentDataList =  List();
  List<RequestedTagModel> receivedRequestList =  List();
  List<RefferalModel> refferList =  List();
  List<PeopleYouMayKnow> peopleYouMayKnowList =  List();

  StreamSubscription<dynamic> _streamSubscription;
  Map<String, String> dataExist =  Map();
  bool isLoading = true;
  bool isViewAllForSentRequest = false;
  bool isViewAllForPendingRequest = false;
  bool isViewAllReceivedRequestList = false;
  bool isViewAllForRequest = false;
  bool isViewAllForPeopleMayYouKnow = false;
  int acceptedCount = 0,
      sentRequestCount = 0,
      pendingRequestCount = 0,
      PeopleYouMayKnowCount = 0,
      receivedRequestCount = 0,
      referralCount = 0,
      requestedCount = 0;

  //--------------------------api Calling for tag------------------
  Future apiCallingForTag2() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });

        Response response = await  ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY +
                userIdPref +
                "&roleId=" +
                roleId+"&skip=0",
            "get");
      print("ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY"+Constant.ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY + userIdPref + "&roleId=" + roleId+"skip=0");
        print("response" + response.toString());
        isLoading = false;
        setState(() {
          isLoading;
        });

        print("ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY Response" + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              List<PeopleYouMayKnow> peopleYouMayKnowListLocal =
                  ParseJson.parsePeopleMayYouKnow(
                      response.data['result']['PeopleYouMayKnow']);

              print("size====" + peopleYouMayKnowListLocal.length.toString());

              for (var PeopleYouMayKnow in peopleYouMayKnowListLocal) {
                if (!dataExist.containsKey(PeopleYouMayKnow.userId)) {
                  var s = dataExist.putIfAbsent(
                      PeopleYouMayKnow.userId, () => PeopleYouMayKnow.userId);
                  print("shubhsss======" +
                      PeopleYouMayKnow.firstName +
                      "    " +
                      s.toString());
                } else {
                  print("shubhsss delete ====" + PeopleYouMayKnow.firstName);
                  peopleYouMayKnowListLocal.remove(PeopleYouMayKnow);
                }
              }

              peopleYouMayKnowList.addAll(peopleYouMayKnowListLocal);

              setState(() {
                peopleYouMayKnowList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallingForRefresh() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });

        Response response = await  ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY +
                userIdPref +
                "&roleId=" +
                roleId+"&skip=0",
            "get");

        print("response" + response.toString());
        isLoading = false;
        setState(() {
          isLoading;
        });

        print("response shubh" + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              ProfileBloc.mMap=response.data['result'];
              tagList.clear();
              dataExist.clear();
              sendRequestList.clear();
              peopleYouMayKnowList.clear();
              acceptedCount = 0;
              sentRequestCount = 0;
              requestedCount = 0;
              PeopleYouMayKnowCount = 0;
              receivedRequestCount = 0;

              acceptedCount = int.parse(
                  response.data['result']['acceptedCount'].toString() == "null"
                      ? "0"
                      : response.data['result']['acceptedCount'].toString());
              sentRequestCount = int.parse(
                  response.data['result']['sentRequestCount'].toString() ==
                          "null"
                      ? "0"
                      : response.data['result']['sentRequestCount'].toString());

              pendingRequestCount = int.parse(response.data['result']
                              ['pendingRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['pendingRequestCount'].toString());

              receivedRequestCount = int.parse(response.data['result']
                              ['receivedRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['receivedRequestCount'].toString());

              requestedCount = int.parse(
                  response.data['result']['requestedCount'].toString() == "null"
                      ? "0"
                      : response.data['result']['requestedCount'].toString());

              PeopleYouMayKnowCount = int.parse(
                  response.data['result']['PeopleYouMayKnowCount'].toString() ==
                          "null"
                      ? "0"
                      : response.data['result']['PeopleYouMayKnowCount']
                          .toString());

              referralCount = int.parse(response.data['result']
                              ['referralRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['referralRequestCount'].toString());
              print(
                  'Apurva referralCount:: $referralCount, response.data[result][referralRequestCount]:: ${response.data['result']['referralRequestCount']}');
              print("" +
                  acceptedCount.toString() +
                  " " +
                  sentRequestCount.toString() +
                  " " +
                  PeopleYouMayKnowCount.toString() +
                  " " +
                  requestedCount.toString());

              tagList = ParseJson.parseRequestedTagList(
                  response.data['result']['Requested']);

              sendRequestList = ParseJson.parseRequestedTagList(
                  response.data['result']['sentRequest']);

              pendinForParentDataList = ParseJson.parseRequestedTagList(
                  response.data['result']['Pending']);

              receivedRequestList = ParseJson.parseRequestedTagList(
                  response.data['result']['receivedRequest']);

              refferList =
                  ParseJson.parseRefferal(response.data['result']['referral']);
              print(
                  'Apurva apiCallingForRefresh refferList.length:: ${refferList.length}, data:::: ${response.data['result']['referral']}');


              List<PeopleYouMayKnow> peopleYouMayKnowListLocal = ParseJson.parsePeopleMayYouKnow(response.data['result']['PeopleYouMayKnow']);
              for (var PeopleYouMayKnow in peopleYouMayKnowListLocal) {
                if (!dataExist.containsKey(PeopleYouMayKnow.userId)) {
                  var s = dataExist.putIfAbsent(
                      PeopleYouMayKnow.userId, () => PeopleYouMayKnow.userId);
                  print("shubhsss======" +
                      PeopleYouMayKnow.firstName +
                      "    " +
                      s.toString());
                } else {
                  print("shubhsss delete ====" + PeopleYouMayKnow.firstName);
                  peopleYouMayKnowListLocal.remove(PeopleYouMayKnow);
                }
              }

              peopleYouMayKnowList.addAll(peopleYouMayKnowListLocal);

              if (tagList != null) {

                setState(() {
                  tagList;
                  refferList;
                  receivedRequestList;
                  pendinForParentDataList;
                  peopleYouMayKnowList;
                  sendRequestList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallingForTag() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        Response response = await  ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY +
                userIdPref +
                "&roleId=" +
                roleId+"&skip=0",
            "get");

        print("map+++" +
            Constant.ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY +
            userIdPref +
            "&roleId=" +
            roleId+"&skip=0");
        print("response" + response.toString());
        isLoading = false;
        setState(() {
          isLoading;
        });

        print("response shubh" + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              ProfileBloc.mMap=response.data['result'];
              tagList.clear();
              dataExist.clear();
              sendRequestList.clear();
              peopleYouMayKnowList.clear();
              acceptedCount = 0;
              sentRequestCount = 0;
              requestedCount = 0;
              PeopleYouMayKnowCount = 0;
              receivedRequestCount = 0;

              acceptedCount = int.parse(
                  response.data['result']['acceptedCount'].toString() == "null"
                      ? "0"
                      : response.data['result']['acceptedCount'].toString());
              sentRequestCount = int.parse(
                  response.data['result']['sentRequestCount'].toString() ==
                          "null"
                      ? "0"
                      : response.data['result']['sentRequestCount'].toString());

              pendingRequestCount = int.parse(response.data['result']
                              ['pendingRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['pendingRequestCount'].toString());

              receivedRequestCount = int.parse(response.data['result']
                              ['receivedRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['receivedRequestCount'].toString());

              requestedCount = int.parse(
                  response.data['result']['requestedCount'].toString() == "null"
                      ? "0"
                      : response.data['result']['requestedCount'].toString());

              PeopleYouMayKnowCount = int.parse(
                  response.data['result']['PeopleYouMayKnowCount'].toString() ==
                          "null"
                      ? "0"
                      : response.data['result']['PeopleYouMayKnowCount']
                          .toString());
              referralCount = int.parse(response.data['result']
                              ['referralRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['referralRequestCount'].toString());
              print(
                  'Apurva referralCount:: $referralCount, response.data[result][referralRequestCount]:: ${response.data['result']['referralRequestCount']}');
              print("" +
                  acceptedCount.toString() +
                  " " +
                  sentRequestCount.toString() +
                  " " +
                  PeopleYouMayKnowCount.toString() +
                  " " +
                  requestedCount.toString());

              tagList = ParseJson.parseRequestedTagList(
                  response.data['result']['Requested']);

              sendRequestList = ParseJson.parseRequestedTagList(
                  response.data['result']['sentRequest']);

              pendinForParentDataList = ParseJson.parseRequestedTagList(
                  response.data['result']['Pending']);

              receivedRequestList = ParseJson.parseRequestedTagList(
                  response.data['result']['receivedRequest']);

              refferList =
                  ParseJson.parseRefferal(response.data['result']['referral']);

              print(
                  'Apurva apiCallingForTag refferList.length:: ${refferList.length}, data:: ${response.data['result']['referral']}');

              List<PeopleYouMayKnow> peopleYouMayKnowListLocal =
                  ParseJson.parsePeopleMayYouKnow(
                      response.data['result']['PeopleYouMayKnow']);
              for (var PeopleYouMayKnow in peopleYouMayKnowListLocal) {
                if (!dataExist.containsKey(PeopleYouMayKnow.userId)) {
                  var s = dataExist.putIfAbsent(
                      PeopleYouMayKnow.userId, () => PeopleYouMayKnow.userId);
                  print("shubhsss======" +
                      PeopleYouMayKnow.firstName +
                      "    " +
                      s.toString());
                } else {
                  print("shubhsss delete ====" + PeopleYouMayKnow.firstName);
                  peopleYouMayKnowListLocal.remove(PeopleYouMayKnow);
                }
              }

              peopleYouMayKnowList.addAll(peopleYouMayKnowListLocal);

              if (tagList != null) {

                setState(() {
                  tagList;
                  refferList;
                  receivedRequestList;
                  pendinForParentDataList;
                  peopleYouMayKnowList;
                  sendRequestList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallingForTagOnListenEvent() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });

        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");

        print("map+++" +
            Constant.ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY +
            userIdPref +
            "&roleId=" +
            roleId);
        print("response" + response.toString());
        isLoading = false;
        setState(() {
          isLoading;
        });

        print("response shubh" + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              ProfileBloc.mMap=response.data['result'];
              tagList.clear();
              dataExist.clear();
              sendRequestList.clear();
              peopleYouMayKnowList.clear();
              acceptedCount = 0;
              sentRequestCount = 0;
              requestedCount = 0;
              PeopleYouMayKnowCount = 0;
              receivedRequestCount = 0;

              acceptedCount = int.parse(
                  response.data['result']['acceptedCount'].toString() == "null"
                      ? "0"
                      : response.data['result']['acceptedCount'].toString());
              sentRequestCount = int.parse(
                  response.data['result']['sentRequestCount'].toString() ==
                          "null"
                      ? "0"
                      : response.data['result']['sentRequestCount'].toString());

              pendingRequestCount = int.parse(response.data['result']
                              ['pendingRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['pendingRequestCount'].toString());

              receivedRequestCount = int.parse(response.data['result']
                              ['receivedRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['receivedRequestCount'].toString());

              requestedCount = int.parse(
                  response.data['result']['requestedCount'].toString() == "null"
                      ? "0"
                      : response.data['result']['requestedCount'].toString());

              PeopleYouMayKnowCount = int.parse(
                  response.data['result']['PeopleYouMayKnowCount'].toString() ==
                          "null"
                      ? "0"
                      : response.data['result']['PeopleYouMayKnowCount']
                          .toString());
              referralCount = int.parse(response.data['result']
                              ['referralRequestCount']
                          .toString() ==
                      "null"
                  ? "0"
                  : response.data['result']['referralRequestCount'].toString());
              print(
                  'Apurva referralCount:: $referralCount, response.data[result][referralRequestCount]:: ${response.data['result']['referralRequestCount']}');
              print("" +
                  acceptedCount.toString() +
                  " " +
                  sentRequestCount.toString() +
                  " " +
                  PeopleYouMayKnowCount.toString() +
                  " " +
                  requestedCount.toString());

              tagList = ParseJson.parseRequestedTagList(
                  response.data['result']['Requested']);

              sendRequestList = ParseJson.parseRequestedTagList(
                  response.data['result']['sentRequest']);

              pendinForParentDataList = ParseJson.parseRequestedTagList(
                  response.data['result']['Pending']);

              receivedRequestList = ParseJson.parseRequestedTagList(
                  response.data['result']['receivedRequest']);

              refferList =
                  ParseJson.parseRefferal(response.data['result']['referral']);

              print(
                  'Apurva apiCallingForTag refferList.length:: ${refferList.length}, data:: ${response.data['result']['referral']}');


              List<PeopleYouMayKnow> peopleYouMayKnowListLocal =
                  ParseJson.parsePeopleMayYouKnow(
                      response.data['result']['PeopleYouMayKnow']);
              for (var PeopleYouMayKnow in peopleYouMayKnowListLocal) {
                if (!dataExist.containsKey(PeopleYouMayKnow.userId)) {
                  var s = dataExist.putIfAbsent(
                      PeopleYouMayKnow.userId, () => PeopleYouMayKnow.userId);
                  print("shubhsss======" +
                      PeopleYouMayKnow.firstName +
                      "    " +
                      s.toString());
                } else {
                  print("shubhsss delete ====" + PeopleYouMayKnow.firstName);
                  peopleYouMayKnowListLocal.remove(PeopleYouMayKnow);
                }
              }

              peopleYouMayKnowList.addAll(peopleYouMayKnowListLocal);

              if (tagList != null) {

                setState(() {
                  tagList;
                  refferList;
                  receivedRequestList;
                  pendinForParentDataList;
                  peopleYouMayKnowList;
                  sendRequestList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  //--------------------------  api ------------------
  Future apiCallForConnect(

      String partnerId, bool isActive, PeopleYouMayKnow, partnerRole) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        bool ageStatus = false;
        if (prefs.getString(UserPreference.DOB) != null &&
            prefs.getString(UserPreference.DOB) != 'null') {
          ageStatus = Util.currentAge(
                   DateTime.fromMillisecondsSinceEpoch(
                      int.tryParse(prefs.getString(UserPreference.DOB))),
                  13) <
              13;
        }
        Map map = {
          "userId": prefs.getString(UserPreference.USER_ID),
          "partnerId": int.parse(partnerId),
          "dateTime":  DateTime.now().millisecondsSinceEpoch,
          "status": ageStatus ? "Pending" : "Requested",
          "isActive": isActive,
          "userRoleId": int.parse(roleId),
          "partnerRoleId": partnerRole
        };
        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {


            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg);

              String connectId =
                  response.data["result"]["connectId"].toString();
              //this.connectId = connectId;

              peopleYouMayKnowList.remove(PeopleYouMayKnow);
              setState(() {
                peopleYouMayKnowList;
              });

              apiCallingForRefresh();
             apiCallingForTag();
              //apiCallingForTag2();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      e.toString();
    }
  }

  Future apiCallingForDeleteStudentConnection(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId),
        "userId": int.parse(userIdPref)
      };
      Response response = await  ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_DELETE_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {

            apiCallingForRefresh();
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      e.toString();
    }
  }

  Future apiCallingForUnfriendTagList(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId)
      };
      Response response = await  ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {

            apiCallingForRefresh();
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      e.toString();
    }
  }

  Future apiCallingForUnfriendSendList(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId)
      };
      Response response = await  ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {

            apiCallingForRefresh();
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      e.toString();
    }
  }

  Future apiCallingForAccept(connectionId, index, type, userIsActive,userIdData) async {
    print("datatat");
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "dateTime":  DateTime.now().millisecondsSinceEpoch,
        "status": type,
        "isActive": userIsActive,
        "roleId": int.parse(roleId),
        "userId": int.parse(userIdData),
      };

      print("Map+++++" + map.toString());

      Response response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("connect:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            apiCallingForRefresh();
          }else{
            ToastWrap.showToast(msg, context);
            apiCallingForTag();
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    dob = prefs.getString(UserPreference.DOB);
    if (dob != null && dob != 'null') {
      int millis = int.tryParse(dob);
      DateTime dobDate =  DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(dobDate, 13);
    }
    setState(() {
      diffrenceInDob;
    });
    print("dobsss++" + diffrenceInDob.toString());

    ProfileBloc.connectionController.stream.listen((map) {
      try {
        if (map != null)
          {
            tagList.clear();
            dataExist.clear();
            sendRequestList.clear();
            peopleYouMayKnowList.clear();
            acceptedCount = 0;
            sentRequestCount = 0;
            requestedCount = 0;
            PeopleYouMayKnowCount = 0;
            receivedRequestCount = 0;

            acceptedCount = int.parse(
                map['acceptedCount'].toString() == "null"
                    ? "0"
                    : map['acceptedCount'].toString());
            sentRequestCount = int.parse(
                map['sentRequestCount'].toString() ==
                    "null"
                    ? "0"
                    : map['sentRequestCount'].toString());

            pendingRequestCount = int.parse(map
            ['pendingRequestCount']
                .toString() ==
                "null"
                ? "0"
                : map['pendingRequestCount'].toString());

            receivedRequestCount = int.parse(map
            ['receivedRequestCount']
                .toString() ==
                "null"
                ? "0"
                : map['receivedRequestCount'].toString());

            requestedCount = int.parse(
                map['requestedCount'].toString() == "null"
                    ? "0"
                    : map['requestedCount'].toString());

            PeopleYouMayKnowCount = int.parse(
                map['PeopleYouMayKnowCount'].toString() ==
                    "null"
                    ? "0"
                    : map['PeopleYouMayKnowCount']
                    .toString());
            referralCount = int.parse(map
            ['referralRequestCount']
                .toString() ==
                "null"
                ? "0"
                : map['referralRequestCount'].toString());
            print(
                'Apurva referralCount:: $referralCount, response.data[result][referralRequestCount]:: ${map['referralRequestCount']}');
            print("" +
                acceptedCount.toString() +
                " " +
                sentRequestCount.toString() +
                " " +
                PeopleYouMayKnowCount.toString() +
                " " +
                requestedCount.toString());

            tagList = ParseJson.parseRequestedTagList(
                map['Requested']);

            sendRequestList = ParseJson.parseRequestedTagList(
                map['sentRequest']);

            pendinForParentDataList = ParseJson.parseRequestedTagList(
                map['Pending']);

            receivedRequestList = ParseJson.parseRequestedTagList(
                map['receivedRequest']);

            refferList =
                ParseJson.parseRefferal(map['referral']);

            print(
                'Apurva apiCallingForTag refferList.length:: ${refferList.length}, data:: ${map['referral']}');


            List<PeopleYouMayKnow> peopleYouMayKnowListLocal =
            ParseJson.parsePeopleMayYouKnow(
                map['PeopleYouMayKnow']);
            for (var PeopleYouMayKnow in peopleYouMayKnowListLocal) {
              if (!dataExist.containsKey(PeopleYouMayKnow.userId)) {
                var s = dataExist.putIfAbsent(
                    PeopleYouMayKnow.userId, () => PeopleYouMayKnow.userId);
                print("shubhsss======" +
                    PeopleYouMayKnow.firstName +
                    "    " +
                    s.toString());
              } else {
                print("shubhsss delete ====" + PeopleYouMayKnow.firstName);
                peopleYouMayKnowListLocal.remove(PeopleYouMayKnow);
              }
            }

            peopleYouMayKnowList.addAll(peopleYouMayKnowListLocal);

            if (tagList != null) {

              setState(() {
                tagList;
                refferList;
                receivedRequestList;
                pendinForParentDataList;
                peopleYouMayKnowList;
                sendRequestList;
              });
            }
          }

      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
        print("stream+++" + e.toString());
      }
      setState(() {});
    });
    bloc.fetchConnection(userIdPref, context, prefs, false);
    bloc.fetchConnected(userIdPref, context, prefs, true,"0");
    //anaylytics.setCurrentSreen(ScreenNameConstant.connection_request_activity);
   // apiCallingForTag();
  }

  @override
  void initState() {

    _streamSubscription =
        SplashScreenState.syncDoneController.stream.listen((value) {
          print("value//////"+value.toString());
      if (Constant.CONNECTIONS_TYPE == value||Constant.PROFILE_TYPE == value) {
        apiCallingForTagOnListenEvent();}

    });

    _streamSubscription = SplashScreenState.syncDoneController.stream.listen((value) {
      print("value//////"+value.toString());
      if (Constant.CONNECTIONS_PROFILE == value) {
        getSharedPreferences();
      }
    });

    _streamSubscription =
        UserProfileDashBoardState.syncDoneController.stream.listen((value) {
          print("value11111//////"+value.toString());
      apiCallingForTag();
    });


    _streamSubscription = PatnerProfileWidgetForOtherUserState
        .syncDoneController.stream
        .listen((value) {
      apiCallingForTag();
    });

    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    void infoDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 220.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 170.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Center(
                                                child:  Column(
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        5.0,
                                                        0.0,
                                                        5.0,
                                                        Image.asset(
                                                          'assets/newDesignIcon/info.png',
                                                          height: 25.0,
                                                          width: 25.0,
                                                        )),


                                                     Container(
                                                        //color: Colors.orange,
                                                        padding:
                                                            EdgeInsets.only(
                                                                top: 10.0),
                                                        child: RichText(
                                                          maxLines: 5,
                                                          textAlign:
                                                              TextAlign.center,
                                                          text: TextSpan(
                                                            text:
                                                                "Your child is under the age of 13, so before they can send or receive a connection request you will need to approve it.",
                                                            style:  TextStyle(
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                          ),
                                                        ))
                                                  ],
                                                ),
                                              ),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Close",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    Container getListviewReferl(requestedTagModel, index, bool isSentRequest) {
      return  Container(
          color: Colors.transparent,
          padding:  EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
          child:  Card(
              color: Colors.transparent,
              elevation: 0.0,
              child:  Column(
                children: <Widget>[
                   InkWell(
                    child:  Row(
                      children: <Widget>[
                         Expanded(
                          child:  InkWell(
                            child:  Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child:  Image.asset(
                                    'assets/profile/user_on_user.png'),
                              ),
                            ),
                            onTap: () {},
                          ),
                          flex: 0,
                        ),
                         Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                               Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                   Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: TextViewWrap.textView(
                                            requestedTagModel.referredTo,
                                            TextAlign.left,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 1,
                                      ),
                                    ],
                                  ),
                                ],
                              )),
                          flex: 1,
                        ),
                      ],
                    ),
                    onTap: () {},
                  ),
                  index == 0
                      ?  Padding(
                          padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
                          child: Divider(
                            color: Colors.transparent,
                            height: 0.0,
                          ))
                      :  Container(
                          height: 0.0,
                        ),
                ],
              )));
    }

    Container getListview(requestedTagModel, index, bool isSentRequest) {
      return  Container(
          color: Colors.transparent,
          padding:  EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
          child:  Card(
              color: Colors.transparent,
              elevation: 0.0,
              child:  Column(
                children: <Widget>[
                   InkWell(
                    child:  Row(
                      children: <Widget>[
                         Expanded(
                          child:  InkWell(
                            child:  Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: requestedTagModel
                                                .patner.profilePicture ==
                                            "" ||
                                        requestedTagModel
                                                .patner.profilePicture ==
                                            "null"
                                    ?  Image.asset(
                                        requestedTagModel.patner.roleId == "4"
                                            ? "assets/profile/partner_img.png"
                                            : 'assets/profile/user_on_user.png',
                                      )
                                    : FadeInImage(
                                        fit: BoxFit.cover,
                                        placeholder: AssetImage(
                                          requestedTagModel.patner.roleId == "4"
                                              ? "assets/profile/partner_img.png"
                                              : 'assets/profile/user_on_user.png',
                                        ),
                                        image: NetworkImage(
                                            Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getSmallImage(
                                                    requestedTagModel.patner
                                                        .profilePicture)),
                                      ),
                              ),
                            ),
                            onTap: () {
                              if (requestedTagModel.patner.userId ==
                                  userIdPref) {
                              } else {
                                Util.onTapImageTile(
                                    tapedUserRole:
                                        requestedTagModel.partnerRoleId,
                                    partnerUserId:
                                        requestedTagModel.patner.userId,
                                    context: context);
                              }
                            },
                          ),
                          flex: 0,
                        ),
                         Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              10.0,
                              0.0,
                              0.0,
                               Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                   Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: TextViewWrap.textView(
                                            requestedTagModel.patner.lastName ==
                                                        null ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        "null" ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        ""
                                                ? requestedTagModel
                                                    .patner.firstName
                                                : requestedTagModel
                                                        .patner.firstName +
                                                    " " +
                                                    requestedTagModel
                                                        .patner.lastName,
                                            TextAlign.left,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        flex: 0,
                                        child:
                                        requestedTagModel.patner.roleId == "1" ?
                                        Util.getStudentBadge12(requestedTagModel.patner.badge,requestedTagModel.patner.badgeImage):Container(),
                                      ),
                                    ],
                                  ),
                                   Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Flexible(
                                          child: TextViewWrap.textView(
                                        requestedTagModel.patner.tagline ==
                                                    null ||
                                                requestedTagModel
                                                        .patner.tagline ==
                                                    "null" ||
                                                requestedTagModel
                                                        .patner.tagline ==
                                                    ""
                                            ? ""
                                            : requestedTagModel.patner.tagline,
                                        TextAlign.start,
                                         ColorValues.GREY_TEXT_COLOR,
                                        12.0,
                                        FontWeight.normal,
                                      )),
                                    ],
                                  ),
                                ],
                              )),
                          flex: 1,
                        ),

                         Expanded(
                          child: Row(
                            children: <Widget>[
                              isSentRequest
                                  ?  Text("")
                                  :  InkWell(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          child:  Container(
                                              height: 45.0,
                                              width: 45.0,
                                              child: Image.asset(
                                                'assets/newDesignIcon/connections/tick_blue.png',
                                              ))),
                                      onTap: () {
                                        apiCallingForAccept(
                                            requestedTagModel.connectId,
                                            index,
                                            "Accepted",
                                            requestedTagModel.userIsActive, requestedTagModel.userId);
                                      },
                                    ),
                               InkWell(
                                child:  Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        10.0, 0.0, 0.0, 0.0),
                                    child:  Container(
                                        height: 35.0,
                                        width: 35.0,
                                        child: Image.asset(
                                          'assets/newDesignIcon/connections/cancel.png',
                                        ))),
                                onTap: () {
                                  String name = requestedTagModel
                                                  .patner.lastName ==
                                              null ||
                                          requestedTagModel.patner.lastName ==
                                              "null" ||
                                          requestedTagModel.patner.lastName ==
                                              ""
                                      ? requestedTagModel.patner.firstName
                                      : requestedTagModel.patner.firstName +
                                          " " +
                                          requestedTagModel.patner.lastName;
                                  educationRemoveConfromationDialogRequest(
                                      requestedTagModel.connectId,
                                      name,
                                      index,
                                      0);
                                },
                              )
                            ],
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                    onTap: () {
                      if (requestedTagModel.patner.userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: requestedTagModel.patner.roleId,
                            partnerUserId: requestedTagModel.patner.userId,
                            context: context);
                      }
                    },
                  ),
                  index == 0
                      ?  Padding(
                          padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
                          child: Divider(
                            color: Colors.transparent,
                            height: 0.0,
                          ))
                      :  Container(
                          height: 0.0,
                        ),
                ],
              )));
    }

    Container getListviewForSendList(
        requestedTagModel, index, bool isSentRequest, status) {
      return  Container(
          color: Colors.transparent,
          padding:  EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
          child:  Card(
              color: Colors.transparent,
              elevation: 0.0,
              child:  Column(
                children: <Widget>[
                   InkWell(
                    child:  Row(
                      children: <Widget>[
                         Expanded(
                          child:  InkWell(
                            child:  Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: requestedTagModel
                                                .patner.profilePicture ==
                                            "" ||
                                        requestedTagModel
                                                .patner.profilePicture ==
                                            "null"
                                    ?  Image.asset(
                                        requestedTagModel.patner.roleId == "4"
                                            ? "assets/profile/partner_img.png"
                                            : 'assets/profile/user_on_user.png')
                                    : FadeInImage(
                                        fit: BoxFit.cover,
                                        placeholder: AssetImage(
                                          requestedTagModel.patner.roleId == "4"
                                              ? "assets/profile/partner_img.png"
                                              : 'assets/profile/user_on_user.png',
                                        ),
                                        image: NetworkImage(
                                            Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getSmallImage(
                                                    requestedTagModel.patner
                                                        .profilePicture)),
                                      ),
                              ),
                            ),
                            onTap: () {
                              if (requestedTagModel.patner.userId ==
                                  userIdPref) {
                              } else {
                                Util.onTapImageTile(
                                    tapedUserRole:
                                        requestedTagModel.patner.roleId,
                                    partnerUserId:
                                        requestedTagModel.patner.userId,
                                    context: context);
                              }
                            },
                          ),
                          flex: 0,
                        ),
                         Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                               Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                   Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: TextViewWrap.textView(
                                            requestedTagModel.patner.lastName ==
                                                        null ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        "null" ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        ""
                                                ? requestedTagModel
                                                    .patner.firstName
                                                : requestedTagModel
                                                        .patner.firstName +
                                                    " " +
                                                    requestedTagModel
                                                        .patner.lastName,
                                            TextAlign.left,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        flex: 0,
                                        child: requestedTagModel.patner.roleId == "1" ?
                                        Util.getStudentBadge12(requestedTagModel.patner.badge,requestedTagModel.patner.badgeImage):Container(),
                                      ),
                                    ],
                                  ),
                                  requestedTagModel.patner.tagline == null ||
                                          requestedTagModel.patner.tagline ==
                                              "null" ||
                                          requestedTagModel.patner.tagline == ""
                                      ?  Container(
                                          height: 0.0,
                                        )
                                      :  Row(
                                          children: <Widget>[
                                            Flexible(
                                                child: TextViewWrap.textViewMultiLine(
                                                    requestedTagModel.patner
                                                                    .tagline ==
                                                                null ||
                                                            requestedTagModel
                                                                    .patner
                                                                    .tagline ==
                                                                "null" ||
                                                            requestedTagModel
                                                                    .patner
                                                                    .tagline ==
                                                                ""
                                                        ? ""
                                                        : requestedTagModel
                                                            .patner.tagline,
                                                    TextAlign.start,
                                                     ColorValues.GREY_TEXT_COLOR,
                                                    12.0,
                                                    FontWeight.normal,
                                                    2)),
                                          ],
                                        ),
                                ],
                              )),
                          flex: 1,
                        ),
                         Expanded(
                          child: Row(
                            children: <Widget>[
                              isSentRequest
                                  ?  Text("")
                                  :  InkWell(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          child:  Container(
                                              height: 45.0,
                                              width: 45.0,
                                              child: Image.asset(
                                                'assets/newDesignIcon/connections/tick_blue.png',
                                              ))),
                                      onTap: () {
                                        if (status != "") {
                                          apiCallingForAccept(
                                              requestedTagModel.connectId,
                                              index,
                                              "Requested",
                                              requestedTagModel.userIsActive, requestedTagModel.userId);
                                        } else {
                                          apiCallingForAccept(
                                              requestedTagModel.connectId,
                                              index,
                                              "Accepted",
                                              requestedTagModel.userIsActive, requestedTagModel.userId);
                                        }
                                      },
                                    ),
                               InkWell(
                                child:  Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        10.0, 0.0, 0.0, 0.0),
                                    child:  Container(
                                        height: 35.0,
                                        width: 35.0,
                                        child: Image.asset(
                                          'assets/newDesignIcon/connections/cancel.png',
                                        ))),
                                onTap: () {
                                  String name = requestedTagModel
                                                  .patner.lastName ==
                                              null ||
                                          requestedTagModel.patner.lastName ==
                                              "null" ||
                                          requestedTagModel.patner.lastName ==
                                              ""
                                      ? requestedTagModel.patner.firstName
                                      : requestedTagModel.patner.firstName +
                                          " " +
                                          requestedTagModel.patner.lastName;

                                  educationRemoveConfromationDialog(
                                      requestedTagModel.connectId,
                                      name,
                                      index,
                                      1);
                                },
                              )
                            ],
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                    onTap: () {
                      if (requestedTagModel.patner.userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: requestedTagModel.patner.roleId,
                            partnerUserId: requestedTagModel.patner.userId,
                            context: context);
                      }
                    },
                  ),
                  index == 0
                      ?  Padding(
                          padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
                          child: Divider(
                            color: Colors.transparent,
                            height: 0.0,
                          ))
                      :  Container(
                          height: 0.0,
                        ),
                ],
              )));
    }

    Container getListviewForPending(
        requestedTagModel, index, bool isSentRequest, status) {
      return  Container(
          color: Colors.transparent,
          padding:  EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
          child:  Card(
              color: Colors.transparent,
              elevation: 0.0,
              child:  Column(
                children: <Widget>[
                   InkWell(
                    child:  Row(
                      children: <Widget>[
                         Expanded(
                          child:  InkWell(
                            child:  Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: requestedTagModel
                                                .patner.profilePicture ==
                                            "" ||
                                        requestedTagModel
                                                .patner.profilePicture ==
                                            "null"
                                    ?  Image.asset(
                                        requestedTagModel.partnerRoleId == "4"
                                            ? "assets/profile/partner_img.png"
                                            : 'assets/profile/user_on_user.png')
                                    : FadeInImage(
                                        fit: BoxFit.cover,
                                        placeholder: AssetImage(
                                          requestedTagModel.partnerRoleId == "4"
                                              ? "assets/profile/partner_img.png"
                                              : 'assets/profile/user_on_user.png',
                                        ),
                                        image: NetworkImage(
                                            Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getSmallImage(
                                                    requestedTagModel.patner
                                                        .profilePicture)),
                                      ),
                              ),
                            ),
                            onTap: () {
                              if (requestedTagModel.partnerId == userIdPref) {
                              } else {
                                print("partner roleId+++++" +
                                    requestedTagModel.partnerRoleId);
                                Util.onTapImageTile(
                                    tapedUserRole:
                                        requestedTagModel.partnerRoleId,
                                    partnerUserId: requestedTagModel.partnerId,
                                    context: context);
                              }
                            },
                          ),
                          flex: 0,
                        ),
                         Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                               Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                   Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: TextViewWrap.textView(
                                            requestedTagModel.patner.lastName ==
                                                        null ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        "null" ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        ""
                                                ? requestedTagModel
                                                    .patner.firstName
                                                : requestedTagModel
                                                        .patner.firstName +
                                                    " " +
                                                    requestedTagModel
                                                        .patner.lastName,
                                            TextAlign.left,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 0,
                                      ),
                                       Expanded(
                                        child:
                                        requestedTagModel.patner.roleId == "1" ?
                                        Util.getStudentBadge12(requestedTagModel.patner.badge,requestedTagModel.patner.badgeImage):Container(),
                                        flex: 0,
                                      )
                                    ],
                                  ),


                                  roleId == "2"
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          0.0,
                                          RichText(
                                            maxLines: 1,
                                            textAlign: TextAlign.start,
                                            text: TextSpan(
                                              text: "For ",
                                              style:  TextStyle(
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontSize: 12.0,
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              ),
                                              children: <TextSpan>[
                                                TextSpan(
                                                    text: requestedTagModel
                                                                    .userData
                                                                    .lastName ==
                                                                null ||
                                                            requestedTagModel
                                                                    .userData
                                                                    .lastName ==
                                                                "null" ||
                                                            requestedTagModel
                                                                    .userData
                                                                    .lastName ==
                                                                ""
                                                        ? requestedTagModel
                                                            .userData.firstName
                                                        : requestedTagModel
                                                                .userData
                                                                .firstName +
                                                            " " +
                                                            requestedTagModel
                                                                .userData
                                                                .lastName,
                                                    style: TextStyle(
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMBOLD,
                                                        fontSize: 12.0,
                                                        color:  ColorValues.GREY_TEXT_COLOR))
                                              ],
                                            ),
                                          ))
                                      : PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          0.0,
                                          TextViewWrap.textViewMultiLine(
                                              requestedTagModel.status ==
                                                      "Pending"
                                                  ? "Your parent approval pending"
                                                  : "Pending" /*requestedTagModel
                                                                  .patner.lastName ==
                                                              null ||
                                                          requestedTagModel.patner
                                                                  .lastName ==
                                                              "null" ||
                                                          requestedTagModel.patner
                                                                  .lastName ==
                                                              ""
                                                      ? "Pending From " +
                                                          requestedTagModel
                                                              .patner.firstName
                                                      : "Pending From " +
                                                          requestedTagModel
                                                              .patner
                                                              .firstName +
                                                          " " +
                                                          requestedTagModel
                                                              .patner.lastName*/
                                              ,
                                              TextAlign.start,
                                               ColorValues.GREY_TEXT_COLOR,
                                              12.0,
                                              FontWeight.normal,
                                              1))
                                ],
                              )),
                          flex: 1,
                        ),
                         Expanded(
                          child: Row(
                            children: <Widget>[
                              isSentRequest
                                  ?  Text("")
                                  :  InkWell(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          child:  Container(
                                              height: 45.0,
                                              width: 45.0,
                                              child: Image.asset(
                                                'assets/newDesignIcon/connections/tick_blue.png',
                                              ))),
                                      onTap: () {
                                        if (status != "") {
                                          apiCallingForAccept(
                                              requestedTagModel.connectId,
                                              index,
                                              "Requested",
                                              requestedTagModel.userIsActive, requestedTagModel.userId);
                                        } else {
                                          apiCallingForAccept(
                                              requestedTagModel.connectId,
                                              index,
                                              "Accepted",
                                              requestedTagModel.userIsActive, requestedTagModel.userId);
                                        }
                                      },
                                    ),
                               InkWell(
                                child:  Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        10.0, 0.0, 0.0, 0.0),
                                    child:  Container(
                                        height: 35.0,
                                        width: 35.0,
                                        child: Image.asset(
                                          'assets/newDesignIcon/connections/cancel.png',
                                        ))),
                                onTap: () {
                                  String name = requestedTagModel
                                                  .patner.lastName ==
                                              null ||
                                          requestedTagModel.patner.lastName ==
                                              "null" ||
                                          requestedTagModel.patner.lastName ==
                                              ""
                                      ? requestedTagModel.patner.firstName
                                      : requestedTagModel.patner.firstName +
                                          " " +
                                          requestedTagModel.patner.lastName;

                                  educationRemoveConfromationDialog(
                                      requestedTagModel.connectId,
                                      name,
                                      index,
                                      4);
                                },
                              )
                            ],
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                    onTap: () {
                      if (requestedTagModel.patner.userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: requestedTagModel.patner.roleId,
                            partnerUserId: requestedTagModel.patner.userId,
                            context: context);
                      }
                    },
                  ),
                ],
              )));
    }

    Container getListviewForRecieveList(
        requestedTagModel, index, bool isSentRequest, status) {
      return  Container(
          color: Colors.transparent,
          padding:  EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
          child:  Card(
              color: Colors.transparent,
              elevation: 0.0,
              child:  Column(
                children: <Widget>[
                   InkWell(
                    child:  Row(
                      children: <Widget>[
                         Expanded(
                          child:  InkWell(
                            child:  Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: requestedTagModel
                                                .userData.profilePicture ==
                                            "" ||
                                        requestedTagModel
                                                .userData.profilePicture ==
                                            "null"
                                    ?  Image.asset(
                                        requestedTagModel.userRoleId == "4"
                                            ? "assets/profile/partner_img.png"
                                            : 'assets/profile/user_on_user.png')
                                    : FadeInImage(
                                        fit: BoxFit.cover,
                                        placeholder: AssetImage(
                                          requestedTagModel.userRoleId == "4"
                                              ? "assets/profile/partner_img.png"
                                              : 'assets/profile/user_on_user.png',
                                        ),
                                        image: NetworkImage(
                                            Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getSmallImage(
                                                    requestedTagModel.userData
                                                        .profilePicture)),
                                      ),
                              ),
                            ),
                            onTap: () {
                              if (requestedTagModel.userId == userIdPref) {
                              } else {
                                Util.onTapImageTile(
                                    tapedUserRole: requestedTagModel.userRoleId,
                                    partnerUserId: requestedTagModel.userId,
                                    context: context);
                              }
                            },
                          ),
                          flex: 0,
                        ),
                         Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                               Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                   Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: TextViewWrap.textView(
                                            requestedTagModel.userData
                                                            .lastName ==
                                                        null ||
                                                    requestedTagModel.userData
                                                            .lastName ==
                                                        "null" ||
                                                    requestedTagModel.userData
                                                            .lastName ==
                                                        ""
                                                ? requestedTagModel
                                                    .userData.firstName
                                                : requestedTagModel
                                                        .userData.firstName +
                                                    " " +
                                                    requestedTagModel
                                                        .userData.lastName,
                                            TextAlign.left,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 0,
                                      ),
                                       Expanded(
                                        child:
                                        requestedTagModel.patner.roleId == "1" ?
                                        Util.getStudentBadge12(requestedTagModel.patner.badge,requestedTagModel.patner.badgeImage):Container(),
                                        flex: 0,
                                      )
                                    ],
                                  ),


                                  roleId == "2"
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          0.0,
                                          RichText(
                                            maxLines: 1,
                                            textAlign: TextAlign.start,
                                            text: TextSpan(
                                              text: "For ",
                                              style:  TextStyle(
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontSize: 12.0,
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                fontWeight: FontWeight.normal,
                                              ),
                                              children: <TextSpan>[
                                                TextSpan(
                                                    text: requestedTagModel.patner
                                                                    .lastName ==
                                                                null ||
                                                            requestedTagModel.patner
                                                                    .lastName ==
                                                                "null" ||
                                                            requestedTagModel
                                                                    .patner
                                                                    .lastName ==
                                                                ""
                                                        ? requestedTagModel
                                                            .patner.firstName
                                                        : requestedTagModel
                                                                .patner
                                                                .firstName +
                                                            " " +
                                                            requestedTagModel
                                                                .patner
                                                                .lastName,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMBOLD,
                                                        fontSize: 12.0,
                                                        color:  ColorValues.GREY_TEXT_COLOR))
                                              ],
                                            ),
                                          ))
                                      : PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          0.0,
                                          TextViewWrap.textViewMultiLine(

                                              "Your parent approval pending"

                                              ,
                                              TextAlign.start,
                                               ColorValues.GREY_TEXT_COLOR,
                                              12.0,
                                              FontWeight.normal,
                                              1))
                                ],
                              )),
                          flex: 1,
                        ),
                         Expanded(
                          child: Row(
                            children: <Widget>[
                              isSentRequest
                                  ?  Text("")
                                  :  InkWell(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          child:  Container(
                                              height: 45.0,
                                              width: 45.0,
                                              child: Image.asset(
                                                'assets/newDesignIcon/connections/tick_blue.png',
                                              ))),
                                      onTap: () {
                                        apiCallingForAccept(
                                            requestedTagModel.connectId,
                                            index,
                                            "Accepted",
                                            requestedTagModel.userIsActive, requestedTagModel.userId);
                                      },
                                    ),
                              roleId == "1"
                                  ?  Container(
                                      height: 0.0,
                                    )
                                  :  InkWell(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              10.0, 0.0, 0.0, 0.0),
                                          child:  Container(
                                              height: 35.0,
                                              width: 35.0,
                                              child: Image.asset(
                                                'assets/newDesignIcon/connections/cancel.png',
                                              ))),
                                      onTap: () {
                                        String name = requestedTagModel
                                                        .userData.lastName ==
                                                    null ||
                                                requestedTagModel
                                                        .userData.lastName ==
                                                    "null" ||
                                                requestedTagModel
                                                        .userData.lastName ==
                                                    ""
                                            ? requestedTagModel
                                                .userData.firstName
                                            : requestedTagModel
                                                    .userData.firstName +
                                                " " +
                                                requestedTagModel
                                                    .userData.lastName;

                                        educationRemoveConfromationDialog(
                                            requestedTagModel.connectId,
                                            name,
                                            index,
                                            5);
                                      },
                                    )
                            ],
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                    onTap: () {
                      if (requestedTagModel.userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: requestedTagModel.userRoleId,
                            partnerUserId: requestedTagModel.userId,
                            context: context);
                      }
                    },
                  ),
                  index == 0
                      ?  Padding(
                          padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
                          child: Divider(
                            color: Colors.transparent,
                            height: 0.0,
                          ))
                      :  Container(
                          height: 0.0,
                        ),
                ],
              )));
    }

    Container getListViewForPeopleMayKnow(PeopleYouMayKnow PeopleYouMayKnow, index) {

      print("//////////////////////////////////"+peopleYouMayKnowList.length.toString());
      return  Container(
        padding:  EdgeInsets.fromLTRB(8.0, 10.0, 0.0, 0.0),
        child:  Container(
            child:  Card(
                color: Colors.white,
                elevation: 0.0,
                child:  Container(
                    decoration:  BoxDecoration(
                        border:  Border.all(
                            color:  ColorValues.BORDER_COLOR,
                            width: 0.5)),
                    child:  Column(
                      children: <Widget>[
                         Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 0.0),
                            child:  Align(
                              child:  InkWell(
                                child:  Container(
                                    height: 20.0,
                                    width: 20,
                                    child: Image.asset(
                                        'assets/newDesignIcon/connections/cancel_withoutbg.png')),
                                onTap: () {
                                  print("clicked"); // Cancel API call here

                                  peopleYouMayKnowList.remove(PeopleYouMayKnow);
                                  setState(() {
                                    peopleYouMayKnowList;
                                  });
                                  if (peopleYouMayKnowList.length < 4) {
                                    setState(() {

                                      apiCallingForTag2();
                                      setState(() {
                                        apiCallingForTag();
                                      });


                                    });
                                  }
                                },
                              ),
                              alignment: Alignment.topRight,
                            )),
                         Container(
                            height: 50.0,
                            width: 50.0,
                            child:  InkWell(
                              child: ClipRRect(
                                  borderRadius: BorderRadius.circular(100),
                                  child: PeopleYouMayKnow.profilePicture ==
                                              "" ||
                                          PeopleYouMayKnow.profilePicture ==
                                              "null"
                                      ?  Image.asset(PeopleYouMayKnow
                                                  .roleId ==
                                              "4"
                                          ? "assets/profile/partner_img.png"
                                          : 'assets/profile/user_on_user.png')
                                      : FadeInImage(
                                          fit: BoxFit.cover,
                                          placeholder: AssetImage(
                                            PeopleYouMayKnow.roleId == "4"
                                                ? "assets/profile/partner_img.png"
                                                : 'assets/profile/user_on_user.png',
                                          ),
                                          image: NetworkImage(Constant
                                                  .IMAGE_PATH_SMALL +
                                              PeopleYouMayKnow.profilePicture),
                                        )),
                              onTap: () {},
                            )),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: TextViewWrap.textView(
                                  PeopleYouMayKnow.lastName == null ||
                                          PeopleYouMayKnow.lastName == "null" ||
                                          PeopleYouMayKnow.lastName == ""
                                      ? PeopleYouMayKnow.firstName
                                      : PeopleYouMayKnow.firstName +
                                          " " +
                                          PeopleYouMayKnow.lastName,
                                  TextAlign.right,
                                   ColorValues.HEADING_COLOR_EDUCATION,
                                  14.0,
                                  FontWeight.normal),
                              flex: 0,
                            ),
                            Expanded(
                              flex: 0,
                              child: PeopleYouMayKnow.roleId == "1" ?
                              Util.getStudentBadge12(PeopleYouMayKnow.badge,PeopleYouMayKnow.badgeImage):Container(),
                            ),

                          ],
                        ),
                        TextViewWrap.textView(
                            PeopleYouMayKnow.tagline == null ||
                                    PeopleYouMayKnow.tagline == "null" ||
                                    PeopleYouMayKnow.tagline == ""
                                ? ""
                                : PeopleYouMayKnow.tagline,
                            TextAlign.right,
                             ColorValues.GREY_TEXT_COLOR,
                            12.0,
                            FontWeight.normal),
                         Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                            child:  InkWell(
                              child:  Container(
                                  color:
                                      ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  height: 30.0,
                                  width: 125.0,
                                  child:  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          5.0, 7.5, 5.0, 0.0),
                                      child:  Text(
                                        "CONNECT",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontFamily: Constant.customRegular,
                                            fontSize: 12.0,
                                            color: Colors.white),
                                      ))),
                              onTap: () {
                                // Connect API Call

                                apiCallForConnect(
                                    PeopleYouMayKnow.userId,
                                    PeopleYouMayKnow.isActive,
                                    PeopleYouMayKnow,
                                    PeopleYouMayKnow.roleId);
                              },
                            ))
                      ],
                    )))),
        height: 190.0,
        width: 165.0,
      );
    }

    // --------------------  DESIGN Code done by AT ---------------------
    Future<Null> _refreshPageHere() async {
      apiCallingForTag();
    }

    onTapRefer() async {
      print("refer now Clicked====================");
      String referCode = prefs.getString(UserPreference.referCode);
      if(roleId == "1")
      Util.shareAppLinkViaOtherApp(context,referCode,prefs.getString(UserPreference.NAME));
      else
      Util.shareAppLinkViaOtherAppParent(context,referCode,roleId=="4"?prefs.getString(UserPreference.COMPANY_NAME_PATH):prefs.getString(UserPreference.NAME));



    }

    onTapDiscover() async {
      String result = await Navigator.push(
          context, MaterialPageRoute(builder: (context) => DiscoverWidget()));
      if (result == "push") {
        apiCallingForTag();
      }
    }

    Widget getMainView() {
      return  RefreshIndicator(
          onRefresh: _refreshPageHere,
          displacement: 0.0,
          child: Container(
            child:  ListView(
              children: <Widget>[
                // Heading and List For Friend Request

                 Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    diffrenceInDob < 13
                        ?  Container(
                            height: 0.0,
                          )
                        :  Column(
                            children: <Widget>[
                              tagList.length == 0
                                  ?  Container(
                                      height: 0.0,
                                    )
                                  : Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0.0, 10, 0.0, 0.0),
                                      child: Container(
                                          width: double.infinity,
                                          decoration:  BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: ColorValues.DARK_GREY),
                                          ),
                                          child:  Column(
                                            children: <Widget>[
                                               Container(
                                                child:  Row(
                                                  children: <Widget>[
                                                     Expanded(
                                                      child:  Padding(
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  13.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                          child:  Text(
                                                            roleId == "4" ||
                                                                    roleId ==
                                                                        "1"
                                                                ? "RECEIVED REQUEST(S) -(" +
                                                                    requestedCount
                                                                        .toString() +
                                                                    ")"
                                                                : "RECEIVED REQUEST(S) (MY ACCOUNT)-(" +
                                                                    requestedCount
                                                                        .toString() +
                                                                    ")",
                                                            style: TextStyle(
                                                                fontSize: 12.0,
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontFamily: Constant
                                                                    .customRegular),
                                                          )),
                                                      flex: 1,
                                                    ),
                                                     Expanded(
                                                      child:  InkWell(
                                                        child:  Container(
                                                            height: 40.0,
                                                            child:  Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        10.0,
                                                                        3.0,
                                                                        10.0,
                                                                        0.0),
                                                                child:  Text(
                                                                  requestedCount >
                                                                          2
                                                                      ? isViewAllForRequest
                                                                          ? "Hide"
                                                                          : "View All"
                                                                      : "",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          14.0,
                                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                      fontFamily:
                                                                          Constant
                                                                              .customRegular),
                                                                ))),
                                                        onTap: () {
                                                          if (requestedCount >
                                                              2) {
                                                            navigationForSeeAllPage(
                                                                "Requests",
                                                                0,
                                                                tagList,
                                                                sendRequestList,
                                                                peopleYouMayKnowList);
                                                          }
                                                        },
                                                      ),
                                                      flex: 0,
                                                    )
                                                  ],
                                                ),
                                                color: ColorValues.GREY__COLOR_DIVIDER,
                                                height: 25.0,
                                              ),
                                               Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 5.0, 0.0, 5.0),
                                                  child:  Column(
                                                    children:  List.generate(
                                                        tagList.length > 2
                                                            ? isViewAllForRequest
                                                                ? tagList.length
                                                                : 2
                                                            : tagList.length,
                                                        (int index) {
                                                      return getListview(
                                                          tagList[index],
                                                          index,
                                                          false);
                                                    }),
                                                  ))
                                            ],
                                          ))),
                            ],
                          ),
                    diffrenceInDob < 13 || roleId == "2"
                        ?  Column(children: <Widget>[
                            roleId == "4" || receivedRequestList.length == 0
                                ?  Container(
                                    height: 0.0,
                                  )
                                : Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 10, 0.0, 0.0),
                                    child: Container(
                                        width: double.infinity,
                                        decoration:  BoxDecoration(
                                          color: Colors.white,
                                          border: Border.all(
                                              color:
                                                  ColorValues.DARK_GREY),
                                        ),
                                        child:  Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                             Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    0.0, 0.0, 0.0, 0.0),
                                                child:  Container(
                                                  child:  Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: <Widget>[
                                                       Expanded(
                                                        child:  Padding(
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    13.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                            child:  Text(
                                                              diffrenceInDob <
                                                                      13
                                                                  ? "RECEIVED REQUEST(S)(" +
                                                                      receivedRequestCount
                                                                          .toString() +
                                                                      ")"
                                                                  : "PENDING APPROVAL RECEIVED REQUEST(S)(STUDENTS)-(" +
                                                                      receivedRequestCount
                                                                          .toString() +
                                                                      ")",
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontFamily:
                                                                      Constant
                                                                          .customRegular),
                                                            )),
                                                        flex: 1,
                                                      ),
                                                      diffrenceInDob > 13
                                                          ?  Expanded(
                                                              child:
                                                                   InkWell(
                                                                child: PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        5.0,
                                                                        0.0,
                                                                        10.0,
                                                                        0.0,
                                                                        Image
                                                                            .asset(
                                                                          'assets/newDesignIcon/info.png',
                                                                          height:
                                                                              25.0,
                                                                          width:
                                                                              25.0,
                                                                        )),
                                                                onTap: () {
                                                                  infoDialog();
                                                                },
                                                              ),
                                                              flex: 0,
                                                            )
                                                          :  Container(
                                                              height: 0.0,
                                                            ),
                                                       Expanded(
                                                        child:  InkWell(
                                                          child:  Container(
                                                              child:
                                                                   Padding(
                                                                      padding: EdgeInsets.fromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          10.0,
                                                                          0.0),
                                                                      child:
                                                                           Text(
                                                                        receivedRequestCount >
                                                                                2
                                                                            ? isViewAllReceivedRequestList
                                                                                ? "Hide"
                                                                                : "View All"
                                                                            : "",
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                14.0,
                                                                            color:
                                                                                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                            fontFamily: Constant.customRegular),
                                                                      ))),
                                                          onTap: () {
                                                            if (receivedRequestCount >
                                                                2) {
                                                              navigationForSeeAllPage(
                                                                  diffrenceInDob <
                                                                          13
                                                                      ? "RECEIVED REQUEST(S)"
                                                                      : "RECEIVED REQUEST(S)(STUDENTS)",
                                                                  5,
                                                                  tagList,
                                                                  sendRequestList,
                                                                  peopleYouMayKnowList);
                                                            }
                                                          },
                                                        ),
                                                        flex: 0,
                                                      ),
                                                    ],
                                                  ),
                                                  color: ColorValues.GREY__COLOR_DIVIDER,
                                                  height: roleId == "1"
                                                      ? 25.0
                                                      : 40.0,
                                                )),
                                            receivedRequestList.length == 0
                                                ?  Container(
                                                    height: 0.0,
                                                  )
                                                :  Padding(
                                                    padding:
                                                        EdgeInsets.fromLTRB(
                                                            0.0, 5.0, 0.0, 5.0),
                                                    child:  Column(
                                                      children:  List
                                                              .generate(
                                                          receivedRequestList
                                                                      .length >
                                                                  2
                                                              ? isViewAllReceivedRequestList
                                                                  ? receivedRequestList
                                                                      .length
                                                                  : 2
                                                              : receivedRequestList
                                                                  .length,
                                                          (int index) {
                                                        return getListviewForRecieveList(
                                                            receivedRequestList[
                                                                index],
                                                            index,
                                                            roleId == "2"
                                                                ? false
                                                                : true,
                                                            "Requested");
                                                      }),
                                                    )),
                                          ],
                                        ))),
                          ])
                        :  Container(
                            height: 0.0,
                          ),
                    diffrenceInDob < 13
                        ?  Container(
                            height: 0.0,
                          )
                        :  Column(
                            children: <Widget>[
                              roleId == "4" || sendRequestList.length == 0
                                  ?  Container(
                                      height: 0.0,
                                    )
                                  : Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0.0, 10, 0.0, 0.0),
                                      child: Container(
                                          width: double.infinity,
                                          decoration:  BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: ColorValues.DARK_GREY),
                                          ),
                                          child:  Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                               Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 0.0, 0.0, 0.0),
                                                  child:  Container(
                                                    child:  Row(
                                                      children: <Widget>[
                                                         Expanded(
                                                          child:  Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .fromLTRB(
                                                                          13.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                              child:  Text(
                                                                "REQUESTS SENT(S) (MY ACCOUNT)-(" +
                                                                    sentRequestCount
                                                                        .toString() +
                                                                    ")",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        12.0,
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontFamily:
                                                                        Constant
                                                                            .customRegular),
                                                              )),
                                                          flex: 1,
                                                        ),
                                                         Expanded(
                                                          child:  InkWell(
                                                            child:  Container(
                                                                height: 40.0,
                                                                child:  Padding(
                                                                    padding: EdgeInsets.fromLTRB(0.0, 3.0, 10.0, 0.0),
                                                                    child:  Text(
                                                                      sentRequestCount >
                                                                              2
                                                                          ? isViewAllForSentRequest
                                                                              ? "Hide"
                                                                              : "View All"
                                                                          : "",
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              14.0,
                                                                          color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                          fontFamily:
                                                                              Constant.customRegular),
                                                                    ))),
                                                            onTap: () {
                                                              if (sentRequestCount >
                                                                  2) {
                                                                navigationForSeeAllPage(
                                                                    "Sent Request",
                                                                    1,
                                                                    tagList,
                                                                    sendRequestList,
                                                                    peopleYouMayKnowList);
                                                              }
                                                            },
                                                          ),
                                                          flex: 0,
                                                        )
                                                      ],
                                                    ),
                                                    color: ColorValues.GREY__COLOR_DIVIDER,
                                                    height: 25.0,
                                                  )),
                                              sendRequestList.length == 0
                                                  ?  Container(
                                                      height: 0.0,
                                                    )
                                                  :  Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              0.0,
                                                              5.0,
                                                              0.0,
                                                              5.0),
                                                      child:  Column(
                                                        children:  List
                                                                .generate(
                                                            sendRequestList
                                                                        .length >
                                                                    2
                                                                ? isViewAllForSentRequest
                                                                    ? sendRequestList
                                                                        .length
                                                                    : 2
                                                                : sendRequestList
                                                                    .length,
                                                            (int index) {
                                                          return getListviewForSendList(
                                                              sendRequestList[
                                                                  index],
                                                              index,
                                                              true,
                                                              "");
                                                        }),
                                                      )),
                                            ],
                                          ))),
                            ],
                          ),
                  ],
                ),

                diffrenceInDob < 13 || roleId == "2"
                    ?  Column(children: <Widget>[
                        roleId == "4" || pendinForParentDataList.length == 0
                            ?  Container(
                                height: 0.0,
                              )
                            : Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 10, 0.0, 0.0),
                                child: Container(
                                    width: double.infinity,
                                    decoration:  BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                          color: ColorValues.DARK_GREY),
                                    ),
                                    child:  Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                         Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.0, 0.0, 0.0, 0.0),
                                            child:  Container(
                                              child:  Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Expanded(
                                                    child:  Padding(
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                13.0,
                                                                0.0,
                                                                0.0,
                                                                0.0),
                                                        child:  Text(
                                                          roleId == "1"
                                                              ? "SENT REQUEST(S)(" +
                                                                  pendingRequestCount
                                                                      .toString() +
                                                                  ")"
                                                              : "PENDING APPROVAL SENT REQUEST(S)(STUDENTS)-(" +
                                                                  pendingRequestCount
                                                                      .toString() +
                                                                  ")",
                                                          style: TextStyle(
                                                              fontSize: 12.0,
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontFamily: Constant
                                                                  .customRegular),
                                                        )),
                                                    flex: 1,
                                                  ),
                                                  diffrenceInDob > 13
                                                      ?  Expanded(
                                                          child:  InkWell(
                                                            child: PaddingWrap
                                                                .paddingfromLTRB(
                                                                    5.0,
                                                                    0.0,
                                                                    10.0,
                                                                    0.0,
                                                                    Image.asset(
                                                                      'assets/newDesignIcon/info.png',
                                                                      height:
                                                                          25.0,
                                                                      width:
                                                                          25.0,
                                                                    )),
                                                            onTap: () {
                                                              infoDialog();
                                                            },
                                                          ),
                                                          flex: 0,
                                                        )
                                                      :  Container(
                                                          height: 0.0,
                                                        ),
                                                   Expanded(
                                                    child:  InkWell(
                                                      child:  Container(
                                                          child:  Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          10.0,
                                                                          0.0),
                                                              child:  Text(
                                                                pendingRequestCount >
                                                                        2
                                                                    ? isViewAllForPendingRequest
                                                                        ? "Hide"
                                                                        : "View All"
                                                                    : "",
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14.0,
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    fontFamily:
                                                                        Constant
                                                                            .customRegular),
                                                              ))),
                                                      onTap: () {
                                                        if (pendingRequestCount >
                                                            2) {
                                                          navigationForSeeAllPage(
                                                              "Pending",
                                                              4,
                                                              tagList,
                                                              sendRequestList,
                                                              peopleYouMayKnowList);
                                                        }
                                                      },
                                                    ),
                                                    flex: 0,
                                                  ),
                                                ],
                                              ),
                                              color: ColorValues.GREY__COLOR_DIVIDER,
                                              height:
                                                  roleId == "1" ? 25.0 : 40.0,
                                            )),
                                        pendinForParentDataList.length == 0
                                            ?  Container(
                                                height: 0.0,
                                              )
                                            :  Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    0.0, 5.0, 0.0, 5.0),
                                                child:  Column(
                                                  children:  List.generate(
                                                      pendinForParentDataList
                                                                  .length >
                                                              2
                                                          ? isViewAllForPendingRequest
                                                              ? pendinForParentDataList
                                                                  .length
                                                              : 2
                                                          : pendinForParentDataList
                                                              .length,
                                                      (int index) {
                                                    return getListviewForPending(
                                                        pendinForParentDataList[
                                                            index],
                                                        index,
                                                        roleId == "2"
                                                            ? false
                                                            : true,
                                                        "Requested");
                                                  }),
                                                )),
                                      ],
                                    ))),
                      ])
                    :  Container(
                        height: 0.0,
                      ),


                roleId == "4"
                    ?  Container(
                        height: 0.0,
                      )
                    :  Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          roleId == "4"
                              ?  Container(
                                  height: 0.0,
                                )
                              : Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      13.0, 10, 13, 0),
                                  child: Container(
                                    width: double.infinity,
                                    decoration:  BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                          color: ColorValues.DARK_GREY),
                                    ),
                                    child: Column(
                                      children: <Widget>[

                                         Column(
                                          children: <Widget>[
                                            Padding(
                                              padding: const EdgeInsets
                                                  .fromLTRB(
                                                  30, 13, 30, 18),
                                              child: Text(
                                              roleId=="2"? "Invite Friends":  "Invite Friends and Earn",
                                                style: TextStyle(
                                                    color:
                                                    Color(0xFF000000),
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMBOLD,
                                                    fontSize: 20),
                                                textAlign:
                                                TextAlign.center,
                                              ),
                                            ),
                                            Image.asset(
                                              "assets/newDesignIcon/connections/refernow.png",
                                              height: 160.0,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets
                                                  .fromLTRB(
                                                  15, 15, 15, 18),
                                              child: Text(
                                                roleId == "1" ?
                                                "Invite your friends and build your global network while earning reward points.":
                                                "Invite your friends and build your global parent network.",


                                                style: TextStyle(
                                                    color:
                                                    Color(0xFF000000),
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 16),
                                                textAlign:
                                                TextAlign.center,
                                              ),
                                            ),

                                             Padding(
                                                padding:
                                                EdgeInsets.fromLTRB(
                                                    0.0,
                                                    15.0,
                                                    0.0,
                                                    15.0),
                                                child:  InkWell(
                                                  child:  Container(
                                                      color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      height: 31,
                                                      width: 100.0,
                                                      child:  Padding(
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                              5.0,
                                                              0.0,
                                                              5.0,
                                                              0.0),
                                                          child: Center(
                                                            child:  Text(
                                                              "INVITE",
                                                              textAlign:
                                                              TextAlign
                                                                  .center,
                                                              style: TextStyle(
                                                                  fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR,
                                                                  fontSize:
                                                                  14.0,
                                                                  color: Colors
                                                                      .white),
                                                            ),
                                                          ))),
                                                  onTap: () {
                                                    onTapRefer();
                                                  },
                                                ))
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 10, 0.0, 0.0),
                              child:  Container(
                                child:  Row(
                                  children: <Widget>[
                                     Expanded(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 0.0, 0.0, 0.0),
                                          child:  Text(
                                            "PEOPLE YOU MAY KNOW",
                                            style: TextStyle(
                                                fontSize: 12.0,
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontFamily:
                                                    Constant.customRegular),
                                          )),
                                      flex: 1,
                                    ),
                                     Expanded(
                                      child:peopleYouMayKnowList.length == 0?Container():  InkWell(
                                        child:  Container(
                                            height: 40.0,
                                            child:  Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    10.0, 3.0, 10.0, 0.0),
                                                child:  Text(
                                                  /*peopleYouMayKnowList.length >
                                                          2
                                                      ? */"View All"
                                                     /* : ""*/,
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily: Constant
                                                          .customRegular),
                                                ))),
                                        onTap: () {
                                          print(".............111111"+peopleYouMayKnowList.length.toString());


                                        //  if (peopleYouMayKnowList.length > 2) {
                                            navigationForSeeAllPage(
                                                "People You May Know",
                                                2,
                                                tagList,
                                                sendRequestList,
                                                peopleYouMayKnowList);
                                        //  }
                                        },
                                      ),
                                      flex: 0,
                                    )
                                  ],
                                ),
                                color: ColorValues.GREY__COLOR_DIVIDER,
                                height: 24.0,
                              )),
                          peopleYouMayKnowList.length == 0
                              ?  Container(
                                  height: 100.0,
                                  color: Colors.white,
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                       Text(
                                        "Not enough data to show",
                                        style: TextStyle(
                                            fontSize: 16.0,
                                            color:  ColorValues.GREY_TEXT_COLOR,
                                            fontFamily: Constant.customBold),
                                      ),
                                    ],
                                  ))
                              :  SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child:  Row(
                                    children:  List.generate(
                                       /* peopleYouMayKnowList.length > 3
                                            ? isViewAllForPeopleMayYouKnow
                                                ? peopleYouMayKnowList.length
                                                : 3
                                            :*/ peopleYouMayKnowList.length,
                                        (int index) {
                                      return getListViewForPeopleMayKnow(
                                          peopleYouMayKnowList[index], index);
                                    }),
                                  )),
                          sendRequestList.length == 0
                              ? Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 10, 0.0, 13.0),
                                  child: Container(
                                      width: double.infinity,
                                      decoration:  BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                            color:
                                                ColorValues.DARK_GREY),
                                      ),
                                      child:  Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                           Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 0.0, 0.0),
                                              child:  Container(
                                                child:  Row(
                                                  children: <Widget>[
                                                     Expanded(
                                                      child:  Padding(
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  13.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                          child:  Text(
                                                            "FIND PEOPLE TO CONNECT WITH",
                                                            style: TextStyle(
                                                                fontSize: 12.0,
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontFamily: Constant
                                                                    .customRegular),
                                                          )),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                ),
                                                color: ColorValues.GREY__COLOR_DIVIDER,
                                                height: 24.0,
                                              )),
                                          Padding(
                                            padding: const EdgeInsets.all(13.0),
                                            child: Container(
                                              width: double.infinity,
                                              child: Column(
                                                children: <Widget>[
                                                   Row(
                                                    children: <Widget>[
                                                       Expanded(
                                                        child: Image.asset(
                                                          "assets/newDesignIcon/connections/want_to_connect.png",
                                                          height: 100.0,
                                                          width: 122.0,
                                                        ),
                                                        flex: 1,
                                                      ),
                                                       Expanded(
                                                        child:  Column(
                                                          children: <Widget>[
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      30,
                                                                      20,
                                                                      30,
                                                                      3),
                                                              child: Text(
                                                                "Discover Connections",
                                                                style: TextStyle(
                                                                    color: Color(
                                                                        0xFF404040),
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR,
                                                                    fontSize:
                                                                        16),
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      13,
                                                                      0,
                                                                      5,
                                                                      2),
                                                              child: Text(
                                                                "Build important connections with teammates, advisors, coaches, leaders, etc.",
                                                                style: TextStyle(
                                                                    color: Color(
                                                                        0xFF404040),
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR,
                                                                    fontSize:
                                                                        14),
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      0,
                                                                      0,
                                                                      0,
                                                                      10),
                                                              child:
                                                                   InkWell(
                                                                child: Text(
                                                                  "DISCOVER",
                                                                  style: TextStyle(
                                                                      color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR,
                                                                      fontSize:
                                                                          14),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                ),
                                                                onTap: () {
                                                                  onTapDiscover();
                                                                },
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        flex: 2,
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      )))
                              :  Container(
                                  height: 0.0,
                                ),
                        ],
                      ),
              ],
            ),
          ));
    }

    return getMainView();
  }

  Future navigationForSeeAllPage(
      String s,
      int listType,
      List<RequestedTagModel> tagList,
      List<RequestedTagModel> sendRequestList,
      List<PeopleYouMayKnow> peopleYouMayKnowList) async {
    bool isNeedToRefresh = false;

    switch (listType) {
      case 0:
        isNeedToRefresh = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    RequestsSeeAllWidget("Requests", listType)));

        if (isNeedToRefresh) {
          apiCallingForTag();
        }

        break;
      case 1:
        isNeedToRefresh = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    RequestsSeeAllWidget("Sent Request", listType)));

        if (isNeedToRefresh) {
          apiCallingForTag();
        }

        break;
      case 2:
        isNeedToRefresh = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    RequestsSeeAllWidget("People You May Know", listType)));

        if (isNeedToRefresh) {
          apiCallingForTag();
        }

        break;

      case 3:
        isNeedToRefresh = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    RequestsSeeAllWidget("Pending Referral", listType)));

        if (isNeedToRefresh) {
          apiCallingForTag();
        }

        break;
      case 4:
        isNeedToRefresh = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => RequestsSeeAllWidget(
                    diffrenceInDob < 13
                        ? "SENT REQUEST(S)"
                        : "SENT REQUEST(S)(STUDENTS)",
                    listType)));

        if (isNeedToRefresh) {
          apiCallingForTag();
        }

        break;
      case 5:
        isNeedToRefresh = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => RequestsSeeAllWidget(
                    diffrenceInDob < 13
                        ? "RECEIVED REQUEST(S)"
                        : "RECEIVED REQUEST(S)(STUDENTS)",
                    listType)));

        if (isNeedToRefresh) {
          apiCallingForTag();
        }

        break;
    }
  }

  void educationRemoveConfromationDialog(id, name, index, int listType) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        25.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(20.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
//                                               Text(
//                                                "Are you sure you want to remove " +
//                                                    name +
//                                                    "?",
//                                                textAlign: TextAlign.center,
//                                                maxLines: 5,
//                                                style:  TextStyle(
//                                                    color:  Color(ColorValues
//                                                        .HEADING_COLOR_EDUCATION),
//                                                    height: 1.2,
//                                                    fontSize: 16.0,
//                                                    fontFamily:
//                                                        Constant.TYPE_CUSTOMREGULAR),
//                                              ),

                                                  RichText(
                                                    textAlign: TextAlign.center,
                                                    text: TextSpan(
                                                      text:
                                                          'This connection request will be declined.',
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),

                                                    ),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Remove",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              // Delete

                                              Navigator.pop(context);
                                              if ((listType == 4 ||
                                                      listType == 5) &&
                                                  roleId == "2") {

                                                apiCallingForDeleteStudentConnection(
                                                  id,
                                                  index,
                                                );
                                              } else if (listType == 0) {
                                                apiCallingForUnfriendTagList(
                                                  id,
                                                  index,
                                                );
                                              } else {
                                                apiCallingForUnfriendSendList(
                                                  id,
                                                  index,
                                                );
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void educationRemoveConfromationDialogRequest(id, name, index, int listType) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        25.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(20.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
//                                               Text(
//                                                "Are you sure you want to remove " +
//                                                    name +
//                                                    "?",
//                                                textAlign: TextAlign.center,
//                                                maxLines: 5,
//                                                style:  TextStyle(
//                                                    color:  Color(ColorValues
//                                                        .HEADING_COLOR_EDUCATION),
//                                                    height: 1.2,
//                                                    fontSize: 16.0,
//                                                    fontFamily:
//                                                        Constant.TYPE_CUSTOMREGULAR),
//                                              ),

                                                  RichText(
                                                    textAlign: TextAlign.center,
                                                    text: TextSpan(
                                                      text:
                                                          'This connection request will be declined.',
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),

                                                    ),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Remove",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              // Delete

                                              Navigator.pop(context);

                                              if (listType == 0) {
                                                apiCallingForUnfriendTagList(
                                                  id,
                                                  index,
                                                );
                                              } else {
                                                apiCallingForUnfriendSendList(
                                                  id,
                                                  index,
                                                );
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
