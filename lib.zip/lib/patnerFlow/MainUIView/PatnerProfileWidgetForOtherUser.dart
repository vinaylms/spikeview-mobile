import 'dart:async';
import 'dart:io';
import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:intl/intl.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/badges/BadgesRequestForm.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/group/RequestedGroupList.dart';

import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/BadgeDataModel.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/ConnectionModel.dart';
import 'package:spike_view_project/modal/GroupListForUserModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/modal/option_menu.dart';

import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';

import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/CompanyDetailPage.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/ManageOfferingWidget.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/rating/RatingModel.dart';

import 'package:spike_view_project/report/ReportWidget.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
class PatnerProfileWidgetForOtherUser extends StatefulWidget {
  String userId, callingType;
  String connectionId, groupId;
  String requestStatus;

  PatnerProfileWidgetForOtherUser(this.userId, this.callingType,
      {this.connectionId, this.requestStatus, this.groupId});

  @override
  PatnerProfileWidgetForOtherUserState createState() =>
      PatnerProfileWidgetForOtherUserState(userId);
}

class PatnerProfileWidgetForOtherUserState
    extends State<PatnerProfileWidgetForOtherUser> {
  int notificationCount = 0;
  final descriptionController = TextEditingController();
  String description = '';

  PatnerProfileWidgetForOtherUserState(this.userIdPref);
  bool isConnection_AccessControl = true;
  bool isProfileVisiblity = true;
  bool isChat_AccessControl = true;
  bool isCallStudentRequestApi = false;

  Color borderColor = Colors.amber;
  bool isRememberMe = false;
  bool isDataRember = false;
  File imagePath, imagePathCover;
  String strNetworkImage = "";
  String userIdPref, roleId, token;
  TextEditingController passwordCtrl, emailCtrl;
  ProfileInfoModal profileInfoModal;
  List<StudentDataModel> listStudent = List();
  List<ProfileEducationModal> userEducationList = List<ProfileEducationModal>();
  List<NarrativeModel> narrativeList = List<NarrativeModel>();
  List<Recomdation> recommendationtList = List<Recomdation>();
  BuildContext context;
  SharedPreferences prefs;
  bool isSentRequest = true;
  bool isNarativeShow = false;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String sasToken, containerName;
  String strPrefixPathforCoverPhoto,
      strPrefixPathforProfilePhoto,
      strAzureCoverImageUploadPath = "",
      strAzureProfileImageUploadPath = "";
  String strSummary;
  String strAccCount = "", strRecCount = "";
  bool isActive = false;
  StreamSubscription<dynamic> _streamSubscription;
  StreamSubscription<dynamic> _streamSubscriptionWizard;
  ScrollController _scrollController = ScrollController();
  bool isTitleVisible = false;
  bool _isAppbar = true;
  final _formKey = GlobalKey<FormState>();
  TextEditingController fromDateController;
  String strDoB = "";
  String strFirstName = "", strLastName = "", strEmail = "";
  bool isLoading = true;
  bool isRatingLodaing = true;
  static String isAchivmentAdded = "false";
  static String isEducationAdded = "false";
  bool isShowAllActiveOpportunity = false;
  bool isShowAllExpireOpportunity = false;
  static StreamController syncDoneController = StreamController.broadcast();

  bool isConnected = false;
  bool isParentApprovalPending = false;

  bool isAccepetd = false;
  String connectId = "0";
  bool isSubscribe = false;
  int subsCriberId = 0;
  ConnectionModel connectionModel;
  bool isDataLoading = true;
  CompanyProfileModel companyModel;
  List<OpportunityModel> activeOpportunityList = List();
  List<OpportunityModel> expireOpportunityList = List();
  List<BadgeDataModel> badgeList = List();
  bool isViewAllBadges = false;
  List<RequestedTagModel> pendinForParentDataList = List();
  List<RequestedTagModel> receivedRequestList = List();

  //-----------for rating------------
  var rating = 4.0;
  var ratingSelected = 0.0;
  bool isSelectTap = false;
  var ratingCalculation = 0.0;
  String creationDate = "";
  bool isView = false;
  bool isSelected = false;
  List<RatingModel> reviewList = List();
  RatingModel myRating;

  List<RatingModel> parseRating(map) {
    ratingCalculation = 0;
    List<RatingModel> tagList = List();
    String userIdMY = prefs.getString(UserPreference.USER_ID);
    try {
      for (int k = 0; k < map.length; k++) {
        String reviewId = map[k]['reviewId'].toString();
        var rating = map[k]['rating'];
        String review = map[k]['review'].toString();
        int date = map[k]['date'];
        String senderId = map[k]['senderId'].toString();
        String receiverId = map[k]['receiverId'].toString();
        String profilePicture = map[k]['profilePicture'].toString();
        String name = map[k]['name'].toString();
        var pointRating = 0.0;
        pointRating = pointRating + rating;
        ratingCalculation = rating + ratingCalculation;
        setState(() {
          ratingCalculation;
        });
        print("totalRating=====" + ratingCalculation.toString());
        if (userIdMY == senderId) {
          myRating = RatingModel(reviewId, pointRating, review, date, senderId,
              receiverId, name, profilePicture);
        }

        tagList.add(new RatingModel(reviewId, pointRating, review, date,
            senderId, receiverId, name, profilePicture));
      }
    } catch (e) {}
    return tagList;
  }

  Future reviewApi() async {
    print("api call");
    try {
      var isConnect = await ConectionDetecter.isConnected();
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String user = prefs.getString(UserPreference.USER_ID);
      print("UserId============" + user);
      if (isConnect) {
        setState(() {
          isRatingLodaing = true;
        });
        Response response = await ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_REVIEW_API + userIdPref, "get");
        print(response);
        myRating = null;
        setState(() {
          isRatingLodaing = false;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data["status"];

            if (status == "Success") {
              reviewList.clear();
              reviewList = parseRating(response.data['result']);
              setState(() {
                reviewList;
              });
            }
          }
        }
      } else {}
    } catch (e) {
      setState(() {
        isRatingLodaing = false;
      });
      e.toString();
    }
  }

  Future badgeApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2()
          .apiCall(context, Constant.ENDPOINT_BADGES + userIdPref, "get");
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response parent" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            badgeList.clear();
            badgeList = ParseJson.parseBadgeList(response.data['result']);

            setState(() {
              badgeList;
            });
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCallDeleteReview() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        SharedPreferences prefs = await SharedPreferences.getInstance();
        Map map = {
          "reviewId": myRating.reviewId,
        };
        print("map++++" + map.toString());
        response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_REVIEW_API, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data["status"];
            String msg = response.data["message"];
            if (status == "Success") {
              reviewApi();
            } else {}
          }
        }
      }
    } catch (e) {}
  }

  String searchUserAccessConnection = "";

  Future apiGetAccessControl() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ACCESS_CONTROL +
              profileInfoModal.schoolCode +
              "&userId=" +
              profileInfoModal.userId +
              "&roleId=4",
          "get");
      print("apiGetAccessControl+++++" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            searchUserAccessConnection = response.data['result']
                    ['accessControl']['connection']
                .toString();
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_PERSONAL_INFO_NEW +
              userIdPref +
              "/false/" +
              "4/" +
              roleId,
          "get");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response parent data++++" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            profileInfoModal =
                ParseJson.parseMapUserProfile(response.data['result']);

            print("school code data+++" + profileInfoModal.schoolCode);
            if (profileInfoModal.isActive == "true") {
              isActive = true;
            }

            if (profileInfoModal != null) {
              try {
                if (profileInfoModal.schoolCode != null &&
                    profileInfoModal.schoolCode != "") {
                  await apiGetAccessControl();
                }
              } catch (e) {}
              strNetworkImage = profileInfoModal.profilePicture;
              setState(() {
                strNetworkImage;
                profileInfoModal;
              });
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future companyInfoApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=" + roleId,
          "get");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response comapny" + response.toString());
      print("response comapny userIdPref" + userIdPref + " &roleId " + roleId);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            var map = response.data['result'];
            if (map != null) {
              companyModel = ParseJson.parseCompanyInfoData(map);
              if (companyModel != null) {
                /*      prefs.setString(UserPreference.COMPANY_IMAGE_PATH,
                    companyModel.profilePicture);
                prefs.setString(
                    UserPreference.COMPANY_NAME_PATH, companyModel.name);
                syncDoneController.add("sucess");*/
              }
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future getOpportuinity(isShowLaoder) async {
    try {
      setState(() {
        isLoading = true;
      });
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_OPPORTUNITY + userIdPref + "&roleId=" + roleId,
          "get");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response comapny" + response.toString());
      setState(() {
        isLoading = false;
      });
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            activeOpportunityList = ParseJson.parseOpportunityData(
                response.data['result']["activeOpportunities"]);
            expireOpportunityList = ParseJson.parseOpportunityData(
                response.data['result']["expiredOpportunities"]);

            print("company name++" + activeOpportunityList.length.toString());
            setState(() {
              activeOpportunityList;
            });
          }
        }
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;

            print("sastoken:===" + sasToken);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

//***************************************************************************************************************
  //-------------------------Code For Approve Child Request----------------------------------
  Future apiCallForChildConnectionStatus() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String uri;
        uri = Constant.ENDPOINT_CHILD_CONNECTION_STATUS + widget.connectionId;

        print(uri);
        response = await ApiCalling2().apiCall(context, uri, "get");
        print("ENDPOINT_CHILD_CONNECTION_STATUS++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status =
                response.data[LoginResponseConstant.STATUS].toString();
            if (status == "Success") {
              isCallStudentRequestApi = true;
            } else {
              String msg =
                  response.data[LoginResponseConstant.MESSAGE].toString();
              if (msg != null && msg != "null") {
                isCallStudentRequestApi = false;
                ToastWrap.showToastGreen(msg, context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForChildList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String uri;
        uri = Constant.ENDPOINT_CHILD_LIST +
            prefs.getString(UserPreference.PARENT_ID) +
            "&partnerId=" +
            widget.userId +
            "&roleId=" +
            roleId +
            "&partnerRoleId=4";

        print(uri);
        response = await ApiCalling2().apiCall(context, uri, "get");
        print("getChildRequest++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            pendinForParentDataList.clear();
            receivedRequestList.clear();
            String status = response.data[LoginResponseConstant.STATUS];

            var map = response.data['result'];

            if (map.length > 0) {
              pendinForParentDataList = ParseJson.parseRequestedTagList(
                  response.data['result']['Pending']);

              receivedRequestList = ParseJson.parseRequestedTagList(
                  response.data['result']['receivedRequest']);
            }
            setState(() {});
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForDeleteStudentConnection(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId),
        "userId": prefs.getString(UserPreference.PARENT_ID)
      };
      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_DELETE_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            syncDoneController.add("");
            apiCallForChildList();
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForAcceptChildRequest(
      connectionId, index, type, userIsActive) async {
    print("datatat");
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": type,
        "isActive": userIsActive,
        "roleId": int.parse(roleId)
      };
      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("connect:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            ToastWrap.showToastGreen(
                MessageConstant.PARENT_ACCEPT_CONNECTION_MSG, context);
            syncDoneController.add("");
            apiCallForChildList();
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  void educationRemoveConfromationDialog(
      id, name, index, int listType, requestedTagModel) {

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: "This connection request will be declined.",
          onPositiveTap: () {
            apiCallingForDeleteStudentConnection(
              id,
              index,
            );
          },
        );
      },
    );
  }

  Container getListviewForPending(
      requestedTagModel, index, bool isSentRequest, status) {
    return Container(
        color: Colors.transparent,
        padding: EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
        child: Card(
            color: Colors.transparent,
            elevation: 0.0,
            child: Column(
              children: <Widget>[
                InkWell(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            0.0,
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    RichText(
                                        maxLines: 1,
                                        textAlign: TextAlign.start,
                                        text: TextSpan(
                                          text: "From ",
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                          ),
                                          children: <TextSpan>[
                                            TextSpan(
                                                text: requestedTagModel.userData
                                                                .lastName ==
                                                            null ||
                                                        requestedTagModel
                                                                .userData
                                                                .lastName ==
                                                            "null" ||
                                                        requestedTagModel
                                                                .userData
                                                                .lastName ==
                                                            ""
                                                    ? requestedTagModel
                                                        .userData.firstName
                                                    : requestedTagModel.userData
                                                            .firstName +
                                                        " " +
                                                        requestedTagModel
                                                            .userData.lastName,
                                                style: TextStyle(
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMBOLD,
                                                    fontSize: 14.0,
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR))
                                          ],
                                        )))
                              ],
                            )),
                        flex: 1,
                      ),
                      Expanded(
                        child: Row(
                          children: <Widget>[
                            isSentRequest
                                ? Text("")
                                : InkWell(
                                    child: Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                            height: 45.0,
                                            width: 45.0,
                                            child: Image.asset(
                                              'assets/newDesignIcon/connections/tick_blue.png',
                                            ))),
                                    onTap: () {
                                      apiCallingForAcceptChildRequest(
                                          requestedTagModel.connectId,
                                          index,
                                          "Requested",
                                          requestedTagModel.userIsActive);
                                    },
                                  ),
                            InkWell(
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                                  child: Container(
                                      height: 35.0,
                                      width: 35.0,
                                      child: Image.asset(
                                        'assets/newDesignIcon/connections/cancel.png',
                                      ))),
                              onTap: () {
                                String name =
                                    requestedTagModel.patner.lastName == null ||
                                            requestedTagModel.patner.lastName ==
                                                "null" ||
                                            requestedTagModel.patner.lastName ==
                                                ""
                                        ? requestedTagModel.patner.firstName
                                        : requestedTagModel.patner.firstName +
                                            " " +
                                            requestedTagModel.patner.lastName;

                                educationRemoveConfromationDialog(
                                    requestedTagModel.connectId,
                                    name,
                                    index,
                                    2,
                                    requestedTagModel);
                              },
                            )
                          ],
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                ),
                index > 0
                    ? Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                        child: Divider(
                          color: ColorValues.DARK_GREY,
                          height: 0.5,
                        ))
                    : Container(
                        height: 0.0,
                      ),
              ],
            )));
  }

  Container getListviewForRecieveList(
      requestedTagModel, index, bool isSentRequest, status) {
    return Container(
        color: Colors.transparent,
        padding: EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
        child: Card(
            color: Colors.transparent,
            elevation: 0.0,
            child: Column(
              children: <Widget>[
                InkWell(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            0.0,
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    RichText(
                                      maxLines: 1,
                                      textAlign: TextAlign.start,
                                      text: TextSpan(
                                        text: "For ",
                                        style: TextStyle(
                                          color: ColorValues.GREY_TEXT_COLOR,
                                          fontSize: 14.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR,
                                          fontWeight: FontWeight.normal,
                                        ),
                                        children: <TextSpan>[
                                          TextSpan(
                                              text: requestedTagModel.patner
                                                              .lastName ==
                                                          null ||
                                                      requestedTagModel.patner
                                                              .lastName ==
                                                          "null" ||
                                                      requestedTagModel.patner
                                                              .lastName ==
                                                          ""
                                                  ? requestedTagModel
                                                      .patner.firstName
                                                  : requestedTagModel
                                                          .patner.firstName +
                                                      " " +
                                                      requestedTagModel
                                                          .patner.lastName,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  fontFamily:
                                                      Constant.TYPE_CUSTOMBOLD,
                                                  fontSize: 14.0,
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR))
                                        ],
                                      ),
                                    ))
                              ],
                            )),
                        flex: 1,
                      ),
                      Expanded(
                        child: Row(
                          children: <Widget>[
                            isSentRequest
                                ? Text("")
                                : InkWell(
                                    child: Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                            height: 45.0,
                                            width: 45.0,
                                            child: Image.asset(
                                              'assets/newDesignIcon/connections/tick_blue.png',
                                            ))),
                                    onTap: () {
                                      apiCallingForAcceptChildRequest(
                                          requestedTagModel.connectId,
                                          index,
                                          "Accepted",
                                          requestedTagModel.userIsActive);
                                    },
                                  ),
                            InkWell(
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                                  child: Container(
                                      height: 35.0,
                                      width: 35.0,
                                      child: Image.asset(
                                        'assets/newDesignIcon/connections/cancel.png',
                                      ))),
                              onTap: () {
                                String name = requestedTagModel
                                                .userData.lastName ==
                                            null ||
                                        requestedTagModel.userData.lastName ==
                                            "null" ||
                                        requestedTagModel.userData.lastName ==
                                            ""
                                    ? requestedTagModel.userData.firstName
                                    : requestedTagModel.userData.firstName +
                                        " " +
                                        requestedTagModel.userData.lastName;

                                educationRemoveConfromationDialog(
                                    requestedTagModel.connectId,
                                    name,
                                    index,
                                    1,
                                    requestedTagModel);
                              },
                            )
                          ],
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                ),
                index > 0
                    ? Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                        child: Divider(
                          color: ColorValues.DARK_GREY,
                          height: 0.5,
                        ))
                    : Container(
                        height: 0.0,
                      ),
              ],
            )));
  }

  GroupListForUserModel _mGroupListForUserModel;

  Future apiCallForGetRequestData() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String uri;

        uri = Constant.ENDPOINT_GROUP_REQUESTED_BY_USER +
            prefs.getString(UserPreference.USER_ID) +
            "&roleId=" +
            prefs.getString(UserPreference.ROLE_ID) +
            "&requestedBy=" +
            userIdPref +
            "&requestedRole=" +
            "4";

        print(uri);
        response = await ApiCalling2().apiCall(context, uri, "get");
        print(response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            _mGroupListForUserModel =
                GroupListForUserModel.fromJson(response.data);
            setState(() {
              _mGroupListForUserModel;
            });
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForAcceptGroupRequest(type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        /*  Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "status": type
        };*/

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(profileInfoModal.userId),
          "roleId": int.parse(profileInfoModal.roleId),
          "isAdmin": true,
          "status": type
        };

        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              setState(() {
                widget.groupId = null;
                isPerformChanges = "push";
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  showInvitationDialog(context) {
    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              //  Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                // Navigator.pop(context);
              },
              child: Scaffold(
                  backgroundColor: Colors.transparent,
                  body: Stack(
                    children: [
                      Positioned(
                        right: 13.0,
                        top: 55.0,
                        left: 13.0,
                        child: Container(
                          color: Colors.black,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 0, 13, 0),
                                      child: Text("RESPOND REQUEST",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Colors.white,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR))),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0.0, 3, 0, 3),
                                    child: InkWell(
                                      child: Container(
                                          color: ColorValues.GREY__COLOR,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                10.0, 5, 10, 5),
                                            child: Text("REJECT",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR)),
                                          )),
                                      onTap: () {
                                        Navigator.pop(context);
                                        apiCallingForAcceptGroupRequest(
                                            "Rejected");
                                      },
                                    ),
                                  ),
                                  flex: 0,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        20.0, 3, 12.0, 3),
                                    child: InkWell(
                                      child: Container(
                                          color:
                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                10.0, 5, 10, 5),
                                            child: Text("ACCEPT",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR)),
                                          )),
                                      onTap: () {
                                        Navigator.pop(context);
                                        apiCallingForAcceptGroupRequest(
                                            "Accepted");
                                      },
                                    ),
                                  ),
                                  flex: 0,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                          right: 2.0,
                          top: 45.0,
                          child: InkWell(
                              child: Image.asset(
                                "assets/black_circle_cancel.png",
                                height: 30.0,
                                width: 30.0,
                              ),
                              onTap: () {
                                Navigator.pop(context);
                              }))
                    ],
                  )),
              onTap: () {
                // Navigator.pop(context);
              },
            )));
  }

  showInvitationDialogForNumberOfRequest(context) {
    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              //  Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                // Navigator.pop(context);
              },
              child: Scaffold(
                  backgroundColor: Colors.transparent,
                  body: Stack(
                    children: [
                      Positioned(
                        right: 13.0,
                        top: 55.0,
                        left: 13.0,
                        child: Container(
                          color: Colors.black,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 0, 0, 0),
                                      child: Text(
                                          "Join group request (" +
                                              _mGroupListForUserModel
                                                  .groupList.length
                                                  .toString() +
                                              ")",
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.white,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR))),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        10.0, 3, 12.0, 3),
                                    child: InkWell(
                                      child: Container(
                                          color:
                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                10.0, 5, 10, 5),
                                            child: Text("View Request",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR)),
                                          )),
                                      onTap: () async {
                                        String result = await Navigator.of(
                                                context)
                                            .push(new MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                    RequestedGroupList(
                                                        _mGroupListForUserModel,
                                                        profileInfoModal.userId,
                                                        profileInfoModal
                                                            .roleId)));
                                        if (result == "push") {
                                          isPerformChanges = "push";
                                          apiCallForGetRequestData();
                                        }
                                      },
                                    ),
                                  ),
                                  flex: 0,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                          right: 2.0,
                          top: 45.0,
                          child: InkWell(
                              child: Image.asset(
                                "assets/black_circle_cancel.png",
                                height: 30.0,
                                width: 30.0,
                              ),
                              onTap: () {
                                Navigator.pop(context);
                              }))
                    ],
                  )),
              onTap: () {
                // Navigator.pop(context);
              },
            )));
  }

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    setState(() {
      isDataLoading = true;
    });
    prefs = await SharedPreferences.getInstance();

    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    try {
      isProfileVisiblity =
      prefs.getString(UserPreference.ACCESS_CONTROL_PROFILE_VISIBILITY) ==
          "enable"
          ? true
          : false;
    } catch (e) {
      isProfileVisiblity = true;
    }
    if (!isProfileVisiblity) {
      try {
        setState(() {
          isDataLoading = false;
        });
        isConnection_AccessControl = prefs
            .getString(UserPreference.ACCESS_CONTROL_CONNECTION)
            .toLowerCase() ==
            "disable"
            ? false
            : true;
      } catch (e) {
        isConnection_AccessControl = true;
      }
      if(isConnection_AccessControl){
        ToastWrap.showToastWithPushMultiLine(
            MessageConstant.PROFILE_VISIBILITY_DISABLED_CONNECTION_ENABLED, context);
      }else {
        ToastWrap.showToastWithPushMultiLine(
            MessageConstant.PROFILE_VISIBILITY_DISABLED, context);
      }
    }else {
      try {
        isConnection_AccessControl = prefs
            .getString(UserPreference.ACCESS_CONTROL_CONNECTION)
            .toLowerCase() ==
            "disable"
            ? false
            : true;
      } catch (e) {
        isConnection_AccessControl = true;
      }
      try {
        isChat_AccessControl =
        prefs.getString(UserPreference.ACCESS_CONTROL_CHAT).toLowerCase() ==
            "disable"
            ? false
            : true;
      } catch (e) {
        isChat_AccessControl = true;
      }
      setState(() {});
      if (widget.groupId == null &&
          widget.callingType != "notification" &&
          widget.callingType != "ActionPerformed" &&
          widget.callingType != "pushNotification")
        await apiCallForGetRequestData();

      if (widget.connectionId != null &&
          widget.connectionId != "" &&
          roleId == "2" &&
          (widget.callingType == "redirect" ||
              widget.callingType == "view" ||
              widget.callingType == "notification")) {
        await apiCallForChildConnectionStatus();
      }
      if ((widget.connectionId != null && widget.connectionId != "") &&
          widget.callingType == "redirect" &&
          isCallStudentRequestApi) {
        await apiCallingForAccept();
      }

      if (roleId == "2") {
        apiCallForChildList();
      }

      var isConnect = await ConectionDetecter.isConnected();
      CustomProgressLoader.showLoader2(context);
      if (isConnect) {
        await profileApi(false);
        await companyInfoApi(false);
        await reviewApi();
        await badgeApi(false);
        apiCallForCheckSubscribe();
        apiCallForCheckIsFriend(false);
        await getOpportuinity(false);
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      isDataLoading = false;
      CustomProgressLoader.cancelLoader(context);

      if (widget.callingType == "ActionPerformed") {
        ToastWrap.showToast2Sec("Action already been taken", context);
      }

      if (isConnect) {
        await callApiForSaas();
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }

      strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
          userIdPref +
          "/" +
          Constant.CONTAINER_COVER +
          "/";

      strPrefixPathforProfilePhoto = Constant.CONTAINER_PREFIX +
          userIdPref +
          "/" +
          Constant.CONTAINER_PROFILE +
          "/";

      Timer _timer;

      _timer = Timer(const Duration(milliseconds: 2500), () async {
        if (widget.groupId != null) showInvitationDialog(context);
        if (_mGroupListForUserModel != null &&
            _mGroupListForUserModel.groupList.length > 0) {
          showInvitationDialogForNumberOfRequest(context);
        }
      });
    }
  }

  void appBarStatus(bool status) {
    setState(() {
      _isAppbar = status;
    });
  }

  Future apiCallingForAccept() async {
    try {
      Map map = {
        "connectId": int.parse(widget.connectionId),
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": widget.requestStatus,
        "isActive": "true",
        "roleId": 2
      };
      Response response = await ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("connect:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            ToastWrap.showToastGreen(
                MessageConstant.PARENT_ACCEPT_CONNECTION_MSG, context);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  String isPerformChanges = "pop";

  @override
  void initState() {
    print("changes");
    print("partner user+++" + widget.userId);
    print("partner user+++" + userIdPref);
    _streamSubscription =
        ManageOfferingWidgetState.syncDoneController.stream.listen((value) {
      print("value changes" + value);
      companyInfoApi(false);
    });

    _scrollController.addListener(() {
      if (_scrollController.offset < 150.0) {
        setState(() {
          isTitleVisible = false;
        });
      } else {
        setState(() {
          isTitleVisible = true;
        });
      }

      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        appBarStatus(false);
      }
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        appBarStatus(true);
      }
    });

    getSharedPreferences();

    super.initState();
  }

  //-------------listener for refresh profile info -------------------------
  void apiUpdated(String result) async {
    profileApi(true);
  }

  Future apiCallForCheckIsFriend(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response;
      String uri;

      uri = Constant.ENDPOINT_CHECK_IS_FRIEND +
          prefs.getString(UserPreference.USER_ID) +
          "&partnerId=" +
          userIdPref +
          "&partnerRoleId=4&userRoleId=" +
          prefs.getString(UserPreference.ROLE_ID);
      ;

      print(uri);
      response = await ApiCalling2().apiCall(context, uri, "get");
      print("Connected+++" + response.toString());
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          var map = response.data['result'];
          if (map.length > 0) {
            isConnected = true;

            String status = map[map.length - 1]['status'];
            isSubscribe = false;
            if (status == "Accepted") {
              isAccepetd = true;
              isSubscribe = true;
            } else if (status == "Requested") {
              isAccepetd = false;
            } else if (status == "Pending") {
              isParentApprovalPending = true;
            } else {
              isConnected = false;
            }

            String connectId = map[map.length - 1]['connectId'].toString();
            String userId = map[map.length - 1]['userId'].toString();
            String partnerId = map[map.length - 1]['partnerId'].toString();
            String dateTime = map[map.length - 1]['dateTime'].toString();
            int lastSeen = map[map.length - 1]['lastSeen'];
            int online = map[map.length - 1]['online'];
            this.connectId = connectId;
            try {
              String requestType =
                  map[map.length - 1]['requestType'].toString();

              if (requestType == "ReceivedByUnder13") {
                isSentRequest = false;
              } else {
                isSentRequest = true;
              }
            } catch (e) {}
            connectionModel = ConnectionModel(connectId, userId, partnerId,
                dateTime, status, lastSeen, online);
            setState(() {
              isAccepetd;
              isConnected;
              connectionModel;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------  api ------------------

  Future apiCallDisConnect() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "connectId": int.parse(connectId),
          "roleId": int.parse(roleId)
        };
        Response response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg);
              setState(() {
                isConnected = false;
                isAccepetd = false;
              });
            } else {
              ToastWrap.showToastLong(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForConnect() async {
    try {
      bool ageStatus = false;
      if (prefs.getString(UserPreference.DOB) != null &&
          prefs.getString(UserPreference.DOB) != 'null') {
        ageStatus = Util.currentAge(
                DateTime.fromMillisecondsSinceEpoch(
                    int.tryParse(prefs.getString(UserPreference.DOB))),
                13) <
            13;
      }
      Map map = {
        "userId": prefs.getString(UserPreference.USER_ID),
        "partnerId": int.parse(widget.userId),
        "userRoleId": int.parse(roleId),
        "partnerRoleId": 4,
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": ageStatus ? "Pending" : "Requested",
        "isActive": profileInfoModal.isActive
      };
      Response response = await ApiCalling().apiCallPostWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            // ToastWrap.showToast(msg);
            String connectId = response.data["result"]["connectId"].toString();
            this.connectId = connectId;
            setState(() {
              isConnected = true;
              isAccepetd = false;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForCheckSubscribe() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String uri;

        uri = Constant.ENDPOINT_CHECK_IS_SUBSCRIBE +
            prefs.getString(UserPreference.USER_ID) +
            "&partnerId=" +
            widget.userId +
            "&partnerRoleId=4&userRoleId=" +
            prefs.getString(UserPreference.ROLE_ID);
        ;

        print(uri);
        response = await ApiCalling2().apiCall(context, uri, "get");
        print(response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            var map = response.data['result'];
            if (map.length > 0) {
              String status = map[map.length - 1]['status'];
              subsCriberId = map[map.length - 1]['subscribeId'];
              if (status == "Un-Subscribe") {
                isSubscribe = false;
              } else {
                isSubscribe = true;
              }
              if (mounted) {
                setState(() {
                  isSubscribe;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForUnSubscribe() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "subscribeId": subsCriberId,
          "userId": prefs.getString(UserPreference.USER_ID),
          "followerId": widget.userId,
          "userRoleId": int.parse(roleId),
          "partnerRoleId": 2,
          "followerName": profileInfoModal.lastName == null ||
                  profileInfoModal.lastName == ""
              ? profileInfoModal.firstName
              : profileInfoModal.firstName + " " + profileInfoModal.lastName,
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "isActive": true,
          "status": "Un-Subscribe"
        };
        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_SUBSCRIBE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast("Un-Subscribe Successfully");
              if (mounted) {
                setState(() {
                  isSubscribe = false;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForSubscribe() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": prefs.getString(UserPreference.USER_ID),
          "followerId": widget.userId,
          "userRoleId": roleId,
          "partnerRoleId": 2,
          "followerName": profileInfoModal.lastName == null ||
                  profileInfoModal.lastName == ""
              ? profileInfoModal.firstName
              : profileInfoModal.firstName + " " + profileInfoModal.lastName,
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "isActive": true,
          "status": "Subscribe"
        };

        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_SUBSCRIBE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg);
              if (mounted) {
                setState(() {
                  isSubscribe = true;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
      child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  generateDropDownList() {
    return isSelectTap
        ? Padding(
      padding: EdgeInsets.only(top: 5, bottom: 8, left: 13, right: 13),
      child: ListView.builder(
          itemCount: isView
              ? reviewList.length
              : reviewList.length > 2
              ? 2
              : reviewList.length,
          physics: ScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (context, iteam) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
              child: isSelectTap
                  ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                // Align children to the left

                children: <Widget>[
                  Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10)),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        // Align children to the left

                        children: [
                          Expanded(
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: Container(
                                      width: 40.0,
                                      height: 40.0,
                                      child: ClipOval(
                                          child:
                                          CachedNetworkImage(
                                            width: 40.0,
                                            height: 40.0,
                                            imageUrl: Constant
                                                .IMAGE_PATH +
                                                reviewList[iteam]
                                                    .profilePicture,
                                            fit: BoxFit.cover,
                                            placeholder: (context,
                                                url) =>
                                                _loader(context,
                                                    "assets/profile/user_on_user.png"),
                                            errorWidget: (context,
                                                url, error) =>
                                                _error(
                                                    "assets/profile/user_on_user.png"),
                                          ))),
                                  flex: 0,
                                ),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: <Widget>[
                                      Row(children: <Widget>[
                                        Expanded(
                                          child: Padding(
                                            padding:
                                            const EdgeInsets
                                                .only(
                                                top: 0.0,
                                                left: 11),
                                            child: Text(
                                              reviewList[iteam]
                                                  .name,
                                              overflow:
                                              TextOverflow
                                                  .ellipsis,
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontFamily: Constant
                                                      .latoSemibold,
                                                  fontWeight:
                                                  FontWeight
                                                      .w700,
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1),
                                            ),
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: Padding(
                                            padding:
                                            const EdgeInsets
                                                .only(
                                                top: 0.0,
                                                right: 5.0),
                                            child: Text(
                                              Util.getConvertedDateStamp(
                                                  reviewList[
                                                  iteam]
                                                      .date
                                                      .toString())
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontFamily: Constant
                                                      .latoRegular,
                                                  color: ColorValues
                                                      .labelColor),
                                            ),
                                          ),
                                          flex: 0,
                                        )
                                      ]),
                                      Row(
                                        children: <Widget>[
                                          Padding(
                                            padding:
                                            const EdgeInsets
                                                .only(
                                                top: 0.0,
                                                left: 11),
                                            child: Text(
                                              '${reviewList[iteam].rating}',
                                              overflow:
                                              TextOverflow
                                                  .ellipsis,
                                              style: TextStyle(
                                                fontSize: 14,
                                                fontFamily: Constant
                                                    .latoSemibold,
                                                fontWeight:
                                                FontWeight
                                                    .w700,
                                                color: ColorValues
                                                    .labelColor,
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            child: Padding(
                                              padding:
                                              const EdgeInsets
                                                  .only(
                                                  top: 5.0,
                                                  left: 5),
                                              child:
                                              SmoothStarRating(
                                                rating:
                                                reviewList[
                                                iteam]
                                                    .rating,
                                                allowHalfRating:
                                                false,
                                                size: 20,
                                                color: Color(
                                                    0xffFEC901),
                                                filledIconData:
                                                Icons.star,
                                                borderColor: Color(
                                                    0xffFDEDEDE),
                                                defaultIconData:
                                                Icons.star,
                                                starCount: 5,
                                                spacing: 1.0,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                            flex: 0,
                          ),

                          reviewList[iteam].review != null &&
                              reviewList[iteam].review != ""
                              ? Padding(
                            padding: const EdgeInsets.only(
                                top: 10,
                                bottom: 10,
                                left: 0,
                                right: 0),
                            child: Container(
                              height: 1.0,
                              color: ColorValues
                                  .GREY__COLOR_DIVIDER,
                            ),
                          )
                              : Container(),

                          reviewList[iteam].review != null &&
                              reviewList[iteam].review != ""
                              ? Padding(
                            padding:
                            const EdgeInsets.fromLTRB(
                                0.0, 5.0, 0.0, 5.0),
                            child: Text(
                              reviewList[iteam].review,
                              style: TextStyle(
                                fontSize: 12,
                                fontFamily:
                                Constant.latoRegular,
                                color: Colors.black,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          )
                              : SizedBox(
                            height: 0,
                          )

                          // isView
                          //     ? reviewList.length - 1 != iteam
                          //     ? Padding(
                          //   padding: const EdgeInsets.all(8.0),
                          //   child: Container(
                          //     height: 1.0,
                          //     color: ColorValues
                          //         .GREY__COLOR_DIVIDER,
                          //   ),
                          // )
                          //     : Container()
                          //     : iteam == 0
                          //     ? Padding(
                          //   padding: const EdgeInsets.all(8.0),
                          //   child: Container(
                          //     height: 1.0,
                          //     color: ColorValues
                          //         .GREY__COLOR_DIVIDER,
                          //   ),
                          // )
                          //     : Container(),
                        ],
                      ),
                    ),
                  ),
                  reviewList.length > 2
                      ? InkWell(
                    onTap: () {
                      if (isView) {
                        isView = false;
                      } else {
                        isView = true;
                      }
                      setState(() {
                        isView;
                      });
                    },
                    child: !isView
                        ? iteam == 1
                        ? PaddingWrap.paddingfromLTRB(
                        5.0,
                        20.0,
                        5.0,
                        20.0,
                        Center(
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius:
                                BorderRadius
                                    .circular(
                                    10),
                                border: Border.all(
                                    color: ColorValues
                                        .BLUE_COLOR_BOTTOMBAR)),
                            height: 30.0,
                            width:
                            reviewList.length >
                                2
                                ? 90.0
                                : 90,
                            child: Padding(
                              padding:
                              const EdgeInsets
                                  .only(top: 5),
                              child: Text(
                                  "View all",
                                  textAlign:
                                  TextAlign
                                      .center,
                                  style: TextStyle(
                                      color: ColorValues
                                          .BLUE_COLOR_BOTTOMBAR,
                                      fontFamily:
                                      Constant
                                          .latoRegular,
                                      fontSize:
                                      14.0)),
                            ),
                          ),
                        ))
                        : Container()
                        : iteam == reviewList.length - 1
                        ? PaddingWrap.paddingfromLTRB(
                        5.0,
                        12.0,
                        5.0,
                        16.0,
                        Center(
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius:
                                BorderRadius
                                    .circular(
                                    10),
                                border: Border.all(
                                    color: ColorValues
                                        .BLUE_COLOR_BOTTOMBAR)),
                            height: 30.0,
                            width:
                            reviewList.length >
                                2
                                ? 90.0
                                : 90,
                            child: Padding(
                              padding:
                              const EdgeInsets
                                  .only(top: 5),
                              child: Text(
                                  "View less",
                                  textAlign:
                                  TextAlign
                                      .center,
                                  style: TextStyle(
                                      color: ColorValues
                                          .BLUE_COLOR_BOTTOMBAR,
                                      fontFamily:
                                      Constant
                                          .latoRegular,
                                      fontSize:
                                      14.0)),
                            ),
                          ),
                        ))
                        : Container(),
                  )
                      : Container(
                    height: 0.0,
                  )
                ],
              )
                  : Container(
                height: 0.0,
              ),
            );
          }),
    )
        : Container(
      height: 10.0,
    );
  }

  InkWell isImageSelectedView() {
    return InkWell(
      child: Container(
        width: 65.0,
        height: 65.0,
        child: Stack(
          children: <Widget>[
            Center(
              child: Stack(
                children: [
                  Container(
                    width: 65.0,
                    height: 65.0,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: ColorValues.light_blue,
                          offset: Offset(0, 2),
                          blurRadius: 6,
                        ),
                      ],
                      border: Border.all(
                        color: ColorValues.light_blue,
                        width: 5,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: companyModel != null
                          ? CachedNetworkImage(
                        imageUrl: companyModel != null
                            ? Constant.IMAGE_PATH_SMALL +
                            ParseJson.getMediumImage(
                                companyModel.profilePicture)
                            : "",
                        fit: BoxFit.cover,
                        placeholder: (context, url) => _loader(
                            context, "assets/profile/partner_img.png"),
                        errorWidget: (context, url, error) =>
                            _error("assets/profile/partner_img.png"),
                      )
                          : Image.asset("assets/profile/partner_img.png"),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      onTap: () {
        // onTapEditProfile();
      },
    );
  }

  int getLenthOfName() {
    int lenght = 0;
    if (companyModel == null) {
      return 0;
    } else {
      lenght = companyModel.name.length;
    }

    return lenght;
  }

  Padding getUiButtonsIfStudentLoggedIn() {
    return PaddingWrap.paddingfromLTRB(
        20.0,
        24.0,
        20.0,
        0.0,
        Container(
            decoration: BoxDecoration(
              color: Color(0xffFBFBFB),
              borderRadius: BorderRadius.circular(10),
            ),
            child: isParentApprovalPending
                ? Padding(
              padding: const EdgeInsets.all(15.0),
              child: Center(
                  child: BaseText(
                    text: isSentRequest
                        ? connectionModel.userId ==
                        prefs.getString(UserPreference.PARENT_ID)
                        ? "Your parent approval pending"
                        : "Pending from parent"
                        : connectionModel.partnerId ==
                        prefs.getString(UserPreference.PARENT_ID)
                        ? "Your parent approval pending"
                        : "Pending from parent",
                    textColor: Color(0xff4684EB),
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    maxLines: 1,
                  )),
            )
                : Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        isConnected
                            ? isAccepetd
                            ? InkWell(
                          child: Column(
                            children: <Widget>[
                              Image.asset(
                                "assets/newDesignIcon/userprofile/right.png",
                                width: 18.0,
                                height: 18.0,
                              ),
                              SizedBox(height: 1,),
                              BaseText(
                                text: "Connected",
                                textColor: AppConstants
                                    .colorStyle.lightBlue,
                                fontFamily: AppConstants
                                    .stringConstant
                                    .latoRegular,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                maxLines: 1,
                              )
                            ],
                          ),
                          onTap: () {
                            //removeConnectionConformationDialog();
                          },
                        )
                            : InkWell(
                          child: Column(
                            children: <Widget>[
                              Image.asset(
                                "assets/newIcon/cancle_blue.png",
                                width: 22.0,
                                height: 22.0,
                              ),
                              SizedBox(height: 1,),
                              BaseText(
                                text: "Cancel request",
                                textColor: AppConstants
                                    .colorStyle.lightGreyShade,
                                fontFamily: AppConstants
                                    .stringConstant
                                    .latoRegular,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                maxLines: 1,
                              )
                            ],
                          ),
                          onTap: () {
                            apiCallDisConnect();
                          },
                        )
                            : InkWell(
                          child: Column(
                            children: <Widget>[
                              Image.asset(
                                "assets/newDesignIcon/userprofile/connect.png",
                                width: 22.0,
                                height: 22.0,
                              ),
                              SizedBox(height: 1,),
                              BaseText(
                                text: "Connect",
                                textColor: AppConstants
                                    .colorStyle.lightGreyShade,
                                fontFamily: AppConstants
                                    .stringConstant.latoRegular,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                maxLines: 1,
                              )
                            ],
                          ),
                          onTap: () {
                            if (isConnection_AccessControl) {
                              apiCallForConnect();
                            } else {
                              ToastWrap.showToastForAccessDenied(
                                  MessageConstant
                                      .FEATURE_DIABLED,
                                  context);
                            }
                          },
                        )
                      ],
                    ),
                    flex: 1,
                  ),
                  isSubscribe || isAccepetd
                      ? Expanded(
                    child: InkWell(
                      child: Column(
                        mainAxisAlignment:
                        MainAxisAlignment.center,
                        crossAxisAlignment:
                        CrossAxisAlignment.center,
                        children: <Widget>[
                          Image.asset(
                            "assets/newDesignIcon/userprofile/subscribe_blue.png",
                            width: 20.0,
                            height: 20.0,
                          ),
                          SizedBox(height: 1,),
                          BaseText(
                            text: "Following",
                            textColor:
                            AppConstants.colorStyle.lightBlue,
                            fontFamily: AppConstants
                                .stringConstant.latoRegular,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            maxLines: 1,
                          )
                        ],
                      ),
                      onTap: () {
                        apiCallForUnSubscribe();
                      },
                    ),
                    flex: 1,
                  )
                      : Expanded(
                    child: InkWell(
                      child: Column(
                        mainAxisAlignment:
                        MainAxisAlignment.center,
                        crossAxisAlignment:
                        CrossAxisAlignment.center,
                        children: <Widget>[
                          Image.asset(
                            "assets/newDesignIcon/userprofile/subscribe.png",
                            width: 20.0,
                            height: 20.0,
                          ),
                          SizedBox(height: 1,),
                          BaseText(
                            text: "Follow",
                            textColor: AppConstants
                                .colorStyle.lightGreyShade,
                            fontFamily: AppConstants
                                .stringConstant.latoRegular,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            maxLines: 1,
                          )
                        ],
                      ),
                      onTap: () {
                        apiCallForSubscribe();
                      },
                    ),
                    flex: 1,
                  ),
                  isConnected && isAccepetd
                      ? Expanded(
                    child: InkWell(
                      child: Column(
                        mainAxisAlignment:
                        MainAxisAlignment.center,
                        crossAxisAlignment:
                        CrossAxisAlignment.center,
                        children: <Widget>[
                          Image.asset(
                            "assets/newDesignIcon/userprofile/msg.png",
                            width: 22.0,
                            height: 22.0,
                          ),
                          SizedBox(height: 1,),
                          BaseText(
                            text: "Chat",
                            textColor: AppConstants
                                .colorStyle.lightGreyShade,
                            fontFamily: AppConstants
                                .stringConstant.latoRegular,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            maxLines: 1,
                          )
                        ],
                      ),
                      onTap: () {
                        String userIdNew = prefs
                            .getString(UserPreference.PARENT_ID);

                        Friends model = Friends(
                            connectId: int.parse(
                                connectionModel.connectId),
                            userId: int.parse(prefs.getString(
                                UserPreference.PARENT_ID)),
                            firstName: profileInfoModal.firstName,
                            lastName: profileInfoModal.lastName,
                            profilePicture:
                            profileInfoModal.profilePicture,
                            partnerId: int.parse(
                                connectionModel.partnerId == userIdNew
                                    ? connectionModel.userId
                                    : connectionModel.partnerId),
                            partnerFirstName:
                            profileInfoModal.firstName,
                            partnerLastName:
                            profileInfoModal.lastName,
                            partnerRoleId: 4,
                            partnerProfilePicture:
                            profileInfoModal.profilePicture,
                            dateTime: DateTime.now()
                                .millisecondsSinceEpoch,
                            creationTime: profileInfoModal.creationTime !=
                                null &&
                                profileInfoModal.creationTime !=
                                    "null" &&
                                profileInfoModal.creationTime != ""
                                ? int.parse(profileInfoModal.creationTime)
                                : 0,
                            isActive: true,
                            online: connectionModel.online == null || connectionModel.online == "null" ? 0 : connectionModel.online,
                            lastMessage: "",
                            unreadMessages: 0,
                            lastTime: 0,
                            lastSeen: connectionModel.lastSeen == null || connectionModel.lastSeen == "null" ? 0 : connectionModel.lastSeen,
                            textSentBy: int.parse(prefs.getString(UserPreference.USER_ID)));

                        if (isChat_AccessControl) {
                          Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder: (BuildContext
                                  context) =>
                                      ChatRoomWidget(
                                          model, "", "")));
                        } else {
                          ToastWrap.showToastForAccessDenied(
                              MessageConstant.FEATURE_DIABLED,
                              context);
                        }
                      },
                    ),
                    flex: 1,
                  )
                      : Expanded(
                    child: Container(
                      height: 0.0,
                      width: 0.0,
                    ),
                    flex: 0,
                  ),
                ],
              ),
            )));
  }

  badgeList2() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(13, 10, 13, 0),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: List.generate(
                  badgeList.length > 2
                      ? isViewAllBadges
                      ? badgeList.length
                      : 2
                      : badgeList.length, (int index) {
                return Padding(
                  padding: const EdgeInsets.only(top: 5,bottom: 5),
                  child: Row(
                    children: <Widget>[
                      Container(
                        height: 78,
                        width: 76,
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: ColorValues.BORDER_GENERATE_SCRIPT),
                          borderRadius:
                          BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(3.0),
                            // Set the border radius here
                            child: FadeInImage.assetNetwork(
                              fit: BoxFit.contain,
                              placeholder:
                              'assets/profile/user_on_user.png',
                              image: Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getMediumImage(
                                      badgeList[index].image),
                              height: 64.0,
                              width: 54.0,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        flex: 1,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Text(
                              badgeList[index].name.toString(),
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                fontFamily: Constant.latoRegular,
                                color:
                                ColorValues.HEADING_COLOR_EDUCATION_1,
                              ),
                            ),
                            InkWell(
                              child: Padding(
                                padding: const EdgeInsets.only(top: 5),
                                child: Text("REQUEST ",
                                    style: TextStyle(
                                      color: ColorValues
                                          .BOTTOAMBAR_ADD_BG_COLOUR,
                                      fontSize: 12,
                                      fontFamily: Constant.latoSemibold,
                                    )),
                              ),
                              onTap: () {
                                Navigator.of(context).push(
                                    MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            BadgesRequestForm(userIdPref,
                                                badgeList[index].badgeId)));
                              },
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                );
              },
              ),
          ),
        ),
        badgeList.length > 2
            ? Padding(
          padding: const EdgeInsets.fromLTRB(0, 12, 0, 12),
              child: Column(
          mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    height: 1.0,
                    color: ColorValues.BORDER_COLOR,
                  ),
                  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        6.0,
                        6.0,
                        6.0,
                        0.0,
                        isViewAllBadges
                            ? Text(
                          "View Less ",
                          style: TextStyle(
                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                              fontSize: 14.0,
                              fontFamily:
                              Constant.TYPE_CUSTOMREGULAR),
                        )
                            : Text(
                          "View All ",
                          style: TextStyle(
                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                              fontSize: 14.0,
                              fontFamily:
                              Constant.TYPE_CUSTOMREGULAR),
                        )),
                    onTap: () {
                      setState(() {
                        if (isViewAllBadges) {
                          isViewAllBadges = false;
                        } else {
                          isViewAllBadges = true;
                        }
                      });
                    },
                  )
                ],
              ),
            )
            : const SizedBox.shrink(),
      ],
    );
  }

  Widget headerUiDesign() {
    return Container(
      height: 100.0,
      color: Colors.white,
      //ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
      child: Stack(
        children: <Widget>[
          Positioned(
              bottom: 10.0,
              left: 0.0,
              right: 0.0,
              child: Column(
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                      20.0,
                      24.0,
                      20.0,
                      0.0,
                      Container(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0, 10.0, 13.0, 10.0, isImageSelectedView()),
                                flex: 0,
                              ),
                              Expanded(
                                child: PaddingWrap.paddingfromLTRB(
                                    5.0,
                                    0.0,
                                    0.0,
                                    8.0,
                                    Container(
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: <Widget>[
                                            PaddingWrap.paddingAll(
                                              2.0,
                                              TextViewWrap.textViewMultiLine(
                                                  companyModel == null
                                                      ? ""
                                                      : companyModel.name,
                                                  TextAlign.start,
                                                  ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  getLenthOfName() > 24 ? 22.0 : 24.0,
                                                  FontWeight.normal,
                                                  2),
                                            ),
                                          ],
                                        ))),
                                flex: 1,
                              )
                            ],
                          ))),
                ],
              )),
        ],
      ),
    );
  }

  Future<String> getVideoThumbnail(context, imagePath) async {
    return await UploadMedia(context).getVideoThumbnailFromUrl(imagePath);
  }

  Future apiCallRating() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        SharedPreferences prefs = await SharedPreferences.getInstance();
        Map map = {
          "userId": prefs.getString(UserPreference.USER_ID),
          "receiverId": widget.userId,
          "rating": rating,
          "review": descriptionController.text
        };
        print("map++++" + map.toString());
        response = await   ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_REVIEW_API, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data["status"];
            String msg = response.data["message"];
            if (status == "Success") {
              isSelected=false;
              reviewApi();
            } else {}
          }
        }
      }
    } catch (e) {}
  }

  Widget getOportunityActive() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color: ColorValues.SELECTION_BG,
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              height: 50,
              decoration: BoxDecoration(
                  color: ColorValues.LIST_BOTTOM_BG,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 0.0, left: 10),
                      child: Text(
                        "Active opportunity",
                        style: TextStyle(
                            fontSize: 18,
                            fontFamily: Constant.latoSemibold,
                            color: ColorValues.HEADING_COLOR_EDUCATION_1),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            activeOpportunityList.length == 0
                ? PaddingWrap.paddingfromLTRB(
                17.0,
                10.0,
                5.0,
                10.0,
                TextViewWrap.textViewSingleLine(
                    "No active opportunities available",
                    TextAlign.start,
                    ColorValues.HEADING_COLOR_EDUCATION,
                    16.0,
                    FontWeight.normal))
                : Padding(
              padding: const EdgeInsets.fromLTRB(13, 14, 13, 0),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(
                      activeOpportunityList.length > 2
                          ? isShowAllActiveOpportunity
                          ? activeOpportunityList.length
                          : 2
                          : activeOpportunityList.length, (int index) {
                    return Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            11.0,
                            //
                            activeOpportunityList[index]
                                .assestVideoAndImage
                                .length >
                                0
                                ? SizedBox(
                              // Pager view
                                height: 215.50,
                                child: PageIndicatorContainer(
                                  pageView: PageView.builder(
                                    itemCount:
                                    activeOpportunityList[
                                    index]
                                        .assestVideoAndImage
                                        .length,
                                    controller:
                                    PageController(),
                                    itemBuilder:
                                        (context, index2) {
                                      return InkWell(
                                        child: Stack(
                                            children: <
                                                Widget>[
                                              activeOpportunityList[index]
                                                  .assestVideoAndImage[
                                              index2]
                                                  .type ==
                                                  "image"
                                                  ? Container(
                                                  decoration: BoxDecoration(
                                                      color: Colors
                                                          .black,
                                                      borderRadius: BorderRadius.circular(
                                                          10)),
                                                  child:
                                                  CachedNetworkImage(
                                                    width:
                                                    double.infinity,
                                                    height:
                                                    215.50,
                                                    imageUrl:
                                                    Constant.IMAGE_PATH + activeOpportunityList[index].assestVideoAndImage[index2].file,
                                                    fit: BoxFit
                                                        .contain,
                                                    placeholder: (context, url) => _loader(
                                                        context,
                                                        "assets/profile/user_on_user.png"),
                                                    errorWidget: (context, url, error) =>
                                                        _error("assets/profile/user_on_user.png"),
                                                  ))
                                                  : Container(
                                                decoration: BoxDecoration(
                                                    color:
                                                    Colors.black,
                                                    borderRadius: BorderRadius.circular(10)),
                                                height:
                                                215.50,
                                                child:
                                                Center(
                                                  child: VideoPlayPause(
                                                      activeOpportunityList[index].assestVideoAndImage[index2].file,
                                                      "",
                                                      true),
                                                ),
                                              ),
                                              activeOpportunityList[index]
                                                  .assestVideoAndImage
                                                  .length ==
                                                  1
                                                  ? Container(
                                                height:
                                                0.0,
                                              )
                                                  : Container(
                                                decoration: BoxDecoration(
                                                    color:
                                                    Colors.black,
                                                    borderRadius: BorderRadius.circular(10)),
                                                height:
                                                215.50,
                                                width: double
                                                    .infinity,
                                                child: Image
                                                    .asset(
                                                  "assets/newDesignIcon/navigation/layer_image.png",
                                                  fit: BoxFit
                                                      .fill,
                                                ),
                                              )
                                            ]),
                                        onTap: () {},
                                      );
                                    },
                                    onPageChanged: (index) {},
                                  ),
                                  align:
                                  IndicatorAlign.bottom,
                                  length:
                                  activeOpportunityList[
                                  index]
                                      .assestVideoAndImage
                                      .length,
                                  indicatorSpace: 10.0,
                                  indicatorColor:
                                  activeOpportunityList[
                                  index]
                                      .assestVideoAndImage
                                      .length ==
                                      1
                                      ? Colors.transparent
                                      : Color(0xffc4c4c4),
                                  indicatorSelectorColor:
                                  activeOpportunityList[
                                  index]
                                      .assestVideoAndImage
                                      .length ==
                                      1
                                      ? Colors.transparent
                                      : ColorValues.WHITE,
                                  shape:
                                  IndicatorShape.circle(
                                      size: 5.0),
                                ))
                                : Stack(children: <Widget>[
                              Image.asset(
                                "assets/profile/default_achievement.png",
                                fit: BoxFit.cover,
                                height: 215.50,
                                width: double.infinity,
                              ),
                              Container(
                                height: 215.50,
                                decoration: BoxDecoration(
                                    color: Colors.black,
                                    borderRadius:
                                    BorderRadius
                                        .circular(10)),
                              )
                            ])),
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                activeOpportunityList[
                                index]
                                    .offerId ==
                                    "4" ||
                                    activeOpportunityList[
                                    index]
                                        .offerId ==
                                        "5"
                                    ? activeOpportunityList[
                                index]
                                    .serviceTitle
                                    : activeOpportunityList[
                                index]
                                    .jobTitle,
                                overflow:
                                TextOverflow.ellipsis,
                                textAlign:
                                TextAlign.start,
                                style: TextStyle(
                                    color: ColorValues
                                        .HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16.0,
                                    fontWeight:
                                    FontWeight.w600,
                                    fontFamily: Constant
                                        .latoRegular),
                              ),
                              flex: 1,
                            ),
                          ],
                        ),
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            5.0,
                            Text(
                              activeOpportunityList[
                              index]
                                  .offerId ==
                                  "1" ||
                                  activeOpportunityList[
                                  index]
                                      .offerId ==
                                      "2" ||
                                  activeOpportunityList[
                                  index]
                                      .offerId ==
                                      "3"
                                  ? activeOpportunityList[
                              index]
                                  .project
                                  : activeOpportunityList[
                              index]
                                  .offerId ==
                                  "4" ||
                                  activeOpportunityList[
                                  index]
                                      .offerId ==
                                      "5"
                                  ? activeOpportunityList[
                              index]
                                  .serviceDesc
                                  : "${activeOpportunityList[index].description}",
                              maxLines: 3,
                              overflow:
                              TextOverflow.ellipsis,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  color: ColorValues
                                      .HEADING_COLOR_EDUCATION_1,
                                  fontSize: 12.0,
                                  fontWeight:
                                  FontWeight.w500,
                                  fontFamily: Constant
                                      .latoRegular),
                            )),
                        activeOpportunityList[index]
                            .offerId ==
                            "6" ||
                            activeOpportunityList[
                            index]
                                .offerId ==
                                "7" ||
                            activeOpportunityList[
                            index]
                                .offerId ==
                                "8"
                            ? Column(
                          mainAxisAlignment:
                          MainAxisAlignment
                              .start,
                          crossAxisAlignment:
                          CrossAxisAlignment
                              .start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                PaddingWrap
                                    .paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    Text(
                                      "Scheduled For:  ",
                                      textAlign:
                                      TextAlign
                                          .left,
                                      maxLines:
                                      null,
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontWeight: FontWeight
                                              .bold,
                                          fontSize:
                                          14.0),
                                    )),
                              ],
                            ),
                            getScheduleWidget(
                                activeOpportunityList[
                                index]),
                          ],
                        )
                            : Column(
                          crossAxisAlignment:
                          CrossAxisAlignment
                              .start,
                          children: <Widget>[
                            PaddingWrap
                                .paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                5.0,
                                Text(
                                  "Scheduled For: ",
                                  textAlign:
                                  TextAlign
                                      .left,
                                  maxLines:
                                  null,
                                  style: TextStyle(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontFamily:
                                      Constant
                                          .latoRegular,
                                      fontWeight:
                                      FontWeight
                                          .bold,
                                      fontSize:
                                      14.0),
                                )),
                            PaddingWrap
                                .paddingfromLTRB(
                                0.0,
                                5.0,
                                0.0,
                                9.0,
                                Text(
                                  getConvertedDateStamp2(
                                      activeOpportunityList[index]
                                          .fromDate) +
                                      " - " +
                                      getConvertedDateStamp2(
                                          activeOpportunityList[index]
                                              .toDate),
                                  textAlign:
                                  TextAlign
                                      .left,
                                  maxLines:
                                  null,
                                  style: TextStyle(
                                      color: ColorValues
                                          .labelColor,
                                      fontFamily:
                                      Constant
                                          .latoRegular,
                                      fontWeight:
                                      FontWeight
                                          .w500,
                                      fontSize:
                                      12.0),
                                )),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0, 12, 0, 12),
                          child: Container(
                              height: 1.0,
                              color: ColorValues.BORDER_COLOR),
                        )
                      ],
                    );
                  },),
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                activeOpportunityList.length > 2
                    ? InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      6.0,
                      4.0,
                      6.0,
                      16.0,
                      isShowAllActiveOpportunity
                          ? Text(
                        "View Less",
                        style: TextStyle(
                            color:
                            ColorValues.BLUE_COLOR_BOTTOMBAR,
                            fontSize: 14.0,
                            fontFamily:
                            Constant.TYPE_CUSTOMREGULAR),
                      )
                          : Text(
                        "View All " +
                            activeOpportunityList.length
                                .toString() +
                            " Active Opportunities",
                        style: TextStyle(
                            color:
                            ColorValues.BLUE_COLOR_BOTTOMBAR,
                            fontSize: 14.0,
                            fontFamily:
                            Constant.TYPE_CUSTOMREGULAR),
                      )),
                  onTap: () {
                    setState(() {
                      if (isShowAllActiveOpportunity)
                        isShowAllActiveOpportunity = false;
                      else
                        isShowAllActiveOpportunity = true;
                    });
                  },
                )
                    :const SizedBox.shrink(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget getOportunityInActive() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color: ColorValues.SELECTION_BG,
            // border: Border.all(
            //     color: ColorValues
            //         .BORDER_COLOR,
            //     width: 0.5)
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              height: 50,
              decoration: BoxDecoration(
                  color: ColorValues.LIST_BOTTOM_BG,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 0.0, left: 10),
                      child: Text(
                        "Expired Opportunities",
                        style: TextStyle(
                            fontSize: 18,
                            fontFamily: Constant.latoSemibold,
                            color: ColorValues.HEADING_COLOR_EDUCATION_1),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            expireOpportunityList.length == 0
                ? PaddingWrap.paddingfromLTRB(
                17.0,
                10.0,
                5.0,
                10.0,
                TextViewWrap.textViewSingleLine(
                    "No expired opportunities",
                    TextAlign.start,
                    ColorValues.HEADING_COLOR_EDUCATION,
                    16.0,
                    FontWeight.normal))
                : Padding(
              padding: const EdgeInsets.fromLTRB(13,14,13,0),
                  child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(
                      expireOpportunityList.length > 2
                          ? isShowAllExpireOpportunity
                          ? expireOpportunityList.length
                          : 2
                          : expireOpportunityList.length, (int index) {
                    return Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          10.0,
                          //
                          expireOpportunityList[index]
                              .assestVideoAndImage
                              .length >
                              0
                              ? SizedBox(
                            // Pager view
                              height: 215.50,
                              child:
                              PageIndicatorContainer(
                                pageView:
                                PageView.builder(
                                  itemCount:
                                  expireOpportunityList[
                                  index]
                                      .assestVideoAndImage
                                      .length,
                                  controller:
                                  PageController(),
                                  itemBuilder: (context,
                                      index2) {
                                    Future<String>
                                    thumbnailFile;
                                    if (expireOpportunityList[
                                    index]
                                        .assestVideoAndImage[
                                    index2]
                                        .type ==
                                        "video") {
                                      thumbnailFile = getVideoThumbnail(
                                          context,
                                          expireOpportunityList[
                                          index]
                                              .assestVideoAndImage[
                                          index2]
                                              .file);
                                      print(
                                          'view thumbnailFile:: ${thumbnailFile}');
                                    }

                                    return Stack(
                                      children: <
                                          Widget>[
                                        expireOpportunityList[index]
                                            .assestVideoAndImage[
                                        index2]
                                            .type ==
                                            "image"
                                            ? Container(
                                            decoration: BoxDecoration(
                                                color: Colors
                                                    .black,
                                                borderRadius: BorderRadius.circular(
                                                    10)),
                                            child:
                                            CachedNetworkImage(
                                              width:
                                              double.infinity,
                                              height:
                                              215.50,
                                              imageUrl:
                                              Constant.IMAGE_PATH + expireOpportunityList[index].assestVideoAndImage[index2].file,
                                              fit: BoxFit
                                                  .contain,
                                              placeholder: (context, url) => _loader(
                                                  context,
                                                  "assets/aerial/default_img.png"),
                                              errorWidget: (context, url, error) =>
                                                  _error("assets/aerial/default_img.png"),
                                            ))
                                            : InkWell(
                                            child:
                                            Container(
                                              decoration:
                                              BoxDecoration(
                                                color:
                                                Colors.black,
                                                borderRadius:
                                                BorderRadius.circular(10),
                                              ),
                                              height:
                                              215.50,
                                              child:
                                              Center(
                                                child: VideoPlayPause(
                                                    expireOpportunityList[index].assestVideoAndImage[index2].file,
                                                    "",
                                                    true),
                                              ),
                                            )),
                                        expireOpportunityList[index].assestVideoAndImage.length ==
                                            1 ||
                                            expireOpportunityList[index].assestVideoAndImage[index2].type ==
                                                "video"
                                            ? Container(
                                          height:
                                          0.0,
                                        )
                                            : Container(
                                          height:
                                          215.50,
                                          width: double
                                              .infinity,
                                          child: Image
                                              .asset(
                                            "assets/newDesignIcon/navigation/layer_image.png",
                                            fit: BoxFit
                                                .fill,
                                          ),
                                        )
                                      ],
                                    );
                                  },
                                  onPageChanged:
                                      (index) {},
                                ),
                                align: IndicatorAlign
                                    .bottom,
                                length: expireOpportunityList[
                                index]
                                    .assestVideoAndImage
                                    .length,
                                indicatorSpace: 10.0,
                                indicatorColor:
                                expireOpportunityList[
                                index]
                                    .assestVideoAndImage
                                    .length ==
                                    1
                                    ? Colors
                                    .transparent
                                    : Color(
                                    0xffc4c4c4),
                                indicatorSelectorColor:
                                expireOpportunityList[
                                index]
                                    .assestVideoAndImage
                                    .length ==
                                    1
                                    ? Colors
                                    .transparent
                                    : ColorValues
                                    .WHITE,
                                shape: IndicatorShape
                                    .circle(size: 5.0),
                              ))
                              : Stack(children: <Widget>[
                            Image.asset(
                              "assets/profile/default_achievement.png",
                              fit: BoxFit.cover,
                              height: 215.50,
                              width: double.infinity,
                            ),
                            Container(
                              height: 215.50,
                              color: Colors.black54
                                  .withOpacity(.4),
                            )
                          ],
                          ),
                        ),
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: Text(
                                expireOpportunityList[index]
                                    .offerId ==
                                    "1" ||
                                    expireOpportunityList[
                                    index]
                                        .offerId ==
                                        "2" ||
                                    expireOpportunityList[
                                    index]
                                        .offerId ==
                                        "3"
                                    ? expireOpportunityList[
                                index]
                                    .jobTitle
                                    : expireOpportunityList[
                                index]
                                    .offerId ==
                                    "4" ||
                                    expireOpportunityList[
                                    index]
                                        .offerId ==
                                        "5"
                                    ? expireOpportunityList[
                                index]
                                    .serviceTitle
                                    : expireOpportunityList[
                                index]
                                    .jobTitle,
                                maxLines: 1,
                                overflow:
                                TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                style: TextStyle(
                                    color: ColorValues
                                        .HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16.0,
                                    fontWeight:
                                    FontWeight.w600,
                                    fontFamily:
                                    Constant.latoRegular),
                              ),
                              flex: 1,
                            ),
                          ],
                        ),
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            5.0,
                            Text(
                              expireOpportunityList[index]
                                  .offerId ==
                                  "1" ||
                                  expireOpportunityList[
                                  index]
                                      .offerId ==
                                      "2" ||
                                  expireOpportunityList[
                                  index]
                                      .offerId ==
                                      "3"
                                  ? expireOpportunityList[
                              index]
                                  .project
                                  : expireOpportunityList[
                              index]
                                  .offerId ==
                                  "4" ||
                                  expireOpportunityList[
                                  index]
                                      .offerId ==
                                      "5"
                                  ? expireOpportunityList[
                              index]
                                  .serviceDesc
                                  : "${expireOpportunityList[index].description}",
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                  color: ColorValues
                                      .HEADING_COLOR_EDUCATION_1,
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily:
                                  Constant.latoRegular),
                            )),
                        expireOpportunityList[index]
                            .offerId ==
                            "6" ||
                            expireOpportunityList[index]
                                .offerId ==
                                "7" ||
                            expireOpportunityList[index]
                                .offerId ==
                                "8"
                            ? Column(
                          mainAxisAlignment:
                          MainAxisAlignment.start,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                5.0,
                                0.0,
                                0.0,
                                Text(
                                  "Scheduled For: ",
                                  textAlign:
                                  TextAlign.left,
                                  maxLines: null,
                                  style: TextStyle(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION,
                                      //fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontWeight:
                                      FontWeight
                                          .bold,
                                      fontSize: 14.0),
                                )),
                            getScheduleWidget(
                                expireOpportunityList[
                                index]),
                          ],
                        )
                            : Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                5.0,
                                0.0,
                                5.0,
                                Text(
                                  'Scheduled For: ',
                                  style: TextStyle(
                                      fontWeight:
                                      FontWeight
                                          .w600,
                                      fontFamily: Constant
                                          .latoRegular,
                                      fontSize: 14,
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1),
                                )),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                5.0,
                                0.0,
                                5.0,
                                Text(
                                  getConvertedDateStamp2(
                                      expireOpportunityList[
                                      index]
                                          .fromDate) +
                                      " - " +
                                      getConvertedDateStamp2(
                                          expireOpportunityList[
                                          index]
                                              .toDate),
                                  style: TextStyle(
                                      fontWeight:
                                      FontWeight
                                          .w500,
                                      fontFamily: Constant
                                          .latoRegular,
                                      fontSize: 12,
                                      color: ColorValues
                                          .labelColor),
                                )),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(
                              0.0, 12, 0.0, 12.0),
                          child: Container(
                              height: 1.0,
                              color: ColorValues.BORDER_COLOR),
                        )
                      ],
                    );
                  })),
                ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                expireOpportunityList.length > 2
                    ? InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      6.0,
                      6.0,
                      6.0,
                      12.0,
                      isShowAllExpireOpportunity
                          ? Text(
                        "View Less",
                        style: TextStyle(
                            color:
                            ColorValues.BLUE_COLOR_BOTTOMBAR,
                            fontSize: 14.0,
                            fontFamily:
                            Constant.TYPE_CUSTOMREGULAR),
                      )
                          : Text(
                        "View All " +
                            expireOpportunityList.length
                                .toString() +
                            " Expired Opportunities",
                        style: TextStyle(
                            color:
                            ColorValues.BLUE_COLOR_BOTTOMBAR,
                            fontSize: 14.0,
                            fontFamily:
                            Constant.TYPE_CUSTOMREGULAR),
                      )),
                  onTap: () {
                    setState(() {
                      if (isShowAllExpireOpportunity)
                        isShowAllExpireOpportunity = false;
                      else
                        isShowAllExpireOpportunity = true;
                    });
                  },
                )
                    : Container(
                  height: 0.0,
                  color: Colors.black,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  onTapReport() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            Report("profile", "", "", widget.userId, roleIdUser: "2")));
    if (result == "push") {
      Navigator.pop(context);
    }
  }

  void optionMenu() {
    final List<OptionMenu> list = [];
    list.add(OptionMenu(
        title: "About Us",
        onTap: () {
          Navigator.of(context).push(
              MaterialPageRoute(
                  builder: (BuildContext
                  context) =>
                      CompanyDetailPage(
                          companyModel)));
        }
    ));
    list.add(OptionMenu(
        title: "Report profile",
        onTap: () {
          onTapReport();
        }
    ));

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ListView.separated(
                  itemBuilder: (_, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        list[index].onTap();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: BaseText(
                          text: list[index].title,
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          textColor: const Color(0xff30322F),
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w500,
                          fontSize: 18,
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (_, index) =>
                      Divider(
                        height: 0,
                        thickness: 1,
                        color: const Color(0xffE8E8E8),
                      ),
                  itemCount: list.length,
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                ),
              ),
              const SizedBox(height: 10),
              InkWell(
                onTap: () => Navigator.pop(context),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.all(13),
                  child: BaseText(
                    text: 'Cancel',
                    maxLines: 1,
                    textAlign: TextAlign.center,
                    textColor: const Color(0xff4684EB),
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 18,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void onBack() {
    print('OnBack partner isDataLoading:: $isDataLoading');
    if (!isDataLoading) {
      if (widget.callingType == "redirect" ||
          widget.callingType == "view" ||
          widget.callingType == "pushNotification") {
        // For Partner DashBoard
        print(
            'inside Partner if 111 widget.pageRedirect:: ${widget.callingType}, roleID:: $roleId');
        if (roleId == "1") {
          // For Studenet
          Navigator.pushReplacement(
            //Constant.applicationContext,
              context,
              MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) => DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));
        } else if (roleId == "2") {
          Navigator.pushReplacement(
            //Constant.applicationContext,
              context,
              MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) => DashBoardWidgetParent(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));

          // For Parent
        } else if (roleId == "4") {
          Navigator.pushReplacement(
            //Constant.applicationContext,
              context,
              MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) => DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));

          // For Partner
        }
      } else {
        print(
            'inside Partner else 111 widget.pageRedirect:: ${widget.callingType}, roleID:: $roleId');
        Navigator.pop(context, isPerformChanges);
      }
    } else {
      print("Not partner perform");
    }
  }

  getView() {
    return Container(
      decoration: isTitleVisible
          ? BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            width: 1.0,
            color: ColorValues.DEVIDER_COLOR,
          ),
        ),
      )
          : const BoxDecoration(color: Colors.transparent),
      child: Container(
          child: Align(
              alignment: Alignment.bottomCenter,
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          20.0,
                          5.0,
                          5.0,
                          5.0,
                          Image.asset(
                            isTitleVisible
                                ? "assets/generateScript/back.png"
                                : "assets/generateScript/back.png",
                            height: 32.0,
                            width: 32.0,
                          )),
                      onTap: () {
                        onBack();
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Container(),
                    flex: 1,
                  ),
                  Expanded(
                    child: InkWell(
                      child: Container(
                          padding: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 0.0),
                          child: Image.asset(
                            "assets/png/more.png",
                            width: 32.0,
                            height: 32.0,
                          )),
                      onTap: () {
                        optionMenu();
                      },
                    ),
                    flex: 0,
                  )
                ],
              ))),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // Main View for return final Output
    this.context = context;
    return SafeArea(
      child: WillPopScope(
          child: Scaffold(
            backgroundColor: Colors.white,
            body: Stack(
              children: <Widget>[
                Positioned(
                    left: 0.0,
                    right: 0.0,
                    top: 0.0,
                    bottom: 0.0,
                    child: SingleChildScrollView(
                      controller: _scrollController,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                            height: 60,
                          ),

                          headerUiDesign(),

                          roleId == "4"
                              ? const SizedBox.shrink()
                              : prefs != null &&
                              profileInfoModal != null &&
                              Util.showAcceptButton(
                                  prefs,
                                  profileInfoModal
                                      .schoolCode,
                                  searchUserAccessConnection) ==
                                  "true"
                              ? getUiButtonsIfStudentLoggedIn()
                              : const SizedBox.shrink(),

                          (pendinForParentDataList.length > 0 ||
                              receivedRequestList.length > 0) &&
                              roleId == "2"
                              ? PaddingWrap.paddingfromLTRB(
                              20.0,
                              5.0,
                              20.0,
                              0.0,
                              Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                          color: ColorValues
                                              .BORDER_COLOR,
                                          width: 0.5)),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: <Widget>[
                                      receivedRequestList.length ==
                                          0
                                          ? Container(
                                        height: 0.0,
                                      )
                                          : Padding(
                                          padding: EdgeInsets
                                              .fromLTRB(
                                              0.0,
                                              0.0,
                                              0.0,
                                              0.0),
                                          child: Container(
                                            child: Row(
                                              children: <
                                                  Widget>[
                                                Expanded(
                                                  child:
                                                  Padding(
                                                      padding: EdgeInsets.fromLTRB(
                                                          13.0,
                                                          0.0,
                                                          0.0,
                                                          0.0),
                                                      child:
                                                      Text(
                                                        "APPROVE THIS CONNECTION REQUEST(S)",
                                                        style: TextStyle(
                                                            fontSize: 12.0,
                                                            color: ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontFamily: Constant.customRegular),
                                                      )),
                                                  flex: 1,
                                                ),
                                              ],
                                            ),
                                            color: ColorValues
                                                .GREY__COLOR_DIVIDER,
                                            height: 25.0,
                                          )),
                                      receivedRequestList.length ==
                                          0
                                          ? Container(
                                        height: 0.0,
                                      )
                                          : Padding(
                                          padding: EdgeInsets
                                              .fromLTRB(
                                              0.0,
                                              5.0,
                                              0.0,
                                              10.0),
                                          child: Column(
                                            children: List.generate(
                                                receivedRequestList
                                                    .length,
                                                    (int index) {
                                                  return getListviewForRecieveList(
                                                      receivedRequestList[
                                                      index],
                                                      index,
                                                      false,
                                                      "Requested");
                                                }),
                                          )),
                                      pendinForParentDataList
                                          .length ==
                                          0
                                          ? Container(
                                        height: 0.0,
                                      )
                                          : Padding(
                                          padding: EdgeInsets
                                              .fromLTRB(
                                              0.0,
                                              0.0,
                                              0.0,
                                              0.0),
                                          child: Container(
                                            child: Row(
                                              children: <
                                                  Widget>[
                                                Expanded(
                                                  child:
                                                  Padding(
                                                      padding: EdgeInsets.fromLTRB(
                                                          13.0,
                                                          0.0,
                                                          0.0,
                                                          0.0),
                                                      child:
                                                      Text(
                                                        "APPROVE THIS SENT REQUEST(S)",
                                                        style: TextStyle(
                                                            fontSize: 12.0,
                                                            color: ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontFamily: Constant.customRegular),
                                                      )),
                                                  flex: 1,
                                                ),
                                              ],
                                            ),
                                            color: ColorValues
                                                .GREY__COLOR_DIVIDER,
                                            height: 25.0,
                                          )),
                                      pendinForParentDataList
                                          .length ==
                                          0
                                          ? Container(
                                        height: 0.0,
                                      )
                                          : Padding(
                                          padding: EdgeInsets
                                              .fromLTRB(
                                              0.0,
                                              5.0,
                                              0.0,
                                              10.0),
                                          child: Column(
                                            children: List.generate(
                                                pendinForParentDataList
                                                    .length,
                                                    (int index) {
                                                  return getListviewForPending(
                                                      pendinForParentDataList[
                                                      index],
                                                      index,
                                                      roleId == "2"
                                                          ? false
                                                          : true,
                                                      "Requested");
                                                }),
                                          )),
                                    ],
                                  ),
                              ),
                          )
                              : const SizedBox.shrink(),

                          isRatingLodaing
                              ? const SizedBox.shrink()
                              : Container(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  20, 24,20, 0),
                              child: Container(
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                      color: ColorValues
                                          .SELECTION_BG,
                                      borderRadius:
                                      BorderRadius.circular(
                                          10)),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: <Widget>[
                                      //Rating View
                                      // myRating == null
                                      //     ? Container(
                                      //         height: 0.0,
                                      //       )
                                      //     :

                                      Padding(
                                          padding:
                                          const EdgeInsets
                                              .only(
                                              top: 0.0,
                                              left: 0),
                                          child: Column(
                                            children: <
                                                Widget>[
                                              Container(
                                                height: 50,
                                                decoration: BoxDecoration(
                                                    color: ColorValues
                                                        .LIST_BOTTOM_BG,
                                                    borderRadius: BorderRadius.only(
                                                        topLeft: Radius.circular(
                                                            10),
                                                        topRight:
                                                        Radius.circular(10))),
                                                child: Row(
                                                  children: <
                                                      Widget>[
                                                    Padding(
                                                      padding: const EdgeInsets.only(
                                                          left:
                                                          10,
                                                          right:
                                                          10),
                                                      child: Container(
                                                          height: 35,
                                                          width: 35,
                                                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10.5)),
                                                          child: Padding(
                                                            padding: const EdgeInsets.all(5.0),
                                                            child: Image.asset(
                                                              "assets/newDesignIcon/parentProfile/partnerRatingReview.png",
                                                              height: 15,
                                                              width: 15,
                                                            ),
                                                          )),
                                                    ),
                                                    Expanded(
                                                      child:
                                                      Padding(
                                                        padding: const EdgeInsets.only(
                                                            top: 0.0,
                                                            left: 10),
                                                        child:
                                                        Text(
                                                          "Ratings and Reviews",
                                                          style: TextStyle(
                                                              fontSize: 18,
                                                              fontFamily: Constant.latoSemibold,
                                                              color: ColorValues.HEADING_COLOR_EDUCATION_1),
                                                        ),
                                                      ),
                                                    ),
                                                    reviewList.length ==
                                                        0
                                                        ? const SizedBox.shrink()
                                                        : InkWell(
                                                            onTap: () {
                                                              if (isSelectTap) {
                                                                isSelectTap = false;
                                                              } else {
                                                                isSelectTap = true;
                                                              }
                                                              setState(() {});
                                                              print(isSelectTap);
                                                            },
                                                            child:Padding(
                                                              padding: const EdgeInsets.fromLTRB(8, 0, 12, 0),
                                                              child: Image.asset(
                                                                isSelectTap
                                                                    ?"assets/newDesignIcon/navigation/upArrow.png"
                                                                :"assets/newDesignIcon/navigation/downArrow.png",
                                                                height: 12,
                                                              ),
                                                            ),
                                                        ),
                                                  ],
                                                ),
                                              ),
                                              SizedBox(
                                                height: 10,
                                              ),

                                              /*
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[

                                                                    Padding(
                                                                        padding: const EdgeInsets
                                                                                .only(
                                                                            bottom:
                                                                                0.0,
                                                                            left:
                                                                                14.0),
                                                                        child:
                                                                            Row(
                                                                          children: <
                                                                              Widget>[
                                                                             Expanded(
                                                                              child:  Container(
                                                                                  width: 50.0,
                                                                                  height: 50.0,
                                                                                  child:  ClipOval(
                                                                                      child:  CachedNetworkImage(
                                                                                    width: 50.0,
                                                                                    height: 50.0,
                                                                                    imageUrl: Constant.IMAGE_PATH + myRating.profilePicture,
                                                                                    fit: BoxFit.cover,
                                                                                    placeholder: (context, url) => _loader(context, "assets/profile/user_on_user.png"),
                                                                                    errorWidget: (context, url, error) => _error("assets/profile/user_on_user.png"),
                                                                                  ))),
                                                                              flex:
                                                                                  0,
                                                                            ),
                                                                             Expanded(
                                                                              child:
                                                                                  Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                children: <Widget>[
                                                                                  Padding(
                                                                                    padding: const EdgeInsets.only(top: 0.0, left: 11),
                                                                                    child: Text(
                                                                                      myRating.name,
                                                                                      overflow: TextOverflow.ellipsis,
                                                                                      style: TextStyle(fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD, fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ),
                                                                                   Row(
                                                                                    children: <Widget>[
                                                                                       Expanded(
                                                                                        child: Padding(
                                                                                          padding: const EdgeInsets.only(top: 5.0, left: 11),
                                                                                          child: SmoothStarRating(
                                                                                            rating: myRating.rating,
                                                                                            allowHalfRating: false,
                                                                                            size: 20,
                                                                                            color: Color(0xffFEC901),
                                                                                            filledIconData: Icons.star,
                                                                                            borderColor: Color(0xffFDEDEDE),
                                                                                            defaultIconData: Icons.star,
                                                                                            starCount: 5,
                                                                                            spacing: 1.0,
                                                                                          ),
                                                                                        ),
                                                                                        flex: 1,
                                                                                      ),
                                                                                       Expanded(
                                                                                        child: Padding(
                                                                                          padding: const EdgeInsets.only(top: 5.0, right: 14.0),
                                                                                          child: Text(
                                                                                            Util.getConvertedDateStamp(myRating.date.toString()).toString(),
                                                                                            style: TextStyle(fontSize: 12, fontFamily: Constant.TYPE_CUSTOMREGULAR, color: ColorValues.GREY_TEXT_COLOR),
                                                                                          ),
                                                                                        ),
                                                                                        flex: 0,
                                                                                      )
                                                                                    ],
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              flex:
                                                                                  1,
                                                                            ),
                                                                          ],
                                                                        )),


                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              10.0,
                                                                          left:
                                                                              18.0,
                                                                          right:
                                                                              14.0,
                                                                          bottom:
                                                                              10.0),

                                                                      child: Text(
                                                                        myRating
                                                                            .review,
                                                                        style:
                                                                            TextStyle(
                                                                          fontSize:
                                                                              16,
                                                                          fontFamily:
                                                                              Constant.TYPE_CUSTOMBOLD,
                                                                        ),
                                                                      ),
                                                                    ),

                                                                    CustomViews
                                                                        .getSepratorLine()
                                                                  ],
                                                                )

                                                                 */
                                            ],
                                          )
                                      ),


                                      Padding(
                                        padding:
                                        const EdgeInsets.only(
                                            top: 5.0,
                                            left: 15, right: 15),
                                        child: Text(
                                          "Encourage your customers to provide reviews. It will help build your brand and customer interest. ",
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontWeight:
                                              FontWeight.w400,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                      ),

                                      Row(
                                        children: <Widget>[
                                          Padding(
                                            padding:
                                            const EdgeInsets
                                                .only(
                                                top: 15.0,
                                                left: 15),
                                            child: Text(
                                              reviewList.length ==
                                                  0
                                                  ? "0.0"
                                                  : (ratingCalculation /
                                                  reviewList
                                                      .length)
                                                  .toStringAsFixed(
                                                  1)
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 47,
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontWeight:
                                                  FontWeight
                                                      .w800,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .start,
                                            children: <Widget>[
                                              Padding(
                                                padding:
                                                const EdgeInsets
                                                    .only(
                                                    top: 13.0,
                                                    left: 20),
                                                child: Center(
                                                    child:
                                                    SmoothStarRating(
                                                      rating: reviewList
                                                          .length ==
                                                          0
                                                          ? 0
                                                          : ratingCalculation /
                                                          reviewList
                                                              .length,
                                                      allowHalfRating:
                                                      false,
                                                      size: 20,
                                                      color: Color(
                                                          0xffFEC901),
                                                      filledIconData:
                                                      Icons.star,
                                                      borderColor: Color(
                                                          0xffFDEDEDE),
                                                      defaultIconData:
                                                      Icons.star,
                                                      starCount: 5,
                                                      spacing: 1.0,
                                                    )),
                                              ),
                                              const SizedBox(height: 5,),
                                              Padding(
                                                padding:
                                                const EdgeInsets
                                                    .only(
                                                    left: 25),
                                                child: Text(
                                                  "Based on " +
                                                      reviewList
                                                          .length
                                                          .toString() +
                                                      " reviews",
                                                  style:
                                                  TextStyle(
                                                    fontSize: 12,
                                                    fontFamily:
                                                    Constant
                                                        .latoRegular,
                                                    color: ColorValues
                                                        .labelColor,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),

                                      generateDropDownList(),

                                      // Container(
                                      //   height: 1.0,
                                      //   color: ColorValues.GREY__COLOR_DIVIDER,
                                      // ),

                                      //Ratting null view

                                      myRating != null
                                          ? Container(
                                        height: 0.0,
                                      )
                                          : InkWell(
                                        onTap: () {
                                          if(isSelected){
                                            isSelected=false;
                                          }else{
                                            isSelected=true;
                                          }

                                          setState(() {

                                          });
                                          //   onTapRating();
                                        },
                                        child: Padding(
                                          padding:
                                          const EdgeInsets
                                              .only(
                                              left: 15,
                                              top: 10.0,
                                              bottom:
                                              15.0),
                                          child: Row(
                                            children: [
                                              Text(
                                                "Rate our service",
                                                style: TextStyle(
                                                    fontSize:
                                                    14,
                                                    fontFamily:
                                                    Constant
                                                        .latoRegular,
                                                    fontWeight: FontWeight.w600,
                                                    color: Color(
                                                        0xff4684EB)),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(left:14.0,top: 3),
                                                child: Image.asset(
                                                    isSelected
                                                        ? "assets/newDesignIcon/competency/up_arrow.png"
                                                        : "assets/newDesignIcon/competency/down_arrow.png",
                                                    height: 15.0,
                                                    width: 15.0,
                                                    color:AppConstants.colorStyle.lightPurple
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                      isSelected?
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start
                                        ,mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding:
                                            const EdgeInsets.only(
                                                top: 10.0,
                                                left: 15),
                                            child: SmoothStarRating(
                                              rating: ratingSelected,
                                              allowHalfRating: true,
                                              size: 25,
                                              color:
                                              Color(0xffFEC901),
                                              filledIconData:
                                              Icons.star,
                                              borderColor:
                                              Color(0xffFDEDEDE),
                                              defaultIconData:
                                              Icons.star,
                                              starCount: 5,
                                              spacing: 10.0,
                                              onRatingChanged:
                                                  (value) {
                                                setState(() {
                                                  ratingSelected =
                                                      value;
                                                  print(
                                                      ratingSelected);
                                                });
                                              },
                                            ),
                                          ),

                                          Container(
                                            height: 100,
                                            child: Padding(
                                                padding:
                                                const EdgeInsets
                                                    .only(
                                                    left: 15.0,
                                                    right: 15.0,
                                                    top: 24.0),
                                                child: Stack(
                                                  children: [
                                                    CustomFormField(
                                                      autovalidateMode:
                                                      AutovalidateMode
                                                          .disabled,
                                                      textInputType:
                                                      TextInputType
                                                          .text,
                                                      onType:
                                                          (val) {},
                                                      controller:
                                                      descriptionController,
                                                      onSaved: (val) =>
                                                      description =
                                                          val,
                                                      maxLength:
                                                      TextLength
                                                          .GROUP_NAME_MAX_LENGTH,
                                                      label:
                                                      "Describe your experience",
                                                    ),
                                                    ratingSelected > 0
                                                        ? SizedBox(
                                                      height: 0,
                                                    )
                                                        : Container(
                                                      height:
                                                      60.0,
                                                      width: double
                                                          .infinity,
                                                      color: ColorValues
                                                          .SELECTION_BG
                                                          .withOpacity(
                                                          0.75),
                                                    )
                                                  ],
                                                )),
                                          ),
                                          Container(
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Container(),
                                                  flex: 1,
                                                ),
                                                Expanded(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                    20.0,
                                                    10.0,
                                                    20.0,
                                                    20.0,
                                                    Container(
                                                      height: 29,
                                                      child: InkWell(
                                                        child: Container(
                                                            height: 29,
                                                            width: 60,
                                                            decoration: BoxDecoration(
                                                              color: ratingSelected >
                                                                  0
                                                                  ? AppConstants.colorStyle.lightBlue
                                                                  : AppConstants.colorStyle.lightBlue.withOpacity(0.75),
                                                              border: Border.all(
                                                                  color: ratingSelected > 0
                                                                      ? AppConstants.colorStyle.lightBlue
                                                                      : AppConstants.colorStyle.lightBlue.withOpacity(0.75)),
                                                              borderRadius:
                                                              BorderRadius.circular(10),
                                                            ),
                                                            child: Center(
                                                              child:
                                                              Text(
                                                                "Post",
                                                                textAlign:
                                                                TextAlign.center,
                                                                style:
                                                                TextStyle(
                                                                  fontWeight:
                                                                  FontWeight.w600,
                                                                  color: ratingSelected > 0
                                                                      ? ColorValues.WHITE
                                                                      : ColorValues.WHITE.withOpacity(.75),
                                                                  fontFamily:
                                                                  AppConstants.stringConstant.latoMedium,
                                                                  fontSize:
                                                                  14.0,
                                                                ),
                                                              ),
                                                            )),
                                                        onTap:
                                                            () async {
                                                          if (ratingSelected >
                                                              0) {
                                                            apiCallRating();
                                                          }
                                                        },
                                                      ),
                                                    ),
                                                  ),
                                                  flex: 0,
                                                ),
                                              ],
                                            ),
                                          )
                                        ],):SizedBox(),


                                    ],
                                  )),
                            ),
                          ),

                          //Active opportunity
                          isLoading
                              ? const SizedBox.shrink()
                              : Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            children: <Widget>[
                              activeOpportunityList.length == 0
                                  ? Container(height: 0.0)
                                  : Padding(
                                padding:
                                const EdgeInsets.fromLTRB(20, 24, 20, 0),
                                child: BaseText(
                                  text: 'Opportunities',
                                  textColor: AppConstants
                                      .colorStyle.darkBlue,
                                  fontFamily: AppConstants
                                      .stringConstant
                                      .latoRegular,
                                  fontSize: 18,
                                  textAlign:
                                  TextAlign.start,
                                  fontWeight:
                                  FontWeight.w600,
                                  maxLines: 1,
                                ),
                              ),

                              activeOpportunityList.length == 0
                                  ? const SizedBox.shrink()
                                  : getOportunityActive(),

                              //Badges
                              roleId == "1"
                                  ? Padding(
                                padding:
                                const EdgeInsets.fromLTRB(20, 24, 20, 0),
                                child: Container(
                                  decoration: BoxDecoration(
                                      color: ColorValues
                                          .SELECTION_BG,
                                      borderRadius:
                                      BorderRadius
                                          .circular(
                                          10)),
                                  child: Column(
                                    mainAxisAlignment:
                                    MainAxisAlignment
                                        .start,
                                    crossAxisAlignment:
                                    CrossAxisAlignment
                                        .start,
                                    children: <Widget>[
                                      Container(
                                        height: 50,
                                        decoration: BoxDecoration(
                                            color: ColorValues
                                                .LIST_BOTTOM_BG,
                                            borderRadius: BorderRadius.only(
                                                topLeft: Radius
                                                    .circular(
                                                    10),
                                                topRight: Radius
                                                    .circular(
                                                    10))),
                                        child: Row(
                                          children: <
                                              Widget>[
                                            Padding(
                                              padding: const EdgeInsets
                                                  .only(
                                                  left: 10,
                                                  right:
                                                  10),
                                              child: Container(
                                                  height: 35,
                                                  width: 35,
                                                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10.5)),
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets.all(5.0),
                                                    child: Image
                                                        .asset(
                                                      'assets/badges/new_badge.png',
                                                      height:
                                                      15,
                                                      width:
                                                      15,
                                                    ),
                                                  )),
                                            ),
                                            Expanded(
                                              child:
                                              Padding(
                                                padding: const EdgeInsets
                                                    .only(
                                                    top:
                                                    0.0,
                                                    left:
                                                    10),
                                                child: Text(
                                                  "Badges",
                                                  style: TextStyle(
                                                      fontSize:
                                                      18,
                                                      fontFamily: Constant
                                                          .latoSemibold,
                                                      color:
                                                      ColorValues.HEADING_COLOR_EDUCATION_1),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      badgeList2(),
                                    ],
                                  ),
                                ),
                              )
                                  : const SizedBox.shrink(),

                              //Expired opportunity
                              expireOpportunityList.length == 0
                                  ? const SizedBox.shrink()
                                  : getOportunityInActive()
                            ],
                          )
                        ],
                      ),
                    )),
                Positioned(
                    left: 0.0,
                    right: 0.0,
                    top: 0.0,
                    child: AnimatedContainer(
                      height: _isAppbar ? 55.0 : 0.0,
                      duration: Duration(milliseconds: 200),
                      child: getView(),
                    )),
              ],
            ),
          ),
          onWillPop: () {
            onBack();
            return Future.value(false);
          }),
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  getHoursData(index, OpportunityModel opportunity) {
    return RichText(
      textAlign: TextAlign.start,
      maxLines: null,
      text: TextSpan(
        text: opportunity.scheduleModelParam[index].day +
            ": " +
            getHours(index, opportunity),
        style: AppTextStyle.getDynamicFont(
            ColorValues.HEADING_COLOR_EDUCATION, 14, FontType.Regular),
        children: <TextSpan>[
          TextSpan(
            text: opportunity.timeZone == null ||
                    opportunity.timeZone == "" ||
                    opportunity.timeZone == "null"
                ? ""
                : "(" + opportunity.timeZone + ")",
            style: TextStyle(
                color: ColorValues.GREY__COLOR,
                fontSize: 14.0,
                fontWeight: FontWeight.normal,
                fontFamily: Constant.customRegular),
          )
        ],
      ),
    );
  }

  Widget getScheduleWidget(OpportunityModel opportunity) {
    print(
        'opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: List.generate(opportunity.scheduleModelParam.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
          child: getHoursData(index, opportunity),
        );
      }),
    );
  }

  String getHours(index, OpportunityModel opportunity) {
    String timeReturn = "";
    try {
      for (HoursData hours in opportunity.scheduleModelParam[index].hours) {
        timeReturn = Util.getConvertedTimeForScheduleDate(hours.timeFrom) +
            " - " +
            Util.getConvertedTimeForScheduleDate(
                hours.timeTo == null ? hours.timeFrom : hours.timeTo) +
            " | " +
            timeReturn;
      }

      return timeReturn.substring(0, timeReturn.lastIndexOf("|"));
    } catch (e) {
      return timeReturn;
    }
  }

  String getConvertedTime(int time) {
    String timeReturn = "";
    print('getConvertedTime time:: $time');
    if (time != null) {
      int startTimeHour = DateTime.fromMillisecondsSinceEpoch(time).hour;
      int startTimeMinute = DateTime.fromMillisecondsSinceEpoch(time).minute;

      if (startTimeHour > 12) {
        return timeReturn = (startTimeHour - 12).toString() +
            ":" +
            startTimeMinute.toString() +
            "PM";
      } else {
        return timeReturn =
            startTimeHour.toString() + ":" + startTimeMinute.toString() + "AM";
      }
    }
    return timeReturn;
  }
}
