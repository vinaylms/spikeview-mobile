class SubjectsModel {
  String status;
  List<SubjectsModelResult> result;

  SubjectsModel({this.status, this.result});

  SubjectsModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<SubjectsModelResult>();
      json['result'].forEach((v) {
        result.add(new SubjectsModelResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SubjectsModelResult {
  int subjectId;
  String name;
  String description;

  SubjectsModelResult({this.subjectId, this.name, this.description});

  SubjectsModelResult.fromJson(Map<String, dynamic> json) {
    subjectId = json['subjectId'];
    name = json['name'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['subjectId'] = this.subjectId;
    data['name'] = this.name;
    data['description'] = this.description;
    return data;
  }
}
