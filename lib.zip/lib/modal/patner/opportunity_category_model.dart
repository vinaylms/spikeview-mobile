class OpportunityCategoriesModel {
  String status;
  List<OpportunityCategoriesResult> result;

  OpportunityCategoriesModel({this.status, this.result});

  OpportunityCategoriesModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<OpportunityCategoriesResult>();
      json['result'].forEach((v) {
        result.add(new OpportunityCategoriesResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class OpportunityCategoriesResult {
  int oppCategoryId;
  String name;
  String image;
  String description;

  OpportunityCategoriesResult({this.oppCategoryId, this.name, this.image, this.description});

  OpportunityCategoriesResult.fromJson(Map<String, dynamic> json) {
    oppCategoryId = json['oppCategoryId'];
    name = json['name'];
    image = json['image'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['oppCategoryId'] = this.oppCategoryId;
    data['name'] = this.name;
    data['image'] = this.image;
    data['description'] = this.description;
    return data;
  }
}
