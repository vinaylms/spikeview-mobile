class TimeBetween {
  String fromTime;
  String toTime;

  TimeBetween({this.toTime, this.fromTime});


  static Map<String, dynamic> toMap(TimeBetween ageBetween) {
    Map<String, dynamic> assetMap = Map();
    assetMap['from'] = ageBetween.fromTime;
    assetMap['to'] = ageBetween.toTime;

    return assetMap;
  }

  static List<Map<String, dynamic>> mapList(List<TimeBetween> agegroup) {
    List<Map<String, dynamic>> listOfOffer = agegroup
        .map((offer) => {
      "from": offer.fromTime,
      "to": offer.toTime,
    })
        .toList();
    return listOfOffer;
  }

  TimeBetween.fromJson(Map<String, dynamic> json) {
    toTime = json['to'];
    fromTime = json['from'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['to'] = this.toTime;
    data['from'] = this.fromTime;
    return data;
  }

  Map<String, dynamic> toJson2() => {
    'to': toTime,
    'from': fromTime,

  };
}
