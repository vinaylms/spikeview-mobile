import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/gateway/company/company_info_view_New.dart';
import 'package:spike_view_project/modal/patner/user_signup_model.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class StaticPage extends StatefulWidget {
  bool isRedirectToRecommendation,isValid;
  String pageName,signupType, firstName = "", lastName = "", email = "",image="";

  StaticPage(this.isRedirectToRecommendation, this.pageName, this.signupType,
      {this.firstName, this.lastName, this.email, this.image,this.isValid});

  @override
  _StaticPageState createState() => _StaticPageState();
}

class _StaticPageState extends State<StaticPage> {
  SharedPreferences prefs;
  var userid;
  UserModel personalInfo = UserModel();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    setState(() {
      userid = prefs.getString(UserPreference.USER_ID);
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getSharedPreferences();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
          automaticallyImplyLeading: false,
          elevation: 0.0,
          brightness: Brightness.light,
          backgroundColor: Colors.white,
          title: Align(
              alignment: Alignment.center,
              child:  Image.asset(
                "assets/newDesignIcon/navigation/spike_logo_login.png",
                height: 30.0,
              ))),
      body:new Column(children: <Widget>[
         Expanded(child:   SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 13, right: 13, top: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  MessageConstant.SETUP,
                  style: TextStyle(fontSize: 18),
                ),
                Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.only(top: 20.46),
                    child: Image.asset(
                      "assets/svgimages/idea.png",
                      height: 263.54,
                    )),

                Padding(
                  padding: const EdgeInsets.fromLTRB(
                      0.0, 15.0, 0.0, 0.0),
                  child: TextViewWrap.textView(
                      "You are signing up as a partner",
                      TextAlign.start,
                       ColorValues.HEADING_COLOR_EDUCATION,
                      16.0,
                      FontWeight.normal),
                ),
                widget.signupType == "apple" ||
                    widget.signupType == "google"
                    ? Padding(
                    padding: const EdgeInsets.fromLTRB(
                        0.0, 15.0, 0.0, 10.0),
                    child:  Row(
                      children: <Widget>[
                         Expanded(
                          child:  InkWell(
                            child:  Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius:
                                BorderRadius
                                    .circular(
                                    100),
                                child:widget.image!=""?  CachedNetworkImage(
                                  height: 50.0,
                                  width: 50.0,
                                  imageUrl: widget.image,
                                  fit: BoxFit.cover,
                                  placeholder:(context, url) =>  Image
                                      .asset(
                                      'assets/profile/user_on_user.png'),
                                  errorWidget:(context, url, error) =>  Image
                                      .asset(
                                      'assets/profile/user_on_user.png'),
                                ):new Image
                                    .asset(
                                    'assets/profile/user_on_user.png'),
                              ),
                            ),
                            onTap: () {},
                          ),
                          flex: 0,
                        ),
                         Expanded(
                          child: PaddingWrap
                              .paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                               Column(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .start,
                                children: <Widget>[
                                  widget.firstName ==
                                      ""
                                      ?  Container(
                                      height:
                                      0.0)
                                      : TextViewWrap.textView(
                                      widget.firstName+" "+widget.lastName,
                                      TextAlign
                                          .start,
                                       ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight
                                          .bold),
                                  TextViewWrap.textView(
                                      widget.email,
                                      TextAlign
                                          .start,
                                       Color(
                                          0xff9a9c9c),
                                      14.0,
                                      FontWeight
                                          .normal),
                                ],
                              )),
                          flex: 1,
                        ),
                         Expanded(
                          child:widget.signupType=="google"?   InkWell(
                            child: TextViewWrap
                                .textView(
                                "Not You?",
                                TextAlign
                                    .start,
                                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                                14.0,
                                FontWeight
                                    .normal),
                            onTap: () {
                              Navigator.pop(context,"notYou");
                            },
                          ):new Container(height: 0.0,),
                          flex: 0,
                        ),
                      ],
                    ))
                    :  Container(height: 0.0),

                Container(
                  margin: EdgeInsets.only(top: 15.98),
                  child: Text(
                    "It's Easy",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
                Points(
                  textString: MessageConstant.BRIEF_ABOUT_YOU,
                ),
                Points(
                  textString: MessageConstant.HOME_PAGE,
                ),
                Points(
                  textString: MessageConstant.CREATE_OPPORTUNITY,
                ),
                Points(
                  textString: MessageConstant.TARGET_AUDIENCE,
                ),
                Points(
                  textString: MessageConstant.BUSINESS_OBJECTIVES,
                ),
                SizedBox(
                  height: 15.38,
                )
              ],
            ),
          ),
        ),flex: 1,),
         Expanded(child: Container(
          margin: EdgeInsets.only(top: 10, bottom: 10),
          child: Row(
            mainAxisAlignment:
            MainAxisAlignment.spaceBetween,
            children: [
               Expanded(
                child: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                        13.0, 0, 0, 0),
                    child: Image.asset(
                      "assets/svgimages/prefixicon.png",
                      width: 30.0,
                      height: 30.0,
                    ),
                  ),
                ),
                flex: 0,
              ),
               Expanded(
                child: Row(
                  children: <Widget>[
                     Text("Already have an account?",
                        style:  TextStyle(
                            color:  ColorValues.GREY__COLOR,
                            fontSize: 14.0,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                    SizedBox(
                      width: 6,
                    ),
                     InkWell(
                      child:  Text("Sign in",
                          style:  TextStyle(
                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                              fontSize: 14.0,
                              fontWeight: FontWeight.bold,
                              fontFamily: Constant.TYPE_CUSTOMBOLD)),
                      onTap: () {

                        print('APurva Static widget.pageName:: ${widget.pageName}');
                        if (widget.pageName ==
                            "Login") {

                          Navigator.of(context).pop('SignIn');
                        } else {

                          Navigator.of(context).pop('SignIn');
                        }
                      },
                    )
                  ],
                ),
                flex: 0,
              ),
               Expanded(
                child: GestureDetector(
                  onTap: () async {
                    String result = await Navigator.of(context).push(new MaterialPageRoute(
                        builder: (BuildContext context) => Center(
                          child:  CompanyInfoNew(
                            isRedirectToRecommendation:
                            widget.isRedirectToRecommendation,
                            pageName: widget.pageName,
                            userId: userid,
                            personalInfoObject: personalInfo,
                            signupType: widget. signupType,
                            firstName: widget.firstName,
                            lastName: widget.lastName,
                            email: widget.email,isValid:widget.isValid
                          ),
                        )));
                    print('onTapContinueButton() static result:: $result');
                    if(result != null){
                      Navigator.of(context).pop('SignIn');
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                        0.0, 0, 13, 0),
                    child: Image.asset(
                      "assets/svgimages/suffixicon.png",
                      width: 30.0,
                      height: 30.0,
                    ),
                  ),
                ),
                flex: 0,
              ),
            ],
          ),
        ),flex: 0,)
      ],)
    );
  }
}

class Points extends StatelessWidget {
  Points({this.textString});

  final textString;

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return Container(
      margin: EdgeInsets.only(top: 15, left: 13, right: 19),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
           Expanded(
            child: Padding(
      padding: const EdgeInsets.only(top:7.0),
      child:   SizedBox(
      height:
        17.0,
        width:
        20.0,
        child:Padding(
          padding: const EdgeInsets.all(2.0),
          child: Image.asset("assets/svgimages/done.png",height:
          17.0,
            width:
            20.0,),
        ) )),
            flex: 0,
          ),
           Expanded(
            child: SizedBox(
              width: 12,
            ),
            flex: 0,
          ),
           Expanded(
            child: Container(
              child: Text(
                textString,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 16, color:  ColorValues.HEADING_COLOR_EDUCATION,fontWeight: FontWeight.w400),
              ),
            ),
            flex: 1,
          ),
        ],
      ),
    );
  }
}
