import 'dart:io';

class AchievementImportanceModal {
  String importanceId,title,description;

  AchievementImportanceModal(this.importanceId, this.title, this.description);

}

