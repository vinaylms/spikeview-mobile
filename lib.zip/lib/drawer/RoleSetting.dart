import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/gateway/ChangePassword.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parentProfile/EditParentProfile.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/Company_Edit_Widget.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/story/PartnerStory.dart';
import 'package:spike_view_project/story/parent_storey.dart';
import 'package:spike_view_project/story/profile_story.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class RoleSetting extends StatefulWidget {
  String userIdPref, role;
  String isUserRole, isParentRole, isPartnerRole;

  RoleSetting(this.userIdPref, this.role, this.isUserRole, this.isParentRole,
      this.isPartnerRole);

  @override
  RoleSettingState createState() =>  RoleSettingState();
}

class RoleSettingState extends State<RoleSetting> {
  String isPerformChanges = "pop", userIdPref, dob = "0", isHide = "";
  int diffrenceInDob;
  SharedPreferences prefs;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    dob = prefs.getString(UserPreference.DOB);
    int millis = int.tryParse(dob);


    DateTime now =  DateTime.fromMillisecondsSinceEpoch(millis);
    diffrenceInDob = Util.currentAge(now, 13);
    setState(() {
      userIdPref;
      dob;
      isHide;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    bool dobCheck(String time) {
      if (time != "null") {
        int millis = int.tryParse(time);
        DateTime now =  DateTime.fromMillisecondsSinceEpoch(millis);
        diffrenceInDob =  DateTime.now().year - now.year;
        if (diffrenceInDob < 13)
          return false;
        else
          return true;
      } else {
        return true;
      }
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child:  Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading: IconButton(
                icon: Image.asset("assets/newDesignIcon/icon/back_icon.png",
                    height: 32.0, width: 32.0, fit: BoxFit.fill),
                onPressed: () {
                  Navigator.pop(context, isPerformChanges);
                }),
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
          backgroundColor: ColorValues.WHITE,
          body:  Container(
              color: Colors.white,
              child:  Column(
            children: <Widget>[
              Container(
                alignment: Alignment.topLeft,
                padding: EdgeInsets.only(bottom: 10),
                color: AppConstants.colorStyle.white,
                child: PaddingWrap.paddingfromLTRB(
                    20.0,
                    5.0,
                    20.0,
                    5.0,
                    BaseText(
                      text: 'Manage roles',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily:
                      AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      textAlign: TextAlign.start,
                      maxLines: 1,
                    )),
              ),
              Expanded(
                flex: 1,
                child: ListView(
                  children: <Widget>[
                    widget.isUserRole == "true"
                        ?  Container(
                            height: 0.0,
                          )
                        :  Container(
                      margin: EdgeInsets.only(top: 20,left: 20,right: 20),
                      decoration: BoxDecoration(
                        color: ColorValues.SELECTION_BG,
                        border: Border.all(
                          color: ColorValues.SELECTION_BG,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                          child: InkWell(
                            child: Stack(
                              children: <Widget>[
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 14, top: 14, right: 14,bottom: 14),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[
                                        Text("Get Student Access",
                                            style: TextStyle(
                                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: Constant.latoMedium)),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                            "Create your spikeview student account and get started on organizing your experiences, discovering  opportunities and building an active network of teammates, advisors, coaches etc.",
                                            style: TextStyle(
                                                color: ColorValues.TEXT_HEADER,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w400,
                                                fontFamily: Constant.latoRegular)),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: InkWell(
                                      child: Padding(
                                          padding: const EdgeInsets.only(top: 14, right: 14),
                                          child: Image.asset(
                                            "assets/newDesignIcon/icon/arrow_left.png",
                                            height: 18.0,
                                          ))),
                                )
                              ],
                            ),
                            onTap: () async {
                              DbHelper().deleteTable();
                              Navigator.of(context).push(
                                   MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                           ProfileStory()));
                            },
                          ),
                        ),

                    widget.isParentRole == "true"
                        ?  Container(
                            height: 0.0,
                          )
                        : Util.currentAge(new DateTime.fromMillisecondsSinceEpoch(int.tryParse(dob)), 18) >= 18
                            ?  Container(
                      margin: EdgeInsets.only(top: 20,left: 20,right: 20),
                      decoration: BoxDecoration(
                        color: ColorValues.SELECTION_BG,
                        border: Border.all(
                          color: ColorValues.SELECTION_BG,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                              child: InkWell(
                                child: Stack(
                                  children: <Widget>[
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 14, top: 14, right: 14,bottom: 14),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: <Widget>[
                                            Text("Get Parental Access",
                                                style: TextStyle(
                                                    color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily: Constant.latoMedium)),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                                "Want your child to have safe place to organize their experiences, build an active network and find opportunities that align to their interests? Setup an account and lets get started!",
                                                style: TextStyle(
                                                    color: ColorValues.TEXT_HEADER,
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: Constant.latoRegular)),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: InkWell(
                                          child: Padding(
                                              padding: const EdgeInsets.only(top: 14, right: 14),
                                              child: Image.asset(
                                                "assets/newDesignIcon/icon/arrow_left.png",
                                                height: 18.0,
                                              ))),
                                    )
                                  ],
                                ),
                                onTap: () async {
                                  DbHelper().deleteTable();
                                  Navigator.of(context).push(
                                       MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                               ParentStory()));
                                },
                              ),
                            )
                            :  Container(
                                height: 0.0,
                              ),

                    widget.isPartnerRole == "true"
                        ?  Container(
                            height: 0.0,
                          )
                        : Util.currentAge(new DateTime.fromMillisecondsSinceEpoch(int.tryParse(dob)), 15) >= 15
                            ?  Container(
                      margin: EdgeInsets.only(top: 20,left: 20,right: 20),
                      decoration: BoxDecoration(
                        color: ColorValues.SELECTION_BG,
                        border: Border.all(
                          color: ColorValues.SELECTION_BG,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                              child: InkWell(
                                child: Stack(
                                  children: <Widget>[
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 14, top: 14, right: 14,bottom: 14),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: <Widget>[
                                            Text("Become a Partner",
                                                style: TextStyle(
                                                  color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily: Constant.latoMedium)),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                                "Do you have service you would like to offer our community of students? Its easy! Setup an account, create the opportunity you want to offer and set a target audience you want to reach and let the customer come to you!",
                                                style: TextStyle(
                                                    color: ColorValues.TEXT_HEADER,
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: Constant.latoRegular)),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: InkWell(
                                          child: Padding(
                                              padding: const EdgeInsets.only(top: 14, right: 14),
                                              child: Image.asset(
                                                "assets/newDesignIcon/icon/arrow_left.png",
                                                height: 18.0,
                                              ))),
                                    ),
                                  ],
                                ),
                                onTap: () async {
                                  DbHelper().deleteTable();
                                  Navigator.of(context).push(
                                       MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                               PartnerStory(
                                                userIdPref,
                                              )));
                                },
                              ),
                            )
                            :  Container(
                                height: 0.0,
                              ),
                  ],
                ),
              )
            ],
          )),
        ));
  }
}
