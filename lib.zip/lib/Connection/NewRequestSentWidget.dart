import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

import '../main.dart';

class NewRequestWidget extends StatefulWidget {
  @override
  State<NewRequestWidget> createState() => _NewRequestWidgetState();
}

class _NewRequestWidgetState extends State<NewRequestWidget>
    with AutomaticKeepAliveClientMixin {
  BuildContext context;
  ScrollController _scrollController = ScrollController();
  TextEditingController edtController = TextEditingController();
  List<RequestedTagModel> sendRequestList = List();
  List<RequestedTagModel> searchtagList = List();
  String userIdPref, roleId, userProfilePath, searchName = "";
  int skip = 0;
  int searchCount = 0;
  int listType;
  String statusIndex;
  bool isNeedToRefresh = false;
  bool isLoading = true;
  List<RequestedTagModel> tagList = List();
  StreamSubscription<dynamic> _streamSubscription;
  SharedPreferences prefs;

  @override
  void initState() {
    _streamSubscription =
        SplashScreenState.syncDoneController.stream.listen((value) {
      if (Constant.CONNECTIONS_PROFILE == value) {
        skip = 0;
        isLoading = true;
        setState(() {});
        apiToGetDetail();
      }
    });

    getSharedPreferences();
    super.initState();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        skip = skip + 1;
        apiToGetDetail();
      }
    });
  }

  Future apiToGetDetail() async {
    searchCount = 0;
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        listType = 1;
        if (searchName.isEmpty) {
          searchtagList.clear();
        } else {
          if (searchCount == 0) {
            searchtagList.clear();
            searchCount = 1;
          }
        }
        print(Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
            userIdPref +
            "&status=" +
            statusIndex.toString() +
            "&roleId=" +
            roleId +
            "&skip=" +
            skip.toString());

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
                userIdPref +
                "&status=" +
                statusIndex.toString() +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString() +
                "&name=" +
                searchName +
                "&limit=" +
                "10",
            "get");
        isLoading = false;
        setState(() {});
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              List<RequestedTagModel> sendRequestListLocal = List();
              sendRequestListLocal = ParseJson.parseRequestedTagList(
                  response.data['result']); //['sentRequest']
              if (searchName.isEmpty) {
                for (int i = 0; i < sendRequestList.length; i++) {
                  for (int j = 0; j < sendRequestListLocal.length; j++) {
                    if (sendRequestList[i].patner.userId ==
                        sendRequestListLocal[j].patner.userId) {
                      sendRequestListLocal.removeAt(j);
                    }
                  }
                }
              } else {
                for (int i = 0; i < searchtagList.length; i++) {
                  for (int j = 0; j < sendRequestListLocal.length; j++) {
                    if (searchtagList[i].patner.userId ==
                        sendRequestListLocal[j].patner.userId) {
                      sendRequestListLocal.removeAt(j);
                    }
                  }
                }
              }
              if (searchName.isEmpty) {
                sendRequestList.addAll(sendRequestListLocal);
                searchtagList.addAll(sendRequestList);
                print("SSS 111 ${searchtagList.length}");
              } else {
                searchtagList.addAll(sendRequestListLocal);
                print("SSS 222 ${searchtagList.length}");
              }

              setState(() {});
              if (tagList != null) {
                if (tagList.length > 0) {
                  prefs.setString(
                      UserPreference.ISACTIVE, tagList[0].userIsActive);
                }

                setState(() {});
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {});
    }
  }

  int diffrenceInDob = 14;
  String dob;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    try {
      dob = prefs.getString(UserPreference.DOB);
      int millis = int.tryParse(dob);
      DateTime dobDate = DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(dobDate, 13);
      setState(() {});
    } catch (e) {}
    statusIndex = Constant.SENT_REQUEST;
    isLoading = true;
    skip = 0;
    setState(() {});
    apiToGetDetail();
  }

  Timer _timer;

  void _onSearch() {
    if (edtController.text.trim().isNotEmpty) {
      if (_timer?.isActive ?? false) {
        _timer?.cancel();
      }
      _timer = Timer(Duration(seconds: 1), () {
        skip = 0;
        isLoading = true;
        setState(() {});
        apiToGetDetail();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    return sendRequestList.length > 0
        ? Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 10.0),
              child: SizedBox(
                height: 40,
                child: TextField(
                  textAlign: TextAlign.left,
                  controller: edtController,
                  onChanged: (value) {
                    searchName = value;
                    _onSearch();
                  },
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: ColorValues.TAB_BACKGROUND_COLOR,
                    hintText: "Search connections",
                    hintStyle: TextStyle(
                        fontSize: 14,
                        fontFamily: Constant.latoRegular,
                        color: ColorValues.hintColor),
                    contentPadding:
                        EdgeInsets.fromLTRB(15.0, 10.0, 20.0, 10.0),
                    suffixIcon: IconButton(
                      onPressed: () {},
                      icon: Image.asset(
                        "assets/newDesignIcon/connections/new_search.png",
                        height: 20,
                        width: 20,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                      borderSide:
                          BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                      borderSide:
                          BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                    ),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10.0),
                        ),
                        borderSide: new BorderSide(
                            color: ColorValues.BORDER_COLOR_NEW)),
                  ),
                ),
              ),
            ),
            Expanded(
              child: searchtagList.length > 0
                  ? ListView.builder(
                      controller: _scrollController,
                      itemCount: searchtagList.length,
                      padding: EdgeInsets.only(bottom: 10),
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            getListview(
                                searchtagList[index], index, true, ""),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20),
                              child: const Divider(
                                thickness: 1,
                                height: 0,
                                color: Color(0xffE5EBF0),
                              ),
                            ),
                          ],
                        );
                      },
                    )
                  : isLoading
                      ? const SizedBox.shrink()
                      : Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Image.asset(
                                "assets/newDesignIcon/icon/no_user_found.png",
                                height: 111.0,
                              ),
                              const SizedBox(height: 10),
                              BaseText(
                                text: 'No user found',
                                textColor: ColorValues.HEADING_COLOR_CHAT_1,
                                fontFamily:
                                AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w600,
                                fontSize: 18,
                                textAlign: TextAlign.center,
                                maxLines: 1,
                              ),
                            ],
                          )),
            ),
          ],
        )
        : isLoading
            ? Center(child: Container())
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Padding(
                      padding: EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 0.0),
                      child: Container(
                        width: 120.0,
                        height: 111.0,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage(
                                  'assets/newDesignIcon/connections/man_to_guide.png'),
                              fit: BoxFit.cover),
                        ),
                      )),
                  Center(
                    child: Text(
                      "You haven’t sent any request",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontSize: 18.0,
                          fontFamily: Constant.latoRegular),
                    ),
                  ),
                ],
              );
  }

  Widget getListview(
      RequestedTagModel requestedTagModel, index, bool isSentRequest, status) {
    return InkWell(
      child: Padding(
        padding: EdgeInsets.fromLTRB(20, index == 0 ? 6 : 16, 20, 16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  ParseJson.getSmallImage(
                      requestedTagModel.patner.profilePicture),
              placeHolderImage: requestedTagModel?.patner?.roleId == "4"
                  ? "assets/profile/partner_img.png"
                  : 'assets/profile/user_on_user.png',
              height: 48.0,
              width: 48.0,
              onTap: () async {
                if (requestedTagModel.patner.userId == userIdPref) {
                } else {
                  Util.onTapImageTile(
                      tapedUserRole: requestedTagModel.patner.roleId,
                      partnerUserId: requestedTagModel.patner.userId,
                      context: context);
                }
              },
            ),
            Expanded(
              child: PaddingWrap.paddingfromLTRB(
                  10.0,
                  0.0,
                  0.0,
                  0.0,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Flexible(
                            child: BaseText(
                              text: getName(null, requestedTagModel),
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              maxLines: 1,
                              textAlign: TextAlign.start,
                            ),
                          ),
                          requestedTagModel.patner.roleId == "1"
                              ? Util.getStudentBadge12New(
                                  requestedTagModel.patner.badge,
                                  requestedTagModel.patner.badgeImage)
                              : const SizedBox.shrink(),
                        ],
                      ),
                      roleId == "1" && diffrenceInDob < 13
                          ? PaddingWrap.paddingfromLTRB(
                              0.0,
                              4.0,
                              0.0,
                              5.0,
                              TextViewWrap.textViewMultiLine(
                                  requestedTagModel.status == "Pending"
                                      ? "Your parent approval pending"
                                      : "Pending",
                                  TextAlign.start,
                                  AppConstants.colorStyle.lightPurple,
                                  12.0,
                                  FontWeight.normal,
                                  1))
                          : requestedTagModel.patner.tagline == null ||
                                  requestedTagModel.patner.tagline == "null" ||
                                  requestedTagModel.patner.tagline == ""
                              ? Container(
                                  height: 0.0,
                                )
                              : PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  4.0,
                                  0.0,
                                  5.0,
                                  TextViewWrap.textView(
                                    requestedTagModel.patner.tagline,
                                    TextAlign.start,
                                    ColorValues.labelColor,
                                    14.0,
                                    FontWeight.normal,
                                  ))
                    ],
                  )),
              flex: 1,
            ),
            Expanded(
              child: Row(
                children: <Widget>[
                  roleId == "2"
                      ? isSentRequest
                          ? Text("")
                          : InkWell(
                              child: Container(
                                  height: 45.0,
                                  width: 45.0,
                                  child: Image.asset(
                                    'assets/newDesignIcon/connections/tick_blue.png',
                                  )),
                              onTap: () {
                                if (status != "") {
                                  apiCallingForAccept(
                                      requestedTagModel.connectId,
                                      index,
                                      "Requested",
                                      requestedTagModel.userIsActive);
                                } else {
                                  apiCallingForAccept(
                                      requestedTagModel.connectId,
                                      index,
                                      "Accepted",
                                      requestedTagModel.userIsActive);
                                }
                              },
                            )
                      : listType == 1
                          ? new Container(
                              height: 0.0,
                            )
                          : InkWell(
                              child: Container(
                                  height: 45.0,
                                  width: 45.0,
                                  child: Image.asset(
                                    'assets/newDesignIcon/connections/tick_blue.png',
                                  )),
                              onTap: () {
                                if (status != "") {
                                  apiCallingForAccept(
                                      requestedTagModel.connectId,
                                      index,
                                      "Requested",
                                      requestedTagModel.userIsActive);
                                } else {
                                  apiCallingForAccept(
                                      requestedTagModel.connectId,
                                      index,
                                      "Accepted",
                                      requestedTagModel.userIsActive);
                                }
                              },
                            ),
                  listType == 4 && roleId == "1"
                      ? Container(
                          height: 0.0,
                        )
                      : ButtonView(
                          btnName: 'Withdraw',
                          onButtonTap: () {
                            String name =
                                requestedTagModel.patner.lastName == null ||
                                        requestedTagModel.patner.lastName ==
                                            "null" ||
                                        requestedTagModel.patner.lastName == ""
                                    ? requestedTagModel.patner.firstName
                                    : requestedTagModel.patner.firstName +
                                        " " +
                                        requestedTagModel.patner.lastName;

                            educationRemoveConfromationDialog(
                                requestedTagModel.connectId, index);
                          },
                        )
                ],
              ),
              flex: 0,
            ),
          ],
        ),
      ),
      onTap: () {
        /*  if (requestedTagModel.patner.userId == userIdPref) {
        } else {
          Util.onTapImageTile(
              tapedUserRole: requestedTagModel.patner.roleId,
              partnerUserId: requestedTagModel.patner.userId,
              context: context);
        }*/
      },
    );
  }

  Future apiCallingForAccept(connectionId, index, type, userIsActive) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": type,
        "isActive": userIsActive,
        "roleId": int.parse(roleId)
      };
      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isNeedToRefresh = true;
            tagList.removeAt(index);
            setState(() {
              tagList;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  void educationRemoveConfromationDialog(id, index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: 'Are you sure you want to withdraw?',
            negativeText: 'Cancel',
            positiveText: 'Withdraw',
            isSucessPopup: false,
            onPositiveTap: () {
              apiCallingForUnfriend(
                id,
                index,
              );
            },
          );
        });
  }

  Future apiCallingForUnfriend(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId)
      };
      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            print("Cancel -----=-=-=-=-=-=-=-= " + listType.toString());

            if (listType == 0) tagList.removeAt(index);

            if (listType == 1) {
              sendRequestList[index].patner.profilePicture = "";
              searchtagList[index].patner.profilePicture = "";
              setState(() {
              });
              searchtagList.clear();
              sendRequestList.removeAt(index);
              searchtagList.addAll(sendRequestList);
            }

            isNeedToRefresh = true;
            setState(() {
            });
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  getName(PeopleYouMayKnow, requestedTagModel) {
    String firstName, lastName;

    if (PeopleYouMayKnow != null) {
      if (PeopleYouMayKnow.lastName == null ||
          PeopleYouMayKnow.lastName == "null" ||
          PeopleYouMayKnow.lastName == "") {
        lastName = "";
      } else {
        lastName = PeopleYouMayKnow.lastName;
      }

      if (PeopleYouMayKnow.firstName == null ||
          PeopleYouMayKnow.firstName == "null" ||
          PeopleYouMayKnow.firstName == "") {
        firstName = PeopleYouMayKnow.email;
      } else {
        firstName = PeopleYouMayKnow.firstName;
      }

      return firstName + " " + lastName;
    } else {
      if (requestedTagModel.patner.lastName == null ||
          requestedTagModel.patner.lastName == "null" ||
          requestedTagModel.patner.lastName == "") {
        lastName = "";
      } else {
        lastName = requestedTagModel.patner.lastName;
      }

      if (requestedTagModel.patner.firstName == null ||
          requestedTagModel.patner.firstName == "null" ||
          requestedTagModel.patner.firstName == "") {
        firstName = requestedTagModel.patner.email;
      } else {
        firstName = requestedTagModel.patner.firstName;
      }

      return firstName + " " + lastName;
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
