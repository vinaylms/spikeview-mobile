import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/group/model/EmailModel.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/group/model/SpikeUserInvitationModel.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class InviteNonSpikeViewMember extends StatefulWidget {
  String pageName;

  InviteNonSpikeViewMember({this.pageName});

  @override
  InviteNonSpikeViewMemberState createState() {
    return  InviteNonSpikeViewMemberState();
  }


}

class InviteNonSpikeViewMemberState extends State<InviteNonSpikeViewMember> {
  SharedPreferences prefs;
  BuildContext context;
  String userIdPref, roleId, name;

  // Variables for Search
  TextEditingController _searchQuery =  TextEditingController(text: "");
  TextEditingController _searchSpieViewUser =
       TextEditingController(text: "");
  List<EmailModel> emailList =  List();
  List<SpikeUserInvitationModel> spikeViewUserList =  List();
  String _searchText = "", previousText = "";

  List<ProfileInfoModal> friendList =  List();
  static StreamController syncDoneController = StreamController.broadcast();
  bool _IsSearching;

  bool isApiCalling = false;
  String isApiCalled = "pop";
  String doubleCodeForSearchHint = "\"";

  TextEditingController edtController;
  String userName = "";
  String userEmail = "";
  var style = TextStyle(
      color: ColorValues.GREY_TEXT_COLOR, fontSize: 16, fontFamily: Constant.TYPE_CUSTOMREGULAR);
  var stylesize = TextStyle(
      color: ColorValues.GREY_TEXT_COLOR, fontSize: 12, fontFamily: Constant.TYPE_CUSTOMREGULAR);

  //--------------------------api Calling for tag------------------

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    name = prefs.getString(UserPreference.NAME);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userName = prefs.getString(UserPreference.NAME);
    userEmail = prefs.getString(UserPreference.EMAIL);
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");
      Navigator.pop(context);
      if (widget.pageName == "wizard") {
        syncDoneController.add("connection");
        Navigator.of(context).popUntil((route) => route.isFirst);
      } else {
        Navigator.pop(context, "push");
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  onBack() {
    print("OnBack++++++");
    if (widget.pageName == "wizard") {
      print("OnBack++++++1");
      syncDoneController.add("connection");
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else {
      print("OnBack++++++2");
      Navigator.pop(context);
    }
    // Navigator.pop(context);
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "nonusers": emailList.map((item) => item.toJson()).toList(),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "invitedBy": name,
          "message": edtController.text
        };
        print(map.toString());
        response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_SEARCH_INVITE_CONNECTION, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              isApiCalled = "push";
              showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    edtController =  TextEditingController(text: '');
    _searchQuery.addListener(() {
      print("Listener   " + _searchQuery.text);
      if (_searchQuery.text.isEmpty) {
      } else {
        if (previousText != _searchQuery.text) {
          if (_searchQuery.text.contains(".com")) {
            print("is true");
            bool isAdd = true;

            if (_searchQuery.text == userEmail) {
              _searchQuery.text = "";
              setState(() {
                emailList;
                _searchQuery;
              });
              ToastWrap.showToast(MessageConstant.SELF_REFER_NOT_GOOD_IDEA, context);

            } else {
              setState(() {
                previousText = _searchQuery.text;
              });
              if (ValidationWidget.isEmail(_searchQuery.text)) {
                for (int i = 0; i < emailList.length; i++) {
                  if (_searchQuery.text == emailList[i].email) {
                    isAdd = false;
                    print("data" + emailList[i].email.toString());
                  }
                }

                if (isAdd) emailList.add(new EmailModel(_searchQuery.text, ""));

                print("addd" + isAdd.toString());
                _searchQuery.text = "";
                setState(() {
                  emailList;
                  _searchQuery;
                });
              }
            }
          }
        }
      }
    });

    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;

    _buildChoiceList() {
      List<Widget> choices = List();
      emailList.forEach((item) {
        choices.add(PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            5.0,
            5.0,
            Container(
              decoration:  BoxDecoration(
                  border:  Border.all(
                      width: 1.0,
                      color:  ColorValues.GREY_TEXT_COLOR)),
              padding: const EdgeInsets.fromLTRB(8.0, 4.0, 8.0, 4.0),
              child: Wrap(
                children: <Widget>[
                   Text(
                    item.email,
                    overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),
                   InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                         Icon(
                          Icons.clear,
                          color: Colors.black,
                          size: 17.0,
                        )),
                    onTap: () {
                      emailList.remove(item);
                      setState(() {
                        emailList;
                      });
                    },
                  )
                ],
              ),
            )));
      });
      return choices;
    }

    return  WillPopScope(
        onWillPop: () {
      onBack();
    },
    child: MaterialApp(
      home:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            appBar: AppBar(
                backgroundColor: Colors.white,
                automaticallyImplyLeading: true,
                elevation: 0.0,
                centerTitle: true,
                title: Text("Refer Now ",
                    style: TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular)),
                leading:  InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0, 0.0, 15.0, 0.0, CustomViews.getBackButton()),
                  onTap: () {
                    onBack();
                  },
                ),
                actions: <Widget>[
                   InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        4.0,
                        15.0,
                        0.0,
                         Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                             Text(
                              "Send",
                              style:  TextStyle(
                                  fontSize: 16.0,
                                  fontFamily: Constant.customRegular,
                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                            )
                          ],
                        )),
                    onTap: () {
                      if (emailList.length == 0 &&
                          spikeViewUserList.length == 0) {
                        ToastWrap.showToast(
                            MessageConstant.ADD_MEMBERS_VAL, context);
                      } else {
                        apiCalling();
                      }
                    },
                  )
                ]),
            body:  Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                 Expanded(
                    child:  ListView(
                  children: <Widget>[
                     Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        emailList.length == 0
                            ?  Container(
                                height: 25.0,
                              )
                            :  Padding(
                                padding:
                                    EdgeInsets.fromLTRB(13.0, 25.0, 13.0, 0.0),
                                child:  Text(
                                  "Invite by email",
                                  style:  TextStyle(
                                      color:  ColorValues.GREY_TEXT_COLOR,
                                      fontSize: 14.0,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                )),
                         Padding(
                          padding: EdgeInsets.fromLTRB(13.0, 5.0, 13.0, 0.0),
                          child: Wrap(
                            children: _buildChoiceList(),
                          ),
                        ),
                         Padding(
                            padding: EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 0.0),
                            child:  Container(
                              decoration:  BoxDecoration(
                                  border: Border(
                                      bottom:  BorderSide(
                                          color:   ColorValues.LIGHT_GREY_TEXT_COLOR,
                                          width: 1.0))),
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  5.0,
                                  5.0,
                                  5.0,
                                   TextField(
                                      controller: _searchQuery,
                                      autocorrect: false,
                                      keyboardType: TextInputType.emailAddress,
                                      autofocus: true,
                                      cursorColor: Constant.CURSOR_COLOR,
                                      decoration:  InputDecoration(
                                        contentPadding:
                                            const EdgeInsets.fromLTRB(
                                                0.0, 5.0, 5.0, 5.0),
                                        border: InputBorder.none,
                                        hintText: emailList.length == 0
                                            ? 'Invite by email'
                                            : "",
                                        hintStyle:  TextStyle(
                                            fontSize: 16.0,
                                            color:  ColorValues.GREY_TEXT_COLOR,
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                      ))),
                            )),
                         Padding(
                            padding: EdgeInsets.fromLTRB(13.0, 35.0, 13.0, 0.0),
                            child:  Container(
                              decoration:  BoxDecoration(
                                  border: Border(
                                      bottom:  BorderSide(
                                          color:   ColorValues.LIGHT_GREY_TEXT_COLOR,
                                          width: 1.0))),
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  5.0,
                                  5.0,
                                  5.0,
                                   TextFormField(
                                      controller: edtController,
                                      autocorrect: false,
                                      keyboardType: TextInputType.multiline,
                                      maxLines: 1,
                                      maxLength:TextLength. INVITE_NON_SPIKEVIEW_USER_MSG_LENGTH,
                                      autofocus: true,
                                      cursorColor: Constant.CURSOR_COLOR,
                                      decoration:  InputDecoration(
                                        contentPadding:
                                            const EdgeInsets.fromLTRB(
                                                0.0, 5.0, 5.0, 5.0),
                                        border: InputBorder.none,
                                        counterText: "",
                                        hintText:
                                             "Hi, let’s get connected on spikeview",
                                        labelText:"Message" ,errorStyle: Util.errorTextStyle,
                                        hintStyle: style,
                                        counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),     labelStyle:  TextStyle(
                                            fontSize: 16.0,
                                            color:  ColorValues.GREY_TEXT_COLOR,
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                      ))),
                            )),
                        Padding(
                          padding: const EdgeInsets.only(
                            top: 5.0,
                            left: 13.0,
                            right: 13.0,
                          ),
                          child: Text(
                            "Please enter a message to send with your referral invite.",
                            style: stylesize,
                            maxLines: 2,
                          ),
                        ),
                      ],
                    )
                  ],
                ))
              ],
            ),
          )),
    );
    // Create Chips View for Selected
  }
}
