import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:geocoder/geocoder.dart';
import 'package:location/location.dart' as LocationManager;
import 'package:dio/dio.dart';
import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/Service.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';

class API {
  static String mediaFileUrl =
      'http://spikeviewmediastorage.blob.core.windows.net/spikeview-media-production/';
  static String baseMediaUploadUrl =
      'http://spikeviewmediastorage.blob.core.windows.net';
  static String generateSasTokenUrl = Constant.BASE_URL + 'ui/azure/sas';
  static String signUpUser = Constant.BASE_URL + 'app/signup/partner';

  static String getPreviousOpportunity =
      Constant.BASE_URL + Constant.ENDPOINT_PREVIOUS_OPORTUNITY;

  static String groupListUrl = Constant.BASE_URL + Constant.ENDPOINT_GROUPS_ALL;

  static String createOpportunityUrl = Constant.BASE_URL + 'ui/opportunity';
  static String editOpportunityUrl = Constant.BASE_URL + 'ui/updateOpportunity';
  static String createOpportunityUrlNew =
      Constant.BASE_URL + 'ui/opportunity/dev';
  static String interestListApi = Constant.BASE_URL + 'ui/interests';

  static String getOpportunityData =
      Constant.BASE_URL + 'ui/opportunity?userId=1019&roleId=4';

  static Map<String, dynamic> getHeaders(token) {
    return {'Authorization': token};
  }



  static Future<AssetModel> uploadMedia(String sasContainer, String fileName,
      String sasToken, File file, bool isImage, userIdPref, type) async {
    String mediaUploadUrl =
        "${baseMediaUploadUrl}/${sasContainer}/sv_${userIdPref}/media/${fileName}?${sasToken}";
    print(mediaUploadUrl);
    var dio = Dio();
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };
    dio.options.followRedirects = false;
    dio.options.validateStatus = (status) {
      return status < 500;
    };

// Binary data
    List<int> postData = file.readAsBytesSync();
    dio.options.contentType = ContentType.parse('application/octet-stream');
    var response = await dio.put(
      mediaUploadUrl,
      data: postData,
      // data: Stream.fromIterable(
      //     postData.map((f) => f)), //create a Stream<List<int>> // not required in dio 1.0.3
      options: Options(
        headers: {
          // Headers.contentLengthHeader: postData.length, // set content-length // not required in dio 1.0.3
          'x-ms-blob-type': 'BlockBlob',
          'x-ms-type': 'file',
          'x-ms-content-length': postData.length,
        },
      ),
    );
    print("response image++++++" + response.statusCode.toString());
    if (response.statusCode == 201) {
      AssetModel model = AssetModel(
        file: "sv_${userIdPref}/media/${fileName}",
        tag: 'media',
        type: type,
      );
      return model;
    } else
      return null;
  }

  static Future<bool> registerUser(Map<String, dynamic> params) async {
    var dio = Dio();
    dio.options.followRedirects = false;
    dio.options.validateStatus = (status) {
      return status < 500;
    };
    FormData formData = FormData.from(params);

    var response = await dio.post(signUpUser, data: formData);
    return true;
  }

  static Future<Map<String, dynamic>> generateSasToken(token) async {
    var dio = Dio();
    dio.options.headers = getHeaders(token);
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };
    dio.options.followRedirects = false;
    dio.options.validateStatus = (status) {
      return status < 500;
    };
    FormData formData = FormData.from({});

    print(generateSasTokenUrl);
    var response = await dio.post(generateSasTokenUrl, data: formData);
    print(response.data);
    return response.data['result'];
  }

  static Future<List<GroupModel>> fetchGroupList(userId, token, roleId) async {
    var dio = Dio();
    dio.options.headers = getHeaders(token);
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };
    dio.options.followRedirects = false;
    dio.options.validateStatus = (status) {
      return status < 500;
    };

    print(groupListUrl);
    var response = await dio.get(groupListUrl + userId + "/" + roleId);
    print(response.data);
    GroupListModel groupListModel =
        ParseJson.parseGroupData3(response.data['result'], userId, roleId);

    return groupListModel.groupList;
  }
  static Future<List<GroupModel>> fetchGroupListForExternalShare(userId, token, roleId) async {
    var dio = Dio();
    dio.options.headers = getHeaders(token);
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };
    dio.options.followRedirects = false;
    dio.options.validateStatus = (status) {
      return status < 500;
    };

    print(groupListUrl);
    var response = await dio.get(groupListUrl + userId + "/" + roleId);
    print(response.data);
    GroupListModel groupListModel =
        ParseJson.parseGroupDataForExternalShare(response.data['result'], userId, roleId);

    return groupListModel.groupList;
  }

  parseJsonData() {}

  static Future<bool> createOpportunity(map, token) async {
    try {
      var dio = Dio();
      dio.options.headers = getHeaders(token);
      dio.onHttpClientCreate = (HttpClient client) {
        client.badCertificateCallback =
            (X509Certificate cert, String host, int port) {
          return true;
        };
      };
      dio.options.followRedirects = false;
      dio.options.validateStatus = (status) {
        return status < 500;
      };

      //FormData formData = FormData.from(params);

      // print(json.encode(params));

      print(createOpportunityUrl);
      var response =
          await dio.post(createOpportunityUrl, data: json.encode(map));
      print(response.data.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            print("message" + response.toString());
            return true;
          } else {
            return false;
          }
        }
      }
    } catch (e) {
      print("api+++" + e.toString());
    }
    return false;
  }

  static Future<bool> createOpportunityNew(map, token) async {
    try {
      var dio = Dio();
      dio.options.headers = getHeaders(token);
      dio.onHttpClientCreate = (HttpClient client) {
        client.badCertificateCallback =
            (X509Certificate cert, String host, int port) {
          return true;
        };
      };
      dio.options.followRedirects = false;
      dio.options.validateStatus = (status) {
        return status < 500;
      };

      //FormData formData = FormData.from(params);

      // print(json.encode(params));

      print("Opportunity URL:: $createOpportunityUrl");
      var response =
          await dio.post(createOpportunityUrl, data: json.encode(map));
      print(response.data.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            print("message" + response.toString());
            return true;
          } else {
            return false;
          }
        }
      }
    } catch (e) {
      print("api+++" + e.toString());
    }
    return false;
  }

  static Future<bool> editOpportunityNew(map, token) async {
    try {
      var dio = Dio();
      dio.options.headers = getHeaders(token);
      dio.onHttpClientCreate = (HttpClient client) {
        client.badCertificateCallback =
            (X509Certificate cert, String host, int port) {
          return true;
        };
      };
      dio.options.followRedirects = false;
      dio.options.validateStatus = (status) {
        return status < 500;
      };

      //FormData formData = FormData.from(params);

      // print(json.encode(params));

      print("Opportunity URL:: $editOpportunityUrl");
      var response = await dio.put(editOpportunityUrl, data: json.encode(map));
      print(response.data.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            print("message" + response.toString());
            return true;
          } else {
            return false;
          }
        }
      }
    } catch (e) {
      print("api+++" + e.toString());
    }
    return false;
  }

  static Future<bool> updateOpportunity(
      Map<String, dynamic> params, token) async {
    var dio = Dio();
    dio.options.headers = getHeaders(token);
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };
    dio.options.followRedirects = false;
    dio.options.validateStatus = (status) {
      return status < 500;
    };

    FormData formData = FormData.from(params);
    print(getOpportunityData);
    var response = await dio.post(getOpportunityData, data: formData);
    print(response.data.toString());
    return true;
  }

  static Future<Placemark> getUserLocation() async {
    final location = LocationManager.Location();
    try {
      LocationManager.LocationData currentLocation =
          await location.getLocation();
      final lat = currentLocation.latitude;
      final lng = currentLocation.longitude;
      List<Placemark> placemark =
          await Geolocator().placemarkFromCoordinates(lat, lng);
      return placemark[0];
    } on Exception {
      print("isFirstTimeCurrentLocation:: inside exception");
      return null;
    }
  }

  static Future<String> getUserCity() async {
    //call this async method from whereever you need
    print("getUserCity()");
    String city = "";
    LocationData myLocation;
    String error;
    Location location =  Location();
    try {
      myLocation = await location.getLocation();
    } on PlatformException catch (e) {
      print('');
      if (e.code == 'PERMISSION_DENIED') {
        error = 'please grant permission';
        print(error);
      }
      if (e.code == 'PERMISSION_DENIED_NEVER_ASK') {
        error = 'permission denied- please enable it from app settings';
        print(error);
      }
      myLocation = null;
    }
    var currentLocation = myLocation;
    final coordinates =
         Coordinates(myLocation.latitude, myLocation.longitude);
    var addresses =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    var first = addresses.first;
    city = '${first.locality}';
    print('City:: $city');
    return city;
  }

  Future<String> getUserLocationNew() async {
    //call this async method from whereever you need
    print("getUserLocationNew()");
    String address = "";
    LocationData myLocation;
    String error;
    Location location =  Location();
    try {
      myLocation = await location.getLocation();
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        error = 'please grant permission';
        print(error);
      }
      if (e.code == 'PERMISSION_DENIED_NEVER_ASK') {
        error = 'permission denied- please enable it from app settings';
        print(error);
      }
      myLocation = null;
    }
    var currentLocation = myLocation;
    final coordinates =
         Coordinates(myLocation.latitude, myLocation.longitude);
    var addresses =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    var first = addresses.first;
    print(
        ' ${first.locality}, ${first.adminArea},${first.subLocality}, ${first.subAdminArea},${first.addressLine}, ${first.featureName},${first.thoroughfare}, ${first.subThoroughfare}');

    address =
        '${first.addressLine},${first.featureName},${first.subAdminArea},${first.adminArea}';
    print('Address:: $address');
    return address;
  }

  static Future<List<Item>> fetchCountryList(
      String keyword, String type) async {
    print("apiCalling++++Location" + Constant.kGoogleApiKey);
    String url = '';
    if (type != null && type.isNotEmpty) {
      url =
          'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$keyword&types=($type)&key=' +
              Constant.kGoogleApiKey;
    } else {
      url =
          'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$keyword&key=' +
              Constant.kGoogleApiKey;
    }
    print(url);
    var dio =  Dio();
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };

    final response = await dio.get(url);
    List<Item> list = [];
    int i = 0;
    list = (response.data['predictions'] as List).map((data) {
      Item item =
           Item(i, data['description'], data['place_id'], "", "", "", "");
      list.add(item);
      i++;
      return item;
    }).toList();
    print(response.data.toString());
    return list;
  }

  static Future<List<Item>> fetchCountryListForSignup(
      String keyword, String type, String countryName) async {
    print("apiCalling++++Location" + Constant.kGoogleApiKey);
    String url = '';

    url =
        'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$keyword&types=($type)&components=country:$countryName&key=' +
            Constant.kGoogleApiKey;

    print(url);
    var dio =  Dio();
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };

    final response = await dio.get(url);
    List<Item> list = [];
    int i = 0;
    list = (response.data['predictions'] as List).map((data) {
      var terms = data['terms'];
      Item item;

      if (terms.length == 1) {
         item =  Item(
            i,
            data['description'],
            data['place_id'],
            "",
            data['terms'][0]['value'].toString(),
            data['description'],
            "");
      } else if (terms.length == 2) {
         item =  Item(
            i,
            data['description'],
            data['place_id'],
            data['terms'][0]['value'].toString(),
            data['terms'][1]['value'].toString(),
            data['description'],
            "");
      } else if (terms.length == 3) {
         item =  Item(
            i,
            data['description'],
            data['place_id'],
            terms[1]['value'].toString(),
            terms[2]['value'].toString(),
            terms[0]['value'].toString(),
            "");
      }
      list.add(item);
      i++;
      return item;
    }).toList();
    print(response.data.toString());
    return list;
  }

  static Future<List<IntrestModel>> fetchInterestList(token) async {
    var dio = Dio();
    dio.options.headers = getHeaders(token);
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };
    dio.options.followRedirects = false;
    dio.options.validateStatus = (status) {
      return status < 500;
    };

    print(interestListApi);
    var response = await dio.get(interestListApi);

    print("intrest+++++" + response.toString());
    // if (response.data.toString() != null &&
    //     response.data.toString().isNotEmpty) {
    print(response.statusCode.toString());
    print(json.encode(response.data));
    List<IntrestModel> list = (response.data['result'] as List)
        .map((i) => IntrestModel.fromJson(i))
        .toList();
    return list;
    // } else
    // return [];
  }


  static Future<List<Service>> getTargetAudienceData(
      userID, token, BuildContext context) async {
    var dio = Dio();
    dio.onHttpClientCreate = (HttpClient client) {
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) {
        return true;
      };
    };
    dio.options.headers = getHeaders(token);
    dio.options.followRedirects = false;
    dio.options.validateStatus = (status) {
      return status < 500;
    };

    print(getPreviousOpportunity);
    CustomProgressLoader.showLoader(context);
    var response = await dio.get(getPreviousOpportunity + userID);
    CustomProgressLoader.cancelLoader(context);
    print(response.data.toString());
    List<Service> list =  List();
    if (response.data['result']['previousOpprtunity'] != null)
      list =
          ParseJson.serviceList(response.data['result']['previousOpprtunity']);

    return list;
  }
}
