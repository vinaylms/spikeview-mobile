import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/custom_multiline_text_form.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class InquireNowScreen extends StatefulWidget {
  String opportunityId, userId, formId;
  String offerId;
  String pageName;

  InquireNowScreen(this.opportunityId, this.userId, this.formId, this.offerId,
      this.pageName);

  @override
  InquireNowScreenState createState() =>  InquireNowScreenState();
}

class InquireNowScreenState extends State<InquireNowScreen> {
  var style = TextStyle(
      color: ColorValues.GREY_TEXT_COLOR,
      fontSize: 14,
      fontFamily: Constant.TYPE_CUSTOMBOLD);
  var styleblack =
  TextStyle(
      color: Colors.black, fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD);
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final ponePinController = TextEditingController();
  final messageController = TextEditingController();
  final FocusNode nameFocus = FocusNode();
  final FocusNode emailFocus = FocusNode();
  final FocusNode phoneFocus = FocusNode();
  final FocusNode pinFocus = FocusNode();
  final FocusNode messageFocus = FocusNode();

  String name = '',
      email = '',
      phone = '',
      pin = '',
      message = '';
  bool nameValidation = true;

  String dropdownvalue = '+91';

  _fieldFocusChange(BuildContext context, FocusNode currentFocus,
      FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }


  final _profileFormKey = GlobalKey<FormState>();

  bool isMessage(String em) {
    String p = r"^[a-zA-Z0-9]+(([',. -][a-zA-Z0-9 ])?[a-zA-Z0-9]*)*$";
    RegExp regExp = RegExp(p);
    return regExp.hasMatch(em);
  }

  onBack() async {
    if (widget.pageName == "login") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                DashBoardWidgetParent(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>
                DashBoardWidget(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context);
    }
  }


  showSucessMsg(msg, context) {

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            headingText: msg,
            negativeText: 'OK',
            isSucessPopup: true,
            positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
              onBack();
            },

          );
        });



  }

  Future apiCalling() async {
    try {
      print("api clicked++++++");
      print("api clicked++++++" + widget.opportunityId);
      print("api clicked++++++" + widget.userId);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "name": nameController.text,
          "email": emailController.text,
          "message": messageController.text,
          "number": phoneController.text,
          "opportunityId": widget.opportunityId,
          "userId": widget.userId
        };

        print("map+++" + map.toString());
        response = await ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_ADD_INQUIRY, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {

        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  void _validateCardDetail() async {
    try {
      final form = _profileFormKey.currentState;
      form.save();
      if (form.validate()) {
//    If all data are correct then save data to out variables
        form.save();
        apiCalling();
        // putUserProfile();
        print("shubh clicked++++++");
      }
    } catch (e) {
      print("++++Inqure+++++++++++++++++++++++" + e.toString());
    }
  }

  List<PinModel> _dataList = PinModel.getCompanies();
  List<DropdownMenuItem<PinModel>> _dropdownMenuItems;
  PinModel _selectedValue;
  SharedPreferences prefs;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
  }

  @override
  void initState() {
    getSharedPreferences();
    _dropdownMenuItems = buildDropdownMenuItems(_dataList);
    _selectedValue = _dropdownMenuItems[0].value;
    messageController.text =
    "I saw your post on spikeview, and would like to request more information about this opportunity. Can you please tell me a little more about it.";

    /* if (widget.offerId == "1") {
      messageController.text =
          "I saw your post on spikeview, and would like to request more information about this opportunity. Can you please tell me a little more about it, and how I can apply";
    } else if (widget.offerId == "2") {
      messageController.text =
          "I saw your post on spikeview, and would like to request more information";
    } else {
      messageController.text =
          "I saw your post on spikeview, and would like to get more information about your college counseling service.";
    }*/


    super.initState();
  }

  List<DropdownMenuItem<PinModel>> buildDropdownMenuItems(List datas) {
    List<DropdownMenuItem<PinModel>> items = List();
    for (PinModel data in datas) {
      items.add(
        DropdownMenuItem(
          value: data,
          child: Container(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 20.0),
              child: Row(
                children: <Widget>[
                  Image.asset(
                    data.img,
                    height: 26.0,
                    width: 26.0,
                  ),
                  Text(
                    "  " + data.pinNumber,
                    style: TextStyle(
                        fontSize: 16,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                        color: ColorValues.GREY_TEXT_COLOR),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }
    return items;
  }

  onChangeDropdownItem(PinModel selectedValue) {
    setState(() {
      _selectedValue = selectedValue;
    });
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // TODO: implement build

    var nameField = Padding(
      padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 10.0),
      child:

      CustomFormField(
        // maxLength: 35,
        textInputType: TextInputType.text,

        onSaved: (val) {
          name = val;
          _fieldFocusChange(context, nameFocus, emailFocus);

        },
        controller: nameController,
        focusNode: nameFocus,

        onType: (v) {
        //  checkAllFieldSubmitter();
        },
        label: "Name",

        validation: (val) =>  val.trim()
            .length == 0
            ? MessageConstant.ENTER_NAME_VAL
            : !ValidationWidget.isName(val.trim())
            ? MessageConstant.NAME_CONTAIN_ALPHABT_VAL
            : null,
      )



      /* old
      TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,
        controller: nameController,
        focusNode: nameFocus,
        onFieldSubmitted: (term) {
          _fieldFocusChange(context, nameFocus, emailFocus);
        },
        validator: (val) =>
        val
            .trim()
            .length == 0
            ? MessageConstant.ENTER_NAME_VAL
            : !ValidationWidget.isName(val.trim())
            ? MessageConstant.NAME_CONTAIN_ALPHABT_VAL
            : null,
        onSaved: (String val) {
          name = val;
        },

        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.text,
        decoration: InputDecoration(
          labelText: "Name",
          errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
          disabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
        ),
      ),
    */
    );

    var emailField = Padding(
      padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 10.0),
      child:

      CustomFormField(
        // maxLength: 35,
          textInputType: TextInputType.emailAddress,

          onSaved: (val) {
          email = val;
          _fieldFocusChange(context, emailFocus, phoneFocus);

        },

        controller: emailController,
        focusNode: emailFocus,

        onType: (v) {
          //  checkAllFieldSubmitter();
        },
        label: "Email",

        validation: (arg){
          if (arg.length > 0) {
            if (ValidationWidget.isEmail(arg)) {
              return null;
            } else {
              return MessageConstant.VALID_EMAIL_VAL;
            }
          } else {
            return MessageConstant.VALID_EMAIL_VAL;
          }
        }
      )


      /*
      TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,
        controller: emailController,
        focusNode: emailFocus,
        onFieldSubmitted: (term) {
          _fieldFocusChange(context, emailFocus, phoneFocus);
        },
        validator: (String arg) {
          if (arg.length > 0) {
            if (ValidationWidget.isEmail(arg)) {
              return null;
            } else {
              return MessageConstant.VALID_EMAIL_VAL;
            }
          } else {
            return MessageConstant.VALID_EMAIL_VAL;
          }
        },
        onSaved: (String val) {
          email = val;
        },

        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.emailAddress,
        decoration: InputDecoration(
          labelText: "Email",
          errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
          disabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: ColorValues.DARK_GREY)),
        ),
      ),
    */
    );

    var phoneField = Padding(
      padding: const EdgeInsets.only(left: 0.0, right: 0.0, top: 10.0),
      child:

      CustomFormField(
        // maxLength: 35,
          textInputType: TextInputType.number,
          onSaved: (val) {
            phone = val;
            _fieldFocusChange(context, phoneFocus, messageFocus);
          },
          controller: phoneController,
          focusNode: phoneFocus,
          onType: (v) {
            //  checkAllFieldSubmitter();
          },
          label: "Phone number",
          validation: (value){
            return ValidationChecks.validatePhone(value);
          }
      )


/*
      TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,
        controller: phoneController,
        focusNode: phoneFocus,
        onFieldSubmitted: (term) {
          _fieldFocusChange(context, phoneFocus, messageFocus);
        },
        validator: (value) {
          return ValidationChecks.validatePhone(value);
        },
        onSaved: (String val) {
          phone = val;
        },

        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.phone,
        decoration: InputDecoration(
          labelText: "Phone Number",
          errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
          disabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: ColorValues.DARK_GREY)),
        ),
      ),

    */
    );


    var contactField = Padding(
        padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 0.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(flex: 1, child: phoneField),
          ],
        ));

    var messageField = Padding(
      padding: const EdgeInsets.only(left: 20.0, right: 20.0, top: 10.0),
      child:

      CustomMultilineTextForm(
      //  enable: false,
        readOnly: true,
        maxLines: 5,
        // maxLength: 2000,
        focusNode:  messageFocus,
        controller: messageController,
        // focusNode: detailNode,
        textAlign: TextAlign.start,
        // hint:
        // 'I participated in your program in the spring of 2020 and was a leader of the team. Please issue a leader badge so I can add to my profile.',
        label: 'Message',
        //  errorText:isShowErrorRequested?errorMsg:null ,
        alignLabelWithHint: true,
        textInputAction:
        TextInputAction.done,
        textInputType:
        TextInputType.multiline,
        validation: (value) {
          // if (value
          //     .toString()
          //     .trim()
          //     .isEmpty) {
          //   return 'Please add text';
          // }
          return null;
        },
        onSaved: (val) {


        },
        onType: (val) {

        },
      ),



      /*
      TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,
        controller: messageController,
        enabled: false,
        focusNode: messageFocus,
        /*  validator: (String arg) {
          if (arg.length > 0) {
            if (isMessage(arg)) {
              return null;
            } else {
              return MessageConstant.ENTER_CORRECT_INPUT_VAL;
            }
          } else {
            return MessageConstant.ENTER_MESSAGE_VAL;
          }
        },*/
        onSaved: (String val) {
          phone = val;
        },
        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.multiline,
        maxLines: null,
        decoration: InputDecoration(
          labelText: "Message",
          errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
          disabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: ColorValues.DARK_GREY),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: ColorValues.DARK_GREY)),
        ),
      ),
    */
    );


    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: customAppbar(
          context,
          GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: ListView(
              padding: EdgeInsets.zero,
                children: <Widget>[
                  Form(
                    key: _profileFormKey, child: Container(
                    child: Padding(
                      padding:
                      const EdgeInsets.only(left: 0.0, top: 24.0, right: 0.0),

                      child: Column(

                          children: <Widget>[

                            Padding(
                              padding: const EdgeInsets.only(left: 20,right: 20),
                              child: Align(
                                  alignment: Alignment.topLeft,
                                  child: BaseText(
                                    text: "Inquire now",
                                    textColor:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 28,
                                    maxLines: 1,
                                  )),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20,right: 20,bottom: 20),
                              child: Align(
                                  alignment: Alignment.topLeft,
                                  child: BaseText(
                                    text: "Please fill in the form below. the email will be sent to the partner.",
                                    textColor:
                                    AppConstants.colorStyle.lightPurple,
                                    fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                    maxLines: 2,
                                  )),
                            ),

                        nameField,
                        emailField,
                        contactField,
                        messageField
                      ]),
                    ),
                  ),
                  )
                ]),
          ),
              () {
            Navigator.pop(context);
          },

          isShowIcon: false,

          bottomNavigation: Stack(
              children: [
                PaddingWrap.paddingfromLTRB(
                  20.0,
                  20.0,
                  20.0,
                  20.0,
                  InkWell(
                    child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          color: AppConstants.colorStyle.lightBlue,
                          border: Border.all(
                              color: AppConstants.colorStyle.lightBlue),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Align(
                            alignment: Alignment.center,
                            // Align however you like (i.e .centerRight, centerLeft)
                            child: Text(
                              "Send",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: ColorValues.WHITE,
                                fontFamily:
                                AppConstants.stringConstant.latoMedium,
                                fontSize: 18.0,
                              ),
                            ))),
                    onTap: () {
                      print("onclick++++++");
                      _validateCardDetail();
                    },
                  ),
                )
              ]
          ),

        )
    );
  }

}

    /*

    return  WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:  Scaffold(
          appBar:

          AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                 InkWell(
                  child:  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "assets/newDesignIcon/navigation/back.png",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),
                  ),
                  onTap: () {
                    onBack();
                  },
                )
              ],
            ),
            title:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                 Text(
                  "Inquire Now ",
                  style:  TextStyle(
                      fontSize: 18.0,
                      fontFamily: Constant.customRegular,
                      color:  ColorValues.HEADING_COLOR_EDUCATION),
                )
              ],
            ),
            actions: <Widget>[
               InkWell(
                child: PaddingWrap.paddingfromLTRB(
                    5.0,
                    7.0,
                    10.0,
                    5.0,
                     Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                         Text(
                          "Send ",
                          style:  TextStyle(
                              fontSize: 16.0,
                              fontFamily: Constant.customRegular,
                              color:
                               ColorValues.BLUE_COLOR_BOTTOMBAR),
                        )
                      ],
                    )),
                onTap: () {
                  print("onclick++++++");
                  _validateCardDetail();
                },
              )
            ],
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
          backgroundColor: ColorValues.singin_bg_color,
          body:
          ListView(
              children: <Widget>[
            Form(
            key: _profileFormKey,child: Container(
              child: Padding(
                padding:
                const EdgeInsets.only(left: 3.0, top: 18.0, right: 3.0),
                child:      Column(children: <Widget>[
                  Padding(
                      padding: const EdgeInsets.only(
                          left: 10.0, top: 0.0, right: 10.0),
                      child: Text(
                        "Please fill in the form below. The email will be sent to the partner.",
                        style: TextStyle(
                            fontSize: 12,
                            color: ColorValues.GREY_TEXT_COLOR,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                      )),
                  nameField,
                  emailField,
                  contactField,
                  messageField
                ]),
              ),
            ),
          )
              ]),

        ));

    */




class PinModel {
  String img = '', pinNumber = '';

  PinModel(this.img, this.pinNumber);

  static List<PinModel> getCompanies() {
    return <PinModel>[
       PinModel("assets/images/1.png", "+1"),
       PinModel("assets/images/1.png", "+234"),
       PinModel("assets/images/1.png", "+376"),
       PinModel("assets/images/1.png", "+244"),
       PinModel("assets/images/1.png", "+355"),
       PinModel("assets/images/1.png", "+93"),
       PinModel("assets/images/1.png", "+672"),
       PinModel("assets/images/1.png", "+61"),
       PinModel("assets/images/1.png", "+291"),
       PinModel("assets/images/1.png", "+20"),
       PinModel("assets/images/1.png", "+500"),
       PinModel("assets/images/1.png", "+33"),
       PinModel("assets/images/1.png", "+358"),
       PinModel("assets/images/1.png", "+251"),
       PinModel("assets/images/1.png", "+240"),
       PinModel("assets/images/1.png", "+30"),
       PinModel("assets/images/1.png", "+299"),
    ];
  }
}
