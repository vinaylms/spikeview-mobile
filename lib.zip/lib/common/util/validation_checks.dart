import 'package:spike_view_project/constant/MessageConstant.dart';

class ValidationChecks {

  static validateLinkLabel(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_LINK_LABEL_VAL;
  }
  static validateURL(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_URL_VAL;
  }


  static validateFirstName(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_FIRST_NAME_VAL;
  }

  static validateLastName(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_LAST_NAME_VAL;
  }

  static validatePhone(String value) {
    String patttern = r'(^(?:[0]9)?[0-9]{10,15}$)';
    RegExp regExp =  RegExp(patttern);
    if (!regExp.hasMatch(value.trim())) {
      return MessageConstant.ENTER_VALID_PHONE_NUMBER_VAL;
    } else {
      return null;
    }

  }

  static validatePhonePortFolio(String value) {
    String patttern = r'(^(?:[0]9)?[0-9]{10,15}$)';
    RegExp regExp =  RegExp(patttern);
    if (!regExp.hasMatch(value.trim())) {
      return MessageConstant.FIELD_REQUIRED;
    } else {
      return null;
    }

  }

  static validateEmail(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex =  RegExp(pattern);
    if (!regex.hasMatch(value.trim()))
      return MessageConstant.ENTER_VALID_EMAIL_VAL;
    else
      return null;
  }

  static validateCompanyName(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_COMPANY_NAMEL_VAL;
  }

  static validateCompanyAddress(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_COMPANY_ADDRESS_VAL;
  }

  static validateWebUrl(String value1) {
    String value = value1.trim();

    RegExp exp =  RegExp(r'((https?|Https|Http|http|ftp|smtp)?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})');

    bool isPasw = exp.hasMatch(value);

    if (isPasw) if (value.split(" ").length > 1||(value.toLowerCase().contains("https//")||value.toLowerCase().contains("http//")))
      return MessageConstant.ENTER_VALID_WEBSITE_URL_VAL;
    else
      null;
    else
      return MessageConstant.ENTER_VALID_WEBSITE_URL_VAL;
  }

  static validateWebUrlSocial(String value1) {
    String value = value1.trim();

    RegExp exp =  RegExp(r'((https?|Https|Http|http|ftp|smtp)?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})');

    bool isPasw = exp.hasMatch(value);
if(value1.trim().length==0){
  return MessageConstant.ADD_URL;
}else {
  if (isPasw)
    if (value
        .split(" ")
        .length > 1||(value.toLowerCase().contains("https//")||value.toLowerCase().contains("http//")))
      return MessageConstant.ADD_URL_NOT_VALID;
    else
      null;
  else
    return MessageConstant.ADD_URL_NOT_VALID;
}
  }


  static validateWebUrlPortFolio(String value1) {
    String value = value1.trim();

    RegExp exp =  RegExp(r'((https?|Https|Http|http|ftp|smtp)?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})');

    bool isPasw = exp.hasMatch(value);
    if(value1.trim().length==0){
      return MessageConstant.FIELD_REQUIRED;
    }else {
      if (isPasw)
        if (value
            .split(" ")
            .length > 1||(value.toLowerCase().contains("https//")||value.toLowerCase().contains("http//")))
          return MessageConstant.ADD_URL_NOT_VALID;
        else
          null;
      else
        return MessageConstant.ADD_URL_NOT_VALID;
    }
  }

  static validateDocURL(String value,{String msg=MessageConstant.ENTER_VALID_DOC_URL_VAL}) {
    RegExp exp =  RegExp(r'((https?|Https|Http|http|ftp|smtp)?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})');
    bool isLink = exp.hasMatch(value);
    if (isLink&&(!(value.toLowerCase().contains("https//")||value.toLowerCase().contains("http//"))))
      return null;
    else
      return msg;
  }


  static validateForLink(String value) {
    RegExp exp =  RegExp(r'^((?:.|\n)*?)((http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)([-A-Z0-9.]+)(/[-A-Z0-9+&@#/%=~_|!:,.;]*)?(\?[A-Z0-9+&@#/%=~_|!:‌​,.;]*)?)');
    bool isLink = exp.hasMatch(value);
    if (isLink&&(!(value.toLowerCase().contains("https//")||value.toLowerCase().contains("http//"))))
      return null;
    else
      return MessageConstant.ENTER_VALID_LINK;
  }
  static validateForResumeLink(String value) {
    RegExp exp =  RegExp(r'((https?|Https|Http|http|ftp|smtp)?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})');
    bool isLink = exp.hasMatch(value);
    if (isLink&&(!(value.toLowerCase().contains("https//")||value.toLowerCase().contains("http//"))))
      return null;
    else
      return MessageConstant.RESUME_ENTER_VALID_LINK;
  }
  static validateAboutCompany(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_SOMETHING_ABOUT_COMPANY_VAL;
  }

  static validateJobTitle(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_JOB_TITLE_VAL;
  }

  static validateServiceTitle(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_SERVICE_TITLE_VAL;
  }

  static validateJobType(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_JOB_TYPE_VAL;
  }

  static validateServiceDesc(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_SERVICE_DESCRIPTION_VAL;
  }

  static validateJobLocation(String value) {
    String patttern = r'(^[a-zA-Z0-9_, ]+$)';
    RegExp regExp =  RegExp(patttern);
    if (!regExp.hasMatch(value.trim())) {
      return MessageConstant.ENTER_JOB_LOCATION_VAL;
    } else {
      return null;
    }

  }

  static validateRole(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.DESCRIBE_ROLE_VAL;
  }
  static validateBio(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_BIO_VAL;
  }
  static validateAdvisorBio(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_BIO_ADVISOR_VAL;
  }
  static validateProjectArea(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_PROJECT_AREA_VAL;
  }
  static validateDescription(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.DESCRIBE_DESCRIPTION_VAL;
  }
  static validateFees(String value) {
    if (value.trim().isNotEmpty)
      return null;
    else
      return MessageConstant.DESCRIBE_FEES_VAL;
  }

  static validateDuration(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_DURATION_VAL;
  }

  static validateStatus(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_STATUS_VAL;
  }

  static validateTitle(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_TITLE_VAL;
  }

  static validateTextToDisplay(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_DISPLAY_VAL;
  }

  static validateAgeFrom(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_FROM_AGE_VAL;
  }

  static validateAgeTo(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_TO_AGE_VAL;
  }

  static validateInterest(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_INTEREST_VAL;
  }

  static validateDateFrom(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.SELECT_FROM_DATE_VAL;
  }

  static validateDateTo(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.SELECT_TO_DATE_VAL;
  }
  static validateTimeFrom(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.SELECT_FROM_TIME_VAL;
  }

  static validateTimeTo(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.SELECT_TO_TIME_VAL;
  }

  static validateGroupName(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_GROUP_NAME_VAL;
  }

  static validateAboutGroup(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_GROUP_ABOUT_VAL;
  }

  static validateGroupOtherInfo(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_OTHER_INFORMATION_VAL;
  }

  static validateExpiryDate(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.ENTER_EXPIRATION_DATE_VAL;
  }

  static validateCallToAction(String value) {
    if (value != null && value.isNotEmpty)
      return null;
    else
      return MessageConstant.SELECT_ATLEAST_ONE_SECTON_VAL;
  }




  static validatePosition(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_POSITION_VAL;
  }

  static validateLabel(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_LABEL_VAL;
  }

  static validateValue(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_VALUE_VAL;
  }


  static validateClubName(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_CLUB_NAME_VAL;
  }

  static validateTeamName(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_TEAM_NAME_VAL;
  }

  static validateCity(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_CITY;
  }


  static validateState(String value) {
    if (value.isNotEmpty)
      return null;
    else
      return MessageConstant.REQUIRED_STATE;
  }


  static bool isName(String em) {
    return RegExp(r"^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$").hasMatch(em.trim());
  }
  static validateJurseyNumber(String value) {
    String patttern = r'(^(?:[+0]9)?[0-9]{1,10}$)';
    RegExp regExp =  RegExp(patttern);
    if (!regExp.hasMatch(value.trim())) {
      return MessageConstant.REQUIRED_JURSEY;
    } else {
      return null;
    }
    return null;
  }

  static  bool isEmail(String em) {
    String emailRegexp =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

    RegExp regExp = RegExp(emailRegexp);

    return regExp.hasMatch(em.trim());
  }




  static isPublicUrlName(String value) {
    RegExp exp =  RegExp(r'^[a-zA-Z0-9]+$');
    bool isLink = exp.hasMatch(value);
    if (isLink)
      return true;
    else
      return false;
  }
}
