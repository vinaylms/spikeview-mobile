import 'package:flutter/cupertino.dart';
import 'package:flutter/painting.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ScreenNameConstant {

  //------------Common for all Role----------



  static const feed_page = 'FeedActivity';
  static const group_listing_page = 'GroupListingActivity';
  static const group_detail_page = 'GroupDetailActivity';
  static const chat_listing_page = 'ChatListingActivity';
  static const chat_page = 'ChatActivity';
  static const connection_request_activity = 'ConnectionRequestActivity';
  static const connection_activity = 'ConnectionActivity';
  static const notification_activity = 'NotificationActivity';
  static const search_activity = 'SearchFriendActivity';
  static const search_opportunity = 'SearchOpportunityActivity';

//------------Student Role----------
  static const student_dasboard = 'StudentDashBoardActivity';
  static const add_education= 'AddEducationActivity';
  static const add_summary= 'AddSummaryActivity';
  static const add_accomplishment= 'AddAccomplishmentActivity';
  static const add_posrtfolio= 'AddPortfolioActivity';
  static const add_test_score= 'AddTestScoreActivity';
  static const add_interest= 'AddInetrestActivity';
  static const add_skill= 'AddSkillActivity';
  static const add_certificate= 'AddCertificateActivity';
  static const add_recommendation= 'AddRecommendationActivity';
  static const add_social= 'AddSocialActivity';
  static const add_resume= 'AddResumeActivity';
  static const share_profile= 'ShareProfileActivity';
  static const add_post= 'AddPostActivity';


  //------------Parent Role----------
  static const parent_dasboard = 'ParentDashBoardActivity';
  static const parent_add_student= 'ParentAddStudentActivity';


  //------------Partner Role----------
  static const partner_dasboard = 'PartnerDashBoardActivity';
  static const create_opp_activity = 'CreateOpportunityActivity';

}
