import 'dart:async';

import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/group/AboutGroupWidget.dart';
import 'package:spike_view_project/group/AddGroupWidget.dart';
import 'package:spike_view_project/group/AddGroupWidgetForParent.dart';
import 'package:spike_view_project/group/EditGroupWidget.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/group/GroupDiscoverWidget.dart';
import 'package:spike_view_project/group/ViewAllGroupList.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/report/ReportWidget.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';

// Create a Form Widget
class GroupBaseWidget extends StatefulWidget {
  String userId;
  final GlobalKey<ScaffoldState> _scaffoldKey;
  int notificationCount = 0;

  GroupBaseWidget(this.userId, this._scaffoldKey, this.notificationCount);

  @override
  GroupBaseWidgetState createState() {
    return GroupBaseWidgetState(notificationCount);
  }
}

class GroupBaseWidgetState extends State<GroupBaseWidget>
    with AutomaticKeepAliveClientMixin {
  List<GroupModel> groupList = List();
  GroupListModel groupListModel;
  bool isLoading = true;
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isParent = false;
  int notificationCount = 0;
  StreamSubscription<dynamic> _streamSubscription;

  StreamSubscription<dynamic> _streamSubscriptionForNotification;

  GroupBaseWidgetState(this.notificationCount);

  Future apiCallForGet() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        Response response;
        response = await ApiCalling().apiCall(context,
            Constant.ENDPOINT_GROUPS_ALL + widget.userId + "/" + roleId, "get");

        print("+++++" +
            Constant.ENDPOINT_GROUPS_ALL +
            widget.userId +
            "/" +
            roleId);

        isLoading = false;
        setState(() {
          isLoading;
        });

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              bloc.fetchGroup(userIdPref, context, prefs, true);

              groupList.clear();
              groupListModel = ParseJson.parseGroupDataAdminFlagChanges(
                  response.data['result'], widget.userId, roleId, "");
              if (groupListModel.groupList.length > 0) {
                setState(() {
                  groupList.addAll(groupListModel.groupList);
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallForGetOnListenEvent() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        Response response;
        response = await ApiCalling().apiCall(context,
            Constant.ENDPOINT_GROUPS_ALL + widget.userId + "/" + roleId, "get");

        print("+++++" +
            Constant.ENDPOINT_GROUPS_ALL +
            widget.userId +
            "/" +
            roleId);
        isLoading = false;
        setState(() {
          isLoading;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              bloc.fetchGroup(userIdPref, context, prefs, true);

              groupList.clear();
              groupListModel = ParseJson.parseGroupDataAdminFlagChanges(
                  response.data['result'], widget.userId, roleId, "");
              if (groupListModel.groupList.length > 0) {
                setState(() {
                  groupList.addAll(groupListModel.groupList);
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  String sasToken, containerName;

  Future apiCallingDeleteGroup(GroupModel groupListModel) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {"groupId": int.parse(groupListModel.groupId)};
        print("test++++" + map.toString());
        response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_ADD_GROUP, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              apiCallForGet();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCallingForAccept(groupId, index, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(widget.userId),
          "status": type,
          "isAdmin": true,
          "roleId": int.parse(roleId),
        };
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg);
              apiCallForGet();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      e.toString();
    }
  }

  void showConfirmationAlert(groupId, index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 125.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 80.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Are you sure you want to withdraw?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR,
                                                        fontWeight:
                                                            FontWeight.normal),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 45.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallForDelete(groupId, index);
                                              //share profile
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallForDelete(groupId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "groupId": groupId,
          "status": "Rejected",
          "roleId": int.parse(roleId),
          "isAdmin": true,
          "userId": int.parse(widget.userId),
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_DELETE_GROUP_MEMBER, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              ToastWrap.showToast(msg, context);

              if (mounted) {
                groupListModel.groupRequestList.removeAt(index);

                setState(() {
                  groupListModel.groupRequestList;
                });
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      e.toString();
    }
  }

  Future apiCallingForLeave(groupId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "userId": int.parse(userIdPref),
          "groupId": int.parse(groupId),
          "roleId": int.parse(roleId)
        };
        response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_LEAVE_GROUP, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              apiCallForGet();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas(isShowLoader) async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    // isParent = prefs.getBool("isParent");
    if (roleId == "2") {
      isParent = true;
    }
    isUserRepoted = UserPreference.getIsUserReported();

    ProfileBloc.groupController.stream.listen((map) {
      try {
        if (map != null) {
          print("map Group Data" + map.toString());
          groupList.clear();
          groupListModel = ParseJson.parseGroupDataAdminFlagChanges(
              map, widget.userId, roleId, "");
          if (groupListModel.groupList.length > 0) {
            setState(() {
              groupList.addAll(groupListModel.groupList);
            });
          }
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
        print("stream+++" + e.toString());
      }
      setState(() {});
    });
    bloc.fetchGroup(userIdPref, context, prefs, false);

    print("userId" + userIdPref);
    //apiCallForGet();
    callApiForSaas(false);
    anaylytics.setCurrentSreen(ScreenNameConstant.group_listing_page);
  }

  bool isUserRepoted = true;

  @override
  void initState() {
    getSharedPreferences();

    _streamSubscription =
        DashBoardState.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        setState(() {
          notificationCount;
        });
      }
    });

    DashBoardStateParent.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted)
          setState(() {
            notificationCount;
          });
      }
    });
    DashBoardStatePartner.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted)
          setState(() {
            notificationCount;
          });
      }
    });


    GlobalSocketConnection.groupController.stream.listen((data) async {
      print("Spike report groupid++++" + data);
      if (groupList != null && groupList.length > 0) {
        for (GroupModel model in groupList) {
          print("Spike report groupid++++" + model.groupId.toString());
          if (data.toString() == model.groupId.toString()) {
            apiCallForGet();
            return;
          }
        }
      }
    });

    _streamSubscriptionForNotification =
        SplashScreenState.syncDoneController.stream.listen((value) {
      if (value.toString().toLowerCase().contains('group')) {
        apiCallForGetOnListenEvent();
      }
    });

    _streamSubscription =
        GroupDetailWidgetState.syncDoneController.stream.listen((value) {
      apiCallForGet();
    });

    _streamSubscription =
        AddGroupWidgetState.syncDoneController.stream.listen((value) {
      apiCallForGet();
    });
    _streamSubscription =
        AddGroupWidgetForParentState.syncDoneController.stream.listen((value) {
          apiCallForGet();
        });
    // TODO: implement initState

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above

    onTapDiscover() async {
      String result = await Navigator.push(context,
          MaterialPageRoute(builder: (context) => GroupDiscoverWidget()));
      if (result == "push") {
        apiCallForGet();
      }
    }

    onTapAddGroup() async {
      print("isParent++++" + isParent.toString());
      if (isParent) {
        String result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                AddGroupWidgetForParent(sasToken, containerName)));

        if (result == "push") {
          groupList.clear();
          apiCallForGet();
        }
      } else {
        String result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                AddGroupWidget(sasToken, containerName, "")));

        if (result == "push") {
          groupList.clear();
          apiCallForGet();
        }
      }
    }

    onTapGroupTile(groupModel) async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => GroupDetailWidget(
              groupModel.groupId, "", sasToken, containerName, "")));
      print('refresh++++++++'+result.trim().toString());
    //  if (result == "push") {

        apiCallForGet();
     // }
    }

    onTapViewAll(listType, title) async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => ViewAllGroupListWidget(
              groupListModel, listType, sasToken, containerName, title)));
      if (result == "push") {
        apiCallForGet();
      }
    }

    void leaveConfromAtionDialog(GroupModel groupListModel) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Center(
                                                child: Container(
                                                    child: RichText(
                                                  maxLines: 5,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text: MessageConstant
                                                        .ABOUT_GROUP_LEAVE,
                                                    style: AppTextStyle
                                                        .getDynamicStyleGroup(
                                                            ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            16.0,
                                                            FontType.Regular),
                                                    /*TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),*/
                                                    children: <TextSpan>[
                                                      TextSpan(
                                                          text: "\" " +
                                                              groupListModel
                                                                  .groupName +
                                                              " \"",
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontSize: 16.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR)),
                                                      TextSpan(
                                                        text: MessageConstant
                                                            .ABOUT_GROUP_GROUP_,
                                                        style: AppTextStyle
                                                            .getDynamicStyleGroup(
                                                                ColorValues
                                                                    .HEADING_COLOR_EDUCATION,
                                                                16.0,
                                                                FontType
                                                                    .Regular), /*TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 16.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),*/
                                                      ),
                                                    ],
                                                  ),
                                                )),
                                              ),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        16.0,
                                                        FontType
                                                            .Regular), /*TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant
                                                    .ABOUT_GROUP_LEAVE,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        16.0,
                                                        FontType
                                                            .Regular), /*TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCallingForLeave(
                                                    groupListModel.groupId);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void deleteConfromAtionDialog(GroupModel groupListModel) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Center(
                                                child: Container(
                                                    child: RichText(
                                                  maxLines: 5,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text: MessageConstant
                                                        .ABOUT_GROUP_DELETE1,
                                                    style: AppTextStyle
                                                        .getDynamicStyleGroup(
                                                            ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            16.0,
                                                            FontType.Regular),
                                                    /*TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),*/
                                                    children: <TextSpan>[
                                                      TextSpan(
                                                          text: "\"" +
                                                              groupListModel
                                                                  .groupName +
                                                              "\"",
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontSize: 16.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR)),
                                                      TextSpan(
                                                        text: MessageConstant
                                                            .ABOUT_GROUP_GROUP_,
                                                        style: AppTextStyle
                                                            .getDynamicStyleGroup(
                                                                ColorValues
                                                                    .HEADING_COLOR_EDUCATION,
                                                                16.0,
                                                                FontType
                                                                    .Regular), /*TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 16.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),*/
                                                      ),
                                                    ],
                                                  ),
                                                )),
                                              ),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        16.0,
                                                        FontType
                                                            .Regular), /*TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant
                                                    .ABOUT_GROUP_DELETE1,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        16.0,
                                                        FontType
                                                            .Regular), /*TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCallingDeleteGroup(
                                                    groupListModel);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    onTapReport(GroupModel groupListModel) async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              Report("group", groupListModel.groupId, "", "")));
      if (result == "push") {
        apiCallForGet();
      }
    }

    void moreOptionIfUserNotAAdmin(GroupModel groupListModel) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child: Container(
                                  height: 210.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        InkWell(
                                                          child: Container(
                                                              height: 50.0,
                                                              padding:
                                                                  EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                              child: Center(
                                                                  child: Text(
                                                                MessageConstant
                                                                    .ABOUT_GROUP_ABOUT_GROUP,
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                maxLines: 5,
                                                                style: AppTextStyle.getDynamicStyleGroupHEIGHT(
                                                                    ColorValues
                                                                        .BLUE_COLOR_BOTTOMBAR,
                                                                    16.0,
                                                                    FontType
                                                                        .Regular,
                                                                    1.2), /*TextStyle(
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    height: 1.2,
                                                                    fontSize:
                                                                        16.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),*/
                                                              ))),
                                                          onTap: () {
                                                            Navigator.pop(
                                                                context);
                                                            GroupDetailModel model = GroupDetailModel(
                                                                "0",
                                                                groupListModel
                                                                    .groupId,
                                                                groupListModel
                                                                    .groupName,
                                                                groupListModel
                                                                    .type,
                                                                groupListModel
                                                                    .creationDate,
                                                                groupListModel
                                                                    .createdBy,
                                                                groupListModel
                                                                    .isActive,
                                                                groupListModel
                                                                    .aboutGroup,
                                                                groupListModel
                                                                    .otherInfo,
                                                                groupListModel
                                                                    .groupImage,
                                                                null,
                                                                groupListModel
                                                                    .isAdmin,
                                                                groupListModel
                                                                    .status,
                                                                null,
                                                                null,
                                                                null,
                                                                false,
                                                                null,
                                                                "");
                                                            Navigator.of(
                                                                    context)
                                                                .push(new MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        AboutGroupWidget(
                                                                            model)));
                                                          },
                                                        )),
                                                    Container(
                                                      height: 1.0,
                                                      color: ColorValues
                                                          .BORDER_COLOR,
                                                    ),
                                                    InkWell(
                                                      child: Container(
                                                          height: 50.0,
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                          child: Center(
                                                              child: Text(
                                                            MessageConstant
                                                                .ABOUT_GROUP_LEAVE_GROUP,
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style: AppTextStyle
                                                                .getDynamicStyleGroupHEIGHT(
                                                                    ColorValues
                                                                        .BLUE_COLOR_BOTTOMBAR,
                                                                    16.0,
                                                                    FontType
                                                                        .Regular,
                                                                    1.2), /* TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),*/
                                                          ))),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        leaveConfromAtionDialog(
                                                            groupListModel);
                                                        //  apiCallingForLeave();
                                                      },
                                                    ),
                                                    Container(
                                                      height: 1.0,
                                                      color: ColorValues
                                                          .BORDER_COLOR,
                                                    ),
                                                    InkWell(
                                                      child: Container(
                                                          height: 50.0,
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                          child: Center(
                                                              child: Text(
                                                            MessageConstant
                                                                .ABOUT_GROUP_SUPPORT_REPORT_GROUP,
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style: AppTextStyle
                                                                .getDynamicStyleGroupHEIGHT(
                                                                    ColorValues
                                                                        .BLUE_COLOR_BOTTOMBAR,
                                                                    16.0,
                                                                    FontType
                                                                        .Regular,
                                                                    1.2), /* TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),*/
                                                          ))),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        onTapReport(
                                                            groupListModel);
                                                        //  apiCallingForLeave();
                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        16.0,
                                                        FontType
                                                            .Regular), /*TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    onTapEditGroup(GroupModel groupListModel) async {
      GroupDetailModel model = GroupDetailModel(
          "0",
          groupListModel.groupId,
          groupListModel.groupName,
          groupListModel.type,
          groupListModel.creationDate,
          groupListModel.createdBy,
          groupListModel.isActive,
          groupListModel.aboutGroup,
          groupListModel.otherInfo,
          groupListModel.groupImage,
          null,
          groupListModel.isAdmin,
          groupListModel.status,
          null,
          null,
          null,
          false,
          null,
          "");

      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              EditGroupWidget(model, sasToken, containerName)));
      if (result == "push") {
        apiCallForGet();
      }
    }

    void moreOptionIfUserAdmin(GroupModel groupListModel) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child: Container(
                                  height: 160.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Container(
                                                      height: 1.0,
                                                      color: ColorValues
                                                          .BORDER_COLOR,
                                                    ),
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        InkWell(
                                                          child: Container(
                                                              height: 50.0,
                                                              padding:
                                                                  EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                              child: Center(
                                                                  child: Text(
                                                                MessageConstant
                                                                    .ABOUT_GROUP_EDIT_GROUP,
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                maxLines: 5,
                                                                style: AppTextStyle.getDynamicStyleGroupHEIGHT(
                                                                    ColorValues
                                                                        .BLUE_COLOR_BOTTOMBAR,
                                                                    16.0,
                                                                    FontType
                                                                        .Regular,
                                                                    1.2), /*TextStyle(
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    height: 1.2,
                                                                    fontSize:
                                                                        16.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),*/
                                                              ))),
                                                          onTap: () {
                                                            Navigator.pop(
                                                                context);
                                                            onTapEditGroup(
                                                                groupListModel);
                                                          },
                                                        )),
                                                    Container(
                                                      height: 1.0,
                                                      color: ColorValues
                                                          .BORDER_COLOR,
                                                    ),
                                                    InkWell(
                                                      child: Container(
                                                          height: 50.0,
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                          child: Center(
                                                              child: Text(
                                                            MessageConstant
                                                                .ABOUT_GROUP_DELETE_GROUP,
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style: AppTextStyle
                                                                .getDynamicStyleGroupHEIGHT(
                                                                    ColorValues
                                                                        .BLUE_COLOR_BOTTOMBAR,
                                                                    16.0,
                                                                    FontType
                                                                        .Regular,
                                                                    1.2), /* TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),*/
                                                          ))),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        deleteConfromAtionDialog(
                                                            groupListModel);
                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        16.0,
                                                        FontType
                                                            .Regular), /*TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    Widget getListview(groupModel, index, request) {
      print("url" + groupModel.groupImage);

      return PaddingWrap.paddingfromLTRB(
        15.0,
        0.0,
        15.0,
        0.0,
        InkWell(
          child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  border:
                      Border.all(color: ColorValues.DEVIDER_COLOR, width: 0.5)),
              padding: EdgeInsets.fromLTRB(10.0, 15.0, 10.0, 15.0),
              child: Card(
                  color: Colors.transparent,
                  elevation: 0.0,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            child: InkWell(
                              child: Container(
                                height: 60.0,
                                width: 60.0,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(100),
                                  child: groupModel.groupImage == "" ||
                                          groupModel.groupImage == "null"
                                      ? Image.asset(
                                          'assets/newDesignIcon/group/default_circle_bg.png')
                                      : FadeInImage(
                                          fit: BoxFit.cover,
                                          placeholder: AssetImage(
                                            'assets/newDesignIcon/group/default_circle_bg.png',
                                          ),
                                          image: NetworkImage(
                                              Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getSmallImage(
                                                      groupModel.groupImage)),
                                        ),
                                ),
                              ),
                            ),
                            flex: 0,
                          ),
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                5.0,
                                5.0,
                                0.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        7.0,
                                        2.0,
                                        2.0,
                                        5.0,
                                        RichText(
                                          maxLines: 2,
                                          textAlign: TextAlign.start,
                                          text: TextSpan(
                                            text: groupModel.groupName + " ",
                                            style: AppTextStyle
                                                .getDynamicStyleGroup(
                                                    ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    14.0,
                                                    FontType.Bold),
                                            /*TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.bold,
                                            ),*/
                                            children: (!groupModel.isAdmin)
                                                ? null
                                                : <TextSpan>[
                                                    TextSpan(
                                                      text: '(Owner)',
                                                      style: AppTextStyle
                                                          .getDynamicStyleGroup(
                                                              ColorValues
                                                                  .GREY_TEXT_COLOR,
                                                              12.0,
                                                              FontType
                                                                  .Regular), /*TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR,
                                                            fontSize: 12.0,
                                                            color:  Color(
                                                                0xFF404040))*/
                                                    )
                                                  ],
                                          ),
                                        )),
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                7.0,
                                                3.0,
                                                0.0,
                                                0.0,
                                                Image.asset(
                                                  groupModel.type == "private"
                                                      ? "assets/newDesignIcon/group/private_grey.png"
                                                      : "assets/newDesignIcon/group/public_grey.png",
                                                  height: 15.0,
                                                  width: 15.0,
                                                ),
                                              ),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  3.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap.textViewMultiLine(
                                                      groupModel
                                                                  .type ==
                                                              "private"
                                                          ? MessageConstant
                                                              .ABOUT_GROUP_PRIVATE_GROUP
                                                          : MessageConstant
                                                              .ABOUT_GROUP_PUBLIC_GROUP,
                                                      TextAlign.center,
                                                      ColorValues
                                                          .GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal,
                                                      1))
                                            ],
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    )
                                  ],
                                )),
                            flex: 1,
                          ),
                          isUserRepoted
                              ? request == ""
                                  ? Expanded(
                                      child: InkWell(
                                        child: Align(
                                            alignment: Alignment.topRight,
                                            child: PaddingWrap.paddingfromLTRB(
                                              5.0,
                                              0.0,
                                              0.0,
                                              0.0,
                                              Image.asset(
                                                "assets/more_grey.png",
                                                width: 25.0,
                                                height: 25.0,
                                              ),
                                            )),
                                        onTap: () {
                                          if (groupModel.status ==
                                                  MessageConstant
                                                      .ABOUT_GROUP_ACCEPTED &&
                                              groupModel.isAdmin) {
                                            moreOptionIfUserAdmin(groupModel);
                                          } else {
                                            moreOptionIfUserNotAAdmin(
                                                groupModel);
                                          }
                                        },
                                      ),
                                      flex: 0,
                                    )
                                  : Container(
                                      height: 0.0,
                                    )
                              : Container(
                                  height: 0.0,
                                )
                        ],
                      ),
                      groupModel.status == "Invited"
                          ? Column(children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  10.0,
                                  20.0,
                                  10.0,
                                  0.0,
                                  Divider(
                                    color: ColorValues.GREY_TEXT_COLOR,
                                    height: 0.5,
                                  )),
                              Row(
                                children: <Widget>[
                                  Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        20.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                        TextViewWrap.textView(
                                            MessageConstant
                                                .ABOUT_GROUP_GROUP_INVITATION,
                                            TextAlign.start,
                                            ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.normal)),
                                    flex: 1,
                                  ),
                                  Expanded(
                                    child: InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          10.0,
                                          0.0,
                                          0.0,
                                          Image.asset(
                                            "assets/newDesignIcon/connections/tick_blue.png",
                                            height: 40.0,
                                            width: 40.0,
                                          )),
                                      onTap: () {
                                        apiCallingForAccept(
                                            groupModel.groupId,
                                            0,
                                            MessageConstant
                                                .ABOUT_GROUP_ACCEPTED);
                                      },
                                    ),
                                    flex: 0,
                                  ),
                                  Expanded(
                                    child: InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          2.0,
                                          10.0,
                                          5.0,
                                          0.0,
                                          Image.asset(
                                            "assets/newDesignIcon/navigation/cancel_circle.png",
                                            height: 40.0,
                                            width: 40.0,
                                          )),
                                      onTap: () {
                                        apiCallingForAccept(
                                            groupModel.groupId,
                                            0,
                                            MessageConstant
                                                .ABOUT_GROUP_REJECTED);
                                      },
                                    ),
                                    flex: 0,
                                  )
                                ],
                              )
                            ])
                          : groupModel.status == "Requested"
                              ? Column(children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      20.0,
                                      10.0,
                                      0.0,
                                      Divider(
                                        color: ColorValues.GREY_TEXT_COLOR,
                                        height: 0.5,
                                      )),
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            10.0,
                                            0.0,
                                            0.0,
                                            TextViewWrap.textView(
                                                MessageConstant
                                                    .ABOUT_GROUP_REQUEST_PENDING,
                                                TextAlign.start,
                                                ColorValues
                                                    .HEADING_COLOR_EDUCATION,
                                                14.0,
                                                FontWeight.normal)),
                                        flex: 1,
                                      ),
                                      Expanded(
                                        child: InkWell(
                                          child: PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              10.0,
                                              0.0,
                                              0.0,
                                              Text(
                                                MessageConstant
                                                    .ABOUT_GROUP_REVOKE,
                                                style: AppTextStyle
                                                    .getDynamicStyleGroup(
                                                        ColorValues
                                                            .BOTTOAMBAR_ADD_BG_COLOUR,
                                                        12.0,
                                                        FontType
                                                            .Regular), /*TextStyle(
                                                    color:   ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                                    fontSize: 12.0,
                                                    fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                          onTap: () {
                                            showConfirmationAlert(
                                                groupModel.groupId, index);
                                            //   apiCallForDelete(groupModel.groupId, index);
                                          },
                                        ),
                                        flex: 0,
                                      ),
                                    ],
                                  ),
                                ])
                              : Container(
                                  height: 0.0,
                                )
                    ],
                  ))),
          onTap: () {
            onTapGroupTile(groupModel);
          },
        ),
      );
    }

    Widget getListviewForChild(groupModel, index) {
      print("url" + groupModel.groupImage);

      return PaddingWrap.paddingfromLTRB(
        10.0,
        0.0,
        10.0,
        0.0,
        InkWell(
          child: Container(
              padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 5.0),
              child: Card(
                  color: Colors.transparent,
                  elevation: 0.0,
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: InkWell(
                              child: Container(
                                height: 60.0,
                                width: 60.0,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(100),
                                  child: groupModel.groupImage == "" ||
                                          groupModel.groupImage == "null"
                                      ? Image.asset(
                                          'assets/newDesignIcon/group/default_circle_bg.png')
                                      : FadeInImage(
                                          fit: BoxFit.cover,
                                          placeholder: AssetImage(
                                            'assets/newDesignIcon/group/default_circle_bg.png',
                                          ),
                                          image: NetworkImage(
                                              Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getSmallImage(
                                                      groupModel.groupImage)),
                                        ),
                                ),
                              ),
                            ),
                            flex: 0,
                          ),
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                0.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        7.0,
                                        2.0,
                                        2.0,
                                        5.0,
                                        RichText(
                                          maxLines: 2,
                                          textAlign: TextAlign.start,
                                          text: TextSpan(
                                            text: groupModel.groupName + " ",
                                            style: AppTextStyle
                                                .getDynamicStyleGroup(
                                                    ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    14.0,
                                                    FontType.Bold),
                                            /*TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.bold,
                                            ),*/
                                            children: (!groupModel.isAdmin)
                                                ? null
                                                : <TextSpan>[
                                                    TextSpan(
                                                        text: '(Owner)',
                                                        style: TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR,
                                                            fontSize: 12.0,
                                                            color: Color(
                                                                0xFF404040)))
                                                  ],
                                          ),
                                        )),
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                7.0,
                                                3.0,
                                                0.0,
                                                0.0,
                                                Image.asset(
                                                  groupModel.type == "private"
                                                      ? "assets/newDesignIcon/group/private_grey.png"
                                                      : "assets/newDesignIcon/group/public_grey.png",
                                                  height: 15.0,
                                                  width: 15.0,
                                                ),
                                              ),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  3.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap.textViewMultiLine(
                                                      groupModel
                                                                  .type ==
                                                              "private"
                                                          ? MessageConstant
                                                              .ABOUT_GROUP_PRIVATE_GROUP
                                                          : MessageConstant
                                                              .ABOUT_GROUP_PUBLIC_GROUP,
                                                      TextAlign.center,
                                                      ColorValues
                                                          .GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal,
                                                      1))
                                            ],
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    )
                                  ],
                                )),
                            flex: 1,
                          ),
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                              5.0,
                              0.0,
                              0.0,
                              0.0,
                              Column(children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            10.0,
                                            0.0,
                                            0.0,
                                            Image.asset(
                                              "assets/newDesignIcon/connections/tick_blue.png",
                                              height: 40.0,
                                              width: 40.0,
                                            )),
                                        onTap: () {
                                          apiCallingForAccept(
                                              groupModel.groupId,
                                              0,
                                              MessageConstant
                                                  .ABOUT_GROUP_ACCEPTED);
                                        },
                                      ),
                                      flex: 0,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: PaddingWrap.paddingfromLTRB(
                                            2.0,
                                            10.0,
                                            5.0,
                                            0.0,
                                            Image.asset(
                                              "assets/newDesignIcon/navigation/cancel_circle.png",
                                              height: 40.0,
                                              width: 40.0,
                                            )),
                                        onTap: () {
                                          apiCallingForAccept(
                                              groupModel.groupId,
                                              0,
                                              MessageConstant
                                                  .ABOUT_GROUP_REJECTED);
                                        },
                                      ),
                                      flex: 0,
                                    )
                                  ],
                                ),
                              ]),
                            ),
                            flex: 0,
                          ),
                        ],
                      ),
                      PaddingWrap.paddingfromLTRB(
                          10.0,
                          16.0,
                          10.0,
                          0.0,
                          Divider(
                            color: ColorValues.GREY_TEXT_COLOR,
                            height: 0.5,
                          )),
                    ],
                  ))),
          onTap: () {
            onTapGroupTile(groupModel);
          },
        ),
      );
    }

    Future<Null> _refreshPageHere() async {
      apiCallForGet();
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: Scaffold(
          backgroundColor: ColorValues.singin_bg_color,
          appBar: CustomViews.getAppBar(
              "Groups", widget._scaffoldKey, context, prefs, notificationCount),
          body: RefreshIndicator(
              onRefresh: _refreshPageHere,
              displacement: 0.0,
              child: Container(
                child: groupListModel == null
                    ? Container(
                        height: 0.0,
                      )
                    : groupListModel.groupInvitationList.length == 0 &&
                            groupListModel.groupList.length == 0 &&
                            groupListModel.groupRequestList.length == 0 &&
                            groupListModel.childInvitationList.length == 0
                        ? ListView(
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.all(13.0),
                                child: Container(
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(
                                        color: ColorValues.DARK_GREY),
                                  ),
                                  child: Column(
                                    children: <Widget>[
                                      Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              30, 10, 30, 7),
                                          child: Image.asset(
                                            "assets/no_group.png",
                                            height: 150.0,
                                            width: 300.0,
                                          )),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            30, 10, 30, 7),
                                        child: Text(
                                          MessageConstant
                                              .ABOUT_GROUP_GO_AHEAD_SETUP,
                                          style:
                                              AppTextStyle.getDynamicStyleGroup(
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  16.0,
                                                  FontType.Bold),
                                          /*TextStyle(
                                              color: ColorValues.GREY_TEXT_COLOR,
                                              fontFamily: Constant.TYPE_CUSTOMBOLD,
                                              fontSize: 16),*/
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13, 0, 13, 2),
                                        child: Text(
                                          MessageConstant
                                              .ABOUT_GROUP_IT_LOOKS_LIKEHAVENT,
                                          style:
                                              AppTextStyle.getDynamicStyleGroup(
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  14.0,
                                                  FontType.Regular),
                                          /*TextStyle(
                                              color: ColorValues.GREY_TEXT_COLOR,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 14),*/
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0, 7, 0, 10),
                                        child: InkWell(
                                          child: Text(
                                            MessageConstant
                                                .ABOUT_GROUP_CREATE_GROUP,
                                            style: AppTextStyle
                                                .getDynamicStyleGroup(
                                                    ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    14.0,
                                                    FontType.Regular),
                                            /*TextStyle(
                                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                fontSize: 14),*/
                                            textAlign: TextAlign.center,
                                          ),
                                          onTap: () {
                                            onTapAddGroup();
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              groupListModel.groupRequestList.length == 0
                                  ? Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                15.0, 10.0, 15.0, 0.0),
                                            child: Container(
                                              child: Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Padding(
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                13.0,
                                                                0.0,
                                                                0.0,
                                                                0.0),
                                                        child: Text(
                                                          MessageConstant
                                                              .ABOUT_GROUP_FIND_GROUP_JOIN,
                                                          style: AppTextStyle
                                                              .getDynamicStyleGroup(
                                                                  ColorValues
                                                                      .HEADING_COLOR_EDUCATION,
                                                                  12.0,
                                                                  FontType
                                                                      .Regular), /*TextStyle(
                                                        fontSize: 12.0,
                                                        color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontFamily: Constant
                                                            .customRegular),*/
                                                        )),
                                                    flex: 1,
                                                  ),
                                                ],
                                              ),
                                              color: ColorValues
                                                  .GREY__COLOR_DIVIDER,
                                              height: 24.0,
                                            )),
                                        PaddingWrap.paddingfromLTRB(
                                            15.0,
                                            0.0,
                                            15.0,
                                            10.0,
                                            new Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border.all(
                                                      color: ColorValues
                                                          .DEVIDER_COLOR,
                                                      width: 0.5)),
                                              child: Container(
                                                width: double.infinity,
                                                child: Column(
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        10.0,
                                                        0.0,
                                                        0.0,
                                                        Image.asset(
                                                          "assets/group_i_want.png",
                                                          height: 140.0,
                                                          width: 245.0,
                                                        )),
                                                    Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          30, 6, 30, 3),
                                                      child: Text(
                                                        MessageConstant
                                                            .ABOUT_GROUP_DISCOVER_GROUP,
                                                        style: AppTextStyle
                                                            .getDynamicStyleGroup(
                                                                ColorValues
                                                                    .GREY_TEXT_COLOR,
                                                                16.0,
                                                                FontType.Bold),
                                                        /*TextStyle(
                                                  color:
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  fontFamily:
                                                  Constant.TYPE_CUSTOMBOLD,
                                                  fontSize: 16),*/
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          13, 0, 13, 2),
                                                      child: Text(
                                                        MessageConstant
                                                            .ABOUT_GROUP_DO_INTERESTS_PASSIONS,
                                                        style: AppTextStyle
                                                            .getDynamicStyleGroup(
                                                                ColorValues
                                                                    .GREY_TEXT_COLOR,
                                                                14.0,
                                                                FontType
                                                                    .Regular),
                                                        /*TextStyle(
                                                  color:
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR,
                                                  fontSize: 14),*/
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          0, 10, 0, 10),
                                                      child: InkWell(
                                                        child: Text(
                                                          MessageConstant
                                                              .ABOUT_GROUP_DISCOVER,
                                                          style: AppTextStyle
                                                              .getDynamicStyleGroup(
                                                                  ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  14.0,
                                                                  FontType
                                                                      .Regular),
                                                          /*TextStyle(
                                                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 14),*/
                                                          textAlign:
                                                              TextAlign.center,
                                                        ),
                                                        onTap: () {
                                                          onTapDiscover();
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            )),
                                      ],
                                    )
                                  : Container(
                                      height: 0.0,
                                    ),
                            ],
                          )
                        : ListView(
                            children: <Widget>[
                              Column(children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        isUserRepoted
                                            ? Expanded(
                                                child:
                                                    PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        10.0,
                                                        5.0,
                                                        10.0,
                                                        InkWell(
                                                          child: Container(
                                                              height: 32.0,
                                                              width: 232.0,
                                                              decoration: BoxDecoration(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  border: Border.all(
                                                                      color: ColorValues
                                                                          .BLUE_COLOR_BOTTOMBAR)),
                                                              child: Row(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: <
                                                                    Widget>[
                                                                  Text(
                                                                    MessageConstant
                                                                        .ABOUT_GROUP_CREATE_GROUP,
                                                                    style: AppTextStyle.getDynamicStyleGroup(
                                                                        ColorValues
                                                                            .WHITE,
                                                                        14.0,
                                                                        FontType
                                                                            .Regular), /*TextStyle(
                                                              color:
                                                                  Colors.white,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR,
                                                              fontSize: 14.0),*/
                                                                  )
                                                                ],
                                                              )),
                                                          onTap: () {
                                                            onTapAddGroup();
                                                          },
                                                        )),
                                                flex: 0,
                                              )
                                            : Container(
                                                height: 0.0,
                                              ),
                                      ],
                                    )),
                              ]),
                              roleId == "2" &&
                                      groupListModel
                                              .childInvitationList.length >
                                          0
                                  ? Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            10.0,
                                            0.0,
                                            0.0,
                                            Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    15.0, 5.0, 15.0, 0.0),
                                                child: Container(
                                                  child: Row(
                                                    children: <Widget>[
                                                      Expanded(
                                                        child: Padding(
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    13.0,
                                                                    5.0,
                                                                    0.0,
                                                                    5.0),
                                                            child: Text(
                                                              "APPROVE REQUEST FOR STUDENT(S) (" +
                                                                  groupListModel
                                                                      .childInvitationList
                                                                      .length
                                                                      .toString() +
                                                                  ")",
                                                              style: AppTextStyle
                                                                  .getDynamicStyleGroup(
                                                                      ColorValues
                                                                          .HEADING_COLOR_EDUCATION,
                                                                      12.0,
                                                                      FontType
                                                                          .Regular), /*TextStyle(
                                                                  fontSize:
                                                                      12.0,
                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontFamily:
                                                                      Constant
                                                                          .customRegular),*/
                                                            )),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: groupListModel
                                                                    .childInvitationList
                                                                    .length >
                                                                2
                                                            ? InkWell(
                                                                child: Container(
                                                                    height: 40.0,
                                                                    child: Padding(
                                                                        padding: EdgeInsets.fromLTRB(10.0, 3.0, 13.0, 0.0),
                                                                        child: Text(
                                                                          MessageConstant
                                                                              .ABOUT_GROUP_VIEW_ALL,
                                                                          style: AppTextStyle.getDynamicStyleGroup(
                                                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                              14.0,
                                                                              FontType.Regular), /*TextStyle(
                                                                              fontSize: 14.0,
                                                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                              fontFamily: Constant.customRegular),*/
                                                                        ))),
                                                                onTap: () {
                                                                  onTapViewAll(
                                                                      "CHILD_Invited",
                                                                      "Invitation Received");
                                                                },
                                                              )
                                                            : Container(
                                                                height: 0.0,
                                                              ),
                                                        flex: 0,
                                                      )
                                                    ],
                                                  ),
                                                  color: ColorValues
                                                      .LIGHT_GREY_TEXT_COLOR,
                                                  height: 25.0,
                                                ))),
                                        PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            0.0,
                                            0.0,
                                            PaddingWrap.paddingfromLTRB(
                                                13.0,
                                                0.0,
                                                13.0,
                                                0.0,
                                                Container(
                                                    decoration: BoxDecoration(
                                                        color: Colors.white,
                                                        border: Border.all(
                                                            color: ColorValues
                                                                .DEVIDER_COLOR,
                                                            width: 0.5)),
                                                    child: Column(
                                                      children: List.generate(
                                                          groupListModel
                                                                      .childInvitationList
                                                                      .length >
                                                                  2
                                                              ? 2
                                                              : groupListModel
                                                                  .childInvitationList
                                                                  .length,
                                                          (int index) {
                                                        return PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                10.0,
                                                                Column(
                                                                  children: <
                                                                      Widget>[
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                            12.0,
                                                                            10.0,
                                                                            12.0,
                                                                            0.0,
                                                                            Column(
                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: <Widget>[
                                                                                PaddingWrap.paddingfromLTRB(
                                                                                    10.0,
                                                                                    10.0,
                                                                                    0.0,
                                                                                    0.0,
                                                                                    RichText(
                                                                                      textAlign: TextAlign.start,
                                                                                      text: TextSpan(
                                                                                        children: <TextSpan>[
                                                                                          TextSpan(text: "For ", style: TextStyle(fontFamily: Constant.customBold, fontSize: 14.0, color: ColorValues.HEADING_COLOR_EDUCATION)),
                                                                                          TextSpan(
                                                                                            text: groupListModel.childInvitationList[index].studentName,
                                                                                            style: AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Bold), /*TextStyle(
                                                                                fontFamily: Constant.customBold,
                                                                                fontSize: 16.0,
                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION)*/
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    )),
                                                                                PaddingWrap.paddingfromLTRB(
                                                                                    10.0,
                                                                                    10.0,
                                                                                    10.0,
                                                                                    16.0,
                                                                                    Divider(
                                                                                      color: ColorValues.GREY_TEXT_COLOR,
                                                                                      height: 0.5,
                                                                                    )),
                                                                              ],
                                                                            )),
                                                                    Column(
                                                                        crossAxisAlignment: CrossAxisAlignment
                                                                            .start,
                                                                        children: List.generate(
                                                                            groupListModel.childInvitationList[index].invitationList.length,
                                                                            (int
                                                                                index2) {
                                                                          return getListviewForChild(
                                                                              groupListModel.childInvitationList[index].invitationList[index2],
                                                                              index);
                                                                        })),
                                                                  ],
                                                                ));
                                                      }),
                                                    )))),
                                      ],
                                    )
                                  : Container(
                                      height: 0.0,
                                    ),
                              groupListModel.groupInvitationList.length == 0
                                  ? Container(
                                      height: 0,
                                    )
                                  : PaddingWrap.paddingfromLTRB(
                                      15.0,
                                      10.0,
                                      15.0,
                                      0.0,
                                      Container(
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      13.0, 5.0, 0.0, 5.0),
                                                  child: Text(
                                                    MessageConstant
                                                            .ABOUT_GROUP_RECEIVED_REQUEST_FORYOU +
                                                        " (" +
                                                        groupListModel
                                                            .groupInvitationList
                                                            .length
                                                            .toString() +
                                                        ")",
                                                    style: AppTextStyle
                                                        .getDynamicStyleGroup(
                                                            ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            12.0,
                                                            FontType
                                                                .Regular), /*TextStyle(
                                                        fontSize: 12.0,
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontFamily: Constant
                                                            .customRegular),*/
                                                  )),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: groupListModel
                                                          .groupInvitationList
                                                          .length >
                                                      2
                                                  ? InkWell(
                                                      child: Container(
                                                          height: 40.0,
                                                          child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .fromLTRB(
                                                                          10.0,
                                                                          3.0,
                                                                          13.0,
                                                                          0.0),
                                                              child: Text(
                                                                MessageConstant
                                                                    .ABOUT_GROUP_VIEW_ALL,
                                                                style: AppTextStyle
                                                                    .getDynamicStyleGroup(
                                                                        ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR,
                                                                        14.0,
                                                                        FontType
                                                                            .Regular), /*TextStyle(
                                                                    fontSize:
                                                                        14.0,
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    fontFamily:
                                                                        Constant
                                                                            .customRegular),*/
                                                              ))),
                                                      onTap: () {
                                                        onTapViewAll("Invited",
                                                            "Invitation Received");
                                                      },
                                                    )
                                                  : Container(
                                                      height: 0.0,
                                                    ),
                                              flex: 0,
                                            )
                                          ],
                                        ),
                                        color:
                                            ColorValues.LIGHT_GREY_TEXT_COLOR,
                                        height: 25.0,
                                      )),
                              groupListModel.groupInvitationList.length == 0
                                  ? Container(
                                      height: 0,
                                    )
                                  : PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                      Column(
                                        children: List.generate(
                                            groupListModel.groupInvitationList
                                                        .length >
                                                    2
                                                ? 2
                                                : groupListModel
                                                    .groupInvitationList
                                                    .length, (int index) {
                                          return getListview(
                                              groupListModel
                                                  .groupInvitationList[index],
                                              index,
                                              "request");
                                        }),
                                      )),
                              groupListModel.groupList.length > 0
                                  ? PaddingWrap.paddingfromLTRB(
                                      15.0,
                                      10.0,
                                      15.0,
                                      0.0,
                                      Container(
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      13.0, 5.0, 0.0, 5.0),
                                                  child: Text(
                                                    groupListModel.groupList
                                                                .length ==
                                                            1
                                                        ? MessageConstant
                                                                .ABOUT_GROUP_MY_GROUP_S +
                                                            " (" +
                                                            groupListModel
                                                                .groupList
                                                                .length
                                                                .toString() +
                                                            ")"
                                                        : MessageConstant
                                                                .ABOUT_GROUP_MY_GROUP_S +
                                                            " (" +
                                                            groupListModel
                                                                .groupList
                                                                .length
                                                                .toString() +
                                                            ")",
                                                    style: AppTextStyle
                                                        .getDynamicStyleGroup(
                                                            ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            12.0,
                                                            FontType
                                                                .Regular), /*TextStyle(
                                                        fontSize: 12.0,
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontFamily: Constant
                                                            .customRegular),*/
                                                  )),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                        color:
                                            ColorValues.LIGHT_GREY_TEXT_COLOR,
                                        height: 25.0,
                                      ))
                                  : Container(
                                      height: 0.0,
                                    ),
                              groupListModel.groupList.length > 0
                                  ? PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                      Column(
                                        children: List.generate(
                                            groupListModel.groupList.length,
                                            (int index) {
                                          return getListview(
                                              groupListModel.groupList[index],
                                              index,
                                              "");
                                        }),
                                      ))
                                  : Container(
                                      height: 0.0,
                                    ),
                              groupListModel.groupRequestList.length == 0
                                  ? Container(
                                      height: 0,
                                    )
                                  : PaddingWrap.paddingfromLTRB(
                                      15.0,
                                      10.0,
                                      15.0,
                                      0.0,
                                      Container(
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      14.0, 5.0, 0.0, 5.0),
                                                  child: Text(
                                                    MessageConstant
                                                            .ABOUT_GROUP_PENDING_GROUP +
                                                        " -(" +
                                                        groupListModel
                                                            .groupRequestList
                                                            .length
                                                            .toString() +
                                                        ")",
                                                    style: AppTextStyle
                                                        .getDynamicStyleGroup(
                                                            ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            12.0,
                                                            FontType
                                                                .Regular), /*TextStyle(
                                                        fontSize: 12.0,
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontFamily: Constant
                                                            .customRegular),*/
                                                  )),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child:
                                                  groupListModel
                                                              .groupRequestList
                                                              .length >
                                                          2
                                                      ? InkWell(
                                                          child: Container(
                                                              height: 40.0,
                                                              child: Padding(
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          10.0,
                                                                          3.0,
                                                                          20.0,
                                                                          0.0),
                                                                  child: Text(
                                                                    MessageConstant
                                                                        .ABOUT_GROUP_VIEW_ALL,
                                                                    style: AppTextStyle.getDynamicStyleGroup(
                                                                        ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR,
                                                                        14.0,
                                                                        FontType
                                                                            .Regular), /*TextStyle(
                                                                            fontSize:
                                                                                14.0,
                                                                            color:
                                                                                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                            fontFamily: Constant.customRegular),*/
                                                                  ))),
                                                          onTap: () {
                                                            onTapViewAll(
                                                                "requestedList",
                                                                "Requested");
                                                          },
                                                        )
                                                      : Container(
                                                          height: 0.0,
                                                        ),
                                              flex: 0,
                                            )
                                          ],
                                        ),
                                        color:
                                            ColorValues.LIGHT_GREY_TEXT_COLOR,
                                        height: 25.0,
                                      )),
                              groupListModel.groupRequestList.length == 0
                                  ? Container(
                                      height: 0,
                                    )
                                  : PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                      Column(
                                        children: List.generate(
                                            groupListModel.groupRequestList
                                                        .length >
                                                    2
                                                ? 2
                                                : groupListModel
                                                    .groupRequestList
                                                    .length, (int index) {
                                          return getListview(
                                              groupListModel
                                                  .groupRequestList[index],
                                              index,
                                              "group");
                                        }),
                                      )),
                              groupListModel.groupRequestList.length == 0
                                  ? Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                15.0, 10.0, 15.0, 0.0),
                                            child: Container(
                                              child: Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Padding(
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                13.0,
                                                                0.0,
                                                                0.0,
                                                                0.0),
                                                        child: Text(
                                                          MessageConstant
                                                              .ABOUT_GROUP_FIND_GROUP,
                                                          style: AppTextStyle
                                                              .getDynamicStyleGroup(
                                                                  ColorValues
                                                                      .HEADING_COLOR_EDUCATION,
                                                                  12.0,
                                                                  FontType
                                                                      .Regular), /* TextStyle(
                                                              fontSize: 12.0,
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontFamily: Constant
                                                                  .customRegular),*/
                                                        )),
                                                    flex: 1,
                                                  ),
                                                ],
                                              ),
                                              color: ColorValues
                                                  .GREY__COLOR_DIVIDER,
                                              height: 24.0,
                                            )),
                                        PaddingWrap.paddingfromLTRB(
                                            15.0,
                                            0.0,
                                            15.0,
                                            10.0,
                                            new Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border.all(
                                                      color: ColorValues
                                                          .DEVIDER_COLOR,
                                                      width: 0.5)),
                                              child: Container(
                                                width: double.infinity,
                                                child: Column(
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        10.0,
                                                        0.0,
                                                        0.0,
                                                        Image.asset(
                                                          "assets/group_i_want.png",
                                                          height: 140.0,
                                                          width: 245.0,
                                                        )),
                                                    Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          30, 6, 30, 3),
                                                      child: Text(
                                                        MessageConstant
                                                            .ABOUT_GROUP_DISCOVER_GROUP,
                                                        style: AppTextStyle
                                                            .getDynamicStyleGroup(
                                                                ColorValues
                                                                    .GREY_TEXT_COLOR,
                                                                16.0,
                                                                FontType.Bold),
                                                        /*TextStyle(
                                                        color:
                                                            ColorValues.GREY_TEXT_COLOR,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMBOLD,
                                                        fontSize: 16),*/
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          13, 0, 13, 2),
                                                      child: Text(
                                                        MessageConstant
                                                            .ABOUT_GROUP_DO_INTERESTS_PASSIONS,
                                                        style: AppTextStyle
                                                            .getDynamicStyleGroup(
                                                                ColorValues
                                                                    .GREY_TEXT_COLOR,
                                                                14.0,
                                                                FontType
                                                                    .Regular),
                                                        /*TextStyle(
                                                        color:
                                                            ColorValues.GREY_TEXT_COLOR,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR,
                                                        fontSize: 14),*/
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          0, 10, 0, 10),
                                                      child: InkWell(
                                                        child: Text(
                                                          MessageConstant
                                                              .ABOUT_GROUP_DISCOVER,
                                                          style: AppTextStyle
                                                              .getDynamicStyleGroup(
                                                                  ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  14.0,
                                                                  FontType
                                                                      .Regular),
                                                          /*TextStyle(
                                                          color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR,
                                                          fontSize: 14),*/
                                                          textAlign:
                                                              TextAlign.center,
                                                        ),
                                                        onTap: () {
                                                          onTapDiscover();
                                                        },
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            )),
                                      ],
                                    )
                                  : Container(
                                      height: 0.0,
                                    ),
                            ],
                          ),
              )),
        ));
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
