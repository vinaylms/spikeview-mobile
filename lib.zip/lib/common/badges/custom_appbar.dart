import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/style.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final String rightTitle;
  final Function() click;

  CustomAppBar({
    this.title,
    this.rightTitle,
    this.click,
  });

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: EdgeInsets.only(left:10,right: 10 ),
        height: preferredSize.height,
        decoration: const BoxDecoration(
          color: Color(0xffFFFFFF),
          border: Border(
            bottom: BorderSide(color: Color(0xffDEDEDE),width: 1),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
          Image.asset(
            'assets/badges/back_arrows.png',
            height: 22,
            width: 25,
          ),
          Text(
            title,
            maxLines: 1,
            textAlign: TextAlign.start,
            style: TxtStyle.nunito_20_600Black,
          ),
            rightTitle != null ? GestureDetector(
              onTap: click,
              child: Text(
              rightTitle,
              maxLines: 1,
              textAlign: TextAlign.start,
              style: TxtStyle.nunito_16_400Blue,
          ),
            ) : SizedBox(),
        ],),
      ),
    );
  }
}
