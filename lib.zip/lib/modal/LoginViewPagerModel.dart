import 'dart:io';

class LoginViewPagerModel {
  String label,path;



  LoginViewPagerModel(this.label, this.path);
}


