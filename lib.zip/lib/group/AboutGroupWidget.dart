import 'package:flutter/material.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class AboutGroupWidget extends StatefulWidget {
  GroupDetailModel model;

  AboutGroupWidget(this.model);

  @override
  AddPostGroupState createState() {
    return  AddPostGroupState();
  }
}

class AddPostGroupState extends State<AboutGroupWidget> {
  SharedPreferences prefs;
  String userIdPref,roleId, token, userProfilePath;
  ScrollController _scrollController;
  bool isTitleVisible = false;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
  }

  @override
  void initState() {
    _scrollController = ScrollController()
      ..addListener(() => setState(() {
        if (_scrollController.offset > 350.0) {
          setState(() {
            isTitleVisible = true;
          });
        } else {
          setState(() {
            isTitleVisible = false;
          });
        }

      }));
    getSharedPreferences();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;




   return customAppbar(
        context,
        GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0, right: 20, top: 24, bottom: 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        BaseText(
                          text: 'About group',
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily:
                          AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w700,
                          fontSize: 28,
                          textAlign: TextAlign.start,
                          maxLines: 3,
                        ),
                      ],
                    ),
                  ),
                  flex: 0,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(left:20.0,right: 20,top: 20),
                    child: ListView(
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(top:0.0),
                          child: BaseText(
                            text: 'Group name',
                            textColor: ColorValues.labelColor,
                            fontFamily:
                            AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top:3.0),
                          child:BaseText(
                            text: widget.model.groupName,
                            textColor: ColorValues.TEXT_COLOR,
                            fontFamily:
                            AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(top:20.0),
                          child: BaseText(
                            text: 'About group',
                            textColor: ColorValues.labelColor,
                            fontFamily:
                            AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top:3.0),
                          child:BaseText(
                            text: widget.model.aboutGroup,
                            textColor: ColorValues.TEXT_COLOR,
                            fontFamily:
                            AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            textAlign: TextAlign.start,
                            maxLines: 50,
                          ),
                        ),



                       /* Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top:20.0),
                              child: BaseText(
                                text: 'Group rules',
                                textColor: ColorValues.labelColor,
                                fontFamily:
                                AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                                textAlign: TextAlign.start,
                                maxLines: 3,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top:3.0),
                              child: Row(
                                children: [
                                  Expanded(child:Padding(
                                      padding: const EdgeInsets.only(left:5.0,top: 3),
                                      child: Container(
                                        decoration: new BoxDecoration(
                                            color: Color(0xff3D4361),
                                            borderRadius: new BorderRadius.all(Radius.circular(10)
                                            )
                                        ),
                                        height: 8,width:8,)) ,flex: 0,),
                                  Expanded(child: Padding(
                                    padding: const EdgeInsets.only(left:7.0),
                                    child: BaseText(
                                      text: 'Growing the group towards its purpose.',
                                      textColor: ColorValues.TEXT_COLOR,
                                      fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16,
                                      textAlign: TextAlign.start,
                                      maxLines: 3,
                                    ),
                                  ) ,flex: 1,),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top:3.0),
                              child: Row(
                                children: [
                                  Expanded(child:Padding(
                                      padding: const EdgeInsets.only(left:5.0,top: 3),
                                      child: Container(
                                        decoration: new BoxDecoration(
                                            color: Color(0xff3D4361),
                                            borderRadius: new BorderRadius.all(Radius.circular(10)
                                            )
                                        ),
                                        height: 8,width:8,)) ,flex: 0,),
                                  Expanded(child: Padding(
                                    padding: const EdgeInsets.only(left:7.0),
                                    child: BaseText(
                                      text: 'Keeping the group spam-free.',
                                      textColor: ColorValues.TEXT_COLOR,
                                      fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16,
                                      textAlign: TextAlign.start,
                                      maxLines: 3,
                                    ),
                                  ) ,flex: 1,),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top:3.0),
                              child: Row(
                                children: [
                                  Expanded(child:Padding(
                                      padding: const EdgeInsets.only(left:5.0,top: 3),
                                      child: Container(
                                        decoration: new BoxDecoration(
                                            color: Color(0xff3D4361),
                                            borderRadius: new BorderRadius.all(Radius.circular(10)
                                            )
                                        ),
                                        height: 8,width:8,)) ,flex: 0,),
                                  Expanded(child: Padding(
                                    padding: const EdgeInsets.only(left:7.0),
                                    child: BaseText(
                                      text: 'Acquainting members with Dos and Don’ts.',
                                      textColor: ColorValues.TEXT_COLOR,
                                      fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16,
                                      textAlign: TextAlign.start,
                                      maxLines: 3,
                                    ),
                                  ) ,flex: 1,),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top:3.0),
                              child: Row(
                                children: [
                                  Expanded(child:Padding(
                                      padding: const EdgeInsets.only(left:5.0,top: 3),
                                      child: Container(
                                        decoration: new BoxDecoration(
                                            color: Color(0xff3D4361),
                                            borderRadius: new BorderRadius.all(Radius.circular(10)
                                            )
                                        ),
                                        height: 8,width:8,)) ,flex: 0,),
                                  Expanded(child: Padding(
                                    padding: const EdgeInsets.only(left:7.0),
                                    child: BaseText(
                                      text: 'Be Kind and Courteous.',
                                      textColor: ColorValues.TEXT_COLOR,
                                      fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16,
                                      textAlign: TextAlign.start,
                                      maxLines: 3,
                                    ),
                                  ) ,flex: 1,),
                                ],
                              ),
                            ),
                          ],),*/

                        Padding(
                          padding: const EdgeInsets.only(top:20.0),
                          child: BaseText(
                            text: 'Group created on',
                            textColor: ColorValues.labelColor,
                            fontFamily:
                            AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top:3.0),
                          child:BaseText(
                            text:widget.model.creationDate,
                            textColor: ColorValues.TEXT_COLOR,
                            fontFamily:
                            AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ),

                        widget.model.otherInfo=='null'||  widget.model.otherInfo==''?SizedBox(): Padding(
                          padding: const EdgeInsets.only(top:20.0),
                          child: BaseText(
                            text: 'Group rule',
                            textColor: ColorValues.labelColor,
                            fontFamily:
                            AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ),
                        widget.model.otherInfo=='null'||  widget.model.otherInfo==''?SizedBox():   Padding(
                          padding: const EdgeInsets.only(top:3.0),
                          child:BaseText(
                            text:widget.model.otherInfo,
                            textColor: ColorValues.TEXT_COLOR,
                            fontFamily:
                            AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  flex: 1,
                ),
              ],
            )), () {
      Navigator.pop(context);
    },
        isShowIcon: false,
      );



  }
}
