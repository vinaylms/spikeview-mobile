import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/group/model/EmailModel.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/group/model/SpikeUserInvitationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

// Create a Form Widget
class InviteMember extends StatefulWidget {
  String groupId;
  String page;
  List<MemberModelDetail> memberList;

  InviteMember(this.groupId, this.page, this.memberList);

  @override
  AddTagGroupWidgetState createState() {
    return AddTagGroupWidgetState();
  }
}

class AddTagGroupWidgetState extends State<InviteMember> {
  SharedPreferences prefs;
  BuildContext context;
  String userIdPref, roleId;

  // Variables for Search
  TextEditingController _searchQuery = TextEditingController(text: "");
  TextEditingController _searchSpieViewUser = TextEditingController(text: "");
  List<EmailModel> emailList = List();
  List<SpikeUserInvitationModel> spikeViewUserList = List();
  String _searchText = "", previousText = "";
  Timer _timer;
  String previousTextForEmail = "";

  List<ProfileInfoModal> friendList = List();
  final ScrollController _scroll = ScrollController();

  List<ProfileInfoModal> friendListWithEmail = List();

  static StreamController syncDoneController = StreamController.broadcast();
  bool _IsSearching;
  bool isEmailLoad = true;

  bool isApiCalling = false;
  String isApiCalled = "pop";
  String doubleCodeForSearchHint = "\"";

  String userName = "";
  String userEmail = "";

  //--------------------------api Calling for tag------------------

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userName = prefs.getString(UserPreference.NAME);
    userEmail = prefs.getString(UserPreference.EMAIL);
  }

  void inviteDialog(bool isMore) {

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            //  headingText: 'Leave group',
            isThreeStepPopup:true,
            headingText: isMore?'Group members invited successfully!':'Group member invited successfully!',
            negativeText: 'Cancel',
            positiveText: 'Invite more',

            positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
              onBack();
            },
            onPositiveTap: (){
            },
          );
        });


  }

  showSucessMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");
      Navigator.pop(context);
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.latoRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  onBack() {
    if (widget.page == "add")
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
              GroupDetailWidget(widget.groupId, "invite", "", "", "")));
    else if (widget.page == "member")
      Navigator.pop(context, isApiCalled);
    else
      Navigator.pop(context, isApiCalled);
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "members": spikeViewUserList.map((item) => item.toJson()).toList(),
          "emails": emailList.map((item) => item.toJson()).toList(),
          "groupId": int.parse(widget.groupId),
          "invitedBy": int.parse(userIdPref),
          "roleId": int.parse(roleId),
        };
        print(map.toString());
        response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_SEARCH_INVITE_GROUP_MEMBER, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            print("sucesss+++++++" + status);
            if (status == "Success") {
              print("sucesss+++++++");
              isApiCalled = "push";
              bool isMore=false;
              if(spikeViewUserList.length>1 ||emailList.length>1){
                isMore=true;
              }
              inviteDialog(isMore);
             // onBack();
             // showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForFrindList2(s) async {
    try {
      if (s.length >= 1) {
        print("api caling 2 =========");

        ///ui/search/searchUsersForGroupByEmail

        previousText = _searchQuery.text;
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_SEARCH_GROUP +
                s +
                "&like=true" +
                "&userId=" +
                userIdPref +
                "&groupId=" +
                widget.groupId,
            "get");

        print("api caling 2 =========" +
            Constant.ENDPOINT_SEARCH_GROUP +
            s +
            "&like=true" +
            "&userId=" +
            userIdPref +
            "&groupId=" +
            widget.groupId);

        isApiCalling = false;
        setState(() {
          isApiCalling;
        });
        print("api caling 3 =========");
        print("groupid" + widget.groupId + " userid" + userIdPref);
        print("groupid response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              friendList.clear();

              var result = response.data['result'];
              var userListMap = result['userList'] as List;

              if (userListMap.length > 0) {
                friendList =
                    ParseJson.parseUserFriendList(userListMap, userIdPref);
              }

              if (friendList.length > 0) {
                setState(() {
                  friendList;
                });
              }
            }
          }
        }
      }
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
    } catch (e) {
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
      e.toString();
    }
  }

  Future apiCallForEmailSearch(s) async {
    try {
      if (s.length >= 1) {
        previousText = _searchQuery.text;

        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_SEARCH_GROUP_EMAIL +
                s +
                "&like=true" +
                "&userId=" +
                userIdPref +
                "&groupId=" +
                widget.groupId,
            "get");

        print("api caling 2 =========" +
            Constant.ENDPOINT_SEARCH_GROUP +
            s +
            "&like=true" +
            "&userId=" +
            userIdPref +
            "&groupId=" +
            widget.groupId);

        isApiCalling = false;
        setState(() {
          isApiCalling;
        });

        print("api caling 3 =========");
        print("groupid" + widget.groupId + " userid" + userIdPref);
        print("groupid response" + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              friendListWithEmail.clear();

              var result = response.data['result'];
              var userListMap = result['userList'] as List;

              if (userListMap.length > 0) {
                friendListWithEmail =
                    ParseJson.parseUserFriendList(userListMap, userIdPref);
              }
              print("isEmailLoad+++++" + isEmailLoad.toString());
              if (friendListWithEmail.length > 0 && isEmailLoad) {
                setState(() {
                  friendListWithEmail;
                });
              } else {
                setState(() {
                  friendListWithEmail.clear();
                });
              }
            }
          }
        }
      }
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
    } catch (e) {
      isApiCalling = false;
      setState(() {
        isApiCalling;
      });
      e.toString();
    }
  }

  @override
  void initState() {
    _searchQuery.addListener(() {
      if (_searchQuery.text.isEmpty) {
        _searchQuery.text = "";
        setState(() {
          _IsSearching = false;
          isEmailLoad = false;
          friendListWithEmail.clear();
        });
      } else {
        if (_searchQuery.text.contains(".com")) {
          print("is true");

          addEmailChipset(_searchQuery.text, "");
          setState(() {
            isEmailLoad = false;
            friendListWithEmail.clear();
            _searchQuery.text = "";
          });
        }
      }
    });

    _IsSearching = false;
    _searchSpieViewUser.addListener(() {
      if(_searchSpieViewUser.text!=previousText) {
        isApiCalling = false;
        setState(() {
          isApiCalling;
        });
        if (_searchSpieViewUser.text.isEmpty) {
          isApiCalling = false;
          friendList.clear();
          setState(() {
            isApiCalling;
            friendList;
            _IsSearching = false;
            _searchText = "";
          });
        } else {
          if (_searchSpieViewUser.text
              .trim()
              .length >= 1) {
            //  if (previousText != _searchSpieViewUser.text) {
            if (_timer != null) {
              print("data++++++timer cancel");
              _timer.cancel();
            }
            _timer = Timer(const Duration(milliseconds: 1000), () {
              print("data++++++apiCall");
              previousText = _searchSpieViewUser.text;
              isApiCalling = true;
              setState(() {
                friendList.clear();
                isApiCalling;
              });
              apiCallingForFrindList2(_searchSpieViewUser.text.trim());
              setState(() {
                _IsSearching = true;
                _searchText = _searchSpieViewUser.text;
              });
            });
            //  }
          } else {
            isApiCalling = false;
            setState(() {
              isApiCalling;
            });
          }
        }
      }
    });

    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;

    _buildChoiceList() {
      List<Widget> choices = List();
      emailList.forEach((item) {
        choices.add(PaddingWrap.paddingfromLTRB(
            4.0,
            0.0,
            5.0,
            5.0,
            Container(
              decoration: BoxDecoration(
                color: AppConstants.colorStyle.orangeShade,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      width: 1.0, color:  AppConstants.colorStyle.orangeShade)),
              padding: const EdgeInsets.fromLTRB(8.0, 4.0, 8.0, 4.0),
              child: Wrap(
                children: <Widget>[
                  Text(
                    item.email,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14.0,
                        fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular),
                  ),
                  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        0.0,
                        0.0,
                        0.0,
                        Icon(
                          Icons.clear,
                          color: Colors.white,
                          size: 17.0,
                        )),
                    onTap: () {
                      emailList.remove(item);
                      setState(() {
                        emailList;
                      });
                    },
                  )
                ],
              ),
            )));
      });
      return choices;
    }

    _buildChoiceListForSpikeUser() {
      List<Widget> choices = List();
      spikeViewUserList.forEach((item) {
        choices.add(PaddingWrap.paddingfromLTRB(
            4.0,
            0.0,
            5.0,
            5.0,
            Container(
                decoration: BoxDecoration(
                    color: AppConstants.colorStyle.orangeShade,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        width: 1.0, color:  AppConstants.colorStyle.orangeShade)),
              padding: const EdgeInsets.fromLTRB(8.0, 4.0, 8.0, 4.0),
              child: Wrap(
                children: <Widget>[
                  Text(
                    item.lastName == null || item.lastName == "null"
                        ? item.firstName
                        : item.firstName + " " + item.lastName,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14.0,
                        fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular),
                  ),
                  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        0.0,
                        0.0,
                        0.0,
                        Icon(
                          Icons.clear,
                          color: Colors.white,
                          size: 17.0,
                        )),
                    onTap: () {
                      spikeViewUserList.remove(item);
                      setState(() {
                        spikeViewUserList;
                      });
                    },
                  )
                ],
              ),
            )));
      });
      return choices;
    }

    List<InkWell> _buildFriendSearchList() {
      //    if (_searchText.isEmpty) {
      return List.generate(friendList.length, (int index) {
        return InkWell(
            child: PaddingWrap.paddingfromLTRB(
                10.0,
                10.0,
                10.0,
                0.0,
                Container(
                  decoration: BoxDecoration(
                      color: AppConstants.colorStyle.tabBg,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          width: 1.0, color:  AppConstants.colorStyle.btnBg)),
                  child: Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Row(
                      children: <Widget>[



                        Expanded(
                          child: Center(
                            child: ProfileImageView(
                              imagePath: Constant.IMAGE_PATH +
                                  ParseJson.getMediumImage(
                                      friendList[index].profilePicture),
                              placeHolderImage: friendList[index].roleId == '4'
                                  ? "assets/profile/partner_img.png"
                                  : 'assets/profile/user_on_user.png',
                              height: 48,
                              width: 48,
                              onTap: () async {},
                            ),
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  RichText(
                                    maxLines: 2,
                                    textAlign: TextAlign.start,
                                    text: TextSpan(
                                      text: friendList[index].lastName == null ||
                                              friendList[index].lastName ==
                                                  "null" ||
                                              friendList[index].lastName == ""
                                          ? friendList[index].firstName
                                          : friendList[index].firstName +
                                              " " +
                                              friendList[index].lastName,
                                      style: TextStyle(
                                          color:
                                              ColorValues.HEADING_COLOR_EDUCATION_1,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.w500,
                                          fontFamily: Constant.latoRegular),
                                      children: [
                                        WidgetSpan(
                                          child: friendList[index].roleId == "1"
                                              ? Util
                                                  .getStudentBadgeRichTextWithPadding(
                                                      friendList[index].badge,
                                                      friendList[index].badgeImage)
                                              : Container(),
                                        ),
                                        TextSpan(
                                            text: getRoll(friendList[index].roleId),
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                fontWeight: FontWeight.bold,
                                                fontFamily:
                                                    Constant.latoRegular)),
                                      ],
                                    ),
                                  ),
                                  friendList[index].tagline == null ||
                                      friendList[index].tagline ==
                                          "null" ||
                                      friendList[index].tagline == ""
                                      ?SizedBox():  Row(
                                    children: <Widget>[
                                      Flexible(
                                          child: TextViewWrap.textView(
                                        friendList[index].tagline == null ||
                                                friendList[index].tagline ==
                                                    "null" ||
                                                friendList[index].tagline == ""
                                            ? ""
                                            : friendList[index].tagline,
                                        TextAlign.start,
                                        AppConstants.colorStyle.lightPurple,

                                        14.0,
                                        FontWeight.normal,
                                      )),
                                    ],
                                  )
                                ],
                              )),
                          flex: 1,
                        ),
                        Expanded(
                          child: Column(
                            children: <Widget>[
                              InkWell(
                                child: Padding(
                                    padding:
                                        EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                    child: Container(
                                        height: 26.0,
                                        width:friendList[index].statusVal ==
                                            "Not connected"
                                                ""
                                            ? 70:82,
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                          color: ColorValues.WHITE,
                                          border: Border.all(
                                              color: ColorValues.HEADING_COLOR_EDUCATION_2,
                                              width: 1),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                              EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 2.0),
                                              child: BaseText(
                                                text:friendList[index].statusVal ==
                                                    "Not connected"
                                                        ""
                                                    ? 'Connect':friendList[index].statusVal ==
                                                    "Accepted"
                                                    ?"Connected":"Requested",
                                                textColor:
                                                ColorValues.HEADING_COLOR_EDUCATION_2,
                                                fontFamily:
                                                AppConstants.stringConstant.latoRegular,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 14,
                                                textAlign: TextAlign.start,
                                                maxLines: 3,
                                              ),
                                            ),
                                          ],
                                        ))

                                    ),
                              ),
                            ],
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                  ),
                )),
            onTap: () {
              if (friendList[index].statusVal == "Not connected") {
                print("roleId+++++++" + friendList[index].roleId);
                spikeViewUserList.add(new SpikeUserInvitationModel(
                    friendList[index].firstName,
                    friendList[index].lastName,
                    friendList[index].userId,
                    friendList[index].roleId));
                setState(() {
                  friendList.clear();
                  _searchSpieViewUser.text = "";
                  spikeViewUserList;
                });
              }
            });
      });
    } // List Builder Here For Search Item

    List<InkWell> _buildFriendSearchListForEmailSharing() {
      //    if (_searchText.isEmpty) {
      return List.generate(friendListWithEmail.length, (int index) {
        return InkWell(
            child: PaddingWrap.paddingfromLTRB(
                14.0,
                15.0,
                0.0,
                14.0,
                Row(
                  children: <Widget>[
                    //  Expanded(
                    //   child:  Center(
                    //     child:  Container(
                    //         width: 45.0,
                    //         height: 45.0,
                    //         child: ClipRRect(
                    //           borderRadius: BorderRadius.circular(100),
                    //           child: FadeInImage.assetNetwork(
                    //             fit: BoxFit.cover,
                    //             placeholder: "assets/profile/user_on_user.png",
                    //             image: Constant.IMAGE_PATH +
                    //                 ParseJson.getMediumImage(
                    //                     friendListWithEmail[index]
                    //                         .profilePicture),
                    //           ),
                    //         )),
                    //   ),
                    //   flex: 0,
                    // ),
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          10.0,
                          0.0,
                          0.0,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Expanded(
                                    child: TextViewWrap.textView(
                                        friendListWithEmail[index].lastName ==
                                                    null ||
                                                friendListWithEmail[index]
                                                        .lastName ==
                                                    "null" ||
                                                friendListWithEmail[index]
                                                        .lastName ==
                                                    ""
                                            ? friendListWithEmail[index]
                                                .firstName
                                            : friendListWithEmail[index]
                                                    .firstName +
                                                " " +
                                                friendListWithEmail[index]
                                                    .lastName,
                                        TextAlign.start,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                        14.0,
                                        FontWeight.bold),
                                    flex: 0,
                                  ),
                                  Expanded(
                                    flex: 0,
                                    child: friendListWithEmail[index].roleId ==
                                            "1"
                                        ? Util.getStudentBadge12(
                                            friendListWithEmail[index].badge,
                                            friendListWithEmail[index]
                                                .badgeImage)
                                        : Container(),
                                  ),
                                  Expanded(
                                    child: TextViewWrap.textView(
                                        getRoll(
                                            friendListWithEmail[index].roleId),
                                        TextAlign.start,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                        14.0,
                                        FontWeight.bold),
                                    flex: 0,
                                  ),
                                ],
                              ),
                              Row(
                                children: <Widget>[
                                  Flexible(
                                      child: TextViewWrap.textView(
                                    friendListWithEmail[index].tagline ==
                                                null ||
                                            friendListWithEmail[index]
                                                    .tagline ==
                                                "null" ||
                                            friendListWithEmail[index]
                                                    .tagline ==
                                                ""
                                        ? ""
                                        : friendListWithEmail[index].tagline,
                                    TextAlign.start,
                                    ColorValues.GREY_TEXT_COLOR,
                                    12.0,
                                    FontWeight.normal,
                                  )),
                                ],
                              )
                            ],
                          )),
                      flex: 1,
                    ),
                  ],
                )),
            onTap: () {
              bool isExist = false;
              for (MemberModelDetail model in widget.memberList)
                addEmailChipset(friendListWithEmail[index].email,
                    friendListWithEmail[index].roleId);
            });
      });
    } // List Builder Here For Search Item

  return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: customAppbar(
            context,
            GestureDetector(
                onTap: () {
                  FocusScope.of(context).requestFocus(new FocusNode());
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20, top: 24, bottom: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'Add to group',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            ),
                          ],
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: ListView(
                        padding: EdgeInsets.zero,
                        children: <Widget>[
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                             /* emailList.length == 0
                                  ? Container(
                                      height: 25.0,
                                    )
                                  : Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          20.0, 25.0, 20.0, 0.0),
                                      child: Text(
                                        MessageConstant
                                            .INVITE_EMAIL_INVITE_BY_EMAIL,
                                        style: TextStyle(
                                            color: ColorValues.GREY_TEXT_COLOR,
                                            fontSize: 14.0,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR),
                                      )),*/


                              // List For user

                              Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(20.0, 20.0, 20.0, 0.0),
                                  child: Container(

                                    decoration: BoxDecoration(

                                        border: Border(
                                            bottom: BorderSide(
                                                color: ColorValues
                                                    .LIGHT_GREY_TEXT_COLOR,
                                                width: 1.0))),
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        5.0,
                                        5.0,
                                        TextField(
                                            controller: _searchQuery,
                                            autocorrect: false,
                                            keyboardType:
                                                TextInputType.emailAddress,
                                            autofocus: true,
                                            cursorColor: Constant.CURSOR_COLOR,
                                            decoration: InputDecoration(

                                              contentPadding:
                                                  const EdgeInsets.fromLTRB(
                                                      0.0, 5.0, 0.0, 0.0),
                                              border: InputBorder.none,
                                              labelText:  MessageConstant
                                                      .INVITE_EMAIL_INVITE_BY_EMAIL
                                                 ,
                                              labelStyle: TextStyle(
                                                  fontSize: 16.0,
                                                  color: AppConstants.colorStyle.lightPurple,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ))),
                                  )),
                              Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 0.0),
                                  child: Text(
                                    MessageConstant.INVITE_EMAIL_SEND_INVITE,
                                    textAlign: TextAlign.start,
                                    maxLines: 3,
                                    style: TextStyle(
                                        color:AppConstants.colorStyle.darkBlue,
                                        fontFamily: Constant.latoRegular,
                                        fontStyle: FontStyle.italic,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14.0),
                                  )),

                              Padding(
                                padding:
                                EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 0.0),
                                child: Wrap(
                                  children: _buildChoiceList(),
                                ),
                              ),

                              friendListWithEmail.length > 0
                                  ? PaddingWrap.paddingfromLTRB(
                                  20.0,
                                      0.0,
                                  20.0,
                                      10.0,
                                      Container(
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              border: Border.all(
                                                  color: ColorValues
                                                      .GREY__COLOR_DIVIDER,
                                                  width: 0.5)),
                                          child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children:
                                                  _buildFriendSearchListForEmailSharing())))
                                  : Container(height: 0.0),


                              PaddingWrap.paddingfromLTRB(
                                  20.0,
                                  20.0,
                                  20.0,
                                  0.0,
                                  Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[

                                        Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.0, 0.0, 20.0, 0.0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  border: Border(
                                                      bottom: BorderSide(
                                                          color: ColorValues
                                                              .LIGHT_GREY_TEXT_COLOR,
                                                          width: 1.0))),
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      5.0,
                                                      5.0,
                                                      5.0,
                                                      TextField(
                                                          controller:
                                                              _searchSpieViewUser,
                                                          autocorrect: false,
                                                          autofocus: true,
                                                          cursorColor: Constant
                                                              .CURSOR_COLOR,
                                                          decoration:
                                                              InputDecoration(
                                                            contentPadding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    0.0,
                                                                    5.0,
                                                                    5.0,
                                                                    0.0),
                                                            border: InputBorder
                                                                .none,
                                                            labelText:  'Invite spikeview users'
                                                                ,
                                                            labelStyle: TextStyle(
                                                                fontSize: 16.0,
                                                                color: AppConstants.colorStyle.lightPurple,
                                                                fontFamily: Constant
                                                                    .latoRegular),
                                                          ))),
                                            ))
                                      ])),
                              Stack(
                                children: <Widget>[
                                  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          20.0, 5.0, 20.0, 0.0),
                                      child: Text(
                                        MessageConstant
                                            .INVITE_EMAIL_SEARCH_SPIKEVIEW,
                                        textAlign: TextAlign.start,
                                        maxLines: 3,
                                        style: TextStyle(
                                            color:AppConstants.colorStyle.darkBlue,
                                            fontFamily: Constant.latoRegular,
                                            fontStyle: FontStyle.italic,
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14.0),
                                      )),
                                  PaddingWrap.paddingfromLTRB(
                                      20.0,
                                      0.0,
                                      20.0,
                                      10.0,
                                      Container(
                                          height: friendList.length == 0
                                              ? 0.0
                                              : friendList.length == 1
                                                  ? 70.0
                                                  : friendList.length == 2
                                                      ? 145.0
                                                      : friendList.length == 3
                                                          ? 220.0
                                                          : 300.0,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              border: Border.all(
                                                  color: Color.fromRGBO(0, 0, 0, 0.10),

                                                  width: 0.5)),
                                          child: Scrollbar(
                                              /*       isAlwaysShown: true,*/
                                              child: ListView(
                                                  children:
                                                      _buildFriendSearchList()))))
                                ],

                              ),
                              Padding(
                                padding: EdgeInsets.fromLTRB(
                                    20.0, 10.0, 20.0, 0.0),
                                child: Wrap(
                                  children:
                                  _buildChoiceListForSpikeUser(),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                      flex: 1,
                    ),
                  ],
                )), () {
          Navigator.pop(context);
        },
            isShowIcon: false,
            bottomNavigation: Stack(
              children: [
               PaddingWrap.paddingfromLTRB(
                      20.0,
                      20.0,
                      20.0,
                      20.0,
                InkWell(
                  child:  Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: AppConstants.colorStyle.lightBlue,
                            border: Border.all(
                                color: AppConstants.colorStyle.lightBlue),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Align(
                              alignment: Alignment.center,
                              // Align however you like (i.e .centerRight, centerLeft)
                              child: Text(
                                "Send invitations",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.WHITE,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontSize: 18.0,
                                ),
                              ))),  onTap: () async {
              if (emailList.length == 0 &&
                  spikeViewUserList.length == 0) {
                ToastWrap.showToast("Please add members.", context);
              } else {
                apiCalling();
              }
            },
            )),

              ],
            )));


    // Create Chips View for Selected
  }

  String getRoll(String roleId) {
    if (roleId == "1") {
      return " (Student)";
    }
    if (roleId == "2") {
      return " (Parent)";
    }
    if (roleId == "4") {
      return " (Partner)";
    }
  }

  void addEmailChipset(String text, roleId) {
    bool isAdd = true;
    if (text == userEmail) {
      _searchQuery.text = "";
      ToastWrap.showToast(MessageConstant.SELF_INVITE_NOT_GOOD_IDEA, context);
      setState(() {
        friendListWithEmail.clear();
        emailList;
        _searchQuery;
      });
    } else {
      setState(() {
        previousText = text;
      });
      if (ValidationWidget.isEmail(text)) {
        for (int i = 0; i < emailList.length; i++) {
          if (text == emailList[i].email) {
            isAdd = false;
            print("data" + emailList[i].email.toString());
          }
        }

        if (isAdd) emailList.add(new EmailModel(text, roleId));

        _searchQuery.text = "";
        setState(() {
          emailList;
          _searchQuery;
          friendListWithEmail.clear();
        });
      }
    }
  }
}
