import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:url_launcher/url_launcher.dart';

class NewWhatsAppViewFeed extends StatefulWidget {
  final String imageUrl;
  final String title;
  String description;
  final String url;
  bool isShowMore = false;
  bool isEmptyFeed = false;
  String feedId;
  String metaWidth, metaHeight, metaSource;

  NewWhatsAppViewFeed(
      {Key key,
      @required this.imageUrl,
      @required this.title,
      @required this.feedId,
      @required this.metaHeight,
      @required this.metaWidth,
      @required this.metaSource,
      this.description,
      @required this.url,@required this.isEmptyFeed});

  @override
  State createState() {
    print("sss wv ${imageUrl} -- ${title} -- ${description} -- ${url}");
    return  NewWhatsAppViewFeedState(
        imageUrl: imageUrl, title: title, description: description, url: url, isEmptyFeed: isEmptyFeed);
  }
}

class NewWhatsAppViewFeedState extends State<NewWhatsAppViewFeed> {
// CachedNetworkImage
//class WhatsAppView extends StatefulWidget {
  final String imageUrl;
  final String title;
  String description;
  final String url;
  bool isShowMore = false;
  bool isEmptyFeed = false;

  NewWhatsAppViewFeedState(
      {Key key,
      @required this.imageUrl,
      @required this.title,
      this.description,
      @required this.url,
      @required this.isEmptyFeed});


  Widget _loader(BuildContext context) => Center(
          child: Container(
        child:  Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.cover,
        ),
      ));

  Widget _error() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill

      ),
    );
  }

  Future apiCallingForIncreaseCount() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCall(context,
            Constant.ENDPOINT_INCREASE_NUMBER_OF_COUNT + widget.feedId, "get");

        print("apiCallingForIncreaseCount data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }



  Widget build(BuildContext context) {
    print('widget.title:: ${widget.title}');
    print('widget.description:: ${widget.description}');
    print('widget.imageUrl:: ${widget.imageUrl}');
    print('widget.feedId:: ${widget.feedId}');
    print('widget.isShowMore:: ${widget.isShowMore}');
    print('widget.metaWidth:: ${widget.metaWidth}');
    print('widget.metaHeight:: ${widget.metaHeight}');
    print('widget.metaSource:: ${widget.metaSource}');
    print('widget.url:: ${widget.url}');
    bool isWidthGreater=true;
    if(widget.metaWidth != null && widget.metaWidth != "" && widget.metaHeight != null && widget.metaHeight != "")
      {
        print('with is greater or equal height:: ${(double.parse(widget.metaWidth) >= double.parse(widget.metaHeight))}');
        isWidthGreater = (double.parse(widget.metaWidth) >= double.parse(widget.metaHeight));
      }


    onTapView() async {
     // apiCallingForIncreaseCount();
     // await launch(url);
      Navigator.of(context,rootNavigator: true).push(new MaterialPageRoute(fullscreenDialog: true,
          builder: (BuildContext context) =>  WebViewWidget(url, "spikeview")));

     /* Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>  WebViewWidget(url, "spikeview")));
*/
      /*   Navigator.push(
          context,
           MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
              builder: (context) =>  WebViewWidget(url, "spikeview")));*/
    }

    if (description != null &&
        description.length > 8 &&
        description.substring(0, 8) == "baseUrl:") {
      description = description.replaceAll(description.substring(0, 8), "");
    }

    return imageUrl == null && title == null
        ?  Container(
            height: 0.0,
          )
        :  Column(
            children: <Widget>[
              imageUrl == null || imageUrl == "" || imageUrl == "null"
                  ?  Container(
                      height: 0.0,
                    )
                  :  InkWell(
                      child:  Container(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 0.0),
                          child: isWidthGreater ?  CachedNetworkImage(
                            /*width:
                                widget.metaWidth != null && widget.metaWidth != ""
                                    ? double.parse(widget.metaWidth)
                                    : double.infinity,*/
                            width: double.infinity,
                            height:250,
                            /*height: widget.metaHeight != null &&
                                    widget.metaHeight != ""
                                ? double.parse(widget.metaHeight)
                                : 215.0,*/
                            imageUrl: imageUrl == null || imageUrl == "null"
                                ? ""
                                : imageUrl,
                            fit: BoxFit.fill,
                            placeholder: (context, url) => _loader(context),
                            errorWidget: (context, url, error) => _error(),
                          ):
                           CachedNetworkImage(

                            //height:  double.parse(widget.metaHeight),
                            height: 300.0,
                            imageUrl: imageUrl == null || imageUrl == "null"
                                ? ""
                                : imageUrl,
                            fit: BoxFit.contain,
                            placeholder: (context, url) => _loader(context),
                            errorWidget: (context, url, error) => _error(),
                          ),
                        ),
                      ),
                      onTap: () {
                        onTapView();
                      },
                    ),
                    isEmptyFeed?Container(height: 0,):
               Container(
                  //padding:  EdgeInsets.fromLTRB(13.0, 10.0, 13.0, 10),
                  padding:  EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 0),
                  //color:  Color(0XFFAA44DD),
                  //color:  Color(0XFFF4F4F4),
                  width: double.infinity,
                  child: Container(
                    padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10),
                    color:  Color(0XFFFFFFFF),
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                         InkWell(
                          child:  Text(
                            title == null ? "" : title.trim(),
                            textAlign: TextAlign.start,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style:  TextStyle(
                                color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily: Constant.TYPE_CUSTOMBOLD,
                                fontSize: 14.0),
                          ),
                          onTap: () {
                            onTapView();
                          },
                        ),
                         InkWell(
                          child:  Text(
                            widget.metaSource == null
                                ? ""
                                : widget.metaSource.trim(),
                            textAlign: TextAlign.start,
                            maxLines: 1,
                            style:  TextStyle(
                                  fontWeight: FontWeight.w400,
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:  Constant.latoRegular,
                                fontSize: 14.0),
                          ),
                          onTap: () {
                            //onTapView();
                            Navigator.of(context).push(new MaterialPageRoute(
                                builder: (BuildContext context) =>  WebViewWidget(url, "spikeview")));
                          },
                        ),
                         Text(
                          description == null ? "" : description.trim(),
                          textAlign: TextAlign.start,
                          maxLines: isShowMore ? 30 : 3,
                          style:  TextStyle(
                              color:
                               ColorValues.HEADING_COLOR_EDUCATION_1,
                               fontWeight: FontWeight.w400,
                              fontFamily:  Constant.latoRegular,
                              fontSize: 14.0),
                        ),
                        description.trim().length > 190
                            ?  InkWell(
                            child:  Text(
                              isShowMore ? "Less" : "More",
                              textAlign: TextAlign.start,
                              maxLines: 1,
                              style:  TextStyle(
                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 12.0),
                            ),
                            onTap: () {
                              setState(() {
                                if (isShowMore) {
                                  isShowMore = false;
                                } else
                                  isShowMore = true;
                              });
                            })
                            :  Container(
                          height: 0.0,
                        )
                      ],
                    ),
                  ))
            ],
          );
  }

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return null;
  }
}
