import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ChatReafctor/viewmodel/chat_friendList_with_viewmodel.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:stacked/stacked.dart';
import '../viewmodel/chat_friendList_viewmodel.dart';
import '../model/FrienndListModel.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';

import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
class ChatFriendListWithHeader extends StatefulWidget {

  String link, shareId, sharedProfileId,pageName,roleId;

  ChatFriendListWithHeader(this.link, this.shareId, this.sharedProfileId,{this.pageName,this.roleId});
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  ChatFriendListViewState();
  }
}

class ChatFriendListViewState extends State<ChatFriendListWithHeader>
    with AutomaticKeepAliveClientMixin, WidgetsBindingObserver {


  //String parameter for convert last message to sub part of string
  String firstHalf = '';

  //object for handle prefrence data
  SharedPreferences prefs;

  //Param for update notification count on appbar
  int notificationCount = 0;

  //Listener for update notification count in appbar
  StreamSubscription<dynamic> _streamSubscription;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    DbHelper().deleteChatTable();
    bloc.fetchChatList(prefs.getString(UserPreference.USER_ID), context, prefs, true, 0.toString());
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getSharedPreferences();
    _streamSubscription =
        DashBoardState.syncDoneController.stream.listen((value) {
      if (value == "msg") {
      } else {
        notificationCount = int.parse(value);
        setState(() {
          notificationCount;
        });
      }
    });

    _streamSubscription =
        DashBoardStateParent.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        setState(() {
          notificationCount;
        });
      }
    });


    DashBoardStatePartner.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted)
          setState(() {
            notificationCount;
          });
      }
    });
  }

  SlidableController slidableCtrl = SlidableController();

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Container getCellItem(Friends model, int index1) {
      return  Container(
          child: Slidable(
            controller: slidableCtrl,
        enabled: false,
        // Added this permission to disable the functionality of cancel
        child:  Column(
          children: <Widget>[
             Container(
              padding:  EdgeInsets.fromLTRB(20.0, 6.0, 20.0, 0.0),
              height: 90.0,
              child:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   Expanded(
                    child:  Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                        child:  Container(
                            width: 55.0,
                            child:  Stack(
                              children: <Widget>[
                                ProfileImageView(
                                  imagePath:   model
                                      .partnerProfilePicture ==
                                      null
                                      ? ""
                                      : Constant.IMAGE_PATH +
                                      model.partnerProfilePicture,
                                  placeHolderImage: model?.partnerRoleId == 4
                                      ? "assets/profile/partner_img.png"
                                      : 'assets/profile/user_on_user.png',
                                  height: 50.0,
                                  width: 50.0,
                                  onTap: () async{

                                  },
                                ),


                                 Positioned(
                                    left: 38.0,
                                    top: 28.0,
                                    child: model.online == 1 ||
                                            model.partnerId == 1
                                        ?  Container(
                                            child:  Image.asset(
                                              'assets/newDesignIcon/indicator_online_offline.png',
                                              width: 15.0,
                                              height: 15.0,
                                              fit: BoxFit.cover,
                                            ),
                                          )
                                        :  Container(
                                            width: 0.0,
                                            height: 0.0,
                                          )), // Online Offline display
                              ],
                            ))),
                    flex: 0,
                  ),
                   Expanded(
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                         Container(
                            child:  Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child:  Padding(
                                      padding:  EdgeInsets.fromLTRB(
                                          12.0, 0.0, 0.0, 0.0),
                                      child: BaseText(
                                        text: model.partnerLastName == null ||
                                                model.partnerLastName == "null"
                                            ? model.partnerFirstName == null ||
                                                    model.partnerFirstName ==
                                                        "null"
                                                ? ""
                                                : model.partnerFirstName
                                            : model.partnerFirstName +
                                                " " +
                                                model.partnerLastName,
                                        textColor: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18,
                                        maxLines: 1,
                                        textAlign: TextAlign.start,
                                      )),
                                  flex: 0,
                                ),

                                 Expanded(
                                  child:
                                  //model.mFriends.partnerRoleId == "1"
                                  true
                                      ? Util.getStudentBadge12(model.badge,model.badgeImage):Container(),
                                  flex: 0,
                                )
                              ],
                            ),
                             Padding(
                              padding:
                                   EdgeInsets.fromLTRB(12.0, 0.0, 10.0, 0.0),
                              child:  Text(
                                model.lastMessage == "null" ||
                                        model.lastMessage == ""
                                    ? ""
                                    : getTextValue(model) + firstHalf,
                                //model.lastMessage,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style:  TextStyle(
                                    color:
                                         ColorValues.GREY_TEXT_COLOR,
                                    fontSize: 13.0),
                              ),
                            ),
                          ],
                        )),
                      ],
                    ),
                    flex: 1,
                  ),
                   Expanded(
                    child:  Container(
                      height: 30.0,
                      width: 40.0,
                      child:  Stack(
                        children: <Widget>[
                          model.unreadMessages > 0
                              ?  Positioned(
                                  top: 1.0,
                                  right: 5.0,
                                  child:  Stack(
                                    children: <Widget>[
                                       Icon(Icons.brightness_1,
                                          size: 30.0,
                                          color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                                       Positioned(
                                          top: 10.0,
                                          bottom: 10.0,
                                          left: 10.0,
                                          right: 10.0,
                                          child:  Text(
                                            model.unreadMessages.toString(),
                                            textAlign: TextAlign.center,
                                            overflow: TextOverflow.ellipsis,
                                            style:  TextStyle(
                                                color: Colors.white,
                                                fontSize: 8.0),
                                          ))
                                    ],
                                  ),
                                )
                              :  Text(
                                  "",
                                  textAlign: TextAlign.center,
                                  overflow: TextOverflow.ellipsis,
                                  style:  TextStyle(
                                      color: Colors.white, fontSize: 8.0),
                                ),
                        ],
                      ),
                    ),
                    flex: 0,
                  )
                ],
              ),
            ),
             Padding(
              padding:  EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 0.0),
              child:  Divider(
                color:  ColorValues.BORDER_COLOR,
                height: 1.0,
              ),
            )
          ],
        ),
        actionPane: SlidableDrawerActionPane(),

        secondaryActions: <Widget>[

        ],
      ));
    }




    return ViewModelBuilder<ChatFriendListWithViewModel>.reactive(
      builder: (context, model, child) => customAppbar(
          context,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 20.0, right: 20, top: 24, bottom: 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      BaseText(
                        text: 'Share with',
                        textColor:
                        ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily:
                        AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ),



                    ],
                  ),
                ),
                flex: 0,
              ),
              Expanded(
                child: model.isLoading
                    ? Center(
                  child: Container(
                    // A simplified version of dialog.
                      width: 30.0,
                      height: 30.0,
                      child:  CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(Colors.black54),
                        strokeWidth: 2.0,
                      )),
                )
                    :  RefreshIndicator(
                    onRefresh: model.onRefresh,
                    displacement: 0.0,
                    child: model.friendList == null || model.friendList.length == 0
                        ?  Padding(
                      padding:  EdgeInsets.fromLTRB(0.0, 81.0, 0.0, 0.0),
                      child:  Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingAll(
                              15.0,
                              Image.asset(
                                "assets/no_message.png",
                                height: 94.0,
                                width: 113.0,
                              )),
                          Column(
                            children: <Widget>[
                              TextViewWrap.textView(
                                "No chats yet.",
                                TextAlign.left,
                                ColorValues.GREY_TEXT_COLOR,
                                16.0,
                                FontWeight.bold,
                              ),
                              PaddingWrap.paddingfromLTRB(
                                  20.0,
                                  10.0,
                                  20.0,
                                  0.0,
                                  TextViewWrap.textViewMultiLine(
                                      "No chats in your inbox, start chatting with people around you.",
                                      TextAlign.center,
                                      ColorValues.GREY_TEXT_COLOR,
                                      14.0,
                                      FontWeight.normal,
                                      3))
                            ],
                          )
                        ],
                      ),
                    )
                        :  ListView.builder(
                        itemCount: model.friendList.length,
                        itemBuilder: (BuildContext ctxt, int index) {
                          return  InkWell(
                            child: getCellItem(model.friendList[index], index),
                            onTap: () {
                              model.onTapItem(context, model.friendList[index]);
                            },
                          );
                        })),
                flex: 1,
              ),

            ],
          ), () {
        if(widget.link!=null&&widget.link!=null){
          if (widget.roleId == "1") {
            // For Studenet
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) =>  DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.CHAT_TYPE)));
          } else if (widget.roleId == "2") {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) =>  DashBoardWidgetParent(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.CHAT_TYPE)));

            // For Parent
          } else if (widget.roleId == "4") {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) =>  DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.CHAT_TYPE)));

            // For Partner
          }
        }else{
          Navigator.pop(context,"pop");
        }
      }, isShowIcon: false,isShowExplanation: false),
      viewModelBuilder: () => ChatFriendListWithViewModel(widget.link, widget.shareId, widget.sharedProfileId,pageName: widget.pageName==null?"":widget.pageName),
    );
    /*return ViewModelBuilder<ChatFriendListWithViewModel>.reactive(
      builder: (context, model, child) => Scaffold(
        backgroundColor:  ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
        appBar:  AppBar(
          elevation: 0.0,
          automaticallyImplyLeading: false,
          titleSpacing: 2.0,
          brightness: Brightness.light,
          leading:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               InkWell(
                child: CustomViews.getBackButton(),
                onTap: () {
                  if(widget.link!=null&&widget.link!=null){
                    if (widget.roleId == "1") {
                      // For Studenet
                      Navigator.pushReplacement(
                          context,
                           MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) =>  DashBoardWidget(
                                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: Constant.CHAT_TYPE)));
                    } else if (widget.roleId == "2") {
                      Navigator.pushReplacement(
                          context,
                           MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) =>  DashBoardWidgetParent(
                                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: Constant.CHAT_TYPE)));

                      // For Parent
                    } else if (widget.roleId == "4") {
                      Navigator.pushReplacement(
                          context,
                           MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) =>  DashBoardWidgetPartner(
                                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: Constant.CHAT_TYPE)));

                      // For Partner
                    }
                  }else{
                    Navigator.pop(context,"pop");
                  }
                },
              )
            ],
          ),
          actions: <Widget>[
             Container(width: 50.0),
          ],
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               Text(
                "Share With",
                style:  TextStyle(
                    fontSize: 18.0,
                    fontFamily: Constant.customRegular,
                    color:  ColorValues.HEADING_COLOR_EDUCATION),
              )
            ],
          ),
          backgroundColor: Colors.white,
        ),
        body: model.isLoading
            ? Center(
                child: Container(
                    // A simplified version of dialog.
                    width: 30.0,
                    height: 30.0,
                    child:  CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(Colors.black54),
                      strokeWidth: 2.0,
                    )),
              )
            :  RefreshIndicator(
                onRefresh: model.onRefresh,
                displacement: 0.0,
                child: model.friendList == null || model.friendList.length == 0
                    ?  Padding(
                        padding:  EdgeInsets.fromLTRB(0.0, 81.0, 0.0, 0.0),
                        child:  Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingAll(
                                15.0,
                                 Image.asset(
                                  "assets/no_message.png",
                                  height: 94.0,
                                  width: 113.0,
                                )),
                             Column(
                              children: <Widget>[
                                TextViewWrap.textView(
                                  "No chats yet.",
                                  TextAlign.left,
                                   ColorValues.GREY_TEXT_COLOR,
                                  16.0,
                                  FontWeight.bold,
                                ),
                                PaddingWrap.paddingfromLTRB(
                                    20.0,
                                    10.0,
                                    20.0,
                                    0.0,
                                    TextViewWrap.textViewMultiLine(
                                        "No chats in your inbox, start chatting with people around you.",
                                        TextAlign.center,
                                         ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal,
                                        3))
                              ],
                            )
                          ],
                        ),
                      )
                    :  ListView.builder(
                        itemCount: model.friendList.length,
                        itemBuilder: (BuildContext ctxt, int index) {
                          return  InkWell(
                            child: getCellItem(model.friendList[index], index),
                            onTap: () {
                              model.onTapItem(context, model.friendList[index]);
                            },
                          );
                        })),
      ),
      viewModelBuilder: () => ChatFriendListWithViewModel(widget.link, widget.shareId, widget.sharedProfileId,pageName: widget.pageName==null?"":widget.pageName),
    );*/
  }

  String getTextValue(Friends model) {
    //print('model.lastMessage.length:: ${model.lastMessage.length}');
    if (model.lastMessage.length > 24) {
      firstHalf = model.lastMessage.substring(0, 24) + '...';
    } else {
      firstHalf = model.lastMessage;
    }
    try {
      if (model.userId != null) {
        if (model.textSentBy == model.userId) {
          return "You: ";
        }

        if (model.textSentBy == model.partnerId) {
          // return model.partnerFirstName + ": ";
          return " ";
        }
      }
      return " ";
    } catch (e) {
      return " ";
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
