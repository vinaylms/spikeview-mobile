// Updated COde

import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/gestures.dart';
//import 'package:flutter_verification_code/flutter_verification_code.dart';

import 'package:http/http.dart' as http;
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/image_utils.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/gateway/TakeATour.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

import 'Login_Widget.dart';

class EmailOtpVerification extends StatefulWidget {
  String email = '';

  EmailOtpVerification(this.email);

  @override
  EmailOtpVerificationState createState() => EmailOtpVerificationState();
}

final formKey = GlobalKey<FormState>();
String _email = "";
bool _isLoading = false;

class EmailOtpVerificationState extends State<EmailOtpVerification> {
  Color borderColor = Colors.amber;
  SharedPreferences prefs;
  String roleId, userId, email;

  void _checkValidation() {
    final form = formKey.currentState;
    setState(() => _isLoading = true);
    form.save();
    if (form.validate()) {
      forgotpassworApiCalling();
    } else {
      setState(() => _isLoading = false);
      print("Failure 00");
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    userId = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    email = widget.email;
  }

  ontapCancel() {
    Navigator.pop(context);
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  onBack() {
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginPage(null)));
  }

  showSucessMsg(msg, context, push) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg:msg=='otp'?"Your otp has been send successfully": 'Your email has been changed successfully',
            headingText:msg=='otp'?'Successfully send': 'Successfully change',
            negativeText: 'OK',
            isSucessPopup: true,
            onNegativeTap: () {
              if(msg=='otp'){
                //Navigator.pop(context, 'pop');
              } else {
                Navigator.pop(context, 'push');
              }
            },
          );
        });
  }

  forgotpassworApiCalling() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data
        var map = {
          "userId": userId,
          "verificationType": "changeEmailOTP",
          "otp": _code
        };
        print('map+++$map');
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_OTP_VERIFICATION,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            showSucessMsg(message, context, true);
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          setState(() => _isLoading = false);
          // If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
        CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      setState(() => _isLoading = false);
      // CustomProgressLoader.cancelLoader(context);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  resendOtpApi() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data
        var map = {
          "userId": userId,
          "email": email,
          "type": "changeEmailOTP",
          "actionType": "resend"
        };
        print('map+++$map');
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_OTP_RESEND,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            prefs.setString(UserPreference.EMAIL, email.trim());
            showSucessMsg('otp', context, false);
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          setState(() => _isLoading = false);
          // If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
        CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      setState(() => _isLoading = false);
      // CustomProgressLoader.cancelLoader(context);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  Future apiCallingUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {"userId": userId, "stage": "1"};
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            print("update data+++ apiCallingUpdate");
            if (status == "Success") {
              Navigator.pop(context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  bool _onEditing = true;
  String _code = '';

  onTapSignOut() async {
    // setState(() {
    Constant.isAlreadyLoggedIn = false;
    //});

    Map map = {
      "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
      "deviceId": prefs.getString("deviceId")
    };
    GlobalSocketConnection.socket
        .emitWithAck("disconnect1", [map]).then((data) {
      print("chat-login++++" + data.toString());
    });

    GlobalSocketConnection.socket.emit("disconnect2", []);

    prefs.setString(UserPreference.NAME, "");
    prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
    prefs.setBool(UserPreference.IS_USER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
    prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
    bloc.resetData(prefs);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage(null)),
    );
  }

  TextEditingController textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return WillPopScope(
        onWillPop: () {},
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: customAppbar(
              context,
              SingleChildScrollView(
                child: Form(
                    key: formKey,
                    child: Container(
                      padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom,
                        left: 0, //11.0,
                        right: 0, // 11.0,
                      ),
                      child: Container(
                        //color: Colors.black.withOpacity(0.8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                                padding: const EdgeInsets.only(
                                    left: 20.0,
                                    right: 0.0,
                                    top: 24.0,
                                    bottom: 150),
                                child: RichText(
                                  maxLines: 1,
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    text: 'Enter verification code',
                                    style: AppConstants
                                        .txtStyle.heading400LatoRegularDarkBlue
                                        .copyWith(
                                            fontSize: 28,
                                            fontWeight: FontWeight.w700),
                                    children: [
                                      TextSpan(
                                          text: '',
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {},
                                          style: AppConstants.txtStyle
                                              .heading40018LatoRegularDarkBlue
                                              .copyWith(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.w700)),
                                    ],
                                  ),
                                )),
                            Center(
                              child: SizedBox(
                                width: 230,
                                child: PinCodeTextField(
                                  length: 4,
                                  keyboardType: TextInputType.number,
                                  obscureText: true,
                                  animationType: AnimationType.fade,
                                  pinTheme: PinTheme(
                                      shape: PinCodeFieldShape.underline,
                                      activeColor: Color(0xffE5EBF0),
                                      inactiveColor: Color(0xffE5EBF0),
                                      disabledColor: Color(0xffE5EBF0),
                                      activeFillColor: Color(0xffE5EBF0),
                                      selectedFillColor: Color(0xffE5EBF0),
                                      inactiveFillColor: Color(0xffE5EBF0),
                                      fieldWidth: 49),
                                  textStyle: TextStyle(
                                      fontSize: 16.0,
                                      color: AppConstants.colorStyle.darkBlue),
                                  animationDuration:
                                      Duration(milliseconds: 300),
                                  backgroundColor: Colors.transparent,
                                  enableActiveFill: false,
                                  controller: textController,
                                  onCompleted: (v) {
                                    setState(() {
                                      _code = v;
                                    });
                                  },
                                  onChanged: (value) {
                                    setState(() {
                                      _code = value;
                                    });
                                  },
                                  beforeTextPaste: (text) {
                                    print("Allowing to paste $text");
                                    //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                                    //but you can show anything you want here, like your pop up saying wrong paste format or etc
                                    return true;
                                  },
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsets.fromLTRB(20.0, 10, 20.0, 50.0),
                              child: InkWell(
                                child: Center(
                                  child: BaseText(
                                    text:
                                        'Please enter the verification code sent to the email you provided.',
                                    textColor:
                                        AppConstants.colorStyle.lightPurple,
                                    textAlign: TextAlign.center,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                  ),
                                ),
                                onTap: () {},
                              ),
                            ),
                            Padding(
                                padding: EdgeInsets.only(
                                    left: 0.0, right: 0.0, top: 0, bottom: 0),
                                child: Container(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      /* Container(color: Color(0xfff1f1f1),height: 1.0,),*/
                                      Center(
                                        child: RichText(
                                          maxLines: 1,
                                          textAlign: TextAlign.center,
                                          text: TextSpan(
                                            text: 'Didn’t get verification code? ',
                                            style: AppConstants.txtStyle
                                                .heading400LatoRegularDarkBlue,
                                            children: [
                                              TextSpan(
                                                  text: 'Resend',
                                                  recognizer:
                                                      TapGestureRecognizer()
                                                        ..onTap = () {
                                                          resendOtpApi();
                                                        },
                                                  style: AppConstants.txtStyle
                                                      .heading400LatoRegularLightBlue),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )),
                            Container(
                                child: Padding(
                                    padding: EdgeInsets.only(
                                        left: 20.0, top: 35.0, right: 20.0),
                                    child: Stack(
                                      children: <Widget>[
                                        Container(
                                            height: 44.0,
                                            width: double.infinity,
                                            child: FlatButton(
                                              onPressed: () async {
                                                _checkValidation();
                                              },
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          10)),
                                              color: AppConstants
                                                  .colorStyle.lightBlue,
                                              child: Row(
                                                // Replace with a Row for horizontal icon + text
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text('Continue',
                                                      style: AppConstants
                                                          .txtStyle
                                                          .heading18600LatoRegularWhite),
                                                ],
                                              ),
                                            )),
                                        _code.length == 4
                                            ? SizedBox(
                                                height: 0,
                                              )
                                            : Container(
                                                height: 44.0,
                                                width: double.infinity,
                                                color: Colors.white
                                                    .withOpacity(0.75),
                                              )
                                      ],
                                    )))
                          ],
                        ),
                      ),
                    )),
              ),
              () {
                Navigator.pop(context);
              },
              isShowExplanation: false,
            )));
  }
}
