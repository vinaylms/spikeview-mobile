import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class AddGoogleDocLink extends StatefulWidget {
  final String googleDocLink;
  final String googleDocTitle;

  AddGoogleDocLink({this.googleDocLink, this.googleDocTitle});

  @override
  State<StatefulWidget> createState() => AddGoogleDocLinkState();
}

class AddGoogleDocLinkState extends State<AddGoogleDocLink>
    with BaseCommonWidget {
  final FocusNode _titleFocus = FocusNode();
  final FocusNode _urlFocus = FocusNode();
  final titleController = TextEditingController();
  final linkController = TextEditingController();

  String url;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    if (widget.googleDocLink != null) {
      linkController.text = widget.googleDocLink;
    }
    if (widget.googleDocTitle != null) {
      titleController.text = widget.googleDocTitle;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext=context;
    // TODO: implement build
    return SafeArea(
      child: Scaffold(
        appBar:  AppBar(
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          brightness: Brightness.light,
          leading:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               InkWell(
                child:  SizedBox(
                  height: 40.0,
                  width: 40.0,
                  child: PaddingWrap.paddingfromLTRB(
                      10.0,
                      5.0,
                      0.0,
                      3.0,
                       Center(
                          child:  Image.asset(
                              "assets/newDesignIcon/navigation/back.png",
                              height: 20.0,
                              width: 10.0,
                              fit: BoxFit.fitHeight))),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              )
            ],
          ),
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               Text(
                //"Upload Document",
                "Other Link",
                style:  TextStyle(
                    fontSize: 18.0,
                    fontFamily: Constant.customRegular,
                    color:  ColorValues.HEADING_COLOR_EDUCATION),
              )
            ],
          ),
          actions: <Widget>[
            InkWell(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(right: 14.0),
                  child: Text(
                    'Save  ',
                    textAlign: TextAlign.center,
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 16, FontType.Regular),
                  ),
                ),
              ),
              onTap: () {
                goToPreviousPage();
              },
            )
          ],
          backgroundColor: Colors.white,
          elevation: 0.0,
        ),
        body:  Column(children: <Widget>[
         Expanded(child:CustomViews.getSepratorLine(),flex: 0,),
           Expanded(child: Container(
            color: Palette.webColor,
            padding: EdgeInsets.all(UIHelper.screenPadding),
            child: Form(
              key: _formKey,
              child: ListView(
                children: <Widget>[
                  /*     UIHelper.verticalSpaceMedium,
                    TextFormField(
                      focusNode: _titleFocus,
                      controller: titleController,
                      decoration:
                          textFormFieldDecorationWithLabel('Text To Display'),
                      style: textFormFieldValueStyle(),
                      keyboardType: TextInputType.text,
                      textCapitalization: TextCapitalization.sentences,
                      onFieldSubmitted: (term) {
                        _titleFocus.unfocus();
                        FocusScope.of(context).requestFocus(_urlFocus);
                      },
                      validator: (value) {
                        return ValidationChecks.validateTextToDisplay(value);
                      },
                    ),*/
                  UIHelper.verticalSpaceMedium,
                  TextFormField(
                    focusNode: _urlFocus,
                    controller: linkController,
                    decoration:
                    textFormFieldDecorationWithLabel('Document URL'),
                    style: textFormFieldValueStyle(),
                    keyboardType: TextInputType.text,
                    /*  onChanged: (val) {
                        url = val;
                      },*/
                    onFieldSubmitted: (term) {
                      url = term;
                      //_urlFocus.unfocus();
                      //goToPreviousPage();
                    },
                    validator: (value) {
                      return ValidationChecks.validateDocURL(value);
                    },
                  ),
                  Text(
                    'Copy or type the link of your document folder',
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.secondaryTextColor, 12, FontType.Regular),
                  ),
                ],
              ),
            ),
          ),flex: 1,)
        ],)
      ),
    );
  }

  void goToPreviousPage() {
    if (_formKey.currentState.validate()) {
      Navigator.pop(
          context, linkController.text + '#####' + titleController.text);
    }
  }
}
