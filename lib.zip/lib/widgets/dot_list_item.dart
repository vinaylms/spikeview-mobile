import 'package:flutter/material.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';

class DotListItem extends StatelessWidget {
  final String text;

  const DotListItem({
    @required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Expanded(
          child:  Container(
            height: 24,
            alignment: Alignment.center,
            child: Container(
              height: 6,
              width: 6,
              decoration: new BoxDecoration(
                color: const Color(0xff27275A),
                shape: BoxShape.circle,
              ),
            ),
          ),
          flex: 6,
        ),
        Expanded(
          child: BaseText(
            text: text,
            textColor: const Color(0xff27275A),
            fontWeight: FontWeight.w400,
            fontSize: 16,
            fontFamily: Constant.latoRegular,
            lineHeight: 1.4,
          ),
          flex: 94,
        ),
      ],
    );
  }
}
