import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:cached_network_image/cached_network_image.dart';

class CommonFullViewWidget extends StatefulWidget {
  List<dynamic> fileDataList;
  String pageName;
  int initialPage;
  String appbarHeading;

  CommonFullViewWidget(
      this.fileDataList, this.pageName, this.initialPage, this.appbarHeading);

  @override
  State createState() {
    return CommonFullViewWidgetState(fileDataList);
  }
}

class CommonFullViewWidgetState extends State<CommonFullViewWidget> {
  // ChewieController _chewieController;
  List<dynamic> fileDataList;

  CommonFullViewWidgetState(this.fileDataList);

  double bottomPadding = 32.0;

  @override
  void initState() {
    if (widget.pageName == MessageConstant.HOME_HEDING ||
        widget.pageName == MessageConstant.HOME_FEED ||
        widget.pageName == MessageConstant.HOME_OPPORTUNITY_HEDING) {
      bottomPadding = 92.0;
    }
    super.initState();
  }

  Widget _loader1(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation(Colors.white),
        ),
      ));

  Widget _error1(String placeHolderImage) {
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          elevation: 0.0,
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const SizedBox(width: 14),
              Expanded(
                child: InkWell(
                  child: Image.asset(
                    "assets/new_onboarding/back_blue_icon.png",
                    height: 32.0,
                    width: 32.0,
                    fit: BoxFit.fill,
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  },
                ),
                flex: 0,
              ),
              Expanded(
                child: Text(
                  '${widget.appbarHeading}',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 18.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                flex: 1,
              ),
              Expanded(
                child: SizedBox(
                  height: 40.0,
                  width: 40.0,
                ),
                flex: 0,
              ),
            ],
          ),
          backgroundColor: Colors.white,
        ),
        backgroundColor: Color(0xff101621),
        body: CarouselSlider.builder(
          //physics: NeverScrollableScrollPhysics(),
          //scrollDirection: Axis.horizontal,
          //shrinkWrap: true,
          //controller: _controller,
          itemCount: fileDataList.length,
          options: CarouselOptions(
            height: double.maxFinite,
            initialPage: widget.initialPage,
            //width: MediaQuery.of(context).size.width,
            //aspectRatio: 16/9,
            viewportFraction: 1.0,
            enableInfiniteScroll: false,
            reverse: false,
            autoPlay: false,
            //autoPlayInterval: Duration(seconds: 3),
            //autoPlayAnimationDuration: Duration(milliseconds: 800),
            //autoPlayCurve: Curves.fastOutSlowIn,
            //enlargeCenterPage: true,
            //onPageChanged: callbackFunction,
            scrollDirection: Axis.horizontal,
          ),
          itemBuilder: (context, index) {
            print(
                "SSS image ${fileDataList[index].file} -- ${widget.pageName}");
            return Padding(
              padding: const EdgeInsets.only(bottom: 0.0),
              child: Padding(
                padding: const EdgeInsets.only(right: 0.0),
                //pagerList.length != index+1 ?  const EdgeInsets.only(right: 24.0): const EdgeInsets.only(right: 0.0),
                child: widget.pageName ==
                            MessageConstant.ACCOMPLISHMENT_HEDING ||
                        widget.pageName ==
                            MessageConstant.HOME_OPPORTUNITY_HEDING
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          fileDataList[index].type == 'image'
                              ? Center(
                                  child: CachedNetworkImage(
                                 /* height: MediaQuery.of(context).size.height -
                                      (bottomPadding +
                                          AppBar().preferredSize.height -
                                          MediaQuery.of(context)
                                              .padding
                                              .bottom +
                                          MediaQuery.of(context).padding.top),*/
                                  width: MediaQuery.of(context).size.width,
                                  imageUrl:
                                      '${Constant.IMAGE_PATH}${fileDataList[index].file}',
                                  fit: BoxFit.contain,
                                  placeholder: (context, url) => _loader1(
                                      context, "assets/aerial/default_img.png"),
                                  errorWidget: (context, url, error) =>
                                      _error1("assets/aerial/default_img.png"),
                                ))
                              : Center(
                                  child: Container(
                                  color: Colors.black,
                                  height: MediaQuery.of(context).size.height -
                                      (bottomPadding +
                                          AppBar().preferredSize.height -
                                          MediaQuery.of(context)
                                              .padding
                                              .bottom +
                                          MediaQuery.of(context).padding.top),
                                  width: double.infinity,
                                  child: Center(
                                    child: VideoPlayPause(
                                        fileDataList[index].file,
                                        "FromMediaDetailPage",
                                        true),
                                  ),
                                )),
                        ],
                      )
                    : widget.pageName ==
                                MessageConstant.CERTIFICATES_TROPHIES_HEDING ||
                            widget.pageName ==
                                MessageConstant.CUSTOM_PROFILE_HEDING ||
                            widget.pageName ==
                                MessageConstant.TEST_SCORE_HEDING ||
                            widget.pageName == MessageConstant.HOME_HEDING ||
                            widget.pageName == MessageConstant.HOME_FEED
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Center(
                                  child: CachedNetworkImage(
                                /*height: MediaQuery.of(context).size.height -
                                    (bottomPadding +
                                        AppBar().preferredSize.height -
                                        MediaQuery.of(context).padding.bottom +
                                        MediaQuery.of(context).padding.top),*/
                                width: MediaQuery.of(context).size.width,
                                imageUrl: widget.pageName ==
                                            MessageConstant
                                                .CUSTOM_PROFILE_HEDING ||
                                        widget.pageName ==
                                            MessageConstant.HOME_HEDING
                                    ? '${Constant.IMAGE_PATH}${fileDataList[index].file}'
                                    : '${Constant.IMAGE_PATH}${fileDataList[index].file}',
                                fit: BoxFit.contain,
                                placeholder: (context, url) => _loader1(
                                    context, "assets/aerial/default_img.png"),
                                errorWidget: (context, url, error) =>
                                    _error1("assets/aerial/default_img.png"),
                              ))
                            ],
                          )
                        : widget.pageName ==
                                MessageConstant.OPPORTUNITY_DETAIL_VIDEO_HEDING
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Center(
                                      child: Container(
                                    color: Colors.black,
                                    /*height: MediaQuery.of(context).size.height -
                                        (bottomPadding +
                                            AppBar().preferredSize.height -
                                            MediaQuery.of(context)
                                                .padding
                                                .bottom +
                                            MediaQuery.of(context).padding.top),*/
                                    width: double.infinity,
                                    child: Center(
                                      child: VideoPlayPause(
                                          fileDataList[index].path,
                                          "FromMediaDetailPage",
                                          true),
                                    ),
                                  )),
                                ],
                              )
                            : Container(),
              ),
            );
          },
        ));
  }
}
