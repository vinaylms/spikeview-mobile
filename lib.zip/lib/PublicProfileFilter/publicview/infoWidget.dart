import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/PublicProfileFilter/ShareProfileView.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/PublicProfileDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicProfilePreViewWidget.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomPresoViewForUser.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class infoWidget extends StatefulWidget {
  @override
  infoWidgetState createState() {
    return   infoWidgetState();
  }
}

class infoWidgetState extends State<infoWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor:   ColorValues.singin_bg_color,
        appBar:   AppBar(
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          elevation: 0.0,
          title:   Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
                Expanded(
                child:   InkWell(
                  child: CustomViews.getBackButton(),
                  onTap: () {
                    Navigator.pop(context);
                  },
                ),
                flex: 0,
              ),
                Expanded(
                child:   Text(
                  "Information",
                  textAlign: TextAlign.center,
                  style:   TextStyle(
                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 18.0,
                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                ),
                flex: 1,
              ),
            ],
          ),actions: [new Container(width: 35,)],
          backgroundColor: Colors.white,
        ),
        body: Container(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
            child: ListView(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    CustomViews.getSepratorLine(),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(13.0, 0, 13, 0),
                      child:   Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0.0,13,0,13),
                            child: Text(
                                "This helps you control your privacy and security on spikeview",
                                style: TextStyle(
                                    fontSize: 14,
                                    color:
                                    ColorValues.GREY__COLOR,
                                    fontFamily:
                                    Constant.TYPE_CUSTOMREGULAR)),


                          ),

                            Container(

                            decoration:   BoxDecoration(
                                color: Colors.white,
                                border:   Border.all(
                                    width: 1.0,
                                    color:
                                      ColorValues.DARK_GREY)),
                            child: Padding(
                              padding: const EdgeInsets.all(13.0),
                              child:   Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Expanded(child:PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      10.0,
                                      0.0,
                                        Center(
                                          child:   Image.asset(
                                              "assets/newIcon/profile_visibility.png",
                                              height: 27.0,
                                              width: 27.0,
                                              fit: BoxFit.fill))) ,flex: 0,),
                                    Expanded(child:  Padding(
                                    padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                    child: Text(
                                        "Profile visibility for connected users",
                                        style: TextStyle(
                                            fontSize: 16,
                                            color:
                                            ColorValues.HEADING_COLOR_EDUCATION,
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR)),


                                  ),flex: 1,),
                                ],),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(0.0,18,0,0),
                                  child:   Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Expanded(child:PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        10.0,
                                        0.0,
                                          Image.asset(
                                          "assets/story_new/bullet_dot.png",
                                          width: 5.0,
                                          height: 5.0,
                                        )) ,flex: 0,),
                                      Expanded(child:  Padding(
                                      padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                      child: Text(
                                          "Aenean imperdiet mi tellus vel massa mollis.",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color:
                                              ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR)),


                                    ),flex: 1,),
                                  ],),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(0.0,13,0,0),
                                  child:   Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Expanded(child:PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        10.0,
                                        0.0,
                                          Image.asset(
                                          "assets/story_new/bullet_dot.png",
                                          width: 5.0,
                                          height: 5.0,
                                        )) ,flex: 0,),
                                      Expanded(child:  Padding(
                                      padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                      child: Text(
                                          "Aenean imperdiet mi tellus vel massa mollis.",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color:
                                              ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR)),


                                    ),flex: 1,),
                                  ],),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(0.0,13,0,0),
                                  child:   Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Expanded(child:PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        10.0,
                                        0.0,
                                          Image.asset(
                                          "assets/story_new/bullet_dot.png",
                                          width: 5.0,
                                          height: 5.0,
                                        )) ,flex: 0,),
                                      Expanded(child:  Padding(
                                      padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                      child: Text(
                                          "Aenean imperdiet mi tellus vel massa mollis.",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color:
                                              ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR)),


                                    ),flex: 1,),
                                  ],),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(0.0,13,0,0),
                                  child:   Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Expanded(child:PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        10.0,
                                        0.0,
                                          Image.asset(
                                          "assets/story_new/bullet_dot.png",
                                          width: 5.0,
                                          height: 5.0,
                                        )) ,flex: 0,),
                                      Expanded(child:  Padding(
                                      padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                      child: Text(
                                          "Aenean imperdiet mi tellus vel massa mollis.",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color:
                                              ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR)),


                                    ),flex: 1,),
                                  ],),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(0.0,13,0,0),
                                  child:   Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Expanded(child:PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        10.0,
                                        0.0,
                                          Image.asset(
                                          "assets/story_new/bullet_dot.png",
                                          width: 5.0,
                                          height: 5.0,
                                        )) ,flex: 0,),
                                      Expanded(child:  Padding(
                                      padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                      child: Text(
                                          "Aenean imperdiet mi tellus vel massa mollis.",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color:
                                              ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR)),


                                    ),flex: 1,),
                                  ],),
                                ),
                              ],),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.fromLTRB(0.0,13,0,13),
                            child:   Container(

                              decoration:   BoxDecoration(
                                  color: Colors.white,
                                  border:   Border.all(
                                      width: 1.0,
                                      color:
                                        ColorValues.DARK_GREY)),
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(5.0,13,13,13),
                                child:   Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Expanded(child:PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        6.0,
                                        0.0,
                                          Center(
                                            child:   Image.asset(
                                                "assets/newIcon/non_connected.png",
                                                height: 40.0,
                                                width: 40.0,
                                                fit: BoxFit.fill))) ,flex: 0,),
                                      Expanded(child:  Padding(
                                      padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                      child: Text(
                                          "Profile visibility for non connected users",
                                          style: TextStyle(
                                              fontSize: 16,
                                              color:
                                              ColorValues.HEADING_COLOR_EDUCATION,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR)),


                                    ),flex: 1,),
                                  ],),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(8.0,0,0,0),
                                  child:   Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(0.0,18,0,0),
                                        child:   Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Expanded(child:PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              0.0,
                                              10.0,
                                              0.0,
                                                Image.asset(
                                                "assets/story_new/bullet_dot.png",
                                                width: 5.0,
                                                height: 5.0,
                                              )) ,flex: 0,),
                                            Expanded(child:  Padding(
                                            padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                            child: Text(
                                                "Aenean imperdiet mi tellus vel massa mollis.",
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    color:
                                                    ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR)),


                                          ),flex: 1,),
                                        ],),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(0.0,13,0,0),
                                        child:   Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                              Expanded(child:PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                10.0,
                                                0.0,
                                                  Image.asset(
                                                  "assets/story_new/bullet_dot.png",
                                                  width: 5.0,
                                                  height: 5.0,
                                                )) ,flex: 0,),
                                              Expanded(child:  Padding(
                                              padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                              child: Text(
                                                  "Aenean imperdiet mi tellus vel massa mollis.",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color:
                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR)),


                                            ),flex: 1,),
                                          ],),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(0.0,13,0,0),
                                        child:   Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                              Expanded(child:PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                10.0,
                                                0.0,
                                                  Image.asset(
                                                  "assets/story_new/bullet_dot.png",
                                                  width: 5.0,
                                                  height: 5.0,
                                                )) ,flex: 0,),
                                              Expanded(child:  Padding(
                                              padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                              child: Text(
                                                  "Aenean imperdiet mi tellus vel massa mollis.",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color:
                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR)),


                                            ),flex: 1,),
                                          ],),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(0.0,13,0,0),
                                        child:   Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                              Expanded(child:PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                10.0,
                                                0.0,
                                                  Image.asset(
                                                  "assets/story_new/bullet_dot.png",
                                                  width: 5.0,
                                                  height: 5.0,
                                                )) ,flex: 0,),
                                              Expanded(child:  Padding(
                                              padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                              child: Text(
                                                  "Aenean imperdiet mi tellus vel massa mollis.",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color:
                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR)),


                                            ),flex: 1,),
                                          ],),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(0.0,13,0,0),
                                        child:   Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                              Expanded(child:PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                10.0,
                                                0.0,
                                                  Image.asset(
                                                  "assets/story_new/bullet_dot.png",
                                                  width: 5.0,
                                                  height: 5.0,
                                                )) ,flex: 0,),
                                              Expanded(child:  Padding(
                                              padding: const EdgeInsets.fromLTRB(0.0,0,0,0),
                                              child: Text(
                                                  "Aenean imperdiet mi tellus vel massa mollis.",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color:
                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR)),


                                            ),flex: 1,),
                                          ],),
                                      ),
                                    ],
                                  )),

                                ],),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ));
  }
}
