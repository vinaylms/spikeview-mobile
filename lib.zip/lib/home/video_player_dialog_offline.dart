import 'dart:async';
import 'dart:io';

import 'package:flutter/gestures.dart';
import 'package:keyboard_avoider/keyboard_avoider.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/EditPostWidget.dart';
import 'package:spike_view_project/home/OpportunityView.dart';
import 'package:spike_view_project/home/SelectedGroup.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/linkPreview/link_preview.dart';
import 'package:spike_view_project/linkPreview/whatsapp/index.dart';
import 'package:spike_view_project/linkPreview/whatsapp/view.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/report/ReportWidget.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/home/AddPost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/home/CommentListWidget.dart';
import 'package:spike_view_project/home/LikeDetailWidget.dart';
import 'package:spike_view_project/home/SharePostWidget.dart';
import 'package:spike_view_project/home/TagDetailWidget.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/shareFlow/ConnectionSelectionWidget.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:chewie/chewie.dart';
import 'package:cached_network_image/cached_network_image.dart';


class VideoPlayPauseDialogOffline extends StatefulWidget {
  final String path;
  bool isShowControll = true;
  String feedId, pageName;
  bool isDialogVideo;

  VideoPlayPauseDialogOffline(this.path,
  this.feedId,
  this.isShowControll,
  {this.pageName});

  @override
  State createState() {
    return  VideoPlayPauseDialogOfflineState();
  }
}

class VideoPlayPauseDialogOfflineState extends State<VideoPlayPauseDialogOffline> {
  FadeAnimation imageFadeAnim =
       FadeAnimation(child:  Icon(Icons.play_arrow, size: 100.0));
  VoidCallback listener;
  bool isApiNeedToCall = true;
  static StreamController syncDoneController = StreamController.broadcast();

  bool isplaying = false;

  Future apiCallingForIncreaseCount(feedId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCall(context,
            Constant.ENDPOINT_INCREASE_NUMBER_OF_COUNT + feedId, "get");

        print("apiCallingForIncreaseCount data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      e.toString();
    }
  }

  VideoPlayerController controller;
  ChewieController _chewieController;
  TargetPlatform _platform;

  VideoPlayPauseState() {
    print("clicked data---------> +++++ ");
    listener = () {
      final bool isPlaying = controller.value.isPlaying;
      if (mounted) {
        setState(() {});
      }
      if (controller.value.isPlaying) {
        if (isApiNeedToCall) {
          if (widget.feedId != "") apiCallingForIncreaseCount(widget.feedId);
        }
        isApiNeedToCall = false;
      } else {
        //print("clicked data +++++");
        isApiNeedToCall = true;
//apiCallingForIncreaseCount(widget.feedId);
      }
    };
  }

  // ChewieController _chewieController;

  @override
  void initState() {
    super.initState();
    _platform = TargetPlatform.android;
    if (widget.isShowControll == null) {
      widget.isShowControll = true;
    }
    print("video path++++++++++++++" + Constant.PATH_FOR_VIDEO + widget.path);
    controller =VideoPlayerController.file(File(widget.path));

    controller.addListener(listener);

    controller.setVolume(1.0);

    controller.pause();
    controller.initialize();
    //  controller.seekTo(Duration(seconds: 5));

    controller.addListener(() {
      if (widget.pageName != null && widget.pageName == "profile") {
        if (controller.value.isPlaying || isplaying) {
          final bool isPlaying = controller.value.isPlaying;
          if (isPlaying) {
            print("shubh--playing.....");
            isplaying = true;
          } else {
            isplaying = false;
            syncDoneController.add("sucess");
            print("shubh--pause.....");
          }
        }
      }
    });

  }

  @override
  void deactivate() {
    controller.setVolume(0.0);
    controller.removeListener(listener);
    //_chewieController.dispose();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    final List<Widget> children = <Widget>[
       GestureDetector(
        child:  Container(
            color: Colors.transparent,
            child:  Stack(
              children: <Widget>[
                 Center(
                  child: controller.value.initialized
                      ? ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: Chewie(
                            controller: ChewieController(
                              videoPlayerController: controller,
                              autoPlay: false,

                              allowFullScreen: false,
                              aspectRatio: controller.value.aspectRatio,
                              looping: false,
                              showControls: widget.isShowControll,
                              // Try playing around with some of these other options:
                              placeholder: Container(
                                /*child: Center(
                                child:
                                    Image.asset("assets/aerial/default_img.png")
                            ),*/
                                color: Colors.transparent,
                              ),
                            ),
                          ),
                      )
                      :  Center(
                          child:  Container(
                          child: widget.feedId == "FromMediaDetailPage"
                              ?  CircularProgressIndicator(
                                  valueColor:
                                      AlwaysStoppedAnimation(Colors.white),
                                )
                              :  CircularProgressIndicator(),
                        )),
                ),
              ],
            )),
        onTap: () {
          print("Play Data+++++");
          if (!controller.value.initialized) {
            return;
          }
          if (controller.value.isPlaying) {
            imageFadeAnim =
                 FadeAnimation(child:  Icon(Icons.pause, size: 100.0));
            controller.pause();
          } else {
            imageFadeAnim =  FadeAnimation(
                child:  Icon(Icons.play_arrow, size: 100.0));
            controller.play();

            print("Play Data+++++");
          }
        },
      ),
       Center(child: imageFadeAnim),
    ];
/*

    if (!controller.value.initialized) {
      children.add(new Center(child: const CupertinoActivityIndicator()));
    }
*/

    return  MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.light().copyWith(
      platform: _platform ?? Theme.of(context).platform,
    ),
    home: Scaffold(
    body: Stack(
        alignment: Alignment.bottomCenter,
        fit: StackFit.passthrough,
        children: children,
      ),
    )
    );
  }

/* @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;



    return   Container(
        width: double.infinity,
        child:   Chewie(
          controller: _chewieController,
        )


    );
  }*/
}

class FadeAnimation extends StatefulWidget {
  final Widget child;
  final Duration duration;

  FadeAnimation({this.child, this.duration: const Duration(milliseconds: 500)});

  @override
  _FadeAnimationState createState() =>  _FadeAnimationState();
}

class _FadeAnimationState extends State<FadeAnimation>
    with SingleTickerProviderStateMixin {
  AnimationController animationController;

  @override
  void initState() {
    super.initState();
    animationController =
         AnimationController(duration: widget.duration, vsync: this);
    animationController.addListener(() {
      if (mounted) {
        setState(() {});
      }
    });
    animationController.forward(from: 0.0);
  }

  @override
  void deactivate() {
    animationController.stop();
    super.deactivate();
  }

  @override
  void didUpdateWidget(FadeAnimation oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.child != widget.child) {
      animationController.forward(from: 0.0);
    }
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return animationController.isAnimating
        ?  Opacity(
            opacity: 1.0 - animationController.value,
            child: widget.child,
          )
        :  Container();
  }
}

typedef Widget VideoWidgetBuilder(
    BuildContext context, VideoPlayerController controller);

/// A widget connecting its life cycle to a [VideoPlayerController].
class PlayerLifeCycle extends StatefulWidget {
  final VideoWidgetBuilder childBuilder;
  final String uri;

  PlayerLifeCycle(this.uri, this.childBuilder);

  @override
  _PlayerLifeCycleState createState() =>  _PlayerLifeCycleState();
}

class _PlayerLifeCycleState extends State<PlayerLifeCycle> {
  VideoPlayerController controller;

  _PlayerLifeCycleState();

  @override
  void initState() {
    super.initState();
    controller =  VideoPlayerController.network(widget.uri.replaceAll(" ", "%20"));
    controller.addListener(() {
      if (controller.value.isBuffering) {
        print(controller.value.errorDescription);
      }
    });

    controller.initialize();
    controller.setLooping(false);
    controller.pause();
  }

  @override
  void deactivate() {
    super.deactivate();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.childBuilder(context, controller);
  }
}

class HomeWidget extends StatefulWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey;
  int notificationCount = 0;

  HomeWidget(this._scaffoldKey, this.notificationCount);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  HomeWidgetState(notificationCount);
  }
}

class HomeWidgetState extends State<HomeWidget>
    with AutomaticKeepAliveClientMixin {
  HomeWidgetState(this.notificationCount);

  String userIdPref, userName, roleId, token, dob, profile_image_path;
  bool isShare = false;
  int diffrenceInDob = 14;
  bool isComment = false;
  int offset = 0;
  bool isLoadMore = true;
  bool isLoadingData = false;
  String strComment = "";
  TextEditingController commentControl =  TextEditingController(text: "");
  List<UserPostModal> userPostList =  List<UserPostModal>();
  SharedPreferences prefs;
  StreamSubscription<dynamic> _streamSubscription;
  ProfileInfoModal profileInfoModal;
  bool isReadMore = false;
  ScrollController _scrollController = ScrollController();
  int positionOfChild = 0;
  int lastPositionOfChild = 0;
  bool isLoading = true;
  Offset position = Offset(20.0, 20.0);
  int notificationCount = 0;
  int previousIndexOfCommentBox = 0;
  int scrolIndex = 0;
  double previousScroll = 0.0;
  double currentPositonScroll = 400.0;
  RegExp exp =  RegExp(
      r"(http|ftp|https|Https|Http)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");
  BuildContext context;

  String profilePath = "", companyPath = "";

  //RegExp exp =  RegExp(r"(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[-A-Z0-9+&@#\/%=~_|$?!:,.])*(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[A-Z0-9+&@#\/%=~_|$])");

  LinkPreview previwer = LinkPreview();
  WhatsAppLinkPreview wspPreview = WhatsAppLinkPreview();

  Future apiCallingForIncreaseCount(feedId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_INCREASE_NUMBER_OF_COUNT +
                feedId +
                "&roleId=" +
                roleId,
            "get");

        print("apiCallingForIncreaseCount data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      e.toString();
    }
  }

  void forwardToParentConformAtionDialog(userPostModal, index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(20.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    "Are you sure you want to forward this feed to your parent?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallForForwardFeed(
                                                  userPostModal, index);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void feedForwardConformation() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Center(
                                              child:  Container(
                                                  child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text:
                                                      ' Your post has been forwarded to your parent. Please follow up with them ',
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                              )),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "OK",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void infoDialog() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                      13.0,
                                      20.0,
                                      13.0,
                                      0.0,
                                      Container(
                                        height: 145.0,
                                        padding: const EdgeInsets.all(8.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child: ListView(children: <Widget>[
                                          Image.asset(
                                            'assets/profile/parent/info.png',
                                            height: 25.0,
                                            width: 25.0,
                                          ),
                                           Container(
                                              padding:
                                                  const EdgeInsets.all(3.0),
                                              child: RichText(
                                                maxLines: 1,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text: 'Forward to Parent',
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                ),
                                              )),
                                           Container(
                                              child: RichText(
                                            maxLines: 5,
                                            textAlign: TextAlign.center,
                                            text: TextSpan(
                                              text:
                                                  'Great that you are interested on this opportunity. Because you are under 13, please follow up your parent/guardian to help with next steps. They will see the details in their feed.',
                                              style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                            ),
                                          ))
                                        ]),
                                      ),
                                    ),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Close",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void groupInvitationAccepted(userPostModal) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Center(
                                              child:  Container(
                                                  child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text: userPostModal
                                                          .opportunityModelForFeed
                                                          .groupIsPublic
                                                      ? ' Awesome! You have successfully joined this group '
                                                      : ' Awesome! You have successfully sent request for this group ',
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                              )),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Close",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallForForwardParent(groupId, userPostModal) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "parentId": int.parse(userIdPref),
          "userId":
              int.parse(userPostModal.opportunityModelForFeed.studentJoinId)
        };

        print("joinMap++++" + map.toString());

        response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_JOIN_GROUP_FORWARD, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted(userPostModal);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      e.toString();
    }
  }

  Future apiCallJoin(groupId, userPostModal) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "opportunityId":
              int.parse(userPostModal.opportunityModelForFeed.opportunityId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId)
        };
        print("map++++" + map.toString());
        response = await  ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_JOIN_GROUP, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted(userPostModal);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      e.toString();
    }
  }

  String getLinkUrl(str) {
    try {
      Iterable<Match> matches = exp.allMatches(str);
      print("uri+++++++matches++++++" + matches.length.toString());
      for (Match m in matches) {
        String match = m.group(0);

        return match;
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      return "";
    }
    return "";
  }

  void onTapLike(userPostModal) {
    apiCallingForAddLike(userPostModal.feedId, userPostModal);
  }

  //AllConnections
  void onTapShare(userPostModel) async {
    print("data+++++" + userPostModel.visibility);
    if (userPostModel.visibility ==
            "Private" /*||
        userPostModel.visibility == "SelectedConnections"*/
        ) {
      ToastWrap.showToast("Only public feeds can be shared.", context);
    } else {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               SharePostWidget(profileInfoModal, userPostModel, "", "0")));

      if (result == "push") {
        apiCallingForUserPost();
      }
    }
  }

  Future apiCallForRemoveComment(List<CommentData> commentList, feedId,
      UserPostModal userPostModal, commentId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": int.parse(feedId),
          "commentId": commentList[commentList.length - 1].commentId,
          "roleId": int.parse(roleId),
          "dateTime":  DateTime.now().millisecondsSinceEpoch
        };
        print("maop++++" + map.toString());

        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_REMOVE_COMMENT, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              commentList.removeLast();
              if (commentList.length == 0) {
                userPostModal.isCommented = false;
              }
              setState(() {
                commentList;
                userPostModal;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      print("error+++" + e.toString());
      e.toString();
    }
  }

//--------------------------Profile Info api ------------------
  Future profileApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO + userIdPref + "/false", "get");

        print("userprofile data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                prefs.setString(
                    UserPreference.ISACTIVE, profileInfoModal.isActive);
                setState(() {
                  prefs.setString(
                      UserPreference.ISHide, profileInfoModal.isHide);
                  profileInfoModal;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      print("error+++" + e.toString());
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }

  Future apiCallingForAddComment(feedId, comment, userpostModal) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": feedId,
          "userId": int.parse(userIdPref),
          "comment": comment,
          "dateTime":  DateTime.now().millisecondsSinceEpoch,
          "name": "",
          "title": "",
          "profilePicture": "",
          "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
          "lastActivityType": "CommentOnFeed",
          "roleId": int.parse(roleId),
        };

        print("map+++" + map.toString());
        Response response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_FEED_COMMENT, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              userpostModal.isCommented = true;
              List<Likes> likesList =  List();
              // userpostModal.commentList.add
              userpostModal.commentList.insert(
                  0,
                   CommentData(
                      response.data["result"]["commentId"].toString(),
                      comment,
                      userIdPref,
                      "few seconds ago",
                      roleId == "4"
                          ? prefs.getString(UserPreference.COMPANY_IMAGE_PATH)
                          : profile_image_path,
                      roleId == "4"
                          ? prefs.getString(UserPreference.COMPANY_NAME_PATH)
                          : profileInfoModal.lastName == "" ||
                                  profileInfoModal.lastName == "null"
                              ? profileInfoModal.firstName
                              : profileInfoModal.firstName +
                                  " " +
                                  profileInfoModal.lastName,
                      "",
                      userIdPref,
                      likesList,
                      false,
                      roleId,
                      profileInfoModal.badge,
                      profileInfoModal.gamificationPoints,
                      profileInfoModal.badgeImage,true));
              setState(() {
                userPostList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      e.toString();
    }
  }

  Future apiCallingForAddLike(feedId, userpostModal) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        bool isLike = false;
        if (userpostModal.isLike) {
          isLike = false;
        } else {
          isLike = true;
        }
        Map map = {
          "feedId": feedId,
          "userId": int.parse(userIdPref),
          "isLike": isLike,
          "roleId": int.parse(roleId),
          "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
          "lastActivityType": "LikeFeed"
        };

        print("map+++" + map.toString());

        Response response = await  ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_ADD_LIKE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              if (userpostModal.isLike) {
                userpostModal.isLike = false;
                userpostModal.likeList.removeLast();
              } else {
                userpostModal.isLike = true;
                userpostModal.likeList.add(new Likes(
                    userIdPref,
                    roleId == "4"
                        ? prefs.getString(UserPreference.COMPANY_NAME_PATH)
                        : profileInfoModal.lastName == "" ||
                                profileInfoModal.lastName == "null"
                            ? profileInfoModal.firstName
                            : profileInfoModal.firstName +
                                " " +
                                profileInfoModal.lastName,
                    roleId == "4"
                        ? prefs.getString(UserPreference.COMPANY_IMAGE_PATH)
                        : profile_image_path,
                    "student",
                    "",
                    "",
                    prefs.getBool(UserPreference.IS_PARENT) ? "2" : "1",
                    profileInfoModal.badge,
                    profileInfoModal.gamificationPoints,
                    profileInfoModal.badgeImage));
              }
              setState(() {
                userpostModal;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      e.toString();
    }
  }

  Future apiCallingForUserPost() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        print("userId" + userIdPref);
        Response response = await  ApiCalling2().apiCall(
            context,
            "ui/feed/postList?userId=$userIdPref&skip=0" + "&roleId=" + roleId,
            "get");
        isLoading = false;
        setState(() {
          isLoading;
        });
        print("userpost data   " +
            "ui/feed/postList?userId=$userIdPref&skip=0" +
            "&roleId=" +
            roleId);
        print("userpost data   " + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              userPostList.clear();
              userPostList.addAll(ParseJson.parseHomeData(
                  response.data['result'], userIdPref, roleId));
              if (userPostList.length > 0) {
                setState(() {
                  userPostList;
                });
                if (userPostList.length < 10) {
                  setState(() {
                    isLoadMore = false;
                  });
                }
              }

              print("userpostlenght " + userPostList.length.toString());
            }
          }
        }
      } else {
        isLoading = false;
        setState(() {
          isLoading;
        });
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallingForUserPostLoadMore() async {
    try {
      isLoadingData = true;
      print("offsetvalue" + offset.toString());
      Response response = await  ApiCalling().apiCall(
          context,
          "ui/feed/postList?userId=$userIdPref&skip=" +
              offset.toString() +
              "&roleId=" +
              roleId,
          "get");
      print("userpost data   " +
          "ui/feed/postList?userId=$userIdPref&skip=" +
          offset.toString() +
          "&roleId=" +
          roleId);
      isLoadingData = false;
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            List<UserPostModal> userPostListNew = ParseJson.parseHomeData(
                response.data['result'], userIdPref, roleId);
            if (userPostListNew.length > 0) {
              userPostList.addAll(userPostListNew);
              setState(() {
                userPostList;
              });
            } else {
              isLoadMore = false;
            }
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      isLoadingData = false;
      e.toString();
    }
  }

  Future apiCallForForwardFeed(userPostModal, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "opportunityId":
              int.parse(userPostModal.opportunityModelForFeed.opportunityId),
          "userId": int.parse(userIdPref)
        };
        print("map+++" + map.toString());
        Response response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_FEED_FORWARD, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              if (msg.contains("Opportunity already forwarded to parent")) {
                ToastWrap.showToast(msg, context);
              } else {
                feedForwardConformation();
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      e.toString();
    }
  }

  Future apiCallingForDeleteFeed(userPostModal, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": userPostModal.feedId /*,"roleId":int.parse(roleId)*/
        };
        print("map+++++++" + map.toString());
        Response response = await  ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_FEED_DELETE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              userPostList.removeAt(index);
              setState(() {
                userPostList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
    }
  }

  Future apiCallingForUpdateFeed(userPostModal, visibility, scopeList) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": userPostModal.feedId,
          "visibility": visibility,
          "roleId": int.parse(roleId),
          "scope": scopeList.map((item) => item.toJson()).toList()
        };

        print(map.toString() + map.toString());

        Response response = await  ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_FEED_UPDATE, map);

        print("response feed::::::::::::-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              userPostModal.visibility = visibility;
              setState(() {
                userPostModal;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    companyPath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    userIdPref = prefs.getString(UserPreference.USER_ID);
    userName = prefs.getString(UserPreference.NAME);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    profile_image_path = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);
    dob = prefs.getString(UserPreference.DOB);
    print("dob++++" + dob.toString());
    if (dob != null && dob != "" && dob != "null") {
      int d = int.tryParse(dob);
      DateTime date =  DateTime.fromMillisecondsSinceEpoch(d);
      diffrenceInDob =  DateTime.now().year - date.year;
      print("dob++++" + diffrenceInDob.toString());
    }

    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      if(mounted){
      CustomProgressLoader.showLoader(context);
      print("DateTime+++" + DateTime.now().millisecondsSinceEpoch.toString());

      await apiCallingForUserPost();
      await profileApi();
      print("DateTime+++" + DateTime.now().millisecondsSinceEpoch.toString());

      CustomProgressLoader.cancelLoader(context);}
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
    if (mounted) {
      print("height" + (MediaQuery.of(context).size.height).toString());
      setState(() {
        position = Offset(((MediaQuery.of(context).size.width) - 60.0),
            ((MediaQuery.of(context).size.height) - 260.0));
      });
    }
  //  wspPreview.build(url, userPostModal)
  }

  onAddComment(feedId, comment, userPostModal) {
    apiCallingForAddComment(feedId, comment, userPostModal);
    print("Comments : " + comment + "feedid:- $feedId");
  }

  @override
  void initState() {
    // TODO: implement initState

    getSharedPreferences();
    //-------------listener for add button click (Dashboard) -------------------------
    _streamSubscription =
        DashBoardState.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        if (mounted) {
          try {
            notificationCount = int.parse(value);
            if (mounted)
              setState(() {
                notificationCount;
              });
          } catch (e) {
            crashlytics_bloc.recordCrashlyticsError(e,"home",context);
          }
        }
      }
    });

    _streamSubscription = DashBoardStateParent.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted)
          setState(() {
            notificationCount;
          });
      }
    });
   DashBoardStatePartner.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted)
          setState(() {
            notificationCount;
          });
      }
    });

    /*  _scrollController = ScrollController()
      ..addListener(() => setState(() {
            setState(() {
              currentPositonScroll = _scrollController.offset;
            });
          }));*/

    super.initState();
  }

  void onTapAddPost(String result) async {
    if (prefs.getBool("isParent") != null && prefs.getBool("isParent")) {
      RewardStatusResponse result = await Navigator.of(context).push(
           MaterialPageRoute(
              builder: (BuildContext context) =>
                   AddPost(profileInfoModal, "",groupDetailModel: null)));

      if (result != null) {
        Util.showRewardPoint(result.rewardStatus, context);
        apiCallingForUserPost();
      }
    } else {
      if (prefs.getString(UserPreference.ISACTIVE) == "true") {
        RewardStatusResponse result = await Navigator.of(context).push(
             MaterialPageRoute(
                builder: (BuildContext context) =>
                     AddPost(profileInfoModal, "",groupDetailModel: null)));

        if (result != null) {
          Util.showRewardPoint(result.rewardStatus, context);
          apiCallingForUserPost();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
            context);
      }
    }
  }

  void onTapViewAllComments(commentList, feedId, userPostModel) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  CommentListWidget(
            commentList,
            profile_image_path,
            feedId,
            profileInfoModal.lastName == "" ||
                    profileInfoModal.lastName == "null"
                ? profileInfoModal.firstName
                : profileInfoModal.firstName + " " + profileInfoModal.lastName,
            userPostModel,
            userIdPref,
            roleId,
            profileInfoModal.badge,
            profileInfoModal.gamificationPoints,
            profileInfoModal.badgeImage)));

    if (result == "push") {
      // apiCallingForUserPost();
    }
  }

  Future<String> initMetaDataState() async {
    dynamic linkPreview;
    try {
      linkPreview = await previwer.getUrlMetaData(url: 'https://flutter.io');
    } on PlatformException catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"home",context);
      debugPrint(e.message);
      linkPreview = 'Failed to get platform version.';
    }
    return linkPreview.toString();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    this.context = context;
    void optionForDelete(List<CommentData> commentList, feedId,
        UserPostModal userPostModal, commentId) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child:  Container(
                                  height: 110.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child:  Text(
                                                            "Delete",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style:  TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () {
                                                        Navigator.pop(context);

                                                        apiCallForRemoveComment(
                                                            commentList,
                                                            feedId,
                                                            userPostModal,
                                                            commentId);
                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    /*   void optionMenuForShareFeed(userPostModal) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 24.0,
                              child:  Container(
                                  height: 148.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child:  Text(
                                                            "Share As Post",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style:  TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        onTapShare(
                                                            userPostModal);
                                                      },
                                                    ),
                                                     Column(
                                                      children: <Widget>[
                                                         Container(
                                                          color:  ColorValues.BORDER_COLOR,
                                                          height: 1.0,
                                                        ),
                                                         InkWell(
                                                          child:  Container(
                                                              height: 50.0,
                                                              padding:
                                                                   EdgeInsets
                                                                          .fromLTRB(
                                                                      0.0,
                                                                      13.0,
                                                                      0.0,
                                                                      13.0),
                                                              child:  Text(
                                                                "Share On Group Feed",
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                maxLines: 5,
                                                                style:  TextStyle(
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    height: 1.2,
                                                                    fontSize:
                                                                        16.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              )),
                                                          onTap: () {
                                                            Navigator.pop(
                                                                context);
                                                            Navigator.of(context).push(new MaterialPageRoute(
                                                                builder: (BuildContext
                                                                        context) =>
                                                                     GroupSelectionForFeed(
                                                                        userIdPref,
                                                                        userPostModal
                                                                            .feedId)));
                                                          },
                                                        ),
                                                      ],
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }*/

    InkWell shareView(userPostModel) {
      return  InkWell(
        child: PaddingWrap.paddingfromLTRB(
            0.0,
            10.0,
            10.0,
            10.0,
             Image.asset(
              "assets/newDesignIcon/feed/share.png",
              height: 25.0,
              width: 25.0,
            )),
        onTap: () {
          // onTapShare(userPostModel);
          if (userPostModel.visibility == "Private" ||
              userPostModel.visibility == "SelectedConnections") {
            ToastWrap.showToast("Only public feeds can be shared.", context);
          } else {
            onTapShare(userPostModel);
            //  optionMenuForShareFeed(userPostModel);
          }
        },
      );
    }

    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {
      } else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }

    void onTapTagSelectedConnection(userPostModel) async {
      List<TagModel> result = await Navigator.of(context).push(
           MaterialPageRoute(
              builder: (BuildContext context) =>
                   AddTagWidget("MY CONNECTIONS", null)));

      if (result != null) {
        List<TagsPost> scopeList =  List();
        for (int i = 0; i < result.length; i++) {
          scopeList.add(new TagsPost(result[i].userId, result[i].roleId));
        }

        if (scopeList.length > 0)
          apiCallingForUpdateFeed(
              userPostModel, "SelectedConnections", scopeList);
      }
    }

    onTapLikeText(userPostModal) {
      print(userPostModal.likeList);
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               LikeDetailWidget(userPostModal.likeList, userIdPref)));
    }

    void conformationDialogForDeletFeed(userPostModal, index) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(20.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to delete this post?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "No",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Yes",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCallingForDeleteFeed(
                                                    userPostModal, index);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    onTapReport(userPostModal, index) async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               Report("feed", "", userPostModal.feedId, "")));
      if (result == "push") {
        userPostModal.isReported = "true";

        setState(() {
          userPostList;
        });
      } else if (result == "hide") {
        userPostList.removeAt(index);
        setState(() {
          userPostList;
        });
      }
    }

    void optionForReport(userPostModal, index) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child:  Container(
                                  height: 110.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child:  Text(
                                                            "Find Support or Report Post",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style:  TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () {
                                                        Navigator.pop(context);

                                                        if (userPostModal
                                                                .isReported ==
                                                            "true") {
                                                          ToastWrap.showToast1Sec(
                                                              "You have already reported this post.",
                                                              context);
                                                        } else {
                                                          onTapReport(
                                                              userPostModal,
                                                              index);
                                                        }
                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void optionMenuForShareOpportunity(userPostModal, index) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 24.0,
                              child:  Container(
                                  height: 148.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child:  Text(
                                                            "Share As Post",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style:  TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        onTapShare(
                                                            userPostModal);
                                                      },
                                                    ),
                                                     Column(
                                                      children: <Widget>[
                                                         Container(
                                                          color:  ColorValues.BORDER_COLOR,
                                                          height: 1.0,
                                                        ),
                                                         InkWell(
                                                          child:  Container(
                                                              height: 50.0,
                                                              padding:
                                                                   EdgeInsets
                                                                          .fromLTRB(
                                                                      0.0,
                                                                      13.0,
                                                                      0.0,
                                                                      13.0),
                                                              child:  Text(
                                                                "Share With Connections",
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                maxLines: 1,
                                                                style:  TextStyle(
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    height: 1.2,
                                                                    fontSize:
                                                                        16.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              )),
                                                          onTap: () {
                                                            Navigator.pop(
                                                                context);
                                                            Navigator.of(context).push(new MaterialPageRoute(
                                                                builder: (BuildContext context) =>  ConnectionsSelectionWidget(
                                                                    userIdPref,
                                                                    roleId,
                                                                    userPostModal
                                                                        .opportunityModelForFeed
                                                                        .opportunityId,
                                                                    userPostModal
                                                                        .feedId)));
                                                          },
                                                        ),
                                                      ],
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void optionMenu(userPostModal, index) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 24.0,
                              child:  Container(
                                  height: 150.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                          child: Center(
                                                            child:  Text(
                                                              "Edit",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 5,
                                                              style:  TextStyle(
                                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant.TYPE_CUSTOMREGULAR),
                                                            ),
                                                          )),
                                                      onTap: () async {
                                                        Navigator.pop(context);
                                                        String result = await Navigator
                                                                .of(context)
                                                            .push(new MaterialPageRoute(
                                                                builder: (BuildContext
                                                                        context) =>
                                                                     EditPostWidget(
                                                                        profileInfoModal,
                                                                        "",
                                                                        null,
                                                                        userPostModal)));
                                                        if (result == "push") {
                                                          apiCallingForUserPost();
                                                        }
                                                      },
                                                    ),
                                                     Column(
                                                      children: <Widget>[
                                                         Container(
                                                          color:  ColorValues.BORDER_COLOR,
                                                          height: 1.0,
                                                        ),
                                                         InkWell(
                                                          child:  Container(
                                                              height: 50.0,
                                                              padding:
                                                                   EdgeInsets
                                                                          .fromLTRB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                              child: Center(
                                                                child:  Text(
                                                                  "Delete",
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 1,
                                                                  style:  TextStyle(
                                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                      height:
                                                                          1.2,
                                                                      fontSize:
                                                                          16.0,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR),
                                                                ),
                                                              )),
                                                          onTap: () {
                                                            Navigator.pop(
                                                                context);
                                                            conformationDialogForDeletFeed(
                                                                userPostModal,
                                                                index);
                                                          },
                                                        ),
                                                      ],
                                                    )
                                                    /*  userPostModal.visibility ==
                                                            "Private"
                                                        ?  Container(
                                                            height: 0.0,
                                                          )
                                                        :  Column(
                                                            children: <Widget>[
                                                               Container(
                                                                color:
                                                                     Color(
                                                                  ColorValues
                                                                      .BORDER_COLOR,
                                                                ),
                                                                height: 1.0,
                                                              ),
                                                               InkWell(
                                                                child:
                                                                     Container(
                                                                        height:
                                                                            50.0,
                                                                        padding:  EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            13.0,
                                                                            0.0,
                                                                            13.0),
                                                                        child:
                                                                             Text(
                                                                          "Make it Private",
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                          maxLines:
                                                                              5,
                                                                          style:  TextStyle(
                                                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                              height: 1.2,
                                                                              fontSize: 16.0,
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                        )),
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                  List<String>
                                                                      scopeList =
                                                                       List();
                                                                  apiCallingForUpdateFeed(
                                                                      userPostModal,
                                                                      "Private",
                                                                      scopeList);
                                                                },
                                                              ),
                                                            ],
                                                          ),
                                                    userPostModal.visibility ==
                                                            "SelectedConnections"
                                                        ?  Container(
                                                            height: 0.0,
                                                          )
                                                        :  Column(
                                                            children: <Widget>[
                                                               Container(
                                                                color:
                                                                     Color(
                                                                  ColorValues
                                                                      .BORDER_COLOR,
                                                                ),
                                                                height: 1.0,
                                                              ),
                                                               InkWell(
                                                                child:
                                                                     Container(
                                                                        height:
                                                                            50.0,
                                                                        padding:  EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            13.0,
                                                                            0.0,
                                                                            13.0),
                                                                        child:
                                                                             Text(
                                                                          "Selected Connections",
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                          maxLines:
                                                                              1,
                                                                          style:  TextStyle(
                                                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                              height: 1.2,
                                                                              fontSize: 16.0,
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                        )),
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                  onTapTagSelectedConnection(
                                                                      userPostModal);
                                                                },
                                                              ),
                                                            ],
                                                          ),
                                                    userPostModal.visibility ==
                                                            "AllConnections"
                                                        ?  Container(
                                                            height: 0.0,
                                                          )
                                                        :  Column(
                                                            children: <Widget>[
                                                               Container(
                                                                color:
                                                                     Color(
                                                                  ColorValues
                                                                      .BORDER_COLOR,
                                                                ),
                                                                height: 1.0,
                                                              ),
                                                               InkWell(
                                                                child:
                                                                     Container(
                                                                        height:
                                                                            50.0,
                                                                        padding:  EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            13.0,
                                                                            0.0,
                                                                            13.0),
                                                                        child:
                                                                             Text(
                                                                          "Connections",
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                          maxLines:
                                                                              1,
                                                                          style:  TextStyle(
                                                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                              height: 1.2,
                                                                              fontSize: 16.0,
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                        )),
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                  List<String>
                                                                      scopeList =
                                                                       List();
                                                                  apiCallingForUpdateFeed(
                                                                      userPostModal,
                                                                      "AllConnections",
                                                                      scopeList);
                                                                },
                                                              ),
                                                            ],
                                                          ),*/
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void optionMenuDelete(userPostModal, index) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 24.0,
                              child:  Container(
                                  height: 100.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    /*   InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                          child: Center(
                                                            child:  Text(
                                                              "Edit",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 5,
                                                              style:  TextStyle(
                                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant.TYPE_CUSTOMREGULAR),
                                                            ),
                                                          )),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        Navigator.of(context).push(
                                                             MaterialPageRoute(
                                                                builder: (BuildContext
                                                                        context) =>
                                                                     EditPostWidget(
                                                                        profileInfoModal,
                                                                        "",
                                                                        null,
                                                                        userPostModal)));
                                                      },
                                                    ),*/
                                                     Column(
                                                      children: <Widget>[
                                                        /*    Container(
                                                          color:  ColorValues.BORDER_COLOR,
                                                          height: 1.0,
                                                        ),*/
                                                         InkWell(
                                                          child:  Container(
                                                              height: 50.0,
                                                              padding:
                                                                   EdgeInsets
                                                                          .fromLTRB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                              child: Center(
                                                                child:  Text(
                                                                  "Delete",
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  maxLines: 1,
                                                                  style:  TextStyle(
                                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                      height:
                                                                          1.2,
                                                                      fontSize:
                                                                          16.0,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR),
                                                                ),
                                                              )),
                                                          onTap: () {
                                                            Navigator.pop(
                                                                context);
                                                            conformationDialogForDeletFeed(
                                                                userPostModal,
                                                                index);
                                                          },
                                                        ),
                                                      ],
                                                    )
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    Widget _loader(BuildContext context) => Center(
            child: Container(
          child:  Image.asset(
            "assets/aerial/feed_default_img.png",
            fit: BoxFit.cover,
          ),
        ));

    Widget _error() {
      return Center(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.fill,
        ),
      );
    }

    Padding getListViewPostForOpportuntiy(UserPostModal userPostModal, index) {
      print('Mona 111 getListViewPostForOpportuntiy() 111');
      return PaddingWrap.paddingAll(
          0.0,
           Card(
              elevation: 0.0,
              color:  ColorValues.GRAY_BG,
              child:  Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    // getEvent(userPostModal),
                    PaddingWrap.paddingfromLTRB(
                        11.0,
                        10.0,
                        11.0,
                        10.0,
                         Row(
                          children: <Widget>[
                             Expanded(
                              child:  InkWell(
                                child:  Center(
                                    child:  Container(
                                        width: 50.0,
                                        height: 50.0,
                                        child: ClipOval(
                                            child: FadeInImage.assetNetwork(
                                          fit: BoxFit.cover,
                                          width: double.infinity,
                                          placeholder: userPostModal
                                                      .postOwnerRoleId ==
                                                  "4"
                                              ? "assets/profile/partner_img.png"
                                              : 'assets/profile/user_on_user.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getSmallImage(
                                                  userPostModal.profilePicture),
                                        )))),
                                onTap: () {
                                  print("postedBy " +
                                      userPostModal.postOwner +
                                      "  " +
                                      userPostModal.postOwnerRoleId);
                                  onTapImageTile(userPostModal.postOwner,
                                      userPostModal.postOwnerRoleId);
                                },
                              ),
                              flex: 0,
                            ),
                             Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  8.0,
                                  0.0,
                                  15.0,
                                  0.0,
                                   Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                       InkWell(
                                        child:  Container(
                                            child: RichText(
                                          maxLines: 2,
                                          textAlign: TextAlign.start,
                                          text: TextSpan(
                                            text: userPostModal.lastName ==
                                                        null ||
                                                    userPostModal.lastName ==
                                                        "null"
                                                ? userPostModal.firstName
                                                : userPostModal.firstName +
                                                    " " +
                                                    userPostModal.lastName,
                                            style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            children: [
                                              WidgetSpan(
                                                child: userPostModal.roleId ==
                                                        "1"
                                                    ? Util
                                                        .getStudentBadgeRichTextWithPadding(
                                                            userPostModal.badge,
                                                            userPostModal
                                                                .badgeImage)
                                                    : Container(
                                                        height: 0.0,
                                                        width: 0.0,
                                                      ),
                                              ),
                                              TextSpan(
                                                  text: ' shared ',
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 14.0,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR)),
                                              TextSpan(
                                                text: userPostModal
                                                            .postOwnerLastName ==
                                                        ""
                                                    ? userPostModal
                                                            .postOwnerFirstName
                                                            .trim() +
                                                        "'s"
                                                    : userPostModal
                                                            .postOwnerFirstName +
                                                        " " +
                                                        userPostModal
                                                            .postOwnerLastName
                                                            .toString()
                                                            .trim() +
                                                        "'s",
                                                style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              TextSpan(
                                                text: " post",
                                                style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.normal,
                                                ),
                                              ),
                                            ],
                                          ),
                                        )),
                                        onTap: () {
                                          onTapImageTile(userPostModal.postedBy,
                                              userPostModal.roleId);

                                          /* Navigator.of(context).push(new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                           TagDetailWidget(
                                              userPostModal.tagList)));*/
                                        },
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0.0, 5, 0, 0),
                                        child:  Row(
                                          children: [
                                            TextViewWrap.textView(
                                                userPostModal.dateTime,
                                                TextAlign.center,
                                                ColorValues.GREY_TEXT_COLOR,
                                                12.0,
                                                FontWeight.normal),
                                            userIdPref == userPostModal.postedBy &&
                                                roleId == userPostModal.roleId.toString()
                                                ?    PaddingWrap.paddingfromLTRB(
                                                10.0,
                                                0.0,
                                                5.0,
                                                0.0,
                                                 Image.asset(
                                                  userPostModal.visibility ==
                                                          "Private"
                                                      ? "assets/profile/post/private_new.png"
                                                      : userPostModal
                                                                  .visibility ==
                                                              "SelectedConnections"
                                                          ? "assets/profile/post/selected_connection.png"
                                                          : userPostModal
                                                                      .visibility ==
                                                                  "AllConnections"
                                                              ? "assets/profile/post/connection.png"
                                                              : userPostModal
                                                                          .visibility ==
                                                                      "Group"
                                                                  ? "assets/profile/post/group_data.png"
                                                                  : "assets/profile/post/community.png",
                                                  width: 13.0,
                                                  color: userPostModal
                                                              .visibility ==
                                                          "SelectedConnections"
                                                      ? null
                                                      : ColorValues.GREY_TEXT_COLOR,
                                                  height: 13.0,
                                                )):new Container(height:0.0),
                                        /*    PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                TextViewWrap.textView(
                                                    userPostModal.visibility ==
                                                            "Private"
                                                        ? "Private"
                                                        : userPostModal
                                                                    .visibility ==
                                                                "SelectedConnections"
                                                            ? "Selected Connections"
                                                            : userPostModal
                                                                        .visibility ==
                                                                    "AllConnections"
                                                                ? "Connections"
                                                                : userPostModal
                                                                            .visibility ==
                                                                        "Group"
                                                                    ? "Group"
                                                                    : "Community",
                                                    TextAlign.center,
                                                    ColorValues.GREY_TEXT_COLOR,
                                                    12.0,
                                                    FontWeight.normal))*/
                                          ],
                                        ),
                                      )

                                      /*        TextViewWrap.textView(
                                          userPostModal.dateTime,
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          12.0,
                                          FontWeight.normal),*/
                                    ],
                                  )),
                              flex: 4,
                            ),
                             Expanded(
                              child: userIdPref == userPostModal.postedBy &&
                                      roleId == userPostModal.roleId.toString()
                                  ?  Container(
                                      padding:  EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 30.0),
                                      child:  InkWell(
                                        child:  Image.asset(
                                          "assets/profile/post/user_more1.png",
                                          width: 25.0,
                                          height: 25.0,
                                        ),
                                        onTap: () {
                                          optionMenuDelete(
                                              userPostModal, index);
                                        },
                                      ))
                                  :  Container(
                                      padding:  EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 30.0),
                                      child:  InkWell(
                                        child:  Image.asset(
                                          "assets/profile/post/user_more1.png",
                                          width: 25.0,
                                          height: 25.0,
                                        ),
                                        onTap: () {
                                          optionForReport(userPostModal, index);
                                        },
                                      )),
                              flex: 0,
                            )
                          ],
                        )),
                    userPostModal.shareText == "null" ||
                            userPostModal.shareText == ""
                        ?  Container(
                            height: 0.0,
                          )
                        :  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                10.0,
                                0.0,
                                userPostModal.shareText == "" ||
                                        userPostModal.shareText == "null" ||
                                        userPostModal.shareText == "\n"
                                    ?  Container(
                                        height: 0.0,
                                      )
                                    : PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        userPostModal.isShareMore
                                            ? /*new Text(userPostModal.shareText,
                                                textAlign: TextAlign.left,
                                                maxLines: null,
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0))*/

                                             Container(
                                                child: Linkify(
                                                  onOpen: (link) async {
                                                    print("onclick +++");
                                                    apiCallingForIncreaseCount(
                                                        userPostModal.feedId);
                                                    Navigator.push(
                                                        context,
                                                         MaterialPageRoute(
                                                            //   builder: (context) =>  DashBoardWidget()));
                                                            builder: (context) =>
                                                                 WebViewWidget(
                                                                    link.url,
                                                                    "spikeview")));
                                                  },
                                                  text: userPostModal.shareText,
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                  linkStyle:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                ),
                                              )
                                            :  Container(
                                                child: Linkify(
                                                  onOpen: (link) async {
                                                    print("onclick +++");
                                                    apiCallingForIncreaseCount(
                                                        userPostModal.feedId);
                                                    Navigator.push(
                                                        context,
                                                         MaterialPageRoute(
                                                            //   builder: (context) =>  DashBoardWidget()));
                                                            builder: (context) =>
                                                                 WebViewWidget(
                                                                    link.url,
                                                                    "spikeview")));
                                                  },
                                                  text:
                                                      /*userPostModal.shareText
                                                              .length >=
                                                          105
                                                      ? userPostModal.shareText
                                                          .toString()
                                                          .substring(0, 105)
                                                      :*/
                                                      userPostModal.shareText,
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                  linkStyle:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                ),
                                              ) /*TextViewWrap.textViewMultiLine(
                                                userPostModal.shareText,
                                                TextAlign.left,
                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                14.0,
                                                FontWeight.normal,
                                                2)*/
                                        ),
                              ),
                              /* userPostModal.shareText.length > 90
                                  ?  Align(
                                      alignment: Alignment.bottomLeft,
                                      child:  InkWell(
                                        child: PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            0.0,
                                            5.0,
                                            10.0,
                                            TextViewWrap.textView(
                                                userPostModal.isShareMore
                                                    ? "Less"
                                                    : "More",
                                                TextAlign.left,
                                                 ColorValues.BLUE_COLOR,
                                                14.0,
                                                FontWeight.normal)),
                                        onTap: () {
                                          if (userPostModal.isShareMore) {
                                            userPostModal.isShareMore = false;
                                          } else {
                                            userPostModal.isShareMore = true;
                                          }
                                          setState(() {
                                            userPostModal.isShareMore;
                                          });
                                        },
                                      ))
                                  :  Container(
                                      height: 10.0,
                                    ),*/
                            ],
                          ),
                    userPostModal.postOwnerDeleted
                        ? PaddingWrap.paddingfromLTRB(
                            11.0,
                            5.0,
                            11.0,
                            5.0,
                             Container(
                              width: double.infinity,
                              decoration:  BoxDecoration(
                                  color:  ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                  border:  Border.all(
                                      width: 0.5,
                                      color:  ColorValues.GREY__COLOR_DIVIDER)),
                              child: PaddingWrap.paddingfromLTRB(
                                  11.0,
                                  17.0,
                                  11.0,
                                  16.0,
                                   Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextViewWrap.textView(
                                          "You can’t see this post",
                                          TextAlign.start,
                                           ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.bold),
                                      TextViewWrap.textView(
                                          MessageConstant.AUTHOR_DELETED_POST,
                                          TextAlign.start,
                                           ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.normal)
                                    ],
                                  )),
                            ))
                        : PaddingWrap.paddingfromLTRB(
                            11.0,
                            5.0,
                            11.0,
                            5.0,
                             Container(
                                decoration:  BoxDecoration(
                                    border:  Border.all(
                                        width: 0.1, color: Colors.black)),
                                child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        17.0,
                                        10.0,
                                        10.0,
                                        10.0,
                                         Row(
                                          children: <Widget>[
                                             Expanded(
                                              child:  InkWell(
                                                child:  Container(
                                                    child:  Center(
                                                        child:  Container(
                                                            width: 50.0,
                                                            height: 50.0,
                                                            child:  ClipOval(
                                                                child: FadeInImage
                                                                    .assetNetwork(
                                                              fit: BoxFit.cover,
                                                              width: double
                                                                  .infinity,
                                                              placeholder: userPostModal
                                                                          .postOwnerRoleId ==
                                                                      "4"
                                                                  ? "assets/profile/partner_img.png"
                                                                  : 'assets/profile/user_on_user.png',
                                                              image: Constant
                                                                      .IMAGE_PATH_SMALL +
                                                                  ParseJson.getSmallImage(
                                                                      userPostModal
                                                                          .postOwnerProfilePicture),
                                                            ))))),
                                                onTap: () {
                                                  onTapImageTile(
                                                      userPostModal.postOwner,
                                                      userPostModal
                                                          .postOwnerRoleId);
                                                },
                                              ),
                                              flex: 0,
                                            ),
                                             Expanded(
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      8.0,
                                                      0.0,
                                                      15.0,
                                                      0.0,
                                                       Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           InkWell(
                                                            child:  Container(
                                                                child: RichText(
                                                              maxLines: 2,
                                                              textAlign:
                                                                  TextAlign
                                                                      .start,
                                                              text: TextSpan(
                                                                text: userPostModal
                                                                            .postOwnerLastName ==
                                                                        "null"
                                                                    ? userPostModal
                                                                        .postOwnerFirstName
                                                                    : userPostModal
                                                                            .postOwnerFirstName +
                                                                        " " +
                                                                        userPostModal
                                                                            .postOwnerLastName,
                                                                style:
                                                                     TextStyle(
                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontSize:
                                                                      15.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ),
                                                                children: userPostModal
                                                                            .tagList
                                                                            .length ==
                                                                        0
                                                                    ? [
                                                                        WidgetSpan(
                                                                          child: userPostModal.postOwnerRoleId == "1"
                                                                              ? Util.getStudentBadgeRichTextWithPadding(userPostModal.postOwnerBadge, userPostModal.postOwnerBadgeImage)
                                                                              : Container(
                                                                                  height: 0.0,
                                                                                  width: 0.0,
                                                                                ),
                                                                        )
                                                                      ]
                                                                    : [
                                                                        WidgetSpan(
                                                                          child: userPostModal.postOwnerRoleId == "1"
                                                                              ? Util.getStudentBadgeRichTextWithPadding(userPostModal.postOwnerBadge, userPostModal.postOwnerBadgeImage)
                                                                              : Container(
                                                                                  height: 0.0,
                                                                                  width: 0.0,
                                                                                ),
                                                                        ),
                                                                        TextSpan(
                                                                            text:
                                                                                ' with ',
                                                                            style:  TextStyle(
                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                fontSize: 14.0,
                                                                                fontWeight: FontWeight.normal,
                                                                                fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                        TextSpan(
                                                                          text: userPostModal.tagList[0].name == null || userPostModal.tagList[0].name == "null"
                                                                              ? ""
                                                                              : userPostModal.tagList[0].name,
                                                                          style:
                                                                               TextStyle(
                                                                            color:
                                                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                          ),
                                                                        ),
                                                                        userPostModal.tagList.length >
                                                                                1
                                                                            ? TextSpan(
                                                                                text: ' and ',
                                                                                style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                              )
                                                                            : TextSpan(
                                                                                text: "",
                                                                                style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                              ),
                                                                        userPostModal.tagList.length >
                                                                                1
                                                                            ? TextSpan(
                                                                                text: (userPostModal.tagList.length - 1).toString(),
                                                                                style:  TextStyle(
                                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                  fontSize: 14.0,
                                                                                  fontWeight: FontWeight.bold,
                                                                                ),
                                                                              )
                                                                            : TextSpan(
                                                                                text: "",
                                                                                style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                              ),
                                                                        userPostModal.tagList.length >
                                                                                1
                                                                            ? TextSpan(
                                                                                text: " others ",
                                                                                style:  TextStyle(
                                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                  fontSize: 14.0,
                                                                                  fontWeight: FontWeight.bold,
                                                                                ),
                                                                              )
                                                                            : TextSpan(
                                                                                text: "",
                                                                                style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                              ),
                                                                      ],
                                                              ),
                                                            )),
                                                            onTap: () {
                                                              if (userPostModal
                                                                      .tagList
                                                                      .length >
                                                                  0) {
                                                                Navigator.of(
                                                                        context)
                                                                    .push(new MaterialPageRoute(
                                                                        builder:
                                                                            (BuildContext context) =>
                                                                                 TagDetailWidget(userPostModal.tagList)));
                                                              } else {
                                                                print(
                                                                    "clicked");
                                                                onTapImageTile(
                                                                    userPostModal
                                                                        .postOwner,
                                                                    userPostModal
                                                                        .postOwnerRoleId);
                                                              }
                                                            },
                                                          ),
                                                          TextViewWrap.textView(
                                                              userPostModal
                                                                  .shareTime,
                                                              TextAlign.center,
                                                               ColorValues.GREY_TEXT_COLOR,
                                                              12.0,
                                                              FontWeight
                                                                  .normal),
                                                        ],
                                                      )),
                                              flex: 4,
                                            )
                                          ],
                                        )),
                                     InkWell(
                                      child: Container(
                                        width: double.infinity,
                                        child: Card(
                                          elevation: 0.0,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(0.0)),
                                          color: ColorValues.WHITE,
                                          child: Column(
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  0.0,
                                                  0.0,
                                                  //
                                                  userPostModal
                                                              .opportunityModelForFeed
                                                              .assestVideoAndImage
                                                              .length >
                                                          0
                                                      ?  SizedBox(
                                                          // Pager view
                                                          height: 215.50,
                                                          child:
                                                              PageIndicatorContainer(
                                                            pageView:
                                                                 PageView
                                                                    .builder(
                                                              itemCount: userPostModal
                                                                  .opportunityModelForFeed
                                                                  .assestVideoAndImage
                                                                  .length,
                                                              controller:
                                                                   PageController(),
                                                              itemBuilder:
                                                                  (context,
                                                                      index2) {
                                                                return  Stack(
                                                                  children: <
                                                                      Widget>[
                                                                    userPostModal.opportunityModelForFeed.assestVideoAndImage[index2].type ==
                                                                            "image"
                                                                        ? Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: Colors.black,
                                                                            ),
                                                                            child:
                                                                                 CachedNetworkImage(
                                                                              width: double.infinity,
                                                                              height: 215.50,
                                                                              imageUrl: Constant.IMAGE_PATH + userPostModal.opportunityModelForFeed.assestVideoAndImage[index2].file,
                                                                              fit: BoxFit.contain,
                                                                              placeholder: (context, url) => _loader(context),
                                                                              errorWidget: (context, url, error) => _error(),
                                                                            ),
                                                                          )

                                                                        /*
                                                                    Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: Colors.black,
                                                                            ),
                                                                            child:
                                                                                 CachedNetworkImage(
                                                                              width: double.infinity,
                                                                              height: 215.50,
                                                                              imageUrl: Constant.IMAGE_PATH + userPostModal.opportunityModelForFeed.assestVideoAndImage[index2].file,
                                                                              fit: BoxFit.fill,
                                                                              placeholder: (context, url) => _loader(context),
                                                                              errorWidget: (context, url, error) => _error(),
                                                                            ),
                                                                          )*/
                                                                        :  InkWell(
                                                                            child:
                                                                                 Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: Colors.black,
                                                                              borderRadius: BorderRadius.circular(0),
                                                                            ),
                                                                            height:
                                                                                215.50,
                                                                            child:
                                                                                 Center(
                                                                              child:  VideoPlayPauseDialogOffline(userPostModal.opportunityModelForFeed.assestVideoAndImage[index2].file, "", true),
                                                                              /*new Container(
                                                                                  child:  Stack(
                                                                                    children: <Widget>[

                                                                                      Container(
                                                                                        height: 215.0,
                                                                                        color: Colors.black,
                                                                                        margin: EdgeInsets.only(left: 0, right: 0),
                                                                                        child:  VideoViewBlack(
                                                                                            Constant.IMAGE_PATH + userPostModal.opportunityModelForFeed.assestVideoAndImage[index2].file, "", false, ""),
                                                                                      ),
                                                                                      */ /*new Container(
                                                                                      height: 54.0,
                                                                                      width: 80.0,
                                                                                      color:  Color(0XFFC0C0C0).withOpacity(.4),
                                                                                    ),*/ /*
                                                                                       Center(
                                                                                          child:  Row(
                                                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                                                            mainAxisAlignment: MainAxisAlignment.center,
                                                                                            children: <Widget>[
                                                                                               InkWell(
                                                                                                child: PaddingWrap.paddingfromLTRB(
                                                                                                    0.0,
                                                                                                    0.0,
                                                                                                    0.0,
                                                                                                    0.0,
                                                                                                     Image.asset(
                                                                                                      //'assets/pre_login/video_play_button.png',
                                                                                                      'assets/newDesignIcon/circle_play.png',
                                                                                                      width: 50.0,
                                                                                                      height: 50.0,
                                                                                                    )),
                                                                                              )
                                                                                            ],
                                                                                          )),
                                                                                    ],
                                                                                  )),*/
                                                                            ),
                                                                          )),
                                                                    userPostModal.opportunityModelForFeed.assestVideoAndImage.length ==
                                                                                1 ||
                                                                            userPostModal.opportunityModelForFeed.assestVideoAndImage[index2].type ==
                                                                                "video"
                                                                        ?  Container(
                                                                            height:
                                                                                0.0,
                                                                          )
                                                                        :  InkWell(
                                                                            onTap:
                                                                                () {
                                                                              Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  CommonFullViewWidget(userPostModal.opportunityModelForFeed.assestVideoAndImage, MessageConstant.HOME_OPPORTUNITY_HEDING, index2, MessageConstant.COMPANY_PROFILE_HEDING)));
                                                                            },
                                                                            child:
                                                                                 Container(
                                                                              height: 215.50,
                                                                              width: double.infinity,
                                                                              child:  Image.asset(
                                                                                "assets/newDesignIcon/navigation/layer_image.png",
                                                                                fit: BoxFit.fill,
                                                                              ),
                                                                            ))
                                                                  ],
                                                                );
                                                              },
                                                              onPageChanged:
                                                                  (index) {},
                                                            ),
                                                            align:
                                                                IndicatorAlign
                                                                    .bottom,
                                                            length: userPostModal
                                                                .opportunityModelForFeed
                                                                .assestVideoAndImage
                                                                .length,
                                                            indicatorSpace:
                                                                10.0,
                                                            indicatorColor: userPostModal
                                                                        .opportunityModelForFeed
                                                                        .assestVideoAndImage
                                                                        .length ==
                                                                    1
                                                                ? Colors
                                                                    .transparent
                                                                :  Color(
                                                                    0xffc4c4c4),
                                                            indicatorSelectorColor: userPostModal
                                                                        .opportunityModelForFeed
                                                                        .assestVideoAndImage
                                                                        .length ==
                                                                    1
                                                                ? Colors
                                                                    .transparent
                                                                :  Color(
                                                                    0XFFFFFFFF),
                                                            shape: IndicatorShape
                                                                .circle(
                                                                    size: 5.0),
                                                          ))
                                                      :  Stack(
                                                          children: <Widget>[
                                                               Image.asset(
                                                                "assets/profile/default_achievement.png",
                                                                fit: BoxFit
                                                                    .cover,
                                                                height: 215.50,
                                                                width: double
                                                                    .infinity,
                                                              ),
                                                               Container(
                                                                height: 215.50,
                                                                color: Colors
                                                                    .black54
                                                                    .withOpacity(
                                                                        .4),
                                                              )
                                                            ])),
                                              Container(
                                                height: 85,
                                                color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                                child: Column(
                                                  children: <Widget>[
                                                    Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  left: 13,
                                                                  top: 16.0),
                                                          child: Image.asset(
                                                            "assets/newDesignIcon/patner/spike_grey.png",
                                                            height: 12.0,
                                                            width: 12.0,
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  left: 3.0,
                                                                  top: 16.0),
                                                          child: Text(
                                                            "OPPORTUNITY",
                                                            style: TextStyle(
                                                                color: Color(
                                                                    0xFF404040),
                                                                fontSize: 12),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Row(
                                                      children: <Widget>[
                                                         Expanded(
                                                          child: Container(
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      13.0,
                                                                      2.0,
                                                                      10.0,
                                                                      10.0),
                                                              child: Text(
                                                                userPostModal.opportunityModelForFeed.offerId ==
                                                                            "4" ||
                                                                        userPostModal.opportunityModelForFeed.offerId ==
                                                                            "5"
                                                                    ? userPostModal
                                                                        .opportunityModelForFeed
                                                                        .serviceTitle
                                                                    : userPostModal
                                                                        .opportunityModelForFeed
                                                                        .jobTitle,
                                                                style:  TextStyle(
                                                                    color: Colors
                                                                        .black,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMBOLD,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold),
                                                                maxLines: 2,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                              ),
                                                            ),
                                                          ),
                                                          flex: 1,
                                                        ),
                                                        diffrenceInDob < 13
                                                            ?  Container(
                                                                height: 0.0,
                                                              )
                                                            :  Expanded(
                                                                child:
                                                                     InkWell(
                                                                  child:
                                                                      Padding(
                                                                    padding: const EdgeInsets
                                                                            .fromLTRB(
                                                                        15.0,
                                                                        0.0,
                                                                        15.0,
                                                                        0.0),
                                                                    child:  Container(
                                                                        height: 25.0,
                                                                        alignment: FractionalOffset.center,
                                                                        decoration:  BoxDecoration(
                                                                          color:
                                                                              ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                                                          border:
                                                                              Border.all(color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                                                                        ),
                                                                        child: Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              6.0,
                                                                              0.0,
                                                                              6.0,
                                                                              0.0),
                                                                          child:
                                                                               Text(
                                                                            userPostModal.opportunityModelForFeed.actionType == Constant.LINK_URL
                                                                                ? userPostModal.opportunityModelForFeed.linkUrlPosition == Constant.LEARN_MORE ? "LEARN MORE" : userPostModal.opportunityModelForFeed.linkUrlPosition == Constant.GET_OFFER ? "GET OFFER" : "APPLY NOW"
                                                                                : userPostModal.opportunityModelForFeed.actionType == Constant.JOIN_GROUP ? "JOIN GROUP" : userPostModal.opportunityModelForFeed.actionType == Constant.CALL_NOW ? "CALL NOW" : "INQUIRE NOW",
                                                                            style:  TextStyle(
                                                                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                                fontSize: 12.0,
                                                                                fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                          ),
                                                                        )),
                                                                  ),
                                                                  onTap: () {
                                                                    apiCallingForIncreaseCount(
                                                                        userPostModal
                                                                            .feedId);
                                                                    if (userPostModal
                                                                            .opportunityModelForFeed
                                                                            .actionType ==
                                                                        Constant
                                                                            .LINK_URL) {
                                                                      Navigator.push(
                                                                          context,
                                                                           MaterialPageRoute(
                                                                              //   builder: (context) =>  DashBoardWidget()));
                                                                              builder: (context) =>  WebViewWidget(userPostModal.opportunityModelForFeed.url.contains("http") ? userPostModal.opportunityModelForFeed.url : "https://" + userPostModal.opportunityModelForFeed.url, userPostModal.opportunityModelForFeed.linkUrlPosition == Constant.LEARN_MORE ? "LEARN MORE" : userPostModal.opportunityModelForFeed.linkUrlPosition == Constant.GET_OFFER ? "GET OFFER" : "APPLY NOW")));
                                                                    } else if (userPostModal
                                                                            .opportunityModelForFeed
                                                                            .actionType ==
                                                                        Constant
                                                                            .JOIN_GROUP) {
                                                                      apiCallJoin(
                                                                          userPostModal
                                                                              .opportunityModelForFeed
                                                                              .groupIdAction,
                                                                          userPostModal);
                                                                    } else if (userPostModal
                                                                            .opportunityModelForFeed
                                                                            .actionType ==
                                                                        Constant
                                                                            .CALL_NOW) {
                                                                      String
                                                                          callingNumber =
                                                                          userPostModal
                                                                              .opportunityModelForFeed
                                                                              .callingNumber;
                                                                      launch("tel:" +
                                                                          callingNumber);
                                                                    } else {
                                                                      Navigator.of(context).push(new MaterialPageRoute(
                                                                          builder: (BuildContext context) =>  InquireNowScreen(
                                                                              userPostModal.opportunityModelForFeed.opportunityId,
                                                                              userPostModal.feedId,
                                                                              userPostModal.opportunityModelForFeed.formId,
                                                                              userPostModal.opportunityModelForFeed.offerId.toString(),
                                                                              "")));
                                                                    }
                                                                  },
                                                                ),
                                                                flex: 0,
                                                              ),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                      onTap: () {
                                        Navigator.of(context).push(
                                             MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                     OpportunityViewWidget(
                                                        userPostModal
                                                            .opportunityModelForFeed,
                                                        userPostModal.feedId,
                                                        userIdPref,
                                                        roleId,
                                                        diffrenceInDob,
                                                        "")));
                                      },
                                    ),
                                    diffrenceInDob < 13
                                        ? Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                15.0, 10.0, 20.0, 10.0),
                                            child:  Row(
                                              children: <Widget>[
                                                 Expanded(
                                                  child:  InkWell(
                                                    child:  Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              0.0),
                                                      child:  Text(
                                                        "FORWARD TO PARENT",
                                                        style: TextStyle(
                                                            fontFamily: Constant
                                                                .customRegular,
                                                            fontSize: 12.0,
                                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                                                      ),
                                                    ),
                                                    onTap: () {
                                                      forwardToParentConformAtionDialog(
                                                          userPostModal, index);
                                                    },
                                                  ),
                                                  flex: 1,
                                                ),
                                                Expanded(
                                                    child:  InkWell(
                                                      child: Image.asset(
                                                        'assets/profile/parent/info.png',
                                                        height: 25.0,
                                                        width: 25.0,
                                                      ),
                                                      onTap: () {
                                                        infoDialog();
                                                      },
                                                    ),
                                                    flex: 0),
                                              ],
                                            ),
                                          )
                                        :  Container(
                                            height: 0.0,
                                          ),
                                  ],
                                ))),

                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                      child:  Row(
                        children: <Widget>[
                           Expanded(
                            child: userPostModal.likeList.length > 0
                                ? PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    10.0,
                                    0.0,
                                    InkWell(
                                      child: TextViewWrap.textView(
                                          userPostModal.likeList.length == 0
                                              ? "Like"
                                              : userPostModal.likeList.length ==
                                                      1
                                                  ? "1 Like"
                                                  : userPostModal
                                                          .likeList.length
                                                          .toString() +
                                                      " Likes",
                                          TextAlign.end,
                                          ColorValues.GREY_TEXT_COLOR,
                                          14.0,
                                          FontWeight.normal),
                                      onTap: () {
                                        onTapLikeText(userPostModal);
                                      },
                                    ))
                                :  Container(
                                    height: 0.0,
                                  ),
                            flex: 0,
                          ),
                          /* Padding(
                            padding: const EdgeInsets.only(bottom: 6.0),
                            child:  Text(
                              ".",
                              style: TextStyle(
                                  fontSize: 16.0,
                                  color: ColorValues.GREY_TEXT_COLOR),
                            ),
                          ),*/
                          userPostModal.commentList.length > 0
                              ?  InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    TextViewWrap.textView(
                                        userPostModal.commentList.length == 0
                                            ? "Comment"
                                            : "" +
                                                userPostModal.commentList.length
                                                    .toString() +
                                                " Comments",
                                        TextAlign.left,
                                        ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal),
                                  ),
                                  onTap: () {
                                    onTapViewAllComments(
                                        userPostModal.commentList,
                                        userPostModal.feedId,
                                        userPostModal);
                                  },
                                )
                              :  Container(
                                  height: 0.0,
                                )
                        ],
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Divider(
                          height: 1.0, color: ColorValues.DARK_GREY),
                    ),

                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        0.0,
                         Row(
                          children: <Widget>[
                             Expanded(
                              child:  Row(
                                children: <Widget>[
                                  userPostModal.isLike
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          10.0,
                                          0.0,
                                           Row(
                                            children: <Widget>[
                                               InkWell(
                                                child: PaddingWrap.paddingAll(
                                                    10.0,
                                                     Image.asset(
                                                      "assets/newDesignIcon/feed/like_green.png",
                                                      height: 24.0,
                                                      width: 25.0,
                                                    )),
                                                onTap: () {
                                                  onTapLike(userPostModal);
                                                },
                                              ),
                                              getText(
                                                  "Like",
                                                  ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR)
                                            ],
                                          ))
                                      : PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                           InkWell(
                                            child:  Row(
                                              children: <Widget>[
                                                PaddingWrap.paddingAll(
                                                    10.0,
                                                     Image.asset(
                                                      "assets/newDesignIcon/feed/like.png",
                                                      height: 24.0,
                                                      width: 25.0,
                                                    )),
                                                getText("Like",
                                                    ColorValues.GREY_TEXT_COLOR)
                                              ],
                                            ),
                                            onTap: () {
                                              onTapLike(userPostModal);
                                            },
                                          )),
                                  Spacer(),
                                  PaddingWrap.paddingfromLTRB(
                                    5.0,
                                    0.0,
                                    10.0,
                                    0.0,
                                     InkWell(
                                      child:  Row(
                                        children: <Widget>[
                                          PaddingWrap.paddingAll(
                                              0.0,
                                               Image.asset(
                                                "assets/newDesignIcon/feed/msg.png",
                                                height: 25.0,
                                                width: 25.0,
                                              )),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 12.0),
                                            child: getText("Comment",
                                                ColorValues.GREY_TEXT_COLOR),
                                          )
                                        ],
                                      ),
                                      onTap: () {
                                        if (userPostModal.isShowCommentIcon)
                                          userPostModal.isShowCommentIcon =
                                              false;
                                        else {
                                          _scrollController.jumpTo(
                                              (_scrollController.offset +
                                                  80.0));
                                          userPostModal.isShowCommentIcon =
                                              true;
                                        }

                                        setState(() {
                                          userPostModal.isShowCommentIcon;
                                        });
                                      },
                                    ),
                                  ),
                                  Spacer(),
                                  /*  Padding(
                                    padding: const EdgeInsets.only(bottom: 5.0),
                                    child:  Text(
                                      ".",
                                      style: TextStyle(
                                          fontSize: 16.0,
                                          color: ColorValues.GREY_TEXT_COLOR),
                                    ),
                                  ),
                                  Spacer(),*/
                                   InkWell(
                                    child:  Row(
                                      children: <Widget>[
                                        PaddingWrap.paddingAll(
                                            10.0,
                                             Image.asset(
                                              "assets/newDesignIcon/feed/share.png",
                                              height: 25.0,
                                              width: 25.0,
                                            )),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 2.0, right: 10.0),
                                          child: getText("Share",
                                              ColorValues.GREY_TEXT_COLOR),
                                        )
                                      ],
                                    ),
                                    onTap: () {
                                      /*   onTapShare(
                                        userPostModal);*/
                                      optionMenuForShareOpportunity(
                                          userPostModal, index);
                                    },
                                  ),
                                ],
                              ),
                              flex: 1,
                            ),
//                             Expanded(
//                              child: userPostModal.likeList.length > 0
//                                  ? PaddingWrap.paddingfromLTRB(
//                                  10.0,
//                                  0.0,
//                                  13.0,
//                                  0.0,
//                                  InkWell(
//                                    child: TextViewWrap.textView(
//                                        userPostModal.likeList.length == 1
//                                            ? "1 Like"
//                                            : userPostModal.likeList.length
//                                            .toString() +
//                                            " Likes",
//                                        TextAlign.end,
//                                        Color(ColorValues
//                                            .BLUE_COLOR_BOTTOMBAR),
//                                        12.0,
//                                        FontWeight.normal),
//                                    onTap: () {
//                                      onTapLikeText(userPostModal);
//                                    },
//                                  ))
//                                  :  Container(
//                                height: 0.0,
//                              ),
//                              flex: 0,
//                            )
                          ],
                        )),
                    PaddingWrap.paddingAll(
                        0.0,
                         Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            // Comment List view
                             Padding(
                                padding:
                                     EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                                child:  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children:  List.generate(
                                        userPostModal.commentList.length > 3
                                            ? 3
                                            : userPostModal.commentList.length,
                                        (int index) {
                                      return PaddingWrap.paddingfromLTRB(
                                          10.0,
                                          5.0,
                                          10.0,
                                          0.0,
                                           Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                               InkWell(
                                                  child:  Container(
                                                      width: 40.0,
                                                      height: 40.0,
                                                      child: ClipOval(
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                        fit: BoxFit.cover,
                                                        width: double.infinity,
                                                        placeholder: userPostModal
                                                                    .commentList[
                                                                        index]
                                                                    .roleId ==
                                                                "4"
                                                            ? "assets/profile/partner_img.png"
                                                            : 'assets/profile/user_on_user.png',
                                                        image: Constant
                                                                .IMAGE_PATH_SMALL +
                                                            userPostModal
                                                                .commentList[
                                                                    index]
                                                                .profilePicture,
                                                      ))),
                                                  onTap: () {
                                                    onTapImageTile(
                                                        userPostModal
                                                            .commentList[index]
                                                            .commentedBy,
                                                        userPostModal
                                                            .commentList[index]
                                                            .roleId);
                                                  }), // User Image
                                               SizedBox(
                                                width: 20.0,
                                              ),
                                               Expanded(
                                                child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(0, 0, 0, 0),
                                                      child:  Container(
                                                          child: Row(
                                                        children: <Widget>[
                                                          RichText(
                                                            maxLines: 2,
                                                            textAlign:
                                                                TextAlign.start,
                                                            text: TextSpan(
                                                              text: userPostModal
                                                                  .commentList[
                                                                      index]
                                                                  .name,
                                                              style:
                                                                   TextStyle(
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontSize: 14.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                              /* children: <TextSpan>[
                                                              TextSpan(
                                                                  text: userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .comment,
                                                                  style:  TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                        ],*/
                                                            ),
                                                          ),
                                                          userPostModal.commentList[
                                                                          index] !=
                                                                      null &&
                                                                  userPostModal
                                                                          .commentList[
                                                                              index]
                                                                          .roleId ==
                                                                      "1"
                                                              //true
                                                              ? Util.getStudentBadge12(
                                                                  userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .badge,
                                                                  userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .badgeImage)
                                                              : Container(),
                                                        ],
                                                      )),
                                                    ),
                                                     Container(
                                                      child: Linkify(
                                                        onOpen: (link) async {
                                                          print("onclick +++");

                                                          Navigator.push(
                                                              context,
                                                               MaterialPageRoute(
                                                                  //   builder: (context) =>  DashBoardWidget()));
                                                                  builder: (context) =>
                                                                       WebViewWidget(
                                                                          link.url,
                                                                          "spikeview")));
                                                        },
                                                        text: userPostModal
                                                            .commentList[index]
                                                            .comment,
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 14.0,
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                        linkStyle:  TextStyle(
                                                            color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR,
                                                            fontSize: 14.0),
                                                      ),
                                                    ),
                                                     Padding(
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                5.0,
                                                                0.0,
                                                                0.0),
                                                        child:  Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: <Widget>[
                                                             Expanded(
                                                              child:  Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: <
                                                                    Widget>[
                                                                   Text(
                                                                    userPostModal
                                                                        .commentList[
                                                                            index]
                                                                        .dateTime,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .end,
                                                                    style: TextStyle(
                                                                        color: ColorValues.GREY_TEXT_COLOR,
                                                                        fontSize:
                                                                            12.0,
                                                                        fontFamily:
                                                                            Constant.customRegular),
                                                                  )
                                                                ],
                                                              ),
                                                              flex: 0,
                                                            ),
                                                             Container(
                                                              width: 10.0,
                                                            ),
                                                             Expanded(
                                                              child: userIdPref ==
                                                                      userPostModal
                                                                          .commentList[
                                                                              index]
                                                                          .commentedBy
                                                                  ?  InkWell(
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            0,
                                                                            0,
                                                                            0),
                                                                        child:  Image
                                                                            .asset(
                                                                          "assets/profile/post/user_more1.png",
                                                                          width:
                                                                              25.0,
                                                                          height:
                                                                              25.0,
                                                                        ),
                                                                      ),
                                                                      onTap:
                                                                          () {
                                                                        optionForDelete(
                                                                            userPostModal.commentList,
                                                                            userPostModal.feedId,
                                                                            userPostModal,
                                                                            userPostModal.commentList[index].commentId);
                                                                      },
                                                                    )
                                                                  :  Container(
                                                                      height:
                                                                          1.0,
                                                                    ),
                                                              flex: 0,
                                                            )
                                                          ],
                                                        )),
                                                  ],
                                                ),
                                                flex: 1,
                                              ) // Comment List Cell
                                            ],
                                          ));
                                    }))),

                            // View All Comments
                            userPostModal.commentList.length > 3
                                ?  InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      0.0,
                                      0.0,
                                      5.0,
                                      TextViewWrap.textView(
                                          "View All " +
                                              userPostModal.commentList.length
                                                  .toString() +
                                              " Comments",
                                          TextAlign.left,
                                          ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          12.0,
                                          FontWeight.normal),
                                    ),
                                    onTap: () {
                                      onTapViewAllComments(
                                          userPostModal.commentList,
                                          userPostModal.feedId,
                                          userPostModal);
                                    },
                                  )
                                :  Container(
                                    height: 0.0,
                                  ),

                            // Comment Edit Text
                            userPostModal.isShowCommentIcon
                                ? PaddingWrap.paddingAll(
                                    10.0,
                                     Row(
                                      children: <Widget>[
                                        //Alok Code Done
                                         Container(
                                          width: 40.0,
                                          height: 40.0,
                                          child: ClipOval(
                                            child: FadeInImage.assetNetwork(
                                              fit: BoxFit.cover,
                                              placeholder: roleId == "4"
                                                  ? "assets/profile/partner_img.png"
                                                  : 'assets/profile/user_on_user.png',
                                              image: roleId == "4"
                                                  ? Constant.IMAGE_PATH +
                                                      companyPath
                                                  : Constant.IMAGE_PATH +
                                                      profilePath,
                                              height: 45.0,
                                              width: 45.0,
                                            ),
                                          ),
                                        ),
                                         SizedBox(
                                          width: 20.0,
                                        ),
                                         Expanded(
                                            child:  Container(
                                                decoration:  BoxDecoration(
                                                    border:  Border.all(
                                                        width: 1.0,
                                                        color:   ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                                child:  Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Expanded(
                                                      child:  TextField(
                                                        controller:
                                                            userPostModal
                                                                .txtController,
                                                        style:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),        keyboardType:
                                                            TextInputType.text,
                                                        textCapitalization:
                                                            TextCapitalization
                                                                .sentences,
                                                        maxLines: null,
                                                        maxLength: TextLength
                                                            .COMMENT_MAX_LENGTH,
                                                        onChanged: (s) {
                                                          if (s.trim().length >
                                                              0) {
                                                            userPostModal
                                                                    .isCommentIconVisible =
                                                                true;
                                                          } else {
                                                            userPostModal
                                                                    .isCommentIconVisible =
                                                                false;
                                                          }
                                                          setState(() {
                                                            userPostModal
                                                                .isCommentIconVisible;
                                                          });
                                                        },
                                                        decoration:
                                                             InputDecoration(
                                                          border:
                                                              InputBorder.none,
                                                          filled: true,
                                                              counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),          counterText: "",
                                                          hintText: roleId ==
                                                                  "4"
                                                              ? "Add Comment as " +
                                                                  prefs.getString(
                                                                      UserPreference
                                                                          .COMPANY_NAME_PATH)
                                                              : profileInfoModal
                                                                              .lastName ==
                                                                          "" ||
                                                                      profileInfoModal
                                                                              .lastName ==
                                                                          "null"
                                                                  ? "Add Comment as " +
                                                                      profileInfoModal
                                                                          .firstName
                                                                  : "Add Comment as " +
                                                                      profileInfoModal
                                                                          .firstName +
                                                                      " " +
                                                                      profileInfoModal
                                                                          .lastName,
                                                          hintStyle:  TextStyle(
                                                              color:   ColorValues.hintColor,
                                                              fontSize: 14.0,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                          fillColor: Colors
                                                              .transparent,
                                                        ),
                                                      ),
                                                      flex: 4,
                                                    ),
                                                     Expanded(
                                                      child:
                                                          /*userPostModal
                                                    .isCommentIconVisible
                                                ?*/
                                                           InkWell(
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                0.0,
                                                                5.0,
                                                                0.0,
                                                                 Image.asset(
                                                                  "assets/newDesignIcon/feed/send.png",
                                                                  width: 22.0,
                                                                  height: 22.0,
                                                                )),
                                                        onTap: () {
                                                          if (userPostModal
                                                              .isCommentIconVisible) {
                                                            FocusScope.of(
                                                                    context)
                                                                .requestFocus(
                                                                     FocusNode());
                                                            userPostModal
                                                                    .isCommentIconVisible =
                                                                false;
                                                            onAddComment(
                                                                userPostModal
                                                                    .feedId,
                                                                userPostModal
                                                                    .txtController
                                                                    .text,
                                                                userPostModal);
                                                            userPostModal
                                                                .txtController
                                                                .text = "";
                                                            setState(() {
                                                              userPostModal
                                                                  .txtController;
                                                              userPostModal
                                                                  .isCommentIconVisible;
                                                            });
                                                          }
                                                        },
                                                      )
                                                      /*:  Container(
                                                    height: 0.0,
                                                  )*/
                                                      ,
                                                      flex: 0,
                                                    )
                                                  ],
                                                )),
                                            flex: 1)
                                      ],
                                    ))
                                :  Container(
                                    height: 0.0,
                                  ),

                            (userPostList.length - 1) == index
                                ?  Container(
                                    height: 10.0,
                                  )
                                : PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    10.0,
                                     Divider(
                                      color: ColorValues.GREY_TEXT_COLOR,
                                      height: 1.0,
                                    ))
                          ],
                        ))
                  ])));
    }

    Padding getListViewForOpportunity(UserPostModal userPostModal, index) {
      print('Mona 222 getListViewForOpportunity() 222');
      return PaddingWrap.paddingAll(
          0.0,
           Container(
              color:  ColorValues.SCREEN_BG_COLOR,
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  //  getEvent(userPostModal),
                  PaddingWrap.paddingfromLTRB(
                      15.0,
                      15.0,
                      13.0,
                      10.0,
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  InkWell(
                              child:  Center(
                                child:  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    child: ClipOval(
                                        child: FadeInImage.assetNetwork(
                                      fit: BoxFit.cover,
                                      width: double.infinity,
                                      placeholder: userPostModal.roleId == "4"
                                          ? "assets/profile/partner_img.png"
                                          : 'assets/profile/user_on_user.png',
                                      image: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getSmallImage(userPostModal
                                              .opportunityModelForFeed
                                              .profilePicture),
                                    ))),
                              ),
                              onTap: () {
                                print("postedBy " +
                                    userPostModal.postedBy +
                                    "  " +
                                    userPostModal.roleId);

                                // ToastWrap.showToast(userPostModal.postedBy);
                                onTapImageTile(userPostModal.postedBy,
                                    userPostModal.roleId);
                              },
                            ),
                            flex: 0,
                          ),
                           Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                8.0,
                                0.0,
                                15.0,
                                0.0,
                                 Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                     InkWell(
                                      child:  Container(
                                          child: Row(
                                        children: <Widget>[
                                          RichText(
                                            maxLines: 2,
                                            textAlign: TextAlign.start,
                                            text: TextSpan(
                                              text: userPostModal
                                                  .opportunityModelForFeed
                                                  .companyName,
                                              style:  TextStyle(
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontSize: 15.0,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                          /*userPostModal.opportunityModelForFeed != null && userPostModal.opportunityModelForFeed.roleId == "1"
                                              //true
                                                  ? Util.getStudentBadge12(userPostModal.opportunityModelForFeed.badge,userPostModal.opportunityModelForFeed.badgeImage):Container(),*/
                                        ],
                                      )),
                                      onTap: () {
                                        onTapImageTile(userPostModal.postedBy,
                                            userPostModal.roleId);
                                      },
                                    ),
                                    TextViewWrap.textView(
                                        userPostModal.dateTime,
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        12.0,
                                        FontWeight.normal),
                                  ],
                                )),
                            flex: 4,
                          ),
                           Expanded(
                            child: userIdPref == userPostModal.postedBy &&
                                    roleId == userPostModal.roleId.toString()
                                ?  Container(
                                    padding:  EdgeInsets.fromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        userPostModal.tagList.length > 0
                                            ? 38.0
                                            : 15.0),
                                    child:  InkWell(
                                      child:  Image.asset(
                                        "assets/profile/post/user_more1.png",
                                        width: 25.0,
                                        height: 25.0,
                                      ),
                                      onTap: () {
                                        optionMenuDelete(userPostModal, index);
                                      },
                                    ))
                                :  Container(
                                    padding:  EdgeInsets.fromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        userPostModal.tagList.length > 0
                                            ? 38.0
                                            : 15.0),
                                    child:  InkWell(
                                      child:  Image.asset(
                                        "assets/profile/post/user_more1.png",
                                        width: 25.0,
                                        height: 25.0,
                                      ),
                                      onTap: () {
                                        optionForReport(userPostModal, index);
                                      },
                                    )),
                            flex: 0,
                          )
                        ],
                      )),

                   InkWell(
                    child: Container(
                      width: double.infinity,
                      child: Card(
                        elevation: 0.0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(0.0)),
                        color: ColorValues.WHITE,
                        child: Column(
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                0.0,
                                //
                                userPostModal.opportunityModelForFeed
                                            .assestVideoAndImage.length >
                                        0
                                    ?  SizedBox(
                                        // Pager view
                                        height: 215.50,
                                        child: PageIndicatorContainer(
                                          pageView:  PageView.builder(
                                            itemCount: userPostModal
                                                .opportunityModelForFeed
                                                .assestVideoAndImage
                                                .length,
                                            controller:  PageController(),
                                            itemBuilder: (context, index2) {
                                              return  Stack(
                                                children: <Widget>[
                                                  userPostModal
                                                              .opportunityModelForFeed
                                                              .assestVideoAndImage[
                                                                  index2]
                                                              .type ==
                                                          "image"
                                                      ? Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors.black,
                                                          ),
                                                          child:
                                                               CachedNetworkImage(
                                                            width:
                                                                double.infinity,
                                                            height: 215.50,
                                                            imageUrl: Constant
                                                                    .IMAGE_PATH +
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .assestVideoAndImage[
                                                                        index2]
                                                                    .file,
                                                            fit: BoxFit.contain,
                                                            placeholder:
                                                                (context,
                                                                        url) =>
                                                                    _loader(
                                                                        context),
                                                            errorWidget:
                                                                (context, url,
                                                                        error) =>
                                                                    _error(),
                                                          ),
                                                        )
                                                      :  InkWell(
                                                          child:  Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors.black,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        0),
                                                          ),
                                                          height: 215.50,
                                                          child:  Center(
                                                            child:  VideoPlayPauseDialogOffline(
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .assestVideoAndImage[
                                                                        index2]
                                                                    .file,
                                                                "",
                                                                true),
                                                            /*new Container(
                                                                child:  Stack(
                                                                  children: <Widget>[

                                                                    Container(
                                                                      height: 215.0,
                                                                      color: Colors.black,
                                                                      margin: EdgeInsets.only(left: 0, right: 0),
                                                                      child:  VideoViewBlack(
                                                                          Constant.IMAGE_PATH + userPostModal
                                                                              .opportunityModelForFeed
                                                                              .assestVideoAndImage[
                                                                          index2]
                                                                              .file, "", false, ""),
                                                                    ),
                                                                    */ /*new Container(
                                                                                      height: 54.0,
                                                                                      width: 80.0,
                                                                                      color:  Color(0XFFC0C0C0).withOpacity(.4),
                                                                                    ),*/ /*
                                                                     Center(
                                                                        child:  Row(
                                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                                          mainAxisAlignment: MainAxisAlignment.center,
                                                                          children: <Widget>[
                                                                             InkWell(
                                                                              child: PaddingWrap.paddingfromLTRB(
                                                                                  0.0,
                                                                                  0.0,
                                                                                  0.0,
                                                                                  0.0,
                                                                                   Image.asset(
                                                                                    //'assets/pre_login/video_play_button.png',
                                                                                    'assets/newDesignIcon/circle_play.png',
                                                                                    width: 50.0,
                                                                                    height: 50.0,
                                                                                  )),
                                                                            )
                                                                          ],
                                                                        )),
                                                                  ],
                                                                )),*/
                                                          ),
                                                        )),
                                                  userPostModal
                                                                  .opportunityModelForFeed
                                                                  .assestVideoAndImage
                                                                  .length ==
                                                              1 ||
                                                          userPostModal
                                                                  .opportunityModelForFeed
                                                                  .assestVideoAndImage[
                                                                      index2]
                                                                  .type ==
                                                              "video"
                                                      ?  Container(
                                                          height: 0.0,
                                                        )
                                                      :  InkWell(
                                                          onTap: () {
                                                            Navigator.of(context).push(new MaterialPageRoute(
                                                                builder: (BuildContext context) =>  CommonFullViewWidget(
                                                                    userPostModal
                                                                        .opportunityModelForFeed
                                                                        .assestVideoAndImage,
                                                                    MessageConstant
                                                                        .HOME_OPPORTUNITY_HEDING,
                                                                    index2,
                                                                    MessageConstant
                                                                        .COMPANY_PROFILE_HEDING)));
                                                          },
                                                          child:  Container(
                                                            height: 215.50,
                                                            width:
                                                                double.infinity,
                                                            child:
                                                                 Image.asset(
                                                              "assets/newDesignIcon/navigation/layer_image.png",
                                                              fit: BoxFit.fill,
                                                            ),
                                                          ))
                                                ],
                                              );
                                            },
                                            onPageChanged: (index) {},
                                          ),
                                          align: IndicatorAlign.bottom,
                                          length: userPostModal
                                              .opportunityModelForFeed
                                              .assestVideoAndImage
                                              .length,
                                          indicatorSpace: 10.0,
                                          indicatorColor: userPostModal
                                                      .opportunityModelForFeed
                                                      .assestVideoAndImage
                                                      .length ==
                                                  1
                                              ? Colors.transparent
                                              :  Color(0xffc4c4c4),
                                          indicatorSelectorColor: userPostModal
                                                      .opportunityModelForFeed
                                                      .assestVideoAndImage
                                                      .length ==
                                                  1
                                              ? Colors.transparent
                                              :  ColorValues.WHITE,
                                          shape:
                                              IndicatorShape.circle(size: 5.0),
                                        ))
                                    :  Stack(children: <Widget>[
                                         Image.asset(
                                          "assets/profile/default_achievement.png",
                                          fit: BoxFit.cover,
                                          height: 215.50,
                                          width: double.infinity,
                                        ),
                                         Container(
                                          height: 215.50,
                                          color: Colors.black54.withOpacity(.4),
                                        )
                                      ])),
                            Container(
                              height: 85,
                              color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 13, top: 16.0),
                                        child: Image.asset(
                                          "assets/newDesignIcon/patner/spike_grey.png",
                                          height: 12.0,
                                          width: 12.0,
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 3.0, top: 16.0),
                                        child: Text(
                                          "OPPORTUNITY",
                                          style: TextStyle(
                                              color: ColorValues.GREY_TEXT_COLOR,
                                              fontSize: 12),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: Container(
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                13.0, 2.0, 10.0, 10.0),
                                            child: Text(
                                              userPostModal
                                                              .opportunityModelForFeed
                                                              .offerId ==
                                                          "4" ||
                                                      userPostModal
                                                              .opportunityModelForFeed
                                                              .offerId ==
                                                          "5"
                                                  ? userPostModal
                                                      .opportunityModelForFeed
                                                      .serviceTitle
                                                  : userPostModal
                                                      .opportunityModelForFeed
                                                      .jobTitle,
                                              style:  TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 14.0,
                                                  fontFamily: Constant.TYPE_CUSTOMBOLD,
                                                  fontWeight: FontWeight.bold),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ),
                                        flex: 1,
                                      ),
                                      diffrenceInDob < 13
                                          ?  Container(
                                              height: 0.0,
                                            )
                                          :  Expanded(
                                              child:  InkWell(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          15.0, 0.0, 15.0, 0.0),
                                                  child:  Container(
                                                      height: 25.0,
                                                      alignment:
                                                          FractionalOffset
                                                              .center,
                                                      decoration:
                                                           BoxDecoration(
                                                        color:
                                                            ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                                        border: Border.all(
                                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                                                      ),
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                6.0,
                                                                0.0,
                                                                6.0,
                                                                0.0),
                                                        child:  Text(
                                                          userPostModal
                                                                      .opportunityModelForFeed
                                                                      .actionType ==
                                                                  Constant
                                                                      .LINK_URL
                                                              ? userPostModal
                                                                          .opportunityModelForFeed
                                                                          .linkUrlPosition ==
                                                                      Constant
                                                                          .LEARN_MORE
                                                                  ? "LEARN MORE"
                                                                  : userPostModal
                                                                              .opportunityModelForFeed
                                                                              .linkUrlPosition ==
                                                                          Constant
                                                                              .GET_OFFER
                                                                      ? "GET OFFER"
                                                                      : "APPLY NOW"
                                                              : userPostModal
                                                                          .opportunityModelForFeed
                                                                          .actionType ==
                                                                      Constant
                                                                          .JOIN_GROUP
                                                                  ? "JOIN GROUP"
                                                                  : userPostModal
                                                                              .opportunityModelForFeed
                                                                              .actionType ==
                                                                          Constant
                                                                              .CALL_NOW
                                                                      ? "CALL NOW"
                                                                      : "INQUIRE NOW",
                                                          style:  TextStyle(
                                                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                              fontSize: 12.0,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                        ),
                                                      )),
                                                ),
                                                onTap: () {
                                                  apiCallingForIncreaseCount(
                                                      userPostModal.feedId);
                                                  if (userPostModal
                                                          .opportunityModelForFeed
                                                          .actionType ==
                                                      Constant.LINK_URL) {
                                                    Navigator.push(
                                                        Constant
                                                            .applicationContext,
                                                         MaterialPageRoute(
                                                            //   builder: (context) =>  DashBoardWidget()));
                                                            builder: (context) =>
                                                                 WebViewWidget(
                                                                    userPostModal
                                                                        .opportunityModelForFeed
                                                                        .url,
                                                                    "Learn More")));
                                                  } else if (userPostModal
                                                          .opportunityModelForFeed
                                                          .actionType ==
                                                      Constant.JOIN_GROUP) {
                                                    if (userPostModal
                                                                .opportunityModelForFeed
                                                                .studentJoinId ==
                                                            "" ||
                                                        userPostModal
                                                                .opportunityModelForFeed
                                                                .studentJoinId ==
                                                            "null") {
                                                      apiCallJoin(
                                                          userPostModal
                                                              .opportunityModelForFeed
                                                              .groupIdAction,
                                                          userPostModal);
                                                    } else {
                                                      apiCallForForwardParent(
                                                          userPostModal
                                                              .opportunityModelForFeed
                                                              .groupIdAction,
                                                          userPostModal);
                                                    }
                                                  } else if (userPostModal
                                                          .opportunityModelForFeed
                                                          .actionType ==
                                                      Constant.CALL_NOW) {
                                                    String callingNumber =
                                                        userPostModal
                                                            .opportunityModelForFeed
                                                            .callingNumber;
                                                    launch(
                                                        "tel:" + callingNumber);
                                                  } else {
                                                    Navigator.of(context).push(new MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                             InquireNowScreen(
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .opportunityId,
                                                                userPostModal
                                                                    .feedId,
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .formId,
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .offerId
                                                                    .toString(),
                                                                "")));
                                                  }
                                                },
                                              ),
                                              flex: 0,
                                            ),
                                    ],
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                               OpportunityViewWidget(
                                  userPostModal.opportunityModelForFeed,
                                  userPostModal.feedId,
                                  userIdPref,
                                  roleId,
                                  diffrenceInDob,
                                  "")));
                    },
                  ),
                  diffrenceInDob < 13
                      ? Padding(
                          padding:
                              const EdgeInsets.fromLTRB(15.0, 10.0, 20.0, 10.0),
                          child:  Row(
                            children: <Widget>[
                               Expanded(
                                child:  InkWell(
                                  child:  Padding(
                                    padding:
                                        EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                    child:  Text(
                                      "FORWARD TO PARENT",
                                      style: TextStyle(
                                          fontFamily: Constant.customRegular,
                                          fontSize: 12.0,
                                          color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                                    ),
                                  ),
                                  onTap: () {
                                    forwardToParentConformAtionDialog(
                                        userPostModal, index);
                                  },
                                ),
                                flex: 1,
                              ),
                              Expanded(
                                  child:  InkWell(
                                    child: Image.asset(
                                      'assets/profile/parent/info.png',
                                      height: 25.0,
                                      width: 25.0,
                                    ),
                                    onTap: () {
                                      infoDialog();
                                    },
                                  ),
                                  flex: 0),
                            ],
                          ),
                        )
                      :  Container(
                          height: 0.0,
                        ),

                  Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                    child:  Row(
                      children: <Widget>[
                         Expanded(
                          child: userPostModal.likeList.length > 0
                              ? PaddingWrap.paddingfromLTRB(
                                  10.0,
                                  0.0,
                                  10.0,
                                  0.0,
                                  InkWell(
                                    child: TextViewWrap.textView(
                                        userPostModal.likeList.length == 0
                                            ? "Like"
                                            : userPostModal.likeList.length == 1
                                                ? "1 Like"
                                                : userPostModal.likeList.length
                                                        .toString() +
                                                    " Likes",
                                        TextAlign.end,
                                        ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal),
                                    onTap: () {
                                      onTapLikeText(userPostModal);
                                    },
                                  ))
                              :  Container(
                                  height: 0.0,
                                ),
                          flex: 0,
                        ),
                        /*  Padding(
                          padding: const EdgeInsets.only(bottom: 6.0),
                          child:  Text(
                            ".",
                            style: TextStyle(
                                fontSize: 16.0,
                                color: ColorValues.GREY_TEXT_COLOR),
                          ),
                        ),*/
                        userPostModal.commentList.length == 0
                            ?  Container(
                                height: 0.0,
                              )
                            :  InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                  10.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  TextViewWrap.textView(
                                      userPostModal.commentList.length == 0
                                          ? "Comment"
                                          : "" +
                                              userPostModal.commentList.length
                                                  .toString() +
                                              " Comments",
                                      TextAlign.left,
                                      ColorValues.GREY_TEXT_COLOR,
                                      14.0,
                                      FontWeight.normal),
                                ),
                                onTap: () {
                                  onTapViewAllComments(
                                      userPostModal.commentList,
                                      userPostModal.feedId,
                                      userPostModal);
                                },
                              )
                      ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Divider(
                        height: 1.0, color: ColorValues.DARK_GREY),
                  ),

                  PaddingWrap.paddingfromLTRB(
                      4.0,
                      5.0,
                      0.0,
                      0.0,
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  Row(
                              children: <Widget>[
                                userPostModal.isLike
                                    ? PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        10.0,
                                        0.0,
                                         InkWell(
                                          child:  Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingAll(
                                                  10.0,
                                                   Image.asset(
                                                    "assets/newDesignIcon/feed/like_green.png",
                                                    height: 24.0,
                                                    width: 25.0,
                                                  )),
                                              getText(
                                                  "Like",
                                                  ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR)
                                            ],
                                          ),
                                          onTap: () {
                                            onTapLike(userPostModal);
                                          },
                                        ),
                                      )
                                    : PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                         InkWell(
                                          child:  Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingAll(
                                                  10.0,
                                                   Image.asset(
                                                    "assets/newDesignIcon/feed/like.png",
                                                    height: 24.0,
                                                    width: 25.0,
                                                  )),
                                              getText("Like",
                                                  ColorValues.GREY_TEXT_COLOR)
                                            ],
                                          ),
                                          onTap: () {
                                            onTapLike(userPostModal);
                                          },
                                        ),
                                      ),
                                Spacer(),
                                PaddingWrap.paddingfromLTRB(
                                  5.0,
                                  0.0,
                                  10.0,
                                  0.0,
                                   InkWell(
                                    child:  Row(
                                      children: <Widget>[
                                        PaddingWrap.paddingAll(
                                            0.0,
                                             Image.asset(
                                              "assets/newDesignIcon/feed/msg.png",
                                              height: 25.0,
                                              width: 25.0,
                                            )),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 12.0),
                                          child: getText("Comment",
                                              ColorValues.GREY_TEXT_COLOR),
                                        )
                                      ],
                                    ),
                                    onTap: () {
                                      if (userPostModal.isShowCommentIcon)
                                        userPostModal.isShowCommentIcon = false;
                                      else {
                                        _scrollController.jumpTo(
                                            (_scrollController.offset + 80.0));
                                        userPostModal.isShowCommentIcon = true;
                                      }

                                      setState(() {
                                        userPostModal.isShowCommentIcon;
                                      });
                                    },
                                  ),
                                ),
                                Spacer(),
                                 InkWell(
                                  child:  Row(
                                    children: <Widget>[
                                      PaddingWrap.paddingAll(
                                          10.0,
                                           Image.asset(
                                            "assets/newDesignIcon/feed/share.png",
                                            height: 25.0,
                                            width: 25.0,
                                          )),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 2.0, right: 10.0),
                                        child: getText("Share",
                                            ColorValues.GREY_TEXT_COLOR),
                                      )
                                    ],
                                  ),
                                  onTap: () {
                                    /*   onTapShare(
                                        userPostModal);*/
                                    optionMenuForShareOpportunity(
                                        userPostModal, index);
                                  },
                                ),

                                /* :  Container(
                                        height: 0.0,
                                      ),*/
                              ],
                            ),
                            flex: 1,
                          ),
                        ],
                      )),
                  PaddingWrap.paddingAll(
                      0.0,
                       Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          // Comment List view
                           Padding(
                              padding:
                                   EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                              child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:  List.generate(
                                      userPostModal.commentList.length > 3
                                          ? 3
                                          : userPostModal.commentList.length,
                                      (int index) {
                                    return PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        5.0,
                                        10.0,
                                        0.0,
                                         Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: <Widget>[
                                             InkWell(
                                                child:  Container(
                                                    width: 40.0,
                                                    height: 40.0,
                                                    child: ClipOval(
                                                        child: FadeInImage
                                                            .assetNetwork(
                                                      fit: BoxFit.cover,
                                                      width: double.infinity,
                                                      placeholder: userPostModal
                                                                  .commentList[
                                                                      index]
                                                                  .roleId ==
                                                              "4"
                                                          ? "assets/profile/partner_img.png"
                                                          : 'assets/profile/user_on_user.png',
                                                      image: Constant
                                                              .IMAGE_PATH_SMALL +
                                                          userPostModal
                                                              .commentList[
                                                                  index]
                                                              .profilePicture,
                                                    ))),
                                                onTap: () {
                                                  onTapImageTile(
                                                      userPostModal
                                                          .commentList[index]
                                                          .commentedBy,
                                                      userPostModal
                                                          .commentList[index]
                                                          .roleId);
                                                }), // User Image
                                             SizedBox(
                                              width: 20.0,
                                            ),
                                             Expanded(
                                              child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(0, 0, 0, 0),
                                                    child:  Container(
                                                        child: Row(
                                                      children: <Widget>[
                                                        RichText(
                                                          maxLines: 2,
                                                          textAlign:
                                                              TextAlign.start,
                                                          text: TextSpan(
                                                            text: userPostModal
                                                                .commentList[
                                                                    index]
                                                                .name,
                                                            style:
                                                                 TextStyle(
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            ),
                                                            /* children: <TextSpan>[
                                                              TextSpan(
                                                                  text: userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .comment,
                                                                  style:  TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                            ],*/
                                                          ),
                                                        ),
                                                        userPostModal.commentList[
                                                                        index] !=
                                                                    null &&
                                                                userPostModal
                                                                        .commentList[
                                                                            index]
                                                                        .roleId ==
                                                                    "1"
                                                            //true
                                                            ? Util.getStudentBadge12(
                                                                userPostModal
                                                                    .commentList[
                                                                        index]
                                                                    .badge,
                                                                userPostModal
                                                                    .commentList[
                                                                        index]
                                                                    .badgeImage)
                                                            : Container(),
                                                      ],
                                                    )),
                                                  ),
                                                   Container(
                                                    child: Linkify(
                                                      onOpen: (link) async {
                                                        print("onclick +++");

                                                        Navigator.push(
                                                            context,
                                                             MaterialPageRoute(
                                                                //   builder: (context) =>  DashBoardWidget()));
                                                                builder: (context) =>
                                                                     WebViewWidget(
                                                                        link.url,
                                                                        "spikeview")));
                                                      },
                                                      text: userPostModal
                                                          .commentList[index]
                                                          .comment,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                      linkStyle:  TextStyle(
                                                          color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR,
                                                          fontSize: 14.0),
                                                    ),
                                                  ),
                                                   Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              0.0,
                                                              5.0,
                                                              0.0,
                                                              0.0),
                                                      child:  Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child:  Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                 Text(
                                                                  userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .dateTime,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .end,
                                                                  style: TextStyle(
                                                                      color:  ColorValues.GREY_TEXT_COLOR,
                                                                      fontSize:
                                                                          12.0,
                                                                      fontFamily:
                                                                          Constant
                                                                              .customRegular),
                                                                )
                                                              ],
                                                            ),
                                                            flex: 0,
                                                          ),
                                                           Container(
                                                            width: 10.0,
                                                          ),
                                                           Expanded(
                                                            child: userIdPref ==
                                                                    userPostModal
                                                                        .commentList[
                                                                            index]
                                                                        .commentedBy
                                                                ?  InkWell(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          const EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              0,
                                                                              0,
                                                                              0),
                                                                      child:  Image
                                                                          .asset(
                                                                        "assets/profile/post/user_more1.png",
                                                                        width:
                                                                            25.0,
                                                                        height:
                                                                            25.0,
                                                                      ),
                                                                    ),
                                                                    onTap: () {
                                                                      optionForDelete(
                                                                          userPostModal
                                                                              .commentList,
                                                                          userPostModal
                                                                              .feedId,
                                                                          userPostModal,
                                                                          userPostModal
                                                                              .commentList[index]
                                                                              .commentId);
                                                                    },
                                                                  )
                                                                :  Container(
                                                                    height: 1.0,
                                                                  ),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      )),
                                                ],
                                              ),
                                              flex: 1,
                                            ) // Comment List Cell
                                          ],
                                        ));
                                  }))),

                          // View All Comments
                          userPostModal.commentList.length > 3
                              ?  InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    0.0,
                                    5.0,
                                    TextViewWrap.textView(
                                        "View All " +
                                            userPostModal.commentList.length
                                                .toString() +
                                            " Comments",
                                        TextAlign.left,
                                        ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        12.0,
                                        FontWeight.normal),
                                  ),
                                  onTap: () {
                                    onTapViewAllComments(
                                        userPostModal.commentList,
                                        userPostModal.feedId,
                                        userPostModal);
                                  },
                                )
                              :  Container(
                                  height: 0.0,
                                ),

                          // Comment Edit Text
                          userPostModal.isShowCommentIcon
                              ? PaddingWrap.paddingAll(
                                  10.0,
                                   Row(
                                    children: <Widget>[
                                      //Alok Code Done
                                       Container(
                                        width: 40.0,
                                        height: 40.0,
                                        child: ClipOval(
                                          child: FadeInImage.assetNetwork(
                                            fit: BoxFit.cover,
                                            placeholder: roleId == "4"
                                                ? "assets/profile/partner_img.png"
                                                : 'assets/profile/user_on_user.png',
                                            image: roleId == "4"
                                                ? Constant.IMAGE_PATH +
                                                    companyPath
                                                : Constant.IMAGE_PATH +
                                                    profilePath,
                                            height: 45.0,
                                            width: 45.0,
                                          ),
                                        ),
                                      ),
                                       SizedBox(
                                        width: 20.0,
                                      ),
                                       Expanded(
                                          child:  Container(
                                              decoration:  BoxDecoration(
                                                  border:  Border.all(
                                                      width: 1.0,
                                                      color:   ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                              child:  Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Expanded(
                                                    child:  TextField(
                                                      controller: userPostModal
                                                          .txtController,
                                                      style:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),    keyboardType:
                                                          TextInputType.text,
                                                      textCapitalization:
                                                          TextCapitalization
                                                              .sentences,
                                                      maxLines: null,
                                                      maxLength: TextLength
                                                          .COMMENT_MAX_LENGTH,
                                                      onChanged: (s) {
                                                        if (s.trim().length >
                                                            0) {
                                                          userPostModal
                                                                  .isCommentIconVisible =
                                                              true;
                                                        } else {
                                                          userPostModal
                                                                  .isCommentIconVisible =
                                                              false;
                                                        }
                                                        setState(() {
                                                          userPostModal
                                                              .isCommentIconVisible;
                                                        });
                                                      },
                                                      decoration:
                                                           InputDecoration(
                                                        border:
                                                            InputBorder.none,
                                                            counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),                filled: true,
                                                        counterText: "",
                                                        hintText: roleId == "4"
                                                            ? "Add Comment as " +
                                                                prefs.getString(
                                                                    UserPreference
                                                                        .COMPANY_NAME_PATH)
                                                            : profileInfoModal
                                                                            .lastName ==
                                                                        "" ||
                                                                    profileInfoModal
                                                                            .lastName ==
                                                                        "null"
                                                                ? "Add Comment as " +
                                                                    profileInfoModal
                                                                        .firstName
                                                                : "Add Comment as " +
                                                                    profileInfoModal
                                                                        .firstName +
                                                                    " " +
                                                                    profileInfoModal
                                                                        .lastName,
                                                        hintStyle:  TextStyle(
                                                            color:  ColorValues.hintColor,
                                                            fontSize: 14.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                        fillColor:
                                                            Colors.transparent,
                                                      ),
                                                    ),
                                                    flex: 4,
                                                  ),
                                                   Expanded(
                                                    child:
                                                        /*userPostModal
                                                    .isCommentIconVisible
                                                ?*/
                                                         InkWell(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                              0.0,
                                                              0.0,
                                                              5.0,
                                                              0.0,
                                                               Image.asset(
                                                                "assets/newDesignIcon/feed/send.png",
                                                                width: 22.0,
                                                                height: 22.0,
                                                              )),
                                                      onTap: () {
                                                        if (userPostModal
                                                            .isCommentIconVisible) {
                                                          FocusScope.of(context)
                                                              .requestFocus(
                                                                   FocusNode());
                                                          userPostModal
                                                                  .isCommentIconVisible =
                                                              false;
                                                          onAddComment(
                                                              userPostModal
                                                                  .feedId,
                                                              userPostModal
                                                                  .txtController
                                                                  .text,
                                                              userPostModal);
                                                          userPostModal
                                                              .txtController
                                                              .text = "";
                                                          setState(() {
                                                            userPostModal
                                                                .txtController;
                                                            userPostModal
                                                                .isCommentIconVisible;
                                                          });
                                                        }
                                                      },
                                                    )
                                                    /*:  Container(
                                                    height: 0.0,
                                                  )*/
                                                    ,
                                                    flex: 0,
                                                  )
                                                ],
                                              )),
                                          flex: 1)
                                    ],
                                  ))
                              :  Container(
                                  height: 0.0,
                                ),

                          (userPostList.length - 1) == index
                              ?  Container(
                                  height: 10.0,
                                )
                              : PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  10.0,
                                   Divider(
                                    color: ColorValues.GREY_TEXT_COLOR,
                                    height: 1.0,
                                  ))
                        ],
                      ))
                ],
              )));
    }

    Padding getListView(UserPostModal userPostModal, index) {
      print('Mona 333 getListViewForOpportunity() 333');
      if (userPostModal.tagList != null && userPostModal.tagList.length > 0)
        print(
            'Mona 333 userPostModal.tagList size:: ${userPostModal.tagList.length}, index:: $index');
      if (userPostModal.groupList != null && userPostModal.groupList.length > 0)
        print(
            'Mona 333 userPostModal.groupList size:: ${userPostModal.groupList.length}, index:: $index');
      return PaddingWrap.paddingAll(
          0.0,
           Container(
              color:  ColorValues.SCREEN_BG_COLOR,
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  //  getEvent(userPostModal),
                  PaddingWrap.paddingfromLTRB(
                      15.0,
                      15.0,
                      13.0,
                      10.0,
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  InkWell(
                              child:  Center(
                                child:  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    child: ClipOval(
                                        child: FadeInImage.assetNetwork(
                                      fit: BoxFit.cover,
                                      width: double.infinity,
                                      placeholder: userPostModal.roleId == "4"
                                          ? "assets/profile/partner_img.png"
                                          : 'assets/profile/user_on_user.png',
                                      image: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getSmallImage(
                                              userPostModal.profilePicture),
                                    ))),
                              ),
                              onTap: () {
                                // ToastWrap.showToast(userPostModal.postedBy);
                                onTapImageTile(userPostModal.postedBy,
                                    userPostModal.roleId);
                              },
                            ),
                            flex: 0,
                          ),
                           Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                8.0,
                                0.0,
                                15.0,
                                0.0,
                                 Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child: RichText(
                                              maxLines: 3,
                                              textAlign: TextAlign.start,
                                              text: TextSpan(
                                                recognizer:
                                                     TapGestureRecognizer()
                                                      ..onTap = () {
                                                        if (userPostModal
                                                                    .tagList
                                                                    .length >
                                                                0 &&
                                                            userPostModal
                                                                    .groupList
                                                                    .length >
                                                                0) {
                                                          onTapImageTile(
                                                              userPostModal
                                                                  .postedBy,
                                                              userPostModal
                                                                  .roleId);
                                                        }
                                                      },
                                                text: userPostModal.lastName ==
                                                            null ||
                                                        userPostModal
                                                                .lastName ==
                                                            "null"
                                                    ? userPostModal.firstName
                                                    : userPostModal.firstName +
                                                        " " +
                                                        userPostModal.lastName,
                                                style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 15.0,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                                children: userPostModal.tagList
                                                                .length ==
                                                            0 &&
                                                        userPostModal.groupList
                                                                .length ==
                                                            0
                                                    ? userPostModal
                                                                    .postedGroupName !=
                                                                null &&
                                                            userPostModal
                                                                    .postedGroupName !=
                                                                "null" &&
                                                            userPostModal
                                                                    .postedGroupName !=
                                                                ""
                                                        ? [
                                                            WidgetSpan(
                                                              child: userPostModal.roleId ==
                                                                      "1"
                                                                  ? Util.getStudentBadgeRichTextWithPadding(
                                                                      userPostModal
                                                                          .badge,
                                                                      userPostModal
                                                                          .badgeImage)
                                                                  : Container(
                                                                      height:
                                                                          0.0,
                                                                      width:
                                                                          0.0,
                                                                    ),
                                                            ),
                                                            TextSpan(
                                                                text: " > ",
                                                                style:
                                                                     TextStyle(
                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontSize:
                                                                      18.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                )),
                                                            TextSpan(
                                                                recognizer:
                                                                     TapGestureRecognizer()
                                                                      ..onTap =
                                                                          () {
                                                                        Navigator.of(context).push(new MaterialPageRoute(
                                                                            builder: (BuildContext context) =>  GroupDetailWidget(
                                                                                userPostModal.postedGroupId,
                                                                                "",
                                                                                "",
                                                                                "",
                                                                                "")));
                                                                      },
                                                                text: userPostModal
                                                                    .postedGroupName,
                                                                style:
                                                                     TextStyle(
                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontSize:
                                                                      15.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ))
                                                          ]
                                                        : [
                                                            WidgetSpan(
                                                              child: userPostModal.roleId ==
                                                                      "1"
                                                                  ? Util.getStudentBadgeRichTextWithPadding(
                                                                      userPostModal
                                                                          .badge,
                                                                      userPostModal
                                                                          .badgeImage)
                                                                  : Container(
                                                                      height:
                                                                          0.0,
                                                                      width:
                                                                          0.0,
                                                                    ),
                                                            ),
                                                          ]
                                                    : userPostModal.tagList
                                                                    .length !=
                                                                0 &&
                                                            userPostModal
                                                                    .groupList
                                                                    .length !=
                                                                0
                                                        ? [
                                                            WidgetSpan(
                                                              child: userPostModal.roleId ==
                                                                      "1"
                                                                  ? Util.getStudentBadgeRichTextWithPadding(
                                                                      userPostModal
                                                                          .badge,
                                                                      userPostModal
                                                                          .badgeImage)
                                                                  : Container(
                                                                      height:
                                                                          0.0,
                                                                      width:
                                                                          0.0,
                                                                    ),
                                                            ),
                                                            userPostModal.postedGroupName !=
                                                                        null &&
                                                                    userPostModal
                                                                            .postedGroupName !=
                                                                        "null" &&
                                                                    userPostModal
                                                                            .postedGroupName !=
                                                                        ""
                                                                ? TextSpan(
                                                                    text: " > ",
                                                                    style:
                                                                         TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          18.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                    ))
                                                                : TextSpan(
                                                                    text: "",
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                            userPostModal.postedGroupName !=
                                                                        null &&
                                                                    userPostModal
                                                                            .postedGroupName !=
                                                                        "null" &&
                                                                    userPostModal
                                                                            .postedGroupName !=
                                                                        ""
                                                                ? TextSpan(
                                                                    recognizer:
                                                                         TapGestureRecognizer()
                                                                          ..onTap =
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  GroupDetailWidget(userPostModal.postedGroupId, "", "", "", "")));
                                                                          },
                                                                    text: userPostModal
                                                                        .postedGroupName,
                                                                    style:
                                                                         TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          15.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ))
                                                                : TextSpan(
                                                                    text: "",
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),

                                                            ///////////////////////////////////////////////////////////////
                                                            TextSpan(
                                                                text: ' > ',
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .normal,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR)),
                                                            TextSpan(
                                                              recognizer:
                                                                   TapGestureRecognizer()
                                                                    ..onTap =
                                                                        () {
                                                                      Navigator.of(
                                                                              context)
                                                                          .push(
                                                                               MaterialPageRoute(builder: (BuildContext context) =>  SelectedGroup(userPostModal,userPostModal.groupList)));
                                                                    },
                                                              text: userPostModal
                                                                              .groupList[
                                                                                  0]
                                                                              .groupName ==
                                                                          null ||
                                                                      userPostModal
                                                                              .groupList[
                                                                                  0]
                                                                              .groupName ==
                                                                          "null"
                                                                  ? ""
                                                                  : userPostModal
                                                                      .groupList[
                                                                          0]
                                                                      .groupName,
                                                              style:
                                                                   TextStyle(
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontSize: 14.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                            ),
                                                            userPostModal
                                                                        .groupList
                                                                        .length >
                                                                    1
                                                                ? TextSpan(
                                                                    recognizer:
                                                                         TapGestureRecognizer()
                                                                          ..onTap =
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  SelectedGroup(userPostModal,userPostModal.groupList)));
                                                                          },
                                                                    text:
                                                                        ' and ',
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )
                                                                : TextSpan(
                                                                    text: "",
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                            userPostModal
                                                                        .groupList
                                                                        .length >
                                                                    1
                                                                ? TextSpan(
                                                                    recognizer:
                                                                         TapGestureRecognizer()
                                                                          ..onTap =
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  SelectedGroup(userPostModal,userPostModal.groupList)));
                                                                          },
                                                                    text: (userPostModal.groupList.length -
                                                                            1)
                                                                        .toString(),
                                                                    style:
                                                                         TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ),
                                                                  )
                                                                : TextSpan(
                                                                    text: "",
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                            userPostModal
                                                                        .groupList
                                                                        .length >
                                                                    1
                                                                ? TextSpan(
                                                                    recognizer:
                                                                         TapGestureRecognizer()
                                                                          ..onTap =
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  SelectedGroup(userPostModal,userPostModal.groupList)));
                                                                          },
                                                                    text:
                                                                        " others ",
                                                                    style:
                                                                         TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ),
                                                                  )
                                                                : TextSpan(
                                                                    text: "",
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),

                                                            ///////////////////////////////////////////////////////////////

                                                            TextSpan(
                                                                text: ' with ',
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .normal,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR)),
                                                            TextSpan(
                                                              recognizer:
                                                                   TapGestureRecognizer()
                                                                    ..onTap =
                                                                        () {
                                                                      Navigator.of(
                                                                              context)
                                                                          .push(
                                                                               MaterialPageRoute(builder: (BuildContext context) =>  TagDetailWidget(userPostModal.tagList)));
                                                                    },
                                                              text: userPostModal
                                                                              .tagList[
                                                                                  0]
                                                                              .name ==
                                                                          null ||
                                                                      userPostModal
                                                                              .tagList[
                                                                                  0]
                                                                              .name ==
                                                                          "null"
                                                                  ? ""
                                                                  : userPostModal
                                                                      .tagList[
                                                                          0]
                                                                      .name,
                                                              style:
                                                                   TextStyle(
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontSize: 14.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                            ),
                                                            userPostModal
                                                                        .tagList
                                                                        .length >
                                                                    1
                                                                ? TextSpan(
                                                                    recognizer:
                                                                         TapGestureRecognizer()
                                                                          ..onTap =
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  TagDetailWidget(userPostModal.tagList)));
                                                                          },
                                                                    text:
                                                                        ' and ',
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )
                                                                : TextSpan(
                                                                    text: "",
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                            userPostModal
                                                                        .tagList
                                                                        .length >
                                                                    1
                                                                ? TextSpan(
                                                                    recognizer:
                                                                         TapGestureRecognizer()
                                                                          ..onTap =
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  TagDetailWidget(userPostModal.tagList)));
                                                                          },
                                                                    text: (userPostModal.tagList.length -
                                                                            1)
                                                                        .toString(),
                                                                    style:
                                                                         TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ),
                                                                  )
                                                                : TextSpan(
                                                                    text: "",
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                            userPostModal
                                                                        .tagList
                                                                        .length >
                                                                    1
                                                                ? TextSpan(
                                                                    recognizer:
                                                                         TapGestureRecognizer()
                                                                          ..onTap =
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  TagDetailWidget(userPostModal.tagList)));
                                                                          },
                                                                    text:
                                                                        " others ",
                                                                    style:
                                                                         TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ),
                                                                  )
                                                                : TextSpan(
                                                                    text: "",
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                          ]
                                                        : userPostModal
                                                                    .groupList
                                                                    .length !=
                                                                0
                                                            ? [
                                                                WidgetSpan(
                                                                  child: userPostModal.roleId ==
                                                                          "1"
                                                                      ? Util.getStudentBadgeRichTextWithPadding(
                                                                          userPostModal
                                                                              .badge,
                                                                          userPostModal
                                                                              .badgeImage)
                                                                      : Container(
                                                                          height:
                                                                              0.0,
                                                                          width:
                                                                              0.0,
                                                                        ),
                                                                ),
                                                             /*   userPostModal
                                                                                .postedGroupName !=
                                                                            null &&
                                                                        userPostModal.postedGroupName !=
                                                                            "null" &&
                                                                        userPostModal.postedGroupName !=
                                                                            ""
                                                                    ? TextSpan(
                                                                        text:
                                                                            " > ",
                                                                        style:
                                                                             TextStyle(
                                                                          color:
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              18.0,
                                                                          fontWeight:
                                                                              FontWeight.normal,
                                                                        ))
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                userPostModal.postedGroupName != null &&
                                                                        userPostModal.postedGroupName !=
                                                                            "null" &&
                                                                        userPostModal.postedGroupName !=
                                                                            ""
                                                                    ? TextSpan(
                                                                        recognizer:
                                                                             TapGestureRecognizer()
                                                                              ..onTap =
                                                                                  () {
                                                                                Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  GroupDetailWidget(userPostModal.postedGroupId, "", "", "", "")));
                                                                              },
                                                                        text: userPostModal
                                                                            .postedGroupName+"sk",
                                                                        style:
                                                                             TextStyle(
                                                                          color:
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              15.0,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ))
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),*/
                                                                TextSpan(
                                                                    text: ' > ',
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR)),
                                                                TextSpan(
                                                                  text: userPostModal.groupList[0].groupName ==
                                                                              null ||
                                                                          userPostModal.groupList[0].groupName ==
                                                                              "null"
                                                                      ? ""
                                                                      : userPostModal
                                                                          .groupList[
                                                                              0]
                                                                          .groupName,
                                                                  style:
                                                                       TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                                ),
                                                                userPostModal
                                                                            .groupList
                                                                            .length >
                                                                        1
                                                                    ? TextSpan(
                                                                        text:
                                                                            ' and ',
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      )
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                userPostModal
                                                                            .groupList
                                                                            .length >
                                                                        1
                                                                    ? TextSpan(
                                                                        text: (userPostModal.groupList.length -
                                                                                1)
                                                                            .toString(),
                                                                        style:
                                                                             TextStyle(
                                                                          color:
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              14.0,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ),
                                                                      )
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                userPostModal
                                                                            .groupList
                                                                            .length >
                                                                        1
                                                                    ? TextSpan(
                                                                        text:
                                                                            " others ",
                                                                        style:
                                                                             TextStyle(
                                                                          color:
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              14.0,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ),
                                                                      )
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                              ]
                                                            : [
                                                                WidgetSpan(
                                                                  child: userPostModal.roleId ==
                                                                          "1"
                                                                      ? Util.getStudentBadgeRichTextWithPadding(
                                                                          userPostModal
                                                                              .badge,
                                                                          userPostModal
                                                                              .badgeImage)
                                                                      : Container(
                                                                          height:
                                                                              0.0,
                                                                          width:
                                                                              0.0,
                                                                        ),
                                                                ),
                                                                userPostModal
                                                                                .postedGroupName !=
                                                                            null &&
                                                                        userPostModal.postedGroupName !=
                                                                            "null" &&
                                                                        userPostModal.postedGroupName !=
                                                                            ""
                                                                    ? TextSpan(
                                                                        text:
                                                                            " > ",
                                                                        style:
                                                                             TextStyle(
                                                                          color:
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              18.0,
                                                                          fontWeight:
                                                                              FontWeight.normal,
                                                                        ))
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                userPostModal.postedGroupName != null &&
                                                                        userPostModal.postedGroupName !=
                                                                            "null" &&
                                                                        userPostModal.postedGroupName !=
                                                                            ""
                                                                    ? TextSpan(
                                                                        recognizer:
                                                                             TapGestureRecognizer()
                                                                              ..onTap =
                                                                                  () {
                                                                                Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  GroupDetailWidget(userPostModal.postedGroupId, "", "", "", "")));
                                                                              },
                                                                        text: userPostModal
                                                                            .postedGroupName,
                                                                        style:
                                                                             TextStyle(
                                                                          color:
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              15.0,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ))
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                TextSpan(
                                                                    text:
                                                                        ' with ',
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .normal,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR)),
                                                                TextSpan(
                                                                  text: userPostModal.tagList[0].name ==
                                                                              null ||
                                                                          userPostModal.tagList[0].name ==
                                                                              "null"
                                                                      ? ""
                                                                      : userPostModal
                                                                          .tagList[
                                                                              0]
                                                                          .name,
                                                                  style:
                                                                       TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                                ),
                                                                userPostModal
                                                                            .tagList
                                                                            .length >
                                                                        1
                                                                    ? TextSpan(
                                                                        text:
                                                                            ' and ',
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      )
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                userPostModal
                                                                            .tagList
                                                                            .length >
                                                                        1
                                                                    ? TextSpan(
                                                                        text: (userPostModal.tagList.length -
                                                                                1)
                                                                            .toString(),
                                                                        style:
                                                                             TextStyle(
                                                                          color:
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              14.0,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ),
                                                                      )
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                userPostModal
                                                                            .tagList
                                                                            .length >
                                                                        1
                                                                    ? TextSpan(
                                                                        text:
                                                                            " others ",
                                                                        style:
                                                                             TextStyle(
                                                                          color:
                                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              14.0,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ),
                                                                      )
                                                                    : TextSpan(
                                                                        text:
                                                                            "",
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                              ],
                                              ),
                                            )),
                                            onTap: () {
                                              if (userPostModal.tagList.length >
                                                      0 &&
                                                  userPostModal
                                                          .groupList.length >
                                                      0) {
                                              } else if (userPostModal
                                                      .groupList.length >
                                                  0) {
                                                Navigator.of(context).push(
                                                     MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                             SelectedGroup(
                                                                 userPostModal, userPostModal
                                                                    .groupList)));
                                              } else if (userPostModal
                                                      .tagList.length >
                                                  0) {
                                                Navigator.of(context).push(
                                                     MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                             TagDetailWidget(
                                                                userPostModal
                                                                    .tagList)));
                                              } else {
                                                onTapImageTile(
                                                    userPostModal.postedBy,
                                                    userPostModal.roleId);
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ),
                                    /*    TextViewWrap.textView(
                                        userPostModal.dateTime,
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        12.0,
                                        FontWeight.normal),*/

                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0.0, 5, 0, 0),
                                      child:  Row(
                                        children: [
                                          TextViewWrap.textView(
                                              userPostModal.dateTime,
                                              TextAlign.center,
                                              ColorValues.GREY_TEXT_COLOR,
                                              12.0,
                                              FontWeight.normal),
                                          userPostModal.visibility == ""
                                              ?  Container(
                                                  height: 0.0,
                                                )
                                              : userIdPref == userPostModal.postedBy &&
                                              roleId == userPostModal.roleId.toString()
                                              ?PaddingWrap.paddingfromLTRB(
                                                  10.0,
                                                  0.0,
                                                  5.0,
                                                  0.0,
                                                   Image.asset(
                                                    userPostModal.visibility ==
                                                            "Private"
                                                        ? "assets/profile/post/private_new.png"
                                                        : userPostModal
                                                                    .visibility ==
                                                                "SelectedConnections"
                                                            ? "assets/profile/post/selected_connection.png"
                                                            : userPostModal
                                                                        .visibility ==
                                                                    "AllConnections"
                                                                ? "assets/profile/post/connection.png"
                                                                : userPostModal
                                                                            .visibility ==
                                                                        "Group"
                                                                    ? "assets/profile/post/group_data.png"
                                                                    : "assets/profile/post/community.png",
                                                    width: 13.0,
                                                    color: userPostModal
                                                                .visibility ==
                                                            "SelectedConnections"
                                                        ? null
                                                        : ColorValues.GREY_TEXT_COLOR,
                                                    height: 14.0,
                                                  )):new Container(
                                            height: 0.0,
                                          ),
                                        /*  userPostModal.visibility == ""
                                              ?  Container(
                                                  height: 0.0,
                                                )
                                              : PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap.textView(
                                                      userPostModal.visibility ==
                                                              "Private"
                                                          ? "Private"
                                                          : userPostModal
                                                                      .visibility ==
                                                                  "SelectedConnections"
                                                              ? "Selected Connections"
                                                              : userPostModal
                                                                          .visibility ==
                                                                      "AllConnections"
                                                                  ? "Connections"
                                                                  : userPostModal
                                                                              .visibility ==
                                                                          "Group"
                                                                      ? "Group"
                                                                      : "Community",
                                                      TextAlign.center,
                                                      ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal))*/
                                        ],
                                      ),
                                    )
                                  ],
                                )),
                            flex: 4,
                          ),
                           Expanded(
                            child: userIdPref == userPostModal.postedBy &&
                                    roleId == userPostModal.roleId.toString()
                                ?  Container(
                                    padding:  EdgeInsets.fromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        userPostModal.tagList.length > 0
                                            ? 38.0
                                            : 15.0),
                                    child:  InkWell(
                                      child:  Image.asset(
                                        "assets/profile/post/user_more1.png",
                                        width: 25.0,
                                        height: 25.0,
                                      ),
                                      onTap: () {
                                        /*   if (userPostModal.visibility ==
                                                "Community" ||
                                            userPostModal.visibility ==
                                                "Group") {
                                          optionMenuDelete(
                                              userPostModal, index);
                                        } else {*/
                                        optionMenu(userPostModal, index);
                                        // }
                                      },
                                    ))
                                :  Container(
                                    padding:  EdgeInsets.fromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        userPostModal.tagList.length > 0
                                            ? 38.0
                                            : 15.0),
                                    child:  InkWell(
                                      child:  Image.asset(
                                        "assets/profile/post/user_more1.png",
                                        width: 25.0,
                                        height: 25.0,
                                      ),
                                      onTap: () {
                                        optionForReport(userPostModal, index);
                                      },
                                    )),
                            flex: 0,
                          )
                        ],
                      )),

                  userPostModal.postdata == null ||
                          userPostModal.postdata.text == null ||
                          userPostModal.postdata.text == "null"
                      ?  Container(
                          height: 0.0,
                        )
                      : PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          10.0,
                          0.0,
                           Container(
                              color: Colors.transparent,
                              child:  Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    userPostModal.postdata.text == "" ||
                                            userPostModal.postdata.text ==
                                                "null" ||
                                            userPostModal.postdata.text == "\n"
                                        ?  Container(
                                            height: 1.0,
                                          )
                                        : userPostModal.postdata.imageList.length ==
                                                    0 &&
                                                (userPostModal.postdata.media ==
                                                        null ||
                                                    userPostModal
                                                            .postdata.media ==
                                                        "" ||
                                                    userPostModal
                                                            .postdata.media ==
                                                        "null") &&
                                                (userPostModal
                                                            .postdata.metaUrl !=
                                                        "" &&
                                                    userPostModal.postdata
                                                            .metaImage !=
                                                        "")
                                            ? exp
                                                            .allMatches(
                                                                userPostModal
                                                                    .postdata
                                                                    .text)
                                                            .length ==
                                                        1 &&
                                                    userPostModal.postdata.text
                                                            .toString()
                                                            .replaceAll(exp, '')
                                                            .length ==
                                                        0
                                                ?  Container(
                                                    height: 0.0,
                                                  )
                                                : PaddingWrap.paddingfromLTRB(
                                                    4.0,
                                                    10.0,
                                                    13.0,
                                                    0.0,
                                                     Container(
                                                      child: Linkify(
                                                        onOpen: (link) async {
                                                          print("onclick +++" +
                                                              link.url
                                                                  .toLowerCase());
                                                          apiCallingForIncreaseCount(
                                                              userPostModal
                                                                  .feedId);

                                                          Navigator.push(
                                                              context,
                                                               MaterialPageRoute(
                                                                  //   builder: (context) =>  DashBoardWidget()));
                                                                  builder: (context) =>
                                                                       WebViewWidget(
                                                                          link.url,
                                                                          "spikeview")));
                                                        },
                                                        text: exp
                                                                    .allMatches(
                                                                        userPostModal
                                                                            .postdata
                                                                            .text)
                                                                    .length >
                                                                1
                                                            ? userPostModal
                                                                .postdata.text
                                                            : userPostModal
                                                                .postdata.text
                                                                .toString()
                                                                .replaceAll(
                                                                    exp, ''),
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR,
                                                            fontSize: 14.0),
                                                        linkStyle:  TextStyle(
                                                            color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR,
                                                            fontSize: 14.0),
                                                      ),
                                                    ))
                                            :  Container(
                                                child: Linkify(
                                                  onOpen: (link) async {
                                                    print("onclick +++" +
                                                        link.url.toLowerCase());
                                                    apiCallingForIncreaseCount(
                                                        userPostModal.feedId);
                                                    Navigator.push(
                                                        context,
                                                         MaterialPageRoute(
                                                            //   builder: (context) =>  DashBoardWidget()));
                                                            builder: (context) =>
                                                                 WebViewWidget(
                                                                    link.url,
                                                                    "spikeview")));
                                                  },
                                                  text: userPostModal
                                                      .postdata.text,
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                  linkStyle:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                ),
                                              ),
                                  ),
                                ],
                              ))),

                  userPostModal.postdata.imageList.length == 0
                      ?  Container(
                          height: 0.0,
                        )
                      : PaddingWrap.paddingfromLTRB(
                          0.0,
                          10.0,
                          0.0,
                          0.0,
                           Container(
                              height: 215.50,
                              child:  SizedBox(
                                  // Pager view
                                  height: 215.50,
                                  child: PageIndicatorContainer(
                                    pageView:  PageView.builder(
                                      itemCount: userPostModal
                                          .postdata.imageList.length,
                                      controller:  PageController(),
                                      itemBuilder: (context, index2) {
                                        return  InkWell(
                                          child:  Stack(children: <Widget>[
                                             Container(
                                                decoration: BoxDecoration(
                                                  color: Colors.black,
                                                ),
                                                height: 215.50,
                                                child:  CachedNetworkImage(
                                                  width: double.infinity,
                                                  height: 215.50,
                                                  imageUrl: Constant
                                                          .IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          userPostModal.postdata
                                                                  .imageList[
                                                              index2]),
                                                  fit: BoxFit.contain,
                                                  placeholder: (context, url) =>
                                                      _loader(context),
                                                  errorWidget:
                                                      (context, url, error) =>
                                                          _error(),
                                                )),
                                            userPostModal.postdata.imageList
                                                        .length ==
                                                    1
                                                ?  InkWell(
                                                    onTap: () {
                                                      Navigator.of(context).push(new MaterialPageRoute(
                                                          builder: (BuildContext
                                                                  context) =>
                                                               CommonFullViewWidget(
                                                                  userPostModal
                                                                      .postdata
                                                                      .imageList,
                                                                  MessageConstant
                                                                      .HOME_FEED,
                                                                  index2,
                                                                  MessageConstant
                                                                      .COMPANY_PROFILE_HEDING)));
                                                    },
                                                    child:  Container(
                                                      height: 0.0,
                                                    ))
                                                :  InkWell(
                                                    onTap: () {
                                                      print("imageDtat++++++++" +
                                                          userPostModal.postdata
                                                                  .imageList[
                                                              index2]);

                                                      Navigator.of(context).push(new MaterialPageRoute(
                                                          builder: (BuildContext
                                                                  context) =>
                                                               CommonFullViewWidget(
                                                                  userPostModal
                                                                      .postdata
                                                                      .imageList,
                                                                  MessageConstant
                                                                      .HOME_FEED,
                                                                  index2,
                                                                  MessageConstant
                                                                      .COMPANY_PROFILE_HEDING)));
                                                    },
                                                    child:  Container(
                                                      height: 215.50,
                                                      width: double.infinity,
                                                      child:  Image.asset(
                                                        "assets/newDesignIcon/navigation/layer_image.png",
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ))
                                          ]),
                                          onTap: () {
                                            Navigator.of(context).push(
                                                 MaterialPageRoute(
                                                    builder: (BuildContext
                                                            context) =>
                                                         CommonFullViewWidget(
                                                            userPostModal
                                                                .postdata
                                                                .imageList,
                                                            MessageConstant
                                                                .HOME_FEED,
                                                            index2,
                                                            MessageConstant
                                                                .COMPANY_PROFILE_HEDING)));
                                          },
                                        );
                                      },
                                      onPageChanged: (index) {},
                                    ),
                                    align: IndicatorAlign.bottom,
                                    length:
                                        userPostModal.postdata.imageList.length,
                                    indicatorSpace: 10.0,
                                    indicatorColor: userPostModal
                                                .postdata.imageList.length ==
                                            1
                                        ? Colors.transparent
                                        :  Color(0xffc4c4c4),
                                    indicatorSelectorColor: userPostModal
                                                .postdata.imageList.length ==
                                            1
                                        ? Colors.transparent
                                        :  ColorValues.WHITE,
                                    shape: IndicatorShape.circle(size: 5.0),
                                  )))),

                  userPostModal.postdata.imageList.length > 0 ||
                          userPostModal.postdata.media == null ||
                          userPostModal.postdata.media == "" ||
                          userPostModal.postdata.media == "null"
                      ?  Container(
                          height: 0.0,
                        )
                      : PaddingWrap.paddingfromLTRB(
                          0.0,
                          10.0,
                          0.0,
                          0.0,
                           InkWell(
                            child:  Container(
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(0),
                              ),
                              height: 215.50,
                              width: double.infinity,
                              child:  Center(
                                  child:  Center(
                                child:  Center(
                                  child:  VideoPlayPauseDialogOffline(
                                      userPostModal.postdata.media,
                                      userPostModal.feedId,
                                      true),
                                  /*new Container(
                                      child:  Stack(
                                        children: <Widget>[

                                          Container(
                                            height: 215.0,
                                            color: Colors.black,
                                            margin: EdgeInsets.only(left: 0, right: 0),
                                            child:  VideoViewBlack(
                                                Constant.IMAGE_PATH + userPostModal.postdata.media, "", false, ""),
                                          ),
                                          */ /*new Container(
                                                                                      height: 54.0,
                                                                                      width: 80.0,
                                                                                      color:  Color(0XFFC0C0C0).withOpacity(.4),
                                                                                    ),*/ /*
                                           Center(
                                              child:  Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: <Widget>[
                                                   InkWell(
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                         Image.asset(
                                                          //'assets/pre_login/video_play_button.png',
                                                          'assets/newDesignIcon/circle_play.png',
                                                          width: 50.0,
                                                          height: 50.0,
                                                        )),
                                                  )
                                                ],
                                              )),
                                        ],
                                      )),*/
                                ),
                              ) /* Chewie(
                                controller: ChewieController(
                                  videoPlayerController:
                                      VideoPlayerController.network(
                                          Constant.IMAGE_PATH +
                                              userPostModal.postdata.media),
                                  aspectRatio: 3 / 2,
                                  autoPlay: false,
                                  looping: false,
                                ),
                              )*/
                                  )
                              /*ChewieListItem(
                              videoPlayerController: VideoPlayerController.network(
                                'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                              ),
                            )*/
                              ,
                            ),
                            onTap: () {
                              print('ontap video feed::: ');
                              apiCallingForIncreaseCount(userPostModal.feedId);
                              /*Navigator.of(context).push(new MaterialPageRoute(
                                  builder: (BuildContext
                                  context) =>
                                   VideoFullViewWidget(
                                      '',
                                      MessageConstant
                                          .VIEWER_END_REWCOMMENDATION_HEDING,
                                      Constant.IMAGE_PATH + userPostModal.postdata.media
                                  )));*/
                            },
                          )),

                  userPostModal.postdata.imageList.length == 0 &&
                          (userPostModal.postdata.media == null ||
                              userPostModal.postdata.media == "" ||
                              userPostModal.postdata.media == "null")
                      ? userPostModal.postdata == null ||
                              userPostModal.postdata.text == null ||
                              userPostModal.postdata.text == "null"
                          ?  Container(
                              height: 0.0,
                            )
                          : userPostModal.postdata.metaUrl != ""
                              ? Container(
                                  margin: EdgeInsets.symmetric(vertical: 4.0),
//                                  child: userPostModal.webLinkModel.imageUrl ==
//                                          ""
//                                      ?new WhatsAppLinkPreview().build(
//                                          getLinkUrl(
//                                              userPostModal.postdata.text),
//                                          userPostModal)
//                                      :

                                  child:  WhatsAppView(
                                    imageUrl: userPostModal.postdata.metaImage,
                                    feedId: userPostModal.feedId,
                                    title: userPostModal.postdata.metaTitle,
                                    url: userPostModal.postdata.metaUrl,
                                    metaSource:
                                        userPostModal.postdata.metaSource,
                                    metaHeight:
                                        userPostModal.postdata.metaHeight,
                                    metaWidth: userPostModal.postdata.metaWidth,
                                    description:
                                        userPostModal.postdata.metaDescription,
                                  ))
                              :  Container(
                                  height: 0.0,
                                )
                      :  Container(
                          height: 0.0,
                        ),

                  Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                    child:  Row(
                      children: <Widget>[
                         Expanded(
                          child: userPostModal.likeList.length > 0
                              ? PaddingWrap.paddingfromLTRB(
                                  10.0,
                                  0.0,
                                  10.0,
                                  0.0,
                                  InkWell(
                                    child: TextViewWrap.textView(
                                        userPostModal.likeList.length == 0
                                            ? "Like"
                                            : userPostModal.likeList.length == 1
                                                ? "1 Like"
                                                : userPostModal.likeList.length
                                                        .toString() +
                                                    " Likes",
                                        TextAlign.end,
                                        ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal),
                                    onTap: () {
                                      onTapLikeText(userPostModal);
                                    },
                                  ))
                              :  Container(
                                  height: 0.0,
                                ),
                          flex: 0,
                        ),
                        /*Padding(
                          padding: const EdgeInsets.only(bottom: 6.0),
                          child:  Text(
                            ".",
                            style: TextStyle(
                                fontSize: 16.0,
                                color: ColorValues.GREY_TEXT_COLOR),
                          ),
                        ),*/
                        userPostModal.commentList.length == 0
                            ?  Container(
                                height: 0.0,
                              )
                            :  InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                  10.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  TextViewWrap.textView(
                                      userPostModal.commentList.length == 0
                                          ? "Comment"
                                          : "" +
                                              userPostModal.commentList.length
                                                  .toString() +
                                              " Comments",
                                      TextAlign.left,
                                      ColorValues.GREY_TEXT_COLOR,
                                      14.0,
                                      FontWeight.normal),
                                ),
                                onTap: () {
                                  onTapViewAllComments(
                                      userPostModal.commentList,
                                      userPostModal.feedId,
                                      userPostModal);
                                },
                              )
                      ],
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Divider(
                        height: 1.0, color: ColorValues.DARK_GREY),
                  ),

                  PaddingWrap.paddingfromLTRB(
                      4.0,
                      5.0,
                      0.0,
                      0.0,
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  Row(
                              children: <Widget>[
                                userPostModal.isLike
                                    ? PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        10.0,
                                        0.0,
                                         InkWell(
                                          child:  Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingAll(
                                                  10.0,
                                                   Image.asset(
                                                    "assets/newDesignIcon/feed/like_green.png",
                                                    height: 24.0,
                                                    width: 25.0,
                                                  )),
                                              getText(
                                                  "Like",
                                                  ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR)
                                            ],
                                          ),
                                          onTap: () {
                                            onTapLike(userPostModal);
                                          },
                                        ))
                                    : PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                         InkWell(
                                          child:  Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingAll(
                                                  10.0,
                                                   Image.asset(
                                                    "assets/newDesignIcon/feed/like.png",
                                                    height: 24.0,
                                                    width: 25.0,
                                                  )),
                                              getText("Like",
                                                  ColorValues.GREY_TEXT_COLOR)
                                            ],
                                          ),
                                          onTap: () {
                                            onTapLike(userPostModal);
                                          },
                                        )),
                                /* Spacer(),
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 5.0),
                                  child:  Text(
                                    ".",
                                    style: TextStyle(
                                        fontSize: 16.0,
                                        color:
                                            ColorValues.GREY_TEXT_COLOR),
                                  ),
                                ),*/
                                Spacer(),
                                PaddingWrap.paddingfromLTRB(
                                    5.0,
                                    0.0,
                                    10.0,
                                    0.0,
                                     InkWell(
                                      child:  Row(
                                        children: <Widget>[
                                          PaddingWrap.paddingAll(
                                              0.0,
                                               Image.asset(
                                                "assets/newDesignIcon/feed/msg.png",
                                                height: 25.0,
                                                width: 25.0,
                                              )),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 12.0),
                                            child: getText("Comment",
                                                ColorValues.GREY_TEXT_COLOR),
                                          )
                                        ],
                                      ),
                                      onTap: () {
                                        if (userPostModal.isShowCommentIcon)
                                          userPostModal.isShowCommentIcon =
                                              false;
                                        else {
                                          _scrollController.jumpTo(
                                              (_scrollController.offset +
                                                  80.0));
                                          userPostModal.isShowCommentIcon =
                                              true;
                                        }

                                        setState(() {
                                          userPostModal.isShowCommentIcon;
                                        });
                                      },
                                    )),
                                /*   Spacer(),
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 5.0),
                                  child:  Text(
                                    ".",
                                    style: TextStyle(
                                        fontSize: 16.0,
                                        color:
                                            ColorValues.GREY_TEXT_COLOR),
                                  ),
                                ),*/
                                Spacer(),
                                 InkWell(
                                    child:  Row(
                                      children: <Widget>[
                                        shareView(userPostModal),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 2.0, right: 10.0),
                                          child: getText("Share",
                                              ColorValues.GREY_TEXT_COLOR),
                                        )
                                      ],
                                    ),
                                    onTap: () {
                                      onTapShare(userPostModal);
                                    })
                              ],
                            ),
                            flex: 1,
                          ),
                        ],
                      )),

                  PaddingWrap.paddingAll(
                      0.0,
                       Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          // Comment List view
                           Padding(
                              padding:
                                   EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                              child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:  List.generate(
                                      userPostModal.commentList.length > 3
                                          ? 3
                                          : userPostModal.commentList.length,
                                      (int index) {
                                    return PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        5.0,
                                        10.0,
                                        0.0,
                                         Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: <Widget>[
                                             InkWell(
                                                child:  Container(
                                                    width: 40.0,
                                                    height: 40.0,
                                                    child: ClipOval(
                                                        child: FadeInImage
                                                            .assetNetwork(
                                                      fit: BoxFit.cover,
                                                      width: double.infinity,
                                                      placeholder: userPostModal
                                                                  .commentList[
                                                                      index]
                                                                  .roleId ==
                                                              "4"
                                                          ? "assets/profile/partner_img.png"
                                                          : 'assets/profile/user_on_user.png',
                                                      image: Constant
                                                              .IMAGE_PATH_SMALL +
                                                          userPostModal
                                                              .commentList[
                                                                  index]
                                                              .profilePicture,
                                                    ))),
                                                onTap: () {
                                                  print(
                                                      "OnClick comment++++++++++++");
                                                  print(
                                                      "OnClick comment++++++++++++" +
                                                          userPostModal
                                                              .commentList[
                                                                  index]
                                                              .toString());
                                                  onTapImageTile(
                                                      userPostModal
                                                          .commentList[index]
                                                          .commentedBy,
                                                      userPostModal
                                                          .commentList[index]
                                                          .roleId);
                                                }), // User Image
                                             SizedBox(
                                              width: 20.0,
                                            ),
                                             Expanded(
                                              child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(0, 0, 0, 0),
                                                    child:  Container(
                                                        child: Row(
                                                      children: <Widget>[
                                                        RichText(
                                                          maxLines: 2,
                                                          textAlign:
                                                              TextAlign.start,
                                                          text: TextSpan(
                                                            text: userPostModal
                                                                .commentList[
                                                                    index]
                                                                .name,
                                                            style:
                                                                 TextStyle(
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            ),
                                                            /* children: <TextSpan>[
                                                              TextSpan(
                                                                  text: userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .comment,
                                                                  style:  TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                            ],*/
                                                          ),
                                                        ),
                                                        userPostModal.commentList[
                                                                        index] !=
                                                                    null &&
                                                                userPostModal
                                                                        .commentList[
                                                                            index]
                                                                        .roleId ==
                                                                    "1"
                                                            //true
                                                            ? Util.getStudentBadge12(
                                                                userPostModal
                                                                    .commentList[
                                                                        index]
                                                                    .badge,
                                                                userPostModal
                                                                    .commentList[
                                                                        index]
                                                                    .badgeImage)
                                                            : Container(
                                                                height: 0.0,
                                                                width: 0.0,
                                                              ),
                                                      ],
                                                    )),
                                                  ),
                                                   Container(
                                                    child: Linkify(
                                                      onOpen: (link) async {
                                                        print("onclick +++");

                                                        Navigator.push(
                                                            context,
                                                             MaterialPageRoute(
                                                                //   builder: (context) =>  DashBoardWidget()));
                                                                builder: (context) =>
                                                                     WebViewWidget(
                                                                        link.url,
                                                                        "spikeview")));
                                                      },
                                                      text: userPostModal
                                                          .commentList[index]
                                                          .comment,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                      linkStyle:  TextStyle(
                                                          color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR,
                                                          fontSize: 14.0),
                                                    ),
                                                  ),
                                                   Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              0.0,
                                                              5.0,
                                                              0.0,
                                                              0.0),
                                                      child:  Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child:  Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                 Text(
                                                                  userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .dateTime,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .end,
                                                                  style: TextStyle(
                                                                      color:  ColorValues.GREY_TEXT_COLOR,
                                                                      fontSize:
                                                                          12.0,
                                                                      fontFamily:
                                                                          Constant
                                                                              .customRegular),
                                                                )
                                                              ],
                                                            ),
                                                            flex: 0,
                                                          ),
                                                           Container(
                                                            width: 10.0,
                                                          ),
                                                           Expanded(
                                                            child: userIdPref ==
                                                                    userPostModal
                                                                        .commentList[
                                                                            index]
                                                                        .commentedBy
                                                                ?  InkWell(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          const EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              0,
                                                                              0,
                                                                              0),
                                                                      child:  Image
                                                                          .asset(
                                                                        "assets/profile/post/user_more1.png",
                                                                        width:
                                                                            25.0,
                                                                        height:
                                                                            25.0,
                                                                      ),
                                                                    ),
                                                                    onTap: () {
                                                                      optionForDelete(
                                                                          userPostModal
                                                                              .commentList,
                                                                          userPostModal
                                                                              .feedId,
                                                                          userPostModal,
                                                                          userPostModal
                                                                              .commentList[index]
                                                                              .commentId);
                                                                    },
                                                                  )
                                                                :  Container(
                                                                    height: 1.0,
                                                                  ),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      )),
                                                ],
                                              ),
                                              flex: 1,
                                            ) // Comment List Cell
                                          ],
                                        ));
                                  }))),

                          // View All Comments
                          userPostModal.commentList.length > 3
                              ?  InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    0.0,
                                    5.0,
                                    TextViewWrap.textView(
                                        "View All " +
                                            userPostModal.commentList.length
                                                .toString() +
                                            " Comments",
                                        TextAlign.left,
                                        ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        12.0,
                                        FontWeight.normal),
                                  ),
                                  onTap: () {
                                    onTapViewAllComments(
                                        userPostModal.commentList,
                                        userPostModal.feedId,
                                        userPostModal);
                                  },
                                )
                              :  Container(
                                  height: 0.0,
                                ),

                          // Comment Edit Text
                          userPostModal.isShowCommentIcon
                              ? PaddingWrap.paddingAll(
                                  10.0,
                                   Row(
                                    children: <Widget>[
                                      //Alok Code Done
                                       Container(
                                        width: 40.0,
                                        height: 40.0,
                                        child: ClipOval(
                                          child: FadeInImage.assetNetwork(
                                            fit: BoxFit.cover,
                                            placeholder: roleId == "4"
                                                ? "assets/profile/partner_img.png"
                                                : 'assets/profile/user_on_user.png',
                                            image: roleId == "4"
                                                ? Constant.IMAGE_PATH +
                                                    companyPath
                                                : Constant.IMAGE_PATH +
                                                    profilePath,
                                            height: 45.0,
                                            width: 45.0,
                                          ),
                                        ),
                                      ),
                                       SizedBox(
                                        width: 20.0,
                                      ),
                                       Expanded(
                                          child:  Container(
                                              decoration:  BoxDecoration(
                                                  border:  Border.all(
                                                      width: 1.0,
                                                      color:   ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                              child:  Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Expanded(
                                                    child:  TextField(
                                                      controller: userPostModal
                                                          .txtController,
                                                      style:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),   keyboardType:
                                                          TextInputType.text,
                                                      textCapitalization:
                                                          TextCapitalization
                                                              .sentences,
                                                      maxLines: null,
                                                      maxLength: TextLength
                                                          .COMMENT_MAX_LENGTH,
                                                      onChanged: (s) {
                                                        if (s.trim().length >
                                                            0) {
                                                          userPostModal
                                                                  .isCommentIconVisible =
                                                              true;
                                                        } else {
                                                          userPostModal
                                                                  .isCommentIconVisible =
                                                              false;
                                                        }
                                                        setState(() {
                                                          userPostModal
                                                              .isCommentIconVisible;
                                                        });
                                                      },
                                                      decoration:
                                                           InputDecoration(
                                                        border:
                                                            InputBorder.none,
                                                        filled: true,
                                                        counterText: "",
                                                            counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),         hintText: roleId == "4"
                                                            ? "Add Comment as " +
                                                                prefs.getString(
                                                                    UserPreference
                                                                        .COMPANY_NAME_PATH)
                                                            : profileInfoModal
                                                                            .lastName ==
                                                                        "" ||
                                                                    profileInfoModal
                                                                            .lastName ==
                                                                        "null"
                                                                ? "Add Comment as " +
                                                                    profileInfoModal
                                                                        .firstName
                                                                : "Add Comment as " +
                                                                    profileInfoModal
                                                                        .firstName +
                                                                    " " +
                                                                    profileInfoModal
                                                                        .lastName,
                                                        hintStyle:  TextStyle(
                                                            color:  ColorValues.hintColor,
                                                            fontSize: 14.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                        fillColor:
                                                            Colors.transparent,
                                                      ),
                                                    ),
                                                    flex: 4,
                                                  ),
                                                   Expanded(
                                                    child:
                                                        /*userPostModal
                                                    .isCommentIconVisible
                                                ?*/
                                                         InkWell(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                              0.0,
                                                              0.0,
                                                              5.0,
                                                              0.0,
                                                               Image.asset(
                                                                "assets/newDesignIcon/feed/send.png",
                                                                width: 22.0,
                                                                height: 22.0,
                                                              )),
                                                      onTap: () {
                                                        if (userPostModal
                                                            .isCommentIconVisible) {
                                                          FocusScope.of(context)
                                                              .requestFocus(
                                                                   FocusNode());
                                                          userPostModal
                                                                  .isCommentIconVisible =
                                                              false;
                                                          onAddComment(
                                                              userPostModal
                                                                  .feedId,
                                                              userPostModal
                                                                  .txtController
                                                                  .text,
                                                              userPostModal);
                                                          userPostModal
                                                              .txtController
                                                              .text = "";
                                                          setState(() {
                                                            userPostModal
                                                                .txtController;
                                                            userPostModal
                                                                .isCommentIconVisible;
                                                          });
                                                        }
                                                      },
                                                    )
                                                    /*:  Container(
                                                    height: 0.0,
                                                  )*/
                                                    ,
                                                    flex: 0,
                                                  )
                                                ],
                                              )),
                                          flex: 1)
                                    ],
                                  ))
                              :  Container(
                                  height: 0.0,
                                ),

                          (userPostList.length - 1) == index
                              ?  Container(
                                  height: 10.0,
                                )
                              : PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  10.0,
                                   Divider(
                                    color: ColorValues.GREY_TEXT_COLOR,
                                    height: 1.0,
                                  ))
                        ],
                      ))
                ],
              )));
    }

    Padding getListViewPost(userPostModal, index) {
      print('Mona 444 getListViewForOpportunity() 444');
      return PaddingWrap.paddingAll(
          0.0,
           Card(
              elevation: 0.0,
              color:  ColorValues.GRAY_BG,
              child:  Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    // getEvent(userPostModal),
                    PaddingWrap.paddingfromLTRB(
                        11.0,
                        10.0,
                        11.0,
                        10.0,
                         Row(
                          children: <Widget>[
                             Expanded(
                              child:  InkWell(
                                child:  Center(
                                    child:  Container(
                                        width: 50.0,
                                        height: 50.0,
                                        child: ClipOval(
                                            child: FadeInImage.assetNetwork(
                                          fit: BoxFit.cover,
                                          width: double.infinity,
                                          placeholder: userPostModal.roleId ==
                                                  "4"
                                              ? "assets/profile/partner_img.png"
                                              : 'assets/profile/user_on_user.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getSmallImage(
                                                  userPostModal.profilePicture),
                                        )))),
                                onTap: () {
                                  onTapImageTile(userPostModal.postedBy,
                                      userPostModal.roleId);
                                },
                              ),
                              flex: 0,
                            ),
                             Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  8.0,
                                  0.0,
                                  15.0,
                                  0.0,
                                   Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                       InkWell(
                                        child:  Container(
                                            child: RichText(
                                          maxLines: 2,
                                          textAlign: TextAlign.start,
                                          text: TextSpan(
                                            text: userPostModal.lastName ==
                                                        null ||
                                                    userPostModal.lastName ==
                                                        "null"
                                                ? userPostModal.firstName
                                                : userPostModal.firstName +
                                                    " " +
                                                    userPostModal.lastName,
                                            style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            children: [
                                              WidgetSpan(
                                                child: userPostModal.roleId ==
                                                        "1"
                                                    ? Util
                                                        .getStudentBadgeRichTextWithPadding(
                                                            userPostModal.badge,
                                                            userPostModal
                                                                .badgeImage)
                                                    : Container(
                                                        height: 0.0,
                                                        width: 0.0,
                                                      ),
                                              ),
                                              TextSpan(
                                                  text: ' shared ',
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 14.0,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR)),
                                              TextSpan(
                                                text: userPostModal.postedGroupName !=
                                                            null &&
                                                        userPostModal
                                                                .postedGroupName !=
                                                            "null" &&
                                                        userPostModal
                                                                .postedGroupName !=
                                                            ""
                                                    ? userPostModal
                                                        .postedGroupName
                                                    : userPostModal
                                                                .postOwnerLastName ==
                                                            ""
                                                        ? userPostModal
                                                                .postOwnerFirstName
                                                                .trim() +
                                                            "'s"
                                                        : userPostModal
                                                                .postOwnerFirstName +
                                                            " " +
                                                            userPostModal
                                                                .postOwnerLastName
                                                                .toString()
                                                                .trim() +
                                                            "'s",
                                                recognizer:
                                                     TapGestureRecognizer()
                                                      ..onTap = () {
                                                        if (userPostModal
                                                                    .postedGroupName ==
                                                                null ||
                                                            userPostModal
                                                                    .postedGroupName !=
                                                                "null" ||
                                                            userPostModal
                                                                    .postedGroupName !=
                                                                "") {
                                                          Navigator.of(context).push(new MaterialPageRoute(
                                                              builder: (BuildContext
                                                                      context) =>
                                                                   GroupDetailWidget(
                                                                      userPostModal
                                                                          .postedGroupId,
                                                                      "",
                                                                      "",
                                                                      "",
                                                                      "")));
                                                        }
                                                      },
                                                style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              TextSpan(
                                                text: " post",
                                                style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.normal,
                                                ),
                                              ),
                                            ],
                                          ),
                                        )),
                                        onTap: () {
                                          onTapImageTile(userPostModal.postedBy,
                                              userPostModal.roleId);

                                          /* Navigator.of(context).push(new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                           TagDetailWidget(
                                              userPostModal.tagList)));*/
                                        },
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0.0, 5, 0, 0),
                                        child:  Row(
                                          children: [
                                            TextViewWrap.textView(
                                                userPostModal.dateTime,
                                                TextAlign.center,
                                                ColorValues.GREY_TEXT_COLOR,
                                                12.0,
                                                FontWeight.normal),
                                            userIdPref == userPostModal.postedBy &&
                                                roleId == userPostModal.roleId.toString()
                                                ?      PaddingWrap.paddingfromLTRB(
                                                10.0,
                                                0.0,
                                                5.0,
                                                0.0,
                                                 Image.asset(
                                                  userPostModal.visibility ==
                                                          "Private"
                                                      ? "assets/profile/post/private_new.png"
                                                      : userPostModal
                                                                  .visibility ==
                                                              "SelectedConnections"
                                                          ? "assets/profile/post/selected_connection.png"
                                                          : userPostModal
                                                                      .visibility ==
                                                                  "AllConnections"
                                                              ? "assets/profile/post/connection.png"
                                                              : userPostModal
                                                                          .visibility ==
                                                                      "Group"
                                                                  ? "assets/profile/post/group_data.png"
                                                                  : "assets/profile/post/community.png",
                                                  width: 13.0,
                                                  color: userPostModal
                                                              .visibility ==
                                                          "SelectedConnections"
                                                      ? null
                                                      : ColorValues.GREY_TEXT_COLOR,
                                                  height: 13.0,
                                                )):new Container(height:0.0),
                                           /* PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                TextViewWrap.textView(
                                                    userPostModal.visibility ==
                                                            "Private"
                                                        ? "Private"
                                                        : userPostModal
                                                                    .visibility ==
                                                                "SelectedConnections"
                                                            ? "Selected Connections"
                                                            : userPostModal
                                                                        .visibility ==
                                                                    "AllConnections"
                                                                ? "Connections"
                                                                : userPostModal
                                                                            .visibility ==
                                                                        "Group"
                                                                    ? "Group"
                                                                    : "Community",
                                                    TextAlign.center,
                                                    ColorValues.GREY_TEXT_COLOR,
                                                    12.0,
                                                    FontWeight.normal))*/
                                          ],
                                        ),
                                      )

                                      /* TextViewWrap.textView(
                                          userPostModal.dateTime,
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          12.0,
                                          FontWeight.normal),*/
                                    ],
                                  )),
                              flex: 4,
                            ),
                             Expanded(
                              child: userIdPref == userPostModal.postedBy &&
                                      roleId == userPostModal.roleId.toString()
                                  ?  Container(
                                      padding:  EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 30.0),
                                      child:  InkWell(
                                        child:  Image.asset(
                                          "assets/profile/post/user_more1.png",
                                          width: 25.0,
                                          height: 25.0,
                                        ),
                                        onTap: () {
                                          optionMenuDelete(
                                              userPostModal, index);
                                        },
                                      ))
                                  :  Container(
                                      padding:  EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 30.0),
                                      child:  InkWell(
                                        child:  Image.asset(
                                          "assets/profile/post/user_more1.png",
                                          width: 25.0,
                                          height: 25.0,
                                        ),
                                        onTap: () {
                                          optionForReport(userPostModal, index);
                                        },
                                      )),
                              flex: 0,
                            )
                          ],
                        )),
                    userPostModal.shareText == "null" ||
                            userPostModal.shareText == ""
                        ?  Container(
                            height: 0.0,
                          )
                        :  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                10.0,
                                0.0,
                                userPostModal.shareText == "" ||
                                        userPostModal.shareText == "null" ||
                                        userPostModal.shareText == "\n"
                                    ?  Container(
                                        height: 0.0,
                                      )
                                    : PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        userPostModal.isShareMore
                                            ? /*new Text(userPostModal.shareText,
                                                textAlign: TextAlign.left,
                                                maxLines: null,
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0))*/

                                             Container(
                                                child: Linkify(
                                                  onOpen: (link) async {
                                                    print("onclick +++");
                                                    apiCallingForIncreaseCount(
                                                        userPostModal.feedId);
                                                    Navigator.push(
                                                        context,
                                                         MaterialPageRoute(
                                                            //   builder: (context) =>  DashBoardWidget()));
                                                            builder: (context) =>
                                                                 WebViewWidget(
                                                                    link.url,
                                                                    "spikeview")));
                                                  },
                                                  text: userPostModal.shareText,
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                  linkStyle:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                ),
                                              )
                                            :  Container(
                                                child: Linkify(
                                                  onOpen: (link) async {
                                                    print("onclick +++");
                                                    apiCallingForIncreaseCount(
                                                        userPostModal.feedId);
                                                    Navigator.push(
                                                        context,
                                                         MaterialPageRoute(
                                                            //   builder: (context) =>  DashBoardWidget()));
                                                            builder: (context) =>
                                                                 WebViewWidget(
                                                                    link.url,
                                                                    "spikeview")));
                                                  },
                                                  text:
                                                      /*userPostModal.shareText
                                                              .length >=
                                                          105
                                                      ? userPostModal.shareText
                                                          .toString()
                                                          .substring(0, 105)
                                                      : */
                                                      userPostModal.shareText,
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                  linkStyle:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                ),
                                              ) /*TextViewWrap.textViewMultiLine(
                                                userPostModal.shareText,
                                                TextAlign.left,
                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                14.0,
                                                FontWeight.normal,
                                                2)*/
                                        ),
                              ),
                            ],
                          ),
                    userPostModal.postOwnerDeleted
                        ? PaddingWrap.paddingfromLTRB(
                            11.0,
                            5.0,
                            11.0,
                            5.0,
                             Container(
                              width: double.infinity,
                              decoration:  BoxDecoration(
                                  color:  ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                  border:  Border.all(
                                      width: 0.5,
                                      color:  ColorValues.GREY__COLOR_DIVIDER)),
                              child: PaddingWrap.paddingfromLTRB(
                                  11.0,
                                  17.0,
                                  11.0,
                                  16.0,
                                   Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextViewWrap.textView(
                                          "You can’t see this post",
                                          TextAlign.start,
                                           ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.bold),
                                      TextViewWrap.textView(
                                          MessageConstant.AUTHOR_DELETED_POST,
                                          TextAlign.start,
                                           ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.normal)
                                    ],
                                  )),
                            ))
                        : PaddingWrap.paddingfromLTRB(
                            11.0,
                            5.0,
                            11.0,
                            5.0,
                             Container(
                                decoration:  BoxDecoration(
                                    border:  Border.all(
                                        width: 0.1, color: Colors.black)),
                                child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        17.0,
                                        10.0,
                                        10.0,
                                        10.0,
                                         Row(
                                          children: <Widget>[
                                             Expanded(
                                              child:  InkWell(
                                                child:  Container(
                                                    child:  Center(
                                                        child:  Container(
                                                            width: 50.0,
                                                            height: 50.0,
                                                            child:  ClipOval(
                                                                child: FadeInImage
                                                                    .assetNetwork(
                                                              fit: BoxFit.cover,
                                                              width: double
                                                                  .infinity,
                                                              placeholder: userPostModal
                                                                          .postOwnerRoleId ==
                                                                      "4"
                                                                  ? "assets/profile/partner_img.png"
                                                                  : 'assets/profile/user_on_user.png',
                                                              image: Constant
                                                                      .IMAGE_PATH_SMALL +
                                                                  ParseJson.getSmallImage(
                                                                      userPostModal
                                                                          .postOwnerProfilePicture),
                                                            ))))),
                                                onTap: () {
                                                  onTapImageTile(
                                                      userPostModal.postOwner,
                                                      userPostModal
                                                          .postOwnerRoleId);
                                                },
                                              ),
                                              flex: 0,
                                            ),
                                             Expanded(
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      8.0,
                                                      0.0,
                                                      15.0,
                                                      0.0,
                                                       Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                               Expanded(
                                                                child:
                                                                     InkWell(
                                                                  child:
                                                                       Container(
                                                                          child:
                                                                              RichText(
                                                                    maxLines: 2,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .start,
                                                                    text:
                                                                        TextSpan(
                                                                      text: userPostModal.postOwnerLastName ==
                                                                              "null"
                                                                          ? userPostModal
                                                                              .postOwnerFirstName
                                                                          : userPostModal.postOwnerFirstName +
                                                                              " " +
                                                                              userPostModal.postOwnerLastName,
                                                                      style:
                                                                           TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                            15.0,
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                      ),
                                                                      children: userPostModal.tagList.length == 0 &&
                                                                              userPostModal.groupList.length == 0
                                                                          ? [
                                                                              WidgetSpan(
                                                                                child: userPostModal.roleId == "1"
                                                                                    ? Util.getStudentBadgeRichTextWithPadding(userPostModal.postOwnerBadge, userPostModal.postOwnerBadgeImage)
                                                                                    : Container(
                                                                                        height: 0.0,
                                                                                        width: 0.0,
                                                                                      ),
                                                                              ),
                                                                            ]
                                                                          : userPostModal.tagList.length != 0 && userPostModal.groupList.length != 0
                                                                              ? [
                                                                                  WidgetSpan(
                                                                                    child: userPostModal.roleId == "1"
                                                                                        ? Util.getStudentBadgeRichTextWithPadding(userPostModal.postOwnerBadge, userPostModal.postOwnerBadgeImage)
                                                                                        : Container(
                                                                                            height: 0.0,
                                                                                            width: 0.0,
                                                                                          ),
                                                                                  ),
                                                                                  TextSpan(text: ' > ', style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                                  TextSpan(
                                                                                    text: userPostModal.groupList[0].groupName == null || userPostModal.groupList[0].groupName == "null" ? "" : userPostModal.tagList[0].groupName,
                                                                                    style:  TextStyle(
                                                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                      fontSize: 14.0,
                                                                                      fontWeight: FontWeight.bold,
                                                                                    ),
                                                                                  ),
                                                                                  userPostModal.groupList.length > 1
                                                                                      ? TextSpan(
                                                                                          text: ' and ',
                                                                                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        )
                                                                                      : TextSpan(
                                                                                          text: "",
                                                                                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        ),
                                                                                  userPostModal.groupList.length > 1
                                                                                      ? TextSpan(
                                                                                          text: (userPostModal.groupList.length - 1).toString(),
                                                                                          style:  TextStyle(
                                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                            fontSize: 14.0,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                        )
                                                                                      : TextSpan(
                                                                                          text: "",
                                                                                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        ),
                                                                                  userPostModal.groupList.length > 1
                                                                                      ? TextSpan(
                                                                                          text: " others ",
                                                                                          style:  TextStyle(
                                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                            fontSize: 14.0,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                        )
                                                                                      : TextSpan(
                                                                                          text: "",
                                                                                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        ),
                                                                                  TextSpan(text: ' with ', style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                                  TextSpan(
                                                                                    text: userPostModal.tagList[0].name == null || userPostModal.tagList[0].name == "null" ? "" : userPostModal.tagList[0].name,
                                                                                    style:  TextStyle(
                                                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                      fontSize: 14.0,
                                                                                      fontWeight: FontWeight.bold,
                                                                                    ),
                                                                                  ),
                                                                                  userPostModal.tagList.length > 1
                                                                                      ? TextSpan(
                                                                                          text: ' and ',
                                                                                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        )
                                                                                      : TextSpan(
                                                                                          text: "",
                                                                                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        ),
                                                                                  userPostModal.tagList.length > 1
                                                                                      ? TextSpan(
                                                                                          text: (userPostModal.tagList.length - 1).toString(),
                                                                                          style:  TextStyle(
                                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                            fontSize: 14.0,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                        )
                                                                                      : TextSpan(
                                                                                          text: "",
                                                                                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        ),
                                                                                  userPostModal.tagList.length > 1
                                                                                      ? TextSpan(
                                                                                          text: " others ",
                                                                                          style:  TextStyle(
                                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                            fontSize: 14.0,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                        )
                                                                                      : TextSpan(
                                                                                          text: "",
                                                                                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        ),
                                                                                ]
                                                                              : userPostModal.groupList.length != 0
                                                                                  ? [
                                                                                      WidgetSpan(
                                                                                        child: userPostModal.roleId == "1"
                                                                                            ? Util.getStudentBadgeRichTextWithPadding(userPostModal.postOwnerBadge, userPostModal.postOwnerBadgeImage)
                                                                                            : Container(
                                                                                                height: 0.0,
                                                                                                width: 0.0,
                                                                                              ),
                                                                                      ),
                                                                                      TextSpan(text: ' > ', style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                                      TextSpan(
                                                                                        text: userPostModal.groupList[0].groupName == null || userPostModal.groupList[0].groupName == "null" ? "" : userPostModal.groupList[0].groupName,
                                                                                        style:  TextStyle(
                                                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                          fontSize: 14.0,
                                                                                          fontWeight: FontWeight.bold,
                                                                                        ),
                                                                                      ),
                                                                                      userPostModal.groupList.length > 1
                                                                                          ? TextSpan(
                                                                                              text: ' and ',
                                                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            )
                                                                                          : TextSpan(
                                                                                              text: "",
                                                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            ),
                                                                                      userPostModal.groupList.length > 1
                                                                                          ? TextSpan(
                                                                                              text: (userPostModal.groupList.length - 1).toString(),
                                                                                              style:  TextStyle(
                                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                                fontSize: 14.0,
                                                                                                fontWeight: FontWeight.bold,
                                                                                              ),
                                                                                            )
                                                                                          : TextSpan(
                                                                                              text: "",
                                                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            ),
                                                                                      userPostModal.groupList.length > 1
                                                                                          ? TextSpan(
                                                                                              text: " others ",
                                                                                              style:  TextStyle(
                                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                                fontSize: 14.0,
                                                                                                fontWeight: FontWeight.bold,
                                                                                              ),
                                                                                            )
                                                                                          : TextSpan(
                                                                                              text: "",
                                                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            ),
                                                                                    ]
                                                                                  : // taglist is not empty
                                                                                  [
                                                                                      WidgetSpan(
                                                                                        child: userPostModal.roleId == "1"
                                                                                            ? Util.getStudentBadgeRichTextWithPadding(userPostModal.postOwnerBadge, userPostModal.postOwnerBadgeImage)
                                                                                            : Container(
                                                                                                height: 0.0,
                                                                                                width: 0.0,
                                                                                              ),
                                                                                      ),
                                                                                      TextSpan(text: ' with ', style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                                      TextSpan(
                                                                                        text: userPostModal.tagList[0].name == null || userPostModal.tagList[0].name == "null" ? "" : userPostModal.tagList[0].name,
                                                                                        style:  TextStyle(
                                                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                          fontSize: 14.0,
                                                                                          fontWeight: FontWeight.bold,
                                                                                        ),
                                                                                      ),
                                                                                      userPostModal.tagList.length > 1
                                                                                          ? TextSpan(
                                                                                              text: ' and ',
                                                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            )
                                                                                          : TextSpan(
                                                                                              text: "",
                                                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            ),
                                                                                      userPostModal.tagList.length > 1
                                                                                          ? TextSpan(
                                                                                              text: (userPostModal.tagList.length - 1).toString(),
                                                                                              style:  TextStyle(
                                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                                fontSize: 14.0,
                                                                                                fontWeight: FontWeight.bold,
                                                                                              ),
                                                                                            )
                                                                                          : TextSpan(
                                                                                              text: "",
                                                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            ),
                                                                                      userPostModal.tagList.length > 1
                                                                                          ? TextSpan(
                                                                                              text: " others ",
                                                                                              style:  TextStyle(
                                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                                fontSize: 14.0,
                                                                                                fontWeight: FontWeight.bold,
                                                                                              ),
                                                                                            )
                                                                                          : TextSpan(
                                                                                              text: "",
                                                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontWeight: FontWeight.normal, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            ),
                                                                                    ],
                                                                    ),
                                                                  )),
                                                                  onTap: () {
                                                                    if (userPostModal
                                                                            .tagList
                                                                            .length >
                                                                        0) {
                                                                      Navigator.of(
                                                                              context)
                                                                          .push(
                                                                               MaterialPageRoute(builder: (BuildContext context) =>  TagDetailWidget(userPostModal.tagList)));
                                                                    } else {
                                                                      print(
                                                                          "clicked");
                                                                      onTapImageTile(
                                                                          userPostModal
                                                                              .postOwner,
                                                                          userPostModal
                                                                              .postOwnerRoleId);
                                                                    }
                                                                  },
                                                                ),
                                                                flex: 0,
                                                              ),
                                                              /*  Expanded(
                                                                child: userPostModal.postedGroupName == null ||
                                                                        userPostModal.postedGroupName ==
                                                                            "null" ||
                                                                        userPostModal.postedGroupName ==
                                                                            ""
                                                                    ?  Container(
                                                                        height:
                                                                            0.0,
                                                                      )
                                                                    :  InkWell(
                                                                        child:
                                                                            RichText(
                                                                          maxLines:
                                                                              2,
                                                                          textAlign:
                                                                              TextAlign.start,
                                                                          text:
                                                                              TextSpan(
                                                                            text:
                                                                                ' > ',
                                                                            style:  TextStyle(
                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                fontSize: 14.0,
                                                                                fontWeight: FontWeight.normal,
                                                                                fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                            children: <TextSpan>[
                                                                              TextSpan(
                                                                                text: userPostModal.postedGroupName,
                                                                                style:  TextStyle(
                                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                  fontSize: 15.0,
                                                                                  fontWeight: FontWeight.bold,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        onTap:
                                                                            () {
                                                                          Navigator.of(context)
                                                                              .push(new MaterialPageRoute(builder: (BuildContext context) =>  GroupDetailWidget(userPostModal.postedGroupId, "", "", "", "")));
                                                                        },
                                                                      ),
                                                                flex: 0,
                                                              ),*/
                                                            ],
                                                          ),
                                                          TextViewWrap.textView(
                                                              userPostModal
                                                                  .shareTime,
                                                              TextAlign.center,
                                                               ColorValues.GREY_TEXT_COLOR,
                                                              12.0,
                                                              FontWeight
                                                                  .normal),
                                                        ],
                                                      )),
                                              flex: 4,
                                            )
                                          ],
                                        )),
                                    userPostModal.postdata == null ||
                                            userPostModal.postdata.text ==
                                                null ||
                                            userPostModal.postdata.text ==
                                                "null"
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        : PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            0.0,
                                            10.0,
                                            0.0,
                                             Container(
                                                color: Colors.transparent,
                                                child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      userPostModal.postdata.text == "" ||
                                                              userPostModal
                                                                      .postdata
                                                                      .text ==
                                                                  "null" ||
                                                              userPostModal
                                                                      .postdata
                                                                      .text ==
                                                                  "\n"
                                                          ?  Container(
                                                              height: 1.0,
                                                            )
                                                          : userPostModal
                                                                          .postdata
                                                                          .imageList
                                                                          .length ==
                                                                      0 &&
                                                                  (userPostModal.postdata.media ==
                                                                          null ||
                                                                      userPostModal.postdata.media ==
                                                                          "" ||
                                                                      userPostModal.postdata.media ==
                                                                          "null") &&
                                                                  (userPostModal
                                                                              .postdata
                                                                              .metaUrl !=
                                                                          "" &&
                                                                      userPostModal
                                                                              .postdata
                                                                              .metaImage !=
                                                                          "")
                                                              ? exp.allMatches(userPostModal.postdata.text).length ==
                                                                          1 &&
                                                                      userPostModal
                                                                              .postdata
                                                                              .text
                                                                              .toString()
                                                                              .replaceAll(exp, '')
                                                                              .length ==
                                                                          0
                                                                  ?  Container(
                                                                      height:
                                                                          0.0,
                                                                    )
                                                                  : PaddingWrap.paddingfromLTRB(
                                                                      4.0,
                                                                      10.0,
                                                                      13.0,
                                                                      0.0,
                                                                       Container(
                                                                        child:
                                                                            Linkify(
                                                                          onOpen:
                                                                              (link) async {
                                                                            print("onclick +++" +
                                                                                link.url.toLowerCase());
                                                                            apiCallingForIncreaseCount(userPostModal.feedId);

                                                                            Navigator.push(
                                                                                context,
                                                                                 MaterialPageRoute(
                                                                                    //   builder: (context) =>  DashBoardWidget()));
                                                                                    builder: (context) =>  WebViewWidget(link.url, "spikeview")));
                                                                          },
                                                                          text: exp.allMatches(userPostModal.postdata.text).length > 1
                                                                              ? userPostModal.postdata.text
                                                                              : userPostModal.postdata.text.toString().replaceAll(exp, ''),
                                                                          style:  TextStyle(
                                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                              fontSize: 14.0),
                                                                          linkStyle:  TextStyle(
                                                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                              fontSize: 14.0),
                                                                        ),
                                                                      ))
                                                              :  Container(
                                                                  child:
                                                                      Linkify(
                                                                    onOpen:
                                                                        (link) async {
                                                                      print("onclick +++" +
                                                                          link.url
                                                                              .toLowerCase());
                                                                      apiCallingForIncreaseCount(
                                                                          userPostModal
                                                                              .feedId);
                                                                      Navigator.push(
                                                                          context,
                                                                           MaterialPageRoute(
                                                                              //   builder: (context) =>  DashBoardWidget()));
                                                                              builder: (context) =>  WebViewWidget(link.url, "spikeview")));
                                                                    },
                                                                    text: userPostModal
                                                                        .postdata
                                                                        .text,
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR,
                                                                        fontSize:
                                                                            14.0),
                                                                    linkStyle:  TextStyle(
                                                                        color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR,
                                                                        fontSize:
                                                                            14.0),
                                                                  ),
                                                                ),
                                                    ),
                                                  ],
                                                ))),

                                    /*    userPostModal.postdata == null ||
                                            userPostModal.postdata.text ==
                                                null ||
                                            userPostModal.postdata.text ==
                                                "null"
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        : exp
                                                        .allMatches(
                                                            userPostModal
                                                                .postdata.text)
                                                        .length ==
                                                    1 &&
                                                userPostModal.postdata.text
                                                        .toString()
                                                        .replaceAll(exp, '')
                                                        .length ==
                                                    0
                                            ?  Container(
                                                height: 0.0,
                                              )
                                            : PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                 Container(
                                                    color: Colors.transparent,
                                                    child:  Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          userPostModal.postdata
                                                                          .text ==
                                                                      "" ||
                                                                  userPostModal
                                                                          .postdata
                                                                          .text ==
                                                                      "null" ||
                                                                  userPostModal
                                                                          .postdata
                                                                          .text ==
                                                                      "\n"
                                                              ?  Container(
                                                                  height: 1.0,
                                                                )
                                                              : PaddingWrap.paddingfromLTRB(
                                                                  17.0,
                                                                  10.0,
                                                                  17.0,
                                                                  0.0,
                                                                  userPostModal.isReadMore
                                                                      ?  Container(
                                                                          child:
                                                                              Linkify(
                                                                            onOpen:
                                                                                (link) async {
                                                                              print("onclick +++");
                                                                              apiCallingForIncreaseCount(userPostModal.feedId);
                                                                              Navigator.push(
                                                                                  context,
                                                                                   MaterialPageRoute(
                                                                                      //   builder: (context) =>  DashBoardWidget()));
                                                                                      builder: (context) =>  WebViewWidget(link.url, "spikeview")));
                                                                            },
                                                                            text:
                                                                                userPostModal.postdata.text,
                                                                            style:  TextStyle(
                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                                fontSize: 14.0),
                                                                            linkStyle:  TextStyle(
                                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                                fontSize: 14.0),
                                                                          ),
                                                                        )
                                                                      :  Container(
                                                                          child:
                                                                              Linkify(
                                                                            onOpen:
                                                                                (link) async {
                                                                              print("onclick +++");
                                                                              apiCallingForIncreaseCount(userPostModal.feedId);
                                                                              Navigator.push(
                                                                                  context,
                                                                                   MaterialPageRoute(
                                                                                      //   builder: (context) =>  DashBoardWidget()));
                                                                                      builder: (context) =>  WebViewWidget(link.url, "spikeview")));
                                                                            },
                                                                            text: exp.allMatches(userPostModal.postdata.text).length > 2
                                                                                ? userPostModal.postdata.text
                                                                                : userPostModal.postdata.text.toString().replaceAll(exp, ''),
                                                                            style:  TextStyle(
                                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                                fontSize: 14.0),
                                                                            linkStyle:  TextStyle(
                                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                                fontSize: 14.0),
                                                                          ),
                                                                        )),
                                                        ),
                                                        */ /*userPostModal.postdata.text
                                                            .length >
                                                        90
                                                    ?  Align(
                                                        alignment: Alignment
                                                            .bottomLeft,
                                                        child:  InkWell(
                                                          child: PaddingWrap.paddingfromLTRB(
                                                              17.0,
                                                              0.0,
                                                              5.0,
                                                              5.0,
                                                              TextViewWrap.textView(
                                                                  userPostModal
                                                                          .isReadMore
                                                                      ? "Less"
                                                                      : "More",
                                                                  TextAlign
                                                                      .left,
                                                                    ColorValues.BLUE_COLOR,
                                                                  14.0,
                                                                  FontWeight
                                                                      .normal)),
                                                          onTap: () {
                                                            if (userPostModal
                                                                .isReadMore) {
                                                              userPostModal
                                                                      .isReadMore =
                                                                  false;
                                                            } else {
                                                              userPostModal
                                                                      .isReadMore =
                                                                  true;
                                                            }
                                                            setState(() {
                                                              userPostModal
                                                                  .isReadMore;
                                                            });
                                                          },
                                                        ))
                                                    :  Container(
                                                        height: 10.0,
                                                      ),*/ /*
                                                      ],
                                                    ))),

                                    */

                                    userPostModal.postdata.imageList.length == 0
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        : PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            0.0,
                                            10.0,
                                            0.0,
                                             Container(
                                                height: 180.0,
                                                child:  SizedBox(
                                                    // Pager view
                                                    height: 180.0,
                                                    child:
                                                        PageIndicatorContainer(
                                                      pageView:
                                                           PageView.builder(
                                                        itemCount: userPostModal
                                                            .postdata
                                                            .imageList
                                                            .length,
                                                        controller:
                                                             PageController(),
                                                        itemBuilder:
                                                            (context, index2) {
                                                          return  InkWell(
                                                            child:  Stack(
                                                                children: <
                                                                    Widget>[
                                                                   Container(
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                      height:
                                                                          180.0,
                                                                      child:
                                                                           CachedNetworkImage(
                                                                        width: double
                                                                            .infinity,
                                                                        height:
                                                                            180.0,
                                                                        imageUrl:
                                                                            Constant.IMAGE_PATH_SMALL +
                                                                                ParseJson.getMediumImage(userPostModal.postdata.imageList[index2]),
                                                                        fit: BoxFit
                                                                            .contain,
                                                                        placeholder:
                                                                            (context, url) =>
                                                                                _loader(context),
                                                                        errorWidget: (context,
                                                                                url,
                                                                                error) =>
                                                                            _error(),
                                                                      )),
                                                                  userPostModal
                                                                              .postdata
                                                                              .imageList
                                                                              .length ==
                                                                          1
                                                                      ?  InkWell(
                                                                          onTap:
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  CommonFullViewWidget(userPostModal.postdata.imageList, MessageConstant.HOME_FEED, index2, MessageConstant.COMPANY_PROFILE_HEDING)));
                                                                          },
                                                                          child:
                                                                               Container(
                                                                            height:
                                                                                0.0,
                                                                          ))
                                                                      :  InkWell(
                                                                          onTap:
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  CommonFullViewWidget(userPostModal.postdata.imageList, MessageConstant.HOME_FEED, index2, MessageConstant.COMPANY_PROFILE_HEDING)));
                                                                          },
                                                                          child:
                                                                               Container(
                                                                            height:
                                                                                180.0,
                                                                            width:
                                                                                double.infinity,
                                                                            child:
                                                                                 Image.asset(
                                                                              "assets/newDesignIcon/navigation/layer_image.png",
                                                                              fit: BoxFit.fill,
                                                                            ),
                                                                          ))
                                                                ]),
                                                            onTap: () {
                                                              Navigator.of(context).push(new MaterialPageRoute(
                                                                  builder: (BuildContext context) =>  CommonFullViewWidget(
                                                                      userPostModal
                                                                          .postdata
                                                                          .imageList,
                                                                      MessageConstant
                                                                          .HOME_FEED,
                                                                      index2,
                                                                      MessageConstant
                                                                          .COMPANY_PROFILE_HEDING)));
                                                            },
                                                          );
                                                        },
                                                        onPageChanged:
                                                            (index) {},
                                                      ),
                                                      align:
                                                          IndicatorAlign.bottom,
                                                      length: userPostModal
                                                          .postdata
                                                          .imageList
                                                          .length,
                                                      indicatorSpace: 10.0,
                                                      indicatorColor:
                                                          userPostModal
                                                                      .postdata
                                                                      .imageList
                                                                      .length ==
                                                                  1
                                                              ? Colors
                                                                  .transparent
                                                              :  Color(
                                                                  0xffc4c4c4),
                                                      indicatorSelectorColor:
                                                          userPostModal
                                                                      .postdata
                                                                      .imageList
                                                                      .length ==
                                                                  1
                                                              ? Colors
                                                                  .transparent
                                                              :  Color(
                                                                  0XFFFFFFFF),
                                                      shape:
                                                          IndicatorShape.circle(
                                                              size: 5.0),
                                                    )))),
                                    userPostModal.postdata.imageList.length >
                                                0 ||
                                            userPostModal.postdata.media ==
                                                null ||
                                            userPostModal.postdata.media ==
                                                "" ||
                                            userPostModal.postdata.media ==
                                                "null"
                                        ?  Container(
                                            height: 1.0,
                                          )
                                        : PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            0.0,
                                            10.0,
                                            0.0,
                                             InkWell(
                                              child:  Container(
                                                decoration: BoxDecoration(
                                                  color: Colors.black,
                                                  borderRadius:
                                                      BorderRadius.circular(0),
                                                ),
                                                height: 180.0,
                                                width: double.infinity,
                                                child:  Center(
                                                  child:  Center(
                                                    child:  VideoPlayPauseDialogOffline(
                                                        userPostModal
                                                            .postdata.media,
                                                        userPostModal.feedId,
                                                        true),
                                                    /*  Container(
                                                        child:  Stack(
                                                          children: <Widget>[

                                                            Container(
                                                              height: 215.0,
                                                              color: Colors.black,
                                                              margin: EdgeInsets.only(left: 0, right: 0),
                                                              child:  VideoViewBlack(
                                                                  Constant.IMAGE_PATH + userPostModal
                                                                      .postdata.media, "", false, ""),
                                                            ),
                                                            */ /*new Container(
                                                                                      height: 54.0,
                                                                                      width: 80.0,
                                                                                      color:  Color(0XFFC0C0C0).withOpacity(.4),
                                                                                    ),*/ /*
                                                             Center(
                                                                child:  Row(
                                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                  children: <Widget>[
                                                                     InkWell(
                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                           Image.asset(
                                                                            //'assets/pre_login/video_play_button.png',
                                                                            'assets/newDesignIcon/circle_play.png',
                                                                            width: 50.0,
                                                                            height: 50.0,
                                                                          )),
                                                                    )
                                                                  ],
                                                                )),
                                                          ],
                                                        )),*/
                                                  ),
                                                ),
                                              ),
                                              onTap: () {
                                                /*Navigator.of(context).push(new MaterialPageRoute(
                                                    builder: (BuildContext
                                                    context) =>
                                                     VideoFullViewWidget(
                                                        '',
                                                        MessageConstant
                                                            .VIEWER_END_REWCOMMENDATION_HEDING,
                                                        Constant.IMAGE_PATH + userPostModal.postdata.media
                                                    )));*/
                                              },
                                            )),
                                    userPostModal.postdata.imageList.length ==
                                                0 &&
                                            (userPostModal.postdata.media ==
                                                    null ||
                                                userPostModal.postdata.media ==
                                                    "" ||
                                                userPostModal.postdata.media ==
                                                    "null")
                                        ? userPostModal.postdata == null ||
                                                userPostModal.postdata.text ==
                                                    null ||
                                                userPostModal.postdata.text ==
                                                    "null"
                                            ?  Container(
                                                height: 0.0,
                                              )
                                            //: getLinkUrl(userPostModal.postdata.text) !=
                                            : userPostModal.postdata.metaUrl !=
                                                    ""
                                                        ""
                                                ?

                                                /*Container(
                                    margin:EdgeInsets.symmetric(
                                        vertical: 4.0),
                                    child: userPostModal.webLinkModel.imageUrl ==
                                        ""
                                        ?new WhatsAppLinkPreview()
                                        .build(
                                        getLinkUrl(
                                            userPostModal
                                                .postdata
                                                .text),
                                        userPostModal)
                                        :  WhatsAppView(
                                      imageUrl: userPostModal.webLinkModel.imageUrl,
                                      feedId: userPostModal.feedId,
                                      title: userPostModal.webLinkModel.title,
                                      url: userPostModal.webLinkModel.url,
                                      description: userPostModal.webLinkModel.description,

                                    ))*/

                                                Container(
                                                    margin:
                                                        EdgeInsets.symmetric(
                                                            vertical: 4.0),
//                                  child: userPostModal.webLinkModel.imageUrl ==
//                                          ""
//                                      ?new WhatsAppLinkPreview().build(
//                                          getLinkUrl(
//                                              userPostModal.postdata.text),
//                                          userPostModal)
//                                      :

                                                    child:  WhatsAppView(
                                                      imageUrl: userPostModal
                                                          .postdata.metaImage,
                                                      feedId:
                                                          userPostModal.feedId,
                                                      title: userPostModal
                                                          .postdata.metaTitle,
                                                      url: userPostModal
                                                          .postdata.metaUrl,
                                                      metaHeight: userPostModal
                                                          .postdata.metaHeight,
                                                      metaWidth: userPostModal
                                                          .postdata.metaWidth,
                                                      metaSource: userPostModal
                                                          .postdata.metaSource,
                                                      description: userPostModal
                                                          .postdata
                                                          .metaDescription,
                                                    ))
                                                :  Container(
                                                    height: 0.0,
                                                  )
                                        :  Container(
                                            height: 0.0,
                                          ),
                                    /*  PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                         Container(
                                            color: Colors.transparent,
                                            child:  Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  userPostModal.postdata.text ==
                                                              "" ||
                                                          userPostModal.postdata
                                                                  .text ==
                                                              "null" ||
                                                          userPostModal.postdata
                                                                  .text ==
                                                              "\n"
                                                      ?  Container(
                                                          height: 1.0,
                                                        )
                                                      : PaddingWrap
                                                          .paddingfromLTRB(
                                                              17.0,
                                                              10.0,
                                                              17.0,
                                                              0.0,
                                                              userPostModal
                                                                      .isReadMore
                                                                  ?  Container(
                                                                      child:
                                                                          Linkify(
                                                                        onOpen:
                                                                            (link) async {
                                                                          print(
                                                                              "onclick +++");
                                                                          apiCallingForIncreaseCount(
                                                                              userPostModal.feedId);
                                                                          Navigator.push(
                                                                              context,
                                                                               MaterialPageRoute(
                                                                                  //   builder: (context) =>  DashBoardWidget()));
                                                                                  builder: (context) =>  WebViewWidget(link.url, "spikeview")));
                                                                        },
                                                                        text: userPostModal
                                                                            .postdata
                                                                            .text,
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontFamily:
                                                                                Constant.TYPE_CUSTOMREGULAR,
                                                                            fontSize:
                                                                                14.0),
                                                                        linkStyle:  TextStyle(
                                                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                            fontFamily:
                                                                                Constant.TYPE_CUSTOMREGULAR,
                                                                            fontSize:
                                                                                14.0),
                                                                      ),
                                                                    )
                                                                  :  Container(
                                                                      child:
                                                                          Linkify(
                                                                        onOpen:
                                                                            (link) async {
                                                                          print(
                                                                              "onclick +++");
                                                                          apiCallingForIncreaseCount(
                                                                              userPostModal.feedId);
                                                                          Navigator.push(
                                                                              context,
                                                                               MaterialPageRoute(
                                                                                  //   builder: (context) =>  DashBoardWidget()));
                                                                                  builder: (context) =>  WebViewWidget(link.url, "spikeview")));
                                                                        },
                                                                        text:*/ /* userPostModal.postdata.text.length >=
                                                                                105
                                                                            ? userPostModal.postdata.text.toString().substring(0,
                                                                                105)
                                                                            : */ /*userPostModal.postdata.text,
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontFamily:
                                                                                Constant.TYPE_CUSTOMREGULAR,
                                                                            fontSize:
                                                                                14.0),
                                                                        linkStyle:  TextStyle(
                                                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                            fontFamily:
                                                                                Constant.TYPE_CUSTOMREGULAR,
                                                                            fontSize:
                                                                                14.0),
                                                                      ),
                                                                    )),
                                                ),
                                                */ /*userPostModal.postdata.text
                                                            .length >
                                                        90
                                                    ?  Align(
                                                        alignment: Alignment
                                                            .bottomLeft,
                                                        child:  InkWell(
                                                          child: PaddingWrap.paddingfromLTRB(
                                                              17.0,
                                                              0.0,
                                                              5.0,
                                                              5.0,
                                                              TextViewWrap.textView(
                                                                  userPostModal
                                                                          .isReadMore
                                                                      ? "Less"
                                                                      : "More",
                                                                  TextAlign
                                                                      .left,
                                                                    ColorValues.BLUE_COLOR,
                                                                  14.0,
                                                                  FontWeight
                                                                      .normal)),
                                                          onTap: () {
                                                            if (userPostModal
                                                                .isReadMore) {
                                                              userPostModal
                                                                      .isReadMore =
                                                                  false;
                                                            } else {
                                                              userPostModal
                                                                      .isReadMore =
                                                                  true;
                                                            }
                                                            setState(() {
                                                              userPostModal
                                                                  .isReadMore;
                                                            });
                                                          },
                                                        ))
                                                    :  Container(
                                                        height: 10.0,
                                                      ),*/ /*
                                              ],
                                            )))*/
                                  ],
                                ))),

                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                      child:  Row(
                        children: <Widget>[
                           Expanded(
                            child: userPostModal.likeList.length > 0
                                ? PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    10.0,
                                    0.0,
                                    InkWell(
                                      child: TextViewWrap.textView(
                                          userPostModal.likeList.length == 0
                                              ? "Like"
                                              : userPostModal.likeList.length ==
                                                      1
                                                  ? "1 Like"
                                                  : userPostModal
                                                          .likeList.length
                                                          .toString() +
                                                      " Likes",
                                          TextAlign.end,
                                          ColorValues.GREY_TEXT_COLOR,
                                          14.0,
                                          FontWeight.normal),
                                      onTap: () {
                                        onTapLikeText(userPostModal);
                                      },
                                    ))
                                :  Container(
                                    height: 0.0,
                                  ),
                            flex: 0,
                          ),
                          /*   Padding(
                            padding: const EdgeInsets.only(bottom: 6.0),
                            child:  Text(
                              ".",
                              style: TextStyle(
                                  fontSize: 16.0,
                                  color: ColorValues.GREY_TEXT_COLOR),
                            ),
                          ),*/
                          userPostModal.commentList.length == 0
                              ?  Container(
                                  height: 0.0,
                                )
                              :  InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    TextViewWrap.textView(
                                        userPostModal.commentList.length == 0
                                            ? "Comment"
                                            : "" +
                                                userPostModal.commentList.length
                                                    .toString() +
                                                " Comments",
                                        TextAlign.left,
                                        ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal),
                                  ),
                                  onTap: () {
                                    onTapViewAllComments(
                                        userPostModal.commentList,
                                        userPostModal.feedId,
                                        userPostModal);
                                  },
                                )
                        ],
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Divider(
                          height: 1.0, color: ColorValues.DARK_GREY),
                    ),

                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        0.0,
                         Row(
                          children: <Widget>[
                             Expanded(
                              child:  Row(
                                children: <Widget>[
                                  userPostModal.isLike
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          10.0,
                                          0.0,
                                           InkWell(
                                            child:  Row(
                                              children: <Widget>[
                                                PaddingWrap.paddingAll(
                                                    10.0,
                                                     Image.asset(
                                                      "assets/newDesignIcon/feed/like_green.png",
                                                      height: 24.0,
                                                      width: 25.0,
                                                    )),
                                                getText(
                                                    "Like",
                                                    ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR)
                                              ],
                                            ),
                                            onTap: () {
                                              onTapLike(userPostModal);
                                            },
                                          ))
                                      : PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                           InkWell(
                                            child:  Row(
                                              children: <Widget>[
                                                PaddingWrap.paddingAll(
                                                    10.0,
                                                     Image.asset(
                                                      "assets/newDesignIcon/feed/like.png",
                                                      height: 24.0,
                                                      width: 25.0,
                                                    )),
                                                getText("Like",
                                                    ColorValues.GREY_TEXT_COLOR)
                                              ],
                                            ),
                                            onTap: () {
                                              onTapLike(userPostModal);
                                            },
                                          )),
                                  Spacer(),
                                  /*Padding(
                                    padding: const EdgeInsets.only(bottom: 5.0),
                                    child:  Text(
                                      ".",
                                      style: TextStyle(
                                          fontSize: 16.0,
                                          color: ColorValues.GREY_TEXT_COLOR),
                                    ),
                                  ),
                                  Spacer(),*/
                                  PaddingWrap.paddingfromLTRB(
                                      5.0,
                                      0.0,
                                      10.0,
                                      0.0,
                                       InkWell(
                                        child:  Row(
                                          children: <Widget>[
                                            PaddingWrap.paddingAll(
                                                0.0,
                                                 Image.asset(
                                                  "assets/newDesignIcon/feed/msg.png",
                                                  height: 25.0,
                                                  width: 25.0,
                                                )),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 12.0),
                                              child: getText("Comment",
                                                  ColorValues.GREY_TEXT_COLOR),
                                            )
                                          ],
                                        ),
                                        onTap: () {
                                          if (userPostModal.isShowCommentIcon)
                                            userPostModal.isShowCommentIcon =
                                                false;
                                          else {
                                            _scrollController.jumpTo(
                                                (_scrollController.offset +
                                                    80.0));
                                            userPostModal.isShowCommentIcon =
                                                true;
                                          }

                                          setState(() {
                                            userPostModal.isShowCommentIcon;
                                          });
                                        },
                                      )),
                                  Spacer(),
                                  /* Padding(
                                    padding: const EdgeInsets.only(bottom: 5.0),
                                    child:  Text(
                                      ".",
                                      style: TextStyle(
                                          fontSize: 16.0,
                                          color: ColorValues.GREY_TEXT_COLOR),
                                    ),
                                  ),
                                  Spacer(),*/
                                  InkWell(
                                    child:  Row(
                                      children: <Widget>[
                                        shareView(userPostModal),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 2.0, right: 10.0),
                                          child: getText("Share",
                                              ColorValues.GREY_TEXT_COLOR),
                                        )
                                      ],
                                    ),
                                    onTap: () {
                                      onTapShare(userPostModal);
                                    },
                                  ),
                                ],
                              ),
                              flex: 1,
                            ),
//                             Expanded(
//                              child: userPostModal.likeList.length > 0
//                                  ? PaddingWrap.paddingfromLTRB(
//                                  10.0,
//                                  0.0,
//                                  13.0,
//                                  0.0,
//                                  InkWell(
//                                    child: TextViewWrap.textView(
//                                        userPostModal.likeList.length == 1
//                                            ? "1 Like"
//                                            : userPostModal.likeList.length
//                                            .toString() +
//                                            " Likes",
//                                        TextAlign.end,
//                                        Color(ColorValues
//                                            .BLUE_COLOR_BOTTOMBAR),
//                                        12.0,
//                                        FontWeight.normal),
//                                    onTap: () {
//                                      onTapLikeText(userPostModal);
//                                    },
//                                  ))
//                                  :  Container(
//                                height: 0.0,
//                              ),
//                              flex: 0,
//                            )
                          ],
                        )),
                    PaddingWrap.paddingAll(
                        0.0,
                         Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            // Comment List view
                             Padding(
                                padding:
                                     EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                                child:  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children:  List.generate(
                                        userPostModal.commentList.length > 3
                                            ? 3
                                            : userPostModal.commentList.length,
                                        (int index) {
                                      return PaddingWrap.paddingfromLTRB(
                                          10.0,
                                          5.0,
                                          10.0,
                                          0.0,
                                           Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                               InkWell(
                                                  child:  Container(
                                                      width: 40.0,
                                                      height: 40.0,
                                                      child: ClipOval(
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                        fit: BoxFit.cover,
                                                        width: double.infinity,
                                                        placeholder: userPostModal
                                                                    .commentList[
                                                                        index]
                                                                    .roleId ==
                                                                "4"
                                                            ? "assets/profile/partner_img.png"
                                                            : 'assets/profile/user_on_user.png',
                                                        image: Constant
                                                                .IMAGE_PATH_SMALL +
                                                            userPostModal
                                                                .commentList[
                                                                    index]
                                                                .profilePicture,
                                                      ))),
                                                  onTap: () {
                                                    onTapImageTile(
                                                        userPostModal
                                                            .commentList[index]
                                                            .commentedBy,
                                                        userPostModal
                                                            .commentList[index]
                                                            .roleId);
                                                  }), // User Image
                                               SizedBox(
                                                width: 20.0,
                                              ),
                                               Expanded(
                                                child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(0, 0, 0, 0),
                                                      child:  Container(
                                                          child: Row(
                                                        children: <Widget>[
                                                          RichText(
                                                            maxLines: 2,
                                                            textAlign:
                                                                TextAlign.start,
                                                            text: TextSpan(
                                                              text: userPostModal
                                                                  .commentList[
                                                                      index]
                                                                  .name,
                                                              style:
                                                                   TextStyle(
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontSize: 14.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                              /* children: <TextSpan>[
                                                              TextSpan(
                                                                  text: userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .comment,
                                                                  style:  TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                        ],*/
                                                            ),
                                                          ),
                                                          userPostModal.commentList[
                                                                          index] !=
                                                                      null &&
                                                                  userPostModal
                                                                          .commentList[
                                                                              index]
                                                                          .roleId ==
                                                                      "1"
                                                              //true
                                                              ? Util.getStudentBadge12(
                                                                  userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .badge,
                                                                  userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .badgeImage)
                                                              : Container(
                                                                  height: 0.0,
                                                                  width: 0.0,
                                                                ),
                                                        ],
                                                      )),
                                                    ),
                                                     Container(
                                                      child: Linkify(
                                                        onOpen: (link) async {
                                                          print("onclick +++");

                                                          Navigator.push(
                                                              context,
                                                               MaterialPageRoute(
                                                                  //   builder: (context) =>  DashBoardWidget()));
                                                                  builder: (context) =>
                                                                       WebViewWidget(
                                                                          link.url,
                                                                          "spikeview")));
                                                        },
                                                        text: userPostModal
                                                            .commentList[index]
                                                            .comment,
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 14.0,
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                        linkStyle:  TextStyle(
                                                            color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR,
                                                            fontSize: 14.0),
                                                      ),
                                                    ),
                                                     Padding(
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                5.0,
                                                                0.0,
                                                                0.0),
                                                        child:  Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: <Widget>[
                                                             Expanded(
                                                              child:  Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: <
                                                                    Widget>[
                                                                   Text(
                                                                    userPostModal
                                                                        .commentList[
                                                                            index]
                                                                        .dateTime,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .end,
                                                                    style: TextStyle(
                                                                        color: ColorValues.GREY_TEXT_COLOR,
                                                                        fontSize:
                                                                            12.0,
                                                                        fontFamily:
                                                                            Constant.customRegular),
                                                                  )
                                                                ],
                                                              ),
                                                              flex: 0,
                                                            ),
                                                             Container(
                                                              width: 10.0,
                                                            ),
                                                             Expanded(
                                                              child: userIdPref ==
                                                                      userPostModal
                                                                          .commentList[
                                                                              index]
                                                                          .commentedBy
                                                                  ?  InkWell(
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            0,
                                                                            0,
                                                                            5),
                                                                        child:  Image
                                                                            .asset(
                                                                          "assets/profile/post/user_more1.png",
                                                                          width:
                                                                              25.0,
                                                                          height:
                                                                              25.0,
                                                                        ),
                                                                      ),
                                                                      onTap:
                                                                          () {
                                                                        optionForDelete(
                                                                            userPostModal.commentList,
                                                                            userPostModal.feedId,
                                                                            userPostModal,
                                                                            userPostModal.commentList[index].commentId);
                                                                      },
                                                                    )
                                                                  :  Container(
                                                                      height:
                                                                          1.0,
                                                                    ),
                                                              flex: 0,
                                                            )
                                                          ],
                                                        )),
                                                  ],
                                                ),
                                                flex: 1,
                                              ) // Comment List Cell
                                            ],
                                          ));
                                    }))),

                            // View All Comments
                            userPostModal.commentList.length > 3
                                ?  InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      0.0,
                                      0.0,
                                      5.0,
                                      TextViewWrap.textView(
                                          "View All " +
                                              userPostModal.commentList.length
                                                  .toString() +
                                              " Comments",
                                          TextAlign.left,
                                          ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          12.0,
                                          FontWeight.normal),
                                    ),
                                    onTap: () {
                                      onTapViewAllComments(
                                          userPostModal.commentList,
                                          userPostModal.feedId,
                                          userPostModal);
                                    },
                                  )
                                :  Container(
                                    height: 0.0,
                                  ),

                            // Comment Edit Text
                            userPostModal.isShowCommentIcon
                                ? PaddingWrap.paddingAll(
                                    10.0,
                                     Row(
                                      children: <Widget>[
                                        //Alok Code Done
                                         Container(
                                          width: 40.0,
                                          height: 40.0,
                                          child: ClipOval(
                                            child: FadeInImage.assetNetwork(
                                              fit: BoxFit.cover,
                                              placeholder: roleId == "4"
                                                  ? "assets/profile/partner_img.png"
                                                  : 'assets/profile/user_on_user.png',
                                              image: roleId == "4"
                                                  ? Constant.IMAGE_PATH +
                                                      companyPath
                                                  : Constant.IMAGE_PATH +
                                                      profilePath,
                                              height: 45.0,
                                              width: 45.0,
                                            ),
                                          ),
                                        ),
                                         SizedBox(
                                          width: 20.0,
                                        ),
                                         Expanded(
                                            child:  Container(
                                                decoration:  BoxDecoration(
                                                    border:  Border.all(
                                                        width: 1.0,
                                                        color:   ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                                child:  Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Expanded(
                                                      child:  TextField(
                                                        controller:
                                                            userPostModal
                                                                .txtController,
                                                        style:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),   keyboardType:
                                                            TextInputType.text,
                                                        textCapitalization:
                                                            TextCapitalization
                                                                .sentences,
                                                        maxLines: null,
                                                        maxLength: TextLength
                                                            .COMMENT_MAX_LENGTH,
                                                        onChanged: (s) {
                                                          if (s.trim().length >
                                                              0) {
                                                            userPostModal
                                                                    .isCommentIconVisible =
                                                                true;
                                                          } else {
                                                            userPostModal
                                                                    .isCommentIconVisible =
                                                                false;
                                                          }
                                                          setState(() {
                                                            userPostModal
                                                                .isCommentIconVisible;
                                                          });
                                                        },
                                                        decoration:
                                                             InputDecoration(
                                                          border:
                                                              InputBorder.none,
                                                          filled: true,
                                                          counterText: "",
                                                          hintText: roleId ==
                                                                  "4"
                                                              ? "Add Comment as " +
                                                                  prefs.getString(
                                                                      UserPreference
                                                                          .COMPANY_NAME_PATH)
                                                              : profileInfoModal
                                                                              .lastName ==
                                                                          "" ||
                                                                      profileInfoModal
                                                                              .lastName ==
                                                                          "null"
                                                                  ? "Add Comment as " +
                                                                      profileInfoModal
                                                                          .firstName
                                                                  : "Add Comment as " +
                                                                      profileInfoModal
                                                                          .firstName +
                                                                      " " +
                                                                      profileInfoModal
                                                                          .lastName,
                                                          hintStyle:  TextStyle(
                                                              color:   ColorValues.hintColor,
                                                              fontSize: 14.0,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                          fillColor: Colors
                                                              .transparent,
                                                        ),
                                                      ),
                                                      flex: 4,
                                                    ),
                                                     Expanded(
                                                      child:
                                                          /*userPostModal
                                                    .isCommentIconVisible
                                                ?*/
                                                           InkWell(
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                0.0,
                                                                5.0,
                                                                0.0,
                                                                 Image.asset(
                                                                  "assets/newDesignIcon/feed/send.png",
                                                                  width: 22.0,
                                                                  height: 22.0,
                                                                )),
                                                        onTap: () {
                                                          if (userPostModal
                                                              .isCommentIconVisible) {
                                                            FocusScope.of(
                                                                    context)
                                                                .requestFocus(
                                                                     FocusNode());
                                                            userPostModal
                                                                    .isCommentIconVisible =
                                                                false;
                                                            onAddComment(
                                                                userPostModal
                                                                    .feedId,
                                                                userPostModal
                                                                    .txtController
                                                                    .text,
                                                                userPostModal);
                                                            userPostModal
                                                                .txtController
                                                                .text = "";
                                                            setState(() {
                                                              userPostModal
                                                                  .txtController;
                                                              userPostModal
                                                                  .isCommentIconVisible;
                                                            });
                                                          }
                                                        },
                                                      )
                                                      /*:  Container(
                                                    height: 0.0,
                                                  )*/
                                                      ,
                                                      flex: 0,
                                                    )
                                                  ],
                                                )),
                                            flex: 1)
                                      ],
                                    ))
                                :  Container(
                                    height: 0.0,
                                  ),

                            (userPostList.length - 1) == index
                                ?  Container(
                                    height: 10.0,
                                  )
                                : PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    10.0,
                                     Divider(
                                      color: ColorValues.GREY_TEXT_COLOR,
                                      height: 1.0,
                                    ))
                          ],
                        ))
                  ])));
    }

    Future<Null> _refreshPageHere() async {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        // CustomProgressLoader.showLoader(context);

        setState(() {
          isLoadMore = true;
          offset = 0;
        });
        print("DateTime+++" + DateTime.now().millisecondsSinceEpoch.toString());
        await profileApi();
        await apiCallingForUserPost();
        print("DateTime+++" + DateTime.now().millisecondsSinceEpoch.toString());

        //CustomProgressLoader.cancelLoader(context);
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    }

    return MaterialApp(
        theme: ThemeData.light().copyWith(
          platform: TargetPlatform.android,
        ),
        home:  Scaffold(
            appBar: CustomViews.getAppBar(
                "Feed", widget._scaffoldKey, context, prefs, notificationCount),
            body:  RefreshIndicator(
                onRefresh: _refreshPageHere,
                displacement: 0.0,
                child:  Stack(children: <Widget>[
                  isLoading
                      ?  Container(
                          height: 0.0,
                        )
                      : userPostList.length > 0
                          ?  Positioned(
                              bottom: 0.0,
                              left: 0.0,
                              right: 0.0,
                              top: 0.0,
                              child:  KeyboardAvoider(
                                autoScroll: true,
                                child:  ListView.builder(
                                    controller: _scrollController,
                                    scrollDirection: Axis.vertical,
                                    itemCount: userPostList.length,
                                    padding:  EdgeInsets.all(0.0),
                                    itemBuilder:
                                        (BuildContext context, int position) {
                                      positionOfChild = position;
                                      if (userPostList.length - 1 == position) {
                                        ++offset;
                                        if (isLoadMore) if (!isLoadingData) {
                                          print("api calling data");
                                          apiCallingForUserPostLoadMore();
                                        }
                                      }
                                      if (userPostList[position]
                                          .isOpportunity) {
                                        if (userPostList[position].postOwner ==
                                            "null") {
                                          return getListViewForOpportunity(
                                              userPostList[position], position);
                                        } else {
                                          return getListViewPostForOpportuntiy(
                                              userPostList[position], position);
                                        }
                                      } else {
                                        if (userPostList[position].postOwner ==
                                            "null")
                                          return getListView(
                                              userPostList[position], position);
                                        else
                                          return getListViewPost(
                                              userPostList[position], position);
                                      }
                                    }),
                              ))
                          :  Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                profileInfoModal == null
                                    ?  Container(
                                        child:  Text(""),
                                      )
                                    : PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        80.0,
                                        0.0,
                                        18.0,
                                         Image.asset(
                                          "assets/newDesignIcon/group/feed_default.png",
                                          width: 79.0,
                                          height: 79.0,
                                        )),
                                TextViewWrap.textView(
                                    profileInfoModal == null
                                        ? ""
                                        : profileInfoModal.isActive == "true"
                                            ? "No feeds yet"
                                            : "No access yet",
                                    TextAlign.left,
                                     ColorValues.GREY_TEXT_COLOR,
                                    16.0,
                                    FontWeight.bold),
                                PaddingWrap.paddingfromLTRB(
                                    30.0,
                                    14.0,
                                    30.0,
                                    5.0,
                                    TextViewWrap.textViewMultiLine(
                                        profileInfoModal == null
                                            ? ""
                                            : profileInfoModal.isActive ==
                                                    "true"
                                                ? "Looks like you have no friends! As you add friends, their activity will appear."
                                                : "Your parents have deactivated your account. Please follow up with them.",
                                        TextAlign.center,
                                         ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal,
                                        4))
                              ],
                            ),
                  profileInfoModal != null &&
                          profileInfoModal.isActive == "true"
                      ? Positioned(
                          left: position.dx,
                          top: position.dy,
                          child: Draggable(
                              feedback: Container(
                                  height: 50.0,
                                  width: 50.0,
                                  child: FloatingActionButton(
                                      heroTag: "one",
                                      elevation: 0.0,
                                      backgroundColor:  ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                      child:  Icon(
                                        Icons.add,
                                        size: 24.0,
                                        color: Colors.white,
                                      ),
                                      onPressed: () {
                                        onTapAddPost("push");
                                      })),
                              child: Container(
                                height: 50.0,
                                width: 50.0,
                                child: FloatingActionButton(
                                    heroTag: "two",
                                    elevation: 0.0,
                                    backgroundColor:  ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                    child: Icon(
                                      Icons.add,
                                      size: 24.0,
                                      color: Colors.white,
                                    ),
                                    onPressed: () {
                                      onTapAddPost("push");
                                    }),
                              ),
                              childWhenDragging: Container(),
                              onDragEnd: (details) {
                                if (details.offset.dy > 50.0 &&
                                    details.offset.dy <
                                        (MediaQuery.of(context).size.height) -
                                            260.0) {
                                  setState(() {
                                    position = Offset(
                                        ((MediaQuery.of(context).size.width) -
                                            60.0),
                                        details.offset.dy);
                                  });
                                }
                                print(position);
                                print(details.offset.dx);
                                print(details.offset.dy);
                                print(MediaQuery.of(context).size.height);
                              }))
                      :  Container(
                          height: 0.0,
                        )
                ]))));
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;

  Widget getText(String s, Color color) {
    return Padding(
      padding: const EdgeInsets.only(left: 0.0),
      child:  Text(s,
          style: TextStyle(
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: color,
              fontSize: 14.0)),
    );
  }
}
