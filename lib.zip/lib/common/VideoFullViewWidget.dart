import 'dart:io';
import 'dart:typed_data';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:thumbnails/thumbnails.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:auto_orientation/auto_orientation.dart';

class VideoFullViewWidget extends StatefulWidget {
  String pageName;
  String appbarHeading;
  String file;

  VideoFullViewWidget(
      this.pageName,this.appbarHeading, this.file);

  @override
  State createState() {
    return  VideoFullViewWidgetState();
  }
}

class VideoFullViewWidgetState extends State<VideoFullViewWidget> {


  VideoFullViewWidgetState();

  double bottomPadding = 0.0;

  @override
  void initState() {
    super.initState();
    AutoOrientation.landscapeAutoMode();
  }

  @override
  Widget build(BuildContext context) {
    final double statusBarHeight = MediaQuery.of(context).padding.top;

    print('video widget.file::: ${widget.file}');
    return  Scaffold(

        backgroundColor:  Color(0xff101621),
        body: Container(
          color: Colors.black,
          child: Padding(
            padding: EdgeInsets.only(top: statusBarHeight),
            child: Stack(
              children: <Widget>[
                Center(
                    child:  Container(
                      color: Colors.black,


                      height: MediaQuery.of(context).size.height,
                      width: double.infinity,
                      child:  Center(
                        child:  VideoPlayPause(
                            widget.file, "", true),

                      ),
                    )),
                Positioned(
                  top: 0,
                  right: 0,
                  child:  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: FlatButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Image.asset(
                            'assets/preso_view_new/cross.png',
                            width: 40.0,
                            height: 40.0,
                          ))),
                ),
              ],
            ),
          ),
        ));
  }
}
