import 'dart:async';

import 'package:adhara_socket_io/manager.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/drawer/ProfileVisibilitySetting.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/OpportunityViewOnNotificationClick.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/notification/OpportunityForBoat.dart';
import 'package:spike_view_project/notification/model/NotificationModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parentProfile/RecommendationListForParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicViewForUser.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForBoatReview.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';

import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';

import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/widgets/positive_button.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/Company_Edit_Widget.dart';

class PartnerRejectionReason extends StatefulWidget {
  String isActive = "false", pageName;
  bool isPartnerApprovedByAdmin = false;

  PartnerRejectionReason(this.pageName, {this.isActive, this.isPartnerApprovedByAdmin});

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  PartnerRejectionReasonState();
  }
}

class PartnerRejectionReasonState extends State<PartnerRejectionReason> {
  List<NotificationModel> dataList =  List();
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isLoading = true;
  bool isDataLoading = false;
  ShareProfileModal shareProfileModal;
  bool isLoadMore = true;
  int offset = 0;
  CompanyProfileModel companyModel;

  String rejectionReason='';

  getSharedPreferences() async {
    setState(() {
      isDataLoading = true;
    });

    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    await companyInfoApi(true);
    setState(() {
      isDataLoading = false;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getSharedPreferences();
  }



  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    void onBack() {
      print('OnBack partner isDataLoading:: $isDataLoading');
      if (!isDataLoading) {
        if (widget.pageName == "main" ) {
          // For Partner DashBoard
          if (roleId == "1") {
            // For Studenet
            Navigator.pushReplacement(
              //Constant.applicationContext,
                context,
                 MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) =>  DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));
          } else if (roleId == "2") {
            Navigator.pushReplacement(
              //Constant.applicationContext,
                context,
                 MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) =>  DashBoardWidgetParent(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));

            // For Parent
          } else if (roleId == "4") {
            Navigator.pushReplacement(
              //Constant.applicationContext,
                context,
                 MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) =>  DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));

            // For Partner
          }
        } else {
          Navigator.pop(context);
        }
      } else {
      }
    }

    return   WillPopScope(
        onWillPop: () {
          if (!isDataLoading) {
            onBack();
          } else
            print("not perform");
              },

        child:customAppbar(
          context,
          GestureDetector(
              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20, top: 24, bottom: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox()
                          // BaseText(
                          //   text:"${opportunity.status} opportunity",
                          //   textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          //   fontFamily: AppConstants.stringConstant.latoMedium,
                          //   fontWeight: FontWeight.w700,
                          //   fontSize: 28,
                          //   textAlign: TextAlign.start,
                          //   maxLines: 3,
                          // ),
                        ],
                      ),
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Padding(
                        padding: const EdgeInsets.only(left: 20.0, right: 20),
                        child:SingleChildScrollView(
                          child: Container(
                            child:  Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [

                                      Text("Opportunity not approved",
                                        //: "College Counselling",
                                        style: TextStyle(
                                            fontSize: 28,
                                            fontFamily: Constant
                                                .customBold,
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1),
                                      ),


                                      SizedBox(height: 10,),



                                      Text(
                                        "Please see comments below, make the updates and resubmit for approval.",
                                        textAlign: TextAlign.start,
                                        style:  TextStyle(
                                            color:  ColorValues.labelColor,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily:Constant.latoRegular),
                                      ),

                                      SizedBox(height: 30,),

                                      Text(
                                        "Reason :",
                                        textAlign: TextAlign.left,
                                        style:  TextStyle(
                                            color:  ColorValues.labelColor,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: Constant.latoMedium),
                                      ),


                                      SizedBox(height: 10,),

                                      RichText(
                                        text:  TextSpan(
                                            text:rejectionReason.toString() != 'null' ? "$rejectionReason" :"" ,
                                            style:  TextStyle(
                                                fontSize: 14,
                                                fontFamily: Constant
                                                    .latoRegular,
                                                fontWeight: FontWeight.w500,
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1),
                                            children: [
                                              TextSpan(
                                                text: "",
                                              )
                                            ]),
                                      ),

                                      SizedBox(height: 30,),

                                      RichText(
                                        text:  TextSpan(
                                          text:"For additional questions email ",
                                          style:  TextStyle(
                                              fontSize: 14,
                                              fontFamily: Constant
                                                  .latoRegular,
                                              fontWeight: FontWeight.w500,
                                              color: ColorValues
                                                  .labelColor),
                                          children: <TextSpan>[
                                            TextSpan(
                                              text: "team@spikeview.com",
                                              style:  TextStyle(
                                                  color:  ColorValues.light_grey,
                                                  fontSize: 14.0,
                                                  fontFamily: Constant.latoSemibold),
                                            ),

                                          ],
                                        ),
                                      ),

                                      SizedBox(height: 100,),

                                      SizedBox(
                                        height: 44,
                                        child: PositiveButton(
                                          onTap: (){
                                            goToProfileUpdate();

                                          },
                                          // isEnable: true,
                                          isEnable: true,
                                          title: 'Edit Account' ,
                                        ),
                                      ),

                                    ],
                                  ),


                              ],
                            ),
                          ),
                        )
                    ),
                    flex: 1,
                  ),
                ],
              )),
              () {
            Navigator.pop(context);
          },
          isShowIcon: false,
        )
    );


    /* //old
    return  WillPopScope(
        onWillPop: () {
          if (!isDataLoading) {
           onBack();
          } else
            print("not perform");
        },
        child:  Scaffold(
            backgroundColor: Colors.white,
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,

              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    flex: 0,
                    child:  InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        if (!isDataLoading) {
                          onBack();
                        } else
                          print("not perform");
                      },
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Center(
                      child:  Image.asset(
                        "assets/newDesignIcon/blue_spike_logo.png",
                        width: 114.0,
                        height: 29.0,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 0,
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),),
                  ),
                ],
              ),

              backgroundColor: Colors.white,
              elevation: 0.0,
            ),
            body: Container(
              //color: Color(0xffDADADA),
              child: Column(
                children: <Widget>[
                  CustomViews.getSepratorLine(),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 0.0),
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [

                        Padding(
                          padding: const EdgeInsets.only(top: 20.0, bottom: 5.0),
                          child: Text(
                            "Partner Account not approved.",
                            textAlign: TextAlign.center,
                            style:  TextStyle(
                                color:  ColorValues.RADIO_BLACK,
                                fontSize: 18.0,
                                fontWeight: FontWeight.w600,
                                fontFamily:Constant.TYPE_CUSTOMREGULAR),
                          ),
                        ),
                        Text(
                          "Please see comments below, make the updates and resubmit for approval.",
                          textAlign: TextAlign.center,
                          style:  TextStyle(
                              color:  ColorValues.GREY__COLOR,
                              fontSize: 12.0,
                              fontWeight: FontWeight.w400,
                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 20.0, bottom: 0.0),
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            decoration:  BoxDecoration(
                              color: Colors.white,
                              border:  Border.all(
                                  color:  ColorValues.BORDER_COLOR, width: 1.0), ),
                            padding: const EdgeInsets.symmetric(horizontal: 13.0, vertical: 20.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(top: 0.0, bottom: 15.0),
                                child: Text(
                                  "Reason :",
                                  textAlign: TextAlign.left,
                                  style:  TextStyle(
                                      color:  ColorValues.RADIO_BLACK,
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w600,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                ),
                              ),
                              Text(
                                rejectionReason.toString() != 'null' ? "$rejectionReason" :"",
                                textAlign: TextAlign.left,
                                style:  TextStyle(
                                    color:  ColorValues.RADIO_BLACK,
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w400,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                              ),
                            ],
                          ),
                          ),

                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 10.0, bottom: 40.0),
                          child:  RichText(
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              text: 'For any further questions email ',
                              style:  TextStyle(
                                  color:  ColorValues.GREY__COLOR,
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.w400,
                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                              children: <TextSpan>[
                                TextSpan(
                                  text: 'team@spikeview.com',
                                  style:  TextStyle(
                                      color:  ColorValues.GREY__COLOR,
                                      fontSize: 12.0,
                                      fontWeight: FontWeight.bold,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                )
                              ],
                            ),
                          ),
                        ),

                        InkWell(
                          onTap: (){
                            goToProfileUpdate();
                          },
                          child:  Container(
                              height: 35.0,
                              //width: 226.0,
                              color:  ColorValues.BLUE_COLOR,
                              child:  Row(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .center,
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .center,
                                children: <Widget>[
                                   Text(
                                    "Edit Account",
                                    style:  TextStyle(
                                        color: Colors.white,
                                        fontFamily:
                                        Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 16.0,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  )
                                ],
                              )),
                        ),

                      ],
                    ),
                  ),
                ],
              ),
            )));

     */
  }

  Future companyInfoApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      print('Company APi:: ${Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=" + roleId}');
      Response response = await  ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=" + roleId,
          "get");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response comapny" + response.toString());
      print("response comapny userIdPref" + userIdPref + " &roleId " + roleId);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            var map = response.data['result'];
            if (map != null) {
              companyModel = ParseJson.parseCompanyInfoData(map);
              if (companyModel != null) {
                /*      prefs.setString(UserPreference.COMPANY_IMAGE_PATH,
                    companyModel.profilePicture);
                prefs.setString(
                    UserPreference.COMPANY_NAME_PATH, companyModel.name);
                syncDoneController.add("sucess");*/
                setState(() {
                  companyModel;
                  rejectionReason = companyModel.declineReason;
                });
              }
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future<void> goToProfileUpdate() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
         Company_Edit_Widget(userIdPref,pageName: "rejectionReason")));
  }
}
