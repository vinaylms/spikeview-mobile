import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/education/model/CollegeDegreeModel.dart';
import 'package:spike_view_project/education/model/CollegeInfoDetailModel.dart';
import 'package:spike_view_project/education/model/PursuingYearModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class AddEducationPerformance extends StatefulWidget {
  String dob, isActive, from;
  ProfileData profileInfoModal;

  AddEducationPerformance(
      this.dob, this.isActive, this.from, this.profileInfoModal);

  @override
  AddEducationState createState() {
    return AddEducationState(dob, isActive);
  }
}

class AddEducationState extends State<AddEducationPerformance> {
  final _formKey = GlobalKey<FormState>();
  String dob, isActive;

  List<String> gradualtionYearList = List();

  int selectedEduIndex = 0;

  String strMajor = '',
      strMinor = '',
      strOtherDegree = '',
      strProfessionCertificateDegree = '';

  //String degree = '',
  String graduationYear = 'Graduation Year';
  String strDegree = '', strDegreeYear = '', strGraduationYear = '';

  bool isOtherSelected = false;
  bool isProfessionalCertificatesSelected = false;

  CollegeDegreeModel collegeDegreeModel = CollegeDegreeModel();
  CollegeInfoDetailModel collegeInfoDetailModel = CollegeInfoDetailModel();
  PursuingYearModel pursuingYearModel = PursuingYearModel();

  List<CollegePursuingResult> pursuingYearList = List();
  List<CollegeDegreeResult> collegeDegreeList = List();
  List<CollegeInfoResult> collegeInfoList = List();

  bool isReadyForApiCall = false;
  String educationInit = 'School';
  bool isWeighted = false;

  TextEditingController otherDegreeController = TextEditingController(text: "");
  TextEditingController professionalCertificatesDegreeController =
      TextEditingController(text: "");
  TextEditingController majorController = TextEditingController(text: "");
  TextEditingController minorController = TextEditingController(text: "");
  TextEditingController obGpaController = TextEditingController(text: "");
  TextEditingController totGpaController = TextEditingController(text: "");

  String obtGPA = "";
  String totGPA = "";
  bool showCollege = true;
  AddEducationState(this.dob, this.isActive);

  String strAchievement,
      strFromDate,
      strToDate,
      strName,
      strEmail,
      strCity,
      strDeascription,
      grade1,
      strGrade1 = "",
      grade2,
      strGrade2 = "",
      year1,
      stryear1 = "",
      year2,
      stryear2 = "";
  SharedPreferences prefs;
  String strAzureUploadPath = "";
  List<OrganizationModal> organizationLst = List<OrganizationModal>();
  TextEditingController fromDateController, toDateController;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String userIdPref, token;
  final TextEditingController _searchQuery = TextEditingController();

  // final TextEditingController _searchQuerySchool = TextEditingController();
  List<String> yearList = List();
  List<String> toYearList = List();
  String sasToken, containerName;
  bool _IsSearching;
  bool isLoadMore = false;
  bool isAllDataLoaded = false;
  int skipIndex = 0;
  FocusNode gpaFocus = FocusNode();
  FocusNode togpaFocus = FocusNode();

  File imagePath;
  String selectedText = "";
  String _searchText = "",
      strOrganizationId = "",
      strInstiute = "",
      strOrganizationType = "School",
      strPrefixPathOrganization;
  double searchListHeight = 0.0;
  int searchListLength = 0;
  final List<String> _items = [
    'Select Grade',
    '1st',
    '2nd',
    '3rd',
    '4th',
    '5th',
    '6th',
    '7th',
    '8th',
    '9th',
    '10th',
    '11th',
    '12th',
  ].toList();
  final List<String> eduOptionList = [
    'School',
    'College',
  ].toList();
  BuildContext context;
  String isPerformChnges = "pop";
  bool isPresent = false;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    token = prefs.getString(UserPreference.USER_TOKEN);

    if (widget.from == '') {
      // recommendationApi();
      if (showCollege) {
        //  collegeInfoApi();
        collegeDegreeApi();
        collegePursuingApi();
      }
    } else if (widget.from == 'School') {
      // recommendationApi();
    } else {
      //collegeInfoApi();
      collegeDegreeApi();
      collegePursuingApi();
    }
    callApiForSaas();
    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_ORGANIZATION +
        "/";
    //anaylytics.setCurrentSreen(ScreenNameConstant.add_education);
  }

  Future collegeInfoApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context, Constant.ENDPOINT_COLLEGE_ORGANIZATION_LIST, "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              collegeInfoList.clear();
              collegeInfoDetailModel =
                  CollegeInfoDetailModel.fromJson(response.data);

              collegeInfoList.addAll(collegeInfoDetailModel.result);
              //collegeInfoList.insert(0,  CollegeInfoResult(degreeId: -1,name: "Degree"));

              setState(() {
                collegeInfoList;
              });
              print('collegeInfoList size:: ${collegeInfoList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEducationPerformance", context);
      e.toString();
    }
  }

  //call college degree list API
  Future collegeDegreeApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print('collegeDegreeApi() 111');
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_GET_DEGREE, "get");
        print('collegeDegreeApi() 222');
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              print('collegeDegreeApi() 333');
              collegeDegreeList.clear();
              collegeDegreeModel = CollegeDegreeModel.fromJson(response.data);

              collegeDegreeList.addAll(collegeDegreeModel.result);
              //collegeDegreeList.insert(0,  CollegeDegreeResult(degreeId: -1, name: "Degree"));

              setState(() {
                //collegeDegreeList = collegeDegreeList.reversed.toList();
                collegeDegreeList;
                if (collegeDegreeList.length > 0)
                  //strDegree = collegeDegreeList[0].name;
                  strDegree = null;
              });
              print('collegeDegreeModel size:: ${collegeDegreeList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEducationPerformance", context);
      e.toString();
    }
  }

  //call college pursuing list API
  Future collegePursuingApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_YEAR_LIST, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              pursuingYearList.clear();
              pursuingYearModel = PursuingYearModel.fromJson(response.data);
              pursuingYearList.addAll(pursuingYearModel.result);

              setState(() {
                //pursuingYearList = pursuingYearList.reversed.toList();
                pursuingYearList;
                if (pursuingYearList.length > 0)
                  //strDegreeYear = pursuingYearList[0].name;
                  strDegreeYear = null;
              });

              print('pursuingYearList size:: ${pursuingYearList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEducationPerformance", context);
      e.toString();
    }
  }

  //=========================================================Api Calling =======================================
  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEducationPerformance", context);
      e.toString();
    }
  }

  Future recommendationApiLoadMore() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": previousText,
          "type": educationInit,
          "skip": skipIndex,
        };
        print("data++++++searchText===" + map.toString());
        Response response = await ApiCalling2()
            .apiCallPostWithMapData(context, Constant.SCHOOL_SEACRH_API, map);
        print("data++++++searchText===" + response.toString());
        isLoadMore = false;
        _IsSearching = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var organizationLst1 = ParseJson.parseMapOrganization(
                  response.data['result'], educationInit);
              if (organizationLst1.length > 0) {
                setState(() {
                  organizationLst.addAll(organizationLst1);
                });
              }else{
                isAllDataLoaded = true;
              }
            }
          }
        }
        setState(() {});
      } else {
        isLoadMore = false;
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadMore = false;
      setState(() {});
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  //--------------------------Recommendation Info api ------------------
  Future recommendationApi(searchText, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": searchText,
          "type": type,
          "skip": skipIndex,
        };
        print("data++++++searchText===" + map.toString());
        Response response = await ApiCalling2()
            .apiCallPostWithMapData(context, Constant.SCHOOL_SEACRH_API, map);
        print("data++++++searchText===" + response.toString());

        _IsSearching = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              organizationLst.clear();
              organizationLst =
                  ParseJson.parseMapOrganization(response.data['result'], type);
              if (organizationLst.length > 0) {
                setState(() {
                  organizationLst;
                  print("List Lenght ---------" +
                      organizationLst.length.toString());
                });
              }
            }
          }
        }
        setState(() {});
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + strPrefixPathOrganization
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEducationPerformance", context);
      CustomProgressLoader.cancelLoader(context);
      return "";
    }
  }

  //--------------------------Upload Organization Data ------------------
  Future organizationApi(addIntoProfile) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //  CustomProgressLoader.showLoader(context);
        if (strAzureUploadPath != "") {
          strAzureUploadPath = strPrefixPathOrganization + strAzureUploadPath;
        }

        Map map;
        Response response;
        if (educationInit == "School") {
          map = {
            "userId": userIdPref,
            "organizationId": strOrganizationId ?? "",
            "logo": strAzureUploadPath,
            "institute": strInstiute.trim(),
            "city": strCity.trim(),
            "fromYear": year1,
            "toYear": year2,
            "fromGrade": grade1,
            "toGrade": grade2,
            "description": strDeascription,
            "isActive": isActive,
            "type": educationInit, //strOrganizationType,
            "gpa": obtGPA != '' ? double.parse(obtGPA) : '',
            "outOfGpa": totGPA != '' ? double.parse(totGPA) : '',
            "isWeighted": isWeighted,
            "certifications": "",
            "addIntoProfile": addIntoProfile
          };
          print("Education School map::::: " + map.toString());
          response = await ApiCalling2().apiCallPostWithMapData(
              context, Constant.ENDPOINT_ADD_ORGANIZATION, map);
        } else {
          map = {
            "userId": userIdPref,
            "organizationId": strOrganizationId ?? "",
            "logo": strAzureUploadPath,
            "institute": strInstiute.trim(),
            "city": strCity.trim(),
            "fromYear": year1,
            "toYear": year2,
            //"description": strDeascription,
            "isActive": isActive,
            "type": educationInit, //strOrganizationType, //"type":"College",
            "gpa": obtGPA != '' ? double.parse(obtGPA) : '',
            "outOfGpa": totGPA != '' ? double.parse(totGPA) : '',
            "isWeighted": isWeighted,
            "degree": strDegree,
            "otherDegree": strOtherDegree,
            "major": strMajor,
            "minor": strMinor,
            "year": strDegreeYear,
            "graduationYear": strGraduationYear,
            "certifications": strProfessionCertificateDegree,
            "addIntoProfile": addIntoProfile
          };

          print("Education College map::::: " + map.toString());
          response = await ApiCalling2().apiCallPostWithMapData(
              context, Constant.ENDPOINT_UPDATE_COLLEGE_INFO, map);
        }

        print("Education API response::::: " + response.toString());

        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        try {
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];

              if (status == "Success") {
                Navigator.pop(context, "push");
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(
              e, "AddEducationPerformance", context);
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEducationPerformance", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Timer _timer;
  String previousText = "";

  @override
  void initState() {
    // TODO: implement initState

    print("/////////////////////////dob////////"+dob.toString());

    DateTime date = DateTime.fromMillisecondsSinceEpoch(int.tryParse(dob));
    print("/////////////////////////dob////////"+date.toString());
    if (dob.toString() != 'null' && dob.toString() != '') {
      DateTime date = DateTime.fromMillisecondsSinceEpoch(int.tryParse(dob));

      //print('Apurva user age:: ${DateTime.now().year - date.year}');
      //if (Util.currentAge(date, 13) < 13) {
      if (!Util.dobCheck(widget.profileInfoModal.dob)) {
        setState(() {
          showCollege = false;
        });
      }
    }
    getSharedPreferences();

    if (widget.from != '') {
      setState(() {
        educationInit = widget.from;
      });
    }

    for (int i = date.year; i <= DateTime.now().year + 10; i++) {
      gradualtionYearList.add(i.toString());
    }
    gradualtionYearList.add("Graduation Year");
    setState(() {
      gradualtionYearList = gradualtionYearList.reversed.toList();
    });

    for (int i = date.year; i <= DateTime.now().year; i++) {
      yearList.add(i.toString());
    }
    yearList.add("Select Year");
    setState(() {
      yearList = yearList.reversed.toList();
    });

    for (int i = date.year; i <= (new DateTime.now().year + 10); i++) {
      toYearList.add(i.toString());
    }
    toYearList.add("Select Year");
    setState(() {
      toYearList = toYearList.reversed.toList();
    });
    print("Add education performance++++");
    _IsSearching = false;
    _searchQuery.addListener(() {
      if (_searchQuery.text.isEmpty) {
        setState(() {
          _IsSearching = false;
          _searchText = "";
          previousText = "";
          organizationLst.clear();
          collegeInfoList.clear();
        });
      } else {
        if (selectedText.trim() != _searchQuery.text.trim()) {
          if (_searchQuery.text.trim().length > 1) {
            if (educationInit == "School") {
              if (_timer != null) {
                print("data++++++timer cancel");
                _timer.cancel();
              }
              _timer = Timer(const Duration(milliseconds: 600), () {
                if (previousText.trim() != _searchQuery.text.trim()) {
                  previousText = _searchQuery.text;
                  if (!_IsSearching) {
                    _IsSearching = true;
                    skipIndex = 0;
                    isAllDataLoaded = false;
                    recommendationApi(_searchQuery.text.trim(), 'school');
                  }
                }
              });
            } else {
              if (_timer != null) {
                print("data++++++timer cancel");
                _timer.cancel();
              }
              _timer = Timer(const Duration(milliseconds: 600), () {
                if (previousText.trim() != _searchQuery.text.trim()) {
                  previousText = _searchQuery.text;
                  if (!_IsSearching) {
                    _IsSearching = true;
                    skipIndex = 0;
                    isAllDataLoaded = false;
                    recommendationApi(_searchQuery.text.trim(), 'college');
                  }
                }
              });
            }
          }
        }
      }
    });

    super.initState();
  }


  Future<Null> _cropImage(File imageFile) async {
    imagePath = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      ratioX: 2.0,
      ratioY: 2.0,
    );
  }

  @override
  Widget build(BuildContext context) {
    //-----------------------------------Image Selectio Ui nd core logic-------------------------------
    Constant.applicationContext = context;
    this.context = context;
    Future getImage(type) async {
      imagePath = await UploadMedia(context).pickImageFromGallery();
    //  imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null) {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);

        print("imagepath shubh" + strPath);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          print("img   :-" +
              imagePath
                  .toString()
                  .replaceAll("File: ", "")
                  .replaceAll("'", "")
                  .trim());
          if (imagePath != null) {
            //   await _cropImage(imagePath);
            setState(() {
              imagePath = imagePath;
            });
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    Widget imageSelectionView() {
      return Container(
        width: 113.0,
        height: 118.0,
        child: InkWell(
          child: Stack(
          children: <Widget>[
            Positioned(
                bottom: 5.0,
                left: 0.0,
                top: 0.0,
                right: 0.0,
                child: Center(
                    child: Container(
                  child: Image.asset(
                    "assets/profile/education_form_default.png",
                    fit: BoxFit.cover,
                  ),
                  width: 113.0,
                  height: 113.0,
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                ))),
            Positioned(
                bottom: 0.0,
                right: 0.0,
                child: InkWell(
                  child: Container(
                    //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                    child: Image.asset("assets/newDesignIcon/edit_img.png"),
                    height: 25.0,
                  ),
                  onTap: () async {
                    var status = await Permission.photos.status;
                    if (status.isGranted) {
                      getImage(ImageSource.gallery);
                    } else {
                      checkPermissionPhoto(context);
                    }
                  },
                ))
          ],
        ),onTap:  () async {
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getImage(ImageSource.gallery);
          } else {
            checkPermissionPhoto(context);
          }
        },)
      );
    }

    Widget isImageSelectedView() {
      return Container(
          width: 113.0,
          height: 118.0,
          child: InkWell(
          child:Stack(
            children: <Widget>[
              Positioned(
                  bottom: 5.0,
                  left: 0.0,
                  top: 0.0,
                  right: 0.0,
                  child: Center(
                      child: Container(
                    child: Image.file(
                      imagePath,
                      fit: BoxFit.cover,
                    ),
                    width: 113.0,
                    height: 113.0,
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                  ))),
              Positioned(
                  bottom: 0.0,
                  right: 0.0,
                  child: InkWell(
                    child: Container(
                      //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                      child: Image.asset("assets/newDesignIcon/edit_img.png"),
                      height: 25.0,
                    ),
                    onTap: () async {
                      var status = await Permission.photos.status;
                      if (status.isGranted) {
                        getImage(ImageSource.gallery);
                      } else {
                        checkPermissionPhoto(context);
                      }
                    },
                  ))
            ],
          ),onTap: () async{
            var status = await Permission.photos.status;
            if (status.isGranted) {
              getImage(ImageSource.gallery);
            } else {
              checkPermissionPhoto(context);
            }
          },));
    }

    //------------------------------------- Dropdown List for Grade & Year Spinner -------------------------
    final dropdownMenuGrade = _items
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: Text(
              item,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();

    //college degree year
    final dropdownCollegeYear = pursuingYearList
        .map((CollegePursuingResult item) => DropdownMenuItem<String>(
            value: item.name,
            child: Text(
              item.name,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();

    //college degree
    final dropdownCollegeDegree = collegeDegreeList
        .map((CollegeDegreeResult item) => DropdownMenuItem<String>(
            value: item.name,
            child: Text(
              item.name,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();

    //dropdown for school/college selection
    final dropdownMenuEducation = eduOptionList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: Text(
              item,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();
    final dropdownGraduationYear = gradualtionYearList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Text(
                  item,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ))))
        .toList();

    final dropdownMenuYear = yearList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Text(
                  item,
                  textAlign: TextAlign.start,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ))))
        .toList();

    final dropdownMenutoYear = toYearList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Text(
                  item,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ))))
        .toList();

    //------------------------------------------- Search LIst Ui  and Logic implementation ----------------------------
    List<InkWell> _buildSearchList() {
      return List.generate(organizationLst.length, (int index) {
        return InkWell(
            child: Column(
              children: <Widget>[
                ListTile(title: Text(organizationLst[index].name)),
                Divider(
                  color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                ),
                organizationLst.length > 20 &&
                        organizationLst.length - 1 == index
                    ? isLoadMore
                        ? Container(
                            child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation(
                                  ColorValues.BLUE_COLOR_BOTTOMBAR),
                              strokeWidth: 2.0,
                            ),
                          ))
                        :isAllDataLoaded?SizedBox(height: 0,): ListTile(
                            onTap: () {
                              skipIndex++;
                              setState(() {
                                isLoadMore = true;
                              });
                              recommendationApiLoadMore();
                            },
                            title: Text(
                              'View More',
                              style: TextStyle(
                                  color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                            ))
                    : SizedBox()
              ],
            ),
            onTap: () {
              setState(() {
                selectedText = organizationLst[index].name;
                _searchQuery.text = organizationLst[index].name;
                strOrganizationId = organizationLst[index].organizationId;
                strOrganizationType = organizationLst[index].type;
                _searchQuery.selection =
                    TextSelection.collapsed(offset: _searchQuery.text.length);
                organizationLst.clear();
                _IsSearching = false;
              });
            });
      });
    }

    List<InkWell> _buildSearchListCollege() {
      return List.generate(organizationLst.length, (int index) {
        return InkWell(
            child: Column(
              children: <Widget>[
                ListTile(title: Text(organizationLst[index].name)),
                Divider(
                  color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                ),
                organizationLst.length > 20 &&
                        organizationLst.length - 1 == index
                    ? isLoadMore
                        ? Container(
                            child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation(
                                  ColorValues.BLUE_COLOR_BOTTOMBAR),
                              strokeWidth: 2.0,
                            ),
                          ))
                        : isAllDataLoaded?SizedBox(height: 0,):ListTile(
                            onTap: () {
                              skipIndex++;
                              setState(() {
                                isLoadMore = true;
                              });
                              recommendationApiLoadMore();
                            },
                            title: Text(
                              'View More',
                              style: TextStyle(
                                  color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                            ))
                    : SizedBox()
              ],
            ),
            onTap: () {
              setState(() {
                selectedText = organizationLst[index].name;
                _searchQuery.text = organizationLst[index].name;
                strOrganizationId =
                    organizationLst[index].organizationId.toString();
                strOrganizationType = organizationLst[index].type;
                _searchQuery.selection =
                    TextSelection.collapsed(offset: _searchQuery.text.length);
                organizationLst.clear();
                _IsSearching = false;
              });
            });
      });
    }

    Container getOrganizationUi() {
      return Container(
          child: Column(
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
              13.0,
              50.0,
              13.0,
              0.0,
              TextFormField(
                  controller: _searchQuery,
                  maxLength: TextLength.SCHOOL_NAME_LENGTH,
                  autocorrect: false,
                  enableInteractiveSelection: false,
                  enableSuggestions: false,
                  cursorColor: Constant.CURSOR_COLOR,
                  keyboardType: TextInputType.visiblePassword,
                  // textCapitalization: TextCapitalization.sentences,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  onSaved: (String value) {
                    // firstName.text = value!;
                  },
                  validator: (val) => val.trim().length == 0
                      ? MessageConstant.ENTER_INSTITUTE_NAME_VAL
                      : /*!ValidationWidget.isSchoolName(val.trim())
                          ? MessageConstant.ENTER_INSTITUTE_NAME_VAL_School
                          : */
                      null,
                  decoration: InputDecoration(
                    hintText: 'Search School',
                    labelText: "School",
                    errorStyle: Util.errorTextStyle,
                    contentPadding:
                        const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                    enabledBorder: UnderlineInputBorder(
                      borderSide:
                          BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                    ),
                    counterStyle:
                        TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: ColorValues.DARK_GREY, width: 1.0)),
                    labelStyle: TextStyle(
                        color: ColorValues.GREY_TEXT_COLOR,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    counterText: "",
                    fillColor: Colors.transparent,
                  ))),
          _searchQuery.text.trim().length > 1
              ? PaddingWrap.paddingfromLTRB(
                  10.0,
                  0.0,
                  10.0,
                  0.0,
                  Container(
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: organizationLst.length > 0
                                  ? ColorValues.LIGHT_GREY_TEXT_COLOR
                                  : Colors.transparent,
                              width: 1.0)),
                      height: organizationLst.length == 0
                          ? 0.0
                          : organizationLst.length == 1
                              ? 70.0
                              : organizationLst.length == 2
                                  ? 145.0
                                  : organizationLst.length == 3 ? 220.0 : 300.0,
                      child: ListView(children: _buildSearchList())))
              : Container(
                  height: 0.0,
                )
        ],
      ));
    }

    Container getCollegeOrganizationUi() {
      return Container(
          child: Column(
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
              13.0,
              30.0,
              13.0,
              0.0,
              TextFormField(
                  controller: _searchQuery,
                  maxLength: 200,
                  maxLines: 1,
                  textCapitalization: TextCapitalization.sentences,
                  keyboardType: TextInputType.visiblePassword,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  validator: (val) => val.trim().isEmpty
                      ? educationInit == "School"
                          ? MessageConstant.ENTER_INSTITUTE_NAME_VAL
                          : MessageConstant.ENTER_College_NAME_VAL
                      : null,
                  decoration: InputDecoration(
                    enabledBorder: UnderlineInputBorder(
                      borderSide:
                          BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                    ),
                    counterStyle:
                        TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    focusedBorder: UnderlineInputBorder(
                      borderSide:
                          BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                    ),
                    hintText: 'Search College',
                    contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                    labelText: "College",
                    errorStyle: Util.errorTextStyle,
                    labelStyle: TextStyle(
                        color: ColorValues.GREY_TEXT_COLOR,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    counterText: "",
                    fillColor: Colors.transparent,
                  ))),
          _searchQuery.text.trim().length > 1
              ? PaddingWrap.paddingfromLTRB(
                  10.0,
                  0.0,
                  10.0,
                  0.0,
                  Container(
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: organizationLst.length > 0
                                  ? ColorValues.LIGHT_GREY_TEXT_COLOR
                                  : Colors.transparent,
                              width: 1.0)),
                      height: organizationLst.length == 0
                          ? 0.0
                          : organizationLst.length == 1
                              ? 70.0
                              : organizationLst.length == 2
                                  ? 145.0
                                  : organizationLst.length == 3 ? 220.0 : 300.0,
                      child: ListView(children: _buildSearchListCollege())))
              : Container()
        ],
      ));
    }

//-----------------------------------------------Spinner Ui Grade nd Year --------------------------------
    final gradeUi1 = PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        0.0,
        0.0,
        Container(
            height: 28.0,
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
            // padding:  EdgeInsets.fromLTRB(5.0, 0.0, 10.0, 0.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            width: double.infinity,
            child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                    hint: Text(
                      "Grade From",
                      style: TextStyle(
                          color: ColorValues.GREY_TEXT_COLOR,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                    value: grade1,
                    items: dropdownMenuGrade,
                    onChanged: (s) {
                      setState(() {
                        if (s != "Select Grade") {
                          FocusScope.of(context).requestFocus(new FocusNode());

                          grade1 = s;
                          strGrade1 = s;
                          grade2 = s;
                          strGrade2 = s;
                        }
                      });
                    }))));

    final gradeUi2 = PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        16.0,
        0.0,
        Container(
            height: 28.0,
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            width: double.infinity,
            child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                    hint: Text(
                      "Grade To",
                      style: TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          color: ColorValues.GREY_TEXT_COLOR),
                    ),
                    value: grade2,
                    items: dropdownMenuGrade,
                    onChanged: (s) {
                      if (grade1 == null) {
                        if (s == "Select Grade") {
                        } else {
                          ToastWrap.showToast(
                              MessageConstant.SELECT_GRADE_FROM_VAL, context);
                        }
                      } else {
                        String strg1 = grade1
                            .replaceAll("th", "")
                            .replaceAll("st", "")
                            .replaceAll("rd", "")
                            .replaceAll("nd", "");
                        String strg2 = s
                            .replaceAll("th", "")
                            .replaceAll("st", "")
                            .replaceAll("rd", "")
                            .replaceAll("nd", "");
                        if (int.parse(strg1) <=
                            int.parse(strg2.replaceAll("th", ""))) {
                          setState(() {
                            FocusScope.of(context)
                                .requestFocus(new FocusNode());

                            grade2 = s;
                            strGrade2 = s;
                          });
                        } else {
                          ToastWrap.showToast(
                              MessageConstant.TO_GRADE_LESS_THAN_FROM_GRADE_VAL,
                              context);
                        }
                      }
                    }))));

    final yearUi1 = Container(
        height: 28.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
                hint: Text(
                  "Date From",
                  style: TextStyle(
                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      color: ColorValues.GREY_TEXT_COLOR),
                ),
                value: year1,
                items: dropdownMenuYear,
                onChanged: (s) {
                  if (grade2 == null && educationInit == "School") {
                    ToastWrap.showToast(
                        MessageConstant.SELECT_GRADE_FROM_VAL, context);
                  } else {
                    setState(() {
                      FocusScope.of(context).requestFocus(new FocusNode());
                      if (stryear2 != "") {
                        if (int.parse(s) > int.parse(stryear2)) {
                          ToastWrap.showToast(
                              MessageConstant
                                  .FROM_DATE_SMALLER_THAN_TO_DATE_VAL,
                              context);
                        } else {
                          year1 = s;
                          stryear1 = s;
                        }
                      } else {
                        year1 = s;
                        stryear1 = s;
                      }
                    });
                  }
                })));

    final yearUi2 = PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        16.0,
        0.0,
        Container(
            height: 28.0,
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            width: double.infinity,
            child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                    hint: Text(
                      "Date To",
                      style: TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          color: ColorValues.GREY_TEXT_COLOR),
                    ),
                    value: year2,
                    items: dropdownMenutoYear,
                    onChanged: (s) {
                      if (year1 == null) {
                        ToastWrap.showToast(
                            MessageConstant.SELECT_FROM_DATE_VAL, context);
                      } else {
                        if (int.parse(year1) <= int.parse(s)) {
                          setState(() {
                            FocusScope.of(context)
                                .requestFocus(new FocusNode());
                            isPresent = false;
                            year2 = s;
                            stryear2 = s;
                          });
                        } else {
                          ToastWrap.showToast(
                              MessageConstant.TO_DATE_GRATER_THAN_FROM_DATE_VAL,
                              context);
                        }
                      }
                    }))));

//-------------------------------------Text Input Fields Ui -----------------------------------
    final eduSelectionUI = PaddingWrap.paddingfromLTRB(
        13.0,
        0.0,
        13.0,
        0.0,
        Container(
            height: 50.0,
            padding: EdgeInsets.fromLTRB(13.0, 0.0, 10.0, 0.0),
            decoration: BoxDecoration(
                color: ColorValues.WHITE,
                border: Border.all(
                    //BorderSide(
                    color: ColorValues.DARK_GREY,
                    width: 1.0
                    //)
                    )),
            width: double.infinity,
            child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                    hint: Text(
                      "School",
                      style: TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          fontSize: 16,
                          color: ColorValues.HEADING_COLOR_EDUCATION),
                    ),
                    value: educationInit,
                    items: dropdownMenuEducation,
                    onChanged: (s) {
                      //get selected index
                      educationInit = s;
                      setState(() {
                        educationInit;
                        _formKey.currentState.reset();
                      });
                    }))));
    final cityUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              maxLength: 200,
              keyboardType: TextInputType.visiblePassword,
              cursorColor: Constant.CURSOR_COLOR,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                hintText: 'e.g.,  York',
                labelText: "City",
                errorStyle: Util.errorTextStyle,
                contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                counterStyle:
                    TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                focusedBorder: UnderlineInputBorder(
                    borderSide:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) =>
                  val.trim().isEmpty ? MessageConstant.ENTER_CITY_VAL : null,
              onSaved: (val) => strCity = val,
            )));

    final otherDegreeUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              maxLength: 100,
              controller: otherDegreeController,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                counterStyle:
                    TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'Other',
                errorStyle: Util.errorTextStyle,
                labelText: "Other",
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) => val.trim().isEmpty
                  ? MessageConstant.SELECT_Other_DEGREE_VAL
                  : null,
              onSaved: (val) => strOtherDegree = val,
            )));

    final professionalCertificatesDegreeUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              maxLength: 200,
              controller: professionalCertificatesDegreeController,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                counterStyle:
                    TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'Certification Name',
                errorStyle: Util.errorTextStyle,
                labelText: "Certification Name",
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) => val.trim().isEmpty
                  ? MessageConstant.SELECT_professional_Certificates_DEGREE_VAL
                  : null,
              onSaved: (val) => strProfessionCertificateDegree = val,
            )));
    final majorUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              maxLength: 200,
              controller: majorController,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                counterStyle:
                    TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'Major',
                labelText: "Major",
                errorStyle: Util.errorTextStyle,
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) => strDegree != null &&
                      strDegree != '' &&
                      strDegree != 'null' &&
                      val.trim().isEmpty
                  ? MessageConstant.SELECT_MAJOR_VAL
                  : null,
              onSaved: (val) => strMajor = val,
            )));
    final minorUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              maxLength: 200,
              controller: minorController,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                counterStyle:
                    TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'Minor',
                labelText: "Minor",
                errorStyle: Util.errorTextStyle,
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              onSaved: (val) => strMinor = val,
            )));

    final gpaFieldUi = PaddingWrap.paddingfromLTRB(
        13.0,
        0.0,
        0.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              textInputAction: TextInputAction.done,

              maxLength: 10,
              focusNode: gpaFocus,
              controller: obGpaController,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              inputFormatters: [
                WhitelistingTextInputFormatter(RegExp(r'^\d+\.?\d{0,2}')),
              ],
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                counterStyle:
                    TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'GPA',
                labelText: "GPA",
                errorStyle: Util.errorTextStyle,
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) {
                return val
                    .trim()
                    .length == 0
                    ? null
                    : !ValidationWidget.isValidaGPA(val)
                    ? MessageConstant.ENTER_gpa_out_of_less
                    : null ;
              },
              onSaved: (val) => obtGPA = val,
            )));

    final totalFieldUi = PaddingWrap.paddingfromLTRB(
        6.0,
        0.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              textInputAction: TextInputAction.done,
              maxLength: 10,
              controller: totGpaController,
              focusNode: togpaFocus,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                counterStyle:
                    TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: '',
                labelText: "GPA Out of",
                errorStyle: Util.errorTextStyle,
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              onSaved: (val) => totGPA = val,
            )));
    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        textAlign: TextAlign.start,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final degreeUi = PaddingWrap.paddingfromLTRB(
        13.0,
        20.0,
        13.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            strDegree == null
                ? Container(
                    height: 10.0,
                  )
                : PaddingWrap.paddingfromLTRB(
                    0.0,
                    10.0,
                    0.0,
                    0.0,
                    getTextLabel("Degree", 11.0, ColorValues.GREY_TEXT_COLOR,
                        FontWeight.normal)),
            Container(
                height: 28.0,
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: ColorValues.DARK_GREY, width: 1.0))),
                width: double.infinity,
                child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                        //isExpanded: true,
                        hint: Text(
                          "Degree",
                          style: TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: ColorValues.GREY_TEXT_COLOR),
                        ),
                        value: strDegree,
                        items: dropdownCollegeDegree,
                        onChanged: (s) {
                          setState(() {
                            FocusScope.of(context)
                                .requestFocus(new FocusNode());
                            strDegree = s;
                            //degree = s;
                            if (s == 'Other') {
                              isOtherSelected = true;
                              isProfessionalCertificatesSelected = false;
                            } else if (s == 'Professional Certificate') {
                              isOtherSelected = false;
                              isProfessionalCertificatesSelected = true;
                            } else {
                              isOtherSelected = false;
                              isProfessionalCertificatesSelected = false;
                            }
                          });
                        }))),
          ],
        ));

    final degreeYearUi = PaddingWrap.paddingfromLTRB(
        13.0,
        20.0,
        13.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            strDegreeYear == null
                ? Container(
                    height: 10.0,
                  )
                : PaddingWrap.paddingfromLTRB(
                    0.0,
                    10.0,
                    0.0,
                    0.0,
                    getTextLabel("Class", 11.0, ColorValues.GREY_TEXT_COLOR,
                        FontWeight.normal)),
            Container(
                height: 28.0,
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: ColorValues.DARK_GREY, width: 1.0))),
                width: double.infinity,
                child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                        hint: Text(
                          "Class",
                          style: TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: ColorValues.GREY_TEXT_COLOR),
                        ),
                        value: strDegreeYear,
                        items: dropdownCollegeYear,
                        onChanged: (s) {
                          setState(() {
                            strDegreeYear = s;
                          });
                        }))),
          ],
        ));

    final graduationYearUi = PaddingWrap.paddingfromLTRB(
        13.0,
        0.0,
        13.0,
        20.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            strGraduationYear != '' && strGraduationYear != 'Graduation Year'
                ? getTextLabel("Graduation Year", 11.0,
                    ColorValues.GREY_TEXT_COLOR, FontWeight.normal)
                : getTextLabel(
                    "", 11.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal),
            Container(
                height: 28.0,
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: ColorValues.DARK_GREY, width: 1.0))),
                width: double.infinity,
                child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                        hint: Text(
                          "Graduation Year",
                          style: TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: ColorValues.GREY_TEXT_COLOR),
                        ),
                        value: graduationYear,
                        items: dropdownGraduationYear,
                        onChanged: (s) {
                          setState(() {
                            FocusScope.of(context)
                                .requestFocus(new FocusNode());
                            graduationYear = s;
                            strGraduationYear = s;
                          });
                        }))),
          ],
        ));

    final getDateFromToUI = PaddingWrap.paddingfromLTRB(
        13.0,
        20.0,
        0.0,
        0.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          mainAxisAlignment: MainAxisAlignment.start,
          textBaseline: TextBaseline.ideographic,
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  year1 != null
                      ? getTextLabel("Date From", 11.0,
                          ColorValues.GREY_TEXT_COLOR, FontWeight.normal)
                      : getTextLabel("", 11.0, ColorValues.GREY_TEXT_COLOR,
                          FontWeight.normal),
                  yearUi1
                ],
              ),
              flex: 4,
            ),
            Expanded(
              child: Container(),
              flex: 1,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  year2 != null
                      ? getTextLabel("Date To", 11.0,
                          ColorValues.GREY_TEXT_COLOR, FontWeight.normal)
                      : getTextLabel("", 11.0, ColorValues.GREY_TEXT_COLOR,
                          FontWeight.normal),
                  yearUi2
                ],
              ),
              flex: 4,
            ),
          ],
        ));

    final getDateFromToCheckbox = PaddingWrap.paddingfromLTRB(
        0.0,
        8.0,
        0.0,
        0.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[],
              ),
              flex: 5,
            ),
            Expanded(
              child: Container(),
              flex: 1,
            ),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: Padding(
                          padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                          child: Image.asset(
                            isPresent
                                ? "assets/newDesignIcon/login/check.png"
                                : "assets/newDesignIcon/login/uncheck.png",
                            width: 25.0,
                            height: 25.0,
                          )),
                      onTap: () {
                        if (isPresent)
                          isPresent = false;
                        else
                          isPresent = true;
                        setState(() {
                          isPresent;
                          year2 = null;
                          stryear2 = "";
                        });
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0.0, 3.0, 0.0, 0.0),
                      child: Container(
                          child: TextViewWrap.textView(
                              "Ongoing   ",
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              16.0,
                              FontWeight.normal)),
                    ),
                    flex: 0,
                  )
                ],
              ),
              flex: 5,
            )
          ],
        ));

    final getCGPAUI = PaddingWrap.paddingfromLTRB(
        0.0,
        20.0,
        0.0,
        20.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          mainAxisAlignment: MainAxisAlignment.start,
          textBaseline: TextBaseline.ideographic,
          children: <Widget>[
            Expanded(
              child: gpaFieldUi,
              flex: 4,
            ),
            Expanded(
              child: Container(),
              flex: 1,
            ),
            Expanded(
              child: totalFieldUi,//totalFieldUi,
              flex: 4,
            ),
          ],
        ));

    final getCGPAWeightCheckbox = PaddingWrap.paddingfromLTRB(
        0.0,
        8.0,
        0.0,
        30.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[],
              ),
              flex: 5,
            ),
            Expanded(
              child: Container(),
              flex: 1,
            ),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: Padding(
                          padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                          child: Image.asset(
                            isWeighted
                                ? "assets/newDesignIcon/login/check.png"
                                : "assets/newDesignIcon/login/uncheck.png",
                            width: 25.0,
                            height: 25.0,
                          )),
                      onTap: () {
                        if (isWeighted)
                          isWeighted = false;
                        else
                          isWeighted = true;
                        setState(() {
                          isWeighted;
                        });
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0.0, 3.0, 0.0, 0.0),
                      child: Container(
                          child: TextViewWrap.textView(
                              "Weighted",
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              16.0,
                              FontWeight.normal)),
                    ),
                    flex: 0,
                  )
                ],
              ),
              flex: 5,
            )
          ],
        ));
    //------------------------------------Button Ui nd Logic Implementation-----------------------------
    bool validatioCheck() {
      if (strInstiute.length <= 0) {
        ToastWrap.showToast(MessageConstant.ENTER_INSTITUTE_NAME_VAL, context);
        isReadyForApiCall = false;
        return false;
      } else if (stryear1 == "" || stryear1 == "Select Year") {
        ToastWrap.showToast(MessageConstant.SELECT_YEAR_VAL, context);
        isReadyForApiCall = false;
        return false;
      } else if ((stryear2 == "" || stryear2 == "Select Year") &&
          (!isPresent)) {
        ToastWrap.showToast(MessageConstant.SELECT_YEAR_VAL, context);
        isReadyForApiCall = false;
        return false;
      } else if (educationInit == "School") {
        if (strGrade1 == "" || strGrade1 == "Select Grade") {
          ToastWrap.showToast(MessageConstant.SELECT_GRAD_VAL, context);
          isReadyForApiCall = false;
          return false;
        } else if (strGrade2 == "" || strGrade2 == "Select Grade") {
          ToastWrap.showToast(MessageConstant.SELECT_GRAD_VAL, context);
          isReadyForApiCall = false;
          return false;
        }
      } else {
        if (strDegreeYear == "" || strDegreeYear == null) {
          ToastWrap.showToast(MessageConstant.SELECT_degree_year_VAL, context);
          isReadyForApiCall = false;
          return false;
        }
      }

      isReadyForApiCall = true;
      return true;
    }

    void conformationDialogForCommunityPost() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      "Do you want to publish this school information to your public profile?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "No",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                CustomProgressLoader.showLoader(
                                                    context);
                                                organizationApi(false);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Yes",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                CustomProgressLoader.showLoader(
                                                    context);
                                                organizationApi(true);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void _checkValidation() async {
      strInstiute = _searchQuery.text.trim();
      final form = _formKey.currentState;
      form.save();
      if (form.validate()) {
        if (validatioCheck()) {
          try {
            if (imagePath != null) {
              Timer _timer = Timer(const Duration(milliseconds: 400), () async {
                strAzureUploadPath = await uploadImgOnAzure(imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim());

                if (Util.dobCheck(widget.profileInfoModal.dob) &&
                    widget.profileInfoModal.publicUrl != null &&
                    widget.profileInfoModal.publicUrl != "null" &&
                    widget.profileInfoModal.publicUrl != "") {
                  conformationDialogForCommunityPost();
                } else {
                  CustomProgressLoader.showLoader(context);
                  organizationApi(false);
                }
              });
              // organizationApi();
            } else {
              if (Util.dobCheck(widget.profileInfoModal.dob) &&
                  widget.profileInfoModal.publicUrl != null &&
                  widget.profileInfoModal.publicUrl != "null" &&
                  widget.profileInfoModal.publicUrl != "") {
                conformationDialogForCommunityPost();
              } else {
                CustomProgressLoader.showLoader(context);
                organizationApi(false);
              }
              // CustomProgressLoader.showLoader(context);

            }
          } catch (e) {
            crashlytics_bloc.recordCrashlyticsError(
                e, "AddEducationPerformance", context);
          }
        }
      } else {
        print("Failure 00");
      }
    }

    getSchoolView() {
      return PaddingWrap.paddingfromLTRB(
          0.0,
          10.0,
          0.0,
          10.0,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              PaddingWrap.paddingfromLTRB(
                  13.0,
                  10.0,
                  0.0,
                  0.0,
                  Container(
                      width: 125.0,
                      child: imagePath == null
                          ? imageSelectionView()
                          : isImageSelectedView())),
              getOrganizationUi(),

              cityUi,
              //descriptrionUi,
              //get
              PaddingWrap.paddingfromLTRB(
                  13.0,
                  20.0,
                  0.0,
                  0.0,
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            grade1 != null
                                ? getTextLabel(
                                    "Grade From",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal)
                                : getTextLabel(
                                    "",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal),
                            gradeUi1
                          ],
                        ),
                        flex: 4,
                      ),
                      Expanded(
                        child: Container(),
                        flex: 1,
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            grade2 != null
                                ? getTextLabel(
                                    "Grade To",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal)
                                : getTextLabel(
                                    "",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal),
                            gradeUi2
                          ],
                        ),
                        flex: 4,
                      ),
                    ],
                  )),
              getDateFromToUI,
              getDateFromToCheckbox,

              getCGPAUI,
              getCGPAWeightCheckbox,

            ],
          ));
    }

    getCollegeView() {
      return PaddingWrap.paddingfromLTRB(
          0.0,
          10.0,
          0.0,
          10.0,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              PaddingWrap.paddingfromLTRB(
                  13.0,
                  10.0,
                  0.0,
                  0.0,
                  Container(
                      width: 125.0,
                      child: imagePath == null
                          ? imageSelectionView()
                          : isImageSelectedView())),
              getCollegeOrganizationUi(),

              cityUi,
              //descriptrionUi,

              //Degree
              degreeUi,
              isOtherSelected ? otherDegreeUi : Container(),
              isProfessionalCertificatesSelected
                  ? professionalCertificatesDegreeUi
                  : Container(),

              //major and minor
              !isProfessionalCertificatesSelected ? majorUi : Container(),
              !isProfessionalCertificatesSelected ? minorUi : Container(),
              degreeYearUi,

              //Date UI
              getDateFromToUI,
              getDateFromToCheckbox,

              //GPA UI
              getCGPAUI,
              getCGPAWeightCheckbox,

              graduationYearUi,
            ],
          ));
    }

    //-------------------------------------Main Ui ------------------------------------------
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: Scaffold(
            backgroundColor: ColorValues.SCREEN_BG_COLOR,
            appBar: AppBar(
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              elevation: 0.0,
              title: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                            Center(
                                child: Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Text(
                      "Education",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          13.0,
                          0.0,
                          TextViewWrap.textView(
                              "Save",
                              TextAlign.start,
                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                              16.0,
                              FontWeight.normal)),
                      onTap: () {
                        _checkValidation();
                      },
                    )
                  ],
                )
              ],
              backgroundColor: Colors.white,
            ),
            body: FormKeyboardActions(
                nextFocus: false,
                keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                //optional
                keyboardBarColor: Colors.grey[200],
                //optional
                actions: [
                  KeyboardAction(
                    focusNode: gpaFocus,
                  ),
                  KeyboardAction(
                    focusNode: togpaFocus,
                  ),
                ],
                child: Theme(
                    data: ThemeData(hintColor: Colors.grey[300]),
                    child: Column(
                      children: <Widget>[
                        CustomViews.getSepratorLine(),
                        Expanded(
                            child: ListView(
                          children: <Widget>[
                            widget.from == '' && showCollege
                                ? Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 40.0, 13.0, 10.0),
                                          child: Text(
                                            //"Select Education",
                                            "I want to add",
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                fontFamily:
                                                    Constant.customRegular,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.normal,
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION),
                                          )),

                                      //add education selection dropdown
                                      eduSelectionUI,
                                    ],
                                  )
                                : Container(),
                            Form(
                              key: _formKey,
                              autovalidate: false,
                              child: educationInit == "School"
                                  ? getSchoolView()
                                  : getCollegeView(),
                            )
                          ],
                        ))
                      ],
                    )))));
  }
}
