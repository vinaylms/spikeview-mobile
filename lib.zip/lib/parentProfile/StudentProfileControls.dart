import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/ProfileVisibilitySetting.dart';
import 'package:spike_view_project/gateway/ChangePassword.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/EditParentProfile.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/Company_Edit_Widget.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class StudentProfilControl extends StatefulWidget {
  StudentDataModel mStudentDataModel;

  StudentProfilControl(this.mStudentDataModel);

  @override
  StudentProfilControlState createState() =>  StudentProfilControlState();
}

class StudentProfilControlState extends State<StudentProfilControl> {
  String isPerformChanges = "pop", userIdPref,roleId, dob = "0", isHide = "";
  int diffrenceInDob;
  SharedPreferences prefs;
  bool isSelectedAllNotification = true;
  bool isSelectedProfile = true;
  bool isSelectedFeed = true;
  bool isLoading = true;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    dob = prefs.getString(UserPreference.DOB);
    isHide = prefs.getString(UserPreference.ISHide);


    fetchPSetting();
  }
  ProfileInfoModal profileInfoModal;

  Future profileApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);
        Response response = await  ApiCalling2().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO +widget. mStudentDataModel.userId + "/false", "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                if (mounted) {

                setState(() {
                  profileInfoModal;
                });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++" + e.toString());
    }
  }

  Future fetchPSetting() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        Response response = await  ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_GET_NOTIFICATION_SETTING +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");
        print("response data" + response.toString());
        isLoading = false;
        setState(() {
          isLoading;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              isSelectedFeed = response.data["data"][0]['feedNotification'];
              isSelectedProfile =
                  response.data["data"][0]['profileNotification'];
              isSelectedAllNotification =
                  response.data["data"][0]['allNotification'];
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    super.initState();
  }

  int dobCheck(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      DateTime now =  DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(now, 18);

      print("diffrenceInDob++++" + diffrenceInDob.toString());
      return diffrenceInDob;
    } else {
      return 0;
    }
  }

  showSucessMsg(msg, context, duration, maxLine) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(Duration(milliseconds: duration), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: maxLine == 2 ? 65.0 : 85.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: maxLine,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  Future apiCallingForCommunitySetting(userId, value) async {
    try {
      Response response;

      Map map = {
        "userId": int.parse(userId),
        "roleId": 1,
        "isSubscribed": value
      };
      print("map:-" + map.toString());

      response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_COMMUNITY_SETTING, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            widget.mStudentDataModel.isSubScribeCommunityPost = value;
            isPerformChanges = "push";
           // showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForPreLogin(userId, value) async {
    try {
      Response response;

      Map map = {
        "userId": int.parse(userId),
        "roleId": 1,
        "isLeaderboardDisplay": value
      };
      print("map:-" + map.toString());

      response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_LEADERBOARD_SETTING, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isPerformChanges = "push";
            widget.mStudentDataModel.isLeaderboardDisplay = value;

           // showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------Api Calling for update user Status ------------------
  Future apiCallingForUpdateStudentStatus(userId, isActive, flag) async {
    try {
      Response response;

      Map map = {
        "userId": userId,
        "isActive": isActive,
        "parentApprovalFlag": flag,
        "parentId": int.parse(userIdPref)
      };

      response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_PARENT_PERSONAL_UPDATEUSER_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isPerformChanges = "push";
            prefs.setString(UserPreference.PATH_PARENT, "");
           /* if (flag) {
              showSucessMsg(msg, context, 2000, 3);
            } else {
              showSucessMsg(msg, context, 3000, 2);
            }*/
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForUpdateStudentHideStatus(userId, isHide) async {
    try {
      Response response;

      Map map = {
        "userId": userId,
        "isHide": isHide,
        "parentId": int.parse(userIdPref)
      };

      response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_PARENT_PERSONAL_UPDATEUSER_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isPerformChanges = "push";
            showSucessMsg(msg, context, 3000, 2);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build


    return GestureDetector(
        child: WillPopScope(
            onWillPop: () {
              Navigator.pop(context, isPerformChanges);
            },
            child: GestureDetector(
                child: customAppbar(
                    context,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(
                                left: 20.0, right: 20, top: 24, bottom: 0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                BaseText(
                                  text: 'Settings',
                                  textColor:
                                  ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 28,
                                  textAlign: TextAlign.start,
                                  maxLines: 3,
                                ),

                              ],
                            ),
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              5.0,
                              isLoading
                                  ?  Container()
                                  :  Container(
                                  child:  ListView(
                                    children: <Widget>[
                                      Column(
                                        children: <Widget>[
                                          Container(
                                            margin: EdgeInsets.only(left: 20, right: 20, top: 0,bottom: 0),
                                            decoration: BoxDecoration(
                                              color: ColorValues.SELECTION_BG,
                                              border: Border.all(
                                                color: ColorValues.SELECTION_BG,
                                                width: 1.0,
                                              ),
                                              borderRadius:
                                              BorderRadius.circular(10),
                                            ),
                                            child: PaddingWrap.paddingfromLTRB(
                                                12.0,
                                                10.0,
                                                12.0,
                                                10.0,
                                                Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(
                                                            left: 0, top: 0, right: 0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.start,
                                                          children: <Widget>[
                                                            Text(
                                                                "Communication and collaboration features",
                                                                style: TextStyle(
                                                                    fontSize: 14,
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontWeight:
                                                                    FontWeight.w500,
                                                                    fontFamily: Constant
                                                                        .latoMedium)),
                                                            SizedBox(
                                                              height: 5,
                                                            ),
                                                            Text(
                                                                "This toggle controls your child’s’ access to the following features: Activity Feed, Group, Chat, & Connections.",
                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                    fontSize: 12,
                                                                    fontWeight:
                                                                    FontWeight.w400,
                                                                    color: ColorValues
                                                                        .TEXT_HEADER,
                                                                    fontFamily: Constant
                                                                        .latoRegular)),
                                                          ],
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                        child: Padding(
                                                            padding: const EdgeInsets.only(
                                                                left: 0, top: 10, right: 0),
                                                            child: widget.mStudentDataModel
                                                                .isActive ==
                                                                "true"
                                                                ?  GestureDetector(
                                                                onHorizontalDragEnd:
                                                                    (DragEndDetails
                                                                details) {
                                                                  setState(() {
                                                                    widget
                                                                        .mStudentDataModel
                                                                        .isActive = "false";

                                                                    apiCallingForUpdateStudentStatus(
                                                                        widget
                                                                            .mStudentDataModel
                                                                            .userId,
                                                                        false,
                                                                        false);
                                                                  });
                                                                },onTap:(){
                                                              setState(() {
                                                                widget
                                                                    .mStudentDataModel
                                                                    .isActive = "false";

                                                                apiCallingForUpdateStudentStatus(
                                                                    widget
                                                                        .mStudentDataModel
                                                                        .userId,
                                                                    false,
                                                                    false);
                                                              });
                                                            },
                                                                child:  Center(
                                                                    child:  Padding(
                                                                        padding:  EdgeInsets
                                                                            .fromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        child:  Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/active_new.png",
                                                                          width: 30.0,
                                                                          height: 16.0,
                                                                        ))))
                                                                :  GestureDetector(
                                                                onHorizontalDragEnd:
                                                                    (DragEndDetails
                                                                details) {
                                                                  setState(() {
                                                                    widget
                                                                        .mStudentDataModel
                                                                        .isActive = "true";
                                                                    apiCallingForUpdateStudentStatus(
                                                                        widget
                                                                            .mStudentDataModel
                                                                            .userId,
                                                                        true,
                                                                        false);
                                                                  });
                                                                },onTap:(){
                                                              setState(() {
                                                                widget
                                                                    .mStudentDataModel
                                                                    .isActive = "true";
                                                                apiCallingForUpdateStudentStatus(
                                                                    widget
                                                                        .mStudentDataModel
                                                                        .userId,
                                                                    true,
                                                                    false);
                                                              });
                                                            },
                                                                child:  Center(
                                                                    child:  Padding(
                                                                        padding:
                                                                        EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        child:  Image.asset(
                                                                          "assets/newDesignIcon/inactive_new.png",
                                                                          width: 30.0,
                                                                          height: 16.0,
                                                                        ))))),
                                                        flex: 0),
                                                  ],
                                                )),
                                          ),


                                          dobCheck(widget.mStudentDataModel.dob) >= 18
                                              ?  Container(
                                            height: 0.0,
                                          )
                                              : Container(
                                            margin: EdgeInsets.only(left: 20, right: 20, top: 12,bottom: 0),
                                            decoration: BoxDecoration(
                                              color: ColorValues.SELECTION_BG,
                                              border: Border.all(
                                                color: ColorValues.SELECTION_BG,
                                                width: 1.0,
                                              ),
                                              borderRadius:
                                              BorderRadius.circular(10),
                                            ),
                                            child: PaddingWrap.paddingfromLTRB(
                                                12.0,
                                                10.0,
                                                12.0,
                                                10.0,
                                                Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(
                                                            left: 0, top: 0, right: 0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.start,
                                                          children: <Widget>[
                                                            Text(
                                                                "Make profile details visible to childs’ connections",
                                                                style: TextStyle(
                                                                    fontSize: 14,
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontWeight:
                                                                    FontWeight.w500,
                                                                    fontFamily: Constant
                                                                        .latoMedium)),
                                                            SizedBox(
                                                              height: 5,
                                                            ),
                                                            Text(
                                                                "This toggle controls whether those you have approved as your child’s spikeview Connections are able to view the childs’ Profile details (spider chart, accomplishments, recommendations, etc) on the profile or not. These Profile details are never accessible to any users who are not Connections.",
                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                    fontSize: 12,
                                                                    fontWeight:
                                                                    FontWeight.w400,
                                                                    color: ColorValues
                                                                        .TEXT_HEADER,
                                                                    fontFamily: Constant
                                                                        .latoRegular)),
                                                          ],
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                        child: Padding(
                                                            padding: const EdgeInsets.only(
                                                                left: 0, top: 10, right: 0),
                                                            child: widget
                                                                .mStudentDataModel
                                                                .isHide ==
                                                                "false"
                                                                ?  GestureDetector(
                                                                onHorizontalDragEnd:
                                                                    (DragEndDetails
                                                                details) {
                                                                  setState(() {
                                                                    widget.mStudentDataModel
                                                                        .isHide =
                                                                    "true";
                                                                    print("hide++++" +
                                                                        true.toString());
                                                                    apiCallingForUpdateStudentHideStatus(
                                                                        widget
                                                                            .mStudentDataModel
                                                                            .userId,
                                                                        true);
                                                                  });
                                                                },onTap:(){
                                                              setState(() {
                                                                widget.mStudentDataModel
                                                                    .isHide =
                                                                "true";
                                                                print("hide++++" +
                                                                    true.toString());
                                                                apiCallingForUpdateStudentHideStatus(
                                                                    widget
                                                                        .mStudentDataModel
                                                                        .userId,
                                                                    true);
                                                              });
                                                            },
                                                                child:  Center(
                                                                    child:  Padding(
                                                                        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                                        child:  Image.asset(
                                                                          "assets/newDesignIcon/active_new.png",
                                                                          width: 30.0,
                                                                          height: 16.0,
                                                                        ))))
                                                                :  GestureDetector(
                                                                onHorizontalDragEnd: (DragEndDetails details) {
                                                                  setState(() {
                                                                    widget.mStudentDataModel
                                                                        .isHide =
                                                                    "false";
                                                                    print("hide++++" +
                                                                        false
                                                                            .toString());
                                                                    apiCallingForUpdateStudentHideStatus(
                                                                        widget
                                                                            .mStudentDataModel
                                                                            .userId,
                                                                        false);
                                                                  });
                                                                },onTap:(){
                                                              setState(() {
                                                                widget.mStudentDataModel
                                                                    .isHide =
                                                                "false";
                                                                print("hide++++" +
                                                                    false
                                                                        .toString());
                                                                apiCallingForUpdateStudentHideStatus(
                                                                    widget
                                                                        .mStudentDataModel
                                                                        .userId,
                                                                    false);
                                                              });
                                                            },
                                                                child:  Center(
                                                                    child:  Padding(
                                                                        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                                        child:  Image.asset(
                                                                          "assets/newDesignIcon/inactive_new.png",
                                                                          width: 30.0,
                                                                          height: 16.0,
                                                                        ))))),
                                                        flex: 0),
                                                  ],
                                                )),
                                          ),



                                          dobCheck(widget.mStudentDataModel.dob) >= 18
                                              ?  Container(
                                            height: 0.0,
                                          )
                                              : Container(
                                            margin: EdgeInsets.only(left: 20, right: 20, top: 12,bottom: 0),
                                            decoration: BoxDecoration(
                                              color: ColorValues.SELECTION_BG,
                                              border: Border.all(
                                                color: ColorValues.SELECTION_BG,
                                                width: 1.0,
                                              ),
                                              borderRadius:
                                              BorderRadius.circular(10),
                                            ),
                                            child: PaddingWrap.paddingfromLTRB(
                                                12.0,
                                                10.0,
                                                12.0,
                                                10.0,
                                                Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(
                                                            left: 0, top: 0, right: 0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.start,
                                                          children: <Widget>[
                                                            Text(
                                                                "Community post",
                                                                style: TextStyle(
                                                                    fontSize: 14,
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontWeight:
                                                                    FontWeight.w500,
                                                                    fontFamily: Constant
                                                                        .latoMedium)),
                                                            SizedBox(
                                                              height: 5,
                                                            ),
                                                            Text(
                                                                'Enables students to post to all spikeview members.',

                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                    fontSize: 12,
                                                                    fontWeight:
                                                                    FontWeight.w400,
                                                                    color: ColorValues
                                                                        .TEXT_HEADER,
                                                                    fontFamily: Constant
                                                                        .latoRegular)),
                                                          ],
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                        child: Padding(
                                                            padding: const EdgeInsets.only(
                                                                left: 0, top: 10, right: 0),
                                                            child: widget
                                                                .mStudentDataModel
                                                                .isSubScribeCommunityPost
                                                                ?  GestureDetector(
                                                                onHorizontalDragEnd:
                                                                    (DragEndDetails
                                                                details) {
                                                                  setState(() {
                                                                    print("hide++++" +
                                                                        true.toString());

                                                                    apiCallingForCommunitySetting(
                                                                        widget
                                                                            .mStudentDataModel
                                                                            .userId,
                                                                        false);
                                                                  });
                                                                },onTap:(){
                                                              setState(() {
                                                                print("hide++++" +
                                                                    true.toString());

                                                                apiCallingForCommunitySetting(
                                                                    widget
                                                                        .mStudentDataModel
                                                                        .userId,
                                                                    false);
                                                              });
                                                            },
                                                                child:  Center(
                                                                    child:  Padding(
                                                                        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                                        child:  Image.asset(
                                                                          "assets/newDesignIcon/active_new.png",
                                                                          width: 30.0,
                                                                          height: 16.0,
                                                                        ))))
                                                                :  GestureDetector(
                                                                onHorizontalDragEnd: (DragEndDetails details) {
                                                                  setState(() {
                                                                    print("hide++++" +
                                                                        false
                                                                            .toString());
                                                                    apiCallingForCommunitySetting(
                                                                        widget
                                                                            .mStudentDataModel
                                                                            .userId,
                                                                        true);
                                                                  });
                                                                },onTap:(){
                                                              setState(() {
                                                                print("hide++++" +
                                                                    false
                                                                        .toString());
                                                                apiCallingForCommunitySetting(
                                                                    widget
                                                                        .mStudentDataModel
                                                                        .userId,
                                                                    true);
                                                              });
                                                            },
                                                                child:  Center(
                                                                    child:  Padding(
                                                                        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                                        child:  Image.asset(
                                                                          "assets/newDesignIcon/inactive_new.png",
                                                                          width: 30.0,
                                                                          height: 16.0,
                                                                        ))))),
                                                        flex: 0),
                                                  ],
                                                )),
                                          ),



                                        ],
                                      ),

                                      Util.  dobCheck(widget.mStudentDataModel.dob) ?  Container(height:0.0): InkWell(
                                        child:  Container(
                                            margin: EdgeInsets.only(left: 20, right: 20, top: 12,bottom: 0),
                                            decoration: BoxDecoration(
                                              color: ColorValues.SELECTION_BG,
                                              border: Border.all(
                                                color: ColorValues.SELECTION_BG,
                                                width: 1.0,
                                              ),
                                              borderRadius:
                                              BorderRadius.circular(10),
                                            ),
                                            child: PaddingWrap.paddingfromLTRB(
                                                12.0,
                                                10.0,
                                                12.0,
                                                10.0,
                                                Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(
                                                            left: 0, top: 0, right: 0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.start,
                                                          children: <Widget>[
                                                            Text(
                                                                "Profile visibility",
                                                                style: TextStyle(
                                                                    fontSize: 14,
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontWeight:
                                                                    FontWeight.w500,
                                                                    fontFamily: Constant
                                                                        .latoMedium)),
                                                            SizedBox(
                                                              height: 5,
                                                            ),
                                                            Text(
                                                                "Configure your child's profile visibility.",

                                                                textAlign: TextAlign.left,
                                                                style: TextStyle(
                                                                    fontSize: 12,
                                                                    fontWeight:
                                                                    FontWeight.w400,
                                                                    color: ColorValues
                                                                        .TEXT_HEADER,
                                                                    fontFamily: Constant
                                                                        .latoRegular)),
                                                          ],
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                        child: Padding(
                                                            padding: const EdgeInsets.only(
                                                                left: 0, top: 10, right: 0),
                                                            child: Image.asset(
                                                              "assets/newDesignIcon/icon/arrow_left.png",
                                                              height: 18.0,
                                                            )),
                                                        flex: 0),
                                                  ],
                                                ))),onTap: () async{
                                        String result=await     Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>  ProfileVisibilitySetting(widget.mStudentDataModel.userId,true)),

                                        );

                                        if (result == "push") {
                                          Navigator.pop(context, "push");
                                        }
                                      },
                                      ),



                                    ],
                                  ))),
                          flex: 1,
                        ),

                      ],
                    ), () {
                  Navigator.pop(context);
                }, isShowIcon: false))));

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child:  Scaffold(
          appBar:  AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                 InkWell(
                  child:  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "assets/newDesignIcon/navigation/back.png",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),
                  ),
                  onTap: () {
                    Navigator.pop(context, isPerformChanges);
                  },
                )
              ],
            ),
            title:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                 Text(
                  "Settings",
                  style:  TextStyle(
                      fontSize: 18.0,
                      fontFamily: Constant.customRegular,
                      color:  ColorValues.HEADING_COLOR_EDUCATION),
                )
              ],
            ),
            actions: <Widget>[
               Container(
                width: 35.0,
              ),
            ],
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
          backgroundColor: ColorValues.WHITE,
          body: isLoading
              ?  Container()
              :  Container(
                  child:  Column(
                  children: <Widget>[
                     Expanded(
                      child: CustomViews.getSepratorLine(),
                      flex: 0,
                    ),
                     Expanded(
                      flex: 1,
                      child: ListView(
                        children: <Widget>[
                           Column(
                            children: <Widget>[
                              Container(
                                margin: EdgeInsets.only(left: 20, right: 20, top: 12,bottom: 0),
                                decoration: BoxDecoration(
                                  color: ColorValues.SELECTION_BG,
                                  border: Border.all(
                                    color: ColorValues.SELECTION_BG,
                                    width: 1.0,
                                  ),
                                  borderRadius:
                                  BorderRadius.circular(10),
                                ),
                                child: PaddingWrap.paddingfromLTRB(
                                    12.0,
                                    10.0,
                                    12.0,
                                    10.0,
                                     Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 0, top: 0, right: 0),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                    "Communication and Collaboration Features",
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontWeight:
                                                        FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoMedium)),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                    "This toggle controls your child’s’ access to the following features: Activity Feed, Group, Chat, & Connections.",
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                        fontSize: 12,
                                                        fontWeight:
                                                        FontWeight.w400,
                                                        color: ColorValues
                                                            .TEXT_HEADER,
                                                        fontFamily: Constant
                                                            .latoRegular)),
                                              ],
                                            ),
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                            child: Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 0, top: 10, right: 0),
                                                child: widget.mStudentDataModel
                                                            .isActive ==
                                                        "true"
                                                    ?  GestureDetector(
                                                        onHorizontalDragEnd:
                                                            (DragEndDetails
                                                                details) {
                                                          setState(() {
                                                            widget
                                                                .mStudentDataModel
                                                                .isActive = "false";

                                                            apiCallingForUpdateStudentStatus(
                                                                widget
                                                                    .mStudentDataModel
                                                                    .userId,
                                                                false,
                                                                false);
                                                          });
                                                        },onTap:(){
                                                  setState(() {
                                                    widget
                                                        .mStudentDataModel
                                                        .isActive = "false";

                                                    apiCallingForUpdateStudentStatus(
                                                        widget
                                                            .mStudentDataModel
                                                            .userId,
                                                        false,
                                                        false);
                                                  });
                                                },
                                                        child:  Center(
                                                            child:  Padding(
                                                                padding:  EdgeInsets
                                                                        .fromLTRB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                                child:  Image
                                                                    .asset(
                                                                  "assets/newDesignIcon/active_new.png",
                                                                  width: 30.0,
                                                                  height: 16.0,
                                                                ))))
                                                    :  GestureDetector(
                                                        onHorizontalDragEnd:
                                                            (DragEndDetails
                                                                details) {
                                                          setState(() {
                                                            widget
                                                                .mStudentDataModel
                                                                .isActive = "true";
                                                            apiCallingForUpdateStudentStatus(
                                                                widget
                                                                    .mStudentDataModel
                                                                    .userId,
                                                                true,
                                                                false);
                                                          });
                                                        },onTap:(){
                                                  setState(() {
                                                    widget
                                                        .mStudentDataModel
                                                        .isActive = "true";
                                                    apiCallingForUpdateStudentStatus(
                                                        widget
                                                            .mStudentDataModel
                                                            .userId,
                                                        true,
                                                        false);
                                                  });
                                                },
                                                        child:  Center(
                                                            child:  Padding(
                                                                padding:
                                                                     EdgeInsets.fromLTRB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        0.0),
                                                                child:  Image.asset(
                                                                  "assets/newDesignIcon/inactive_new.png",
                                                                  width: 30.0,
                                                                  height: 16.0,
                                                                ))))),
                                            flex: 0),
                                      ],
                                    )),
                              ),


                              dobCheck(widget.mStudentDataModel.dob) >= 18
                                  ?  Container(
                                height: 0.0,
                              )
                                  : Container(
                                margin: EdgeInsets.only(left: 20, right: 20, top: 12,bottom: 0),
                                decoration: BoxDecoration(
                                  color: ColorValues.SELECTION_BG,
                                  border: Border.all(
                                    color: ColorValues.SELECTION_BG,
                                    width: 1.0,
                                  ),
                                  borderRadius:
                                  BorderRadius.circular(10),
                                ),
                                child: PaddingWrap.paddingfromLTRB(
                                    12.0,
                                    10.0,
                                    12.0,
                                    10.0,
                                     Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 0, top: 0, right: 0),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                    "Make Profile Details Visible To Childs’ Connections",
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontWeight:
                                                        FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoMedium)),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                    "This toggle controls whether those you have approved as your child’s spikeview Connections are able to view the childs’ Profile details (spider chart, accomplishments, recommendations, etc) on the profile or not. These Profile details are never accessible to any users who are not Connections.",
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                        fontSize: 12,
                                                        fontWeight:
                                                        FontWeight.w400,
                                                        color: ColorValues
                                                            .TEXT_HEADER,
                                                        fontFamily: Constant
                                                            .latoRegular)),
                                              ],
                                            ),
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                            child: Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 0, top: 10, right: 0),
                                                child: widget
                                                    .mStudentDataModel
                                                    .isHide ==
                                                    "false"
                                                    ?  GestureDetector(
                                                    onHorizontalDragEnd:
                                                        (DragEndDetails
                                                    details) {
                                                      setState(() {
                                                        widget.mStudentDataModel
                                                            .isHide =
                                                        "true";
                                                        print("hide++++" +
                                                            true.toString());
                                                        apiCallingForUpdateStudentHideStatus(
                                                            widget
                                                                .mStudentDataModel
                                                                .userId,
                                                            true);
                                                      });
                                                    },onTap:(){
                                                  setState(() {
                                                    widget.mStudentDataModel
                                                        .isHide =
                                                    "true";
                                                    print("hide++++" +
                                                        true.toString());
                                                    apiCallingForUpdateStudentHideStatus(
                                                        widget
                                                            .mStudentDataModel
                                                            .userId,
                                                        true);
                                                  });
                                                },
                                                    child:  Center(
                                                        child:  Padding(
                                                            padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                            child:  Image.asset(
                                                              "assets/newDesignIcon/active_new.png",
                                                              width: 30.0,
                                                              height: 16.0,
                                                            ))))
                                                    :  GestureDetector(
                                                    onHorizontalDragEnd: (DragEndDetails details) {
                                                      setState(() {
                                                        widget.mStudentDataModel
                                                            .isHide =
                                                        "false";
                                                        print("hide++++" +
                                                            false
                                                                .toString());
                                                        apiCallingForUpdateStudentHideStatus(
                                                            widget
                                                                .mStudentDataModel
                                                                .userId,
                                                            false);
                                                      });
                                                    },onTap:(){
                                                  setState(() {
                                                    widget.mStudentDataModel
                                                        .isHide =
                                                    "false";
                                                    print("hide++++" +
                                                        false
                                                            .toString());
                                                    apiCallingForUpdateStudentHideStatus(
                                                        widget
                                                            .mStudentDataModel
                                                            .userId,
                                                        false);
                                                  });
                                                },
                                                    child:  Center(
                                                        child:  Padding(
                                                            padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                            child:  Image.asset(
                                                              "assets/newDesignIcon/inactive_new.png",
                                                              width: 30.0,
                                                              height: 16.0,
                                                            ))))),
                                            flex: 0),
                                      ],
                                    )),
                              ),



                              dobCheck(widget.mStudentDataModel.dob) >= 18
                                  ?  Container(
                                height: 0.0,
                              )
                                  : Container(
                                margin: EdgeInsets.only(left: 20, right: 20, top: 12,bottom: 0),
                                decoration: BoxDecoration(
                                  color: ColorValues.SELECTION_BG,
                                  border: Border.all(
                                    color: ColorValues.SELECTION_BG,
                                    width: 1.0,
                                  ),
                                  borderRadius:
                                  BorderRadius.circular(10),
                                ),
                                child: PaddingWrap.paddingfromLTRB(
                                    12.0,
                                    10.0,
                                    12.0,
                                    10.0,
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 0, top: 0, right: 0),
                                            child: Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                    "Community Post",
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontWeight:
                                                        FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoMedium)),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                    'Enables students to post to all spikeview members.',

                                                textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                        fontSize: 12,
                                                        fontWeight:
                                                        FontWeight.w400,
                                                        color: ColorValues
                                                            .TEXT_HEADER,
                                                        fontFamily: Constant
                                                            .latoRegular)),
                                              ],
                                            ),
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                            child: Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 0, top: 10, right: 0),
                                                child: widget
                                                    .mStudentDataModel
                                                    .isSubScribeCommunityPost
                                                    ?  GestureDetector(
                                                    onHorizontalDragEnd:
                                                        (DragEndDetails
                                                    details) {
                                                      setState(() {
                                                        print("hide++++" +
                                                            true.toString());

                                                        apiCallingForCommunitySetting(
                                                            widget
                                                                .mStudentDataModel
                                                                .userId,
                                                            false);
                                                      });
                                                    },onTap:(){
                                                  setState(() {
                                                    print("hide++++" +
                                                        true.toString());

                                                    apiCallingForCommunitySetting(
                                                        widget
                                                            .mStudentDataModel
                                                            .userId,
                                                        false);
                                                  });
                                                },
                                                    child:  Center(
                                                        child:  Padding(
                                                            padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                            child:  Image.asset(
                                                              "assets/newDesignIcon/active_new.png",
                                                              width: 30.0,
                                                              height: 16.0,
                                                            ))))
                                                    :  GestureDetector(
                                                    onHorizontalDragEnd: (DragEndDetails details) {
                                                      setState(() {
                                                        print("hide++++" +
                                                            false
                                                                .toString());
                                                        apiCallingForCommunitySetting(
                                                            widget
                                                                .mStudentDataModel
                                                                .userId,
                                                            true);
                                                      });
                                                    },onTap:(){
                                                  setState(() {
                                                    print("hide++++" +
                                                        false
                                                            .toString());
                                                    apiCallingForCommunitySetting(
                                                        widget
                                                            .mStudentDataModel
                                                            .userId,
                                                        true);
                                                  });
                                                },
                                                    child:  Center(
                                                        child:  Padding(
                                                            padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                            child:  Image.asset(
                                                              "assets/newDesignIcon/inactive_new.png",
                                                              width: 30.0,
                                                              height: 16.0,
                                                            ))))),
                                            flex: 0),
                                      ],
                                    )),
                              ),



                            ],
                          ),

                          Util.  dobCheck(widget.mStudentDataModel.dob) ?  Container(height:0.0): InkWell(
                            child:  Container(
                            margin: EdgeInsets.only(left: 20, right: 20, top: 12,bottom: 0),
                            decoration: BoxDecoration(
                              color: ColorValues.SELECTION_BG,
                              border: Border.all(
                                color: ColorValues.SELECTION_BG,
                                width: 1.0,
                              ),
                              borderRadius:
                              BorderRadius.circular(10),
                            ),
                            child: PaddingWrap.paddingfromLTRB(
                                12.0,
                                10.0,
                                12.0,
                                10.0,
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 0, right: 0),
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                                "Profile Visiblity",
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoMedium)),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                                "Configure your child's profile visibility.",

                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight:
                                                    FontWeight.w400,
                                                    color: ColorValues
                                                        .TEXT_HEADER,
                                                    fontFamily: Constant
                                                        .latoRegular)),
                                          ],
                                        ),
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                        child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 0, top: 10, right: 0),
                                            child: Image.asset(
                                              "assets/newDesignIcon/icon/arrow_left.png",
                                              height: 18.0,
                                            )),
                                        flex: 0),
                                  ],
                                ))),onTap: () async{
                            String result=await     Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>  ProfileVisibilitySetting(widget.mStudentDataModel.userId,true)),

                            );

                            if (result == "push") {
                              Navigator.pop(context, "push");
                            }
                          },
                          ),



                        ],
                      ),
                    )
                  ],
                )),
        ));
  }
}
