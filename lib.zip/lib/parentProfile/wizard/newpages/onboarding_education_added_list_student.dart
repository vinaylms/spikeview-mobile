import 'dart:convert';
import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/new_onboarding/All_education_list_model.dart';

import 'package:spike_view_project/new_onboarding/PrimaryEducation.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

import 'AddEducationWidgetParentChild.dart';
import 'onboarding_child_edit_education.dart';
import 'onboarding_child_interest_widget.dart';

class EducationAddedWeightParentChild extends StatefulWidget {
  const EducationAddedWeightParentChild({
    this.studModel,
    this.screenName,
    this.userId,
    Key key,
  }) : super(key: key);

  final StudentDataModel studModel;
  final String screenName;
  final String userId;

  @override
  EducationAddedWeightParentChildStateWeight createState() {
    return EducationAddedWeightParentChildStateWeight();
  }
}

class EducationAddedWeightParentChildStateWeight
    extends State<EducationAddedWeightParentChild> {
  SharedPreferences prefs;
  String userIdPref = "";
  int diffrenceInDob = 14;
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    if (widget.userId != null) {
      userIdPref = widget.userId;
    }
    if (widget.studModel.dob != null && widget.studModel.dob != 'null') {
      int millis = int.tryParse(widget.studModel.dob);
      DateTime dobDate =  DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(dobDate, 13);
    }
    setState(() {
    });
    ApiGetAllEducationList();
  }

  bool btn = false;
  int listLengh = -1;
  AllEducationListModel allEducationList;

  List<PrimaryEducation> mPrimaryEducationList = [];
  List<PrimaryEducation> mMiddleEducationList = [];
  List<PrimaryEducation> mHighEducationList = [];
  List<PrimaryEducation> mCollegeEducationList = [];
  List<PrimaryEducation> mAllEducationList = [];

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  getEducationRange(index){
    try {
      return  mAllEducationList[
      index]
          .fromYear +
          "-" +
          mAllEducationList[
          index]
              .toYear
              .substring(mAllEducationList[
          index]
              .toYear
              .length -
              2);
    }catch(e){
      return  mAllEducationList[
      index]
          .fromYear;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorValues.WHITE,
      body: PaddingWrap.paddingfromLTRB(
          20.0,
          50.0,
          20.0,
          0.0,
          SingleChildScrollView(
              child: Container(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    BaseText(
                      text: MessageConstant.EDUCATION_HEDING,
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      maxLines: 1,
                    ),
                    const HelpButtonWidget(),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Align(
                  alignment: Alignment.topLeft,
                  child: BaseText(
                    textAlign: TextAlign.start,
                    text: AppConstants
                        .stringConstant.str_education_list_subtitle,
                    textColor: AppConstants.colorStyle.lightPurple,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                    maxLines: 1,
                  ),
                ),
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    20.0,
                    0.0,
                    85.0,
                    ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return Row(
                            children: [
                              Expanded(
                                child: Column(
                                  children: [
                                    Container(
                                        padding: const EdgeInsets.only(
                                            bottom: 0, top: 0, left: 0),
                                        height: 50,
                                        child: VerticalDivider(
                                            color: index == 0
                                                ? Colors.transparent
                                                : AppConstants
                                                    .colorStyle.btnBg)),
                                    Container(
                                      // height: 20,
                                      margin: const EdgeInsets.only(
                                          right: 5, top: 5,bottom: 3),
                                      decoration: mAllEducationList[index]
                                                  .institute ==
                                              ""
                                          ? BoxDecoration(
                                              color: Color(0xFFE5EBF0),
                                              borderRadius:
                                                  BorderRadius.all(
                                                      Radius.circular(12)),
                                            )
                                          : int.parse(mAllEducationList[
                                                              index]
                                                          .fromYear) ==
                                                      DateTime.now().year ||
                                                  int.parse(
                                                          mAllEducationList[
                                                                  index]
                                                              .toYear) ==
                                                      DateTime.now().year ||
                                                  setRange(
                                                      mAllEducationList[
                                                              index]
                                                          .fromYear,
                                                      mAllEducationList[
                                                              index]
                                                          .toYear)
                                              ? BoxDecoration(
                                                  color: Color(0xFF198754),
                                                  borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(
                                                              12)),
                                                )
                                              : BoxDecoration(
                                                  color: Color(0xFF4684EB),
                                                  borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(
                                                              12)),
                                                ),
                                      child: Center(
                                          child:
                                              PaddingWrap.paddingfromLTRB(
                                                  3.0,
                                                  4.0,
                                                  3.0,
                                                  4.0,
                                                  BaseText(
                                                    text: getEducationRange(index)
                                                    ,
                                                    textColor: mAllEducationList[
                                                                    index]
                                                                .institute ==
                                                            ""
                                                        ? AppConstants
                                                            .colorStyle
                                                            .darkBlue
                                                        : ColorValues.WHITE,
                                                    fontFamily: AppConstants
                                                        .stringConstant
                                                        .latoMedium,
                                                    fontWeight:
                                                        FontWeight.w700,
                                                    fontSize: 12,
                                                    maxLines: 1,
                                                  ))),
                                    ),
                                    BaseText(
                                      text: mAllEducationList[index]
                                          .educationType,
                                      textColor:
                                          AppConstants.colorStyle.darkBlue,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                      maxLines: 1,
                                    ),
                                    Container(
                                        padding: const EdgeInsets.only(
                                            bottom: 0, top: 0, left: 0),
                                        margin: EdgeInsets.only(top: 5),
                                        height: 50,
                                        child: VerticalDivider(
                                            color: AppConstants
                                                .colorStyle.btnBg))
                                  ],
                                ),
                                flex: 1,
                              ),
                              Expanded(
                                child:
                                    mAllEducationList[index].institute == ""
                                        ? Container(
                                            height: 100,
                                          )
                                        : Stack(
                                            overflow: Overflow.visible,
                                            alignment:
                                                AlignmentDirectional.topEnd,
                                            children: [
                                              PaddingWrap.paddingfromLTRB(
                                                  5.0,
                                                  5.0,
                                                  10.0,
                                                  8.0,
                                                  Container(
                                                      width:
                                                          double.infinity,
                                                      decoration:
                                                          BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                                    10),
                                                        image:
                                                            DecorationImage(
                                                          image: AssetImage(int
                                                                          .parse(mAllEducationList[
                                                                                  index]
                                                                              .fromYear) ==
                                                                      DateTime.now()
                                                                          .year ||
                                                                  int.parse(mAllEducationList[index]
                                                                          .toYear) ==
                                                                      DateTime.now()
                                                                          .year ||
                                                                  setRange(
                                                                      mAllEducationList[index]
                                                                          .fromYear,
                                                                      mAllEducationList[index]
                                                                          .toYear)
                                                              ? "assets/new_onboarding/education_btn_bg.png"
                                                              : "assets/new_onboarding/education_grey_btn.png"),
                                                        ),
                                                        color: int.parse(
                                                                        mAllEducationList[index]
                                                                            .fromYear) ==
                                                                    DateTime.now()
                                                                        .year ||
                                                                int.parse(mAllEducationList[
                                                                            index]
                                                                        .toYear) ==
                                                                    DateTime.now()
                                                                        .year ||
                                                                setRange(
                                                                    mAllEducationList[index]
                                                                        .fromYear,
                                                                    mAllEducationList[index]
                                                                        .toYear)
                                                            ? AppConstants
                                                                .colorStyle
                                                                .education_bg_green
                                                            : AppConstants
                                                                .colorStyle
                                                                .education_bg,
                                                      ),
                                                      margin:
                                                          EdgeInsets.only(
                                                              top: 10,
                                                              bottom: 10),
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                        13.0,
                                                        8.0,
                                                        10.0,
                                                        8.0,
                                                        Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            BaseText(
                                                              text: mAllEducationList[
                                                                      index]
                                                                  .institute
                                                                  .toString(),
                                                              textColor: AppConstants
                                                                  .colorStyle
                                                                  .darkBlue,
                                                              fontFamily: AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              fontSize: 16,
                                                              maxLines: 2,
                                                            ),
                                                            mAllEducationList[index]
                                                                        .educationType ==
                                                                    "College"
                                                                ? Container(
                                                                    height:
                                                                        0,
                                                                  )
                                                                : mAllEducationList[index].school?.address.toString() == "" ||
                                                                        mAllEducationList[index].school?.address.toString() ==
                                                                            null ||
                                                                        mAllEducationList[index].school?.address.toString() ==
                                                                            "null"
                                                                    ? Container(
                                                                        height:
                                                                            0,
                                                                      )
                                                                    : PaddingWrap.paddingfromLTRB(
                                                                        0.0,
                                                                        3.0,
                                                                        0.0,
                                                                        0.0,
                                                                        BaseText(
                                                                          text: mAllEducationList[index].school.address.toString() + ", " + mAllEducationList[index].school.city.toString() + ", " + mAllEducationList[index].school.state.toString(),
                                                                          textColor: AppConstants.colorStyle.darkBlue,
                                                                          fontFamily: AppConstants.stringConstant.latoMedium,
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 13,
                                                                          maxLines: 2,
                                                                        )),
                                                            PaddingWrap
                                                                .paddingfromLTRB(
                                                                    0.0,
                                                                    3.0,
                                                                    0.0,
                                                                    0.0,
                                                                    BaseText(
                                                                      text: mAllEducationList[index].educationType == "College"
                                                                          ? mAllEducationList[index].gpa == null || mAllEducationList[index].gpa == "null"
                                                                              ? ""
                                                                              : "GPA: " + mAllEducationList[index].gpa.toString()
                                                                          : mAllEducationList[index].fromGrade.toString() + "-" + mAllEducationList[index].toGrade.toString(),
                                                                      textColor: AppConstants
                                                                          .colorStyle
                                                                          .darkBlue,
                                                                      fontFamily: AppConstants
                                                                          .stringConstant
                                                                          .latoMedium,
                                                                      fontWeight:
                                                                          FontWeight.w400,
                                                                      fontSize:
                                                                          12,
                                                                      maxLines:
                                                                          1,
                                                                    ))
                                                          ],
                                                        ),
                                                      ))),
                                              //
                                              Container(
                                                margin: EdgeInsets.only(
                                                    top: 8, right: 3),
                                                child:
                                                    MediaQuery
                                                        .removePadding(
                                                            context:
                                                                context,
                                                            removeTop: true,
                                                            child: InkWell(
                                                              child: Image
                                                                  .asset(
                                                                "assets/new_onboarding/edit_pen.png",
                                                                fit: BoxFit
                                                                    .fitWidth,
                                                                height: 30,
                                                                width: 30,
                                                              ),
                                                              onTap:
                                                                  () async {
                                                                int endYar =
                                                                    DateTime.now().year +
                                                                        10;
                                                                DateTime
                                                                    date =
                                                                    DateTime.fromMillisecondsSinceEpoch(int.tryParse(widget
                                                                        .studModel
                                                                        .dob));
                                                                String
                                                                    result =
                                                                    await Navigator.of(context)
                                                                        .push(new MaterialPageRoute(
                                                                  builder: (BuildContext
                                                                          context) =>
                                                                      EditEducationWeightChild(
                                                                    studModel:
                                                                        widget.studModel,
                                                                    mPrimaryEducation:
                                                                        mAllEducationList[index],
                                                                    startYear:
                                                                        date.year,
                                                                    endYear:
                                                                        endYar,
                                                                    ScreenName:
                                                                        widget.screenName,
                                                                  ),
                                                                ));

                                                                if (result ==
                                                                    "push") {
                                                                  mPrimaryEducationList
                                                                      .clear();
                                                                  mMiddleEducationList
                                                                      .clear();
                                                                  mHighEducationList
                                                                      .clear();
                                                                  mCollegeEducationList
                                                                      .clear();
                                                                  mAllEducationList
                                                                      .clear();

                                                                  ApiGetAllEducationList();
                                                                }
                                                              },
                                                            )),
                                              )
                                            ],
                                          ),
                                flex: 3,
                              )
                            ],
                          );
                        },
                        /*  separatorBuilder: (context, index) {
                          return dotLine();
                        },*/
                        itemCount: mAllEducationList.length)),
              ],
            ),
            color: ColorValues.WHITE,
          ))),
      bottomSheet: Container(
          padding: EdgeInsets.only(top: 10),
          decoration: BoxDecoration(
            image: DecorationImage(
              image:
                  AssetImage("assets/generateScript/bottom_rectangle.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: widget.screenName == "profile"
              ? Expanded(
                  child: InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      20.0,
                      20.0,
                      20.0,
                      20.0,
                      Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: ColorValues.WHITE,
                            border: Border.all(
                                color: AppConstants.colorStyle.btnBg),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Align(
                              alignment: Alignment.center,
                              // Align however you like (i.e .centerRight, centerLeft)
                              child: Text(
                                "Back",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color:
                                      AppConstants.colorStyle.lightPurple,
                                  fontFamily: AppConstants
                                      .stringConstant.latoMedium,
                                  fontSize: 18.0,
                                ),
                              )))),
                  onTap: () async {
                    Navigator.pop(context);
                  },
                ))
              : Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                        flex: 2,
                        child: InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              20.0,
                              20.0,
                              0.0,
                              20.0,
                              Container(
                                  height: 44,
                                  decoration: BoxDecoration(
                                    color: ColorValues.WHITE,
                                    border: Border.all(
                                        color:
                                            AppConstants.colorStyle.btnBg),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Align(
                                      alignment: Alignment.center,
                                      // Align however you like (i.e .centerRight, centerLeft)
                                      child: Text(
                                        "Back",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: AppConstants
                                              .colorStyle.lightPurple,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontSize: 18.0,
                                        ),
                                      )))),
                          onTap: () async {
                            Navigator.pop(context);

                            /*   Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => UpdateUserProfile(
                                        widget.mProfileInfoModal, '')));*/
                          },
                        )),
                    Expanded(
                        flex: 3,
                        child: Stack(
                          children: [
                            InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  10.0,
                                  20.0,
                                  20.0,
                                  20.0,
                                  Container(
                                      height: 44,
                                      decoration: BoxDecoration(
                                        color: AppConstants
                                            .colorStyle.lightBlue,
                                        border: Border.all(
                                            color: AppConstants
                                                .colorStyle.lightBlue),
                                        borderRadius:
                                            BorderRadius.circular(10),
                                      ),
                                      child: Align(
                                          alignment: Alignment.center,
                                          // Align however you like (i.e .centerRight, centerLeft)
                                          child: Text(
                                            "Proceed",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              color: ColorValues.WHITE,
                                              fontFamily: AppConstants
                                                  .stringConstant
                                                  .latoMedium,
                                              fontSize: 18.0,
                                            ),
                                          )))),
                              onTap: () {
                                Navigator.of(context).push(
                                    new MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            SelectingChildIterestWidget(
                                              studModel: widget.studModel,
                                            )));
                              },
                            ),
                            btn
                                ? Container(
                                    height: 0,
                                  )
                                : InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        20.0,
                                        20.0,
                                        20.0,
                                        Container(
                                            height: 44,
                                            decoration: BoxDecoration(
                                              color: Colors.white60,
                                              border: Border.all(
                                                  color: Colors.white60),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Align(
                                                alignment: Alignment.center,
                                                // Align however you like (i.e .centerRight, centerLeft)
                                                child: Text(
                                                  "Proceed",
                                                  textAlign:
                                                      TextAlign.center,
                                                  style: TextStyle(
                                                    fontWeight:
                                                        FontWeight.w600,
                                                    color:
                                                        ColorValues.WHITE,
                                                    fontFamily: AppConstants
                                                        .stringConstant
                                                        .latoMedium,
                                                    fontSize: 18.0,
                                                  ),
                                                )))),
                                    onTap: () {},
                                  )
                          ],
                        ))
                  ],
                )),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 50.0),
        child: FloatingActionButton(
          shape: RoundedRectangleBorder(
              side: BorderSide(
                  width: 3, color: AppConstants.colorStyle.lightBlue),
              borderRadius: BorderRadius.circular(100)),
          onPressed: () async {
            int endYar = DateTime.now().year + 10;
            //  Navigator.of(context).popUntil((route) => route.isFirst);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(
                int.tryParse(widget.studModel.dob));

            String result = await Navigator.of(context).push(
                new MaterialPageRoute(
                    builder: (BuildContext context) =>
                        AddEducationWidgetParentChild(
                          studModel: widget.studModel,
                          startYear: date.year,
                          endYear: endYar,
                          pageName: 'Add More',
                        )));
            if (result == "push") {
              ApiGetAllEducationList();
            }
            // Add your onPressed code here!
          },
          backgroundColor: AppConstants.colorStyle.chartTxtlighBlue,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                "assets/new_onboarding/add_education.png",
                fit: BoxFit.fitWidth,
                height: 20,
                width: 18,
              ),
              PaddingWrap.paddingfromLTRB(
                  0.0,
                  2.0,
                  0.0,
                  0.0,
                  BaseText(
                    text: "Add",
                    textColor: AppConstants.colorStyle.white,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    maxLines: 1,
                  ))
            ],
          ),
        ),
      ),
    );
  }



  Future ApiGetAllEducationList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2().apiCall4(
            context,
            Constant.ENDPOINT_GET_ALLEDUCATION_LIST + '?userId=' + userIdPref,
            "get" /*context, Constant.ENDPOINT_ORGANIZATION_LIST, map*/);
        MessageConstant.printWrapped("data++++++searchText===" +
            Constant.ENDPOINT_GET_ALLEDUCATION_LIST +
            '?userId=' +
            userIdPref);

        final String jsonString = jsonEncode(response.data);
        log("data++++++searchText===" + jsonString);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              try {
                mPrimaryEducationList.clear();
                mMiddleEducationList.clear();
                mHighEducationList.clear();
                mCollegeEducationList.clear();
                mAllEducationList.clear();
                allEducationList =
                    AllEducationListModel.fromJson(response.data);
              } catch (e) {
                print('errorr+++0000+++=' + e.toString());
              }
              mPrimaryEducationList
                  .addAll(allEducationList.result.primaryEducation);
              mMiddleEducationList
                  .addAll(allEducationList.result.middleEducation);
              mHighEducationList.addAll(allEducationList.result.highEducation);
              mCollegeEducationList
                  .addAll(allEducationList.result.collegeEducation);

              try {
                if (mPrimaryEducationList.isEmpty) {
                  if (mMiddleEducationList.isEmpty) {
                    if (mHighEducationList.isEmpty) {
                      if (mCollegeEducationList.isEmpty) {
                        DateTime date = DateTime.fromMillisecondsSinceEpoch(
                            int.tryParse(widget.studModel.dob));
                        int endYar = DateTime.now().year + 10;
                        String result = await Navigator.of(context).push(
                            new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    AddEducationWidgetParentChild(
                                      studModel: widget.studModel,
                                      startYear: date.year,
                                      endYear: endYar,
                                    )));
                        if (result == "push") {}
                      }
                    }
                  }
                }
                if (mPrimaryEducationList.isNotEmpty) {
                  for (int i = 0; i < mPrimaryEducationList.length; i++) {
                    mPrimaryEducationList[i].educationType = "Primary";
                  }
                  setState(() {
                    btn = true;
                    mAllEducationList.addAll(mPrimaryEducationList);
                  });
                } else {
                  PrimaryEducation mPrimaryEducation = PrimaryEducation();

                  if (mMiddleEducationList.isEmpty) {
                    if (mHighEducationList.isEmpty) {
                      if (mCollegeEducationList.isEmpty) {
                      } else {
                        var now_1y = new DateTime(int.parse(
                                mCollegeEducationList[
                                        mCollegeEducationList.length - 1]
                                    .fromYear) -
                            14);
                        var now_2y = new DateTime(int.parse(
                                mCollegeEducationList[
                                        mCollegeEducationList.length - 1]
                                    .fromYear) -
                            8);
                        mPrimaryEducation.fromYear = now_1y.year.toString();
                        mPrimaryEducation.toYear = now_2y.year.toString();
                      }
                    } else {
                      var now_1y = new DateTime(int.parse(
                              mHighEducationList[mHighEducationList.length - 1]
                                  .fromYear) -
                          9);
                      var now_2y = new DateTime(int.parse(
                              mHighEducationList[mHighEducationList.length - 1]
                                  .fromYear) -
                          3);
                      mPrimaryEducation.fromYear = now_1y.year.toString();
                      mPrimaryEducation.toYear = now_2y.year.toString();
                    }
                  } else {
                    var now_1y = new DateTime(int.parse(mMiddleEducationList[
                                mMiddleEducationList.length - 1]
                            .fromYear) -
                        6);
                    var now_2y = new DateTime(int.parse(
                        mMiddleEducationList[mMiddleEducationList.length - 1]
                            .fromYear));
                    mPrimaryEducation.fromYear = now_1y.year.toString();
                    mPrimaryEducation.toYear = now_2y.year.toString();
                  }

                  mPrimaryEducation.educationType = "Primary";
                  mPrimaryEducation.fromGrade = "";
                  mPrimaryEducation.toGrade = "";
                  mPrimaryEducation.institute = "";

                  setState(() {
                    mAllEducationList.add(mPrimaryEducation);
                  });
                }
              } catch (e) {
                print('errorr+++1111+++=' + e.toString());
              }
              try {
                Future.delayed(Duration(seconds: 2), () {
                  if (mMiddleEducationList.isNotEmpty) {
                    for (int i = 0; i < mMiddleEducationList.length; i++) {
                      mMiddleEducationList[i].educationType = "Middle";
                    }
                    setState(() {
                      btn = true;
                      mAllEducationList.addAll(mMiddleEducationList);
                    });
                  } else {
                    PrimaryEducation mPrimaryEducation = PrimaryEducation();

                    if (mPrimaryEducationList.isEmpty) {
                      if (mHighEducationList.isEmpty) {
                        if (mCollegeEducationList.isEmpty) {
                        } else {
                          var now_1y = new DateTime(int.parse(
                                  mCollegeEducationList[
                                          mCollegeEducationList.length - 1]
                                      .fromYear) -
                              8);
                          var now_2y = new DateTime(int.parse(
                                  mCollegeEducationList[
                                          mCollegeEducationList.length - 1]
                                      .fromYear) -
                              5);
                          mPrimaryEducation.fromYear = now_1y.year.toString();
                          mPrimaryEducation.toYear = now_2y.year.toString();
                        }
                      } else {
                        var now_1y = new DateTime(int.parse(mHighEducationList[
                                    mHighEducationList.length - 1]
                                .fromYear) -
                            3);
                        var now_2y = new DateTime(int.parse(
                            mHighEducationList[mHighEducationList.length - 1]
                                .fromYear));
                        mPrimaryEducation.fromYear = now_1y.year.toString();
                        mPrimaryEducation.toYear = now_2y.year.toString();
                      }
                    } else {
                      var now_1y = new DateTime(int.parse(mPrimaryEducationList[
                              mPrimaryEducationList.length - 1]
                          .toYear));
                      var now_2y = new DateTime(int.parse(mPrimaryEducationList[
                                  mPrimaryEducationList.length - 1]
                              .toYear) +
                          3);
                      mPrimaryEducation.fromYear = now_1y.year.toString();
                      mPrimaryEducation.toYear = now_2y.year.toString();
                    }

                    mPrimaryEducation.educationType = "Middle";
                    mPrimaryEducation.fromGrade = "";
                    mPrimaryEducation.toGrade = "";
                    mPrimaryEducation.institute = "";
                    setState(() {
                      mAllEducationList.add(mPrimaryEducation);
                    });
                  }
                });

                Future.delayed(Duration(seconds: 3), () {
                  if (mHighEducationList.isNotEmpty) {
                    for (int i = 0; i < mHighEducationList.length; i++) {
                      mHighEducationList[i].educationType = "High";
                    }
                    setState(() {
                      btn = true;
                      mAllEducationList.addAll(mHighEducationList);
                    });
                  } else {
                    PrimaryEducation mPrimaryEducation = PrimaryEducation();

                    if (mMiddleEducationList.isEmpty) {
                      if (mPrimaryEducationList.isEmpty) {
                        if (mCollegeEducationList.isEmpty) {
                        } else {
                          var now_1y = new DateTime(int.parse(
                                  mCollegeEducationList[
                                          mCollegeEducationList.length - 1]
                                      .fromYear) -
                              5);
                          var now_2y = new DateTime(int.parse(
                              mCollegeEducationList[
                                      mCollegeEducationList.length - 1]
                                  .fromYear));
                          mPrimaryEducation.fromYear = now_1y.year.toString();
                          mPrimaryEducation.toYear = now_2y.year.toString();
                        }
                      } else {
                        var now_1y = new DateTime(int.parse(
                                mPrimaryEducationList[
                                        mPrimaryEducationList.length - 1]
                                    .toYear) +
                            3);
                        var now_2y = new DateTime(int.parse(
                                mPrimaryEducationList[
                                        mPrimaryEducationList.length - 1]
                                    .toYear) +
                            7);
                        mPrimaryEducation.fromYear = now_1y.year.toString();
                        mPrimaryEducation.toYear = now_2y.year.toString();
                      }
                    } else {
                      var now_1y = new DateTime(int.parse(
                          mMiddleEducationList[mMiddleEducationList.length - 1]
                              .toYear));
                      var now_2y = new DateTime(int.parse(mMiddleEducationList[
                                  mMiddleEducationList.length - 1]
                              .toYear) +
                          4);
                      mPrimaryEducation.fromYear = now_1y.year.toString();
                      mPrimaryEducation.toYear = now_2y.year.toString();
                    }

                    mPrimaryEducation.educationType = "High";
                    mPrimaryEducation.fromGrade = "";
                    mPrimaryEducation.toGrade = "";
                    mPrimaryEducation.institute = "";
                    setState(() {
                      mAllEducationList.add(mPrimaryEducation);
                    });
                  }
                });

                Future.delayed(Duration(seconds: 4), () {
                  if (mCollegeEducationList.isNotEmpty) {
                    for (int i = 0; i < mCollegeEducationList.length; i++) {
                      mCollegeEducationList[i].educationType = "College";
                    }
                    setState(() {
                      btn = true;
                      mAllEducationList.addAll(mCollegeEducationList);
                      listLengh = mAllEducationList.length;
                      listLengh = listLengh - 2;
                      print("listLengh" + listLengh.toString());
                    });
                    CustomProgressLoader.cancelLoader(context);
                  } else {
                    PrimaryEducation mPrimaryEducation = PrimaryEducation();
                    if (mHighEducationList.isEmpty) {
                      if (mMiddleEducationList.isEmpty) {
                        if (mPrimaryEducationList.isEmpty) {
                        } else {
                          var now_1y = new DateTime(int.parse(
                                  mPrimaryEducationList[
                                          mPrimaryEducationList.length - 1]
                                      .toYear) +
                              7);
                          var now_2y = new DateTime(int.parse(
                                  mPrimaryEducationList[
                                          mPrimaryEducationList.length - 1]
                                      .toYear) +
                              11);
                          mPrimaryEducation.fromYear = now_1y.year.toString();
                          mPrimaryEducation.toYear = now_2y.year.toString();
                        }
                      } else {
                        var now_1y = new DateTime(int.parse(
                                mMiddleEducationList[
                                        mMiddleEducationList.length - 1]
                                    .toYear) +
                            4);
                        var now_2y = new DateTime(int.parse(
                                mMiddleEducationList[
                                        mMiddleEducationList.length - 1]
                                    .toYear) +
                            8);
                        mPrimaryEducation.fromYear = now_1y.year.toString();
                        mPrimaryEducation.toYear = now_2y.year.toString();
                      }
                    } else {
                      var now_1y = new DateTime(int.parse(
                          mHighEducationList[mHighEducationList.length - 1]
                              .toYear));
                      var now_2y = new DateTime(int.parse(
                              mHighEducationList[mHighEducationList.length - 1]
                                  .toYear) +
                          4);
                      mPrimaryEducation.fromYear = now_1y.year.toString();
                      mPrimaryEducation.toYear = now_2y.year.toString();
                    }

                    mPrimaryEducation.educationType = "College";

                    mPrimaryEducation.fromGrade = "";
                    mPrimaryEducation.toGrade = "";
                    mPrimaryEducation.institute = "";
                    setState(() {
                      mAllEducationList.add(mPrimaryEducation);
                      listLengh = mAllEducationList.length;
                      listLengh = listLengh;
                      print("listLengh" + listLengh.toString());
                    });
                    CustomProgressLoader.cancelLoader(context);
                  }
                });
              } catch (e) {
                print('errorr+++2222+++=' + e.toString());
              }
            } else {
              CustomProgressLoader.cancelLoader(context);
            }
          }
        }
        setState(() {});
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print('errorr++++++=' + e.toString());
      CustomProgressLoader.cancelLoader(context);
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  setRange(String fromYear, String toYear) {
    DateTime dateD = DateTime.now();
    //DateTime now = DateTime.now();

    String convertedDateTime =
        "${fromYear}-${dateD.month.toString().padLeft(2, '0')}-${dateD.day.toString().padLeft(2, '0')} ${dateD.hour.toString().padLeft(2, '0')}-${dateD.minute.toString().padLeft(2, '0')}";
    String convertedDateTime1 =
        "${toYear}-${dateD.month.toString().padLeft(2, '0')}-${dateD.day.toString().padLeft(2, '0')} ${dateD.hour.toString().padLeft(2, '0')}-${dateD.minute.toString().padLeft(2, '0')}";

    if (DateTime.parse(convertedDateTime).isBefore(dateD) &&
        DateTime.parse(convertedDateTime1).isAfter(dateD)) {
      return true;
    } else {
      return false;
    }
  }
}

class Model {
  String address;
  double lat;
  double long;
  Color color;

  //Other fields if needed....
  Model(this.address, this.color);
//initialise other fields so on....
}
