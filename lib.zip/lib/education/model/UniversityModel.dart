import 'dart:convert';

class UniversityModel {
  String status;
  List<UniversityResult> result;

  UniversityModel({this.status, this.result});

  UniversityModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<UniversityResult>();
      json['result'].forEach((v) {
        result.add(new UniversityResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class UniversityResult {
  String sId;
  String universityId;
  String name;

  UniversityResult({this.sId, this.universityId, this.name});

  UniversityResult.fromJson(Map<String, dynamic> json) {
    sId = json['_id'].toString();
    universityId = json['universityId'].toString();
    name = json['name'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['universityId'] = this.universityId;
    data['name'] = this.name;
    return data;
  }



  static Map<String, dynamic> toMap(UniversityResult universityData) => {
    '_id': universityData.sId,
    'universityId': universityData.universityId,
    'name': universityData.name,
  };


  static String encode(List<UniversityResult> musics) => json.encode(
    musics
        .map<Map<String, dynamic>>((universityData) => UniversityResult.toMap(universityData))
        .toList(),
  );


  static List<UniversityResult> decode(String musics) =>
      (json.decode(musics) as List<dynamic>)
          .map<UniversityResult>((item) => UniversityResult.fromJson(item))
          .toList();
  
}
