import 'package:flutter/cupertino.dart';
import 'package:flutter/painting.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class MessageConstant {
  //ERROR MESSAGE
  static const String FEATURE_DIABLED =
      "Your school does not allow access to this feature.";
  static const String SHARE_PERSONAL_EMAIL = "Share your personal Email";
  static const String CHANGE_EXISTING_EMAIL = "Personal Email";
  static const String SHARE_PERSONAL_EMAIL_TEXT =
      "Your graduation date is nearby, please provide your personal email id so that after graduation. you can login with your personal email ID.";
  static const String PROFILE_VISIBILITY_DISABLED_CONNECTION_ENABLED =
      "Sorry, you are not authorized to see this user's profile as per your school rules.";
  static const String PROFILE_VISIBILITY_DISABLED =
      "Sorry, you are not authorized to see this user's profile as per your school rules.";
  static const String JOIN_GROUP_DISABLE =
      "Your school does not allow access to this feature.";
  static const String ENTER_Other_VAL = 'Please enter a value for Other.';

  static const String CHANGE_EXISTING_EMAIL_TEXT =
      "After graduation, your high school email id will not be valid. Please provide a personal email so that you can use that to log into your account.";
  static const String CHANGE_EXISTING_EMAIL_TEXT_ONBOARDING =
      "Add a personal email to help recover your account.";
  static const String EXISTING_EMAIL_ADDRESS = "Existing Email address";
  static const String NEW_EMAIL_ADDRESS = "New Email address";
  static const String EMAIL_CHANGE_SUCCESSFULLY =
      "Your email changed successfully, please do re-login.";
  static const String EMAIL_FORGOT_ERROR =
      "Your school email is no longer valid.Please request school admin to reset your email address.";
  static const String REMOVE_NAME = "Are you sure you want to delete? ";
  static const String CANCEL = "Cancel";
  static const String UPDATE = "Update";
  static const String SKIP = "Skip";
  static const String NO = "No";
  static const String YES = "Yes";
  static const String REMOVE = "Remove";
  static const String SAVE = "Save";
  static const String SAVE_ = "SAVE";
  static const String OK = "OK";
  static const String SEND = "Send";
  static const String DONE = "Done";
  static const String CERTIFICATE = "certificate";
  static const String REMOVE_NAME_ = "Are you sure you want to remove ";
  static const String REMOVE_UPDATE = "Update";
  static const String CONNECTION_NOT_AVAILABLE_ERROR = "Please check your internet connection.";
  static const String ENTER_LINK_LABEL_VAL = 'Please enter label.';
  static const String ENTER_URL_VAL = 'Please enter URL.';
  static const String ACTIVE_PARTNER_VAL = 'Already active account.';
  static const String DECLINE_PARTNER_VAL = 'Already decline account';
  static const String FEED_IS_DELETED = "Author has deleted the shared post.";
  static const String BADGE = 'Badge';
  static const String BADGE_TWO = 'Go ahead and embellish!';
  static const String REcommendation_sub_heading = 'Recommendations are a great way to enhance your profile.';
  static const String TEST_HEDING = 'Select a test';
  static const String TEST_HEDING_TWO = 'All tests available, please select here.';
  // static const String ADD_ACC_SHARE_PROFILE = "Please add some of your accomplishments to share an awesome profile of yours";
  static const String ADD_ACC_SHARE_PROFILE =
      "You need to add some experiences to your story before you can share your profile.";
  static const String IMAGE_SOURCE_IS_INCORRECT_ERROR =
      "Image source is incorrect, please select from other location."; //
  static const String CONNECTION_INACTIVE_ERROR =
      "Your connection is inactive"; //
  static const String ACCESS_PROFILE_REVOKED_ERROR =
      "Your access on this profile has revoked.";
  static const String LEAVEA_PAGE =
      "Your data will not save if you go back!\n  Are you sure you want to continue?";
  static const String SORRY_OVER_18_BECOME_PARENT_ERROR =
      "Sorry, you need to be over 18 to become a Parent.";

  static const String OVER_18_CONFORM_ERROR =
      "Please confirm that you are above 18 years old.";
  static const String SORRY_OVER_15_BECOME_PARTNER_ERROR =
      "Sorry, you need to be over 15 to become a partner.";
  static const String
      PARTNER_NOT_ALLOWED_CONNECTON_REQUEST_SPIKEVIEW_USERS_ERROR =
      "Partners are not allowed to send connection requests to spikeview users.";
  static const String FROM_TIME_LESS_THAN_TO_TIME_VAL =
      "From Time should be smaller than to Time.";
  static const String SELECT_TIMEZONE = 'Please provide timezone';
  static const String SELECT_MAJOR_VAL = "Please enter major.";
  static const String SELECT_MINOR_VAL = "Please enter minor.";
  static const String PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR =
      "Your account is still under review. This feature will be available once your account has been approved. For any questions, please contact: team@spikeview.com";
  static const String PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR =
      "Your parent needs to activate your account.";
  static const String PENDING_PROFILE_ACTIVATION =
      "You are under the age of 13. Follow up with your parent to activate the account before posting.";

/*  static const String PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR =
      "Please have your parents approve your account before you can use these features.";*/
  /* static const String PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR =
      "Please have your parents approve your account before you can use these features.";*/

  static const String SOMETHING_WENT_WRONG_ERROR = 'Something went wrong!!';
  static const String MSG_FOR_CONNECTED =
      "Preview of profile visibility to your connected users.";
  static const String MSG_FOR_NON_CONNECTED =
      "Preview of profile visibility to users not connected to you.";
  static const String MSG_FOR_OPPORTUNITY_APPROVAL =
      "Opportunity will be reviewed by admin and once approved it will display to end users.";
  static const String MSG_FOR_CONNECTED_LESS_THEN_3_ACC =
      "Preview of profile visibility to your connected users";
  static const String MSG_FOR_NON_CONNECTED_LESS_THEN_3_ACC =
      "Preview of profile visibility to users not connected to you";
  static const String AUTHORIZED_ACCESS_RECOMMENDATON_ERROR =
      "Sorry, you are not authorized to access this recommendation.";
  static const String NOT_AUTHORIZED_ACCESS_OUTSIDE_ACCOMPLISHMENT =
      "Sorry, you are not authorized to access this feature.";
  static const String WRITE_SOMETHING_ERROR = "Please write something.";
  static const String VIDEO_SOURCE_INCORRECT_ERROR =
      "Video source is incorrect, please select from other location.";
  static const String SELECT_PROBLEM_CONTINUE_ERROR =
      "Please select a problem to continue.";
  static const String NEED_OVER_18_BECOME_PARENT_ERROR =
      "Sorry, you need to be over 18 to become a parent.";

  //SUCCESS MESSAGE
  /* static const String SUCCESSFULLY_SEND_RECOMMENDATION_REQUEST_SUCCESS =
      "Nice work! You have successfully done something that makes you great and your recommendation request has been sent.";
*/
  static const String SUCCESSFULLY_SEND_RECOMMENDATION_REQUEST_SUCCESS =
      "Nice work! Your profile looks great. Connect with others, share, and discover and your recommendation request has been sent.";

/*  static const String SUCCESSFULLY_DONE_SOMETHING_SUCCESS =
      "Nice Work! You’ve successfully done something that makes you great.";*/

  static const String SUCCESSFULLY_DONE_SOMETHING_SUCCESS =
      "Nice work! Your profile looks great. Connect with others, share, and discover.";

  static const String SUCCESSFULLY_UPDATE_MANAGE_OFFERING_SUCCESS =
      "Manage offering updated successfully.";

  //VALIDATION MESSAGE
  static const String SELECT_COMPETENCY_VAL = "Please select a focus area.";
  static const String SELECT_COMPETENCY_VAL_PORTFOLIO =
      "Please select a focus area.";
  static const String AUTHOR_DELETED_POST =
      "Author has deleted the post that has been shared";
  static const String OPPORTUNITY_DELETED_POST =
      "This opportunity no longer exists";
  static const String GROUP_DELETED = "This group is no longer valid";
  static const String SELECT_SKILLS_VAL = "Please select applicable skills.";
  static const String SELECT_ACHIEVEMENT_LEVEL_VAL =
      "Please select achievement level.";
  static const String SELECT_FROM_TIME_VAL = "Please select \"from time\".";
  static const String SELECT_TO_TIME_VAL = "Please select \"to time\".";
  static const String SELECT_FROM_DATE_VAL = "Please select \"start date\".";
  static const String SELECT_TO_DATE_VAL = "Please select \"end date\".";

  static const String ENTER_RECOMMENDATION_TITLE_VAL =
      "Please enter recommendation";
  static const String ENTER_FIRST_NAME_VAL = "Please enter first name.";
  static const String ENTER_NAME_VAL = "Please enter name.";
  static const String ENTER_REFERALLCODE_VAL =
      "Please enter referral code if you have one.";
  static const String FIRST_NAME_CONTAINS_ALPHABET_VAL =
      'First name can only contain:  \', . ,a-z, A-Z, -';
  static const String ENTER_LAST_NAME_VAL = "Please enter last name.";
  static const String LAST_NAME_CONTAINS_ALPHABET_VAL =
      'Last name can only contain:  \', . ,a-z, A-Z, -';
  static const String ENTER_EMAIL_VAL = "Please enter email.";
  static const String VALID_EMAIL_VAL = 'Please enter a valid email.';
  static const String OLD_EMAIL_VAL = 'Can not enter old Email.';
  static const String ENTER_DESCRIPTION_VAL = 'Please enter description.';
  static const String ENTER_Personal_Reflection_VAL =
      'Please enter personal reflection.';
  static const String ENTER_WEIGHT_VAL = 'Please enter weight.';
  static const String ENTER_HEIGHT_VAL = 'Please enter height.';
  static const String ENTER_PHONE_NUMBER_VAL = "Please Enter phone number";
  static const String ENTER_OTHER_BUSINESS_CATE_VAL =
      "Please enter the other business category";
  static const String ENTER_BUSINESS_CATE_VAL =
      "Please select business category.";

  static const String FEE_EMPTY_VAL = "Contact Provider";

  static const String ENTER_BIO_ADVISOR_VAL =
      "Please enter a brief bio.Hint Text > Example: I have 5 years of experience in working with highschool students."; //"Please enter bio.";
  static const String ENTER_BIO_VAL = "Please enter your bio.";
  static const String ENTER_PROJECT_AREA_VAL = "Please enter project areas.";
  static const String ENTER_DESIGNATION_VAL = "Please select a category.";
  static const String ENTER_SUBJECT_VAL = "Please select a subject.";
  static const String ENTER_MENTEE_VAL = "Please select mentee support.";
  static const String ENTER_QUALIFICATION_VAL =
      "Please select the highest level qualification.";
  static const String ENTER_DESIGNATION_VAL_other =
      "Please enter other Category.";
  static const String ENTER_SUBJECT_VAL_other = "Please enter other subject.";
  static const String ENTER_QUALIFICATION_VAL_other =
      "Please enter the highest level qualification.";

  static const String ENTER_CORRECT_DATE_RANGE_VAL =
      "Please enter the correct date range.";
  static const String ENTER_CORRECT_TIME_RANGE_VAL =
      "From Time should be smaller than to Time.";
  static const String MAXIMUM_10_IMAGE_UPLOADED_VAL =
      "Maximum 10 images can be uploaded.";
  static const String MAXIMUM_100_IMAGE_UPLOADED_VAL =
      "Maximum 100 files can be uploaded.";
  static const String MAXIMUM_1_VIDEO_UPLOADED_VAL =
      "Only 1 video selection at a time";
  static const String MAXIMUM_8_IMAGE_UPLOADED_VAL =
      "Maximum 8 images can be uploaded.";
  static const String ENTER_VALUE_ACCOMPLISHMENT_FIELD_VAL =
      "A field(s) value has been left blank. Enter the value in Accomplishment field(s) before proceeding.";

  static const String ENTER_VALUE_PORTFOLIO_FIELD_VAL =
      'A field(s) value has been left blank. Enter the value in Portfolio field(s) before proceeding';
  static const String REQUIRED_FIRST_NAME_VAL = 'First name required';
  static const String REQUIRED_LAST_NAME_VAL = 'Last name required';
  static const String ENTER_VALID_PHONE_NUMBER_VAL =
      'Please enter a valid phone number.';
  static const String ENTER_VALID_EMAIL_VAL = 'Please enter a valid email.';
  static const String ENTER_COMPANY_NAMEL_VAL =
      'Please enter the company or a display name.';
  static const String ENTER_COMPANY_NAMEL_VALIDATION =
      'First name can only contain:  \', . ,a-z, A-Z, -';
  static const String ENTER_PARTNER_REJECTION =
      'Please enter rejection reason.';
  static const String ENTER_COMPANY_ADDRESS_VAL =
      'Please enter the company or your address.';
  static const String ENTER_VALID_WEBSITE_URL_VAL =
      "Please enter a valid website url";
  static const String ENTER_WEB_URL_VAL = "Please enter webUrl";
  static const String ENTER_VALID_DOC_URL_VAL = 'Please enter a valid doc url';
  static const String ENTER_VALID_VIDEO_URL_VAL = 'Please enter a valid video url';
  static const String ENTER_VALID_LINK =
      'Link invalid, please check and add new link.';
  static const String RESUME_ENTER_VALID_LINK = 'Enter a valid URL.';
  static const String RESUME_ENTER_URL = 'URL is required';
  static const String ENTER_SOMETHING_ABOUT_COMPANY_VAL =
      'Please enter details about your company and service.';
  static const String ENTER__ABOUT_COMPANY_VAL =
      "Please enter about your compnay";
  static const String ENTER_JOB_TITLE_VAL = 'Please enter Title';
  static const String ENTER_SERVICE_TITLE_VAL = 'Please enter service title';
  static const String ENTER_JOB_TYPE_VAL = 'Please enter job type';
  static const String REQUIRED_SERVICE_DESCRIPTION_VAL =
      'Service description required';
  static const String ENTER_JOB_LOCATION_VAL = 'Please enter job location';
  static const String DESCRIBE_ROLE_VAL = 'Please describe the role';
  static const String DESCRIBE_BIO_VAL = 'Please describe the bio';
  static const String DESCRIBE_DESCRIPTION_VAL = 'Please enter description.';
  static const String DESCRIBE_FEES_VAL =
      "Please enter fee's for your service. If free, leave it as \$0"; //'Please enter fees.';
  static const String REQUIRED_DURATION_VAL = 'Duration required';
  static const String REQUIRED_STATUS_VAL = 'Status required';
  static const String REQUIRED_TITLE_VAL = 'Title required';
  static const String REQUIRED_DISPLAY_VAL = 'Text to display required';
  static const String REQUIRED_FROM_AGE_VAL = 'Age from required';
  static const String REQUIRED_TO_AGE_VAL = 'Age to required';
  static const String REQUIRED_INTEREST_VAL = 'Interest required';
  static const String REQUIRED_GROUP_NAME_VAL = 'Group name required';
  static const String REQUIRED_GROUP_ABOUT_VAL = 'About group required';
  static const String REQUIRED_OTHER_INFORMATION_VAL =
      'Other information required';
  static const String ENTER_EXPIRATION_DATE_VAL =
      'Please enter expiration Date.';
  static const String ENTER_EXPIRATION_DATE_BETWEEN_VAL =
      'Please select date between the scheduled date.';
  static const String SELECT_ATLEAST_ONE_SECTON_VAL =
      'Select atleast one action';

  static const String ENTER_INSTITUTE_NAME_VAL = 'Please enter school name.';
  static const String ENTER_INSTITUTE_NAME_VAL_School =
      'Please enter valid school name';
  static const String SELECT_GRADE_FROM_VAL = "Please select from grade";
  static const String TO_GRADE_LESS_THAN_FROM_GRADE_VAL =
      "To grade should not be less than from grade";
  static const String FROM_DATE_SMALLER_THAN_TO_DATE_VAL =
      "From date should be smaller than To date.";
  static const String TO_DATE_GRATER_THAN_FROM_DATE_VAL =
      "To date should not be less than From date.";
  static const String FROM_GRADE_LESS_THAN_TO_GRADE_VAL =
      "From grade should  be smaller than to grade";
  static const String SELECT_GRADE_TO_VAL = "Please select grade (to)";
  static const String ENTER_CITY_VAL = 'Please enter city.';
  static const String ENTER_TITLE_VAL = 'This field is required.';
  static const String RESUME_ENTER_TITLE_VAL = 'Display name is required.';
  static const String ENTER_TITLE_VAL_OTHER_CHANGE =
      'Add a display name to replace "Other"';
  static const String ENTER_TITLE_VAL_GENERAL_CHANGE =
      'Add a display name to replace "General"';
  static const String SELECT_GRAD_VAL = 'Please select grade.';
  static const String SELECT_YEAR_VAL = "Please select year.";
  static const String REVIEW_CONFIRM_DATE_VAL =
      "Please review and confirm the dates below.";
  static const String DONT_THINK_YOU_MAKE_TENURE_VAL =
      "Don't think, you can make it in this tenure.";
  static const String ALREADY_ADDED_ALL_GRADE_VAL =
      "You have already added all grades";
  static const String VIDEO_UPLOAD_NOT_SUPPORT_VAL =
      "Video uploads are not yet supported. Please upload an image instead.";
  static const String REQUIRED_MIN_1_STUDENT_VAL =
      "Minimum 1 student required.";

  static const String ENTER_PASSWORD_VAL = "Please enter password";
  static const String ENTER_PASSWORD_MESSAGE = "Minimum of 8 characters, one lowercase and one uppercase letter, one special character and one number.";
  static const String ENTER_OTHER_DISPLAY_TITLE = "Other, enter display title";
  static const String ENTER_GENERAL_DISPLAY_TITLE =
      "General, enter display title";
  static const String FOCUS_AREA_HINT_TEXT = "Example:Public forum";
  static const String FOCUS_AREA_VALIDATION = "Please enter focus area";

  static const String ENTER_CURRENT_PASSWORD_VAL =
      "Please enter current password";
  static const String ENTER_TEMPORARY_PASSWORD_VAL =
      "Please enter temporary password";
  static const String ENTER_CORRECT_CURRENT_PASSWORD_VAL =
      "Please enter current password";
  static const String ENTER_NEW_PASSWORD_VAL = "Please enter  password";
  static const String ENTER_CONFIRM_PASSWORD_VAL =
      "Please enter confirm password";

  static const String ENTER_CONFIRM_PASSWORD =
      "Passwords don't match. Please try again. ";
  static const String PASSWORD_SHOULD_8_CHARACTER_VAL =
      'Your password needs to have a minimum of 8 characters- one special character, a number, and lower case and upper case letters';

  static const String INVALID_FILE_FORMAT_VAL =
      "Invalid file format, please select .pdf files";
  static const String MAX_5_DOC_UPLOADED_VAL =
      "Maximum 5 documents can be uploaded.";
  static const String UPLOAD_FILE_FAILED = "Upload failed. Please try again";
  static const String MAX_3_PHOTO_UPLOADED_VAL =
      "Maximum 3 images can be uploaded.";
  static const String MAX_10_IMAGE_VIDEO_UPLOADED_VAL =
      "Maximum 10 images or video can be uploaded.";
  static const String MAX_5_LINK_UPLOADED_VAL =
      "Maximum 5 link can be uploaded.";
  static const String MIN_1_OFFERING_SELECTED_VAL =
      "Please select at least 1 offering";
  static const String SELECT_1_PHOTO_VIDEO_VAL = 'Select one photo or video.';
  static const String SELECT_1_MENTOR_PHOTO_VAL = 'Please select mentor photo.';
  static const String SELECT_ADVISOR_PHOTO_VAL = 'Please select advisor photo.';
  static const String SELECT_TUTOR_CERTIFICATE =
      'Please select teaching certificate.';
  static const String SELECT_DAY_VAL = 'Please enter your availability';
  static const String SELECT_time_slot_VAL = 'Select atleast one time slot.';
  static const String REQUIRED_FILL_ALL_FIELD_VAL =
      "Please fill all required field.";

  static const String ENTER_CORRECRT_EMAIL_VAL =
      'Incorrect email. Please try again.';
  static const String SECONDARY_EMAIL_VAL =
      'Secondary email can\'t be same as primary email.';
  static const String ENTER_CORRECRT_DOMAIN_VAL =
      'org, .edu and .us domains are not allowed for personal email.';
  static const String SELECT_DOB_VAL = 'Please select date of birth.';
  static const String SELECT_ISSUED_DATE = 'This field is required';
  static const String SELECT_DATE_TAKEN_VAL = 'Please select date taken.';
  static const String SELECT_SERVICE_TYPE = 'Please select platform.';
  static const String SELECT_GENDER_VAL = "Please select gender.";
  static const String ENTER_STUDENT_FIRST_NAME_VAL =
      "Please enter student first name.";
  static const String ENTER_STUDENT_LAST_NAME_VAL =
      "Please enter student last name.";
  static const String STUDENT_FIRST_NAME_CONTAIN_ALPHABET_VAL =
      'Student first name can only contain:  \', . ,a-z, A-Z, -';
  static const String STUDENT_LAST_NAME_CONTAIN_ALPHABET_VAL =
      'Student Last name can only contain:  \', . ,a-z, A-Z, -';
  static const String ENTER_VALID_ZIP_CODE_VAL =
      "Please enter a valid zip code.";
  static const String ENTER_VALID_COUNTRY_ZIP_CODE_VAL =
      "Invalid zip code for selected country.";
  static const String ENTER_VALID_COUNTRY_ZIP_CODE_VAL_PARENT =
      "Parent's zip code invalid for selected country.";
  static const String STUDENT_PARENT_EMAIL_CANNOT_SAME_VAL =
      "Student and parent email cannot be the same.";
  static const String INVALID_REFERRAL_CODE =
      "Please enter valid referral code.";
  static const String VALID_REFERRAL_CODE = "Referral code applied.";

  static const String ENTER_PARENT_EMAIL_VAL = "Please enter email.";
  static const String ENTER_PARENT_FIRST_NAME_VAL = "Please enter first name.";
  static const String ENTER_PARENT_LAST_NAME_VAL = "Please enter last name.";
  static const String PARENT_FIRST_NAME_CONTAIN_ALPHABET_VAL =
      'Parent first name can only contain:  \', . ,a-z, A-Z, -';
  static const String PARENT_LAST_NAME_CONTAIN_ALPHABET_VAL =
      'Parent last name can only contain:  \', . ,a-z, A-Z, -';

  static const String ENTER_GROUP_NAME_VAL = 'Please enter group name.';
  static const String ENTER_GROUP = 'Please select at least 1 group.';
  static const String ENTER_MIN_3_CHAR_VAL =
      "Please insert minimum 3 character";
  static const String ENTER_GROUP_MOTIVE_VAL = 'Please enter group motive';
  static const String ENTER_GROUP_MOTIVE_VAL_MAximum = 'Maximum 500 character allowed';
  static const String SELECT_STUDENT_VAL = "Please select student.";
  static const String NAME_CONTAIN_ALPHABT_VAL =
      'Name can only contain:  \', . ,a-z, A-Z, -';
  static const String ENTER_CORRECT_INPUT_VAL =
      "Please enter correct input here";
  static const String ENTER_MESSAGE_VAL = "Please enter message";
  static const String INSERT_LINK_VAL = "Please insert link";
  static const String SELECT_TYPE_OF_CALL_TO_ACTION_VAL =
      'Please select the type of call to action: This shows up as a button next to your opportunity posting.';

  static const String CREATE_GROUP_VAL = "Please create a group";
  static const String SELECT_GROUP_VAL = "Please select a group";
  static const String ENTER_NUMBER_VAL = "Please enter number";
  static const String ADD_MEMBERS_VAL = "Please add members.";

  static const String REMOVE_LEARN_MORE_LINK_VAL =
      'Are you sure you want to remove learn more link?';
  static const String REMOVE_GET_OFFER_LINK_VAL =
      'Are you sure you want to remove get offer link?';
  static const String REMOVE_APPLY_NOW_LINK_VAL =
      'Are you sure you want to remove apply now link?';
  static const String REMOVE_NEW_GROUP_AND_ADD_EXISTING_GROUP_VAL =
      'Are you sure you want to remove  group and add existing group?';
  static const String REMOVE__EXISTING_GROUP_AND_CREATE_NEW_GROUP_VAL =
      'Are you sure you want to remove existing group and create  group?';

  static const String ENTER_DURATION_VAL = 'Please enter duration.';
  static const String ENTER_STATUS_VAL = 'Please enter status.';
  static const String ENTER_REASON_VAL = 'Please enter reason';
  static const String SELECT_ATLEAST_1_GROUP_TO_SHARE_VAL =
      "Please select atleast one group to share.";
  static const String CREATE_1_GROUP_TO_SHARE_VAL =
      "Please create one group to share.";
  static const String SELECT_PARENT_GENDER_VAL = "Please select parent gender.";
  static const String STUDENT_MUST_HAVE_1_PARENT_ATTACHED_VAL =
      "Being a minor, student must need at least one parent attached with.";
  static const String SELF_SHARE_NOT_GOOD_IDEA =
      "Self share is not a good idea.";
  static const String SELF_RECOMMENDATION_NOT_GOOD_IDEA =
      "Self recommendation is not a good idea.";
  static const String SELF_REFER_NOT_GOOD_IDEA = "You can't refer your self.";

  static const String PARENT_ACCEPT_CONNECTION_MSG =
      "Connection request approved.";
  static const String UNDER_13_GROUP_MSG =
      "This group will be a private group because you are under the age of 13.";
  static const String SELF_INVITE_NOT_GOOD_IDEA = "You can't refer your self.";

  static const String ENTER_CITY_NAME = "Please enter city.";
  static const String ENTER_REQUEST_VAL = 'Please enter your request.';

  static const String ENTER_RECOMMENDER_TITLE_VAL =
      'Please enter recommender title.';

  static const String RATE_OUR_SERVICE = 'Please rate our service.';

  static const String BADGE_VALIDATION =
      'Provide details about your qualification for the badge being requested.';
  static const String EMAIL_VALIDATION = 'Your own email is not allowed.';

  static const String BUILDDASHBOARD = "Start building your dashboard!";
  static const String CHARTSUBHEADING =
      "Before we can create any charts, we’ll first need to get some data in here!";
  static const String THANKS = "Profile created successfully";
  static const String DIS =
      "We have sent email to you with instructions and credentials to access account. ";
  static const String SETUP =
      "Let's get you setup and get you connected to our community!";
  static const String BRIEF_ABOUT_YOU = "Provide a brief background about you";
  static const String HOME_PAGE = "Set up your homepage";
  static const String CREATE_OPPORTUNITY =
      "Create opportunities - share your programs with our community";
  static const String TARGET_AUDIENCE = "Set your target audience";
  static const String BUSINESS_OBJECTIVES =
      "Sit back, relax and let our community help you meet your business objectives";
  static const String ENTER_DELETE_GROUP_MSG = "This group is no longer valid.";

  static const String SELECT_Other_DEGREE_VAL = "Please select other degree.";

  static const String ENTER_GPA_VAL = 'Please enter GPA.';
  static const String ENTER_out_of_VAL = 'Please enter out of GPA.';
  static const String SELECT_Degree_VAL = 'Please select degree.';
  static const String SELECT_degree_year_VAL = 'Please select class.';
  static const String SELECT_GRADUATION_YEAR_VAL =
      'Please select graduation year.';
  static const String ENTER_INTEREST_INSTITUTE_VAL =
      'Please enter interest institute.';
  static const String ENTER_gpa_out_of_less = 'Please enter valid GPA.';
  static const String SELECT_professional_Certificates_DEGREE_VAL =
      "Please enter certification name.";

  static const String REQUIRED_POSITION_VAL = 'Position required';
  static const String REQUIRED_IMAGE = 'Please select image';
  static const String REQUIRED_HEGHT = 'Please select height';
  static const String REQUIRED_SPORTS = 'Please select sports';
  static const String REQUIRED_ARTS = 'Please select art form.';
  static const String REQUIRED_SPORT = 'Please select sport form.';
  static const String REQUIRED_LABEL_VAL = 'Label required';
  static const String REQUIRED_VALUE_VAL = 'Value required';
  static const String REQUIRED_CLUB_NAME_VAL = 'Club required';
  static const String REQUIRED_TEAM_NAME_VAL = 'Team required';
  static const String REQUIRED_CITY = 'City required';
  static const String REQUIRED_STATE = 'State required';
  static const String REQUIRED_JURSEY = 'Jurssey required';

  static const String COACH_NAME_CONTAIN_ALPHABET_VAL =
      'Coach name can only contain:  \', . ,a-z, A-Z, -';
  static const String COACH_NAME_VAL = "Please enter coach name.";
  static const String REQUIRED_MIN_1_SKILLL = "Minimum 1 skill required.";
  static const String MAXIMUM_7_SKILLL = "Maximum 7 skills can be added.";

  static const String CATEGORY_REQUIRED = 'Please enter category.';

  static const String ADD_PHOTO =
      'Add a clean and clear photo for your profile.';
  static const String ADD_URL = ' Please add url';
  static const String ADD_URL_NOT_VALID = 'URL not valid. Please try again';
  static const String FIELD_REQUIRED = 'This field is required';
  static const String THIRD_LEVEL_REQUIRED =
      'Add a display name to replace "Other"';
  static const String FIELD_REQUIRED_LABEL = 'Label is required.';
  static const String ENTER_College_NAME_VAL = 'Please enter college name.';
  static const String MEDIA_TEXT_PORTFOLIO =
      'Upload photos, videos or links your reels to showcase your skills.';
  static const String ADD_EDUCATION_HEDING_1 = 'Add ';
  static const String EDIT_EDUCATION_HEDING_1 = 'Edit ';
  static const String ADD_EDUCATION_HEDING_2 = 'education';
  static const String EDUCATION_HEDING = 'Education';
  static const String INTEREST_HEDING = 'Interests';
  static const String ACCOMPLISHMENT_HEDING = 'Accomplishment';
  static const String CERTIFICATES_TROPHIES_HEDING =
      'CERTIFICATES, TROPHIES & BADGES';
  static const String CUSTOM_PROFILE_HEDING = 'CUSTOM PROFILE';
  static const String TEST_SCORE_HEDING = 'Test Score';
  static const String COMPANY_PROFILE_HEDING = 'Media';
  static const String VIEWER_END_REWCOMMENDATION_HEDING = 'Media';
  static const String HOME_HEDING = 'Home';
  static const String HOME_FEED = 'HomeFeed';
  static const String HOME_OPPORTUNITY_HEDING = 'HomeOpportunity';
  static const String OPPORTUNITY_DETAIL_VIDEO_HEDING =
      'OpportunityDetailVideo';

  static const String PRIVATE_EMAIL_MSG =
      'You have hidden your Email ID from apple account, please unhide it and register again.';

  /*-----------------------------------Login_Widget.dart Constant Text-------------------------Start */

  static const String ARE_YOU_SURE_SWITCH_PARENT =
      "Are you sure you want to switch your role as Parent?";

  static const String LOGIN_YES = "Yes";
  static const String LOGIN_CAREERS = "Careers";
  static const String LOGIN_CAREER = "Career";
  static const String LOGIN_PRIVACY_PLICY = "Privacy policy";
  static const String LOGIN_FAQS = "FAQ's";
  static const String LOGIN_TERMS_OF_SERVICE = "Terms of service";
  static const String LOGIN_TERMS_OF_DATA = "Terms, Data";
  static const String LOGIN_SIGN_IN = "Sign in";
  static const String LOGIN_ENTER_PASSWORD = "Please enter password.";
  static const String LOGIN_INCORRECT_PASSWORD =
      'Incorrect password. Please try again.';
  static const String LOGIN_PASSWORD = "Password";
  static const String LOGIN_OR = "   or continue with   ";
  static const String LOGIN_SIGN_WITH_GOOGLE = "Google";
  static const String LOGIN_SIGN_WITH_APPLE = "Apple";
  static const String LOGIN_DONT_HAVE_ACCOUNT = "Don’t have an account? ";
  static const String LOGIN_SIGN_UP = "Sign up";
  static const String LOGIN_BY_SIGNING = 'By signing in, you agree to our ';
  static const String LOGIN_BY_OR_SIGN_WITH = "  Or sign in with  ";
  static const String LOGIN_BY_PARTNER = "Partner";
  static const String LOGIN_BY_SELECT_ANY_ROLE = 'Please select any role.';
  static const String LOGIN_SIGN_UP_WITH = "  Sign up with  ";
  static const String LOGIN_EMAIL = "Email";
  static const String LOGIN_ALREADY_ACCOUNT = "Already have an account? ";

/*-----------------------------------Partner file Constant Text (Company_info_view)-------------------------Start */

  static const String PARTNER_UPLOAD_DOCUMENT = 'Upload document link';
  static const String PARTNER_ADD_MORE = 'Add More';
  static const String PARTNER_ADD_COMPELLING_PHOTO =
      'Add compelling photos of your company, logos or products';
  static const String PARTNER_PHOTO = 'Photos';
  static const String PARTNER_VIDEOS = 'Videos';

  static const String PARTNER_ABOUT_YOUR_COMPANY =
      'Tell the users about your company';
  static const String PARTNER_UPLOAD_DOC_ADDITIONAL_DET =
      'Upload documents with additional details';
  static const String PARTNER_ADD_MEDIA = 'Add media';
  static const String PARTNER_ADD_COMPANY_LOGOS_PRODUCT_IMAGE =
      'Add your company logos, images of your product or service. This will be visible to users visiting your homepage';
  static const String PARTNER_PROVIDE_DETAILS_ABOUT_BUSINESS =
      "Please provide details about your business. If you are offering the services as an individual, you can share your details.!";

  static const String PARTNER_PASSWORD = "Password";
  static const String PARTNER_REFERRAL_CODE = "Please enter referral code";
  static const String PARTNER_CONFIRM = "Confirm";
  static const String PARTNER_DISCARD_ALL_CHANGES =
      "Are you sure you want to discard all changes?";
  static const String PARTNER_OK = "OK";
  static const String PARTNER_DISPLAY_NAME = 'Company / Display name';
  static const String PARTNER_DISPLAYED_HOMEPAGE = "Displayed on homepage";

  static const String PARTNER_YOUR_NAME = 'Your name';
  static const String PARTNER_FIRST_LAST_NAME = "First name, Last name";
  static const String PARTNER_BUSINESS_CATEGORY = 'Business category';
  static const String PARTNER_SELECT_CATEGORY = 'Select category';
  static const String PARTNER_OTHER_BUSINESS_CATEGORY =
      'Other Business Category';
  static const String PARTNER_YOUR_ADDRESS = 'Company / Your address';
  static const String PARTNER_MINIMUM_8_CHARACTERS = "Minimum of 8 characters";
  static const String PARTNER_SPECIAL_CHARACTER = "One special character";
  static const String PARTNER_LOWER_UPPER_LETTER =
      "Lower case and upper case letter";
  static const String PARTNER_WEBSITE_URL = "Website URL";
  static const String PARTNER_ABOUT_COMPANY_SERVICE =
      'About Your Company / Service';
  static const String PARTNER_PREMIER_TUTORING_SERVICE_SPECIALIZING =
      "We are a premier tutoring service specializing in Advanced Math, Science and CS";
  static const String PARTNER_MESSAGE_COMPELLING =
      'Make your message compelling and dont forget to include how the user can contact you and apply to your opportunity';
  static const String PARTNER_HAVE_REFERRAL_CODE = "Have a referral code?";
  static const String PARTNER_SIGINGUP_AGREE_TO_OUR =
      'By signing up, you agree to our ';
  static const String PARTNER_TERMS_DATA = "Terms, Data";
  static const String PARTNER_PRIVACY_POLICY = "Privacy Policy";
  static const String PARTNER_CERTIFY_THAT_OVER_15 =
      ". I certify that I am over the age of 15. ";

  static const String PARTNER_ALREADY_HAVE_ACCOUNT = "Already have an account?";
  static const String PARTNER_CONTINUE = 'Continue';
  static const String PARTNER_SIGNIN = "Sign in";

  static const String PARTNER_CAREER = "Career";
  static const String PARTNER_CAREERS = "Careers";

  static const String PARTNER_FAQS = "FAQ's";
  static const String PARTNER_TERMS_SERVICES = "Terms of service";

  static const String PARTNER_LETTS_STARTED = "Let’s get started!";
  static const String PARTNER_PROVIDE_BUSINESS_DETAILS =
      "Please provide details about your business. If you are offering the services as an individual, you can share your details.";
  static const String PARTNER_CONNECTED_OUR_COMMUNITY =
      "Let’s get you set up and connected to our community!";

/*-----------------------------------student file Constant Text (SignupStudentPageNew)-------------------------Start */

  static const String STUDENT_DISCARD_ALL_CHANGES =
      "Are you sure you want to discard all changes?";

  static const String STUDENT_OK = "OK";
  static const String STUDENT_PASSWORD = "Password";
  static const String STUDENT_FIRST_NAME = "First name";
  static const String STUDENT_LAST_NAME = "Last name";
  static const String STUDENT_EMAIL = "Email";
  static const String STUDENT_REFERRAL_CODE = "Please enter referral code";
  static const String STUDENT_CONFIRM = "Confirm";
  static const String STUDENT_CONTINUE = 'Continue';
  static const String STUDENT_CAREER = "Career";
  static const String STUDENT_CAREERS = "Careers";
  static const String STUDENT_PRIVACY_POLICY = "Privacy Policy";
  static const String STUDENT_FAQS = "FAQ's";
  static const String STUDENT_TERMS_DATA = "Terms, Data";
  static const String STUDENT_TERMS_OF_SERVICE = "Terms of Service";

  static const String STUDENT_SIGNING_UP_STUDENT =
      "You are signing up as a student";
  static const String STUDENT_8_CHARACTERS = "Minimum of 8 characters";
  static const String STUDENT_SPECIAL_CHARACTER = "One special character";
  static const String STUDENT_LOWER_UPPER_LETTER =
      "Lower case and upper case letter";
  static const String STUDENT_ONE_NUMBER = "One number";
  static const String STUDENT_UNDER_13 = 'Under 13';
  static const String STUDENT_ABOVE_13 = 'Above 13';
  static const String STUDENT_SELECT_AGE_GROUP = "Please select your age group";
  static const String STUDENT_HAVE_REFERRAL_CODE = "Have a referral code?";
  static const String STUDENT_SIGNING_UP_AGREE =
      'By signing up, you agree to our ';
  static const String STUDENT_CONFIRMING_YOUR_AGE =
      ' and confirming your age selected above is accurate.';
  static const String STUDENT_ALREADY_HAVE_ACCOUNT =
      "Already have an account? ";
  static const String STUDENT_LEGAL_GUARDIAN_INFORMATION =
      "You are under 13 so we will need your legal guardian information to complete the account set up.";

  static const String STUDENT_SIGNIN = "Sign in";

/*-----------------------------------PARENT file Constant Text (SIGNUP_AS_PARENT_WIDGET)-------------------------Start */

  static const String PARENT_DISCARD_ALL_CHANGES =
      "Are you sure you want to discard all changes?";

  static const String PARENT_OK = "OK";

  static const String PARENT_PASSWORD = "Password";
  static const String PARENT_FIRST_NAME = "First name";
  static const String PARENT_LAST_NAME = "Last name";
  static const String PARENT_EMAIL = "Email";
  static const String PARENT_STUDENT_EMAIL = "Student email";
  static const String PARENT_STUDENT_FIRST_NAME = "Student first name";
  static const String PARENT_STUDENT_LAST_NAME = "Student last name";
  static const String PARENT_CONTINUE = 'Continue';
  static const String PARENT_REFERRAL_CODE = "Please enter referral code";
  static const String PARENT_CONFIRM = "Confirm";
  static const String PARENT_CAREER = "Career";
  static const String PARENT_CAREERS = "Careers";
  static const String PARENT_PRIVACY_POLICY = "Privacy policy";
  static const String PARENT_FAQS = "FAQ's";
  static const String PARENT_TERMS_DATA = "Terms, Data";
  static const String PARENT_TERMS_SERVICE = "Terms of service";
  static const String PARENT_YOU_SIGNING_ASA_PARENT =
      "You are signing up as a parent";
  static const String PARENT_MINIMUM_8_CHA = "Minimum of 8 characters";
  static const String PARENT_SPECIAL_CHARACTER = "One special character";
  static const String PARENT_LOWER_UPPER_LETTER =
      "Lower case and upper case letter";
  static const String PARENT_ONE_NUMBER = "One number";
  static const String PARENT_CONFIRM_ABOVE_18_YEAR =
      'Please confirm that you are above 18 years old.';
  static const String PARENT_HAVE_REFERRAL_CODE = "Have a referral code?";
  static const String PARENT_SIGNINGUP_AGREE =
      'By signing up, you agree to our ';
  static const String PARENT_CONFIRM_SELECTED_AGE =
      ' and confirming your age selected above is accurate.';
  static const String PARENT_ALREADY_HAVE_ACCOUNT = "Already have an account? ";

  static const String PARENT_SIGNIN = "Sign In";

/*-----------------------------------Add Aducation -------------------------Start */

  static const String ADD_ADUCATION_SCHOOL = "School";
  static const String ADD_ADUCATION_SEARCH_SCHOOL = 'Search school';
  static const String ADD_ADUCATION_COLLEGE = "College";
  static const String ADD_ADUCATION_SEARCH_COLLEGE = 'Search college';
  static const String ADD_ADUCATION_SELECT_GRADE = "Select grade";
  static const String ADD_ADUCATION_GRADUATION_YEAR = 'Graduation Year';
  static const String ADD_ADUCATION_DEGREE = "Degree";
  static const String ADD_ADUCATION_SELECT_YEAR = "Select Year";
  static const String ADD_ADUCATION_GRADE_FROM = "Grade From";
  static const String ADD_ADUCATION_GRADE_TO = "Grade To";
  static const String ADD_ADUCATION_CLASS = "Class";
  static const String ADD_ADUCATION_DATA_FROM = "Date From";
  static const String ADD_ADUCATION_DATA_TO = "Date To";
  static const String ADD_ADUCATION_CITY = "City";
  static const String ADD_ADUCATION_OTHER = "Other";
  static const String ADD_ADUCATION_CERTIFICATION_NAME = "Certification name";

  static const String ADD_ADUCATION_MAJOR = "Major";
  static const String ADD_ADUCATION_MINOR = "Minor";
  static const String ADD_ADUCATION_GPA = "GPA";
  static const String ADD_ADUCATION_OUT_OF = "GPA Out of";

  static const String ADD_ADUCATION_EDIT_EDUCATION = "Edit education";
  static const String ADD_ADUCATION_ADD_EDUCATION = "Add education";
  static const String ADD_ADUCATION_SAVE = 'SAVE';

  static const String ADD_ADUCATION_I_WANT_TO_ADD = "I want to add";

/*-----------------------------------Add Accomplishment -------------------------Start */

  static const String ADD_ACCOMPLISHMENT_FIRST_NAME = "First Name";
  static const String ADD_ACCOMPLISHMENT_LAST_NAME = "Last Name";
  static const String ADD_ACCOMPLISHMENT_EMAIL = "Email";
  static const String ADD_ACCOMPLISHMENT_BIO = "Bio";
  static const String ADD_ACCOMPLISHMENT_CITY = "City";
  static const String ADD_ACCOMPLISHMENT_STATE = "State";
  static const String ADD_ACCOMPLISHMENT_DATE_TO = "Date To";
  static const String ADD_ACCOMPLISHMENT_HEIGHT = "Height";

  static const String ADD_ACCOMPLISHMENT_SAVE = "Save";
  static const String ADD_ACCOMPLISHMENT_AGE = "Age";
  static const String ADD_ACCOMPLISHMENT_DATE_FROM = "Date from";

  static const String ADD_ACCOMPLISHMENT_CONTINUE = "Continue";
  static const String ADD_ACCOMPLISHMENT_ARTS = "Arts";
  static const String ADD_ACCOMPLISHMENT_SPORTS = "Sports";
  static const String ADD_ACCOMPLISHMENT_CREATE_YOUR_DETAILS_ARTS =
      "Create your detailed arts portfolio and showcase your talents. The more details you can add, the better.";
  static const String ADD_ACCOMPLISHMENT_CREATE_YOUR_DETAILS_SPORTS =
      "Create your detailed sports portfolio and showcase your talents. The more details you can add, the better.";
  static const String ADD_ACCOMPLISHMENT_ABOUT_PORTFOLIO = "About portfolio";

  static const String ADD_ACCOMPLISHMENT_CREATE_IMMERSIVE =
      "Create an immersive, detailed art portfolio to showcase your talents. The more you can add the better.";
  static const String ADD_ACCOMPLISHMENT_LETS_YOUR_TALENT_SHINE =
      "Let your talent shine. Create you detailed sports portfolio here.";

  static const String ADD_ACCOMPLISHMENT_SHARE_YOUR_ATHLETIC =
      "Share your athletic information with the coaches here.";
  static const String ADD_ACCOMPLISHMENT_ATHLETIC_INFORMATION =
      "Athletic Information";
  static const String ADD_ACCOMPLISHMENT_SELECT_TEAM = "Select Team";
  static const String ADD_ACCOMPLISHMENT_ADD_DETAILLS_ABOUT_TEAM =
      "Add details about all the team you have played with.";
  static const String ADD_ACCOMPLISHMENT_CLUB_TEAM = "Club Team";
  static const String ADD_ACCOMPLISHMENT_HIGH_SCHOOL_TEAM = "High school team";

  static const String ADD_ACCOMPLISHMENT_COLLEGE_TEAM = "College team";
  static const String ADD_ACCOMPLISHMENT_ASK_RECOMMENDATION =
      "  Ask for recommendation";
  static const String ADD_ACCOMPLISHMENT_RECOMMENDER_DETAILS =
      "RECOMMENDER DETAILS";
  static const String ADD_ACCOMPLISHMENT_EXERNAL_LINKS =
      "External Links & Mentions";
  static const String ADD_ACCOMPLISHMENT_UPLOAD_PRESS_COVERAGE =
      "Upload press coverage, video montages/highlight reels, documents.";
  static const String ADD_ACCOMPLISHMENT_DESCRIPTION = 'Description';

  static const String ADD_ACCOMPLISHMENT_TITLE = 'Title';
  static const String ADD_ACCOMPLISHMENT_I_AM_A_POSSIONATE =
      "I am a passionate artist focused on pottery. I have 5 years of experience, but pottery is where I stand out. Statement: In my art, I like to capture the beauty in mundane objects and places. Different mediums allow me to...";

  static const String ADD_ACCOMPLISHMENT_AS_VERSATILE_STUDENT =
      "As a versatile student-athlete, I bring unique skills to any competitive baseball team. I strive to be an impact player, always looking at how to help my team win.";

  static const String ADD_ACCOMPLISHMENT_IN_DETAILS_DESCRIBE_ART =
      "In detail describe your art or performance highlighting key features";
  static const String ADD_ACCOMPLISHMENT_IN_DETAILS_DESCRIBE_SPORTS =
      "In detail describe your sports performance highlighting key features";

  static const String ADD_ACCOMPLISHMENT_NOTE_PERSONAL_REFLECTION =
      "Note: Personal reflection is a note to self and will not be shared with anyone.";

  static const String ADD_ACCOMPLISHMENT_ADD_SOME_NOTES =
      "Add some notes/reminders for yourself that you want to remember.";
  static const String ADD_ACCOMPLISHMENT_PERSONAL_REFLECTION =
      "Personal reflection";
  static const String ADD_ACCOMPLISHMENT_COACH_PHONE_NUMBER =
      'Coach phone Number';
  static const String ADD_ACCOMPLISHMENT_COACH_EMAIL = 'Coach email';
  static const String ADD_ACCOMPLISHMENT_COACH_NAME = 'Coach name';
  static const String ADD_ACCOMPLISHMENT_TEAM_NAME = 'Team name';
  static const String ADD_ACCOMPLISHMENT_COLLEGE = 'College';

/*-----------------------------------Add Achievment -------------------------Start */

  static const String ADD_ACHIEVMENT_HOURS_WORKED = "Hours worked per week";
  static const String ADD_ACHIEVMENT_TITLE = "Title";
  static const String ADD_ACHIEVMENT_RECOMMENDATION_REQUEST =
      "Recommendation request";
  static const String ADD_ACHIEVMENT_RECOMMENDATION_TITLE =
      "Recommendation title";
  static const String ADD_ACHIEVMENT_GREATE_SOCCER_SEASON =
      "Hi Coach, What a great soccer season. Can you please take a few min to recommend me on my soccer, leadership, and team building skills.";
  static const String ADD_ACHIEVMENT_FIRST_NAME = "First name";
  static const String ADD_ACHIEVMENT_LAST_NAME = "Last name";
  static const String ADD_AACHIEVMENT_EMAIL = "Email";
  static const String ADD_AACHIEVMENT_DESCRIPTION = 'Description';
  static const String ADD_AACHIEVMENT_HIGHLIGHT_KAY_LEARNING =
      "Highlight key learnings and contributions";
  static const String ADD_AACHIEVMENT_DATE_FROM = "Date from";
  static const String ADD_AACHIEVMENT_DATE_TO = "Date to";
  static const String ADD_AACHIEVMENT_SAVE = "Save";
  static const String ADD_AACHIEVMENT_ENTER_DISPLAY_TITLE =
      "Enter display title";
  static const String ADD_AACHIEVMENT_FOCUS_AREA = "Focus area";
  static const String ADD_AACHIEVMENT_ACHIEVEMENT_LEVEL = "Achievement level";
  static const String ADD_AACHIEVMENT_VOLUNTEERING = "Volunteering";
  static const String ADD_AACHIEVMENT_SELECT_ALL_SKILLS =
      "Select all your skills from the list below:";
  static const String ADD_AACHIEVMENT_EACH_EXPERIENCE =
      "Each experience leads to skill building. So, select every skill you feel you built or exercised "
      "with this experience. Demonstrate why this experience was so enriching for you.";

  static const String ADD_AACHIEVMENT_DONE = 'Done';
  static const String ADD_AACHIEVMENT_SELECT_ALL = "Select all";
  static const String ADD_AACHIEVMENT_CONTINUE = "Continue";

/*----------------------------------ABOUT Group -------------------------Start */
  static const String ABOUT_GROUP_ABOUT_GROUP = "About group";
  static const String ABOUT_GROUP_CREATE_ON = "Created on:";
  static const String ABOUT_GROUP_GROUP_CREATE = ' Group created successfully ';
  static const String ABOUT_GROUP_INVITE_USER_LATER = "Invite users later";
  static const String ABOUT_GROUP_INVITE_USER_NOW = "Invite users now";
  static const String ABOUT_GROUP_GROUP_RULES = "Group rules";
  static const String ABOUT_GROUP_SAVE = 'Save ';
  static const String ABOUT_GROUP_DELETE = 'Delete ';
  static const String ABOUT_GROUP_CREATE = "Create";
  static const String ABOUT_GROUP_GROUP = "Group";
  static const String ABOUT_GROUP_GROUP_ = " group?";
  static const String ABOUT_GROUP_DISCOVER_ = "Discover";
  static const String ABOUT_GROUP_PRIVATE_GROUP = " Private group";
  static const String ABOUT_GROUP_GROUP_NAME = "Group name";
  static const String ABOUT_GROUP_FOR_STUDENT = "For student";
  static const String ABOUT_GROUP_ADD_STUDENT_AS_ADMIN =
      "Click to add your student as admin of this group ";
  static const String ABOUT_GROUP_SELECT_STUDENT = "Select student";
  static const String ABOUT_GROUP_PUBLIC_GROUP = " Public group";
  static const String ABOUT_GROUP_YOU_HAVE_NOT_PICKED_VIDEO =
      'You have not yet picked a video';
  static const String ABOUT_GROUP_NO_CONNECTIONS = "No connections ";
  static const String ABOUT_GROUP_SEARCH_YOUR_CONNECTIONS =
      'Search your connections';
  static const String ABOUT_GROUP_UPDATE = "Update";

  static const String ABOUT_GROUP_DONE = "Done";
  static const String ABOUT_GROUP_LEAVE = "Leave";

  static const String ABOUT_GROUP_DELETE1 = ' Delete ';
  static const String ABOUT_GROUP_LEAVE_GROUP = "Leave group";
  static const String ABOUT_GROUP_SUPPORT_REPORT_GROUP =
      "Find Support or Report Group";
  static const String ABOUT_GROUP_EDIT_GROUP = "Edit group";
  static const String ABOUT_GROUP_DELETE_GROUP = "Delete Group";
  static const String ABOUT_GROUP_GROUP_INVITATION =
      "Respond to group invitation";
  static const String ABOUT_GROUP_REJECTED = "Rejected";
  static const String ABOUT_GROUP_REQUESTED = "Requested";

  static const String ABOUT_GROUP_REQUEST_PENDING = "Request pending";
  static const String ABOUT_GROUP_REVOKE = "Withdraw";
  static const String ABOUT_GROUP_ACCEPTED = "Accepted";
  static const String ABOUT_GROUP_CONNECTED = "Connected";
  static const String ABOUT_GROUP_GO_AHEAD_SETUP =
      "Go ahead and setup one or participate in one!";
  static const String ABOUT_GROUP_IT_LOOKS_LIKEHAVENT =
      "It looks like you haven’t created or joined a group. Go ahead and setup one up or participate in one! You can start a club, become an influencer or contribute your knowledge for the greater good.";
  static const String ABOUT_GROUP_CREATE_GROUP = "Create group";
  static const String ABOUT_GROUP_FIND_GROUP_JOIN = "Find groups to join";
  static const String ABOUT_GROUP_DISCOVER_GROUP = "Discover group";
  static const String ABOUT_GROUP_DO_INTERESTS_PASSIONS =
      "Do have interests and passions and want to connect with other community members with similar interests? Join some groups start sharing your ideas.";
  static const String ABOUT_GROUP_DISCOVER = "Discover";
  static const String ABOUT_GROUP_SELECT_GROUP_INTERACT =
      'Select a group to interact with your audience';
  static const String ABOUT_GROUP_RECEIVED_REQUEST_FORYOU =
      "RECEIVED REQUEST FOR YOU ";
  static const String ABOUT_GROUP_VIEW_ALL = "View All";
  static const String ABOUT_GROUP_MY_GROUP_S = "MY GROUP(S)";
  static const String ABOUT_GROUP_PENDING_GROUP =
      "PENDING GROUP JOIN REQUEST(S)";
  static const String ABOUT_GROUP_FIND_GROUP = "FIND GROUPS TO JOIN";
  static const String ABOUT_GROUP_YOU_CANT_SEE = "You can’t see this post";
  static const String ABOUT_GROUP_SHARING_KNOWLEDGE =
      "Sharing knowledge is the most fundamental act of community building. Because it is a way you can give something without losing it. Start contributing, show leadership, and get involved with a post here.";
  static const String ABOUT_GROUP_JOIN_THE_GROUP =
      "Join the group now to catch up with like minded people on topics you care about and get access to all the posts and conversations.";
  static const String ABOUT_GROUP_JOIN_GROUP_CHECK_FEED =
      "Join the group to check all the feeds";
  static const String ABOUT_GROUP_INVITED = "Invited";
  static const String ABOUT_GROUP_PRIVATE = "private";
  static const String ABOUT_GROUP_FROM_GROUP_INVITATION =
      " from the group invitation?";
  static const String ABOUT_GROUP_INVITATION_MEMBERS = "Invited members";
  static const String ABOUT_GROUP_INVITATION_MEMBERS_ = "INVITE MEMBERS";
  static const String ABOUT_GROUP_INVITED_ANY_MEMBERS =
      "You haven’t invited any members yet";
  static const String ABOUT_GROUP_LOOKS_LIKE_THERE_MEMBERS =
      "Looks like there is no members at the moment, kindly invite to group";
  static const String ABOUT_GROUP_ADD_FRIEND = "Connect";
  static const String ABOUT_GROUP_GROUP_MEMBERS = "Group Members";

  static const String ABOUT_GROUP_INVITE_GROUP = "INVITE TO GROUP";

  static const String ABOUT_GROUP_GROUP_REQUEST = "Group request";
  static const String ABOUT_GROUP_GROUP_REQUESTs = "Group requests";

  static const String ABOUT_GROUP_RESPOND_GROUP_INVITATION =
      "Respond to group invitation";

  static const String ABOUT_GROUP_ITS_LOOKs =
      "It looks like you haven’t created or joined a group.";

/*----------------------------------INVITE BY EMAIL -------------------------Start */

  static const String INVITE_EMAIL_FIRST_NAME = "First name";
  static const String INVITE_EMAIL_LAST_NAME = "Last name";
  static const String INVITE_EMAIL_EMAIL = "Email";
  static const String INVITE_EMAIL_CLOSE = 'CLOSE ';
  static const String INVITE_EMAIL_INVITE_MEMBERS_EMAIL =
      "INVITE MEMBERS BY EMAIL";
  static const String INVITE_EMAIL_INVITE = 'INVITE ';
  static const String INVITE_EMAIL_INVITE_BY_EMAIL = "Invite by email";

  static const String INVITE_EMAIL_SEND_INVITE =
      "Send invite to non spikeview users ";
  static const String INVITE_EMAIL_INVITED = "Invited";
  static const String INVITE_EMAIL_SEARCH_SPIKEVIEW =
      "Search spikeview users from your connections to invite";
  static const String INVITE_EMAIL_MEMBER_REQUEST = "Member request";

/*----------------------------------TEXT SCORE  -------------------------Start */

  static const String TEXT_SCORE_DATE_TAKEN = "Date taken";

  static const String TEXT_SCORE_DO_YOU_WANT_PUBLISH =
      "Do you want to publish this test score to your public profile?";
  static const String TEXT_SCORE_PHOTOS = "Photos ";
  static const String TEXT_SCORE_TEST_SCORE = "Test Score";
  static const String TEXT_SCORE_SELECT_TEST = "Select a Test";
  static const String TEXT_SCORE_VIEW_PHOTOS = "View photos & documents";

  static const String TEXT_SCORE_DOCUMENTS = "Documents ";

  static const String TEXT_SCORE_UPDATE_TEST_SCORE = "Update your test score";

  static const String TEXT_SCORE_REMOVE_SCRORE =
      "Are you sure you want to remove this test score?";

  static const String TEXT_SCORE_USER_WONT_ABLE =
      "Users won’t be able to see your test scores until you change the settings from filter and will be shown when you share your profile.";

/*----------------------------------Skills   -------------------------Start */
  static const String SKILLS_DO_WANTS_PUBLIC_CERTIFICATE =
      "Do you want to publish this certificate to your public profile?";
  static const String SKILLS_DO_WANTS_PUBLIC_SKILL =
      "Do you want to publish this skills to your public profile?";
  static const String SKILLS_ISSUED_ON = "Issued on";
  static const String SKILLS_ISSUED_ON_ = 'Received on: ' ;
  static const String SKILLS_TITLE = "Title";
  static const String SKILLS_ADOBE_PHOTOSHOP = "Adobe photoshop";
  static const String SKILLS_CERTIFICATION = "Certification";
  static const String SKILLS_SURE_REMOVE_SKILL =
      "Are you sure you want to remove this skill?";
  static const String SKILLS_SURE_REMOVE_CERTIFICATE =
      "Are you sure you want to remove this certificate?";
  static const String SKILLS_AND_CERTIFICATION = "Skills & certifications";
  static const String SKILLS_ADD_CERTIFICATION = "Add certifications";
  static const String SKILLS_ADD_SKILLS = "Add skills";
  static const String SKILLS_ADD_OTHER_SKILLS = "Add other skills";
  static const String SKILLS = "Skills";
  static const String SKILLS_ADDITIONAL_SKILLS = "Add additional skills";
  static const String SKILLS_HIGHLIGHT_PROFILE = "Add any other skills you would like to highlight on your profile.";

/*----------------------------------RECOMMENDATIONS   -------------------------Start */

  static const String ADD_RECOMMENDATION_CLOSE = 'CLOSE';
  static const String ADD_RECOMMENDATION_DONE = 'DONE';
  static const String ADD_RECOMMENDATION_SELECT_SKILLS = "Select skills";
  static const String ADD_RECOMMENDATION_SKILLS = "Skills";
  static const String ADD_RECOMMENDATION_SELECT_FOCUS_1 = "Select focus area 1";
  static const String ADD_RECOMMENDATION_SELECT_FOCUS_2 = "Select focus area 2";
  static const String ADD_RECOMMENDATION_SELECT_FOCUS_3 = "Select focus area 3";
  static const String ADD_RECOMMENDATION_TITLE = "Title";
  static const String ADD_RECOMMENDATION_TITLE_HINT = "eg.Science teacher";
  static const String ADD_RECOMMENDATION_FIRST_NAME = "First name";
  static const String ADD_RECOMMENDATION_LAST_NAME = "Last name";
  static const String ADD_RECOMMENDATION_EMAIL = "Email";
  static const String ADD_RECOMMENDATION_ENTER_TITLE = "Enter title";
  static const String ADD_RECOMMENDATION_REC_TITLE = "Recommendation title";
  static const String ADD_RECOMMENDATION_GREAT_SOCCER_SEASON =
      "Hi Coach, What a great soccer season. Can you please take a few min to recommend me on my soccer,"
      " leadership, and team building skills.";
  static const String ADD_RECOMMENDATION_REQUEST = "Request";
  static const String ADD_RECOMMENDATION_DATE = "Date";
  static const String ADD_RECOMMENDATION_START_DATE = "Start date";
  static const String ADD_RECOMMENDATION_END_DATE = "End date";
  static const String ADD_RECOMMENDATION_TO = "To";
  static const String ADD_RECOMMENDATION_BADGE = "Badges";
  static const String ADD_REQUEST_BADGE = "Request or add a badge to your profile.";
 // static const String ADD_REQUEST_BADGE = "Request a badge to add to your profile.";
  static const String ADD_RECOMMENDATION_TROPHY = "Trophy";
  static const String ADD_RECOMMENDATION_RECOMMENDATION = "Recommendation";
  static const String MANAGE_BADGES_TITLE = "Badge";
  static const String ADD_RECOMMENDATION_RECOMMENDER_DETAILS =
      "Recommender details";
  static const String ADD_RECOMMENDATION_RECOMMENDATION_DETAIL =
      "Recommendation detail ";
  static const String ADD_RECOMMENDATION_FROM_FRIEND_COACH =
      "Add details of the recommender who sent you the recommendation.";
  static const String ADD_RECOMMENDATION_PERSONALIZED_MESSAGE =
      "Send a personalized message with your request.";
  static const String ADD_RECOMMENDATION_FOCUS_1 = "Focus area 1";
  static const String ADD_RECOMMENDATION_FOCUS_2 = "Focus area 2";
  static const String ADD_RECOMMENDATION_FOCUS_3 = "Focus area 3";
  static const String ADD_RECOMMENDATION_OTHER = "Other";
  static const String ADD_RECOMMENDATION_GENERAL = "General";
  static const String ADD_RECOMMENDATION_ADD_SKILLS = "Add skills...";
  static const String ADD_RECOMMENDATION_INTERACTION_DATE = "Interaction date";
  static const String ADD_RECOMMENDATION_WORK_WITH_RECOMMENDER =
      "Date when you worked with the recommender.";
  static const String ADD_RECOMMENDATION_ONGOING = "Ongoing   ";
  static const String ADD_RECOMMENDATION_ADD_MEDIA = "Add media";
  static const String ADD_RECOMMENDATION_UPLOAD_MEDIA = "Upload media";
  static const String ADD_RECOMMENDATION_SELECT_MEDIA = "Supported format: PNG, JPEG only";
  static const String ADD_RECOMMENDATION_PUBLISH_RECOMMENDATION =
      "Do you want to publish this recommendation to your public profile?";

  static const String ADD_RECOMMENDATION_REMOVE_RECOMMENDATION =
      "Are you sure you want to remove this recommendation?";

  static const String ADD_RECOMMENDATION_FROM = "From: ";
  static const String ADD_RECOMMENDATION_FOR = "For: ";
  static const String ADD_RECOMMENDATION_VIEW_REQUEST = "View";
  static const String ADD_RECOMMENDATION_ASK_RECOMMENDATION =
      "ASK FOR RECOMMENDATION";
  static const String ADD_RECOMMENDATION_RECOMMENDATION_REQUESTED =
      "RECOMMENDATIONS REQUESTED";
  static const String ADD_RECOMMENDATION_ADDED = "Added";
  static const String ADD_RECOMMENDATION_REPLIED = "RECOMMENDATIONS REPLIED";
  static const String ADD_RECOMMENDATION_PENDING = "RECOMMENDATIONS PENDING";
  static const String ADD_RECOMMENDATION_RECOMMENDATIONS = 'Recommendations';
  static const String ADD_RECOMMENDATION_REMINDER = 'Send reminder';
  static const String GROUP_REPORTED_HIDE = 'This group no longer exists.';
  static const String OPPORTUNITY_NOT_IN_COMMUNITY =
      'You are not authorized to access this group. Please check with your school admin.';
  static const String ALREADY_SKILL_ADDEDD = "Already Skill is added";
  static const String ALREADY_GOAL_ADDEDD = "Already Skill is added";
  static const String ALREADY_INTREST_ADDEDD = "Already Skill is added";
  static const String ALREADY_ORGANIZATION_ADDEDD = "Already Skill is added";
  static const String REQUEST_NO_LONGER_EXISTS = "  Request no longer exists.";


  static const String RECOMMENDER_REQUEST_TITLE = "Recommendations are a great way to strengthen your profile. Request a recommendation or add one if you have received from somewhere else.";
  static const String ADD_RECOMMENDATION = "Add Recommendation";
  static const String UPLOAD_RECOMMENDATION = "Please add or upload recommendation that you received from the recommender.";
  static const String YOU_CAN_UPLOAD_PDF ="Supported format: .pdf, .doc only";

  static const String RECOMMENDER_DETAILS_TITLE ="Add details of the recommender who sent you the recommendation.";

  static const String RECOMMENDATION_REQUESTADD_SUCCESS_TITLE = "We will notify you once the recommendation has been received.";

  static const String RECOMMENDATION_SELFADD_SUCCESS_TITLE = "Recommendation added to your profile";
  static const String RECOMMENDATION_REMINDER ="Reminder";
  static const String RECOMMENDATION_REQUEST_NO_DATA ="No requests available for your review.";
  static const String RECOMMENDATION_REPLIED_NO_DATA ="No requests pending for you.";
  static const String RECOMMENDATION_PENDING_NO_DATA ="No requests pending.";
  static const String RECOMMENDATION_SUBMIT =  "Recommendation sent successfully.";
  static const String RECOMMENDATION_PUP_HEADING_REQUEST =  "Request sent";
  static const String RECOMMENDATION_PUP_HEADING_ADD =  "Success";
  static const Recommendation_Reminder = 'RecommendationReminder';
  static const BADGES_Reminder = 'BadgeReminder';
  static const Recommendation_Pending = 'RecommendationPending';
  static const Recommendation_Replied = 'RecommendationReplied';
  static const Recommendation_RecommendationRequest = 'RecommendationRequest';

  static const BadgeRequest_Notification = 'BadgeRequest';
  static const BadgeCollection_Notification = 'BadgeCollection';
  static const BadgePresented_Notification = 'BadgePresented';
  static const Recommendation_TYPE = 'Recommendation';

  static void printWrapped(String text) {
    final pattern = RegExp('.{1,800}'); // 800 is the size of each chunk
    pattern.allMatches(text).forEach((match) => print(match.group(0)));
  }

  static const String ADD_Add_certificate = "Add certificate";
  static const String EDIT_Add_certificate = "Edit certificate";
  static const String Empty_connections= "You need to add some connections before you can share.";
}
