import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/group/InviteMember.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';

import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class GroupMembersListWidget extends StatefulWidget {
  String groupId, roleId;
  GroupDetailModel modell;
  String userIdPref, userProfilePath;

  GroupMembersListWidget(this.groupId, this.modell, this.userIdPref,
      this.roleId);

  @override
  State<StatefulWidget> createState() {
    return MainView();
  }
}

class MainView extends State<GroupMembersListWidget> {
  BuildContext context;
  SharedPreferences prefs;
  int item = 0;
  bool isConnection_AccessControl = true;
  String isPerformChanges = "pop",
      roleId,
      searchName = "";

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    roleId = prefs.getString(UserPreference.ROLE_ID);
    try {
      isConnection_AccessControl = prefs
          .getString(UserPreference.ACCESS_CONTROL_CONNECTION)
          .toLowerCase() ==
          "disable"
          ? false
          : true;
    } catch (e) {
      isConnection_AccessControl = true;
    }
    setState(() {});
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  // -------------------  API ------------------------------

  Future apiCallForConnect(userId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": widget.userIdPref,
          "partnerId": int.parse(userId),
          "userRoleId": int.parse(roleId),
          "partnerRoleId": int.parse(widget.modell.memberList[index].roleId),
          "dateTime": DateTime
              .now()
              .millisecondsSinceEpoch,
          "status": Util.currentAge(
              new DateTime.fromMillisecondsSinceEpoch(
                  int.tryParse(prefs.getString(UserPreference.DOB))),
              13) <
              13
              ? "Pending"
              : "Requested",
          "isActive": true
        };
        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg);

              widget.modell.memberList[index].connectionStatus = "Requested";
              if (mounted) {
                setState(() {});
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForDelete(userId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "groupId": widget.groupId,
          "status": "Rejected",
          "userId": int.parse(userId),
          "isAdmin": true,
          "roleId": int.parse(widget.modell.memberList[index].roleId),
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_DELETE_GROUP_MEMBER, map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg);

              if (mounted) {
                widget.modell.memberList.removeAt(index);
                setState(() {});
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  onTapImageTile(tapedUserId, roleId) {
    if (tapedUserId == widget.userIdPref) {} else {
      Util.onTapImageTile(
          tapedUserRole: roleId,
          partnerUserId: tapedUserId,
          context: context);
    }
  }

  void confromAtionDialog(memberModelDetail, index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            //  headingText: 'Remove from group',
            headingText: memberModelDetail.lastName ==
                null ||
                memberModelDetail.lastName ==
                    "null" ||
                memberModelDetail.lastName == ""
                ? MessageConstant.REMOVE_NAME_ +
                '"' +
                memberModelDetail.firstName +
                '"' +
                "?"
                : MessageConstant.REMOVE_NAME_ +
                '"' +
                memberModelDetail.firstName +
                " " +
                memberModelDetail.lastName +
                '"' +
                "?",
            negativeText: 'Cancel',
            positiveText: 'Remove',
            isThreeStepPopup:true,
            positiveTextColor: AppConstants
                .colorStyle.btn_text_red,
            onNegativeTap: () {},
            onPositiveTap: () {
              apiCallForDelete(
                  memberModelDetail.userId,
                  index);
            },
            msg: null,
          );
        });
  }

  Container getListview(memberModelDetail, index, bool isSentRequest) {
    setState(() {
      item++;
    });
    return Container(
        padding: EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 0.0),
        child: Card(
            elevation: 0.0,
            child: Column(
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      child: InkWell(
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: Container(
                              height: memberModelDetail.profilePicture ==
                                  null ||
                                  memberModelDetail.profilePicture ==
                                      'null' ||
                                  memberModelDetail.profilePicture ==
                                      '' ||
                                  memberModelDetail.profilePicture == ' '
                                  ? 58
                                  : 48.0,
                              width: memberModelDetail.profilePicture ==
                                  null ||
                                  memberModelDetail.profilePicture ==
                                      'null' ||
                                  memberModelDetail.profilePicture ==
                                      '' ||
                                  memberModelDetail.profilePicture == ' '
                                  ? 58
                                  : 48.0,
                              child: FadeInImage(
                                fit: BoxFit.cover,
                                placeholder: AssetImage(
                                  'assets/profile/user_on_user.png',
                                ),
                                image: NetworkImage(Constant
                                    .IMAGE_PATH_SMALL +
                                    ParseJson.getSmallImage(
                                        memberModelDetail.profilePicture)),
                              ),
                            )),
                        onTap: () {
                          onTapImageTile(memberModelDetail.userId,
                              memberModelDetail.roleId);
                        },
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          0.0,
                          0.0,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              /*Row(
                                children: <Widget>[
                                  Flexible(
                                    child: BaseText(
                                      text:
                                      memberModelDetail.firstName ==
                                          null ||
                                          memberModelDetail
                                              .firstName ==
                                              "null" ||
                                          memberModelDetail
                                              .firstName ==
                                              "" ||
                                          memberModelDetail
                                              .firstName ==
                                              "NA"
                                          ? memberModelDetail.email
                                          : memberModelDetail.lastName ==
                                          null ||
                                          memberModelDetail
                                              .lastName ==
                                              "null" ||
                                          memberModelDetail
                                              .lastName ==
                                              ""
                                          ? memberModelDetail
                                          .firstName
                                          : memberModelDetail
                                          .firstName +
                                          " " +
                                          memberModelDetail
                                              .lastName,
                                      textColor: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      textAlign: TextAlign.start,
                                      maxLines: 3,
                                    ),
                                  ),

                                ],
                              ),*/
                              RichText(text: TextSpan(
                                text:  memberModelDetail.firstName ==
                                    null ||
                                    memberModelDetail
                                        .firstName ==
                                        "null" ||
                                    memberModelDetail
                                        .firstName ==
                                        "" ||
                                    memberModelDetail
                                        .firstName ==
                                        "NA"
                                    ? memberModelDetail.email
                                    : memberModelDetail.lastName ==
                                    null ||
                                    memberModelDetail
                                        .lastName ==
                                        "null" ||
                                    memberModelDetail
                                        .lastName ==
                                        ""
                                    ? memberModelDetail
                                    .firstName
                                    : memberModelDetail
                                    .firstName +
                                    " " +
                                    memberModelDetail
                                        .lastName,
                                style: TextStyle(
                                  color: ColorValues
                                      .HEADING_COLOR_EDUCATION_1,
                                  fontFamily: AppConstants
                                      .stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                ),
                                children: [
                                  WidgetSpan(
                                    child: memberModelDetail.roleId == "1"
    ? Padding(
                                      padding: const EdgeInsets.only(
                                          left: 1.0,
                                          top: 4.0,
                                          right: 10),
                                      child: Util
                                          .getStudentBadgeMember(
    memberModelDetail.badge,
    memberModelDetail.badgeImage),
                                    )
                                        : const SizedBox.shrink(),
                                  )


                           /*       WidgetSpan(child: memberModelDetail.roleId == "1"
                                      ? Util.getStudentBadge15(
                                      memberModelDetail.badge,
                                      memberModelDetail.badgeImage)
                                      : SizedBox(),
                                    alignment: PlaceholderAlignment.top*/

                                ]
                              ),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 2,
                              ),
                              memberModelDetail.tagline == null ||
                                  memberModelDetail.tagline == "null" ||
                                  memberModelDetail.tagline == ""
                                  ? new Container(
                                height: 0.0,
                              )
                                  : Padding(
                                  padding: const EdgeInsets.only(
                                      top: 4.0, bottom: 5),
                                  child: BaseText(
                                    text: memberModelDetail.tagline ==
                                        null ||
                                        memberModelDetail.tagline ==
                                            "null" ||
                                        memberModelDetail.tagline ==
                                            ""
                                        ? ""
                                        : memberModelDetail.tagline,
                                    textColor: AppConstants
                                        .colorStyle.lightPurple,
                                    fontFamily: AppConstants
                                        .stringConstant.latoRegular,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                    textAlign: TextAlign.start,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ))
                            ],
                          )),
                      flex: 1,
                    ),
                    Expanded(
                      child: Row(
                        children: <Widget>[
                          widget.roleId == "4"
                              ? Container(width: 30.0)
                              : memberModelDetail.connectionStatus ==
                              "Not Connected"
                              ? prefs != null &&
                              Util.showAcceptButton(
                                  prefs,
                                  memberModelDetail
                                      .schoolCode,
                                  "") ==
                                  "true"
                              ? InkWell(
                            child: Padding(
                                padding: EdgeInsets.fromLTRB(
                                    0.0, 0.0, 0.0, 0.0),
                                child: Container(
                                    height: 26.0,

                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      color: AppConstants
                                          .colorStyle
                                          .box_bg_color,
                                      border: Border.all(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_2,
                                          width: 1),
                                      borderRadius:
                                      BorderRadius.circular(
                                          10),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment
                                          .center,
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .center,
                                      children: <Widget>[
                                        Padding(
                                          padding: EdgeInsets
                                              .fromLTRB(
                                              8.0,
                                              0.0,
                                              8.0,
                                              2.0),
                                          child: BaseText(
                                            text: MessageConstant
                                                .ABOUT_GROUP_ADD_FRIEND,
                                            textColor:
                                            AppConstants
                                                .colorStyle
                                                .lightBlue,
                                            fontFamily: AppConstants
                                                .stringConstant
                                                .latoRegular,
                                            fontWeight:
                                            FontWeight.w400,
                                            fontSize: 14,
                                            textAlign:
                                            TextAlign.start,
                                            maxLines: 3,
                                          ),
                                        ),
                                      ],
                                    ))),
                            onTap: () {
                              if (isConnection_AccessControl) {
                                apiCallForConnect(
                                    memberModelDetail.userId, index);
                              } else {
                                ToastWrap.showToastForAccessDenied(
                                    MessageConstant.FEATURE_DIABLED, context);
                              }
                            },
                          )
                              : SizedBox()
                              : memberModelDetail.connectionStatus ==
                              MessageConstant.ABOUT_GROUP_ACCEPTED
                              ? InkWell(
                            child: Padding(
                                padding: EdgeInsets.fromLTRB(
                                    0.0, 0.0, 0.0, 0.0),
                                child: Container(
                                    height: 26.0,

                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      color: AppConstants
                                          .colorStyle.lightBg,
                                      borderRadius:
                                      BorderRadius.circular(
                                          10),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment
                                          .center,
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .center,
                                      children: <Widget>[
                                        Padding(
                                          padding: EdgeInsets
                                              .fromLTRB(
                                              8.0,
                                              0.0,
                                              8.0,
                                              2.0),
                                          child: BaseText(
                                            text: MessageConstant
                                                .ABOUT_GROUP_CONNECTED,
                                            textColor:
                                            AppConstants
                                                .colorStyle
                                                .lightPurple,
                                            fontFamily: AppConstants
                                                .stringConstant
                                                .latoRegular,
                                            fontWeight:
                                            FontWeight.w400,
                                            fontSize: 14,
                                            textAlign:
                                            TextAlign.start,
                                            maxLines: 3,
                                          ),
                                        ),
                                      ],
                                    ))),
                            onTap: () {},
                          )
                              : memberModelDetail.connectionStatus ==
                              MessageConstant
                                  .ABOUT_GROUP_REQUESTED
                              ? InkWell(
                            child: Padding(
                                padding:
                                EdgeInsets.fromLTRB(
                                    0.0, 0.0, 0.0, 0.0),
                                child: Container(
                                    height: 26.0,

                                    alignment:
                                    Alignment.center,
                                    decoration:
                                    BoxDecoration(
                                      color: AppConstants
                                          .colorStyle
                                          .lightBg,
                                      borderRadius:
                                      BorderRadius
                                          .circular(10),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment
                                          .center,
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .center,
                                      children: <Widget>[
                                        Padding(
                                          padding:
                                          EdgeInsets
                                              .fromLTRB(
                                              8.0,
                                              0.0,
                                              8.0,
                                              2.0),
                                          child: BaseText(
                                            text: MessageConstant
                                                .ABOUT_GROUP_REQUESTED,
                                            textColor: AppConstants
                                                .colorStyle
                                                .lightPurple,
                                            fontFamily: AppConstants
                                                .stringConstant
                                                .latoRegular,
                                            fontWeight:
                                            FontWeight
                                                .w400,
                                            fontSize: 14,
                                            textAlign:
                                            TextAlign
                                                .start,
                                            maxLines: 3,
                                          ),
                                        ),
                                      ],
                                    ))),
                            onTap: () {},
                          )
                              : Container(
                            height: 0.0,
                          ),
                          memberModelDetail.isAdmin == "true"
                              ? Container(
                            height: 0.0,
                          )
                              : widget.modell.isAdmin
                              ? InkWell(
                            child: Padding(
                                padding: EdgeInsets.fromLTRB(
                                    10.0, 0.0, 0.0, 0.0),
                                child: Container(
                                    height: 22.0,
                                    width: 22.0,
                                    child: Image.asset(
                                      'assets/newDesignIcon/connections/cancel.png',
                                    ))),
                            onTap: () {
                              confromAtionDialog(
                                  memberModelDetail, index);
                            },
                          )
                              : Container(
                            height: 0.0,
                          )
                        ],
                      ),
                      flex: 0,
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 16.0, bottom: 8),
                  child: Container(
                    height: 1,
                    color: AppConstants.colorStyle.btnBg,
                  ),
                )
              ],
            )));
  }

  invite() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            InviteMember(
                widget.modell.groupId, "member",
                widget.modell.allMembersList)));

    if (result == "push") {
      Navigator.pop(context, "push");
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;

    return customAppbar(
      context,
      GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 20.0, right: 20, top: 24, bottom: 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      BaseText(
                        text: 'Group members',
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ),
                    ],
                  ),
                ),
                flex: 0,
              ),
              Expanded(
                child: widget.modell.memberList.length == 0
                    ? SizedBox()
                    : Container(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.fromLTRB(
                              20.0, 17.0, 20.0, 10.0),
                          child: SizedBox(
                            height: 40,
                            child: TextField(
                              textAlign: TextAlign.left,
                              onChanged: (value) {
                                // Method For Searching
                                searchName = value;
                                if (searchName.isEmpty) {
                                  item = 0;
                                  setState(() {});
                                }
                                print("SSS Seacrh Name ${searchName}");
                              },
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: ColorValues.TAB_BACKGROUND_COLOR,
                                hintText: "Search group member",
                                hintStyle: TextStyle(
                                    fontSize: 14, color: ColorValues.hintColor,
                                    fontFamily: Constant.latoRegular),
                                contentPadding: EdgeInsets.fromLTRB(
                                    15.0, 10.0, 20.0, 10.0),
                                suffixIcon: IconButton(
                                  onPressed: () {
                                    setState(() {
                                      item = 0;
                                      searchName;
                                    });
                                  },
                                  icon: Image.asset(
                                    "assets/newDesignIcon/connections/new_search.png",
                                    height: 20,
                                    width: 20,
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(10.0),
                                  ),
                                  borderSide: BorderSide(
                                      color: ColorValues.BORDER_COLOR_NEW),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(10.0),
                                  ),
                                  borderSide: BorderSide(
                                      color: ColorValues.BORDER_COLOR_NEW),
                                ),
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(10.0),
                                    ),
                                    borderSide: new BorderSide(
                                        color: ColorValues.BORDER_COLOR_NEW)),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                            child: ListView(
                              padding: EdgeInsets.zero,
                              children: <Widget>[
                                Column(
                                  children: List.generate(
                                      widget.modell.memberList.length,
                                          (int index) {
                                        return (searchName == '' ||
                                            widget.modell.memberList[index]
                                                .firstName
                                                .toString()
                                                .toLowerCase()
                                                .startsWith(searchName))
                                            ? getListview(
                                            widget.modell.memberList[index],
                                            index,
                                            false)
                                            : SizedBox();
                                      }),
                                ),
                                item > 0
                                    ? SizedBox()
                                    : Padding(
                                  padding:
                                  const EdgeInsets.only(top: 140.0),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                    MainAxisAlignment.center,
                                    children: <Widget>[
                                      PaddingWrap.paddingAll(
                                          10.0,
                                          Image.asset(
                                            "assets/png/no_user_found.png",
                                            height: 111.0,
                                          )),
                                      Column(
                                        children: <Widget>[
                                          BaseText(
                                            text: "No user found",
                                            textColor: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: AppConstants
                                                .stringConstant.latoMedium,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 18,
                                            textAlign: TextAlign.center,
                                            maxLines: 1,
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ))
                      ],
                    )),
                flex: 1,
              ),
            ],
          )),
          () {
        Navigator.pop(context);
      },
      isShowIcon: false,
    );
  }
}
