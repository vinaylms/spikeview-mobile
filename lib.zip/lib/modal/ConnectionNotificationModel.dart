import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';

class ConnectionNotificationModel {
  String connectionCount,messagingCount,notificationCount,groupCount;

  ConnectionNotificationModel(this.connectionCount, this.messagingCount,
      this.notificationCount,this.groupCount);

}
