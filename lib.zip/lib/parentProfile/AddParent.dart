import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/CustomDropdownButtonNew.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/positive_button.dart';

import 'package:geocoder/geocoder.dart';
import 'package:google_maps_webservice/places.dart';

// Create a Form Widget
class AddParent extends StatefulWidget {
  String title, parentName;
  String studentId;

  AddParent(this.title, this.studentId, this.parentName);

  @override
  AddParentState createState() {
    return AddParentState();
  }
}

class AddParentState extends State<AddParent> {
  static const platform = const MethodChannel('samples.flutter.io/battery');
  SharedPreferences prefs;
  String userIdPref, token;
  final _formKey = GlobalKey<FormState>();
  TextEditingController dobController;
  int strDateOfBirth = 0;
  int diffrenceInDob = 14;
  DateTime pickedDate;
  bool isValid = true;
  String isMostCloselyIdentified = "";
  String dob, strDate;
  String strParentZip = "";
  TextEditingController parentZipController = TextEditingController(text: ""),
      firstNameParentController = TextEditingController(),
      lastNameParentController = TextEditingController(),
      parentEmailController = TextEditingController();
  String strFirstName, strLastName, strEmail;
  FocusNode zipcodeFocusNode = FocusNode();
  String strCountryName = "";
  bool isStudentCountrySelected = true;
  CountryList _mCountryItem;
  CountryListModel _mCountryListModel;
  List<CountryList> countryList = List();
  final searchCountryController = TextEditingController();
  List<Item> countries = List();
  Item selectedCityItem;
  bool isShowErrorMsg = false;
  bool isShowStudentCitySelectionError = true;
  bool showList = false;
  String userProfile,
      sasToken = '',
      strAdd = "",
      containerName = '',
      strPrefixPathForPhoto = '';
  File profileImageFile;
  Map addressData = {};
  final add1Controller = TextEditingController();
  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: Constant.kGoogleApiKey);

  bool allFieldCompletedParent = false;

  List<String> genderList = [
    "NA",
    "Non-Binary",
    "Female",
    "Male",
  ].toList();

  showSucessMsg(msg, context) {
    Timer(const Duration(milliseconds: 2000), () async {
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    strPrefixPathForPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
  }

  //--------------------------Api Calling ------------------
  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;
        String city = "", state = "", country = "";

        /*   if (selectedCityItem == null) {
          try {
            Response response1 = await Util.getDetailUsingZipCodeNew(
                false, context, parentZipController.text);

            //apurva added for zip code validation start
            if (response1 == null) {
              print('apurva address2.country:: response:: $response1');
              //CustomProgressLoader.cancelLoader(context);
              CustomProgressLoader.cancelLoader(context);
              isShowErrorMsg = true;
              setState(() {});
              */ /*  ToastWrap.showToast2Sec(
                  MessageConstant.ENTER_VALID_ZIP_CODE_VAL, context);*/ /*
              return;
            } else {
              print('apurva address2.country:: response:: elseee $response1');
            }
            //apurva added for zip code validation end

            final data = response1.data['results'][0]["address_components"];

            if (data.length > 3) {
              city = data[data.length - 3]['long_name'];
              state = data[data.length - 2]['long_name'];
              country = data[data.length - 1]['long_name'];
            } else if (data.length > 0) {
              //city=json[1]['long_name'];
              state = data[data.length - 2]['long_name'];
              country = data[data.length - 1]['long_name'];
            }

            //Apurva Added for match country and zipode start
            if (country.toString().trim() !=
                _mCountryItem.name.toString().trim()) {
              CustomProgressLoader.cancelLoader(context);
              isShowErrorMsg = true;
              setState(() {});

              //////////
              //print('apurva address2.country:: country:: $country');
              //print('apurva address2.country:: _mCountryItem.name:: ${_mCountryItem.name}');
              //CustomProgressLoader.cancelLoader(context);
              */ /* ToastWrap.showToast2Sec(
                  MessageConstant.ENTER_VALID_COUNTRY_ZIP_CODE_VAL,
                  context);*/ /*
              return;
            }
            //Apurva Added for match country and zipode end

          } catch (e) {
            crashlytics_bloc.recordCrashlyticsError(
                e, "EditUserProfile", context);
          }
        }*/

        Map map = {
          "roleId": 2,
          "firstName": strFirstName,
          "lastName": strLastName,
          "email": strEmail.toLowerCase(),
          "userId": userIdPref,
          "parentName": widget.parentName,
          "studentId": widget.studentId,
          "dob": strDateOfBirth,
          "profileImage": userProfile ?? '',
          "zipCode": parentZipController.text,
          "gender": isMostCloselyIdentified,
          /*"state": selectedCityItem != null
              ? selectedCityItem.state
              : state
                  ,
          "city": selectedCityItem != null
              ? selectedCityItem.city
              : city,
          "country": _mCountryItem == null ? "" : _mCountryItem.name,*/
          "mobileNo": "",

          "city": addressData['city'] ?? "",
          "state": addressData['state'] ?? "",
          "country": addressData['country'] ?? "",
          "zipCode": addressData['zip'] ?? "",
          //  "address": add1Controller.text,
          "address": addressData,
        };
        log("map:-" + map.toString());
        response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_PARENT_ADD, map);
        CustomProgressLoader.cancelLoader(context);
        log("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              Navigator.pop(context, "push");
              //  showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddParent", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future _callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        final response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null && response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
    }
  }

  Future<String> _uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod(
            'getBatteryLevel',
            {
              "sasToken": sasToken,
              "imagePath": imagePath,
              "uploadPath": Constant.IMAGE_PATH + prefixPath
            },
          );
          return result;
        } else {
          return "";
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return "";
      }
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      return "";
    }
  }

  Future<void> _fileUploading(String filePath) async {
    try {
      if (filePath.isNotEmpty) {
        CustomProgressLoader.showLoader(context);
        String strAzureImageUploadPath = await _uploadImgOnAzure(
            filePath.replaceAll("File: ", "").replaceAll("'", "").trim(),
            strPrefixPathForPhoto);
        CustomProgressLoader.cancelLoader(context);
        if (strAzureImageUploadPath != null ||
            strAzureImageUploadPath != "false") {
          userProfile = strPrefixPathForPhoto + strAzureImageUploadPath;
          setState(() {});
        }
      } else {
        debugPrint("------ _fileUploading file path empty");
        setState(() {});
      }
    } catch (e) {
      debugPrint("------ _fileUploading error ${e.toString()}");
      setState(() {});
    }
  }

  Future getCountry() async {
    print('inside getPreLoginData() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCallWithouAuth(context, Constant.ENDPOINT_GET_COUNTRY, "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mCountryListModel = CountryListModel.fromJson(response.data);
              setState(() {
                _mCountryListModel;
                countryList.addAll(_mCountryListModel.countryList);
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddParent", context);
      e.toString();
    }
  }

  initCountryList(text, sortname) async {
    countries.clear();
    countries = await API.fetchCountryListForSignup(text, 'cities', sortname);
    if (countries.length > 0) {
      setState(() {});
    }
  }

  @override
  void initState() {
    _callApiForSaas();
    dobController = TextEditingController(text: '');
    //  genderList.add("Gender");

    searchCountryController.addListener(() {
      if (searchCountryController.text.isEmpty) {
        setState(() {
          countries.clear();
        });
      } else {
        if (searchCountryController.text.trim().length >= 1) {
          initCountryList(
              searchCountryController.text.trim(), _mCountryItem.sortname);
        }
      }
    });

    setState(() {
      genderList = genderList.reversed.toList();
    });
    getSharedPreferences();
    getCountry();
    super.initState();
  }

  Widget _buildAddedItem(Item item, Animation animation, type) {
    return FadeTransition(
      opacity: CurvedAnimation(curve: Curves.linear, parent: animation),
      child: SizeTransition(
        axis: Axis.vertical,
        sizeFactor: CurvedAnimation(curve: Curves.linear, parent: animation),
        child: InkWell(
          onTap: () {
            print("item++++" + item.name);
            print("item++++" + item.city);
            print("item++++" + item.country);
            print("item++++" + item.state);

            searchCountryController.text = item.name;
            selectedCityItem = item;
            showList = !showList;

            //searchCountryController.clear();
            setState(() {});
          },
          child: AnimatedContainer(
            curve: Curves.easeIn,
            duration: Duration(milliseconds: 500),
            width: MediaQuery.of(context).size.width,
            child: Text(item.name,
                style: TextStyle(fontFamily: Constant.customRegular)),
            padding: EdgeInsets.all(8),
          ),
        ),
      ),
    );
  }

  Widget countryOrCityListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? countries.length > 0
                ? Container(
                    height: countries.length == 1
                        ? 40.0
                        : countries.length == 2
                            ? 90.0
                            : countries.length == 3
                                ? 130
                                : 200.0,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(13.0, 0, 13, 0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(
                              color: ColorValues.BORDER_COLOR, width: 0.5),
                        ),
                        padding: countries.length > 0
                            ? EdgeInsets.all(0)
                            : EdgeInsets.all(0),
                        child: ListView(
                          children: [
                            AnimatedList(
                              physics: NeverScrollableScrollPhysics(),
                              initialItemCount: countries.length,
                              shrinkWrap: true,
                              itemBuilder: (context, index, animation) {
                                /* animation = CurvedAnimation(
                                        curve: Curves.linear, parent: animation);*/

                                return _buildAddedItem(
                                    countries.length == 1
                                        ? countries[0]
                                        : countries[index],
                                    animation,
                                    "student");
                              },
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                : Container()
            : Container(),
      ],
    );
  }

  checkAllFieldSubmitterParent() {
    try {
      print('++++++++checkAllFieldSubmitterParent');
      print('++++++++checkAllFieldSubmitterParent+' +
          firstNameParentController.text);
      print('++++++++checkAllFieldSubmitterParent+' +
          lastNameParentController.text);
      print(
          '++++++++checkAllFieldSubmitterParent+' + parentEmailController.text);
      print('++++++++checkAllFieldSubmitterParent+' +
          dobController.text.toString());
      print('++++++++checkAllFieldSubmitterParent+' +
          add1Controller.text.toString());
      print('++++++++checkAllFieldSubmitterParent+' +
          isMostCloselyIdentified.toString());
      if (ValidationWidget.isName(firstNameParentController.text) &&
          ValidationWidget.isName(lastNameParentController.text) &&
          ValidationWidget.isEmail(parentEmailController.text) &&
          dobController.text.length > 0 &&
          add1Controller.text.length > 0 &&
          isMostCloselyIdentified.length > 0) {
        print('++++++++true');
        allFieldCompletedParent = true;
        setState(() {});
      } else {
        print('++++++++false');
        allFieldCompletedParent = false;
        setState(() {});
      }
    } catch (e) {
      print('++++++++error' + e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return customAppbar(
      context,
      GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: FormKeyboardActions(
          nextFocus: false,
          keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
          //optional
          keyboardBarColor: Colors.grey[200],
          //optional
          actions: [
            KeyboardAction(
              focusNode: zipcodeFocusNode,
            ),
          ],
          child: Theme(
            data: ThemeData(hintColor: Colors.grey[300]),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      BaseText(
                        text: widget.title,
                        textColor: AppConstants.colorStyle.darkBlue,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        textAlign: TextAlign.start,
                        maxLines: 1,
                      ),
                      const SizedBox(height: 20),
                      CustomFormField(
                        autovalidateMode: AutovalidateMode.disabled,
                        textInputType: TextInputType.text,
                        maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
                        alignLabelWithHint: true,
                        onType: (val) {
                          checkAllFieldSubmitterParent();
                        },
                        controller: firstNameParentController,
                        onSaved: (val) => strFirstName = val,
                        label: 'Parent\'s first name',
                        validation: (val) => val.trim().length == 0
                            ? MessageConstant.ENTER_FIRST_NAME_VAL
                            : !ValidationWidget.isName(val)
                                ? MessageConstant
                                    .FIRST_NAME_CONTAINS_ALPHABET_VAL
                                : null,
                      ),
                      const SizedBox(height: 18),
                      CustomFormField(
                        autovalidateMode: AutovalidateMode.disabled,
                        textInputType: TextInputType.text,
                        maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
                        alignLabelWithHint: true,
                        label: 'Parent\'s last name',
                        onType: (val) {
                          checkAllFieldSubmitterParent();
                        },
                        controller: lastNameParentController,
                        onSaved: (val) => strLastName = val,
                        validation: (val) => val.trim().length == 0
                            ? MessageConstant.ENTER_LAST_NAME_VAL
                            : !ValidationWidget.isName(val)
                                ? MessageConstant
                                    .LAST_NAME_CONTAINS_ALPHABET_VAL
                                : null,
                      ),
                      const SizedBox(height: 18),
                      CustomFormField(
                        autovalidateMode: AutovalidateMode.disabled,
                        textInputType: TextInputType.emailAddress,
                        alignLabelWithHint: true,
                        onType: (val) {
                          checkAllFieldSubmitterParent();
                        },
                        controller: parentEmailController,
                        label: 'Parent\'s email',
                        validation: (val) => val.trim().length == 0
                            ? MessageConstant.ENTER_EMAIL_VAL
                            : !ValidationWidget.isEmail(val)
                                ? MessageConstant.VALID_EMAIL_VAL
                                : null,
                        onSaved: (val) => strEmail = val,
                      ),
                      const SizedBox(height: 18),
                      CustomFormField(
                          onSaved: (val) => strDate = val,
                          readOnly: true,
                          controller: dobController,
                          alignLabelWithHint: true,
                          label: "Parent\'s date of birth",
                          onClick: () async {
                            DateTime pickedDate1 = await showDatePicker(
                              context: context,
                              initialDate: pickedDate == null
                                  ? DateTime.now()
                                  : pickedDate,
                              firstDate: DateTime(1900),
                              lastDate: DateTime.now(),
                              confirmText: 'Apply',
                              cancelText: 'Cancel',
                            );
                            if (pickedDate1 != null) {
                              pickedDate = pickedDate1;
                              strDateOfBirth =
                                  pickedDate1.millisecondsSinceEpoch;
                              String date = Util.getDate(pickedDate1);
                              diffrenceInDob = Util.currentAge(pickedDate1, 18);
                              setState(() {
                                dobController =
                                    TextEditingController(text: date);
                              });
                              checkAllFieldSubmitterParent();
                            }
                          },
                          validation: (value) {
                            return value.length == 0
                                ? MessageConstant.SELECT_DATE_TAKEN_VAL
                                : Util.currentAge(pickedDate, 18) < 18
                                    ? MessageConstant
                                        .SORRY_OVER_18_BECOME_PARENT_ERROR
                                    : null;
                          }),
                      const SizedBox(height: 18),
                      CustomFormField(
                          onSaved: (val) => strAdd = val,
                          readOnly: true,
                          alignLabelWithHint: true,
                          autovalidateMode: AutovalidateMode.disabled,
                          textInputType: TextInputType.text,
                          label: "Address",
                          controller: add1Controller,
                          onType: (v) {
                            checkAllFieldSubmitterParent();
                          },
                          onClick: () {
                            _handlePressButton();
                          },
                          validation: (value) {
                            return value.length == 0
                                ? 'Please enter valid address'
                                : null;
                          }),

                      /*     CustomDropdownButtonFormFieldNew(
                        icon: Image.asset(
                          'assets/recommendation/ic_arrow_down.png',
                          height: 24,
                          width: 24,
                        ),
                        items: countryList
                            .map(
                              (item) => CustomDropdownMenuItem<CountryList>(
                                value: item,
                                child: Text(
                                  item.name,
                                  style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: Constant.latoMedium,
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: (s) {
                          setState(() {
                            _mCountryItem = s;
                          });
                        },
                        value: _mCountryItem,
                        labelText: "Select parent's country",
                      ),
                      isStudentCountrySelected
                          ? const SizedBox.shrink()
                          : Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: Text(
                                "Please select country",
                                style: TextStyle(
                                  color: Colors.red[600],
                                  fontSize: 12,
                                ),
                              ),
                            ),
                      _mCountryItem == null
                          ? _zipField()
                          : _mCountryItem.isZipcode
                              ? _zipField()
                              : Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                          color: isShowStudentCitySelectionError
                                              ? Palette.dividerColor
                                              : Colors.red[600]),
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Expanded(
                                            flex: 1,
                                            child: TextFormField(
                                              decoration:
                                                  _decoration('Select City'),
                                              controller:
                                                  searchCountryController,
                                              onChanged: (value) {
                                                setState(() {
                                                  showList = true;
                                                });
                                              },
                                            ),
                                          ),
                                          searchCountryController.text.length >
                                                  0
                                              ? IconButton(
                                                  onPressed: () {
                                                    showList = !showList;
                                                    setState(() {});
                                                  },
                                                  icon: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 15.0),
                                                    child: Icon(showList
                                                        ? Icons.arrow_drop_up
                                                        : Icons
                                                            .arrow_drop_down),
                                                  ),
                                                )
                                              : const SizedBox.shrink(),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                      isShowStudentCitySelectionError
                          ? const SizedBox.shrink()
                          : Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: Text(
                                "Please select city",
                                style: TextStyle(
                                  color: Colors.red[600],
                                  fontSize: 12.0,
                                ),
                              ),
                            ),
                      countryOrCityListWidget(),*/
                      const SizedBox(height: 40),
                      _genderView(),
                      const SizedBox(height: 60),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      () {
        Navigator.pop(context);
      },
      isShowIcon: false,
      bottomNavigation: Container(
          height: 44,
          margin: const EdgeInsets.fromLTRB(20, 20, 20, 66),
          child: Stack(
            children: [
              InkWell(
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(
                    color: AppConstants.colorStyle.lightBlue,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    'Save',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: ColorValues.WHITE,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 18,
                    ),
                  ),
                ),
                onTap: () {
                  _checkValidation();
                },
              ),
              allFieldCompletedParent
                  ? SizedBox(
                      height: 0,
                    )
                  : Container(
                      height: 46.0,
                      width: double.infinity,
                      color: Colors.white.withOpacity(0.75),
                    )
            ],
          )),
    );
  }

  void _checkValidation() {
    final form = _formKey.currentState;
    form.save();
    /*   setState(() {
      isShowErrorMsg = false;
    });
    if (strDateOfBirth == 0) {
      setState(() {
        isValid = false;
      });
    } else {
      setState(() {
        isValid = true;
      });
    }
    if (_mCountryItem == null) {
      setState(() {
        isStudentCountrySelected = false;
      });
    } else {
      setState(() {
        isStudentCountrySelected = true;
      });
    }

    if (_mCountryItem != null &&
        (!_mCountryItem.isZipcode) &&
        selectedCityItem == null) {
      isShowStudentCitySelectionError = false;
    } else {
      isShowStudentCitySelectionError = true;
    }*/

    if (form.validate()) {
      try {
        /* if (strDateOfBirth == 0) {
          setState(() {
            isValid = false;
          });
        }
        if (!isStudentCountrySelected) {
          setState(() {});
        } else if (!isShowStudentCitySelectionError) {
        } else {
          setState(() {
            isValid = true;
          });
          if (diffrenceInDob < 18) {
            ToastWrap.showToast(
                MessageConstant.SORRY_OVER_18_BECOME_PARENT_ERROR, context);
          } else {
            apiCalling();
          }
        }*/
        apiCalling();
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "AddParent", context);
        //CustomProgressLoader.cancelLoader(context);
      }
    } else {
      print("Failure 00");
    }
  }

  InputDecoration _decoration(String name, {String helperText}) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        5.0,
      ),
      labelText: name,
      errorStyle: TextStyle(
          fontFamily: AppTextStyle.getFont(FontType.Regular),
          color: Palette.redColor),
      helperText: helperText,
      helperStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          ColorValues.hintColor, 14, FontType.Regular),
      labelStyle: TextStyle(
          color: ColorValues.GREY_TEXT_COLOR,
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
      enabledBorder: InputBorder.none,
      focusedBorder: InputBorder.none,
      border: InputBorder.none,
    );
  }

  Widget _genderView() {
    return Row(
      children: <Widget>[
        Flexible(
          child: InkWell(
            onTap: () {
              print('male++++++==');
              isMostCloselyIdentified = "Male";
              FocusScope.of(context).requestFocus(new FocusNode());

              setState(() {});
              checkAllFieldSubmitterParent();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Male"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Male"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10.0),
                    bottomLeft: Radius.circular(10.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'Male',
                  textColor: isMostCloselyIdentified == "Male"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "Female";

              setState(() {});
              checkAllFieldSubmitterParent();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Female"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Female"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(0.0),
                    bottomLeft: Radius.circular(0.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'Female',
                  textColor: isMostCloselyIdentified == "Female"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "Non-Binary";

              setState(() {});
              checkAllFieldSubmitterParent();
            },
            child: Container(
              height: 35,
              width: 96,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Non-Binary"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Non-Binary"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(0.0),
                    bottomLeft: Radius.circular(0.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: ' Non-binary ',
                  textColor: isMostCloselyIdentified == "Non-Binary"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "NA";

              setState(() {});
              checkAllFieldSubmitterParent();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "NA"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "NA"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10.0),
                  topRight: Radius.circular(10.0),
                ),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'NA',
                  textColor: isMostCloselyIdentified == "NA"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 1,
        ),
      ],
    );
  }

  Widget _zipField() {
    return CustomFormField(
      autovalidateMode: AutovalidateMode.disabled,
      textInputType: TextInputType.text,
      maxLength: TextLength.ZIPCODE_MAX_LENGTH,
      controller: parentZipController,
      alignLabelWithHint: true,
      onType: (val) {},
      label: 'Parent\'s zip code',
      errorText:
          isShowErrorMsg ? 'Invalid zip code for selected country' : null,
      validation: (val) => !ValidationWidget.isZipCode(val)
          ? MessageConstant.ENTER_VALID_ZIP_CODE_VAL
          : null,
      onSaved: (val) => strParentZip = val,
    );
  }

  Widget _errorEmptyProfileView() {
    return Container(
      height: 115,
      width: 115,
      color: const Color(0xff666B9A),
      alignment: Alignment.center,
      child: Image.asset(
        'assets/default_avatar.png',
        height: 64,
        width: 64,
      ),
    );
  }

  Future<void> getImage(type) async {
    final imagePath = await UploadMedia(context).pickImageFromGallery();
    if (imagePath != null) {
      String strPath = imagePath.toString().substring(
          imagePath.toString().lastIndexOf("/") + 1,
          imagePath.toString().length);
      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        if (imagePath != null) {
          profileImageFile = imagePath;
          _fileUploading(imagePath.path);
          setState(() {});
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  Future<void> checkPermissionPhoto(BuildContext context) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => CupertinoAlertDialog(
              title: Text('Please allow access'),
              content: RichText(
                maxLines: 2,
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: '',
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  children: <TextSpan>[
                    TextSpan(
                        text: 'This app needs access to photos and camera roll',
                        style: TextStyle(
                            color: ColorValues.HEADING_COLOR_EDUCATION,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                            fontSize: 15.0,
                            fontWeight: FontWeight.normal)),
                  ],
                ),
              ),
              actions: <Widget>[
                CupertinoDialogAction(
                  child: Text('Deny'),
                  onPressed: () => Navigator.of(context).pop(),
                ),
                CupertinoDialogAction(
                    child: Text('Settings'),
                    onPressed: () {
                      Navigator.of(context).pop();
                      openAppSettings();
                    }),
              ],
            ));
  }

  Future<void> _handlePressButton() async {
    Prediction p = await PlacesAutocomplete.show(
      context: context,
      apiKey: Constant.kGoogleApiKey,
      onError: onError,
      hint: "Search here..",
      logo: Image.asset("assets/logo"),
      mode: Mode.fullscreen,
      components: [
        Component(Component.country, "ind"),
        Component(Component.country, "uk"),
        Component(Component.country, "usa"),
      ],
    );
    displayPrediction(p);
  }

  void onError(PlacesAutocompleteResponse response) {
    ToastWrap.showToast(response.errorMessage, context);
  }

  Future<Null> displayPrediction(Prediction p) async {
    if (p != null) {
      PlacesDetailsResponse detail =
          await _places.getDetailsByPlaceId(p.placeId);
      final lat = detail.result.geometry.location.lat;
      final lng = detail.result.geometry.location.lng;
      try {
        final coordinates = Coordinates(lat, lng);
        var addresses =
            await Geocoder.local.findAddressesFromCoordinates(coordinates);
        var first = addresses.first;
        setState(() {
          add1Controller.text =
              first.addressLine != null && p.description != "null"
                  ? p.description
                  : "";
          addressData = {
            "street1": add1Controller.text.trim(),
            "address": add1Controller.text.trim(),
            "street2": first.subLocality != null && first.subLocality != "null"
                ? first.subLocality
                : "",
            "city": first.subAdminArea != null && first.subAdminArea != "null"
                ? first.subAdminArea
                : "",
            "state": first.adminArea != null && first.adminArea != "null"
                ? first.adminArea
                : "",
            "country": first.countryName != null && first.countryName != "null"
                ? first.countryName
                : "",
            "zip": first.postalCode != null && first.postalCode != "null"
                ? first.postalCode
                : ""
          };
        });
      } catch (e) {
        setState(() {
          add1Controller.text = p.description;
        });
      }

      checkAllFieldSubmitterParent();
    }
  }
}
