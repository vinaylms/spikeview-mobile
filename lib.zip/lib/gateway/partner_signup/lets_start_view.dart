import 'package:flutter/material.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/gateway/Signup_As_Student_Widget_New.dart';
import 'package:spike_view_project/gateway/partner_signup/partner_profile_view.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/dot_list_item.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/positive_button.dart';

class LetsStartView extends StatelessWidget {
  final List<String> points = [
    MessageConstant.BRIEF_ABOUT_YOU,
    MessageConstant.HOME_PAGE,
    MessageConstant.CREATE_OPPORTUNITY,
    MessageConstant.BUSINESS_OBJECTIVES,
  ];
  final LoginRole role;
  final bool isRecommendation;
  final String pageName;
  final String firstName;
  final String lastName;
  final String email;
  final String profile;
  final String signupType;
  final bool isValid;

  LetsStartView({
    @required this.role,
    this.isRecommendation,
    this.pageName,
    this.firstName,
    this.lastName,
    this.email,
    this.profile,
    this.isValid,
    this.signupType,
});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/new_onboarding/background_screen.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 54, 20, 18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      child: SizedBox(
                        height: 32.0,
                        width: 32.0,
                        child: Center(
                            child: Image.asset(
                                "assets/new_onboarding/back_blue_icon.png",
                                height: 32.0,
                                width: 32.0,
                                fit: BoxFit.fitHeight)),
                      ),
                      onTap: () => Navigator.pop(context),
                    ),
                    const HelpButtonWidget(),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(35),
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        right: -15,
                        top: 0,
                        child: Image.asset(
                          'assets/partner_profile/lets_start_bg.png',
                          height: 225,
                          width: 225,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(20, 25, 20, 0),
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              BaseText(
                                text:
                                    "Let’s get you set up and connected to our community!",
                                textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontSize: 28,
                                fontWeight: FontWeight.w700,
                                fontFamily: Constant.latoRegular,
                              ),
                              const SizedBox(height: 30),
                              BaseText(
                                text: "It’s easy:",
                                textColor: const Color(0xff666B9A),
                                fontSize: 24,
                                fontWeight: FontWeight.w700,
                                fontFamily: Constant.latoRegular,
                              ),
                              const SizedBox(height: 18),
                              ListView.separated(
                                itemBuilder: (_, index) =>
                                    DotListItem(text: points[index]),
                                separatorBuilder: (_, index) =>
                                    const SizedBox(height: 24),
                                itemCount: points.length,
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                padding: EdgeInsets.zero,
                              ),
                              const SizedBox(height: 100),
                              PositiveButton(
                                title: 'Continue',
                                onTap: () => _onContinueTap(context),
                                isEnable: true,
                              ),
                              const SizedBox(height: 40),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _onContinueTap(BuildContext context) async {
    String result = await Navigator.of(context).push(MaterialPageRoute(
        builder: (BuildContext context) => SignupStudentPageNew(
            isRecommendation, pageName, signupType,
            firstName: firstName,
            lastName: lastName,
            email: email,
            image: profile,
            isValid: isValid,
          loginRole: LoginRole.partner,
        )));

  }

}
