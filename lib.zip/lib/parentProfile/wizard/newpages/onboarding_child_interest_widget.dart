import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/new_onboarding/Interest_list_model.dart';
import 'package:spike_view_project/new_onboarding/interest_result_list.dart';
import 'package:spike_view_project/new_onboarding/onboarding_add_education.dart';
import 'package:spike_view_project/new_onboarding/onboarding_education_added_list.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

import 'onboarding_education_added_list_student.dart';

class SelectingChildIterestWidget extends StatefulWidget {
  final StudentDataModel studModel;

  const SelectingChildIterestWidget({
    this.studModel,
    Key key,
  }) : super(key: key);

  @override
  State<SelectingChildIterestWidget> createState() =>
      SelectingChildIterestWidgetState();
}

class SelectingChildIterestWidgetState
    extends State<SelectingChildIterestWidget> {

  Future ApiGetAllinterest() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2().apiCall4(context,
            Constant.ENDPOINT_GET_hobbies_LIST + '?type=love_interests', "get");
        MessageConstant.printWrapped("data++++++searchText===" +
            Constant.ENDPOINT_GET_hobbies_LIST +
            '?type=love_interests');

        final String jsonString = jsonEncode(response.data);
        MessageConstant.printWrapped(
            "data++++++love_interests===" + jsonString);
        if (response != null) {
          CustomProgressLoader.cancelLoader(context);
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              mInterestListModel = InterestListModel.fromJson(response.data);
              setState(() {
                mInterestResultList.addAll(mInterestListModel.result);
                setState(() {});
              });
            }
          }
        } else {
          CustomProgressLoader.cancelLoader(context);
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  Future<void> addInterestApi(
      BuildContext mContext, List<SelectedInterest> mSelectedInterest) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": widget.studModel.userId,
          "roleId": "1",
          'love_interests':
              mSelectedInterest.map((item) => item.toJson()).toList()
        };
        print("response+++ apiCallingUpdate" + map.toString());
        Response response = await ApiCalling()
            .apiCallPostWithMapData(mContext, '/ui/userHobby', map);
        print("response+++ apiCallingUpdate" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToasSucess(msg, mContext);
              apiCallingUpdate(mContext);
            } else {
              //  ToastWrap.showToast(msg, mContext);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, mContext);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", mContext);
      e.toString();
    }
  }

  InterestListModel mInterestListModel = InterestListModel();
  List<InterestResult> mInterestResultList = [];

  // List<InterestResult> mInterestResultSelected = [];
  List<InterestResult> mOtherInterestResultList = [];
  List<SelectedInterest> mSelectedInterestList = [];
  SharedPreferences prefs;
  String userIdPref = "";
  static StreamController syncDoneController = StreamController.broadcast();

  TextEditingController _controlleraddInterest = TextEditingController();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.studModel.userId;
  }

  bool selectedLength = false;

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();
    ApiGetAllinterest();
    super.initState();
  }

  Future apiCallWizardCompleted() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("current student id accoplis" + widget.studModel.userId);

        Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_COMPLETED_WIZARD + widget.studModel.userId,
          "get",
        );
        print("wizardapi" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            syncDoneController.add("profile");
            Navigator.of(context).popUntil((route) => route.isFirst);
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingUpdate(BuildContext mContext) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);

        Map map = {"userId": userIdPref, "stage": "5"};
        print("update data+++ apiCallingUpdate" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);
        print("update data+++ apiCallingUpdate" + response.toString());
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            print("update data+++ apiCallingUpdate");
            if (status == "Success") {
              apiCallWizardCompleted();
            } else {}
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  FocusNode _focusNode = FocusNode();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomPadding: true, // this avoids the overflow error
        body: SingleChildScrollView(
          reverse: true,
          child: Container(
            padding: const EdgeInsets.only(top: 50.0, left: 20, right: 20),
            child: Column(
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    BaseText(
                      text: MessageConstant.INTEREST_HEDING,
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      maxLines: 1,
                    ),
                    const HelpButtonWidget(),
                  ],
                ),
                SizedBox(height: 5),
                Align(
                    alignment: Alignment.topLeft,
                    child: BaseText(
                      text: AppConstants
                          .stringConstant.str_interest_list_subtitle,
                      textColor: AppConstants.colorStyle.lightPurple,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w400,
                      fontSize: 16,
                      maxLines: 2,
                    )),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.65,
                  child: Container(
                    padding: EdgeInsets.only(top: 10),
                    child: GridView.builder(
                      itemCount: mInterestResultList.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          childAspectRatio: (220.0 / 190.0),
                          crossAxisSpacing: 10.0,
                          mainAxisSpacing: 10.0),
                      itemBuilder: (BuildContext context, int index) {
                        return InkWell(
                          onTap: () {
                            setState(() {
                              _focusNode.unfocus();
                            });
                            if (mInterestResultList[index].selected) {
                              setState(() {
                                mInterestResultList[index].selected = false;
                                selectedLength = false;
                                checkSelectIndex(mInterestResultList);
                              });
                            } else {
                              //  mInterestResultSelected.add(mInterestResultList[index]);
                              setState(() {
                                mInterestResultList[index].selected = true;
                                selectedLength = false;
                              });
                              checkSelectIndex(mInterestResultList);
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.fromLTRB(6, 11, 6, 11),
                            decoration: BoxDecoration(
                              color: mInterestResultList[index].selected
                                  ? AppConstants.colorStyle.btn_selected_color
                                  : AppConstants.colorStyle.tabBg,
                              border: Border.all(
                                  color: mInterestResultList[index].selected
                                      ? AppConstants
                                          .colorStyle.btn_selected_color
                                      : AppConstants.colorStyle.tabBg),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            alignment: Alignment.center,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                SvgPicture.network(
                                  Constant.IMAGE_PATH +
                                      ParseJson.getMediumImage(
                                          mInterestResultList[index].image),
                                  width: 25.0,
                                  height: 25.0,
                                  color: mInterestResultList[index].selected
                                      ? AppConstants.colorStyle.white
                                      : AppConstants.colorStyle.lightBlue,
                                  placeholderBuilder: (context) => Container(
                                      height: 30,
                                      width: 30,
                                      alignment: Alignment.center,
                                      child:
                                          const CircularProgressIndicator()), //placeholder while downloading file.
                                ),
                                const SizedBox(height: 4),
                                BaseText(
                                  text: mInterestResultList[index].name,
                                  textColor: mInterestResultList[index].selected
                                      ? AppConstants.colorStyle.white
                                      : AppConstants.colorStyle.lightBlue,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w700,
                                  textAlign: TextAlign.center,
                                  fontSize: 13,
                                  maxLines: 3,
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    10.0,
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            15.0,
                            10.0,
                            TextFormField(
                              controller: _controlleraddInterest,
                              focusNode: _focusNode,
                              style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                fontSize: 18.0,
                                fontWeight: FontWeight.w500,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                              ),
                              decoration: InputDecoration(
                                border: UnderlineInputBorder(
                                    borderSide: new BorderSide(
                                        color: AppConstants.colorStyle.btnBg)),
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(
                                      color: AppConstants.colorStyle.btnBg),
                                ),
                                disabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(
                                      color: AppConstants.colorStyle.btnBg),
                                ),
                                contentPadding:
                                    const EdgeInsets.fromLTRB(0, 10, 0, 10),
                                hintStyle: TextStyle(
                                  color: ColorValues.hintColor,
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                ),
                                hintText:
                                    AppConstants.stringConstant.str_btn_add_new,
                              ),
                            ),
                          ),
                        ),
                        Align(
                            child: InkWell(
                              child: SizedBox(
                                height: 32.0,
                                width: 32.0,
                                child: Center(
                                    child: Image.asset(
                                        "assets/new_onboarding/add_interest.png",
                                        height: 32.0,
                                        width: 32.0,
                                        fit: BoxFit.fitHeight)),
                              ),
                              onTap: () {
                                if (_controlleraddInterest.text.trim() != "") {
                                  List<InterestResult> results = List();
                                  results = mInterestResultList
                                      .where((user) =>
                                          user.name
                                              .trim()
                                              .toString()
                                              .toLowerCase() ==
                                          (_controlleraddInterest.text
                                              .toString()
                                              .toLowerCase()
                                              .trim()))
                                      .toList();

                                  List<InterestResult> results1 = List();
                                  results1 = mOtherInterestResultList
                                      .where((user) =>
                                          user.name
                                              .trim()
                                              .toString()
                                              .toLowerCase() ==
                                          (_controlleraddInterest.text
                                              .toString()
                                              .toLowerCase()
                                              .trim()))
                                      .toList();

                                  if (results.length == 0 &&
                                      results1.length == 0) {
                                    InterestResult mInterestResult =
                                        InterestResult();
                                    mInterestResult.name =
                                        _controlleraddInterest.text.trim();
                                    mInterestResult.selected = true;
                                    mOtherInterestResultList
                                        .add(mInterestResult);
                                    selectedLength = false;
                                    checkSelectIndex(mInterestResultList);
                                    //    mInterestResultList.add(mInterestResult);
                                    //      mInterestResultSelected.add(mInterestResult);
                                    _controlleraddInterest.clear();
                                    setState(() {
                                      mInterestResultList;
                                      mOtherInterestResultList;
                                    });
                                  } else {
                                    for (int i = 0;
                                        i < mInterestResultList.length;
                                        i++) {
                                      if (mInterestResultList[i].hobbyId ==
                                          results[0].hobbyId) {
                                        setState(() {
                                          mInterestResultList[i].selected =
                                              true;
                                          selectedLength = false;
                                          checkSelectIndex(mInterestResultList);
                                          _controlleraddInterest.clear();
                                        });
                                      }
                                    }
                                  }
                                }
                                setState(() {
                                  _focusNode.unfocus();
                                });
                              },
                            ),
                            alignment: Alignment.topRight),
                      ],
                    )),
                mOtherInterestResultList.isEmpty ||
                        mOtherInterestResultList == null
                    ? Container(
                        height: 80,
                      )
                    : PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        95.0,
                        MediaQuery.removePadding(
                          context: context,
                          removeTop: true,
                          removeBottom: true,
                          child: ListView(
                            physics: const NeverScrollableScrollPhysics(),
                            primary: true,
                            shrinkWrap: true,
                            children: <Widget>[
                              Wrap(
                                spacing: 12.0,
                                runSpacing: 0.0,
                                children: List<Widget>.generate(
                                    mOtherInterestResultList.length,
                                    // place the length of the array here
                                    (int index) {
                                  return PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      5.0,
                                      0.0,
                                      5.0,
                                      Container(
                                        decoration: BoxDecoration(
                                          color: AppConstants
                                              .colorStyle.orangeShade,
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(10)),
                                        ),
                                        padding: const EdgeInsets.only(
                                            left: 20,
                                            right: 20,
                                            top: 6,
                                            bottom: 6),
                                        child: Wrap(
                                          children: <Widget>[
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                1.0,
                                                0.0,
                                                0.0,
                                                Text(
                                                  '${mOtherInterestResultList[index].name}',
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                      color: ColorValues.WHITE,
                                                      fontSize: 16.0,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoMedium),
                                                )),
                                            InkWell(
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      5.0,
                                                      3.0,
                                                      0.0,
                                                      2.0,
                                                      Icon(
                                                        Icons.clear,
                                                        color: Colors.white,
                                                        size: 19.0,
                                                      )),
                                              onTap: () {
                                                setState(() {
                                                  _focusNode.unfocus();
                                                  mOtherInterestResultList
                                                      .removeAt(index);
                                                  selectedLength = false;
                                                  checkSelectIndex(
                                                      mInterestResultList);
                                                  setState(() {
                                                    mOtherInterestResultList;
                                                  });
                                                });
                                              },
                                            )
                                          ],
                                        ),
                                      ));
                                }).toList(),
                              ),
                            ],
                          ),
                        )),
              ],
            ),
          ),
        ),
        bottomSheet: Container(
            height: 90,
            padding: EdgeInsets.only(top: 10),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/generateScript/bottom_rectangle.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                        flex: 2,
                        child: InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              20.0,
                              20.0,
                              0.0,
                              0.0,
                              Container(
                                  height: 44,
                                  decoration: BoxDecoration(
                                    color: ColorValues.WHITE,
                                    border: Border.all(
                                        color: AppConstants.colorStyle.btnBg),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Align(
                                      alignment: Alignment.center,
                                      // Align however you like (i.e .centerRight, centerLeft)
                                      child: Text(
                                        "Back",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: AppConstants
                                              .colorStyle.lightPurple,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontSize: 18.0,
                                        ),
                                      )))),
                          onTap: () async {
                           /* String result = await Navigator.of(context).pushReplacement(
                                new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        EducationAddedWeightParentChild(
                                          studModel: widget.studModel,
                                          screenName: "onBoarding",
                                          userId: widget.studModel.userId,
                                        ),
                                ),
                            );
                            if (result == "push") {}*/
                            Navigator.pop(context);
                          },
                        ),
                    ),
                    Expanded(
                        flex: 3,
                        child: Stack(
                          children: [
                            InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  10.0,
                                  20.0,
                                  20.0,
                                  0.0,
                                  Container(
                                      height: 44,
                                      decoration: BoxDecoration(
                                        color:
                                            AppConstants.colorStyle.lightBlue,
                                        border: Border.all(
                                            color: AppConstants
                                                .colorStyle.lightBlue),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Align(
                                          alignment: Alignment.center,
                                          // Align however you like (i.e .centerRight, centerLeft)
                                          child: Text(
                                            "Proceed",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              color: ColorValues.WHITE,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoMedium,
                                              fontSize: 18.0,
                                            ),
                                          )))),
                              onTap: () {
                                mInterestResultList
                                    .addAll(mOtherInterestResultList);
                                for (int i = 0;
                                    i < mInterestResultList.length;
                                    i++) {
                                  if (mInterestResultList[i].selected) {
                                    SelectedInterest mSelectedInterest =
                                        SelectedInterest();
                                    mSelectedInterest.name =
                                        mInterestResultList[i].name;
                                    mSelectedInterest.hobbyId =
                                        mInterestResultList[i].hobbyId;
                                    mSelectedInterestList
                                        .add(mSelectedInterest);
                                  }
                                }
                                addInterestApi(context, mSelectedInterestList);
                              },
                            ),
                            selectedLength == false
                                ? InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        20.0,
                                        20.0,
                                        0.0,
                                        Container(
                                            height: 44,
                                            decoration: BoxDecoration(
                                              color: Colors.white60,
                                              border: Border.all(
                                                color: Colors.white60,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Align(
                                                alignment: Alignment.center,
                                                // Align however you like (i.e .centerRight, centerLeft)
                                                child: Text(
                                                  "Proceed",
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w600,
                                                    color: ColorValues.WHITE,
                                                    fontFamily: AppConstants
                                                        .stringConstant
                                                        .latoMedium,
                                                    fontSize: 18.0,
                                                  ),
                                                )))),
                                    onTap: () {},
                                  )
                                : Container(
                                    height: 0,
                                  )
                          ],
                        ))
                  ],
                )
              ],
            ),
        ),
    );
  }

  void checkSelectIndex(List<InterestResult> mInterestResultList1) {
    List<InterestResult> checkLengh = [];
    List<SelectedInterest> mSelectedInterestListCheckLengh = [];

    checkLengh.addAll(mInterestResultList1);
    checkLengh.addAll(mOtherInterestResultList);

    for (int i = 0; i < checkLengh.length; i++) {
      if (checkLengh[i].selected) {
        SelectedInterest mSelectedInterest = SelectedInterest();
        mSelectedInterest.name = checkLengh[i].name;
        mSelectedInterest.hobbyId = checkLengh[i].hobbyId;
        mSelectedInterestListCheckLengh.add(mSelectedInterest);
        if (mSelectedInterestListCheckLengh.length >= 3) {
          setState(() {
            selectedLength = true;
          });
        } else {
          setState(() {
            selectedLength = false;
          });
        }
      }
    }
  }
}

class SelectedInterest {
  SelectedInterest({
    this.hobbyId,
    this.name,
  });

  SelectedInterest.fromJson(dynamic json) {
    hobbyId = json['hobbyId'];
    name = json['name'];
  }

  int hobbyId;
  String name;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['hobbyId'] = hobbyId;
    map['name'] = name;
    return map;
  }
}
