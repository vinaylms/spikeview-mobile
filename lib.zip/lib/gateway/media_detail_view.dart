import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:video_player/video_player.dart';
import 'package:spike_view_project/gateway/PreLoginResponse.dart';

class MediaDetailView extends StatefulWidget {
  String mediaUrl;
  String mediaType;
  List<Blocks> mediaDataList;
  int index;

  MediaDetailView(this.mediaUrl, this.mediaType,this.mediaDataList, this.index);

  @override
  _MediaDetailViewState createState() => _MediaDetailViewState();
}

class _MediaDetailViewState extends State<MediaDetailView> {
  double statusBarHeight = 24.0;

  //VideoPlayerController _controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }

  @override
  void dispose() {
    // TODO: implement dispose
    //_controller.pause();
    //_controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print('widget.mediaUrl:: ${widget.mediaUrl}');
    print('widget.mediaType:: ${widget.mediaType}');
    statusBarHeight = MediaQuery.of(context).padding.top + 15;
    print('statusBarHeight:: $statusBarHeight');

    return Material(
      child: Scaffold(
        resizeToAvoidBottomPadding: false,
        body:  MediaQuery.removePadding(
          context: context,
          removeTop: true,
          child: Container(
            color: Colors.black,
            child: Stack(
              children: <Widget>[


                getGalleryScroll(context),

                Positioned(
                  left: 15.0,
                  top: statusBarHeight,
                  child: InkWell(
                    onTap: (){
                      onBack();
                    },
                    child: Container(
                      //color: Colors.black.withOpacity(0.8),
                      child: Padding(
                        padding: const EdgeInsets.all(0.0),
                        child:  Image.asset(
                          'assets/pre_login/back_arrow.png',
                          height: 20.0,
                          width: 20.0,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  getGalleryScroll(context) {
    if (widget.mediaDataList != null && widget.mediaDataList.length > 0) {

      print('Apurva 111 widget.mediaDataList::: ${widget.mediaDataList.length}');
      return  CarouselSlider.builder(
        //physics: NeverScrollableScrollPhysics(),
        //scrollDirection: Axis.horizontal,
        //shrinkWrap: true,
        //controller: _controller,
        itemCount: widget.mediaDataList.length,
        options: CarouselOptions(
          height: MediaQuery.of(context).size.height,
          //width: MediaQuery.of(context).size.width,
          //aspectRatio: 16/9,
          viewportFraction: 1.0,
          initialPage: widget.index,
          enableInfiniteScroll: false,
          reverse: false,
          autoPlay: false,
          //autoPlayInterval: Duration(seconds: 3),
          //autoPlayAnimationDuration: Duration(milliseconds: 800),
          //autoPlayCurve: Curves.fastOutSlowIn,
          //enlargeCenterPage: true,
          //onPageChanged: callbackFunction,
          scrollDirection: Axis.horizontal,
        ),
        itemBuilder: (context, index) {

          return Padding(
            padding: const EdgeInsets.only(bottom: 0.0),
            child: Padding(
              padding: const EdgeInsets.only(right: 0.0),
              //pagerList.length != index+1 ?  const EdgeInsets.only(right: 24.0): const EdgeInsets.only(right: 0.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  widget.mediaDataList[index].type == 'image' ? Center(
                    child:  CachedNetworkImage(
                      height: MediaQuery.of(context).size.height,
                      width: MediaQuery.of(context).size.width,
                      imageUrl: '${Constant.IMAGE_PATH}${widget.mediaDataList[index].largeImg}',
                      fit: BoxFit.contain,
                      placeholder: (context, url) =>
                          _loader(context,
                              "assets/aerial/default_img.png"),
                      errorWidget: (context, url,
                          error) =>
                          _error(
                              "assets/aerial/default_img.png"),
                    ),
                  ) :  Center(
                      child:  Container(
                        color: Colors.black,
                        //height: 215.50,
                        width: double.infinity,
                        child:  Center(
                          child:  VideoPlayPause(
                              widget.mediaDataList[index].largeImg,
                              //'https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mp4-file.mp4',
                              "FromMediaDetailPage",true),

                        ),
                      )

                  ),
                ],
              ),
            ),
          );
        },
      );
    }
    else
      return Container();
  }

  void onBack() {
    //_controller.pause();
    Navigator.of(context).pop();
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
      child: Container(

        child:
         CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation(Colors.white),
        ),
      ));

  Widget _error(String placeHolderImage) {
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
