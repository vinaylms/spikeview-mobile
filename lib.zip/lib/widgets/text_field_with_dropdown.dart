import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/component/app_constants.dart';

// ignore: must_be_immutable
class TextFieldWithDropdown extends StatefulWidget {
  TextFieldWithDropdown({
    Key key,
    @required this.listItem,
    @required this.onSelect,
    this.label,
    this.hint,
    this.optional = false,
    this.readOnly = false,
    this.checkBoxEnable = false,
    this.checkBoxTxt = "Placeholder",
    this.suffixWidget,
    this.prefixWidget,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.done,
    this.maxLength,
    this.validation,
    this.controller,
    this.inputFormatter,
    this.onClick,
    this.borderRadius = 0.0,
    this.isChecked,
    this.onType,
    this.onSaved,
    this.enable,
    this.focusNode,
    this.isObsecure,
    this.autoValidate,
    this.baseAlign,
    this.autovalidateMode,
    this.alignLabelWithHint,
    this.textAlign = TextAlign.left,
    this.maxLines,
  }) : super(key: key);

  final Function(int index) onSelect;
  final label;
  final hint;
  final borderRadius;
  final textAlign;
  final optional;
  final checkBoxEnable;
  final checkBoxTxt;
  final Widget suffixWidget;
  final Widget prefixWidget;
  final FocusNode focusNode;
  final TextInputType textInputType;
  final TextInputAction textInputAction;
  final AutovalidateMode autovalidateMode;
  final int maxLength;
  final Function() onClick;
  final Function(String selected) onSaved;
  final Function isChecked;
  final Function(String selected) onType;
  final String Function(String) validation;
  final TextEditingController controller;
  final bool alignLabelWithHint;
  final int maxLines;
  final List<String> listItem;
  List<TextInputFormatter> inputFormatter;
  bool enable = true;
  bool readOnly = false;
  bool isObsecure = false;
  bool autoValidate = false;
  bool baseAlign = false;

  @override
  _TextFieldWithDropdownState createState() => _TextFieldWithDropdownState();
}

class _TextFieldWithDropdownState extends State<TextFieldWithDropdown> {
  bool isFocus = false;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: TextFormField(
                    enabled: false,
                    autovalidateMode: widget.autovalidateMode == null
                        ? AutovalidateMode.onUserInteraction
                        : widget.autovalidateMode,
                    textCapitalization: TextCapitalization.sentences,
                    textAlign: widget.textAlign,
                    textInputAction: widget.textInputAction,
                    cursorColor: AppConstants.colorStyle.lightBlue,
                    maxLines: widget.maxLines ?? 1,
                    onSaved: (value) {
                      if (widget.onSaved != null) widget.onSaved(value);
                    },
                    focusNode: widget.focusNode,
                    readOnly: widget.readOnly,
                    keyboardType: widget.textInputType,
                    autovalidate: widget.autoValidate ?? false,
                    obscureText: widget.isObsecure ?? false,
                    onTap: widget.onClick,
                    onChanged: (value) {
                      widget.onType(value);
                    },
                    controller: widget.controller,
                    style: isFocus
                        ? AppConstants.txtStyle.labelStyleTextFormlightBlue
                        : AppConstants.txtStyle.txtStyleTextForm,
                    validator: widget.validation,
                    inputFormatters: widget.inputFormatter,
                    decoration: InputDecoration(
                      alignLabelWithHint: widget.alignLabelWithHint ?? false,
                      isDense: true,
                      filled: true,
                      focusColor: AppConstants.colorStyle.lightBlue,
                      fillColor: Colors.transparent,
                      labelText: widget.label,
                      hintText: widget.hint,
                      hintStyle: TextStyle(
                          fontFamily:AppConstants.stringConstant.latoRegular,
                          fontStyle: FontStyle.normal,
                          fontSize: 18,
                          color: AppConstants.colorStyle.darkBlue,
                          fontWeight: FontWeight.w500
                      ),
                      labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                      contentPadding: EdgeInsets.fromLTRB(
                        0.0,
                        7.0,
                        10.0,
                        widget.baseAlign == null ? 10.0 : 0,
                      ),
                      border: InputBorder.none
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: widget.suffixWidget ?? Image.asset(
                    'assets/experience/ic_arrow_down.png',
                    width: 16,
                    height: 14,
                  ),
                )
              ],
            ),
            Divider(
              height: 0,
              thickness: 1,
              color: Color(0x99E5EBF0),
            ),
          ],
        ),
        offset: Offset(0,50),
        onSelected: (String value) {
          int index = widget.listItem.indexWhere((element) => element.toLowerCase() == value.toLowerCase());
          if(index > -1){
            widget.onSelect(index);
          }
        },
        itemBuilder: ( context) {
          return widget.listItem
              .map<PopupMenuItem<String>>((String value) {
            return PopupMenuItem(
              child: Container(
                padding: const EdgeInsets.fromLTRB(11, 7, 8, 11),
                width: double.maxFinite,
                decoration: BoxDecoration(
                    color: Color(0xffF3F5FF),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Color(0xffE5EBF0),),),
                child: Text(
                  value,
                  style: TextStyle(
                    color: Color(0xff27275A),
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                  ),
                ),
              ),
              value: value,

            );
          }).toList();
        },
      );
  }
}
