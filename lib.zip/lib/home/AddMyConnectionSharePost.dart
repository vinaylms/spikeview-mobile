import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';

import 'package:spike_view_project/constant/TextView_Wrap.dart';

import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

// Create a Form Widget
class AddMyConnectionSharePost extends StatefulWidget {
  String title;
  List<TagsPost> selectedtScopeList;

  AddMyConnectionSharePost(this.title, this.selectedtScopeList);

  @override
  AddMyConnectionSharePostState createState() {
    return AddMyConnectionSharePostState();
  }
}

class AddMyConnectionSharePostState extends State<AddMyConnectionSharePost> {
  List<TagModel> tagList = List();
  List<TagsPost> selectedUerId = List();
  List<TagModel> filteredRecored = List();
  List<bool> selectedCheckedList = List();
  var isButtonEnable = false;
  SharedPreferences prefs;
  BuildContext context;
  String userIdPref, roleId, userProfilePath;
  bool isApiCalled = false;
  bool isSelectAll = false;
  TextEditingController _textController = TextEditingController();

  //--------------------------api Calling for tag------------------
  Future apiCallingForTag() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_USER_CONNECTION_LIST +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");

        print("pi Calling+++++++++" +
            Constant.ENDPOINT_USER_CONNECTION_LIST +
            userIdPref +
            "&roleId=" +
            roleId);
        setState(() {
          isApiCalled = true;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              filteredRecored.clear();
              tagList =
                  ParseJson.parseTagList(response.data['result']['Accepted']);
              if (tagList != null) {
                setState(() {
                  tagList;
                  filteredRecored.addAll(tagList);
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      setState(() {
        isApiCalled = true;
      });
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    await apiCallingForTag();

    if (widget.selectedtScopeList.length > 0) {
      for (int i = 0; i < widget.selectedtScopeList.length; i++) {
        for (int j = 0; j < tagList.length; j++) {
          if ((widget.selectedtScopeList[i].userId.toString() ==
                  filteredRecored[j].userId.toString()) &&
              (widget.selectedtScopeList[i].roleId.toString() ==
                  filteredRecored[j].roleId.toString())) {
            filteredRecored[j].isSelected = true;
            selectedCheckedList.add(true);
          }
        }
      }
      isButtonEnable = true;
    } else {
      isButtonEnable = false;
    }

    setState(() {
      filteredRecored;
    });
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }

  void onTapOkBtn() {
    for (int i = 0; i < tagList.length; i++) {
      if (tagList[i].isSelected)
        selectedUerId.add(new TagsPost(tagList[i].userId, tagList[i].roleId));
    }
    Navigator.pop(context, selectedUerId);
  }

  Widget addButton() {
    return Container(
      margin: EdgeInsets.fromLTRB(20, 20, 20, 32),
      color: Colors.white,
      height: 44,
      child: ElevatedButton(
        onPressed: () => onTapOkBtn(),
        style: ElevatedButton.styleFrom(
          elevation: 0,
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          padding: EdgeInsets.symmetric(vertical: 10),
          primary: const Color(0xff4684EB),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: Center(
          child: Text(
            'Add',
            textAlign: TextAlign.center,
            style: TextStyle(
                fontFamily: AppConstants.stringConstant.latoRegular,
                fontSize: 16,
                color: AppConstants.colorStyle.white,
                fontWeight: FontWeight.w600),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;

    return Scaffold(
      bottomNavigationBar: addButton(),
      backgroundColor: ColorValues.WHITE,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/new_onboarding/background_screen.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 54, 20, 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    child: SizedBox(
                      height: 32.0,
                      width: 32.0,
                      child: Center(
                          child: Image.asset(
                              "assets/new_onboarding/back_blue_icon.png",
                              height: 32.0,
                              width: 32.0,
                              fit: BoxFit.fitHeight)),
                    ),
                    onTap: () => Navigator.pop(context),
                  ),
                  const HelpButtonWidget(),
                ],
              ),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(35),
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
                child: isApiCalled
                    ? tagList.length == 0
                        ? Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                Text(
                                  "No connections",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily: Constant.customRegular,
                                    fontSize: 23.0,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Select connections",
                                style: AppConstants
                                    .txtStyle.heading28700LatoRegularDarkBlue,
                              ),
                              const SizedBox(height: 9),
                              const SizedBox(height: 9),
                              Container(
                                  padding:
                                  const EdgeInsets.only(right: 15),
                                  decoration: BoxDecoration(
                                    color:
                                    AppConstants.colorStyle.tabBg,
                                    border: Border.all(
                                        color: AppConstants
                                            .colorStyle.btnBg),
                                    borderRadius:
                                    const BorderRadius.all(
                                        Radius.circular(10)),
                                  ),
                                  child: TextField(
                                    cursorColor: Constant.CURSOR_COLOR,
                                    controller: _textController,
                                    decoration: InputDecoration(
                                        enabledBorder:
                                        UnderlineInputBorder(
                                          borderSide: BorderSide(
                                            color: Colors.transparent,
                                          ),
                                        ),
                                        focusedBorder:
                                        UnderlineInputBorder(
                                          borderSide: BorderSide(
                                            color: Colors.transparent,
                                          ),
                                        ),
                                        hintText:
                                        'Search in your connections',
                                        suffixIconConstraints:
                                        BoxConstraints(
                                          maxHeight: 24,
                                          maxWidth: 24,
                                        ),
                                        suffixIcon: _textController
                                            .text.length >
                                            0
                                            ? InkWell(
                                          child: Icon(
                                              Icons.cancel,
                                              color:
                                              Colors.black26),
                                          onTap: () {
                                            setState(() {
                                              _textController
                                                  .text = "";
                                              updateSearchQuery(
                                                  "");
                                            });
                                          },
                                        )
                                            : Image.asset(
                                          "assets/feed/search.png",
                                          height: 20,
                                          width: 20,
                                        ),
                                        isDense: true,
                                        contentPadding:
                                        const EdgeInsets.fromLTRB(
                                            15, 11, 15, 12)),
                                    onChanged: updateSearchQuery,
                                  )),
                              const SizedBox(height: 13),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.end,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        if (!isSelectAll) {
                                          for (int i = 0;
                                          i <
                                              filteredRecored
                                                  .length;
                                          i++) {
                                            filteredRecored[i]
                                                .isSelected = true;
                                            selectedCheckedList
                                                .add(true);
                                          }
                                        } else {
                                          for (int i = 0;
                                          i <
                                              filteredRecored
                                                  .length;
                                          i++) {
                                            filteredRecored[i]
                                                .isSelected = false;
                                            selectedCheckedList
                                                .remove(true);
                                          }
                                        }
                                        isSelectAll = !isSelectAll;
                                        if (selectedCheckedList
                                            .length !=
                                            0) {
                                          isButtonEnable = true;
                                        } else {
                                          isButtonEnable = false;
                                        }
                                      });
                                    },
                                    child: Text(
                                      filteredRecored.length > 0
                                          ? isSelectAll
                                          ? "Clear all"
                                          : "Select all"
                                          : "",
                                      style: AppConstants.txtStyle
                                          .heading14500LatoRegularDarkBlue,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Expanded(
                                child: SingleChildScrollView(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      filteredRecored.length > 0
                                          ? Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: List.generate(
                                                  filteredRecored.length,
                                                  (int position) {
                                                return connectionListItem(
                                                    position);
                                              }),
                                            )
                                          : SizedBox(
                                              height: MediaQuery.of(context)
                                                      .size
                                                      .height *
                                                  0.4,
                                              child: Center(
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "No Data Found.",
                                                          TextAlign.center,
                                                          ColorValues
                                                              .GREY_TEXT_COLOR,
                                                          16.0,
                                                          FontWeight.normal,
                                                          2)),
                                            ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          )
                    : const Center(child: SizedBox.shrink()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void updateSearchQuery(String newQuery) {
    filteredRecored.clear();
    if (newQuery.length > 0) {
      Set<TagModel> set = Set.from(tagList);
      set.forEach((element) => filterList(element, newQuery));
    }
    if (newQuery.isEmpty) {
      filteredRecored.addAll(tagList);
    }
    setState(() {});
  }

  filterList(TagModel model, String searchQuery) {
    setState(() {
      if (model.firstName.toLowerCase().contains(searchQuery) ||
          model.firstName.contains(searchQuery) ||
          model.lastName.toLowerCase().contains(searchQuery) ||
          model.lastName.contains(searchQuery)) {
        filteredRecored.add(model);
      }
    });
  }

  Widget connectionListItem(position) {
    return InkWell(
      onTap: () {
        bool value = filteredRecored[position].isSelected;

        if (value) {
          filteredRecored[position].isSelected = false;
          selectedCheckedList.remove(true);
        } else {
          filteredRecored[position].isSelected = true;
          selectedCheckedList.add(true);
        }

        setState(() {
          if (selectedCheckedList.length != 0) {
            isButtonEnable = true;
          } else {
            isButtonEnable = false;
          }
          if (selectedCheckedList.length == filteredRecored.length) {
            isSelectAll = true;
          }
          if (selectedCheckedList.length == 0) {
            isSelectAll = false;
          }
        });
      },
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              height: 48,
              width: 48,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 1.5),
                borderRadius: const BorderRadius.all(Radius.circular(15)),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: FadeInImage(
                  fit: BoxFit.cover,
                  placeholder: AssetImage(
                    'assets/profile/user_on_user.png',
                  ),
                  image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                      ParseJson.getSmallImage(
                          filteredRecored[position].profilePicture)),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Row(
                children: <Widget>[
                  TextViewWrap.textView(
                      filteredRecored[position].lastName == "" ||
                              filteredRecored[position].lastName == "null"
                          ? filteredRecored[position].firstName
                          : filteredRecored[position].firstName +
                              " " +
                              filteredRecored[position].lastName,
                      TextAlign.start,
                      ColorValues.HEADING_COLOR_EDUCATION_1,
                      16.0,
                      FontWeight.bold),
                  filteredRecored[position].roleId == "1"
                      ? Util.getStudentBadge12(filteredRecored[position].badge,
                          filteredRecored[position].badgeImage)
                      : Container(),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Image.asset(
              filteredRecored[position].isSelected
                  ? "assets/feed/checkedBox.png"
                  : "assets/feed/unCheckedBox.png",
              height: 22.0,
              width: 22.0,
            ),
          ],
        ),
      ),
    );
  }
}
