import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

// Create a Form Widget
class NewLikeDetailWidget extends StatefulWidget {
  // List<Likes> likesList;
  String userId, feedId;

  NewLikeDetailWidget(this.feedId, this.userId);

  @override
  NewLikeDetailWidgetState createState() {
    return NewLikeDetailWidgetState(feedId, userId);
  }
}

class NewLikeDetailWidgetState extends State<NewLikeDetailWidget> {
  List<LikeDetailModel> likesList;
  SharedPreferences prefs;
  BuildContext context;
  int skip = 0;
  bool isLoading = true;
  String userIdPref, userProfilePath, roleId, feedId;
  String userId;
  ScrollController _scrollController = ScrollController();

  NewLikeDetailWidgetState(this.feedId, this.userId);

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    apiToGetDetail();
  }

  @override
  void initState() {
    getSharedPreferences();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        skip = skip + 1;

        print("sss  _scrollController skip" + skip.toString());
        apiToGetDetail();
      }
    });
    super.initState();

  }

  Future apiToGetDetail() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
        });

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_LIKE_LIST_ALL +
                userIdPref +
                "&feedId=" +
                feedId +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString(),
            "get");
        isLoading = false;

        setState(() {
        });

        print("-=------------ skip.toString()++++ " + skip.toString());
        print(response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              likesList = ParseJson.parseLikeList(response.data['result']);

              setState(() {
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
      });
    }
  }

  onTapImageTile(tapedUserId, roleId) {
    if (tapedUserId == userIdPref) {
    } else {
      Util.onTapImageTile(
          tapedUserRole: roleId, partnerUserId: tapedUserId, context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                "assets/generateScript/script_background.png",
              ),
              fit: BoxFit.fill,
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 40, 20, 23),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Image.asset(
                        "assets/generateScript/back.png",
                        height: 32.0,
                        width: 32.0,
                      ),
                    ),
                    HelpButtonWidget(),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 41, 20, 20),
                  child: isLoading
                      ? const SizedBox.shrink()
                      : Column(
                          children: [
                            Row(
                              children: <Widget>[
                                InkWell(
                                  onTap: () {},
                                  child: Image.asset(
                                    "assets/feed/heart_pink.png",
                                    height: 16.0,
                                    width: 16.0,
                                  ),
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                likesList.length > 9
                                    ? Text(
                                        "${likesList[9].firstName} ${likesList[9].lastName} and ${likesList.length - 10} others",
                                        textAlign: TextAlign.center,
                                        maxLines: 5,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 16.0,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w500),
                                      )
                                    : Text(
                                        "${likesList.length} likes",
                                        textAlign: TextAlign.center,
                                        maxLines: 5,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 16.0,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w500),
                                      ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Expanded(
                              child: ListView.builder(
                                controller: _scrollController,
                                itemCount: likesList.length,
                                itemBuilder:
                                    ( context,  position) {
                                  return Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        0, 12, 0, 12),
                                    child: InkWell(
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            10.0,
                                            0.0,
                                            InkWell(
                                              child: Container(
                                                height: 50.0,
                                                width: 50.0,
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          10),
                                                  child: FadeInImage(
                                                    fit: BoxFit.cover,
                                                    placeholder: AssetImage(
                                                      likesList[position]
                                                                  .likedByRole ==
                                                              "4"
                                                          ? "assets/profile/partner_img.png"
                                                          : 'assets/profile/user_on_user.png',
                                                    ),
                                                    image: NetworkImage(Constant
                                                            .IMAGE_PATH_SMALL +
                                                        ParseJson.getSmallImage(
                                                            likesList[
                                                                    position]
                                                                .profilePicture)),
                                                  ),
                                                ),
                                              ),
                                              onTap: () {
                                                onTapImageTile(
                                                    likesList[position]
                                                        .likedBy,
                                                    likesList[position]
                                                        .likedByRole);
                                              },
                                            ),
                                          ),
                                          Expanded(
                                            child: BaseText(
                                              text: likesList[position]
                                                  .firstName +
                                                  " " +
                                                  likesList[
                                                  position]
                                                      .lastName,
                                              textColor: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize : 16.0,
                                              fontWeight : FontWeight.normal,
                                              maxLines: 2,
                                            ),
                                          ),
                                          /*Expanded(
                                              child: TextViewWrap.textView(
                                                  likesList[position]
                                                          .firstName +
                                                      " " +
                                                      likesList[
                                                              position]
                                                          .lastName,
                                                  TextAlign.start,
                                                  ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  16.0,
                                                  FontWeight.normal,

                                              ),
                                          ),*/
                                          likesList[position].likedBy != userId
                                              ? likesList[position]
                                                          .status ==
                                                      Constant.ACCEPTED
                                                  ? Padding(
                                                      padding:
                                                          EdgeInsets
                                                              .fromLTRB(
                                                                  12.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Text(
                                                        likesList[position]
                                                                    .statusValue ==
                                                                "null"
                                                            ? ""
                                                            : "Connected",
                                                        style: TextStyle(
                                                            fontFamily:
                                                                Constant
                                                                    .latoRegular,
                                                            color: ColorValues
                                                                .labelColor,
                                                            fontSize:
                                                                14.0,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400),
                                                      ))
                                                  : Padding(
                                                      padding:
                                                          EdgeInsets
                                                              .fromLTRB(
                                                                  12.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Container(
                                                        width: 130,
                                                        height: 30,
                                                        decoration: BoxDecoration(
                                                            color: ColorValues
                                                                .TAB_BACKGROUND_COLOR,
                                                            borderRadius: const BorderRadius
                                                                    .all(
                                                                Radius.circular(
                                                                    10))),
                                                        child: Center(
                                                          child: Text(
                                                            likesList[position].statusValue ==
                                                                    "null"
                                                                ? ""
                                                                : "Add connection",
                                                            style: TextStyle(
                                                                fontFamily:
                                                                    Constant
                                                                        .latoRegular,
                                                                color: ColorValues
                                                                    .BLUE_COLOR,
                                                                fontSize:
                                                                    14.0,
                                                                fontWeight:
                                                                    FontWeight.w400),
                                                          ),
                                                        ),
                                                      ),
                                                    )
                                              : const SizedBox.shrink(),
                                        ],
                                      ),
                                      onTap: () {
                                        if (likesList[position].likedBy ==
                                            userIdPref) {
                                        } else {
                                          Util.onTapImageTile(
                                              tapedUserRole: likesList[position]
                                                  .likedByRole
                                                  .toString(),
                                              partnerUserId: likesList[position]
                                                  .likedBy
                                                  .toString(),
                                              context: context);
                                        }
                                      },
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}
