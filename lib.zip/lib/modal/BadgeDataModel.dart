import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class BadgeDataModel {
int badgeId;
String name,image,status,createdAt;

BadgeDataModel(this.badgeId, this.name, this.image, this.status,
    this.createdAt);


}
