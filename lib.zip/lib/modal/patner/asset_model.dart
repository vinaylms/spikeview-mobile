class AssetModel {
  String type;
  String tag;
  String file,label;

  AssetModel({this.type, this.tag, this.file,this.label});

  static Map<String, dynamic> toMap(AssetModel assetObject) {
    Map<String, dynamic> assetMap = Map();
    assetMap['type'] = assetObject.type;
    assetMap['tag'] = assetObject.tag;
    assetMap['file'] = assetObject.file;

    return assetMap;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> assetMap = Map<String, dynamic>();
    assetMap['type'] = this.type;
    assetMap['tag'] = this.tag;
    assetMap['file'] = this.file;

    return assetMap;
  }

  AssetModel.fromJson(Map<String, dynamic> json) {
    type = json['type'];
    tag = json['tag'];
    file = json['file'];
  }


  static List<Map<String, dynamic>> mapList(List<AssetModel> assets) {
    List<Map<String, dynamic>> listOfAsset = assets
        .map((asset) => {
              "type": asset.type,
              "tag": asset.tag,
              "file": asset.file,
              "label": asset.label==null?"":asset.label,
            })
        .toList();
    return listOfAsset;
  }

  static getAssetArray() {
/*    AssetModel assetModel = AssetModel(
        type: 'image',
        tag: 'media',
        file:
            'https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Google_Images_2015_logo.svg/1200px-Google_Images_2015_logo.svg.png');*/
    List<AssetModel> assets = [];
   // assets.add(assetModel);
    return assets;
  }
}
