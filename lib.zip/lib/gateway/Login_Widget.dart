import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';

import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges_notification.dart';
import 'package:spike_view_project/badges/new_badges/request_badges_view.dart';
import 'dart:convert';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicViewForUser.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/image_utils.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/ChangePasswordNew.dart';
import 'package:spike_view_project/gateway/RoleSelctionWidget.dart';
import 'package:spike_view_project/gateway/Signup_As_Parent_Widget_New.dart';
import 'package:spike_view_project/gateway/Signup_As_Student_Widget_New.dart';
import 'package:spike_view_project/gateway/company/company_info_view_New.dart';
import 'package:spike_view_project/gateway/more_data.dart';
import 'package:spike_view_project/gateway/partner_signup/lets_start_view.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/IntroDuctioVideoModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/patner/user_signup_model.dart';
import 'package:spike_view_project/notification/OpportunityForBoat.dart';
import 'package:spike_view_project/notification/opportunityRejected.dart';
import 'package:spike_view_project/parentProfile/ParentOnBoarding.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PartnerRejectionReason.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForBoatReview.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';
import 'package:spike_view_project/patnerFlow/PartnerOnBoarding.dart';
import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/gallery/FullImageViewPager.dart';
import 'package:spike_view_project/gateway/ChangePassword.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/gateway/ForgotPassword.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/modal/LoginViewPagerModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/ParentProfileImage.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/recommendation/SharedRecoomendAtion.dart';
import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/unsubscribe/UnsubscribeWidget.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

import 'CongratulationWidget.dart';
import 'EmailVerification.dart';
import 'TakeATour.dart';

enum LoginRole { student, parent, partner }

class LoginPage extends StatefulWidget {
  static String tag = 'login-page';
  List<SharedMediaFile> imageList;
  bool isRedirectToRecommendation;
  String pageName;
  bool showSignup;
  bool showLogin;

  ///  PreLoginResponse preLoginResponse;

  LoginPage(this.imageList,
      {this.isRedirectToRecommendation,
      this.pageName,
      this.showSignup,
      this.showLogin});

  @override
  _LoginPageState createState() => _LoginPageState();
}

String _email = "", _password = "";
bool _isLoading = false;
List<UserData> userList = List();
List<UserData> userList2 = List();

class _LoginPageState extends State<LoginPage> with WidgetsBindingObserver {
  Color borderColor = Colors.amber;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String userId;
  String roleId;
  var formKey = GlobalKey<FormState>();
  var formKeyOld = GlobalKey<FormState>();
  bool isPasswordChanged;
  bool ProfileCreatedByParent;
  bool userLoginFirstTime;
  bool isPasswordVisible = true;
  bool isBack = true;
  TextEditingController emailTxtController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  SharedPreferences prefs;
  ShareProfileModal shareProfileModal;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String linkUrl = "";
  static StreamController syncDoneController = StreamController.broadcast();
  final FocusNode _emailFocus = FocusNode();
  final FocusNode _passwordFocus = FocusNode();
  ProfileInfoModal profileInfoModal;
  PageController _controller = PageController();
  CompanyProfileModel companyModel;

  bool showSignupButton = true;
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  List<RoleDataModel> dataList = List();
  List<RoleDataModel> dummyDataList = List();

  //List<RoleDataModel> pagerList =  List();

  bool isSelected = false;

  bool isOpenLogin = false;
  bool isOpenSignup = false;

  //var bottomSheetController;
  PersistentBottomSheetController _controllerB;
  GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _open = false;
  bool allFieldCompleted = false;
  bool isRedirectToRecommendationLocal = false;
  String pageNameLocal = 'Login';

  //String pageNameLocal = 'LoginNew';

  double highLightWidth = 82; //263.0;
  double highLightHeight = 147.0;

  var imageSlideDuration = 2;

  // PreLoginResponse preLoginResponseData;

  ScrollController _scrollControllerHighlights = ScrollController();
  ScrollController _scrollControllerExplore = ScrollController();
  ScrollController _scrollControllerParent = ScrollController();

  static int skipExplore = 0;
  static int skipHighlights = 0;

  bool showHighlightProgress = false;

  bool showExploreProgress = false;

  double screenWidth;
  double screenHeight;

  String mediaUrl;
  String mediaType;
  int itemIndex;
  bool isShowDetailView = false;
  double statusBarHeight = 24.0;
  double detailPagePadding = 140.0;

  double bottomPadding = 0;
  String selectedRole = "", signinType = "spikeview";
  bool isShowError = false;

  String sasToken = '';

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print("Resumed++++++");
    Constant.applicationContext = context;
    if (state == AppLifecycleState.resumed) {
      linkUrl = prefs.getString(UserPreference.PATHURL);
      if (linkUrl == null) {
        linkUrl = "";
      }
      String email = "", password = "";
      if (linkUrl == "" || linkUrl == " ") {
      } else {
        if (linkUrl.contains("joingroup")) {
          List<String> mesagelist = linkUrl.split("/");

          email = mesagelist[mesagelist.length - 1];

        /*  List<String> mesagelist = linkUrl.split("=");

          email = mesagelist[3].replaceAll("&pass", "");*/
        } else {
          List<String> pathSplitList = linkUrl.split("/");

          if (linkUrl.toString().contains("true")) {
            if (pathSplitList.length > 3) {
              email = pathSplitList[pathSplitList.length - 4];
            }
          }
        }

        if (mounted) {
          setState(() {
            if (emailTxtController.text.trim().length == 0)
              emailTxtController.text = email;
          });
        }
      }
    }
  }
  String email = "", password = "";

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    linkUrl = prefs.getString(UserPreference.PATHURL);

    Constant.CURRENT_PAGE_NAME = "Login";
    if (linkUrl == null) {
      linkUrl = "";
    }
    print("linkUrl//////////////////" + linkUrl.toString());
    if (linkUrl == "" || linkUrl == " ") {
    } else {
      if (linkUrl.contains(Constant.CONNECTION_REQUEST)) {
        linkUrl = linkUrl.replaceAll(
            Constant.LINK_REDIRECTION_CONNECTION_REQUEST, "");
        List<String> mesagelist = linkUrl.split("&");
        email = mesagelist[3].replaceAll("email=", "");
        print("linkUrl///11//////" + linkUrl.toString());
      } else if (linkUrl.contains(Constant.SUSCRIPTION)) {
        List<String> mesagelist = linkUrl.split("/");
        email = mesagelist[mesagelist.length - 2];
        print("linkUrl///22//////" + linkUrl.toString());
      } else if (linkUrl.contains(Constant.PREVIEWPROFILE)) {
        List<String> mesagelist = linkUrl.split("/");
        email = mesagelist[mesagelist.length - 2];
        print("linkUrl///33//////" + linkUrl.toString());
      } else if (linkUrl.contains(Constant.VIEWPROFILE)) {
        linkUrl = linkUrl.replaceAll(Constant.LINK_VIEWPROFILE, "");
        print("linkUrl///44//////" + linkUrl.toString());
        List<String> mesagelist = linkUrl.split("&");

        email = mesagelist[2].replaceAll("email=", "");
      } else if (linkUrl.contains("joingroup")) {
        List<String> mesagelist = linkUrl.split("/");

        email = mesagelist[mesagelist.length - 1];


        print("linkUrl///55//////" + linkUrl.toString());
        print("linkUrl///55//////" + email.toString());
      } else if (linkUrl.contains("forwardToParentGroup")) {
        List<String> mesagelist = linkUrl.split("=");
        print("linkUrl///66//////" + linkUrl.toString());
        email = mesagelist[4].replaceAll("&pass", "");
      } else if (linkUrl.contains("forwardToParentInquire")) {
        List<String> mesagelist = linkUrl.split("=");
        print("linkUrl///77//////" + linkUrl.toString());
        // String opportunityId = mesagelist[1].replaceAll("&email", "");
        email = mesagelist[2].replaceAll("&pass", "");
      } else if (linkUrl.contains("recommendation")) {
        List<String> pathSplitList = linkUrl.split("/");
        email = pathSplitList[pathSplitList.length - 2];
        if (email != "app.spikeview.com") {
          setState(() {
            emailTxtController.text = email;
          });
        }
        if (!ValidationWidget.isEmail(email)) email = "";
      } else if (linkUrl.contains("/badges/")) {
        List<String> pathSplitList = linkUrl.split("/");
        email = pathSplitList[pathSplitList.length - 2];
        if (email != "app.spikeview.com") {
          setState(() {
            emailTxtController.text = email;
          });
        }
        if (!ValidationWidget.isEmail(email)) email = "";
      } else {
        List<String> pathSplitList = linkUrl.split("/");

        if (linkUrl.toString().contains("studentActivation")) {
          email = pathSplitList[pathSplitList.length - 2];
          setState(() {
            emailTxtController.text = email;
          });
          prefs.setString(UserPreference.PATHURL, "");
        } else {
          print("linkUrl///999/////" + pathSplitList[pathSplitList.length - 2]);

          email = pathSplitList[pathSplitList.length - 2];
          if (email != "app.spikeview.com") {
            setState(() {
              emailTxtController.text = email;
            });
          }
          prefs.setString(UserPreference.PATHURL, "");
          if (!ValidationWidget.isEmail(email)) email = "";
        }
      }

      List<String> mesagelist = linkUrl.split("/");

      String roleId = mesagelist[mesagelist.length - 4];

      print("linkUrl///5555/////" + email);

      setState(() {

      });
    }
  }

  @override
  void dispose() {
    // TODO: implement dispose

    _controller.dispose();
    _scrollControllerHighlights.dispose();
    _scrollControllerExplore.dispose();
    _scrollControllerParent.dispose();
    super.dispose();
  }

  GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseAuth _fbAuth = FirebaseAuth.instance;
  GoogleSignInAccount _currentUser;
  String _contactText;
  FirebaseAuth _auth;

  @override
  void initState() {
    // _controller =  PageController();
    super.initState();
    if (Platform.isIOS) {
      detailPagePadding = 180.0;
    }
    if (widget.showSignup != null) {
      isOpenSignup = widget.showSignup;
    }
    if (widget.showLogin != null) {
      isOpenLogin = widget.showLogin;
    }
    if (widget.isRedirectToRecommendation != null) {
      isRedirectToRecommendationLocal = widget.isRedirectToRecommendation;
    }

    if (widget.pageName != null) {
      pageNameLocal = widget.pageName;
    }

    print(
        'widget.showSignup:: ${widget.showSignup}, widget.showLogin:: ${widget.showLogin}, widget.isRedirectToRecommendation:: ${widget.isRedirectToRecommendation}, widget.pageName:: ${widget.pageName}');
    print(
        'isOpenSignup:: ${isOpenSignup}, isOpenLogin:: ${isOpenLogin}, isRedirectToRecommendationLocal:: ${isRedirectToRecommendationLocal}, pageNameLocal:: ${pageNameLocal}');

    WidgetsBinding.instance.addObserver(this);

    getSharedPreferences();

    dataList.add(RoleDataModel(
        "1", "Student", "", "assets/newDesignIcon/patner/student.png", false));
    dataList.add(RoleDataModel(
        "2", "Parent", "", "assets/newDesignIcon/patner/parent.png", false));
    dataList.add(RoleDataModel(
        "3", "Partner", "", "assets/newDesignIcon/patner/patner.png", false));

    WidgetsBinding.instance
        .addPostFrameCallback((_) => openSignupBottomSheet(context));
  }

  void _checkValidation() async {
    final form = formKey.currentState;
    setState(() => _isLoading = true);
    form.save();
    if (form.validate()) {
      print("SUCCESS 00");
      signinType = "spikeview";
      loginServiceCall();
    } else {
      setState(() => _isLoading = false);
      print("Failure 00");
    }
  }

  onTapPresoView() async {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    Navigator.of(context).popUntil((route) => route.isFirst);
    await Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) => SharePresoView23(
                shareProfileModal.profileOwner, shareProfileModal, "main")));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  Future shareIDData(shareId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2()
            .apiCall4(context, Constant.ENDPOINT_SHARE_ID + shareId, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String message = response.data['message'];
            print(response.toString());
            if (status == "Success") {
              shareProfileModal =
                  ParseJson.parseShareProfile(response.data['result']);
              if (shareProfileModal.profileOwner != "") {
                print("profile status" + shareProfileModal.isActive);
                print("profile status" + shareProfileModal.isViewed);

                if (shareProfileModal.sharedView == "linear") {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ShareProfilePage(
                              shareProfileModal.profileOwner,
                              false,
                              "shareProfile",
                              shareProfileModal,
                              "")));
                } else {
                  onTapPresoView();
                }
              }

              return;
            } else {
              print("processForUri++++2");

              goto();

              ToastWrap.showToast(message, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        print("processForUri++++3");

        goto();
      }
    } catch (e) {
      print("processForUri++++4");
      crashlytics_bloc.recordCrashlyticsError(e, "LoginPage", context);
      goto();
      e.toString();
      return;
    }
  }

  approveConnectionFlow(message, type) {
    String connectId, status, email, pass, userId, roleId;
    if (type == "redirect") {
      message = message.replaceAll(
          "https://app.spikeview.com/student/connectionrequest/?connectId=",
          "");
      List<String> mesagelist = message.split("&");
//https://app.spikeview.com/student/connectionrequest/?connectId=10116&status=Requested&loginRole=2&email=p55@yopmail.com&pass=null&userId=4186&roleId=1
      connectId = mesagelist[0];
      status = mesagelist[1].replaceAll("status=", "");
      status = mesagelist[2].replaceAll("loginRole=", "");
      email = mesagelist[3].replaceAll("email=", "");
      pass = mesagelist[4].replaceAll("pass=", "");
      userId = mesagelist[5].replaceAll("userId=", "");
      roleId = mesagelist[6].replaceAll("roleId=", "");
    } else {
      //https://app.spikeview.com/viewprofile/?connectId=10116&loginRole=2&email=p55@yopmail.com&pass=null&userId=4186&roleId=1
      message = message.replaceAll(
          "https://app.spikeview.com/viewprofile/?connectId=", "");
      List<String> mesagelist = message.split("&");

      connectId = mesagelist[0];
      status = mesagelist[1].replaceAll("loginRole=", "");
      status = "";
      email = mesagelist[2].replaceAll("email=", "");
      pass = mesagelist[3].replaceAll("pass=", "");
      userId = mesagelist[4].replaceAll("userId=", "");
      roleId = mesagelist[5].replaceAll("roleId=", "");
    }

    print("=======" +
        connectId +
        "  " +
        status +
        "  " +
        email +
        "  " +
        pass +
        "  " +
        userId +
        "  " +
        roleId);

    if (roleId == "1") {
      // For Student
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => UserProfileDashBoardForOther(
                userId,
                true,
                type,
                "1",
                connectionId: connectId,
              )));
    } else if (roleId == "2") {
      // For Parent
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => ParentProfilePageWithHeader(
                userId,
                type,
                connectionId: connectId,
              )));
    } else if (roleId == "4") {
      // For Partner
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => PatnerProfileWidgetForOtherUser(
                userId,
                type,
                connectionId: connectId,
              )));
    }
  }

  roleSwitchConfirmationDialogForParentApprovel(message, type) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 193.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    MessageConstant
                                                        .ARE_YOU_SURE_SWITCH_PARENT,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            "customRegular"),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.NO,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: 'customRegular'),
                                            )),
                                            onTap: () {
                                              Navigator.of(
                                                      Constant
                                                          .applicationContext,
                                                      rootNavigator: true)
                                                  .pop('dialog');
                                              print("processForUri++++6");

                                              goto();
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.LOGIN_YES,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: 'customRegular'),
                                            )),
                                            onTap: () {
                                              Navigator.of(
                                                      Constant
                                                          .applicationContext,
                                                      rootNavigator: true)
                                                  .pop('dialog');

                                              prefs.setString(
                                                  UserPreference.ROLE_ID, "2");
                                              approveConnectionFlow(
                                                  message, "redirect");
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  processForUri(result, email, name) async {
    prefs.setString(UserPreference.PATHURL, "");
    print("processForUri shubh++++" + result.toString());
    if (result.contains("parentNotification")) {
      try {
        List<String> mesagelist = result.split("/");

        String userId = mesagelist[mesagelist.length - 1];
        String profileId = mesagelist[mesagelist.length - 2];
        String actedBy = mesagelist[mesagelist.length - 3];
        if (userId == prefs.getString(UserPreference.USER_ID)) {
          prefs.setString(UserPreference.ROLE_ID, "2");
          Navigator.of(
            context,
          ).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => PublicViewForUser(
                    "",
                    "main",
                    "Connected",
                    true,
                    actedUserId: actedBy,
                    acteRoleId: "2",
                    profileValue: profileId,
                  )));
        } else {
          goto();
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "LoginPage", context);
        print("processForUri++++Error" + e.toString());
      }
      //   isLoading = true;

    } else if (result.toString().toLowerCase().contains(email)) {
      if (result.contains("/badges/")) {
        try {
          List<String> mesagelist = result.split("/");

          String badgeId = mesagelist[mesagelist.length - 4];
          print("badgeid++$badgeId");
          if (result.contains("/request/")) {
            if (prefs.getString(UserPreference.ROLE_ID) == '4') {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              Navigator.of(Constant.applicationContext).pushReplacement(
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          PartnerNotificationManageBadges("login",
                              badgeId: badgeId)));
            } else {
              goto();
            }
          } else {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => BadgeRequest(badgeId, 'main')));
          }
        } catch (e) {
          goto();
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
      } else if (result.contains("connectionrequest")) {
        prefs.setString(UserPreference.ROLE_ID, "2");
        if (prefs.getString(UserPreference.ROLE_ID) == "2") {
          approveConnectionFlow(result, "redirect");
        } else {
          roleSwitchConfirmationDialogForParentApprovel(result, "redirect");
        }

        //   isLoading = true;

      } else if (result.contains("partner_approval")) {
        List<String> mesagelist = result.split("/");
        prefs.setString(UserPreference.ROLE_ID, "1");
        String userId = mesagelist[mesagelist.length - 3];

        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) =>
                PatnerProfileWidgetForBoatReview(userId, "main")));
      } else if (result.contains("partner_approved")) {
        prefs.setString(UserPreference.ROLE_ID, "4");
        goto();
      } else if (result.contains("partner_decline")) {
        prefs.setString(UserPreference.ROLE_ID, "4");
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    PartnerRejectionReason('main')));
      } else if (result.contains("OpportunityApproval")) {
        List<String> mesagelist = result.split("/");
        prefs.setString(UserPreference.ROLE_ID, "1");
        String opportunityId = mesagelist[mesagelist.length - 3];

        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) =>
                OpportunityForBoat(opportunityId, "1", 'main')));
      } else if (result.contains(Constant.OPPORTUNITY_APPROVED)) {
        List<String> mesagelist = result.split("/");
        prefs.setString(UserPreference.ROLE_ID, "4");
        String opportunityId = mesagelist[mesagelist.length - 1];

        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) =>
                OpportunityForBoat(opportunityId, "4", 'main')));
      } else if (result.contains(Constant.OPPORTUNITY_DECLINE)) {
        List<String> mesagelist = result.split("/");
        prefs.setString(UserPreference.ROLE_ID, "4");
        String opportunityId = mesagelist[mesagelist.length - 1];

        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    opportunityRejected('main', opportunityId)));
      } else if (result.contains("subscription")) {
        List<String> mesagelist = result.split("/");
        print("MessageList++++");
        print("MessageList++++" + mesagelist[mesagelist.length - 2]);
        //   isLoading = true;
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    UnSubScribeWidget(mesagelist[mesagelist.length - 2])));
      } else if (result.contains("previewprofile")) {
        List<String> mesagelist = result.split("/");

        //   ToastWrap.showToast(mesagelist[mesagelist.length-3]);
        String sharedId = mesagelist[mesagelist.length - 3];

        try {
          Codec<String, String> stringToBase64 = utf8.fuse(base64);
          String decodedSharedId = stringToBase64
              .decode(sharedId.replaceAll("&SPK", "=")); // username:password

          print('decodedSharedId public preview 222:: ${decodedSharedId}');
          print('SharedID public preview 222:: ${sharedId}');
          if (decodedSharedId != null && decodedSharedId != "") {
            await shareIDData(decodedSharedId);
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "LoginPage", context);
        }
      } else if (result.contains("viewprofile")) {
        prefs.setString(UserPreference.ROLE_ID, "2");
        if (prefs.getString(UserPreference.ROLE_ID) == "2") {
          approveConnectionFlow(result, "view");
        } else {
          roleSwitchConfirmationDialogForParentApprovel(result, "view");
        }
      } else if (result.contains("recommendation")) {
        List<String> mesagelist = result.split("/");

        String recommendationId = mesagelist[mesagelist.length - 3];

        print("recommendationId///" + recommendationId);
        String userIdRecomm = mesagelist[mesagelist.length - 5];

        if (prefs.getString(UserPreference.USER_ID) == userIdRecomm) {
          Navigator.of(context).popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => SharedRecommendationDetail(
                      recommendationId, false, "", "existing")));
        } else {
          print("processForUri++++5");

          goto();
          ToastWrap.showToastLong(
              MessageConstant.AUTHORIZED_ACCESS_RECOMMENDATON_ERROR, context);
        }
        print("sharedid" + recommendationId + "userId" + userIdRecomm);
      } else if (result.contains("joingroup")) {


        List<String> mesagelist = result.split("/");
        String roleId = mesagelist[mesagelist.length - 3];
        String groupId = mesagelist[mesagelist.length - 2];
        String email = mesagelist[mesagelist.length - 1];

     /*   List<String> mesagelist = result.split("=");

        String roleId = mesagelist[1].replaceAll("&groupId", "");
        String groupId = mesagelist[2].replaceAll("&email", "");
        String email = mesagelist[3].replaceAll("&pass", "");
        String pass = mesagelist[4];*/
        print("name shubh" +
            roleId +
            "   " +
            groupId +
            " " +
            "  " +
            email +
            "  "
            );

        //https://spikeview.com/joingroup?roleId=1&groupId=513&email=p11@yopmail.com&pass=null
        prefs.setString(UserPreference.ROLE_ID, roleId);

        if (name == null || name == "null" || name == "") {
          Navigator.of(context).popUntil((route) => route.isFirst);
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => EditUserProfile(groupId)));
        } else {
          Navigator.of(context).popUntil((route) => route.isFirst);
          Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) =>
                  GroupDetailWidget(groupId, "login", "", "", "")));
        }
      } else if (result.contains("forwardToParentGroup")) {
        List<String> mesagelist = result.split("=");

        String groupId = mesagelist[1].replaceAll("&studentId", "");
        String studentId = mesagelist[2].replaceAll("&roleId", "");
        String roleId = mesagelist[3].replaceAll("&email", "");
        String email = mesagelist[4].replaceAll("&pass", "");

        /* String groupId = mesagelist[1].replaceAll("&studentId", "");
        String studentId = mesagelist[2].replaceAll("&email", "");
        String pass = mesagelist[3];*/

        print("dtata++++" + groupId + " " + studentId);

        //117&studentId  368&email  papa20@yopmail.com&pass
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) =>
                GroupDetailWidget(groupId, "login", "", "", studentId)));
      } else if (result.contains("forwardToParentInquire")) {
        List<String> mesagelist = result.split("=");

        String opportunityId = mesagelist[1].replaceAll("&email", "");
        String email = mesagelist[2].replaceAll("&pass", "");

        print("opportunityId++++" + opportunityId + "  " + email);
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) =>
                InquireNowScreen(opportunityId, userId, "", "1", "login")));
      }
    } else {
      print("processForUri++++1");
      goto();
    }
    prefs.setString(UserPreference.PATHURL, "");
  }

  checkAllFieldSubmitter() {
    if (/*ValidationWidget.isEmail(emailTxtController.text) &&*/

        emailTxtController.text.length > 0 &&
            passwordController.text.length > 0) {
      allFieldCompleted = true;
      setState(() {});
    } else {
      allFieldCompleted = false;
      setState(() {});
    }
  }

  goto() {
    print('inside goto');
    skipExplore = 0;
    skipHighlights = 0;
    //  emailTxtController.text = '';
    prefs.setString(UserPreference.PATHURL, "");

    if (isPasswordChanged) {
      // homeBloc.fetcPost(userId, roleId, context);
      if (roleId == "2") {
       /* if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
          Navigator.of(context).popUntil((route) => route.isFirst);
          Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (BuildContext context) => MoreData()));
        } else*/ if (profileInfoModal != null &&
            profileInfoModal.stage != null &&
            int.parse(profileInfoModal.stage) < 2) {
          ParentOnBoarding()
              .onBoardingInit(context, profileInfoModal, profileInfoModal.userId);

    /*      Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) =>
                  ParentProfileImage(sasToken, "parent")));*/
        } else {
          Navigator.of(context).popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => DashBoardWidgetParent(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE),
                  currentPage: Constant.PROFILE_TYPE,
                  profileInfoModal: profileInfoModal,
                ),
              ));
        }
      } else if (roleId == "4") {
        PartnerOnBoarding()
            .onBoardingInit(context, profileInfoModal, profileInfoModal.userId);

       /* Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      companyModel: companyModel,
                    )));*/
      } else {
        print('profileInfoModal.stage:: ${profileInfoModal.stage}');
        if (profileInfoModal != null && int.parse(profileInfoModal.stage) >= 5) {
          if(profileInfoModal.isEmailVerified==null || !profileInfoModal.isEmailVerified){
            Navigator.of(context).popUntil((route) => route.isFirst);
            Navigator.of(context).pushReplacement(new MaterialPageRoute(
                builder: (BuildContext context) =>
                    EmailVerification(profileInfoModal, sasToken, loginRole: LoginRole.student,)));
          }else
          CustomProgressLoader.showLoader(context);
          bloc.loadData(profileInfoModal.userId, context, prefs);
          Timer _timer = Timer(const Duration(milliseconds: 3000), () {
            CustomProgressLoader.cancelLoader(context);
            Navigator.of(context).popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(
                          UserPreference.IS_USER_ROLE,
                        ),
                        profileInfoModal: profileInfoModal)));
          });
        } else {
          if (profileInfoModal.isExistingUser.toString() == "true") {
            CustomProgressLoader.showLoader(context);
            bloc.loadData(profileInfoModal.userId, context, prefs);
            Timer _timer = Timer(const Duration(milliseconds: 3000), () {
              CustomProgressLoader.cancelLoader(context);
              Navigator.of(context).popUntil((route) => route.isFirst);
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DashBoardWidget(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(
                            UserPreference.IS_USER_ROLE,
                          ),
                          profileInfoModal: profileInfoModal)));
            });
          } else {
            /*if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (BuildContext context) => MoreData()));
            } else {*/
            StudentOnBoarding().getStudentOnBoardingInit(
                context, profileInfoModal, sasToken, userId);
            // }
          }
        }
      }
    } else {
      if (ProfileCreatedByParent && userLoginFirstTime) {
        print('changePassword for userId:: $userId');
        prefs.setString(UserPreference.PASSWORD, _password);
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  ChangePasswordNew("login", roleId, userId: userId)),
        );
      } else {
        print('for userId:: $userId');
        prefs.setString(UserPreference.PASSWORD, _password);
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  ChangePassword("login", roleId, userId: userId)),
        );
      }
    }
  }

  loginServiceCall() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        //prefs = await SharedPreferences.getInstance();
        String encryptedPassWord = "";
        if (_password != "" && _password != "null") {
          encryptedPassWord = await platform.invokeMethod('encryption', {
            "password": _password,
          });
        }
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data
        Map map = {
          "email": _email.toLowerCase(),
          "password": encryptedPassWord,
          "deviceId": prefs.getString("deviceId"),
          "signinType": signinType,
          "socialId": "",
          "platformType": "mobile"
        };

        print("map+++" + map.toString());
        // Make API call
        Response response =
            await dio.post(Constant.ENDPOINT_LOGIN, data: json.encode(map));
        print("response+++" + response.toString());
        CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];
          try {
            if (status == "Success") {
              print("value.........." +
                  response.data['result']['token'].toString());
              // setState(() {
              Constant.isAlreadyLoggedIn = true;

              prefs.setString(UserPreference.PASSWORD, "");
              prefs.setString(UserPreference.IS_USER_ROLE, "false");
              if (response.data['result']['inviteDetails'] != null) {
                var emailChangeSkipCount = response.data['result']
                ['inviteDetails']['emailChangeSkipCount'];
                if (emailChangeSkipCount == null) {
                  emailChangeSkipCount = 0;
                }
                prefs.setInt(
                    UserPreference.EMAIL_SKIP_COUNT, emailChangeSkipCount);
              }

              prefs.setString(UserPreference.IS_PARENT_ROLE, "false");
              prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");

              prefs.setString(UserPreference.SCHOOL_CODE,
                  response.data['result']['schoolCode']);

              var companyMap = response.data['result']['company'];
              Company company = Company('', '', false);
              if (companyMap != null) {
                print('Apurva companyMap:: $companyMap not null');
                company = Company(
                    companyMap['name'].toString(),
                    companyMap['partnerStatus'].toString(),
                    companyMap['isActive']);

                if (company.partnerStatus.toString() == 'Decline')
                  prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP, true);
                else
                  prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP, false);
              }

              print(
                  'Apurva UserPreference.IS_SHOW_REJECTION_POPUP:: ${prefs
                      .getBool(UserPreference.IS_SHOW_REJECTION_POPUP)}');

              userId = response.data['result']['userId'].toString();
              // Api call for get setting data
              bloc.fetchSetting(userId, context, prefs);

              print('Login_Widget userId:: $userId');
              String firstName = response.data['result']['firstName']
                  .toString();
              String lastName = response.data['result']['lastName'].toString();
              String email = response.data['result']['email'].toString();
              String salt = response.data['result']['salt'].toString();
              String mobileNo = response.data['result']['mobileNo'].toString();
              String profilePicture =
              response.data['result']['profilePicture'].toString();
              roleId = response.data['result']['roleId'].toString();

              bool isAddedDob = response.data['result']['isAddedDob'];
              if (isAddedDob == null) {
                isAddedDob = false;
              }
              prefs.setBool(UserPreference.IS_ADDED_DOB, isAddedDob);
              String schoolCode =
              response.data['result']['schoolCode'].toString();
              if (schoolCode == null ||
                  schoolCode == "" ||
                  schoolCode == "null") {
                schoolCode = "";
                prefs.setBool(UserPreference.IS_SCHOOL, false);
              } else {
                prefs.setBool(UserPreference.IS_SCHOOL, true);
              }
              prefs.setString(UserPreference.SCHOOL_CODE, schoolCode);

              if (prefs.getString(UserPreference.SCHOOL_CODE) != null &&
                  prefs.getString(UserPreference.SCHOOL_CODE) != "null" &&
                  prefs.getString(UserPreference.SCHOOL_CODE) != "") {
                bloc.apiCallForAcessControl(prefs, userId, context);
              } else {
                bloc.accessControlParam(prefs);
              }

              bool isUnderAge = response.data['result']['isUnderAge'];
              if (isUnderAge == null) {
                isUnderAge = false;
              }
              prefs.setBool(UserPreference.IS_UNDER_AGE, isUnderAge);

              String dob = response.data['result']['dob'].toString();
              if (dob == null || dob == "null" || dob == "") {
                dob = "0";
              }
              String companyName =
              response.data['result']['companyName'].toString();
              String companyProfilePicture =
              response.data['result']['companyProfilePicture'].toString();
              ProfileCreatedByParent =
              response.data['result']['profileCreatedByParent'];
              if (ProfileCreatedByParent == null) {
                ProfileCreatedByParent = false;
              }

              userLoginFirstTime =
              response.data['result']['userLoginFirstTime'];
              if (userLoginFirstTime == null) {
                userLoginFirstTime = false;
              }

              prefs.setBool(
                  UserPreference.SHOW_BOT_DEFAULT_COUNT, userLoginFirstTime);

              print(
                  "userLoginFirstTime+++++++" + userLoginFirstTime.toString());
              prefs.setBool(
                  UserPreference.IS_USER_LOGIN_FIRST_TIME, userLoginFirstTime);

              prefs.setString(UserPreference.DOB, dob);
              try {
                var role = response.data['result']['role'];
                for (int i = 0; i < role.length; i++) {
                  print("role++" + role[i]['id'].toString());
                  if (role[i]['id'] == 1) {
                    prefs.setString(UserPreference.IS_USER_ROLE, "true");
                  } else if (role[i]['id'] == 2) {
                    prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
                  } else if (role[i]['id'] == 4) {
                    prefs.setString(UserPreference.IS_PARTNER_ROLE, "true");
                  }
                }

                if (prefs.getString(UserPreference.IS_PARTNER_ROLE) == "true") {
                  roleId = "4";
                } else if (prefs.getString(UserPreference.IS_PARENT_ROLE) ==
                    "true") {
                  roleId = "2";
                } else {
                  roleId = "1";
                }
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "LoginPage", context);
              }

              String token = response.data['result']['token'].toString();
              isPasswordChanged = response.data['result']['isPasswordChanged'];
              if (signinType == "apple" || signinType == "google") {
                isPasswordChanged = true;
              }
              userList.add(UserData(
                  userId,
                  firstName,
                  lastName,
                  email,
                  salt,
                  mobileNo,
                  profilePicture,
                  roleId));
              print("user Login id" + userId);

              prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
              String isActive = response.data['result']['isActive'].toString();
              bool isExistingUser = response.data['result']['isExistingUser'];
              bool isEmailVerified = response.data['result']['isEmailVerified'];
              if (isEmailVerified == null) {
                isEmailVerified = false;
              }
              bool isCollegeAdded = response.data['result']['isCollegeAdded'];
              if (isExistingUser == null) {
                isExistingUser = false;
              }
              if (isCollegeAdded == null) {
                isCollegeAdded = false;
              }
              String isHide = response.data['result']['isHide'].toString();
              prefs.setString(UserPreference.ISHide, isHide);
              prefs.setString(UserPreference.ISACTIVE, isActive);

              prefs.setBool(UserPreference.LOGIN_STATUS, true);
              prefs.setString(UserPreference.ROLE_ID, roleId);
              print("user RoleId test+++" + roleId);
              Constant.ROLE_ID = roleId;

              prefs.setBool(
                  UserPreference.IS_PASSWORD_CHANGED, isPasswordChanged);
              prefs.setBool(UserPreference.IS_PROFILECRETED_BY_PARENT,
                  ProfileCreatedByParent);

              prefs.setString(UserPreference.USER_ID, userId);
              prefs.setBool(
                  UserPreference.IS_PARENT, roleId == "2" ? true : false);
              prefs.setString(UserPreference.PARENT_ID, userId);
              prefs.setString(UserPreference.NAME, firstName + " " + lastName);
              prefs.setString(UserPreference.EMAIL, email);
              prefs.setString(UserPreference.MOBILE, mobileNo);
              prefs.setString(UserPreference.chat_skip_count, "0");

              prefs.setString(
                  UserPreference.PROFILE_IMAGE_PATH, profilePicture);
              prefs.setString(
                  UserPreference.COMPANY_IMAGE_PATH, companyProfilePicture);
              prefs.setString(UserPreference.COMPANY_NAME_PATH, companyName);
              prefs.setString(UserPreference.USER_TOKEN, "Spike " + token);

              String path = "";
              try {
                path = prefs.getString(UserPreference.PATHURL);
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "LoginPage", context);
              }

              String requireParentApproval =
              response.data['result']['requireParentApproval'].toString();
              String isPasswordChanged1 =
              response.data['result']['isPasswordChanged'].toString();
              if (signinType == "apple" || signinType == "google") {
                isPasswordChanged1 = "true";
              }
              String ccToParents =
              response.data['result']['ccToParents'].toString();
              String lastAccess =
              response.data['result']['lastAccess'].toString();
              String organizationId =
              response.data['result']['organizationId'].toString();
              String gender = response.data['result']['gender'].toString();
              String genderAtBirth =
              response.data['result']['genderAtBirth'].toString();
              String usCitizenOrPR =
              response.data['result']['usCitizenOrPR'].toString();
              String summary = response.data['result']['summary'].toString();
              String coverImage =
              response.data['result']['coverImage'].toString();
              String tagline = response.data['result']['tagline'].toString();
              String title = response.data['result']['title'].toString();
              String tempPassword =
              response.data['result']['tempPassword'].toString();

              String isArchived =
              response.data['result']['isArchived'].toString();
              String achievement =
              response.data['result']['isAchievement'].toString();
              String isEducation =
              response.data['result']['isEducation'].toString();
              String groupId = response.data['result']['groupId'].toString();
              String groupName = response.data['result']['groupName']
                  .toString();
              String groupImage =
              response.data['result']['groupImage'].toString();
              String zipCode = response.data['result']['zipCode'].toString();
              bool referralPopup = response.data['result']['referralPopup'];
              String stage = response.data['result']['stage'].toString();
              String creationTime = "0";
              creationTime = response.data['result']['creationTime'].toString();
              if (creationTime == "null") {
                creationTime = "0";
              }

              bool isPublicUrlActive =
              response.data['result']['isPublicUrlActive'];
              if (isPublicUrlActive == "null") {
                isPublicUrlActive = false;
              }

              bool isPublicProfileGlobalyActive =
              response.data['result']['isPublicProfileGlobalyActive'];
              if (isPublicProfileGlobalyActive == null ||
                  isPublicProfileGlobalyActive == "null") {
                isPublicProfileGlobalyActive = false;
              }

              String publicUrl =
              response.data['result']['publicUrl'].toString().trim();
              if (publicUrl == "null") {
                publicUrl = "";
              }

              String referCode = response.data['result']['referCode']
                  .toString();

              bool isPreLoginSetting =
              response.data["result"]["isLeaderboardDisplay"];
              if (isPreLoginSetting == null) {
                isPreLoginSetting = false;
              }
              prefs.setBool(UserPreference.IS_PRE_LOGIN, isPreLoginSetting);
              prefs.setBool(UserPreference.IS_PRE_LOGIN, isPreLoginSetting);

              String badgeImage =
              response.data['result']['badgeImage'].toString();
              if (badgeImage == null ||
                  badgeImage == "null" ||
                  badgeImage == "") {
                badgeImage = "";
              }
              String badge = response.data['result']['badge'].toString();
              if (badge == null || badge == "null" || badge == "") {
                badge = "";
              }
              String gamification =
              response.data['result']['gamificationPoints'].toString();
              int gamificationPoints;
              if (gamification == null ||
                  gamification == "" ||
                  gamification == "null") {
                gamificationPoints = 0;
              } else {
                gamificationPoints = int.parse(gamification);
              }

              prefs.setString(UserPreference.referCode, referCode);
              prefs.setString(UserPreference.badgeType, badge);
              prefs.setInt(
                  UserPreference.gamificationPoints, gamificationPoints);
              prefs.setString(UserPreference.badgeImage, badgeImage);
              if (achievement == "true") {
                prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, true);
              } else {
                prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, false);
              }

              if (isEducation == "true") {
                prefs.setBool(UserPreference.isEducationAdded, true);
              } else {
                prefs.setBool(UserPreference.isEducationAdded, false);
              }

              if (referralPopup == null || referralPopup == "null") {
                referralPopup = false;
              }

              List<SocialLinkData> socialLinkList = List();
              var socalLinkMap = response.data['result']['socialLinks'];
              if (socalLinkMap != null && socalLinkMap.length > 0) {
                for (int i = 0; i < socalLinkMap.length; i++) {
                  String image = socalLinkMap[i]['image'].toString();
                  String socialName = socalLinkMap[i]['socialName'].toString();
                  String socialUrl = socalLinkMap[i]['socialUrl'].toString();
                  int socialId = socalLinkMap[i]['socialId'];

                  socialLinkList.add(SocialLinkData(
                      image: image,
                      socialName: socialName,
                      socialUrl: socialUrl,
                      socialId: socialId));
                }
              }
              var introVideo = response.data['result']['introVideo'] != null
                  ? IntroVideo.fromJson(response.data['result']['introVideo'])
                  : null;
              profileInfoModal = ProfileInfoModal(
                  userId,
                  firstName,
                  lastName,
                  email,
                  mobileNo,
                  profilePicture,
                  roleId,
                  isActive,
                  requireParentApproval,
                  ccToParents,
                  lastAccess,
                  isPasswordChanged1,
                  organizationId,
                  gender,
                  dob,
                  genderAtBirth,
                  usCitizenOrPR,
                  null,
                  summary,
                  coverImage,
                  tagline,
                  title,
                  tempPassword,
                  isArchived,
                  null,
                  false,
                  groupId,
                  groupName,
                  groupImage,
                  "",
                  "",
                  zipCode,
                  isHide,
                  referralPopup,
                  userLoginFirstTime,
                  stage,
                  creationTime,
                  badge,
                  gamificationPoints,
                  badgeImage,
                  referCode,
                  socialLinkList,
                  publicUrl,
                  isPublicUrlActive,
                  isPublicProfileGlobalyActive,
                  introVideo,
                  company,
                  isExistingUser,
                  isCollegeAdded,
                  null,
                  schoolCode,
                  '',
                  "",
                  false,
                  isEmailVerified);

              prefs.setString(
                  UserPreference.CREATION_TIME, profileInfoModal.creationTime);
              prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
              prefs.setString(UserPreference.ZIPCODE, profileInfoModal.zipCode);
              prefs.setString(UserPreference.NAME,
                  profileInfoModal.firstName + " " + profileInfoModal.lastName);
              prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                  profileInfoModal.profilePicture);

              prefs.setString(UserPreference.TAGLINE, profileInfoModal.tagline);
              prefs.setString(
                  UserPreference.ISACTIVE, profileInfoModal.isActive);

              var CompanyMap = response.data['result']['company'];
              if (CompanyMap != null) {
                companyModel =
                    ParseJson.parseCompanyInfoDataForLogin(CompanyMap);
                if (companyModel != null) {
                  prefs.setString(UserPreference.COMPANY_IMAGE_PATH,
                      companyModel.profilePicture);

                  //for remove college counselling
                  for (int i = 0; i < companyModel.offers.length; i++) {
                    if (companyModel.offers[i].offerId == 3) {
                      companyModel.offers.removeAt(i);
                    }
                  }

                  prefs.setString(
                      UserPreference.COMPANY_NAME_PATH, companyModel.name);
                }
              }

              try {
                if (widget.imageList == null || widget.imageList.length == 0) {
                  if (path != null && path != "") {
                    print("Skjjj++++" + path);
                    processForUri(path, email, firstName);
                    if (path.toString().contains("studentActivation")) {
                      prefs.setString(UserPreference.PATH_PARENT, path);
                    }
                  } else {
                    print("processForUri++++7");

                    goto();
                  }
                } else {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              FullIMageViewGallery(widget.imageList)));
                }
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "LoginPage", context);
                if (path != null && path != "") {
                  processForUri(path, email, firstName);
                } else {
                  print("processForUri++++8");

                  goto();
                }
              }
            } else {
              ToastWrap.showToastLongNew(message, context);
            }
          }catch(e){
            print("error+++Data++" + e.toString());
          }
        } else {
          setState(() => _isLoading = false);
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "LoginPage", context);
        print("error+++" + e.toString());
        if (mounted) CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      setState(() => _isLoading = false);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  _fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();

    FocusScope.of(context).requestFocus(nextFocus);
  }

  @override
  Widget build(BuildContext context) {
    Constant.pageNameFr = "login";
    Constant.applicationContext = context;
    print("called constant shubh data+++");

    screenWidth = MediaQuery.of(context).size.width;
    screenHeight = MediaQuery.of(context).size.height;

    bottomPadding = MediaQuery.of(context).padding.bottom;

    return Theme(
        data: ThemeData(
          backgroundColor: Colors.white,
          brightness: Brightness.light,
          indicatorColor: Colors.black,
          textSelectionColor: Colors.black54,
          cursorColor: Colors.black,
          accentColor: Colors.black,
          /*bottomSheetTheme: BottomSheetThemeData(
                  backgroundColor: Colors.transparent
              ),*/
        ),
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(FocusNode());
              //if(!showSignupButton)Navigator.pop(context);
            },
            child: Scaffold(
              key: _key,

              //Colors.white,
              backgroundColor: ColorValues.WHITE,
              bottomNavigationBar: Container(
                height: 50.0,
                child: Padding(
                    padding: EdgeInsets.only(
                        left: 0.0, right: 0.0, top: 0, bottom: 0),
                    child: Container(
                      child: Column(
                        children: <Widget>[
                          /* Container(color: Color(0xfff1f1f1),height: 1.0,),*/
                          RichText(
                            maxLines: 1,
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text: MessageConstant.LOGIN_DONT_HAVE_ACCOUNT,
                              style: AppConstants
                                  .txtStyle.heading400LatoRegularDarkBlue,
                              children: [
                                TextSpan(
                                    text: MessageConstant.LOGIN_SIGN_UP,
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        setState(() {
                                          isShowDetailView = false;
                                          emailTxtController.text = '';
                                          passwordController.text = '';
                                          FocusScope.of(context).unfocus();
                                        });
                                        setState(() {
                                          widget.isRedirectToRecommendation =
                                              null;
                                        });
                                        for (RoleDataModel data in dataList) {
                                          data.isSelected = false;
                                        }
                                        _googleSignIn.signOut();
                                        selectedRole = "";
                                        isShowError = false;
                                        showJoinNowPopup(context);
                                      },
                                    style: AppConstants.txtStyle
                                        .heading400LatoRegularLightBlue),
                              ],
                            ),
                          )
                        ],
                      ),
                    )),
              ),
              body: WillPopScope(
                  onWillPop: () {
                    if (isShowDetailView) {
                      setState(() {
                        isShowDetailView = false;
                      });
                    }
                  },
                  child: SafeArea(
                      child: Container(
                    //height: 314.0,
                    //color: Colors.black.withOpacity(0.8),
                    color: Colors.white,
                    child: Form(
                      key: formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                              child: SingleChildScrollView(
                                  child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 20.0, right: 20),
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Padding(
                                          padding: const EdgeInsets.only(
                                              left: 0.0,
                                              right: 0.0,
                                              top: 40.0,
                                              bottom: 10),
                                          child: RichText(
                                            maxLines: 1,
                                            textAlign: TextAlign.center,
                                            text: TextSpan(
                                              text: AppConstants
                                                  .stringConstant.strSignIn,
                                              style: AppConstants.txtStyle
                                                  .heading400LatoRegularDarkBlue
                                                  .copyWith(
                                                      fontSize: 28,
                                                      fontWeight:
                                                          FontWeight.w700),
                                              children: [
                                                TextSpan(
                                                    text:
                                                        '' /*AppConstants
                                                        .stringConstant
                                                        .strAccount*/
                                                    ,
                                                    recognizer:
                                                        TapGestureRecognizer()
                                                          ..onTap = () {},
                                                    style: AppConstants.txtStyle
                                                        .heading40018LatoRegularDarkBlue
                                                        .copyWith(
                                                            fontSize: 28,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w700)),
                                              ],
                                            ),
                                          )),
                                      BaseText(
                                        text: AppConstants
                                            .stringConstant.strLoginTxt,
                                        textColor:
                                            AppConstants.colorStyle.lightPurple,
                                        fontFamily: AppConstants
                                            .stringConstant.latoSemibold,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18,
                                      ),
                                      SizedBox(
                                        height: 35,
                                      ),
                                      CustomFormField(
                                        // maxLength: 35,
                                        onSaved: (val) => _email = val,
                                        autovalidateMode:
                                            AutovalidateMode.disabled,
                                        prefixWidget: Image.asset(
                                          getAssetsPNGImg('email'),
                                          height: 20,
                                          width: 20,
                                        ),
                                        onType: (v) {
                                          checkAllFieldSubmitter();
                                        },
                                        textInputType:
                                            TextInputType.emailAddress,
                                        controller: emailTxtController,
                                        label: "Email",
                                        validation: (val) => val
                                                    .trim()
                                                    .length ==
                                                0
                                            ? MessageConstant.ENTER_EMAIL_VAL
                                            : !ValidationWidget.isEmail(val)
                                                ? MessageConstant
                                                    .ENTER_CORRECRT_EMAIL_VAL
                                                : null,
                                      ),
                                      SizedBox(
                                        height: 35,
                                      ),
                                      CustomFormField(
                                        // maxLength: 35,
                                        onSaved: (val) => _password = (val),
                                        controller: passwordController,
                                        autovalidateMode:
                                            AutovalidateMode.disabled,
                                        prefixWidget: Image.asset(
                                          getAssetsPNGImg('password'),
                                          height: 20,
                                          width: 20,
                                        ),
                                        onType: (v) {
                                          checkAllFieldSubmitter();
                                        },
                                        label: "Password",
                                        isObsecure: isPasswordVisible,

                                        suffixWidget: GestureDetector(
                                          child: isPasswordVisible
                                              ? Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      10.0, 18.0, 0.0, 6.0),
                                                  child: Image.asset(
                                                    "assets/newDesignIcon/login/hide.png",
                                                    width: 25.0,
                                                    height: 25.0,
                                                  ))
                                              : Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  10.0, 18.0, 0.0, 6.0),
                                              child: Image.asset(
                                                "assets/newDesignIcon/login/unhide.png",
                                                width: 25.0,
                                                height: 25.0,color: AppConstants.colorStyle.lightPurple,
                                              )),
                                          onTap: () {
                                            if (isPasswordVisible)
                                              isPasswordVisible = false;
                                            else
                                              isPasswordVisible = true;

                                            setState(() {
                                              isPasswordVisible;
                                            });
                                          },
                                        ),
                                        validation: (val) => val
                                                    .trim()
                                                    .length ==
                                                0
                                            ? MessageConstant
                                                .LOGIN_ENTER_PASSWORD
                                            /* : !ValidationWidget.isPass(val)
                                                        ? MessageConstant
                                                        .LOGIN_INCORRECT_PASSWORD*/
                                            : null,
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      forgotLabel(),
                                      loginButton(),
                                      Padding(
                                          padding: EdgeInsets.only(
                                              top: 24.0, bottom: 24.0),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Container(
                                                  height: 1.0,
                                                  color:
                                                      ColorValues.BORDER_COLOR,
                                                ),
                                                flex: 1,
                                              ),
                                              Expanded(
                                                child: Text(
                                                  MessageConstant.LOGIN_OR,
                                                  style: AppConstants.txtStyle
                                                      .heading14400LatoRegularLightPurple,
                                                ),
                                                flex: 0,
                                              ),
                                              Expanded(
                                                child: Container(
                                                  height: 1.0,
                                                  color:
                                                      ColorValues.BORDER_COLOR,
                                                ),
                                                flex: 1,
                                              )
                                            ],
                                          )),
                                      Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: Padding(
                                              padding: const EdgeInsets.only(
                                                  right: 12.0),
                                              child: InkWell(
                                                onTap: () {
                                                  //_googleSignIn.signOut();
                                                  signInWithGoogle(
                                                      context, "SignIn");
                                                  // _handleSignIn("SignIn");
                                                },
                                                child: Container(
                                                  height: 45.0,
                                                  decoration: BoxDecoration(
                                                      color: AppConstants
                                                          .colorStyle.btnBg,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10)),
                                                  child: Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0, 0, 13, 0),
                                                        child: Image.asset(
                                                          'assets/login/google.png',
                                                          height: 20.0,
                                                          width: 20.0,
                                                        ),
                                                      ),
                                                      Text(
                                                        MessageConstant
                                                            .LOGIN_SIGN_WITH_GOOGLE,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppConstants
                                                            .txtStyle
                                                            .heading14500LatoRegularDarkBlue,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 12.0),
                                              child: InkWell(
                                                onTap: () async {
                                                  final credential =
                                                      await SignInWithApple
                                                          .getAppleIDCredential(
                                                    scopes: [
                                                      AppleIDAuthorizationScopes
                                                          .email,
                                                      AppleIDAuthorizationScopes
                                                          .fullName,
                                                    ],
                                                    webAuthenticationOptions:
                                                        WebAuthenticationOptions(
                                                      // TODO: Set the `clientId` and `redirectUri` arguments to the values you entered in the Apple Developer portal during the setup
                                                      clientId:
                                                          'com.spikeview.spikeviewproject',
                                                      redirectUri: Uri.parse(
                                                        //  'https://quick-mangrove-marble.glitch.me/callbacks/sign_in_with_apple',
                                                        'https://app.spikeview.com/ui/callbacks/sign_in_with_apple',
                                                      ),
                                                    ),
                                                    // TODO: Remove these if you have no need for them
                                                  );

                                                  _email = credential.email
                                                      .toString();
                                                  if (credential.email
                                                              .toString() ==
                                                          "null" ||
                                                      credential.email
                                                              .toString() ==
                                                          "") {
                                                    String yourToken =
                                                        credential
                                                            .identityToken;
                                                    Map<String, dynamic>
                                                        decodedToken =
                                                        JwtDecoder.decode(
                                                            yourToken);
                                                    print(
                                                        "decode++++++++++++++" +
                                                            decodedToken
                                                                .toString());
                                                    print(
                                                        "decode++++++++++++++" +
                                                            decodedToken[
                                                                "email"]);
                                                    _email =
                                                        decodedToken["email"];
                                                  }
                                                  signinType = "apple";
                                                  loginServiceCall();
                                                },
                                                child: Container(
                                                    height: 45.0,
                                                    decoration: BoxDecoration(
                                                        color: AppConstants
                                                            .colorStyle.btnBg,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10)),
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  0,
                                                                  13,
                                                                  0),
                                                          child: Image.asset(
                                                            'assets/login/apple.png',
                                                            height: 20.0,
                                                            width: 20.0,
                                                          ),
                                                        ),
                                                        Text(
                                                          MessageConstant
                                                              .LOGIN_SIGN_WITH_APPLE,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: AppConstants
                                                              .txtStyle
                                                              .heading14500LatoRegularDarkBlue,
                                                        ),
                                                      ],
                                                    )),
                                              ),
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ),
                                    ]),
                              )),
                              flex: 1)
                        ],
                      ),
                    ),
                  ))),
            )));
  }

  openSignupBottomSheet(context) {
    if (isOpenSignup)
      showJoinNowPopup(context);
    else
      return Container();
    //isOpenLogin ? signInPopup(context): Container(),
  }

  userNameView() {
    return Padding(
      padding: EdgeInsets.only(left: 0.0, top: 40.0, right: 0.0, bottom: 0.0),
      child: Theme(
        data: ThemeData(
            backgroundColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
            indicatorColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
            cursorColor: ColorValues.HEADING_COLOR_EDUCATION,
            textSelectionColor: Colors.black54,
            accentColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
            hintColor: ColorValues.LIGHT_GREY_TEXT_COLOR),
        child: TextFormField(
          controller: emailTxtController,
          keyboardType: TextInputType.emailAddress,
          textInputAction: TextInputAction.next,
          focusNode: _emailFocus,
          onFieldSubmitted: (term) {
            //_fieldFocusChange(context, _emailFocus, _passwordFocus);
          },
          validator: (val) => val.trim().length == 0
              ? MessageConstant.ENTER_EMAIL_VAL
              : !ValidationWidget.isEmail(val)
                  ? MessageConstant.ENTER_CORRECRT_EMAIL_VAL
                  : null,
          onSaved: (val) => _email = val,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(color: Colors.black, fontFamily: "customRegular"),
          decoration: InputDecoration(
              /*suffixIcon:  GestureDetector(
                  child:  Padding(
                    padding:  EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),
                    child:  Image.asset(
                      "assets/newDesignIcon/login/mail.png",
                      width: 25.0,
                      height: 25.0,
                    ),
                  )),*/
              contentPadding: EdgeInsets.fromLTRB(0.0, 7.0, 5.0, 10.0),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: ColorValues.DARK_GREY)),
              disabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: ColorValues.DARK_GREY)),
              enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: ColorValues.DARK_GREY)),
              labelText: "Email",
              errorStyle: Util.errorTextStyle,
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: "customRegular"),
              border: UnderlineInputBorder(
                  borderSide: BorderSide(color: ColorValues.DARK_GREY))),
        ),
      ),
    );
  }

  forgotLabel() {
    return Align(
        alignment: Alignment.topRight,
        child: InkWell(
          child: Padding(
              padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
              child: Text(
                "Forgot password? ",
                style: AppConstants.txtStyle.heading14400LatoRegularLightBlue,
              )),
          onTap: () {
            /*     Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => EmailVerification()),
            ).then((value) {
              print('111111111111111111111111111');
              FocusScope.of(context).requestFocus(FocusNode());
            });*/

            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ForgotPassword(
                      emailTxtController == null
                          ? ""
                          : emailTxtController.text)),
            ).then((value) {
              print('111111111111111111111111111');
              FocusScope.of(context).requestFocus(FocusNode());
            });
          },
        ));
  }

  loginButton() {
    return Container(
        child: Padding(
            padding: EdgeInsets.only(top: 30.0),
            child: Stack(
              children: <Widget>[
                Container(
                    height: 44.0,
                    child: FlatButton(
                      onPressed: () {
                        FocusScope.of(context).unfocus();
                        _checkValidation();
                      },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: AppConstants.colorStyle.lightBlue,
                      child: Row(
                        // Replace with a Row for horizontal icon + text
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text('Sign in',
                              style: AppConstants
                                  .txtStyle.heading18600LatoRegularWhite),
                        ],
                      ),
                    )),
                allFieldCompleted
                    ? SizedBox(
                        height: 0,
                      )
                    : Container(
                        height: 44.0,
                        width: double.infinity,
                        color: Colors.white.withOpacity(0.0),
                      )
              ],
            )));
  }

  showJoinNowPopupAlert() {
    showDialog(
        barrierDismissible: true,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.transparent,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 0.0,
                            child: Container(
                                height: 314.0,
                                padding: EdgeInsets.symmetric(horizontal: 11.0),
                                //color: Colors.black.withOpacity(0.9),
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        0.0,
                                        10.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 314.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color:
                                                Colors.black.withOpacity(0.9),
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  userNameView(),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                      ],
                    )))));
  }

  Future<Null> updated(StateSetter updateState, role) async {
    updateState(() {
      selectedRole = role;
    });
  }

  Widget showJoinNowPopup(context) {
    String selectedData = "";

    setState(() {
      showSignupButton = false;
    });
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        builder: (BuildContext bc) {
          return StatefulBuilder(builder: (context, state) {
            return Scaffold(

                //Colors.white,
                backgroundColor: ColorValues.WHITE,
                bottomNavigationBar: Container(
                  height: 50.0,
                  child: Padding(
                      padding: EdgeInsets.only(
                          left: 20.0, right: 20.0, top: 0, bottom: 0),
                      child: Container(
                        child: Column(
                          children: <Widget>[
                            /* Container(color: Color(0xfff1f1f1),height: 1.0,),*/
                            RichText(
                              maxLines: 1,
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                text: MessageConstant.LOGIN_ALREADY_ACCOUNT,
                                style: AppConstants
                                    .txtStyle.heading400LatoRegularDarkBlue,
                                children: [
                                  TextSpan(
                                      text: MessageConstant.LOGIN_SIGN_IN,
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {
                                          Navigator.pop(context);
                                        },
                                      style: AppConstants.txtStyle
                                          .heading400LatoRegularLightBlue),
                                ],
                              ),
                            )
                          ],
                        ),
                      )),
                ),
                body: SafeArea(
                    child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20.0, right: 20.0),
                    child: Column(
                      children: <Widget>[
                        SingleChildScrollView(
                            child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                                padding: const EdgeInsets.only(
                                    left: 0.0,
                                    right: 0.0,
                                    top: 80.0,
                                    bottom: 10),
                                child: RichText(
                                  maxLines: 2,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: 'Select a role to sign up\nwith',
                                    style: AppConstants
                                        .txtStyle.heading400LatoRegularDarkBlue
                                        .copyWith(
                                            fontSize: 28,
                                            fontWeight: FontWeight.w700),
                                    children: [
                                      TextSpan(
                                          text: '',
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {},
                                          style: AppConstants.txtStyle
                                              .heading40018LatoRegularDarkBlue
                                              .copyWith(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.w700)),
                                    ],
                                  ),
                                )),
                            /*   BaseText(
                              text: 'Select a role to sign up with',
                              textColor: AppConstants.colorStyle.lightPurple,
                              fontFamily:
                                  AppConstants.stringConstant.latoSemibold,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),*/
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                40.0,
                                0.0,
                                12.0,
                                InkWell(
                                    onTap: () {
                                      if (widget.isRedirectToRecommendation ==
                                              null ||
                                          widget.isRedirectToRecommendation
                                                  .toString() ==
                                              "false") {
                                        setState(() {
                                          dataList;
                                          isSelected = true;
                                          selectedRole = "1";
                                          selectedData = "1";
                                        });
                                        print("role++++" + selectedData);
                                        updated(state, selectedData);
                                        onTapContinueButton(
                                            "spikeview", "", "", email, "", true);
                                      } else {
                                        selectedRole = "1";
                                        selectedData = "1";
                                        print("email++++11" + email);
                                        onTapContinueButton(
                                            "spikeview", "", "", email, "", true);
                                        //onTap(dataList[Index].roleTypeId);
                                      }
                                    },
                                    child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(12.0),
                                        child: Container(
                                          width: double.infinity,
                                          height: 112,
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: AssetImage(
                                                  getAssetsPNGImg('b1')),
                                              fit: BoxFit.fill,
                                            ),
                                            //color: Colors.blue.withOpacity(0.5),
                                          ),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                  flex: 1,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 25.0),
                                                    child: BaseText(
                                                      text: 'Student',
                                                      textColor: Colors.white,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoRegular,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      fontSize: 28,
                                                      maxLines: 1,
                                                    ),
                                                  )),
                                              Expanded(
                                                  flex: 0,
                                                  child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              right: 2.0),
                                                      child: Image.asset(
                                                        getAssetsPNGImg('b11'),
                                                        height: 112,
                                                        width: 117,
                                                      ))),
                                            ],
                                          ),
                                        )))),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                12.0,
                                0.0,
                                12.0,
                                InkWell(
                                    onTap: () {
                                      if (widget.isRedirectToRecommendation ==
                                              null ||
                                          widget.isRedirectToRecommendation
                                                  .toString() ==
                                              "false") {
                                        setState(() {
                                          dataList;
                                          isSelected = true;
                                          selectedRole = "2";
                                          selectedData = "2";
                                        });
                                        updated(state, selectedData);
                                        print("role++++" + selectedData);
                                        onTapContinueButton(
                                            "spikeview", "", "", email, "", true);
                                      } else {
                                        selectedRole = "2";
                                        selectedData = "2";
                                        onTapContinueButton(
                                            "spikeview", "", "", email, "", true);
                                        //onTap(dataList[Index].roleTypeId);
                                      }
                                    },
                                    child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(12.0),
                                        child: Container(
                                          width: double.infinity,
                                          height: 112,
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: AssetImage(
                                                  getAssetsPNGImg('b2')),
                                              fit: BoxFit.fill,
                                            ),
                                            //color: Colors.blue.withOpacity(0.5),
                                          ),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                  flex: 1,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 25.0),
                                                    child: BaseText(
                                                      text: 'Parent',
                                                      textColor: Colors.white,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoRegular,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      fontSize: 28,
                                                      maxLines: 1,
                                                    ),
                                                  )),
                                              Expanded(
                                                  flex: 0,
                                                  child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              right: 5.0),
                                                      child: Image.asset(
                                                        getAssetsPNGImg('b21'),
                                                        height: 112,
                                                        width: 152,
                                                      ))),
                                            ],
                                          ),
                                        )))),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                12.0,
                                0.0,
                                12.0,
                                InkWell(
                                    onTap: () {
                                      if (widget.isRedirectToRecommendation ==
                                              null ||
                                          widget.isRedirectToRecommendation
                                                  .toString() ==
                                              "false") {
                                        setState(() {
                                          dataList;
                                          isSelected = true;
                                          selectedRole = "3";
                                          selectedData = "3";
                                        });
                                        updated(state, selectedData);
                                        onTapContinueButton(
                                            "spikeview", "", "", email, "", true);
                                        //Navigator.pop(context);
                                        //  showJoinNowPopup(context);
                                      } else {
                                        selectedRole = "3";
                                        selectedData = "3";
                                        onTapContinueButton(
                                            "spikeview", "", "", email, "", true);
                                        //onTap(dataList[Index].roleTypeId);
                                      }
                                    },
                                    child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(12.0),
                                        child: Container(
                                          width: double.infinity,
                                          height: 112,
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: AssetImage(
                                                  getAssetsPNGImg('b3')),
                                              fit: BoxFit.fill,
                                            ),
                                            //color: Colors.blue.withOpacity(0.5),
                                          ),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                  flex: 1,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 25.0),
                                                    child: BaseText(
                                                      text: 'Partner',
                                                      textColor: Colors.white,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoRegular,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      fontSize: 28,
                                                      maxLines: 1,
                                                    ),
                                                  )),
                                              Expanded(
                                                  flex: 0,
                                                  child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              right: 1.0),
                                                      child: Image.asset(
                                                        getAssetsPNGImg('b31'),
                                                        height: 112,
                                                        width: 120,
                                                      ))),
                                            ],
                                          ),
                                        )))),
                          ],
                        )),
                      ],
                    ),
                  ),
                )));
          });
        }).then((value) => _closeModal(value));
  }

  signInWithGoogle(BuildContext context, String type) async {
    User user = FirebaseAuth.instance.currentUser;
    bool isSignedIn = await _googleSignIn.isSignedIn();
    if (isSignedIn) {
      _googleSignIn.signOut();
    } else {}
    _googleSignIn = GoogleSignIn();
    final GoogleSignInAccount googleSignInAccount =
        await _googleSignIn.signIn();
    if (googleSignInAccount != null) {
      try {
        final GoogleSignInAccount googleUser = await _googleSignIn.signIn();
        final GoogleSignInAuthentication googleAuth =
            await googleUser.authentication;
        final GoogleAuthCredential credential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );
        final UserCredential authResult =
            await _fbAuth.signInWithCredential(credential);
        final User user = authResult.user;
        assert(!user.isAnonymous);
        assert(await user.getIdToken() != null);
        final User currentUser = _fbAuth.currentUser;
        assert(currentUser.uid == user.uid);
        print("log______" + user.toString());
        try {
          _email = user.email;
          signinType = "google";
          if (type == "Signup") {
            String firstName = "";
            String lastName = "";
            if (user.displayName != null) {
              List<String> data = user.displayName.split(" ");
              firstName = data[0];
              lastName = data[1];
            }
            String image = user.photoURL;
            if (image == null || image == "null") {
              image = "";
            }

            onTapContinueButton(
                "google", firstName, lastName, _email, image, true);
          } else {
            loginServiceCall();
          }
        } catch (e) {}
        //return user;

      } catch (e) {
        print("eroor+++++++e+" + e.toString());
        crashlytics_bloc.recordCrashlyticsError(e, "LoginPage", context);
        if (e.code == 'account-exists-with-different-credential') {
        } else if (e.code == 'invalid-credential') {}
      }
    }

    //}
    /*   try {
      print("log______1_"+type);
      _email = user.email;
      signinType = "google";
      print("log______1_"+type);
      if (type == "Signup") {
        String firstName = "";
        String lastName = "";
        if (user.displayName != null) {
          List<String> data = user.displayName.split(" ");
          firstName = data[0];
          lastName = data[1];
        }
        String image = user.photoURL;
        if (image == null || image == "null") {
          image = "";
        }

        onTapContinueButton("google", firstName, lastName, _email, image, true);
      } else {
        loginServiceCall();
      }
    } catch (e) {}*/
  }

  void _closeModal(void value) {
    setState(() {
      showSignupButton = true;
      isOpenSignup = !isOpenSignup;
      isOpenLogin = !isOpenLogin;
    });
  }

//onTapContinueButton(bool isRedirectToRecommendation, String pageName) {
  onTapContinueButton(
      signupType, firstName, lastName, email, image, bool isValid) async {
    //false, "Login"

    print('email+++'+email);
    if (selectedRole == "1") {


      String result = await Navigator.of(context).push(MaterialPageRoute(
          builder: (BuildContext context) => SignupStudentPageNew(
              isRedirectToRecommendationLocal, pageNameLocal, signupType,
              firstName: firstName,
              lastName: lastName,
              email: email,
              image: image,
              loginRole: LoginRole.student,
              isValid: isValid)));

      if (result != null && result == 'SignIn') {
        getLoginAfterBack();
      } else if (result == 'notYou') {
        _googleSignIn.signOut();
        signInWithGoogle(context, "Signup");
      }
    } else if (selectedRole == "2") {


      String result = await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (BuildContext context) => SignupStudentPageNew(
            isRedirectToRecommendationLocal,
            pageNameLocal,
            signupType,
            firstName: firstName,
            lastName: lastName,
            email: email,
            image: image,
            isValid: isValid,
            loginRole: LoginRole.parent,
          ),
        ),
      );

      if (result != null && result == 'SignIn') {
        getLoginAfterBack();
      } else if (result == 'notYou') {
        _googleSignIn.signOut();

        signInWithGoogle(context, "Signup");
      }
    } else {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => LetsStartView(
            role: LoginRole.partner,
            email: email,
            firstName: firstName,
            lastName: lastName,
            isRecommendation: isRedirectToRecommendationLocal,
            isValid: isValid,
            pageName: pageNameLocal,
            profile: image,
            signupType: signinType,
          ),
        ),
      );

    }
  }

  void getLoginAfterBack() {
    Navigator.of(context).pop();
    setState(() {
      emailTxtController.text = '';
      isOpenSignup = false;
      isOpenLogin = true;
      showSignupButton = false;
    });
  }
}
