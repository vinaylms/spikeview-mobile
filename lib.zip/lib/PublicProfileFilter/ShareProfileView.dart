import 'dart:async';

import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ShareProfileView extends StatefulWidget {
  String link;
  String firstName, pageName;
  bool isParentCalling;

  ShareProfileView(
      this.link, this.firstName, this.pageName, this.isParentCalling);

  @override
  _ShareProfileViewState createState() => _ShareProfileViewState();
}

class _ShareProfileViewState extends State<ShareProfileView> {
  bool isLinkCopied = false;
  static ConfettiController _controllerConfetti = ConfettiController(
    duration: Duration(seconds: 2),
  );

  @override
  void initState() {
    Timer(Duration(seconds: 2), () {
      print("Yeah, this line is printed after 3 seconds");
      _controllerConfetti.play();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return customAppbar(
      context,
      GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(20,25, 20, 12),
                child: BaseText(
                  text: 'Share Profile',
                  textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w700,
                  fontSize: 28,
                  textAlign: TextAlign.start,
                  maxLines: 3,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20.0, 12, 20, 12),
                child: Container(
                  width: double.infinity,
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        width: double.maxFinite,
                        height: 170.0,
                        child: Stack(
                          children: [
                            Positioned.fill(child:
                            Align(
                              alignment: Alignment.centerRight,
                              child: ConfettiWidget(
                                confettiController:
                                _controllerConfetti,
                                // radial value - LEFT
                                canvas: Size(
                                    MediaQuery.of(context).size.width,
                                    200),
                                particleDrag: 0.05,
                                // apply drag to the confetti
                                emissionFrequency: 0.05,
                                // how often it should emit
                                numberOfParticles: 20,
                                // number of particles to emit
                                gravity: 0.05,
                                // gravity - or fall speed
                                shouldLoop: false,
                                minimumSize: Size(4, 4),
                                maximumSize: Size(16, 6),
                                colors:  [
                                  ColorValues.confetti1,
                                  ColorValues.confetti2,
                                  ColorValues.confetti3,
                                  ColorValues.confetti4,
                                  ColorValues.confetti5,
                                  ColorValues.confetti6,
                                  ColorValues.confetti7,
                                ], // manually specify the colors to be used
                              ),
                            ),),

                            Positioned(
                              bottom: 0,
                              left: 0,
                              right:0 ,
                              child: Center(
                                child: Image.asset(
                                  "assets/newDesignIcon/share/right_icon.png",
                                  height: 120.0,
                                  width: 120.0,
                                ),
                              ),
                            ),
                         /*   Positioned.fill(
                              child: Align(
                                alignment: Alignment.center,
                                child: ConfettiWidget(
                                  confettiController: _controllerConfetti,
                                  // radial value - LEFT
                                  canvas: Size(
                                      MediaQuery.of(context).size.width, 200),
                                  particleDrag: 0.05,
                                  // apply drag to the confetti
                                  emissionFrequency: 0.05,
                                  // how often it should emit
                                  numberOfParticles: 20,
                                  // number of particles to emit
                                  gravity: 0.05,

                                  // gravity - or fall speed
                                  shouldLoop: false,
                                  //minimumSize: Size(4, 4),
                                 // maximumSize: Size(16, 6),
                                  colors: [
                                    ColorValues.confetti1,
                                    ColorValues.confetti2,
                                    ColorValues.confetti3,
                                    ColorValues.confetti4,
                                    ColorValues.confetti5,
                                    ColorValues.confetti6,
                                    ColorValues.confetti7,
                                  ], // manually specify the colors to be used
                                ),
                              ),
                            ),*/
                          ],
                        ),
                      ),
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          32.0,
                          0.0,
                          24.0,
                          BaseText(
                            text: widget.pageName == "custom"
                                ? "Your Profile is ready to share."
                                : "Congratulation your profile is now publicly visible.",
                            textColor: AppConstants.colorStyle.darkBlue,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                            textAlign: TextAlign.center,
                            maxLines: 3,
                          )),
                      Row(
                        children: [
                          Expanded(
                            flex: 77,
                            child: Container(
                              height: 34,
                              padding: EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                border: Border.all(
                                    color: ColorValues
                                        .SEARCH_CATEGORY_BOX_BG_SELCTED,
                                    width: 1.0),
                                borderRadius: new BorderRadius.only(
                                    topLeft: const Radius.circular(8.0),
                                    bottomLeft: const Radius.circular(8.0)),
                              ),
                              child: BaseText(
                                text: widget.link,
                                textColor:
                                AppConstants.colorStyle.lightBlue,
                                fontFamily:
                                AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                textAlign: TextAlign.start,
                                maxLines: 2,
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 23,
                            child: InkWell(
                              child: Container(
                                height: 34,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      color:ColorValues
                                          .SEARCH_CATEGORY_BOX_BG_SELCTED,
                                      width: 1.0),
                                  color:ColorValues
                                      .SEARCH_CATEGORY_BOX_BG_SELCTED,
                                  borderRadius: new BorderRadius.only(
                                      topRight: const Radius.circular(8.0),
                                      bottomRight:
                                      const Radius.circular(8.0)),
                                ),
                                alignment: Alignment.center,
                                child: BaseText(
                                  text:isLinkCopied?'Copied': 'Copy link',
                                  textColor: AppConstants.colorStyle.white,
                                  fontFamily: AppConstants
                                      .stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                  textAlign: TextAlign.center,
                                  maxLines: 1,
                                ),
                              ),
                              onTap: () {
                                Util.copyToClipboardTextWithoutToast(
                                    widget.link, context);
                                setState(() {
                                  isLinkCopied = true;
                                });
                              },
                            ),
                          )
                        ],
                      ),
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          12.0,
                          0.0,
                          48.0,
                          BaseText(
                            text:
                                'Please copy the link and email, text or share your profile via other apps on your phone.',
                            textColor: AppConstants.colorStyle.lightPurple,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                            textAlign: TextAlign.center,
                          )),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 0, vertical: 0),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 1,
                              child: InkWell(
                                child: Container(
                                  padding: EdgeInsets.symmetric(vertical: 10),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: ColorValues.WHITE,
                                    border: Border.all(
                                        color: ColorValues
                                            .SEARCH_CATEGORY_BOX_BG_SELCTED,
                                        width: 1.0),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: BaseText(
                                    text: 'Download profile',
                                    textColor:
                                        AppConstants.colorStyle.lightBlue,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12,
                                    textAlign: TextAlign.center,
                                    maxLines: 1,
                                  ),
                                ),
                                onTap: () async {
                                  Util.launchUrl(
                                      "Url",
                                      /*widget.link.replaceAll("https://app.spikeview.com",
                                      "http://103.187.101.54:8001")+"/true"*/
                                      widget.link + "/true");
                                },
                              ),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              flex: 1,
                              child: Stack(
                                children: [
                                  InkWell(
                                    child: Container(
                                        padding:
                                            EdgeInsets.symmetric(vertical: 10),
                                        decoration: BoxDecoration(
                                          color:
                                              AppConstants.colorStyle.lightBlue,
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        alignment: Alignment.center,
                                        child: BaseText(
                                          text: 'Share',
                                          textColor:
                                              AppConstants.colorStyle.white,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 12,
                                          textAlign: TextAlign.center,
                                          maxLines: 1,
                                        )),
                                    onTap: () {
                                      callShareProfile();
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )),
      () {
        _showBackDialog();
      },
      isShowIcon: false,
      isShowExplanation: false,
    );
  }

  void _showBackDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 50),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(height: 15),
                    BaseText(
                      text: 'Go to profile',
                      maxLines: 1,
                      textAlign: TextAlign.center,
                      textColor: const Color(0xff27275A),
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                    const SizedBox(height: 7),
                    BaseText(
                      text: "Are you sure you want to stop profile sharing and go to profile?",
                      textAlign: TextAlign.center,
                      textColor: const Color(0xff666B9A),
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                    ),
                    const SizedBox(height: 15),
                    const Divider(
                      color: Color(0xffE5EBF0),
                      thickness: 1,
                      height: 0,
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.of(context).popUntil((route) => route.isFirst);
                      },
                      child: Container(
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(13),
                        child: BaseText(
                          text: 'Yes',
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          textColor: const Color(0xff4684EB),
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              InkWell(
                onTap: () => Navigator.pop(context),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.all(13),
                  child: BaseText(
                    text: 'Cancel',
                    maxLines: 1,
                    textAlign: TextAlign.center,
                    textColor: const Color(0xff27275A),
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void callShareProfile() {
    String preLinkText = 'Hi,' +
        "\n\n" +
        'I am sharing my spikeview with you. Please take a look and let\'s connect.';
    String postLinkText = widget.firstName;
    String sharedText =
        '$preLinkText \n\n' + widget.link + ' \n\n$postLinkText';
    Util.shareViaOtherApp(context, sharedText, 'My spikeview Shared With You');
  }
}
