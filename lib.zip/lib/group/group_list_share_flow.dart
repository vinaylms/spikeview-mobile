import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/home/AddPost.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
class GroupListShareFlow extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  String link;
  GroupListShareFlow(this.profileInfoModal,this.link);
  @override
  State<StatefulWidget> createState() => GroupListShareFlowState();
}

class GroupListShareFlowState extends State<GroupListShareFlow> with BaseCommonWidget {
  List<GroupModel> groups = [];
  String userIdPref, token;
  SharedPreferences prefs;
  int selectedIndex = -1;
  GroupListModel groupListModel;

  String roleId;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    fetchGroupList();
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  Future<void> fetchGroupList() async {
    CustomProgressLoader.showLoader(context);
    groups = await API.fetchGroupListForExternalShare(userIdPref, token, roleId);
    CustomProgressLoader.cancelLoader(context);

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    onBack(){
      if (roleId == "1") {
        // For Studenet
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidget(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: Constant.GROUP_TYPE)));
      } else if (roleId == "2") {
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidgetParent(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: Constant.GROUP_TYPE)));

        // For Parent
      } else if (roleId == "4") {
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: Constant.GROUP_TYPE)));

        // For Partner
      }
    }


    return  WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:  customAppbar(
        context,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 20.0, right: 20, top: 24, bottom: 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    BaseText(
                      text: 'Existing groups',
                      textColor:
                      ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily:
                      AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      textAlign: TextAlign.start,
                      maxLines: 3,
                    ),
                    SizedBox(
                      height: 5,
                    ),
                   BaseText(
                      text:MessageConstant.ABOUT_GROUP_SELECT_GROUP_INTERACT,
                      textColor:
                      AppConstants.colorStyle.lightPurple,
                      fontFamily: AppConstants
                          .stringConstant.latoMedium,
                      fontWeight: FontWeight.w600,
                      textAlign: TextAlign.start,
                      fontSize: 16,
                      maxLines: 2,
                    )

                  ],
                ),
              ),
              flex: 0,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      groups.length==0?   Padding(
                        padding: const EdgeInsets.only(left:13.0,right: 13,top: 40),
                        child: Container(
                          width: double.infinity,

                          child: Column(
                            children: <Widget>[
                              Padding(
                                  padding: const EdgeInsets.fromLTRB(30, 20, 30, 7),
                                  child: Image.asset(
                                    "assets/no_group.png",
                                    height: 150.0,
                                    width: 300.0,
                                  )),

                              Padding(
                                padding: const EdgeInsets.fromLTRB(13, 0, 13, 2),
                                child: Text(
                                  MessageConstant.ABOUT_GROUP_ITS_LOOKs,
                                  style: AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,14.0,FontType.Regular ),/*TextStyle(
                            color: ColorValues.GREY_TEXT_COLOR,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                            fontSize: 14),*/
                                  textAlign: TextAlign.center,
                                ),
                              ),

                            ],
                          ),
                        ),
                      ):Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [

                          ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: groups.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.only(top:10.0,left: 20,right: 20,bottom: 10),
                                child: InkWell(
                                  child: itemWidget(index),
                                  onTap: () {

                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                AddPost(widget.profileInfoModal,  groups[index].groupId,link: widget.link,)));
                                  },
                                ),
                              );
                            },
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
              flex: 1,
            ),

          ],
        ), () {
          onBack();
    }, isShowIcon: false,isShowExplanation: false));
    // TODO: implement build
    return  WillPopScope(
        onWillPop: () {
        onBack();
        },
        child: SafeArea(
      child: Scaffold(
        appBar:  AppBar(
          elevation: 0.0,
          backgroundColor: Colors.white,
          centerTitle: true,
          title: Text('Existing Groups',
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.primaryTextColor, 18, FontType.Regular)),
          leading: Padding(
            padding: const EdgeInsets.fromLTRB(0.0, 0.0, 25.0, 0.0),
            child: IconButton(
                icon: Image.asset(
                  ImagePath.ICON_BACK,
                  color: Palette.primaryTextColor,
                  height: 20,
                  width: 10,
                ),
                onPressed: () {
                  onBack();
                }),
          ),

        ),
        body: ListView(
          // physics: NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          children: <Widget>[
            CustomViews.getSepratorLine(),
            groups.length==0?   Padding(
              padding: const EdgeInsets.all(13.0),
              child: Container(
                width: double.infinity,

                child: Column(
                  children: <Widget>[
                    Padding(
                        padding: const EdgeInsets.fromLTRB(30, 20, 30, 7),
                        child: Image.asset(
                          "assets/no_group.png",
                          height: 150.0,
                          width: 300.0,
                        )),

                    Padding(
                      padding: const EdgeInsets.fromLTRB(13, 0, 13, 2),
                      child: Text(
                      MessageConstant.ABOUT_GROUP_ITS_LOOKs,
                        style: AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,14.0,FontType.Regular ),/*TextStyle(
                            color: ColorValues.GREY_TEXT_COLOR,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                            fontSize: 14),*/
                        textAlign: TextAlign.center,
                      ),
                    ),

                  ],
                ),
              ),
            ):new Container(height: 0.0,),
            groups.length > 0?     Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  color: Palette.webColor,
                  padding: EdgeInsets.all(UIHelper.screenPadding),
                  child: Text(
                    groups.length > 0
                        ? MessageConstant.ABOUT_GROUP_SELECT_GROUP_INTERACT
                        : '',
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.primaryTextColor, 14, FontType.Regular),
                  ),
                ),
                UIHelper.verticalGapBetweenBox,
                ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: groups.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: InkWell(
                        child: itemWidget(index),
                        onTap: () {

                          Navigator.of(context).push(
                               MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                   AddPost(widget.profileInfoModal,  groups[index].groupId,link: widget.link,)));
                        },
                      ),
                    );
                  },
                )
              ],
            ):new Container(height: 0.0,),
          ],
        ),
      ),
    ));
  }

  itemWidget(int index) {
    GroupModel model = groups[index];
    return Container(
      margin: EdgeInsets.only(bottom: 0),
      padding: EdgeInsets.only(left: 13, top: 13, bottom: 13, right: 13),
      decoration: groups[index].isSelected
          ? rectangleDecorationWithDynamicColor2(
               ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP)
          : rectangleDecorationWithDynamicColor2(Colors.white),
      child: Row(
        children: <Widget>[
          ClipOval(
            child: FadeInImage(
              fit: BoxFit.cover,
              width: 48,
              height: 48,
              placeholder: AssetImage(
                'assets/newDesignIcon/group/default_circle_bg.png',
              ),
              image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                  ParseJson.getSmallImage(model.groupImage)),
            ),
          ),
          UIHelper.horizontalGapBetweenBox,
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  model.groupName,
                  style: TextStyle(
                    fontStyle: FontStyle.normal,
                    color: AppConstants.colorStyle.darkBlue,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                  ),
                ),
                UIHelper.verticalSpaceExtraSmall,

                Row(
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                      0.0,
                      3.0,
                      0.0,
                      0.0,
                      Image.asset(
                        model.type == "private"
                            ? "assets/png/private_group.png"
                            : "assets/png/public_group.png",
                        height: 15.0,
                        width: 15.0,
                      ),
                    ),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        0.0,
                        BaseText(
                          text:  model.type ==
                              MessageConstant.ABOUT_GROUP_PRIVATE
                              ? MessageConstant.ABOUT_GROUP_PRIVATE_GROUP
                              : MessageConstant.ABOUT_GROUP_PUBLIC_GROUP,
                          textColor: ColorValues.labelColor,
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w400,
                          fontSize: 14,
                          textAlign: TextAlign.start,
                          maxLines: 3,
                        ))
                  ],
                ),


              ],
            ),
          )
        ],
      ),
    );
  }
}
