import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';

import 'package:spike_view_project/common/Connectivity.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';

class NotificationSetting extends StatefulWidget {
  NotificationSetting();

  @override
  NotificationSettingState createState() => NotificationSettingState();
}

class NotificationSettingState extends State<NotificationSetting> {
  String isPerformChanges = "pop", userIdPref, roleId, dob = "0", isHide = "";
  int diffrenceInDob;
  SharedPreferences prefs;
  bool isSelectedAllNotification = true;
  bool isSelectedProfile = true;
  bool isSelectedFeed = true;
  bool isLoading = true;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    dob = prefs.getString(UserPreference.DOB);
    isHide = prefs.getString(UserPreference.ISHide);
    fetchPSetting();
    //anaylytics.setCurrentSreen(ScreenNameConstant.notification_activity);
  }

//{groupId: 526, userId: 3577, roleId: 4, status: Accepted}
  Future fetchPSetting() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {});
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_GET_NOTIFICATION_SETTING +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");
        print("response data" + response.toString());
        isLoading = false;
        setState(() {});
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              isSelectedFeed = response.data["data"][0]['feedNotification'];
              isSelectedProfile =
                  response.data["data"][0]['profileNotification'];
              isSelectedAllNotification =
                  response.data["data"][0]['allNotification'];
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {});
      e.toString();
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  Future apiCallingForUpdateNotificationSetting(type, value) async {
    try {
      Response response;

      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "field": type,
        "value": value,
      };
      print("map:-" + map.toString());

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_NOTIFICATION_SETTING_UPDATY, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          // String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            if (type == "feedNotification") {
              isSelectedFeed = value;
            } else if (type == "profileNotification") {
              isSelectedProfile = value;
            } else if (type == "allNotification") {
              isSelectedAllNotification = value;
            }

            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    /*return customAppbar(
      context,
      Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 20.0, right: 20, top: 20, bottom: 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    BaseText(
                      text: 'Notification settings',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      textAlign: TextAlign.start,
                      maxLines: 3,
                    ),
                  ],
                ),
              ),
              flex: 0,
            ),
            Expanded(
              child: isLoading
                  ? const SizedBox.shrink()
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                      shrinkWrap: true,
                      children: <Widget>[

                        _button(
                          title: "Allow all notifications on spikeview",
                          desc:
                              "Enables you to receive notification from spikeview.",
                          isOn: isSelectedAllNotification,
                          onChange: () {
                            apiCallingForUpdateNotificationSetting(
                                "allNotification", !isSelectedAllNotification);
                          },
                        ),
                        const SizedBox(height: 15),
                        _button(
                          title: "Allow profile notifications",
                          desc:
                              "Enables you to receive notifications regarding your profile",
                          isOn: isSelectedProfile,
                          onChange: () {
                            apiCallingForUpdateNotificationSetting(
                                "profileNotification", !isSelectedProfile);
                          },
                        ),
                        const SizedBox(height: 15),
                        _button(
                          title: "Allow feed notifications",
                          desc:
                              "Enables you to receive notification on feed activity",
                          isOn: isSelectedFeed,
                          onChange: () {
                            apiCallingForUpdateNotificationSetting(
                                "feedNotification", !isSelectedFeed);
                          },
                        ),
                        const SizedBox(height: 15),
                      ],
                    ),
              flex: 1,
            ),
          ],
        ),
      ),
      () {
        Navigator.pop(context, isPerformChanges);
      },
      isShowIcon: false,
    );*/

    return WillPopScope(
      onWillPop: () {
        Navigator.pop(context, isPerformChanges);
        return Future.value(false);
      },
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/new_onboarding/background_screen.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 50, 20, 22),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    InkWell(
                      child: Image.asset(
                        "assets/new_onboarding/back_blue_icon.png",
                        height: 32.0,
                        width: 32.0,
                        fit: BoxFit.fill,
                      ),
                      onTap: () => Navigator.pop(context, isPerformChanges),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(35),
                    ),
                  ),
                  child: isLoading
                      ? const SizedBox.shrink()
                      : ListView(
                          padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                          shrinkWrap: true,
                          children: <Widget>[
                            BaseText(
                              text: "Notification settings",
                              fontSize: 28,
                              fontWeight: FontWeight.w700,
                              fontFamily: Constant.latoRegular,
                              textColor: const Color(0xff27275A),
                            ),
                            const SizedBox(height: 24),
                            _button(
                              title: "Allow all notifications on spikeview",
                              desc:
                                  "Enables you to receive notification from spikeview.",
                              isOn: isSelectedAllNotification,
                              onChange: () {
                                apiCallingForUpdateNotificationSetting(
                                    "allNotification",
                                    !isSelectedAllNotification);
                              },
                            ),
                            const SizedBox(height: 15),
                            _button(
                              title: "Allow profile notifications",
                              desc:
                                  "Enables you to receive notifications regarding your profile",
                              isOn: isSelectedProfile,
                              onChange: () {
                                apiCallingForUpdateNotificationSetting(
                                    "profileNotification", !isSelectedProfile);
                              },
                            ),
                            const SizedBox(height: 15),
                            _button(
                              title: "Allow feed notifications",
                              desc:
                                  "Enables you to receive notification on feed activity",
                              isOn: isSelectedFeed,
                              onChange: () {
                                apiCallingForUpdateNotificationSetting(
                                    "feedNotification", !isSelectedFeed);
                              },
                            ),
                            const SizedBox(height: 15),
                          ],
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _button({
    @required String title,
    @required String desc,
    @required bool isOn,
    @required VoidCallback onChange,
  }) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      decoration: BoxDecoration(
        color: const Color(0xffF5F6FA),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 80,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BaseText(
                  textColor: const Color(0xff3D4361),
                  text: title,
                  fontFamily: Constant.latoRegular,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
                const SizedBox(height: 2),
                BaseText(
                  textColor: const Color(0xff7E8BAF),
                  text: desc,
                  fontFamily: Constant.latoRegular,
                  fontWeight: FontWeight.w400,
                  fontSize: 12,
                ),
              ],
            ),
          ),
          Expanded(
            flex: 20,
            child: Align(
              alignment: Alignment.centerRight,
              child: GestureDetector(
                onTap: onChange,
                onHorizontalDragEnd: (details) => onChange(),
                child: Image.asset(
                  isOn
                      ? "assets/newDesignIcon/active_new.png"
                      : "assets/newDesignIcon/inactive_new.png",
                  width: 30,
                  height: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
