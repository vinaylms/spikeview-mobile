import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/component/app_constants.dart';

class ListItem<T> extends StatelessWidget {
  final String title;
  final T value;
  final VoidCallback onTap;

  const ListItem(
    this.title, {
    this.value,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap ?? () {},
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Text(title ?? ''),
        ),
      ),
    );
  }
}

class CustomDropdown<T> extends StatefulWidget {
  final List<ListItem<T>> listItems;
  final T value;
  final ValueChanged onChange;
  final Function(int selectedndex) onSelected;
  final Widget icon;
  final String hint;

  const CustomDropdown({
    Key key,
    @required this.listItems,
    this.value,
    this.onChange,
    this.icon,
    this.hint,
    this.onSelected,
  }) : super(key: key);

  @override
  State createState() => _CustomDropdownState<T>();
}

class _CustomDropdownState<T> extends State<CustomDropdown> {
  ListItem _selected;
  final GlobalKey _key = GlobalKey();
  final FocusNode _focusNode = FocusNode();
  final LayerLink _layerLink = LayerLink();
  bool _isOverlayShown = false;
  bool _isFocused = false;
  OverlayEntry _overlay;
  FocusScopeNode _focusScopeNode;

  @override
  void initState() {
    super.initState();
    log('------- initState call');
    try {
      if (widget.value != null) {
        _selected = widget.listItems
            .firstWhere((listItem) => listItem.value == widget.value);
      } else {
        _selected = null;
      }
    } catch (e) {
      _selected = null;
      //log('------- initState ${e.toString()}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: GestureDetector(
        onTap: _onTap,
        child: FocusableActionDetector(
          focusNode: _focusNode,
          mouseCursor: SystemMouseCursors.click,
          actions: {
            ActivateIntent: CallbackAction<Intent>(onInvoke: (_) => _onTap()),
          },
          onShowFocusHighlight: (isFocused) =>
              setState(() => _isFocused = isFocused),
          //onShowHoverHighlight: (isHovered) => setState(() => _isHovered = isHovered),
          child: Container(
            key: _key,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _selected != null
                          ? _selected.title
                          : widget.hint != null
                              ? widget.hint
                              : 'Select',
                      style: _selected != null
                          ? TextStyle(
                              color: Color(0xff27275A),
                              fontWeight: FontWeight.w500,
                              fontSize: 18,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                            )
                          : TextStyle(
                              color: Color(0xff666B9A),
                              fontWeight: FontWeight.w500,
                              fontSize: 18,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                            ),
                    ),
                    const Spacer(),
                    widget.icon ??
                        Image.asset(
                          'assets/recommendation/ic_arrow_down.png',
                          height: 24,
                          width: 24,
                        ),
                  ],
                ),
                const SizedBox(height: 10),
                Divider(
                  height: 0,
                  thickness: 1,
                  color: Color(0x99E5EBF0),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
     _focusNode?.unfocus();
     _focusScopeNode?.unfocus();
    super.dispose();
  }

  OverlayEntry _createOverlay() {
    _focusScopeNode = FocusScopeNode();
    return OverlayEntry(
      builder: (context) => GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: _removeOverlay,
        child: Stack(
          children: [
            CompositedTransformFollower(
              link: _layerLink,
              showWhenUnlinked: false,
              child: Material(
                color: Colors.transparent,
                child: FocusScope(
                  node: _focusScopeNode,
                  child: _createListItems(),
                  onKey: (node, event) {
                    if (event.logicalKey == LogicalKeyboardKey.escape) {
                      _removeOverlay();
                    }
                    return false;
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _removeOverlay() {
    _overlay?.remove();
    _isOverlayShown = false;
    _focusScopeNode?.dispose();
    FocusScope.of(context).nextFocus();
  }

  Widget _createListItems() {
    RenderBox renderBox = _key.currentContext?.findRenderObject() as RenderBox;
    return Container(
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Color(0xffE5EBF0),
              blurRadius: 10,
              spreadRadius: 5,
            )
          ],
        ),
        width: renderBox.size.width,
        constraints: BoxConstraints(
          minHeight: 50,
         // maxHeight: double.parse('${(40 * widget.listItems.length)}'),
          maxHeight: 150,
        ),
        child: ListView.separated(
          itemBuilder: (_, index) {
            final listItem = widget.listItems[index];
            return InkWell(
              onTap: () {
                _onListItemTap(listItem);
                widget.onSelected(index);
              },
              child: Container(
                padding: const EdgeInsets.fromLTRB(11, 7, 8, 11),
                decoration: BoxDecoration(
                    color: Color(0xffF3F5FF),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Color(0xffE5EBF0))),
                child: Text(
                  listItem.title,
                  style: TextStyle(
                    color: Color(0xff27275A),
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                  ),
                ),
              ),
            );
          },
          separatorBuilder: (_, index) => const SizedBox(height: 9),
          itemCount: widget.listItems?.length ?? 0,
          padding: const EdgeInsets.symmetric(horizontal: 9),
          shrinkWrap: true,
        ));
  }

  void _onTap() {
    if (widget.listItems.isNotEmpty) {
      if (_isOverlayShown) {
        _removeOverlay();
      } else {
        _overlay = _createOverlay();
        Overlay.of(context)?.insert(_overlay);
        _isOverlayShown = true;
        FocusScope.of(context).setFirstFocus(_focusScopeNode);
      }
    }
  }

  void _onListItemTap(ListItem<T> listItem) {
    _removeOverlay();
    setState(() {
      _selected = listItem;
    });
    //widget?.onChange?.call(listItem.value);
  }

  // @override
  // void didUpdateWidget(covariant CustomDropdown oldWidget) {
  //   if(widget.value != oldWidget.value){
  //     initState();
  //   }
  //   super.didUpdateWidget(oldWidget);
  // }
}
