import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/accomplishment/VideoViewBlack.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestRepliedParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';

class OpportunityViewWidget extends StatefulWidget {
  OpportunityModelForFeed opportunity;
  String feedId, userIdPref, roleId, pageName;
  int diffrenceInDob;

  OpportunityViewWidget(this.opportunity, this.feedId, this.userIdPref,
      this.roleId, this.diffrenceInDob, this.pageName);

  @override
  State<StatefulWidget> createState() =>
      OpportunityViewWidgetState(opportunity, diffrenceInDob);
}

class OpportunityViewWidgetState extends State<OpportunityViewWidget>
    with BaseCommonWidget {
  bool isActivate = true;
  OpportunityModelForFeed opportunity;
  SharedPreferences prefs;
  List<Assest> mediaDocumentList =  List();
  List<Assest> googleLinkList =  List();
  String userIdPref;
  String location = "";

  String firstHalf = '';
  String secondHalf = '';
  bool flag = true;

  String firstHalfDesc = '';
  String secondHalfDesc = '';
  bool flagDesc = true;

  String descVal = '';

  String categoryString = '';

  String subjectString = '';

  OpportunityViewWidgetState(this.opportunity, this.diffrenceInDob);
  bool isGroup_AccessControl = true;
  int diffrenceInDob;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    String dob = prefs.getString(UserPreference.DOB);
    try {
      isGroup_AccessControl =
          prefs.getString(UserPreference.ACCESS_CONTROL_GROUP)
              .toLowerCase() ==
              "true";

    }catch(e){
      isGroup_AccessControl = true;
    }
    setState(() { });
  }

  Future apiCallingForIncreaseCount() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_INCREASE_NUMBER_OF_COUNT +
                widget.feedId +
                "&roleId=" +
                widget.roleId,
            "get");

        print("apiCallingForIncreaseCount data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    if (opportunity.qualificationModelParam != null)
      print(
          'APurva Qualification::: ${opportunity.qualificationModelParam.length}');
    mediaDocumentList.addAll(opportunity.docList);

    googleLinkList.addAll(opportunity.googleLinkList);
    for (Address adress in opportunity.locationList) {
      if (location == "") {
        location = location + " " + adress.street1;
      } else {
        location = location + " | " + adress.street1;
      }
    }

    if (opportunity.bio != null) {
      if (opportunity.bio.length > 150) {
        firstHalf = opportunity.bio.substring(0, 150);
        secondHalf = opportunity.bio.substring(150, opportunity.bio.length);
      } else {
        firstHalf = opportunity.bio;
        secondHalf = "";
      }
    }

    descVal = '';
    if (opportunity.offerId == "1" ||
        opportunity.offerId == "2" ||
        opportunity.offerId == "3") {
      descVal = opportunity.project;
    } else if (opportunity.offerId == "4" || opportunity.offerId == "5") {
      descVal = opportunity.serviceDesc;
    } else {
      descVal = opportunity.description;
    }

    if (descVal != null) {
      if (descVal.length > 150) {
        firstHalfDesc = descVal.substring(0, 150);
        secondHalfDesc = descVal.substring(150, descVal.length);
      } else {
        firstHalfDesc = descVal;
        secondHalfDesc = "";
      }
    }

    getData();

    getSharedPreferences();
    super.initState();
  }

  void groupInvitationAccepted() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Center(
                                              child:  Container(
                                                  child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text: opportunity
                                                          .groupIsPublic
                                                      ? ' Awesome! You have successfully joined this group '
                                                      : ' Awesome! You have successfully sent request for this group ',
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                              )),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Close",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallJoin(groupId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(widget.userIdPref),
          "roleId": int.parse(widget.roleId)
        };
        print("map++++" + map.toString());
        response = await  ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_JOIN_GROUP, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForForwardParent(groupId, opportunityModelForFeed) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "parentId": int.parse(widget.userIdPref),
          "userId": int.parse(opportunityModelForFeed.studentJoinId)
        };

        print("joinMap++++" + map.toString());

        response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_JOIN_GROUP_FORWARD, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    void feedForwardConformation() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Center(
                                                child:  Container(
                                                    child: RichText(
                                                  maxLines: 5,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text:
                                                        ' Your post has been forwarded to your parent. Please follow up with them ',
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                )),
                                              ),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "OK",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    Future apiCallForForwardFeed(id) async {
      try {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          Map map = {
            "opportunityId": int.parse(id),
            "userId": int.parse(widget.userIdPref)
          };
          print("map+++" + map.toString());
          Response response = await  ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_FEED_FORWARD, map);

          print("response:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                if (msg.contains("Opportunity already forwarded to parent")) {
                  ToastWrap.showToast(msg, context);
                } else {
                  feedForwardConformation();
                }
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      } catch (e) {
        e.toString();
      }
    }

    Widget _loader(BuildContext context) => Center(
            child: Container(
          child:  Image.asset(
            "assets/aerial/feed_default_img.png",
            fit: BoxFit.cover,
          ),
        ));

    Widget _error() {
      return Center(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.fill,
        ),
      );
    }

    void forwardToParentConformAtionDialog(id) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(20.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to forward this feed to your parent?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "No",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Yes",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCallForForwardFeed(id);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void infoDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        Container(
                                          height: 145.0,
                                          padding: const EdgeInsets.all(8.0),
                                          width: double.infinity,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(10),
                                            color: Colors.white,
                                          ),
                                          child: ListView(children: <Widget>[
                                            SizedBox(height: 7,),
                                            Image.asset(
                                              'assets/profile/parent/info.png',
                                              height: 25.0,
                                              width: 25.0,
                                            ),
                                             Container(
                                                padding:
                                                    const EdgeInsets.only(top:5.0),
                                                child:  BaseText(
                                                  text: 'Forward to parent',
                                                  textAlign: TextAlign.center,
                                                  textColor: const Color(0xff27275A),
                                                  fontSize: 14,
                                                  fontFamily: Constant.latoRegular,
                                                  fontWeight: FontWeight.w700,
                                                )),

                                            BaseText(
                                              text:  'Great that you are interested on this opportunity. Because you are under 13, please follow up your parent/guardian to help with next steps. They will see the details in their feed.',

                                              textAlign: TextAlign.center,
                                              textColor: const Color(0xff27275A),
                                              fontSize: 14,
                                              fontFamily: Constant.latoRegular,
                                              fontWeight: FontWeight.w500,
                                            )


                                          ]),
                                        ),
                                      ),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                       decoration: BoxDecoration(
                                         borderRadius: BorderRadius.circular(10),
                                         color: Colors.white,
                                       ),
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  BaseText(
                                                    text:  "Close",
                                                    textAlign: TextAlign.center,
                                                    textColor: Color(0xff27275A),
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily: Constant.latoRegular,
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }


    final docListUiData =  Container(
        padding: const EdgeInsets.fromLTRB(0.0, 18.0, 0.0, 0.0),
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 0.9,
          scrollDirection: Axis.vertical,
          crossAxisCount: 4,
          children: opportunity.docList.map((file) {
            var fileName;
            String docName = "";
            if (file.file != null) {
              fileName = file.file.split("/");
              if (fileName != null && fileName.length > 0) {
                docName = fileName[fileName.length - 1];
              }
            }
            print('Apurva docListUiData docName:: $docName, file:: $file');

            return Column(
              children: <Widget>[
                Container(
                    height: 60.0,
                    width: 64.0,
                    child:  Stack(
                      children: <Widget>[
                        InkWell(
                          onTap: () {
                            print("DOC++++" + Constant.IMAGE_PATH + file.file);
                            launch(Constant.IMAGE_PATH +
                                (file.file).replaceAll("pdf'", 'pdf'));
                          },
                          child:  Container(
                              height: 54.0,
                              width: 62.0,
                              child:  Image.asset(
                                "assets/resume/ic_doc_pdf.png",
                                height: 54.0,
                                width: 62.0,
                              )),
                        ),
                      ],
                    )),
                Expanded(
                  child: Container(
                    height: 14.0,
                    child: Padding(
                      padding:  EdgeInsets.only(top: 3.0),
                      child: docNameLabelText('${docName}'),
                    ),
                  ),
                ),
              ],
            );
          }).toList(),
        ));

    uploadGoogleDocLink() {
      return Column(
        children: <Widget>[
          Column(
            children: List.generate(opportunity.googleLinkList.length, (index) {
              return Row(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                      child:  InkWell(
                        child: Text(
                          opportunity. googleLinkList[
                          index]
                              .label
                              .trim()=="null"?   opportunity.googleLinkList[index]
                              .file
                              .trim():   opportunity.  googleLinkList[
                          index]
                              .label
                              .trim(),
                          style: TextStyle(
                              color: Palette.accentColor, fontSize: 14,fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        ),
                        onTap: () {
                          String url="";
                          if ( opportunity.googleLinkList[index].file
                              .contains("http")) {
                            url = opportunity.googleLinkList[index].file;
                          } else {
                            url = "http://" +  opportunity.googleLinkList[index].file;

                          }
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) =>  WebViewWidget(
                                      url,
                                      "spikeview")));
                        },
                      ),
                    ),
                  ),
                ],
              );
            }),
          )
        ],
      );
    }

    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {
      } else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }

    return   WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:customAppbar(
          context,
          GestureDetector(
              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20.0, 0.0, 24.0, 15.0),
                        child: Container(
                          child:  Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[


                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  15.0,
                                  0.0,
                                  10.0,
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child:  InkWell(
                                          child:   Container(
                                            height: 50.0,
                                            width: 50.0,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(15),
                                              child: FadeInImage(
                                                  fit: BoxFit.cover,
                                                  placeholder: AssetImage(
                                                    "assets/profile/partner_img.png"
                                                    ,
                                                  ),
                                                  image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                                                      ParseJson.getSmallImage(
                                                          opportunity
                                                              .profilePicture))),
                                            ),
                                          ),
                                          onTap: () {
                                            onTapImageTile(opportunity.userId,
                                                opportunity.roleId);
                                          },
                                        ),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        child: PaddingWrap.paddingfromLTRB(
                                            8.0,
                                            0.0,
                                            15.0,
                                            0.0,
                                            Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: <Widget>[
                                                InkWell(
                                                  child:  Container(
                                                      child: RichText(
                                                        maxLines: 2,
                                                        textAlign: TextAlign.start,
                                                        text: TextSpan(
                                                          text: opportunity.companyName,
                                                          style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 15.0,
                                                            fontWeight: FontWeight.bold,
                                                          ),
                                                        ),
                                                      )),
                                                ),
                                              ],
                                            )),
                                        flex: 4,
                                      ),
                                    ],
                                  )),
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  0.0,
                                  //
                                  opportunity.assestVideoAndImage.length > 0
                                      ?  SizedBox(
                                    // Pager view
                                      height: 215.50,
                                      child: PageIndicatorContainer(
                                        pageView:  PageView.builder(
                                          itemCount: opportunity
                                              .assestVideoAndImage.length,
                                          controller:  PageController(),
                                          itemBuilder: (context, index2) {
                                            return  InkWell(
                                              child:  Stack(children: <Widget>[
                                                opportunity
                                                    .assestVideoAndImage[
                                                index2]
                                                    .type ==
                                                    "image"
                                                    ?Container(
                                                    decoration:
                                                    BoxDecoration(
                                                        color:
                                                        Colors.black,
                                                        borderRadius: BorderRadius.circular(10)
                                                    ),
                                                    child:  CachedNetworkImage(
                                                      width: double.infinity,
                                                      height: 215.50,
                                                      imageUrl: Constant
                                                          .IMAGE_PATH +
                                                          opportunity
                                                              .assestVideoAndImage[
                                                          index2]
                                                              .file,
                                                      fit: BoxFit.contain,
                                                      placeholder:
                                                          (context, url) =>
                                                          _loader(context),
                                                      errorWidget: (context,
                                                          url, error) =>
                                                          _error(),
                                                    ))
                                                    :  InkWell(
                                                    child:  Container(
                                                      decoration:
                                                      BoxDecoration(
                                                        color:
                                                        Colors.black,
                                                        borderRadius:
                                                        BorderRadius.circular(10),
                                                      ),
                                                      height: 215.50,
                                                      child:  Center(
                                                          child:

                                                          VideoPlayPause(
                                                              opportunity
                                                                  .assestVideoAndImage[
                                                              index2]
                                                                  .file,
                                                              "",true)

                                                        /*new Container(
                                                            child:  Stack(
                                                              children: <Widget>[

                                                                Container(
                                                                  height: 215.0,
                                                                  color: Colors.black,
                                                                  margin: EdgeInsets.only(left: 0, right: 0),
                                                                  child:  VideoViewBlack(
                                                                      Constant.IMAGE_PATH + opportunity
                                                                          .assestVideoAndImage[
                                                                      index2]
                                                                          .file, "", false, ""),
                                                                ),
                                                                *//*new Container(
                                                                                      height: 54.0,
                                                                                      width: 80.0,
                                                                                      color:  Color(0XFFC0C0C0).withOpacity(.4),
                                                                                    ),*//*
                                                                 Center(
                                                                    child:  Row(
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                      children: <Widget>[
                                                                         InkWell(
                                                                          child: PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                               Image.asset(
                                                                                //'assets/pre_login/video_play_button.png',
                                                                                'assets/newDesignIcon/circle_play.png',
                                                                                width: 50.0,
                                                                                height: 50.0,
                                                                              )),
                                                                        )
                                                                      ],
                                                                    )),
                                                              ],
                                                            )),*/
                                                      ),
                                                    )),
                                                opportunity.assestVideoAndImage
                                                    .length ==
                                                    1 ||
                                                    opportunity
                                                        .assestVideoAndImage[
                                                    index2]
                                                        .type ==
                                                        "video"
                                                    ?  Container(
                                                  height: 0.0,
                                                )
                                                    :new InkWell(
                                                    onTap:
                                                        () {
                                                      Navigator.of(context)
                                                          .push(new MaterialPageRoute(builder: (BuildContext context) =>
                                                          CommonFullViewWidget(opportunity.assestVideoAndImage,
                                                              MessageConstant.ACCOMPLISHMENT_HEDING, index2,
                                                              MessageConstant. VIEWER_END_REWCOMMENDATION_HEDING)));
                                                    },
                                                    child:  Container(
                                                      height: 215.50,
                                                      width: double.infinity,
                                                      child:  Image.asset(
                                                        "assets/newDesignIcon/navigation/layer_image.png",
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ))
                                              ]),
                                              onTap: () {},
                                            );
                                          },
                                          onPageChanged: (index) {},
                                        ),
                                        align: IndicatorAlign.bottom,
                                        length: opportunity
                                            .assestVideoAndImage.length,
                                        indicatorSpace: 10.0,
                                        indicatorColor: opportunity
                                            .assestVideoAndImage.length ==
                                            1
                                            ? Colors.transparent
                                            :  Color(0xffc4c4c4),
                                        indicatorSelectorColor: opportunity
                                            .assestVideoAndImage.length ==
                                            1
                                            ? Colors.transparent
                                            :  ColorValues.WHITE,
                                        shape: IndicatorShape.circle(size: 5.0),
                                      ))
                                      :  Stack(children: <Widget>[
                                    Image.asset(
                                      "assets/profile/default_achievement.png",
                                      fit: BoxFit.cover,
                                      height: 215.50,
                                      width: double.infinity,
                                    ),
                                    Container(
                                      height: 215.50,
                                      color: Colors.black54.withOpacity(.4),
                                    )
                                  ])),
                              UIHelper.verticalSpaceMedium,
                              Container(
                                width: double.infinity,
                                margin: EdgeInsets.all(0),
                                padding: EdgeInsets.all(0),
                                // decoration: rectangleDecoration(),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[


                                    Container(
                                      width: double.infinity,
                                      padding: EdgeInsets.all(0),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text(

                                            opportunity.offerId == "4" ||
                                                opportunity.offerId == "5"
                                                ? opportunity.serviceTitle
                                                : opportunity.jobTitle,
                                            //: "College Counselling",
                                            style: TextStyle(
                                                fontSize: 20,
                                                fontFamily: Constant
                                                    .latoSemibold,
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1),
                                          ),

                                          UIHelper.verticalSpaceSmall,

                                          RichText(
                                            text:  TextSpan(
                                                text: secondHalfDesc == null &&
                                                    secondHalfDesc == ""
                                                    ? firstHalfDesc
                                                    : flagDesc
                                                    ? (firstHalfDesc + "")
                                                    : (firstHalfDesc +
                                                    secondHalfDesc),
                                                style:  TextStyle(
                                                    fontSize: 12,
                                                    fontFamily: Constant
                                                        .latoRegular,
                                                    fontWeight: FontWeight.w500,
                                                    color: ColorValues
                                                        .labelColor),
                                                children: [
                                                  TextSpan(
                                                    text: secondHalfDesc == ''
                                                        ? ''
                                                        : flagDesc
                                                        ? " More"
                                                        : " Less",
                                                    style:
                                                    AppTextStyle.getDynamicFont(
                                                        ColorValues.BLUE_COLOR,
                                                        12,
                                                        FontType.Regular),
                                                    recognizer:
                                                    TapGestureRecognizer()
                                                      ..onTap = () {
                                                        print('Tap Here onTap');
                                                        setState(() {
                                                          flagDesc = !flagDesc;
                                                        });
                                                      },
                                                  )
                                                ]),
                                          ),
                                          UIHelper.verticalSpaceSmall,
                                          opportunity.offerId == "6" ||
                                              opportunity.offerId == "7" ||
                                              opportunity.offerId == "8"
                                              ? getMentorAdvisorTutor()
                                              : opportunity.offerId == "1" ||
                                              opportunity.offerId == "2" ||
                                              opportunity.offerId == "3"
                                              ? getJobInternship()
                                              : Container(height: 0.0,),

                                          /*   UIHelper.verticalSpaceSmall,
                                opportunity.url == "null"
                                    ?  Container(
                                  height: 0,
                                )
                                    : Text(
                                  opportunity.url,
                                  style: AppTextStyle.getDynamicFontStyle(
                                      Palette.accentColor,
                                      16,
                                      FontType.Regular),
                                ),*/
                                          /*opportunity.jobLocation==null  || opportunity.jobLocation=="null"  || opportunity.jobLocation==""?new Container(height: 0.0,):
                                    UIHelper.verticalSpaceSmall,
                                    opportunity.jobLocation==null  || opportunity.jobLocation=="null"  || opportunity.jobLocation==""?new Container(height: 0.0,):  Text(
                                      'Job Location: ' +

                                          opportunity.jobLocation,
                                      style: AppTextStyle.getDynamicFontStyle(
                                          Palette.primaryTextColor,
                                          14,
                                          FontType.Regular),
                                    ),*/
                                          opportunity.offerId == "6" ||
                                              opportunity.offerId == "7" ||
                                              opportunity.offerId == "8"
                                              ? UIHelper.verticalSpaceSmall
                                              : Container(height: 0.0),
                                          opportunity.offerId == "6" ||
                                              opportunity.offerId == "7" ||
                                              opportunity.offerId == "8"
                                              ? getScheduleWidget(opportunity)
                                              : Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              /*Text(
                                      'Schedule For: ' +
                                          getConvertedDateStamp2(
                                              opportunity.fromDate) +
                                          " - " +
                                          getConvertedDateStamp2(
                                              opportunity.toDate),
                                      style: AppTextStyle.getDynamicFontStyle(
                                          Palette.primaryTextColor,
                                          14,
                                          FontType.Regular),
                                    ),*/

                                              otherInformationHeader('Scheduled For: '),


                                              UIHelper.verticalSpaceSmall,

                                              otherInformationValue(getConvertedDateStamp2(
                                                  opportunity
                                                      .fromDate) +
                                                  " - " +
                                                  getConvertedDateStamp2(
                                                      opportunity.toDate),),


                                              //
                                              // AppTextStyle.getLableTextForDetail(
                                              //     'Scheduled For: ',
                                              //     getConvertedDateStamp2(
                                              //         opportunity
                                              //             .fromDate) +
                                              //         " - " +
                                              //         getConvertedDateStamp2(
                                              //             opportunity.toDate)),
                                              /*Text(
                                      'Schedule For: ' +
                                          getConvertedDateStamp2(
                                              opportunity.fromDate) +
                                          " - " +
                                          getConvertedDateStamp2(
                                              opportunity.toDate),
                                      style: AppTextStyle.getDynamicFontStyle(
                                          Palette.primaryTextColor,
                                          14,
                                          FontType.Regular),
                                    ),*/
                                            ],
                                          ),
                                          UIHelper.verticalSpaceSmall,

                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              /*Text(
                                      'Schedule For: ' +
                                          getConvertedDateStamp2(
                                              opportunity.fromDate) +
                                          " - " +
                                          getConvertedDateStamp2(
                                              opportunity.toDate),
                                      style: AppTextStyle.getDynamicFontStyle(
                                          Palette.primaryTextColor,
                                          14,
                                          FontType.Regular),
                                    ),*/


                                              otherInformationHeader('Expiration Date: '),


                                              UIHelper.verticalSpaceSmall,

                                              otherInformationValue(getConvertedDateStamp2(
                                                  opportunity.expiresOn)),


                                              // Text(getConvertedDateStamp2(
                                              //     opportunity.expiresOn),
                                              //   //: "College Counselling",
                                              //   style: TextStyle(
                                              //       fontSize: 14,
                                              //       fontFamily: Constant
                                              //           .latoRegular,
                                              //       color: ColorValues
                                              //           .labelColor,
                                              //     fontWeight: FontWeight.w600
                                              //   ),
                                              // ),

                                              //
                                              // AppTextStyle.getLableTextForDetail(
                                              //     'Scheduled For: ',
                                              //     getConvertedDateStamp2(
                                              //         opportunity
                                              //             .fromDate) +
                                              //         " - " +
                                              //         getConvertedDateStamp2(
                                              //             opportunity.toDate)),
                                              /*Text(
                                      'Schedule For: ' +
                                          getConvertedDateStamp2(
                                              opportunity.fromDate) +
                                          " - " +
                                          getConvertedDateStamp2(
                                              opportunity.toDate),
                                      style: AppTextStyle.getDynamicFontStyle(
                                          Palette.primaryTextColor,
                                          14,
                                          FontType.Regular),
                                    ),*/
                                            ],
                                          ),
                                          // AppTextStyle.getLableTextForDetail(
                                          //     'Expiration Date: ',
                                          //     getConvertedDateStamp2(
                                          //         opportunity.expiresOn)),
                                        ],
                                      ),
                                    ),

                                    opportunity.docList.length == 0 ||
                                        opportunity.offerId == "6"
                                        ?  Container(
                                      height: 0.0,
                                    )
                                        : Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0.0, 10.0, 0.0, 0.0),
                                        child:  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            otherInformationHeader('Documents'),
                                            docListUiData,
                                          ],
                                        )),


                                    opportunity.offerId == "7" ||
                                        opportunity.offerId == "8"
                                        ? Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      children: <Widget>[
                                        opportunity != null &&
                                            opportunity.userImageModelParam
                                                .length >
                                                0
                                            ? PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            10.0,
                                            15.0,
                                            0.0,
                                            otherInformationHeader("${opportunity.offerId == "8" ? "Advisors Photo" : "Mentor Photo"}"))


                                        // Text(
                                        //   "${opportunity.offerId == "8" ? "Advisors Photo" : "Mentor Photo"}",
                                        //   style:  TextStyle(
                                        //       fontSize: 12,
                                        //       fontFamily: Constant
                                        //           .latoRegular,
                                        //       color: ColorValues
                                        //           .labelColor),
                                        //
                                        //   // AppTextStyle
                                        //   //     .getDynamicFont(
                                        //   //     ColorValues.HEADING_COLOR_EDUCATION_1,
                                        //   //     12,
                                        //   //     FontType.Regular),
                                        // ))
                                            :  Container(
                                          height: 0.0,
                                        ),
                                        userImageListUI(),
                                      ],
                                    )
                                        : Container(),



                                    opportunity.offerId == "6" ||
                                        opportunity.offerId == "7" ||
                                        opportunity.offerId == "8"
                                        ? Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                        0.0,
                                        2.0,
                                        0.0,
                                        0.0,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        children: <Widget>[
                                          UIHelper.verticalSpaceSmall,

                                          otherInformationHeader("Bio"),



                                          UIHelper.verticalSpaceExtraSmall,
                                          RichText(
                                            text:  TextSpan(
                                                text: secondHalf == ""
                                                    ? firstHalf
                                                    : flag
                                                    ? (firstHalf + "")
                                                    : (firstHalf +
                                                    secondHalf),
                                                //style: underlineStyle.copyWith(decoration: TextDecoration.none),
                                                style: TextStyle(
                                                  color: ColorValues.labelColor,
                                                  fontFamily: Constant.latoRegular,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.w600,
                                                ),


                                                children: [
                                                  TextSpan(
                                                    text: secondHalf == ''
                                                        ? ''
                                                        : flag
                                                        ? " More"
                                                        : " Less",
                                                    style: AppTextStyle
                                                        .getDynamicFont(
                                                        ColorValues.BLUE_COLOR,
                                                        14,
                                                        FontType.Regular),
                                                    recognizer:
                                                    TapGestureRecognizer()
                                                      ..onTap = () {
                                                        print(
                                                            'Tap Here onTap');
                                                        setState(() {
                                                          flag = !flag;
                                                        });
                                                      },
                                                  )
                                                ]),
                                          ),
                                        ],
                                      ),
                                    )
                                        : Container(),

                                    opportunity.docList.length != 0 &&
                                        opportunity.offerId == "6"
                                        ? Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0.0, 10.0, 0.0, 0.0),
                                        child:  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[


                                            otherInformationHeader('Teaching Certifications'),

                                            // mediaLabelText(
                                            //     'Teaching Certifications'),
                                            docListUiData,
                                          ],
                                        ))
                                        :  Container(
                                      height: 0.0,
                                    ),
                                    opportunity.googleLinkList.length == 0
                                        ?  Container(
                                      height: 0.0,
                                    )
                                        : Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0.0, 10.0, 0.0, 0.0),
                                        child:  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            otherInformationHeader('Additional Link(s): '),

                                            // mediaLabelText('Additional Link(s): '),
                                            Padding(
                                              padding:
                                              const EdgeInsets.only(top: 0.0),
                                              child: uploadGoogleDocLink(),
                                            ),
                                          ],
                                        )),
                                  ],
                                ),
                              ),
                              UIHelper.verticalSpaceSmall,


                              widget.pageName == "preview"
                                  ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  opportunity.targetAudience == "true"
                                      ? Container(
                                    width: double.infinity,
                                    //color: Palette.titleBg,
                                    padding: EdgeInsets.only(
                                        left: 0, top: 5, bottom: 10),
                                    child: Text(
                                        'OTHER INFORMATION',
                                        style: TextStyle(
                                            fontFamily: Constant.latoRegular,
                                            fontSize: 13,
                                            color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                            fontWeight: FontWeight.w600
                                        )
                                    ),
                                  )
                                      :  Container(
                                    height: 0.0,
                                  ),
                                  opportunity.targetAudience == "true"
                                      ?Container(
                                    padding: EdgeInsets.all(0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[

                                        location != ""
                                            ?  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            otherInformationHeader(
                                                'Location You Like To Cover'),
                                            SizedBox(height: 8,),
                                            otherInformationValue(
                                                location.trim()),
                                          ],
                                        )
                                            :  Container(
                                          height: 0.0,
                                        ),


                                        opportunity.gender == ""
                                            ?  Container(
                                          height: 0.0,
                                        )
                                            :  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            SizedBox(height: 13,),
                                            otherInformationHeader(
                                                'Gender'),
                                            SizedBox(height: 8,),

                                            otherInformationValue(
                                                opportunity.gender),
                                          ],
                                        ),

                                        // UIHelper.verticalSpaceMedium,
                                        opportunity.ageList.length == 0
                                            ?  Container(
                                          height: 0.0,
                                        )
                                            :  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            SizedBox(height: 13,),
                                            otherInformationHeader(
                                                'Age Group'),
                                            SizedBox(height: 8,),

                                            getAgeList(),
                                          ],
                                        ),

                                        opportunity.interestTypeList.length == 0
                                            ?  Container(
                                          height: 0.0,
                                        )
                                            :  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            SizedBox(height: 13,),
                                            otherInformationHeader(
                                                'Interest(s)'),
                                            SizedBox(height: 8,),
                                            Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children:  List.generate(
                                                  opportunity.interestTypeList
                                                      .length, (index) {
                                                return otherInformationValue(
                                                    opportunity
                                                        .interestTypeList[index]
                                                        .name);
                                              }),
                                            ),
                                            UIHelper.verticalSpaceMedium,
                                          ],
                                        )
                                      ],
                                    ),
                                  )
                                      :  Container(
                                    height: 0.0,
                                  ),
                                ],
                              )
                                  : Container(),
                            ],
                          ),
                        ),
                      ),
                    ),
                    flex: 1,
                  ),




                  widget.pageName == "preview"
                      ?  Container(
                    height: 0.0,
                  )
                      :  Expanded(
                    child: diffrenceInDob < 13
                        ?  PaddingWrap.paddingfromLTRB(
                        17.0,
                        15.0,
                        17.0,
                        15.0, Container(
                      width: MediaQuery.of(context).size.width,
                      height: 44.0,
                      decoration: BoxDecoration(
                        color: ColorValues.call_now_color,
                        borderRadius:
                        BorderRadius.circular(10),
                      ),
                      child:  Row(
                      crossAxisAlignment:
                      CrossAxisAlignment.center,
                      children: <Widget>[
                          Expanded(
                          child: InkWell(
                            child: Padding(
                              padding:
                              const EdgeInsets
                                  .fromLTRB(
                                  15.0,
                                  0.0,
                                  15.0,
                                  0.0),
                              child: Container(


                                  child:  Text(
                                    "FORWARD TO PARENT",
                                    style: TextStyle(
                                        color: ColorValues
                                            .WHITE,
                                        fontSize:
                                        14.0,
                                        fontFamily:
                                        Constant
                                            .latoRegular,
                                        fontWeight: FontWeight
                                            .w600),
                                  )),
                            ),
                            onTap: () {

                            },
                          ),
                          flex: 0,
                        ),

                        Spacer(),
                        Padding(
                          padding:
                          const EdgeInsets.only(right:
                              15.0),
                          child:InkWell(
                            child: Image.asset(
                              'assets/profile/parent/info.png',
                              height: 20.0,
                              width: 20.0,
                              color: Colors.white,
                            ),
                            onTap: () {
                              infoDialog();
                            },
                          ) ,
                        )
                      ],
                    ),))
                        :
                    PaddingWrap.paddingfromLTRB(
                        20.0,
                        15.0,
                        20.0,
                        15.0, InkWell(
                      onTap: (){
                        apiCallingForIncreaseCount();
                        if (opportunity.actionType ==
                            Constant.LINK_URL) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) =>
                                      WebViewWidget(
                                          opportunity.url
                                              .contains(
                                              "http")
                                              ? opportunity.url
                                              : "https://" +
                                              opportunity.url,
                                          opportunity.linkUrlPosition ==
                                              Constant
                                                  .LEARN_MORE
                                              ? "LEARN MORE"
                                              : opportunity
                                              .linkUrlPosition ==
                                              Constant
                                                  .GET_OFFER
                                              ? "GET OFFER"
                                              : "APPLY NOW")));
                        } else if (opportunity.actionType ==
                            Constant.JOIN_GROUP) {
                          if(prefs!=null&&opportunity!=null&& Util.showJoinGroupButton(
                              prefs,opportunity.schoolCode,
                              opportunity.actionType)=="true"){
                            if (opportunity.studentJoinId == "" ||
                                opportunity.studentJoinId ==
                                    "null") {
                              if (isGroup_AccessControl) {
                                apiCallJoin(
                                    opportunity.groupIdAction);
                                ;
                              } else {
                                ToastWrap.showToastForAccessDenied(
                                    MessageConstant.JOIN_GROUP_DISABLE, context);
                              }
                            } else {
                              apiCallForForwardParent(
                                  opportunity.groupIdAction,
                                  opportunity);
                            }}else{
                            ToastWrap.showToast(MessageConstant.OPPORTUNITY_NOT_IN_COMMUNITY, context);

                          }

                        } else if (opportunity.actionType ==
                            Constant.CALL_NOW) {
                          String callingNumber =
                              opportunity.callingNumber;
                          launch("tel:" + callingNumber);
                        } else {
                          Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder:
                                      (BuildContext context) =>
                                      InquireNowScreen(
                                          opportunity
                                              .opportunityId,
                                          widget.feedId,
                                          opportunity.formId,
                                          opportunity.offerId
                                              .toString(),
                                          "")));
                        }
                      },
                      child: Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color: ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED,
                            borderRadius:
                            BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.all(10.0),
                          height: 44.0,
                          child: BaseText(
                            text: opportunity.actionType ==
                                Constant.LINK_URL
                                ? opportunity
                                .linkUrlPosition ==
                                Constant
                                    .LEARN_MORE
                                ? "Learn more"
                                : opportunity
                                .linkUrlPosition ==
                                Constant
                                    .GET_OFFER
                                ? "Get offer"
                                : "Apply now"
                                : opportunity
                                .actionType ==
                                Constant
                                    .JOIN_GROUP
                                ? "Join group"
                                : opportunity
                                .actionType ==
                                Constant
                                    .CALL_NOW
                                ? "Call now"
                                : "Inquire now",//Learn More
                            textColor: ColorValues.WHITE,
                            fontFamily:
                            AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w400,
                            fontSize: 18,
                            textAlign: TextAlign.center,
                            maxLines: 1,
                          )),
                    )),
                    flex: 0,
                  )
                ],
              )),
              () {
            Navigator.pop(context);
          },
          isShowIcon: false,
        ));



  }

  Widget getAgeList() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(opportunity.ageList.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 2.0, 0.0, 0.0),
          child: Text(
            opportunity.ageList[index].from +
                "-" +
                opportunity.ageList[index].to +
                " years ",
            style: AppTextStyle.getDynamicFontStyle(
                Palette.primaryTextColor, 16, FontType.Regular),
          ),
        );
      }),
    );
  }

  otherInformationHeader(String title) {
    return Text(
      title,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 12,
          color: ColorValues.HEADING_COLOR_EDUCATION_1,
          fontWeight: FontWeight.w600
      ),
    );
  }

  otherInformationHeaderBold(String title) {
    return Text(
      title,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 12,
          color: ColorValues.HEADING_COLOR_EDUCATION_1,
          fontWeight: FontWeight.w600
      ),
    );
  }

  otherInformationValue(String value) {
    return Text(
      value,
      textAlign: TextAlign.start,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 14,
          color: ColorValues.labelColor,
          fontWeight: FontWeight.w600
      ),
    );
  }

  bottomWidgetDataTitleWidget(String text, Color color) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(color, 14, FontType.Regular),
    );
  }

  bottomWidgetDataValueWidget(String text) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.accentColor, 24, FontType.Regular),
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now =  DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter =  DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter =  DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  Widget getScheduleWidget( opportunity) {
    print(
        'opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[


            otherInformationHeader('Scheduled For: '),



            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children:
              List.generate(opportunity.scheduleModelParam.length, (index) {
                return Padding(
                  padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  child:
                  /*Text(
                          opportunity
                              .scheduleModelParam[
                          index]
                              .day +
                              " : " +
                              getHours(
                                  index),
                          maxLines: null,
                          style: AppTextStyle.getDynamicFont(
                               ColorValues.HEADING_COLOR_EDUCATION,
                              14,
                              FontType
                                  .Regular))*/
                  getHoursData(index),
                );
              }),
            )
          ],
        ));
  }

  getHoursData(index) {
    return RichText(
      textAlign: TextAlign.start,
      maxLines: null,
      text: TextSpan(

        text:
        opportunity.scheduleModelParam[index].day + ": " + getHours(index),


        style:TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 14,
            fontFamily: Constant.latoRegular,
            color: ColorValues.labelColor
        ),

        children: <TextSpan>[
          TextSpan(
            text: opportunity.timeZone == null ||
                opportunity.timeZone == "" ||
                opportunity.timeZone == "null"
                ? ""
                : "(" + opportunity.timeZone + ")",
            style:  TextStyle(
                color:  ColorValues.GREY__COLOR,
                fontSize: 14.0,
                fontWeight: FontWeight.normal,
                fontFamily: Constant.customRegular),
          )
        ],
      ),
    );
  }

  String getConvertedTime(int time) {
    String timeReturn = "";
    if (time != null) {
      int startTimeHour = DateTime.fromMillisecondsSinceEpoch(time).hour;
      int startTimeMinute = DateTime.fromMillisecondsSinceEpoch(time).minute;

      if (startTimeHour > 12) {
        String startTimeH = (startTimeHour - 12).toString();

        startTimeH = startTimeH.toString().length == 2
            ? startTimeH.toString()
            : "0" + startTimeH.toString();
        String startTimeM = startTimeMinute.toString().length == 2
            ? startTimeMinute.toString()
            : "0" + startTimeMinute.toString();

        return timeReturn = startTimeH.toString() + ":" + startTimeM + " pm";
      } else {
        String startTimeH = startTimeHour.toString().length == 2
            ? startTimeHour.toString()
            : "0" + startTimeHour.toString();
        String startTimeM = startTimeMinute.toString().length == 2
            ? startTimeMinute.toString()
            : "0" + startTimeMinute.toString();

        return timeReturn =
            startTimeH.toString() + ":" + startTimeM.toString() + " am";
      }
    } else {
      return "";
    }
  }

  Widget getMentorAdvisorTutor() {
    print('opportunity.fees:: ${opportunity.fees}');
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall,


        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Category: '),
            SizedBox(height: 9,),
            otherInformationValue(categoryString),

          ],),


        // AppTextStyle.getBoldLableTextForDetail('Category: ', categoryString),
        //opportunity.toMapStringForDesignation()),

        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7"
            ? Container()
            :
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Subject: '),
            SizedBox(height: 8,),
            otherInformationValue(subjectString),

          ],),
        //opportunity.toMapStringSubject()),

        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceSmall1,

        opportunity.offerId == "7"
            ? Container()
            :
        //  AppTextStyle.getLableTextForDetail(
        //         'Qualification: ', opportunity.toMapStringQualification()),

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Qualification: '),
            SizedBox(height: 8,),
            otherInformationValue(opportunity.toMapStringQualification()),

          ],),

        /*opportunity.offerId == "6" ? Container(): UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7" ? Text(
          "Mentee Support Offered: " +
              opportunity
                  .menteeSupport,
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        )
            :
        opportunity.offerId == "8" ? Text(
            "Advisor Support Offered: " +
                opportunity.advisorSupportOffered,
            style: AppTextStyle
                .getDynamicFont(
                 Color(
                    ColorValues
                        .HEADING_COLOR_EDUCATION),
                14,
                FontType
                    .Regular)) : Container(),
                    opportunity.offerId == "8" ? UIHelper
            .verticalSpaceSmall1: Container(),
        opportunity.offerId == "8" ? Text(
          "Project Areas: ${opportunity.projectAreas}",
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        ): Container(),

                    */

        UIHelper.verticalSpaceSmall1,

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Fees: '),
            SizedBox(height: 8,),
            otherInformationValue(opportunity.fees == "0"
                ? MessageConstant.FEE_EMPTY_VAL
                : opportunity.fees),

          ],),

        // AppTextStyle.getBoldLableTextForDetail(
        //     'Fees: ',
        //     opportunity.fees == "0"
        //         ? MessageConstant.FEE_EMPTY_VAL
        //         : opportunity.fees),
      ],
    );
  }

  String getHours(index) {
    String timeReturn = "";
    try {
      for (HoursData hours in opportunity.scheduleModelParam[index].hours) {
        timeReturn = Util.getConvertedTimeForScheduleDate(hours.timeFrom) +
            " - " +
            Util.getConvertedTimeForScheduleDate(
                hours.timeTo == null ? hours.timeFrom : hours.timeTo) +
            " | " +
            timeReturn;
      }

      return timeReturn.substring(0, timeReturn.lastIndexOf("|"));
    } catch (e) {
      return timeReturn;
    }
  }

  userImageListUI() {
    return Container(
      child: opportunity != null && opportunity.userImageModelParam.length > 0
          ? PaddingWrap.paddingfromLTRB(
              0.0,
              10.0,
              15.0,
              10.0,
               Container(
                  child:  GridView.count(
                      primary: false,
                      shrinkWrap: true,
                      padding: const EdgeInsets.all(0.0),
                      crossAxisSpacing: 10.0,
                      childAspectRatio: 1.5,
                      scrollDirection: Axis.vertical,
                      crossAxisCount: 3,
                      children:  List.generate(
                          opportunity.userImageModelParam.length, (index2) {
                        return  Container(
                            child:  Stack(
                          children: <Widget>[
                             InkWell(
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  placeholder: 'assets/aerial/default_img.png',
                                  image: Constant.IMAGE_PATH +
                                      opportunity
                                          .userImageModelParam[index2].file,
                                  height: 80.0,
                                  width: 120.0,
                                ),
                                onTap: () {
                                  Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                           CommonFullViewWidget(
                                              opportunity.userImageModelParam,
                                              MessageConstant.HOME_HEDING,
                                              index2,
                                              MessageConstant
                                                  .VIEWER_END_REWCOMMENDATION_HEDING)));

                                  /*  Navigator.push(
                                  context,
                                   HeroDialogRoute(
                                    builder: (BuildContext context) {
                                      return  Center(
                                        child:  AlertDialog(
                                          content:  Container(
                                            child:  Hero(
                                              tag: 'developer-hero',
                                              child:  Container(
                                                height: 200.0,
                                                width: 200.0,
                                                child: Image.network(
                                                  Constant.IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          path.file),
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              ),
                                            ),
                                          ),
                                          actions: <Widget>[
                                             FlatButton(
                                              child:  Text('Close'),
                                              onPressed: Navigator.of(context).pop,
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                );*/
                                }),
                          ],
                        ));
                      })

                      /*   opportunity.userImageModelParam.map((path) {
                  return  Container(
                      child:  Stack(
                        children: <Widget>[
                           InkWell(
                              child: FadeInImage.assetNetwork(
                                fit: BoxFit.cover,
                                placeholder: 'assets/aerial/default_img.png',
                                image: Constant.IMAGE_PATH + path.file,
                                height: 80.0,
                                width: 120.0,
                              ),
                              onTap: () {
                                Navigator.push(
                                  context,
                                   HeroDialogRoute(
                                    builder: (BuildContext context) {
                                      return  Center(
                                        child:  AlertDialog(
                                          content:  Container(
                                            child:  Hero(
                                              tag: 'developer-hero',
                                              child:  Container(
                                                height: 200.0,
                                                width: 200.0,
                                                child: Image.network(
                                                  Constant.IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          path.file),
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              ),
                                            ),
                                          ),
                                          actions: <Widget>[
                                             FlatButton(
                                              child:  Text('Close'),
                                              onPressed: Navigator.of(context).pop,
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                );
                              }),
                        ],
                      ));
                }).toList(),*/
                      )))
          :  Container(
              height: 0.0,
            ),
    );
  }

  getJobInternship() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall,

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Job Type: '),
            SizedBox(height: 8,),
            otherInformationValue(opportunity.jobType),

          ],),
        UIHelper.verticalSpaceSmall,

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Job Location: '),
            SizedBox(height: 8,),
            otherInformationValue(opportunity.jobLocation),

          ],),

        // AppTextStyle.getLableTextForDetail('Job Type: ', opportunity.jobType),
        // UIHelper.verticalSpaceSmall,
        // AppTextStyle.getLableTextForDetail(
        //     'Job Location: ', opportunity.jobLocation),
        UIHelper.verticalSpaceSmall,
      ],
    );
  }

  void getData() {
    //category
    categoryString = opportunity.toMapStringForDesignation();
    if (opportunity.selectedDesignationCareerOption != null &&
        opportunity.selectedDesignationCareerOption.length > 0) {
      if (categoryString != "")
        categoryString = categoryString +
            " | " +
            opportunity.toMapStringForDesignationCareer();
      else
        categoryString = opportunity.toMapStringForDesignationCareer();
    }
    if (opportunity.selectedDesignationOtherOption != null &&
        opportunity.selectedDesignationOtherOption.length > 0) {
      if (categoryString != "")
        categoryString = categoryString +
            " | " +
            opportunity.toMapStringForDesignationOther();
      else
        categoryString = opportunity.toMapStringForDesignationOther();
    }

    //Subject
    subjectString = opportunity.toMapStringSubject();
    if (opportunity.selectedSubjectOtherOption != null &&
        opportunity.selectedSubjectOtherOption.length > 0) {
      if (subjectString != "")
        subjectString =
            subjectString + " | " + opportunity.toMapStringSubjectOther();
      else
        subjectString = opportunity.toMapStringSubjectOther();
    }

    setState(() {
      categoryString;
      subjectString;
    });
  }
}
