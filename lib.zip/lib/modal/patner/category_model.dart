class CategoryModel {
  bool isOther;
  String name;
  int businessCategoryId;

  CategoryModel({this.name, this.businessCategoryId,this.isOther});
  
  static Map<String, dynamic> toMap(CategoryModel categoryObject) {
    Map<String, dynamic> categoryMap = Map();
    categoryMap['name'] = categoryObject.name;
    categoryMap['businessCategoryId'] = categoryObject.businessCategoryId;
    categoryMap['isOther'] = categoryObject.isOther;
    return categoryMap;
  }

  static List<Map<String, dynamic>> mapList(List<CategoryModel> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
              "name": category.name,
              "businessCategoryId": category.businessCategoryId,
              "isOther": category.isOther,
            })
        .toList();
    return listOfCategory;
  }
}
