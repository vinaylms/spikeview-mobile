import 'package:shared_preferences/shared_preferences.dart';

class UserPreference {
  static const String NAME = "name";
  static const String LINK = "link";
  static const String EMAIL = "email";
  static const String PASSWORD = "password";
  static const String MOBILE = "mobile";
  static const String USER_ID = "userId";
  static const String PARENT_WIZARD_USERID = "puserId";
  static const String PATHURL = "path";
  static const String PATH_PARENT = "pathParent";
  static const String PARENT_ID = "parentId";
  static const String TENANT_LOGIN_ID = "tenantLoginId";
  static const String PROFILE_IMAGE_PATH = "profileImagePath";
  static const String COMPANY_IMAGE_PATH = "company";
  static const String COMPANY_NAME_PATH = "cName";
  static const String USER_TOKEN = "token";
  static const String DEVICE_ID = "deviceId";
  static const String DOB = "DOB";
  static const String PHONE = "phone";
  static const String iSACCOMPLISHMENTADD= "iSACCOMPLISHMENTADD";
  static const String isEducationAdded= "isEducationAdded";
  static const String LOGIN_STATUS = "loginStatus";
  static const String ISACTIVE = "isActive";
  static const String ISHide = "isHide";
  static const String CREATION_TIME = "creationTime";
  static const String TAGLINE = "tagLine";
  static const String IS_DIALOG_SHOW = "isHideDilogShow";
  static const String IS_PASSWORD_CHANGED = "isPasswordChanged";
  static const String IS_PROFILECRETED_BY_PARENT = "isProfileCreatedByParent";
  static const String IS_USER_LOGIN_FIRST_TIME = "isUserLoginFirstTime";
  static const String IS_PARENT = "isParent";
  static const String IS_PARENT_ROLE = "isParentrole";
  static const String EDU_ALLOWED_DOMAIN = "educatorAllowedDomain";
  static const String STAGE = "stage";
  static const String IS_PARTNER_ROLE = "isPartnerRole";

  static const String SCHOOL_CODE = "schoolCode";
  static const String IS_SCHOOL = "isSchool";
  static const String IS_REPORTED = "isReported";
  static const String SCHOOL_NAME = "schoolName";
  static const String EMAIL_SKIP_COUNT= "skipCount";
  static const String IS_USER_ROLE = "isUSerRole";
  static const String IS_ADDED_DOB = "isAddedDob";
  static const String IS_UNDER_AGE = "isUnderAge";
  static const String ROLE_ID = "roleId";


  static const String ACCESS_CONTROL_FEED = "HIDE_FEED";
  static const String ACCESS_CONTROL_FEED_STATUS = "HIDE_FEED_DISABLE";
  static const String ADMINI_PROFILE_SHARING_HANDELING = "ADMINI_PROFILE_SHARING_HANDELING";
  static const String ACCESS_CONTROL_GROUP =  "HIDE_GROUP";
  static const String ACCESS_CONTROL_CONNECTION =  "HIDE_CONNECTION";
  static const String ACCESS_CONTROL_CHAT =  "HIDE_CHAT";
  static const String ACCESS_CONTROL_PROFILE_VISIBILITY =  "HIDE_PROFILE_VISIBILITY";
  static const String ACCESS_CONTROL_GROUP_TYPE =  "HIDE_GROUP_TYPE";

 // static const String ACCESS_UPDATE_EMAIL =  "UPDATE_EMAIL";


  static const String ACCESS_CONTROL_PROFILE_SHARE =  "profileshare";
  static const String ACCESS_CONTROL_ALLOWFEEDPOST =  "allowFeedPost";

  static const String IS_PARTNER_ACTIVE = "isPartnerApprovedByAdmin";
  static const String ZIPCODE = "zipCode";
  static const String LOGIN_RESPONSE= "loginResponse";

  static const String COMPANY_COUNT = "companyCount";
  static const String SHOW_BOT_DEFAULT_COUNT = "botCount";
  static const String IS_COWNER = "coOwner";
  static const String IS_TENANT = "isTenant";
  static const String IS_ALLOW_TO_PERFORM_CHANGES = "userPermission";
  static const String PROPERTY_COUNT = "propertyCount";
  static const String LEASE_COUNT = "leaseCount";
  static const String EXPENSE_COUNT = "expenseCount";
  static const String TENANTS_COUNT = "tenantsCount";
  static const String gamificationPoints = "gamificationPoints";
  static const String badgeType = "badgeType";

  static const String badgeImage = "badgeImage";
  static const String refferalCode = "refferalCode";
  static const String referCode = "referCode";

  static const String chat_skip_count = "0";
  static const String IS_PRE_LOGIN = "isPreLogin";
  static const String IS_SCHOOLCODE = "isPreLogin";
  static const String IS_PRIENT_LOGGER = "isPreLogin";

  static const String IS_COMMUNITY_POPUP = "isCommunityPopup";
 // static const String NEW_FEATURE_POP_UP = "showNewFeaturePopup";
 // static const String NEW_FEATURE_FEED_POP_UP = "showNewFeatureFeedPopup";

  static const String UNIVERSITY_LIST= "universityList";


  //for     coach mark
  static const String IS_socialLinks_POPUP = "isSocialLinksPopup";
  static const String IS_skillAndCertification_POPUP = "isSkillAndCertificationPopup";
  static const String IS_skill_POPUP = "isSkillPopup";
  static const String IS_Certification_POPUP = "isCertificationPopup";
  static const String IS_interest_POPUP = "isInterestPopup";
  static const String IS_profileSharing_POPUP = "isProfileSharingPopup";
  static const String IS_portfolio_POPUP = "isPortfolioPopup";


  static const String COACH_MARK_NAME_POPUP = "coachMarkNamePopup";

  static const String IS_SHOW_REJECTION_POPUP = "isShowRejectionPopup";
  static const String IS_COACHMARK_POPUP = "isCoachMarkPopup";
  static const String PARTNER_STATUS = "partnerStatus";


  static const String PROFILE_DATA = "profileData";
  static const String SPIDER_CHART_DATA = "spiderChart";
  static const String ACCOMPLISHMENT_DATA = "accomplishmentData";
  static const String INCOMPLETE_ACCOMPLISHMENT_DATA = "InCompleteAccomplishmentData";
  static const String SKILL_DATA = "skillData";




  static Future<SharedPreferences> get _instance async =>
      _prefsInstance ??= await SharedPreferences.getInstance();
  static SharedPreferences _prefsInstance;



  static Future initSharedPreference() async {
    _prefsInstance = await SharedPreferences.getInstance();
  }


  static void setIsUserReported(bool strValue) {
    _prefsInstance.setBool(UserPreference.IS_REPORTED, strValue);
  }

  static bool getIsUserReported() {
    return _prefsInstance.getBool(UserPreference.IS_REPORTED);
  }



}
