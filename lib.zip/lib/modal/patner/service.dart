import 'package:spike_view_project/modal/patner/age_between.dart';

class Service {
  String title;
  String location = "Location";
  String cities = "City";
  String gender = "Male";
  List<AgeBetween> ageBetween;
  List<String> interests;

  Service(
      {this.title,
        this.location,
        this.cities,
        this.gender,
        this.ageBetween,
        this.interests});

  Service.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    location = json['location'];
    cities = json['cities'];
    gender = json['gender'];

    if (json['age'] != null) {
      ageBetween =  List<AgeBetween>();
      json['age'].forEach((v) {
        ageBetween.add(new AgeBetween.fromJson(v));
      });
    }
    if (json['interests'] != null) {
      interests =  List<String>();
      json['interests'].forEach((v) {
        interests.add(v.toString());
      });
    } else {
      interests = [];
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['title'] = this.title;
    data['location'] = this.location;
    data['cities'] = this.cities;
    data['gender'] = this.gender;
    if (this.ageBetween != null) {
      data['age'] = this.ageBetween.map((v) => v.toJson()).toList();
    }
    data['interests'] = this.interests;
    return data;
  }



  static List<String> getInterests() {
    return ["Interest1", "Interest2", "Interest3"];
  }
}
