import 'dart:async';
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:multi_charts/multi_charts.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:readmore/readmore.dart';
import 'package:spike_view_project/PublicProfileFilter/ShareProfileView.dart';
import 'package:spike_view_project/PublicProfileFilter/custom_portfolio_details_view.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/PublicProfileDataModel.dart';
import 'package:spike_view_project/TestScore/DocumentPerformance.dart';
import 'package:spike_view_project/accomplishment/portfolio/PortfolioViewWidget.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/FullImageView.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/ScoreDataModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/read_more_text.dart';
import 'package:url_launcher/url_launcher.dart';

import 'model/SpiderAndSkillDataModel.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart'
    as profile;

// Create a Form Widget
class CustomizeProfilePreViewWidget extends StatefulWidget {
  bool isDisplaySocialEmail;
  bool isGPA;
  PublicProfileDataModel _mPublicProfileDataModel;
  AcoomplismentDataModel _mAcoomplismentDataModel;
  String link, userId;
  final profile.ProfileData studentProfile;

  CustomizeProfilePreViewWidget(
    this.isDisplaySocialEmail,
    this.isGPA,
    this._mPublicProfileDataModel,
    this._mAcoomplismentDataModel,
    this.link,
    this.userId, {
    this.studentProfile,
  });

  @override
  CustomizeProfilePreViewWidgetState createState() {
    return CustomizeProfilePreViewWidgetState(
      isGPA,
      _mPublicProfileDataModel,
      _mAcoomplismentDataModel,
    );
  }
}

class CustomizeProfilePreViewWidgetState
    extends State<CustomizeProfilePreViewWidget> {
  UploadMedia uploadMedia;

  CustomizeProfilePreViewWidgetState(
    this.isGPA,
    this._mPublicProfileDataModel,
    this._mAcoomplismentDataModel,
  );

  SharedPreferences prefs;
  String userIdPref, roleId;
  ScrollController _scrollController = ScrollController();

  PublicProfileDataModel _mPublicProfileDataModel;
  AcoomplismentDataModel _mAcoomplismentDataModel;
  final PageController pageController = PageController();
  final dataKey0 = GlobalKey();
  SpiderAndSkillDataModel _mSpiderAndSkillDataModel;

  bool isSpiderChartApiCalled = true;
  bool isShowSummary = false;
  bool isViewAllBadges = false;
  bool isShowAllTestScore = false;
  bool isShowAllRecommendation = false;
  int achievmentCount = 0;
  int achivmentLength = 0;
  bool isGPA = false;
  List<double> spiderChartList = List<double>();
  List<String> spiderChartName = List<String>();

  Future skillApi(isShowLaoder, userId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        String profileID = widget.link.split("/Linear/")[1];
        Codec<String, String> stringToBase64 = utf8.fuse(base64);
        String decodedSharedId =
            stringToBase64.decode(profileID.replaceAll("&SPK", "="));
        Response response = await ApiCalling2().apiCallWithouAuth(
            context,
            Constant.ENDPOINT_SPIDER_AND_SKILL_DETAIL +
                decodedSharedId +
                "&userId=" +
                userId.toString(),
            "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("response+++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mSpiderAndSkillDataModel =
                  SpiderAndSkillDataModel.fromJson(response.data);

              setState(() {});

              spiderChartName.addAll(_mSpiderAndSkillDataModel.result.toName());
              spiderChartList
                  .addAll(_mSpiderAndSkillDataModel.result.toValue());

              if (spiderChartList.length > 0) {
                if (spiderChartList.length < 3) {
                  if (spiderChartList.length == 1) {
                    spiderChartList.add(0);
                    spiderChartName.add("");

                    spiderChartName.add("");
                    spiderChartList.add(0);
                  } else if (spiderChartList.length == 2) {
                    spiderChartList.add(0);
                    spiderChartName.add("");
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("Skillapi++++" + e.toString());
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.userId;
    roleId = "1";

    for (int i = 0;
        i < _mPublicProfileDataModel.result.recommendations.length;
        i++) {
      setState(() {
        _mPublicProfileDataModel.result.recommendations[i].isMore = false;
      });
    }

    skillApi(true, userIdPref);
  }

  @override
  void initState() {
    uploadMedia = UploadMedia(context);
    if (_mAcoomplismentDataModel.toJson().length == 0 ||
        (!_mPublicProfileDataModel.result.isAccomplishment)) {
      _mPublicProfileDataModel.result.isAccomplishment = false;
    }

    _streamSubscription =
        VideoPlayPauseState.syncDoneController.stream.listen((value) {
      setState(() {
        isVideoPlay = false;
      });
    });

    getSharedPreferences();
    getShowExternalLinks(_mAcoomplismentDataModel.accomplimentData);
    super.initState();
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  bool isVideoPlay = false;
  StreamSubscription<dynamic> _streamSubscription;

  Widget introductionViewUI() {
    String videoThumbnailUrl =
        _mPublicProfileDataModel?.result?.introVideo?.thumbnailUrl ?? '';
    String videoUrl =
        _mPublicProfileDataModel?.result?.introVideo?.videoUrl ?? '';

    return _mPublicProfileDataModel.result == null ||
            _mPublicProfileDataModel.result.introVideo == null ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == null ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == "null" ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == ""
        ? const SizedBox.shrink()
        : PaddingWrap.paddingfromLTRB(
            20.0,
            8.0,
            20.0,
            13.0,
            Container(
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                            BaseText(
                              text: 'Introduction',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                              maxLines: 1,
                            )),
                      ),
                    ],
                  ),
                  Container(
                    height: 200,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(10)),
                    clipBehavior: Clip.antiAlias,
                    margin: const EdgeInsets.only(top: 14),
                    child: isVideoPlay ?? false
                        ? VideoPlayPause(
                            _mPublicProfileDataModel.result.introVideo.videoUrl,
                            "",
                            true,
                            pageName: "profile",
                          )
                        : Container(
                            color: Colors.black,
                            child: Stack(
                              children: [
                                videoThumbnailUrl?.isNotEmpty ?? false
                                    ? CachedNetworkImage(
                                        height: 200,
                                        width: double.infinity,
                                        imageUrl: videoThumbnailUrl
                                                    .toLowerCase()
                                                    .contains("http") ||
                                                videoThumbnailUrl
                                                    .toLowerCase()
                                                    .contains("www.")
                                            ? videoThumbnailUrl
                                            : "${Constant.IMAGE_PATH}$videoThumbnailUrl",
                                        fit: BoxFit.contain,
                                        placeholder: (context, url) =>
                                            Util.loader(context, ""),
                                        errorWidget: (context, url, error) =>
                                            Util.error(""),
                                      )
                                    : const SizedBox.shrink(),
                                Center(
                                  child: InkWell(
                                    onTap: () {
                                      if (videoUrl
                                              .toLowerCase()
                                              .contains("http") ||
                                          videoUrl
                                              .toLowerCase()
                                              .contains("www.")) {
                                        if (videoUrl
                                            .toLowerCase()
                                            .contains("http")) {
                                          launch(videoUrl);
                                        } else {
                                          String url = "http://" + videoUrl;
                                          launch(url);
                                        }
                                      } else {
                                        setState(() {
                                          isVideoPlay = true;
                                        });
                                      }
                                    },
                                    child: Image.asset(
                                      'assets/ic_intro_play.png',
                                      height: 40,
                                      width: 40,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                  )
                ],
              ),
            ),
          );
  }

  barList() {
    return Container(
        //   color: Colors.white,
        child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(
          _mSpiderAndSkillDataModel.result.skillChart.length, (int index) {
        return Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Text(
                  _mSpiderAndSkillDataModel.result.skillChart[index].name,
                  style: TextStyle(
                      fontFamily: Constant.TYPE_CUSTOMREGULAR, fontSize: 14),
                ),
              ),
              Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0.0, 0, 10),
                  child: InkWell(
                    child: Padding(
                      padding: EdgeInsets.only(
                          top: 5,
                          right: 0,
                          left: 5,
                          bottom: _mSpiderAndSkillDataModel
                                          .result.skillChart.length -
                                      1 ==
                                  index
                              ? 10
                              : 0),
                      child: LinearPercentIndicator(
                        width: MediaQuery.of(context).size.width / 1.1,
                        animation: true,
                        backgroundColor:
                            ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                        lineHeight: 15.0,
                        animationDuration: 100,
                        percent: _mSpiderAndSkillDataModel
                            .result.skillChart[index].value,
                        linearStrokeCap: LinearStrokeCap.butt,
                        progressColor: _mSpiderAndSkillDataModel
                            .result.skillChart[index].color,
                      ),
                    ),
                  )),
            ],
          ),
        );
      }),
    ));
  }

  Widget headerUiDesign() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
            padding: EdgeInsets.only(top: 12, left: 20, right: 20, bottom: 15),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x70F48808),
                        blurRadius: 3,
                        spreadRadius: 1,
                      )
                    ],
                    border: Border.all(
                      color: ColorValues.DARK_YELLOW,
                      width: 5.0,
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  width: 65.0,
                  height: 65.0,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: _mPublicProfileDataModel.result != null
                        ? CachedNetworkImage(
                      imageUrl: Constant.IMAGE_PATH_SMALL +
                          ParseJson.getMediumImage(
                              _mPublicProfileDataModel
                                  .result.profilePicture),
                      fit: BoxFit.cover,
                      placeholder: (context, url) => _loader(
                          context,
                          "assets/profile/user_on_user.png"),
                      errorWidget: (context, url, error) =>
                          _error(
                              "assets/profile/user_on_user.png"),
                    )
                        : ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.asset(
                        "assets/profile/user_on_user.png",
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: PaddingWrap.paddingfromLTRB(
                      5.0,
                      0.0,
                      0.0,
                      0.0,
                      Container(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingAll(
                              2.0,
                              RichText(
                                  maxLines: 3,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                      text: _mPublicProfileDataModel.result ==
                                              null
                                          ? ""
                                          : _mPublicProfileDataModel
                                                          .result.lastName ==
                                                      "" ||
                                                  _mPublicProfileDataModel
                                                          .result.lastName ==
                                                      "null"
                                              ? _mPublicProfileDataModel
                                                          .result.firstName ==
                                                      null
                                                  ? ""
                                                  : _mPublicProfileDataModel
                                                      .result.firstName
                                              : _mPublicProfileDataModel
                                                      .result.firstName +
                                                  " " +
                                                  _mPublicProfileDataModel
                                                      .result.lastName,
                                      style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 22,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: Constant.latoRegular,
                                      )))),
                          (_mPublicProfileDataModel.result == null ||
                                  (_mPublicProfileDataModel.result.tagline ==
                                          null ||
                                      _mPublicProfileDataModel.result.tagline ==
                                          'null' ||
                                      _mPublicProfileDataModel
                                          .result.tagline.isEmpty))
                              ? SizedBox()
                              : Container(
                                  decoration: BoxDecoration(
                                    color: AppConstants.colorStyle.cardLight,
                                    border: Border.all(
                                      color: AppConstants.colorStyle.cardLight,
                                    ),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: BaseText(
                                      text: _mPublicProfileDataModel
                                          .result.tagline,
                                      textColor:
                                          AppConstants.colorStyle.lightPurple,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 16,
                                      maxLines: 2,
                                    ),
                                  ),
                                ),
                        ],
                      ))),
                  flex: 1,
                )
              ],
            )),
        (_mPublicProfileDataModel.result == null ||
                _mPublicProfileDataModel.result.recommendCount == null ||
                _mPublicProfileDataModel.result.recommendCount.toString() ==
                    "null")
            ? SizedBox()
            : Column(
                children: [
                  Divider(
                    color: AppConstants.colorStyle.dividerLine,
                    height: 1,
                  ),
                  Container(
                    color: AppConstants.colorStyle.bg,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Container(
                                decoration: BoxDecoration(
                                  border: Border(
                                    right: BorderSide(
                                        width: 0.8,
                                        color: ColorValues.HEADING_COLOR),
                                  ),
                                ),
                                child: PaddingWrap.paddingfromLTRB(
                                  5.0,
                                  0.0,
                                  5.0,
                                  0.0,
                                  Column(
                                    children: <Widget>[
                                      BaseText(
                                        text:
                                            _mAcoomplismentDataModel == null ||
                                                    _mPublicProfileDataModel ==
                                                        null ||
                                                    _mPublicProfileDataModel
                                                            .result ==
                                                        null ||
                                                    !_mPublicProfileDataModel
                                                        .result.isAccomplishment
                                                ? _mAcoomplismentDataModel
                                                    .toJsonLength()
                                                    .length
                                                    .toString()
                                                : _mAcoomplismentDataModel
                                                    .toJson()
                                                    .length
                                                    .toString(),
                                        textColor: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontFamily: AppConstants
                                            .stringConstant.latoRegular,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 24,
                                        maxLines: 2,
                                      ),
                                      InkWell(
                                        child: BaseText(
                                          text: "Experiences",
                                          textColor: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14,
                                          maxLines: 2,
                                        ),
                                        onTap: () {},
                                      )
                                    ],
                                  ),
                                )),
                            flex: 1,
                          ),
                          Expanded(
                            child: Container(
                                child: PaddingWrap.paddingfromLTRB(
                                    5.0,
                                    0.0,
                                    5.0,
                                    0.0,
                                    Column(
                                      children: <Widget>[
                                        BaseText(
                                          text: _mAcoomplismentDataModel ==
                                                      null ||
                                                  _mPublicProfileDataModel ==
                                                      null ||
                                                  _mPublicProfileDataModel
                                                          .result ==
                                                      null ||
                                                  !_mPublicProfileDataModel
                                                      .result.isRecommendation
                                              ? _mPublicProfileDataModel.result
                                                  .toJsonRecLength()
                                                  .length
                                                  .toString()
                                              : _mPublicProfileDataModel.result
                                                  .toJsonRec()
                                                  .length
                                                  .toString(),
                                          textColor: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w800,
                                          fontSize: 24,
                                          maxLines: 2,
                                        ),
                                        InkWell(
                                          child: BaseText(
                                            text: "Recommendations",
                                            textColor: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                            maxLines: 2,
                                          ),
                                          onTap: () {},
                                        )
                                      ],
                                    ))),
                            flex: 1,
                          )
                        ],
                      ),
                    ),
                  ),
                  Divider(
                    color: AppConstants.colorStyle.dividerLine,
                    height: 1,
                  ),
                ],
              ),
        (_mSpiderAndSkillDataModel != null &&
                    _mSpiderAndSkillDataModel.result != null) &&
                (_mSpiderAndSkillDataModel.result.spiderChart.length > 0 ||
                    _mSpiderAndSkillDataModel.result.skillChart.length > 0)
            ? SizedBox(
                height: 482,
                child: PageIndicatorContainer(
                  pageView: PageView.builder(
                    itemCount: 2,
                    controller: pageController,
                    itemBuilder: (context, index2) {
                      return index2 == 0
                          ? PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              30.0,
                              Container(
                                  child: Container(
                                      decoration:
                                          BoxDecoration(color: Colors.white),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Container(
                                              padding: EdgeInsets.all(0.0),
                                              width: 450,
                                              height: 450,
                                              child: Container(
                                                //Radar Chart
                                                child: RadarChart(
                                                  values: spiderChartList,
                                                  labels: spiderChartName,
                                                  maxWidth: 450,
                                                  maxLinesForLabels: 5,
                                                  labelWidth: 70,
                                                  strokeColor:
                                                      Color(0xffC4C4C4),
                                                  maxValue: 9,
                                                  animate: false,
                                                  textScaleFactor: 0.03,
                                                  size: Size.infinite,
                                                  fillColor: Color(0xffEB5757),
                                                  chartRadiusFactor: 0.6,
                                                  labelColor: Color(0xff666B9A),
                                                ),
                                              )),
                                        ],
                                      ))),
                            )
                          : PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              30.0,
                              Container(
                                  child: Container(
                                      padding: const EdgeInsets.fromLTRB(
                                          10.0, 0.0, 0.0, 10.0),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                      ),
                                      child: Column(
                                        // padding: const EdgeInsets.all(0.0),
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          SizedBox(
                                            height: 20,
                                          ),
                                          barList()
                                        ],
                                      ))));
                    },
                    onPageChanged: (index) {},
                  ),
                  align: IndicatorAlign.bottom,
                  length: 2,
                  indicatorSpace: 7.0,
                  indicatorColor: ColorValues.LIST_BOTTOM_BG,
                  indicatorSelectorColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
                  shape: IndicatorShape.roundRectangleShape(
                      size: Size(20.0, 5.0), cornerSize: const Size.square(6)),
                ))
            : PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        isSpiderChartApiCalled
                            ? Container(
                                padding: EdgeInsets.all(0.0),
                                height: 360.0,
                                width: double.infinity,
                                child: Container(
                                    child: Stack(
                                  children: <Widget>[
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Image.asset("assets/radar.png",
                                            width: double.infinity,
                                            height: 221),
                                      ],
                                    ),
                                  ],
                                )))
                            : Container(
                                height: 160.0,
                              )
                      ],
                    ))),
      ],
    );
  }

  Padding summaryView() {
    return PaddingWrap.paddingfromLTRB(
        20.0,
        20.0,
        20.0,
        10.0,
        Container(
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                color: ColorValues.LIST_BOTTOM_BG,
                borderRadius: new BorderRadius.only(
                    topLeft: const Radius.circular(10.0),
                    topRight: const Radius.circular(10.0)),
              ),
              child: Row(
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                      6.0,
                      10.0,
                      10.0,
                      10.0,
                      Image.asset(
                        "assets/newDesignIcon/icon/my_summary.png",
                        width: 35,
                        height: 35,
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      10.0,
                      BaseText(
                        text: 'Summary',
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w600,
                        fontSize: 18,
                        maxLines: 1,
                      )),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: ColorValues.SELECTION_BG,
                borderRadius: new BorderRadius.only(
                    bottomLeft: const Radius.circular(10.0),
                    bottomRight: const Radius.circular(10.0)),
              ),
              child: PaddingWrap.paddingfromLTRB(
                  17.0,
                  12.0,
                  17.0,
                  12.0,
                  Text(
                      _mPublicProfileDataModel.result == null ||
                              _mPublicProfileDataModel.result.summary == null ||
                              _mPublicProfileDataModel.result.summary == "null"
                          ? "No Information Available"
                          : _mPublicProfileDataModel.result.summary,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 100,
                      style: TextStyle(
                          fontFamily: Constant.latoMedium,
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontWeight: FontWeight.w500,
                          fontSize: 16.0))),
            ),
          ],
        )));
  }

  onTapShare() async {
    String result = await Navigator.of(context).push(
      new MaterialPageRoute(
        builder: (BuildContext context) => ShareProfileView(
          widget.link,
          _mPublicProfileDataModel.result.firstName,
          "custom",
          false,
        ),
      ),
    );
    if (result == "push") {
      Navigator.pop(context, "push");
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    final bottomBar = BottomAppBar(
      elevation: 15.0,
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border(
              top: BorderSide(color: ColorValues.BORDER_COLOR, width: 0.5),
            )),
        height: 90,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          child: Row(
            children: [
              Expanded(
                flex: 2,
                child: InkWell(
                  child: Container(
                    height: 45,
                    padding: EdgeInsets.symmetric(vertical: 11),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: ColorValues.WHITE,
                      border: Border.all(
                          color: ColorValues.BORDER_COLOR_NEW, width: 1.0),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: BaseText(
                      text: 'Edit',
                      textColor: AppConstants.colorStyle.lightPurple,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                    ),
                  ),
                  onTap: () async {
                    Navigator.pop(context);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 3,
                child: Stack(
                  children: [
                    InkWell(
                      child: Container(
                        height: 45,
                        padding: EdgeInsets.symmetric(vertical: 11),
                        decoration: BoxDecoration(
                          color: AppConstants.colorStyle.lightBlue,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: BaseText(
                          text: 'Share',
                          textColor: AppConstants.colorStyle.white,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w600,
                          fontSize: 18,
                          textAlign: TextAlign.center,
                          maxLines: 1,
                        ),
                      ),
                      onTap: () {
                        onTapShare();
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(new FocusNode());
      },
      child: Scaffold(
        bottomNavigationBar: bottomBar,
        backgroundColor: ColorValues.WHITE,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
                padding: const EdgeInsets.fromLTRB(20, 50, 20, 12),
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Image.asset(
                    "assets/new_onboarding/back_blue_icon.png",
                    height: 32.0,
                    width: 32.0,
                  ),
                )),
            Expanded(
              child: Container(
                color: Colors.white,
                child:
                    _mPublicProfileDataModel == null ||
                            _mPublicProfileDataModel.result == null
                        ? const SizedBox.shrink()
                        : ListView(
                            controller: _scrollController,
                            padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  headerUiDesign(),
                                  Column(
                                    children: <Widget>[
                                      !_mPublicProfileDataModel
                                              .result.isIntroVideo
                                          ? const SizedBox.shrink()
                                          : introductionViewUI(),
                                      _mPublicProfileDataModel.result == null ||
                                              _mPublicProfileDataModel
                                                      .result.summary ==
                                                  null ||
                                              _mPublicProfileDataModel
                                                      .result.summary
                                                      .trim() ==
                                                  "" ||
                                              _mPublicProfileDataModel
                                                      .result.summary ==
                                                  "null"
                                          ? const SizedBox.shrink()
                                          : !_mPublicProfileDataModel
                                                  .result.isSummary
                                              ? const SizedBox.shrink()
                                              : summaryView(),
                                      _mPublicProfileDataModel.result.educations
                                                      .colleges.length +
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .schools
                                                      .length ==
                                              0
                                          ? const SizedBox.shrink()
                                          : !_mPublicProfileDataModel
                                                  .result.isEducations
                                              ? const SizedBox.shrink()
                                              : _mPublicProfileDataModel
                                                          .result.educations
                                                          .toJson()
                                                          .length ==
                                                      0
                                                  ? const SizedBox.shrink()
                                                  : PaddingWrap.paddingfromLTRB(
                                                      20.0,
                                                      24.0,
                                                      20.0,
                                                      0.0,
                                                      Container(
                                                          child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0, 0, 0, 0),
                                                        child: Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: ColorValues
                                                                    .LIST_BOTTOM_BG,
                                                                borderRadius: new BorderRadius
                                                                        .only(
                                                                    topLeft: const Radius
                                                                            .circular(
                                                                        10.0),
                                                                    topRight: const Radius
                                                                            .circular(
                                                                        10.0)),
                                                              ),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .center,
                                                                    children: [
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          6.0,
                                                                          10.0,
                                                                          10.0,
                                                                          10.0,
                                                                          Image.asset(
                                                                            "assets/png/education.png",
                                                                            width:
                                                                                35,
                                                                            height:
                                                                                35,
                                                                          )),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          10.0,
                                                                          BaseText(
                                                                            text:
                                                                                'Education',
                                                                            textColor:
                                                                                ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                            fontFamily:
                                                                                AppConstants.stringConstant.latoMedium,
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                            fontSize:
                                                                                18,
                                                                            maxLines:
                                                                                1,
                                                                          ))
                                                                    ],
                                                                  ),
                                                                  SizedBox()
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: ColorValues
                                                                    .SELECTION_BG,
                                                                borderRadius: new BorderRadius
                                                                        .only(
                                                                    bottomLeft:
                                                                        const Radius.circular(
                                                                            10.0),
                                                                    bottomRight:
                                                                        const Radius.circular(
                                                                            10.0)),
                                                              ),
                                                              child: Column(
                                                                children: [
                                                                  _mPublicProfileDataModel
                                                                              .result
                                                                              .educations
                                                                              .schools
                                                                              .length >
                                                                          0
                                                                      ? Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          children: <
                                                                              Widget>[
                                                                            Column(
                                                                                children: List.generate(_mPublicProfileDataModel.result.educations.schools.length, (int index) {
                                                                              return getSchoolEducationListItem(index, _mPublicProfileDataModel.result.educations.schools);
                                                                            })),
                                                                          ],
                                                                        )
                                                                      : Container(),
                                                                  _mPublicProfileDataModel
                                                                              .result
                                                                              .educations
                                                                              .colleges
                                                                              .length >
                                                                          0
                                                                      ? Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          children: <
                                                                              Widget>[
                                                                            Column(
                                                                                children: List.generate(_mPublicProfileDataModel.result.educations.colleges.length, (int index) {
                                                                              return getCollegeEducationListItem(index, _mPublicProfileDataModel.result.educations.colleges);
                                                                            })),
                                                                          ],
                                                                        )
                                                                      : Container(),
                                                                  _mPublicProfileDataModel
                                                                              .result
                                                                              .educations ==
                                                                          null
                                                                      ? SizedBox()
                                                                      : Padding(
                                                                          padding:
                                                                              const EdgeInsets.all(12.0),
                                                                          child:
                                                                              InkWell(
                                                                            onTap:
                                                                                () {
                                                                              Util.onTapViewTimeLine(context,'other');
                                                                            },
                                                                            child:
                                                                                Center(
                                                                              child: BaseText(
                                                                                text: 'View timeline',
                                                                                textColor: Color(0xff4684EB),
                                                                                fontFamily: AppConstants.stringConstant.latoRegular,
                                                                                fontSize: 16,
                                                                                fontWeight: FontWeight.w600,
                                                                                maxLines: 1,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                ],
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                      ))),
                                      !_mPublicProfileDataModel
                                              .result.isTestScore
                                          ? const SizedBox.shrink()
                                          : _mPublicProfileDataModel.result
                                                      .toJsonTestScore()
                                                      .length ==
                                                  0
                                              ? const SizedBox.shrink()
                                              : PaddingWrap.paddingfromLTRB(
                                                  20.0,
                                                  24.0,
                                                  20.0,
                                                  0.0,
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: <Widget>[
                                                      Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorValues
                                                              .LIST_BOTTOM_BG,
                                                          borderRadius: new BorderRadius
                                                                  .only(
                                                              topLeft: const Radius
                                                                      .circular(
                                                                  10.0),
                                                              topRight: const Radius
                                                                      .circular(
                                                                  10.0)),
                                                        ),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: <Widget>[
                                                            Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: [
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        6.0,
                                                                        10.0,
                                                                        10.0,
                                                                        10.0,
                                                                        Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/icon/test_score.png",
                                                                          width:
                                                                              35,
                                                                          height:
                                                                              35,
                                                                        )),
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        10.0,
                                                                        0.0,
                                                                        10.0,
                                                                        BaseText(
                                                                          text:
                                                                              'Test score',
                                                                          textColor:
                                                                              ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                          fontFamily: AppConstants
                                                                              .stringConstant
                                                                              .latoMedium,
                                                                          fontWeight:
                                                                              FontWeight.w600,
                                                                          fontSize:
                                                                              18,
                                                                          maxLines:
                                                                              1,
                                                                        )),
                                                              ],
                                                            ),
                                                            SizedBox()
                                                          ],
                                                        ),
                                                      ),
                                                      Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorValues
                                                              .SELECTION_BG,
                                                          borderRadius: new BorderRadius
                                                                  .only(
                                                              bottomLeft:
                                                                  const Radius
                                                                          .circular(
                                                                      10.0),
                                                              bottomRight:
                                                                  const Radius
                                                                          .circular(
                                                                      10.0)),
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  12,
                                                                  0,
                                                                  12),
                                                          child:
                                                              Column(children: <
                                                                  Widget>[
                                                            PaddingWrap
                                                                .paddingfromLTRB(
                                                                    10.0,
                                                                    0.0,
                                                                    12.0,
                                                                    0.0,
                                                                    BaseText(
                                                                      text:
                                                                          "Your test scores remain private and are not visible to any of you connections. If you want to share them, please select them during the ‘Filter’ step.",
                                                                      textColor:
                                                                          ColorValues
                                                                              .HEADING_COLOR_EDUCATION_1,
                                                                      fontFamily: AppConstants
                                                                          .stringConstant
                                                                          .latoRegular,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                      fontSize:
                                                                          12,
                                                                    )),
                                                            Column(
                                                              children: List.generate(
                                                                  _mPublicProfileDataModel
                                                                      .result
                                                                      .testScores
                                                                      .length,
                                                                  (int index) {
                                                                return getTestScoreListItem(
                                                                    index);
                                                              }),
                                                            ),
                                                          ]),
                                                        ),
                                                      ),
                                                    ],
                                                  )),
                                      _mAcoomplismentDataModel == null
                                          ? const SizedBox.shrink()
                                          : !_mPublicProfileDataModel
                                                  .result.isAccomplishment
                                              ? const SizedBox.shrink()
                                              : Container(
                                                  margin:
                                                      const EdgeInsets.fromLTRB(
                                                          20, 24, 20, 0),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Container(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                6, 7, 6, 8),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorValues
                                                              .LIST_BOTTOM_BG,
                                                          borderRadius:
                                                              new BorderRadius
                                                                  .all(const Radius
                                                                      .circular(
                                                                  10.0)),
                                                        ),
                                                        child: Row(
                                                          children: [
                                                            Image.asset(
                                                              "assets/experience/ic_experience.png",
                                                              width: 35,
                                                              height: 35,
                                                            ),
                                                            const SizedBox(
                                                                width: 10),
                                                            BaseText(
                                                              text:
                                                                  'Experiences',
                                                              textColor: ColorValues
                                                                  .HEADING_COLOR_EDUCATION_1,
                                                              fontFamily: AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              fontSize: 18,
                                                              maxLines: 1,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                          height: 24),
                                                      ListView.separated(
                                                        itemBuilder: (_,
                                                                index) =>
                                                            _storyItem(
                                                                _mAcoomplismentDataModel
                                                                        .accomplimentData[
                                                                    index],
                                                                index),
                                                        separatorBuilder:
                                                            (_, index) =>
                                                                const SizedBox(
                                                                    height: 21),
                                                        itemCount:
                                                            _mAcoomplismentDataModel
                                                                    ?.accomplimentData
                                                                    ?.length ??
                                                                0,
                                                        shrinkWrap: true,
                                                        padding:
                                                            EdgeInsets.zero,
                                                        physics:
                                                            const NeverScrollableScrollPhysics(),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                      _mPublicProfileDataModel.result
                                                      .loveInterests.length >
                                                  0 ||
                                              _mPublicProfileDataModel.result
                                                      .goalInterests.length >
                                                  0
                                          ? !_mPublicProfileDataModel
                                                  .result.isInterests
                                              ? const SizedBox.shrink()
                                              : getUserInterestAndGoals()
                                          : const SizedBox.shrink(),
                                      !_mPublicProfileDataModel.result
                                                  .isSkillAndCertification ||
                                              (_mPublicProfileDataModel.result
                                                          .toJsonCertificate()
                                                          .length ==
                                                      0 &&
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .skills
                                                          .length ==
                                                      0)
                                          ? const SizedBox.shrink()
                                          : skillView(),
                                      _mPublicProfileDataModel.result.badges ==
                                                  null ||
                                              _mPublicProfileDataModel
                                                      .result
                                                      .badges
                                                      .collections
                                                      .length ==
                                                  0 ||
                                              (_mPublicProfileDataModel
                                                      .result
                                                      .badges
                                                      .collections
                                                      .length ==
                                                  0)
                                          ? const SizedBox.shrink()
                                          : !_mPublicProfileDataModel
                                                  .result.isBadges
                                              ? const SizedBox.shrink()
                                              : _mPublicProfileDataModel
                                                          .result.badges
                                                          .toJsonBadge()
                                                          .length ==
                                                      0
                                                  ? const SizedBox.shrink()
                                                  : Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          20, 24, 20, 0),
                                                      child: Container(
                                                        child: Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: ColorValues
                                                                    .LIST_BOTTOM_BG,
                                                                borderRadius: new BorderRadius
                                                                        .only(
                                                                    topLeft: const Radius
                                                                            .circular(
                                                                        10.0),
                                                                    topRight: const Radius
                                                                            .circular(
                                                                        10.0)),
                                                              ),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                children: <
                                                                    Widget>[
                                                                  Row(
                                                                    children: [
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          6.0,
                                                                          10.0,
                                                                          10.0,
                                                                          10.0,
                                                                          Image.asset(
                                                                            "assets/newDesignIcon/icon/badges_icon.png",
                                                                            width:
                                                                                35,
                                                                            height:
                                                                                35,
                                                                          )),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          10.0,
                                                                          BaseText(
                                                                            text:
                                                                                'Badges',
                                                                            textColor:
                                                                                ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                            fontFamily:
                                                                                AppConstants.stringConstant.latoMedium,
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                            fontSize:
                                                                                18,
                                                                            maxLines:
                                                                                1,
                                                                          )),
                                                                    ],
                                                                  ),
                                                                  SizedBox()
                                                                ],
                                                              ),
                                                            ),
                                                            badgeList2(),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                      _mPublicProfileDataModel.result == null ||
                                              _mPublicProfileDataModel
                                                      .result.recommendations ==
                                                  null ||
                                              _mPublicProfileDataModel.result
                                                      .recommendations.length ==
                                                  0
                                          ? const SizedBox.shrink()
                                          : !_mPublicProfileDataModel
                                                  .result.isRecommendation
                                              ? const SizedBox.shrink()
                                              : _mPublicProfileDataModel.result
                                                          .toJsonRec()
                                                          .length ==
                                                      0
                                                  ? const SizedBox.shrink()
                                                  : getRecommendation(),
                                      !_mPublicProfileDataModel
                                              .result.isDisplaySocialEmail
                                          ? const SizedBox.shrink()
                                          : PaddingWrap.paddingfromLTRB(
                                              20.0,
                                              24.0,
                                              20.0,
                                              0.0,
                                              Container(
                                                  child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .LIST_BOTTOM_BG,
                                                      borderRadius: new BorderRadius
                                                              .only(
                                                          topLeft: const Radius
                                                              .circular(10.0),
                                                          topRight: const Radius
                                                              .circular(10.0)),
                                                    ),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: <Widget>[
                                                        Row(
                                                          children: [
                                                            PaddingWrap
                                                                .paddingfromLTRB(
                                                                    6.0,
                                                                    10.0,
                                                                    10.0,
                                                                    10.0,
                                                                    Image.asset(
                                                                      "assets/newDesignIcon/icon/my_contact_info.png",
                                                                      width: 35,
                                                                      height:
                                                                          35,
                                                                    )),
                                                            PaddingWrap
                                                                .paddingfromLTRB(
                                                                    0.0,
                                                                    10.0,
                                                                    0.0,
                                                                    10.0,
                                                                    BaseText(
                                                                      text:
                                                                          'Contact information',
                                                                      textColor:
                                                                          ColorValues
                                                                              .HEADING_COLOR_EDUCATION_1,
                                                                      fontFamily: AppConstants
                                                                          .stringConstant
                                                                          .latoMedium,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      fontSize:
                                                                          18,
                                                                      maxLines:
                                                                          1,
                                                                    )),
                                                          ],
                                                        ),
                                                        SizedBox()
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .SELECTION_BG,
                                                      borderRadius: new BorderRadius
                                                              .only(
                                                          bottomLeft:
                                                              const Radius
                                                                      .circular(
                                                                  10.0),
                                                          bottomRight:
                                                              const Radius
                                                                      .circular(
                                                                  10.0)),
                                                    ),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  12.0,
                                                                  0,
                                                                  13,
                                                                  13),
                                                          child: Container(
                                                            child: Row(
                                                              children: [
                                                                Expanded(
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Image
                                                                              .asset(
                                                                            "assets/newDesignIcon/userprofile/Mail.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                  flex: 0,
                                                                ),
                                                                Expanded(
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          10.0,
                                                                          10.0,
                                                                          0.0,
                                                                          10.0,
                                                                          BaseText(
                                                                            text:
                                                                                _mPublicProfileDataModel.result.email,
                                                                            textColor:
                                                                                ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                            fontFamily:
                                                                                AppConstants.stringConstant.latoMedium,
                                                                            fontWeight:
                                                                                FontWeight.w400,
                                                                            fontSize:
                                                                                16,
                                                                            maxLines:
                                                                                1,
                                                                          )),
                                                                  flex: 1,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              ))),
                                      _mPublicProfileDataModel.result == null ||
                                              _mPublicProfileDataModel
                                                      .result.socialLinks ==
                                                  null
                                          ? const SizedBox.shrink()
                                          : !_mPublicProfileDataModel
                                                  .result.isSocialLinks
                                              ? const SizedBox.shrink()
                                              : _mPublicProfileDataModel.result
                                                          .toJsonLink()
                                                          .length ==
                                                      0
                                                  ? const SizedBox.shrink()
                                                  : PaddingWrap.paddingfromLTRB(
                                                      20.0,
                                                      24.0,
                                                      20.0,
                                                      0.0,
                                                      Container(
                                                          child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color: ColorValues
                                                                  .LIST_BOTTOM_BG,
                                                              borderRadius: new BorderRadius
                                                                      .only(
                                                                  topLeft:
                                                                      const Radius
                                                                              .circular(
                                                                          10.0),
                                                                  topRight:
                                                                      const Radius
                                                                              .circular(
                                                                          10.0)),
                                                            ),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: <
                                                                  Widget>[
                                                                Row(
                                                                  children: [
                                                                    PaddingWrap.paddingfromLTRB(
                                                                        6.0,
                                                                        10.0,
                                                                        10.0,
                                                                        10.0,
                                                                        Image.asset(
                                                                          "assets/newDesignIcon/icon/social_links.png",
                                                                          width:
                                                                              35,
                                                                          height:
                                                                              35,
                                                                        )),
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                            0.0,
                                                                            10.0,
                                                                            0.0,
                                                                            10.0,
                                                                            BaseText(
                                                                              text: 'Social links',
                                                                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                              fontFamily: AppConstants.stringConstant.latoMedium,
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize: 18,
                                                                              maxLines: 1,
                                                                            )),
                                                                  ],
                                                                ),
                                                                SizedBox()
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color: ColorValues
                                                                  .SELECTION_BG,
                                                              borderRadius: new BorderRadius
                                                                      .only(
                                                                  bottomLeft:
                                                                      const Radius
                                                                              .circular(
                                                                          10.0),
                                                                  bottomRight:
                                                                      const Radius
                                                                              .circular(
                                                                          10.0)),
                                                            ),
                                                            child: Container(
                                                              height: 45.0,
                                                              margin: EdgeInsets
                                                                  .only(
                                                                      left: 5,
                                                                      top: 10,
                                                                      bottom:
                                                                          10),
                                                              child: ListView(
                                                                scrollDirection:
                                                                    Axis.horizontal,
                                                                children: List.generate(
                                                                    _mPublicProfileDataModel
                                                                        .result
                                                                        .socialLinks
                                                                        .length,
                                                                    (int
                                                                        index) {
                                                                  return !_mPublicProfileDataModel
                                                                          .result
                                                                          .socialLinks[
                                                                              index]
                                                                          .isProfileDisplay
                                                                      ? Container(
                                                                          height:
                                                                              0.0,
                                                                        )
                                                                      : Padding(
                                                                          padding: const EdgeInsets.fromLTRB(
                                                                              5.0,
                                                                              4,
                                                                              5,
                                                                              4),
                                                                          child:
                                                                              ClipRRect(
                                                                            borderRadius:
                                                                                BorderRadius.circular(10.0),
                                                                            child:
                                                                                Container(
                                                                              height: 36,
                                                                              child: FadeInImage.assetNetwork(
                                                                                fit: BoxFit.fill,
                                                                                placeholder: 'assets/profile/img_default.png',
                                                                                image: Constant.IMAGE_PATH + _mPublicProfileDataModel.result.socialLinks[index].image,
                                                                                height: 35.0,
                                                                                width: 35.0,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        );
                                                                }),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ))),
                                      !_mPublicProfileDataModel.result.isResume
                                          ? const SizedBox.shrink()
                                          : _mPublicProfileDataModel
                                                          .result.resume !=
                                                      null &&
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .resume
                                                          .displayName !=
                                                      "null" &&
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .resume
                                                          .displayName !=
                                                      ""
                                              ? PaddingWrap.paddingfromLTRB(
                                                  20.0,
                                                  24.0,
                                                  20.0,
                                                  0.0,
                                                  Container(
                                                      child: Container(
                                                          child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorValues
                                                              .LIST_BOTTOM_BG,
                                                          borderRadius: new BorderRadius
                                                                  .only(
                                                              topLeft: const Radius
                                                                      .circular(
                                                                  10.0),
                                                              topRight: const Radius
                                                                      .circular(
                                                                  10.0)),
                                                        ),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: <Widget>[
                                                            Row(
                                                              children: [
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        6.0,
                                                                        10.0,
                                                                        10.0,
                                                                        10.0,
                                                                        Image
                                                                            .asset(
                                                                          "assets/profile/skills/ic_resume.png",
                                                                          width:
                                                                              35,
                                                                          height:
                                                                              35,
                                                                        )),
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        10.0,
                                                                        0.0,
                                                                        10.0,
                                                                        BaseText(
                                                                          text:
                                                                              'Resume',
                                                                          textColor:
                                                                              ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                          fontFamily: AppConstants
                                                                              .stringConstant
                                                                              .latoMedium,
                                                                          fontWeight:
                                                                              FontWeight.w600,
                                                                          fontSize:
                                                                              18,
                                                                          maxLines:
                                                                              1,
                                                                        )),
                                                              ],
                                                            ),
                                                            SizedBox()
                                                          ],
                                                        ),
                                                      ),
                                                      Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    0.0,
                                                                    0,
                                                                    0,
                                                                    0),
                                                            child: Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: ColorValues
                                                                    .SELECTION_BG,
                                                                borderRadius: new BorderRadius
                                                                        .only(
                                                                    bottomLeft:
                                                                        const Radius.circular(
                                                                            10.0),
                                                                    bottomRight:
                                                                        const Radius.circular(
                                                                            10.0)),
                                                              ),
                                                              child: Row(
                                                                children: [
                                                                  Expanded(
                                                                    child: PaddingWrap
                                                                        .paddingfromLTRB(
                                                                            10.0,
                                                                            10.0,
                                                                            0.0,
                                                                            10.0,
                                                                            Image.asset(
                                                                              "assets//newDesignIcon/icon/pdf_icon.png",
                                                                              height: 33.0,
                                                                              width: 33.0,
                                                                            )),
                                                                    flex: 0,
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: <
                                                                          Widget>[
                                                                        PaddingWrap.paddingfromLTRB(
                                                                            10.0,
                                                                            5.0,
                                                                            5.0,
                                                                            10.0,
                                                                            InkWell(
                                                                                onTap: () {
                                                                                  Util.launchUrl(_mPublicProfileDataModel.result.resume.uploadType, _mPublicProfileDataModel.result.resume.resumeUrl);
                                                                                },
                                                                                child: Text(
                                                                                  _mPublicProfileDataModel.result.resume.displayName,
                                                                                  maxLines: 1,
                                                                                  style: TextStyle(fontWeight: FontWeight.normal, color: ColorValues.BLUE_COLOR_BOTTOMBAR, fontFamily: Constant.TYPE_CUSTOMREGULAR, fontSize: 16.0),
                                                                                ))),
                                                                      ],
                                                                    ),
                                                                    flex: 1,
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  ))))
                                              : const SizedBox.shrink(),
                                      const SizedBox(height: 30),
                                    ],
                                  ),
                                ],
                              )
                            ],
                          ),
              ),
              flex: 1,
            )
          ],
        ),
      ),
    );
  }

  Widget _storyItem(AccomplimentData narrative, int mainIndex) {
    bool isAcc = false;
    for (Achievement acc in narrative.achievement) {
      if (acc.isProfileDisplay) {
        isAcc = true;
      }
    }

    return !isAcc
        ? const SizedBox.shrink()
        : Container(
            decoration: BoxDecoration(
              color: const Color(0xffF5F6FA),
              borderRadius: BorderRadius.circular(10),
            ),
            clipBehavior: Clip.antiAlias,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xffE8ECFF),
                  ),
                  child: Row(
                    children: [
                      BaseText(
                        text: narrative.name,
                        textColor: const Color(0xff27275A),
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                      ),
                    ],
                  ),
                ),
                ListView.separated(
                  itemBuilder: (_, index) {
                    final achieveItem = narrative.achievement[index];
                    int size = achieveItem.fileList.length;
                    return !achieveItem.isProfileDisplay
                        ? Container(
                            height: 0.0,
                          )
                        : Padding(
                            padding: const EdgeInsets.all(12),
                            child: achieveItem.type == "portfolio"
                                ? Container(
                                    clipBehavior: Clip.antiAlias,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SizedBox(
                                          height: 190,
                                          child: Stack(
                                            children: [
                                              achieveItem.fileList.length < 4
                                                  ? achieveItem.fileList
                                                              .length ==
                                                          0
                                                      ? ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                          child: Image.asset(
                                                            narrative.level1 ==
                                                                    "Sports"
                                                                ? "assets/portfolio/sport_default.png"
                                                                : "assets/portfolio/arts_default.png",
                                                            fit: BoxFit.fill,
                                                            height: 190,
                                                          ),
                                                        )
                                                      : isImageOrVideo(
                                                          achieveItem.fileList[
                                                              size - 1],
                                                          190.0,
                                                          narrative.level1)
                                                  : Container(
                                                      color: Colors.black,
                                                      child: Column(
                                                        children: [
                                                          Row(
                                                            children: [
                                                              Expanded(
                                                                child: isImageOrVideo(
                                                                    achieveItem
                                                                            .fileList[
                                                                        size -
                                                                            1],
                                                                    95.0,
                                                                    narrative
                                                                        .level1),
                                                                flex: 1,
                                                              ),
                                                              Expanded(
                                                                child: isImageOrVideo(
                                                                    achieveItem
                                                                            .fileList[
                                                                        size -
                                                                            2],
                                                                    95.0,
                                                                    narrative
                                                                        .level1),
                                                                flex: 1,
                                                              )
                                                            ],
                                                          ),
                                                          Row(
                                                            children: [
                                                              Expanded(
                                                                child: isImageOrVideo(
                                                                    achieveItem
                                                                            .fileList[
                                                                        size -
                                                                            3],
                                                                    95.0,
                                                                    narrative
                                                                        .level1),
                                                                flex: 1,
                                                              ),
                                                              Expanded(
                                                                child: isImageOrVideo(
                                                                    achieveItem
                                                                            .fileList[
                                                                        size -
                                                                            4],
                                                                    95.0,
                                                                    narrative
                                                                        .level1),
                                                                flex: 1,
                                                              )
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                              Positioned(
                                                left: 0,
                                                right: 0,
                                                bottom: 0,
                                                top: 0,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                      gradient:
                                                          const LinearGradient(
                                                    colors: [
                                                      Color(0xff000000),
                                                      Color(0x7A000000),
                                                      Color(0xB5000000),
                                                    ],
                                                    begin: Alignment.topCenter,
                                                    end: Alignment.bottomCenter,
                                                  )),
                                                ),
                                              ),
                                              Positioned(
                                                left: 14,
                                                top: 16,
                                                right: 10,
                                                child: Row(
                                                  children: [
                                                    Center(
                                                      child: ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        child:
                                                            CachedNetworkImage(
                                                          imageUrl: Constant
                                                                  .IMAGE_PATH +
                                                              achieveItem
                                                                  .userImage,
                                                          fit: BoxFit.cover,
                                                          height: 54,
                                                          width: 54,
                                                          placeholder:
                                                              (context, url) =>
                                                                  Image.asset(
                                                            "assets/profile/user_on_user.png",
                                                            height: 54,
                                                            width: 54,
                                                          ),
                                                          errorWidget: (context,
                                                                  url, error) =>
                                                              Image.asset(
                                                            "assets/profile/user_on_user.png",
                                                            height: 54,
                                                            width: 54,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 8),
                                                    Expanded(
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          BaseText(
                                                            text: achieveItem
                                                                .title,
                                                            fontSize: 16,
                                                            textColor:
                                                                Colors.white,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            fontFamily: Constant
                                                                .latoRegular,
                                                            maxLines: 1,
                                                          ),
                                                          const SizedBox(
                                                              height: 4),
                                                          BaseText(
                                                            text:
                                                                "${achieveItem?.city ?? ''}, ${achieveItem?.state ?? ''}",
                                                            fontSize: 14,
                                                            textColor:
                                                                Colors.white,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            fontFamily: Constant
                                                                .latoRegular,
                                                            maxLines: 1,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                    CustomPortFolioDetailsView(
                                                  achieveItem: achieveItem,
                                                  levelOneName:
                                                      narrative.level1,
                                                ),
                                              ),
                                            );
                                          },
                                          child: Container(
                                            color: const Color(0xff27275A),
                                            padding: const EdgeInsets.fromLTRB(
                                                12, 7, 12, 12),
                                            alignment: Alignment.center,
                                            child: BaseText(
                                              text: narrative.level1 == "Sports"
                                                  ? "View sports portfolio"
                                                  : "View arts portfolio",
                                              fontSize: 16,
                                              textColor: Colors.white,
                                              fontWeight: FontWeight.w600,
                                              fontFamily: Constant.latoRegular,
                                              maxLines: 1,
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                : Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        clipBehavior: Clip.antiAlias,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        height: 184,
                                        child: achieveItem
                                                .mediaAndVideoList.isNotEmpty
                                            ? PageIndicatorContainer(
                                                pageView: PageView.builder(
                                                  itemCount: achieveItem
                                                      .mediaAndVideoList.length,
                                                  controller: PageController(),
                                                  itemBuilder: (_, innerIndex) {
                                                    return InkWell(
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                        ),
                                                        child: achieveItem
                                                                    .mediaAndVideoList[
                                                                        innerIndex]
                                                                    .type ==
                                                                "image"
                                                            ? CachedNetworkImage(
                                                                width: double
                                                                    .infinity,
                                                                height: 184,
                                                                imageUrl: Constant
                                                                        .IMAGE_PATH +
                                                                    achieveItem
                                                                        .mediaAndVideoList[
                                                                            innerIndex]
                                                                        .file,
                                                                fit: BoxFit
                                                                    .cover,
                                                                placeholder: (context,
                                                                        url) =>
                                                                    Util.loader(
                                                                        context,
                                                                        "assets/aerial/default_img.png"),
                                                                errorWidget: (context,
                                                                        url,
                                                                        error) =>
                                                                    Util.error(
                                                                        "assets/aerial/default_img.png"),
                                                              )
                                                            : Center(
                                                                child: VideoPlayPauseNew(
                                                                    achieveItem
                                                                        .mediaAndVideoList[
                                                                            innerIndex]
                                                                        .file,
                                                                    "",
                                                                    false,
                                                                    _scrollController),
                                                              ),
                                                      ),
                                                      onTap: () {
                                                        Navigator.of(context)
                                                            .push(
                                                          MaterialPageRoute(
                                                            builder: (BuildContext
                                                                    context) =>
                                                                CommonFullViewWidget(
                                                              achieveItem
                                                                  .mediaAndVideoList,
                                                              MessageConstant
                                                                  .ACCOMPLISHMENT_HEDING,
                                                              innerIndex,
                                                              achieveItem.title,
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                    );
                                                  },
                                                  onPageChanged: (index) {},
                                                ),
                                                align: IndicatorAlign.bottom,
                                                length: achieveItem
                                                    .mediaAndVideoList.length,
                                                indicatorSpace: 10.0,
                                                indicatorColor: achieveItem
                                                            .mediaAndVideoList
                                                            .length ==
                                                        1
                                                    ? Colors.transparent
                                                    : const Color(0xffc4c4c4),
                                                indicatorSelectorColor:
                                                    achieveItem.mediaAndVideoList
                                                                .length ==
                                                            1
                                                        ? Colors.transparent
                                                        : const Color(
                                                            0XFFFFFFFF),
                                                shape: IndicatorShape.circle(
                                                    size: 5.0),
                                              )
                                            : Image.asset(
                                                "assets/profile/default_achievement.png",
                                                fit: BoxFit.cover,
                                                height: 184,
                                                width: double.infinity,
                                              ),
                                      ),
                                      const SizedBox(height: 8),
                                      RichText(
                                        textAlign: TextAlign.start,
                                        maxLines: 15,
                                        text: TextSpan(
                                          text: achieveItem.focusArea == null ||
                                                  achieveItem.focusArea ==
                                                      "null" ||
                                                  achieveItem.focusArea == ""
                                              ? achieveItem.level3Competency +
                                                  " | "
                                              : achieveItem.focusArea + " | ",
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 16,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          children: [
                                            TextSpan(
                                              text: achieveItem.title,
                                              style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16,
                                                fontFamily:
                                                    Constant.latoRegular,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      BaseText(
                                        text:
                                            "${Util.getConvertedDateStamp2(achieveItem.fromDate.toString())} - ${Util.getConvertedDateStamp2(achieveItem.toDate.toString())}",
                                        textColor: const Color(0xff666B9A),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        fontFamily: Constant.latoRegular,
                                        maxLines: 1,
                                      ),
                                      achieveItem.hoursWorkedPerWeek != null &&
                                              achieveItem.hoursWorkedPerWeek !=
                                                  "null" &&
                                              achieveItem.hoursWorkedPerWeek
                                                      .trim() !=
                                                  ""
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.only(top: 6),
                                              child: BaseText(
                                                text:
                                                "Hours worked per week ${achieveItem?.hoursWorkedPerWeek ?? ''}",
                                                textColor:
                                                    const Color(0xff666B9A),
                                                fontWeight: FontWeight.w400,
                                                fontSize: 12,
                                                fontFamily:
                                                    Constant.latoRegular,
                                                maxLines: 1,
                                              ),
                                            )
                                          : const SizedBox.shrink(),
                                      const SizedBox(height: 5),
                                      ReadMoreTextWidget(
                                        text: achieveItem.description,
                                      ),
                                      achieveItem.all_badge_trophy_certificate
                                              .isNotEmpty
                                          ? Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                const SizedBox(height: 11),
                                                BaseText(
                                                  text:
                                                      "Certificates, trophies & badges",
                                                  textColor:
                                                      const Color(0xff27275A),
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 14,
                                                  fontFamily:
                                                      Constant.latoRegular,
                                                  maxLines: 1,
                                                ),
                                                const SizedBox(height: 7),
                                                SingleChildScrollView(
                                                  scrollDirection:
                                                      Axis.horizontal,
                                                  child: Row(
                                                    children: achieveItem
                                                        .all_badge_trophy_certificate
                                                        .map((e) {
                                                      return Container(
                                                        margin: const EdgeInsets
                                                            .only(right: 10),
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                        ),
                                                        //padding: const EdgeInsets.fromLTRB(9, 2, 8, 2),
                                                        child: InkWell(
                                                          child:
                                                              CachedNetworkImage(
                                                            height: 51,
                                                            width: 64,
                                                            imageUrl: Constant
                                                                    .IMAGE_PATH +
                                                                e.file,
                                                            fit: BoxFit.cover,
                                                            placeholder: (context,
                                                                    url) =>
                                                                Util.loader(
                                                                    context,
                                                                    "assets/profile/default_achievement.png"),
                                                            errorWidget: (context,
                                                                    url,
                                                                    error) =>
                                                                Util.error(
                                                                    "assets/profile/default_achievement.png"),
                                                          ),
                                                          onTap: () {
                                                            Navigator.of(
                                                                    context)
                                                                .push(
                                                              new MaterialPageRoute(
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    CommonFullViewWidget(
                                                                  achieveItem
                                                                      .all_badge_trophy_certificate,
                                                                  MessageConstant
                                                                      .CERTIFICATES_TROPHIES_HEDING,
                                                                  achieveItem
                                                                      .all_badge_trophy_certificate
                                                                      .indexOf(
                                                                          e),
                                                                  MessageConstant
                                                                      .CERTIFICATES_TROPHIES_HEDING,
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        ),
                                                      );
                                                    }).toList(),
                                                  ),
                                                ),
                                              ],
                                            )
                                          : const SizedBox.shrink(),
                                      Visibility(
                                          visible: achieveItem
                                              .externalLinks.isNotEmpty,
                                          child:
                                              _showExternalLinks(achieveItem)),
                                    ],
                                  ),
                          );
                  },
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: narrative.achievement?.length ?? 0,
                  separatorBuilder: (_, index) => const SizedBox(height: 12),
                ),
              ],
            ),
          );
  }

  Widget _showExternalLinks(Achievement achieveItem) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListView.separated(
          itemCount: achieveItem.externalLinks.length,
          itemBuilder: (_, exIndex) {
            final exItem = achieveItem.externalLinks[exIndex];
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BaseText(
                  text: "External links:",
                  textColor: const Color(0xff27275A),
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  fontFamily: Constant.latoRegular,
                  maxLines: 1,
                ),
                const SizedBox(height: 7),
                InkWell(
                  onTap: () {
                    if (exItem.url.toLowerCase().contains("https") ||
                        exItem.url.toLowerCase().contains("http")) {
                      launch(exItem.url.trim());
                    } else {
                      launch("https://" + exItem.url.trim());
                    }
                  },
                  child: BaseText(
                    text: exItem.label,
                    textColor: const Color(0xff4684EB),
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                    fontFamily: Constant.latoRegular,
                    maxLines: 3,
                    textDecoration: TextDecoration.underline,
                  ),
                ),
                const SizedBox(height: 11),
                BaseText(
                  text: "External description:",
                  textColor: const Color(0xff27275A),
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  fontFamily: Constant.latoRegular,
                  maxLines: 1,
                ),
                const SizedBox(height: 5),
                ReadMoreTextWidget(
                  text: exItem.description,
                  textStyle: TextStyle(
                    color: Color(0xff666B9A),
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            );
          },
          separatorBuilder: (_, ind) => const SizedBox(height: 10),
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(0, 11, 0, 0),
          physics: const NeverScrollableScrollPhysics(),
        ),
      ],
    );
  }

  Container getSchoolEducationListItem(index, schoolsInfoList) {
    return !_mPublicProfileDataModel
            .result.educations.schools[index].isProfileDisplay
        ? Container(
            height: 0.0,
          )
        : Container(
            child: InkWell(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                12.0,
                13.0,
                0.0,
                Container(
                  height: 84,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: int.parse(schoolsInfoList[index].fromYear) ==
                                DateTime.now().year ||
                            int.parse(schoolsInfoList[index].toYear) ==
                                DateTime.now().year ||
                            setRange(schoolsInfoList[index].fromYear,
                                schoolsInfoList[index].toYear)
                        ? AppConstants.colorStyle.education_bg_green
                        : Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(12)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 12.0, top: 12, bottom: 12, right: 4),
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                            //color: Colors.transparent,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                BaseText(
                                  text: schoolsInfoList[index].institute,
                                  textColor:
                                      ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  maxLines: 2,
                                ),
                                SizedBox(
                                  height: 4,
                                ),
                                RichText(
                                  maxLines: 15,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: schoolsInfoList[index].toYear ==
                                                null ||
                                            schoolsInfoList[index].toYear ==
                                                "null" ||
                                            schoolsInfoList[index].toYear == ""
                                        ? schoolsInfoList[index].fromYear +
                                            " - " +
                                            "Ongoing" +
                                            " | "
                                        : schoolsInfoList[index].fromYear +
                                            " - " +
                                            schoolsInfoList[index].toYear +
                                            " | ",
                                    style: TextStyle(
                                        color:
                                            AppConstants.colorStyle.lightPurple,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: Constant.latoRegular,
                                        fontSize: 13.0),
                                    children: [
                                      TextSpan(
                                          text: schoolsInfoList[index]
                                                  .fromGrade +
                                              " - " +
                                              schoolsInfoList[index].toGrade,
                                          style: TextStyle(
                                              color: AppConstants
                                                  .colorStyle.lightPurple,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant.latoRegular,
                                              fontSize: 13.0)),
                                      TextSpan(
                                          text: schoolsInfoList[index].gpa !=
                                                      null &&
                                                  schoolsInfoList[index].gpa !=
                                                      ''
                                              ? " | GPA: " +
                                                  schoolsInfoList[index]
                                                      .gpa
                                                      .toString()
                                              : '',
                                          style: TextStyle(
                                              color: AppConstants
                                                  .colorStyle.lightPurple,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant.latoRegular,
                                              fontSize: 13.0)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          flex: 1,
                        ),
                        Expanded(
                          child: Image.asset(
                            'assets/new_onboarding/l1.png',
                            height: 68,
                            width: 72,
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                  ),
                )),
            onTap: () {},
          ));
  }

  Container getCollegeEducationListItem(index, collegesInfoList) {
    return !_mPublicProfileDataModel
            .result.educations.colleges[index].isProfileDisplay
        ? Container(
            height: 0.0,
          )
        : Container(
            child: InkWell(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                12.0,
                13.0,
                0.0,
                Container(
                  height: 84,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: int.parse(collegesInfoList[index].fromYear) ==
                                DateTime.now().year ||
                            int.parse(collegesInfoList[index].toYear) ==
                                DateTime.now().year ||
                            setRange(collegesInfoList[index].fromYear,
                                collegesInfoList[index].toYear)
                        ? AppConstants.colorStyle.education_bg_green
                        : Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(12)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 12.0, top: 12, bottom: 12, right: 4),
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                            //color: Colors.transparent,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                BaseText(
                                  text: collegesInfoList[index].institute,
                                  textColor:
                                      ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  maxLines: 2,
                                ),
                                SizedBox(
                                  height: 4,
                                ),
                                Row(
                                  children: [
                                    BaseText(
                                      text: collegesInfoList[index].toYear ==
                                                  null ||
                                              collegesInfoList[index].toYear ==
                                                  "null" ||
                                              collegesInfoList[index].toYear ==
                                                  ""
                                          ? collegesInfoList[index].fromYear +
                                              " - " +
                                              "Ongoing"
                                          : collegesInfoList[index].fromYear +
                                              " - " +
                                              collegesInfoList[index].toYear,
                                      textColor:
                                          AppConstants.colorStyle.lightPurple,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 13,
                                      maxLines: 2,
                                    ),
                                    BaseText(
                                      text: " | " +
                                          collegesInfoList[index].degree,
                                      textColor:
                                          AppConstants.colorStyle.lightPurple,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 13,
                                      maxLines: 2,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          flex: 1,
                        ),
                        Expanded(
                          child: Image.asset(
                            'assets/new_onboarding/l1.png',
                            height: 68,
                            width: 72,
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                  ),
                )),
            onTap: () {},
          ));
  }

  setRange(String fromYear, String toYear) {
    DateTime dateD = DateTime.now();
    //DateTime now = DateTime.now();

    String convertedDateTime =
        "$fromYear-${dateD.month.toString().padLeft(2, '0')}-${dateD.day.toString().padLeft(2, '0')} ${dateD.hour.toString().padLeft(2, '0')}-${dateD.minute.toString().padLeft(2, '0')}";
    String convertedDateTime1 =
        "$toYear-${dateD.month.toString().padLeft(2, '0')}-${dateD.day.toString().padLeft(2, '0')} ${dateD.hour.toString().padLeft(2, '0')}-${dateD.minute.toString().padLeft(2, '0')}";

    if (DateTime.parse(convertedDateTime).isBefore(dateD) &&
        DateTime.parse(convertedDateTime1).isAfter(dateD)) {
      return true;
    } else {
      return false;
    }
  }

  Container getSchoolEducationListItem22(index) {
    return !_mPublicProfileDataModel
            .result.educations.schools[index].isProfileDisplay
        ? Container(
            height: 0.0,
          )
        : Container(
            child: InkWell(
            child: PaddingWrap.paddingfromLTRB(
                17.0,
                0.0,
                13.0,
                10.0,
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          10.0,
                          0.0,
                          _mPublicProfileDataModel.result.educations
                                          .schools[index].logo ==
                                      "" ||
                                  _mPublicProfileDataModel.result.educations
                                          .schools[index].logo ==
                                      "null"
                              ? Image.asset(
                                  "assets/profile/img_default.png",
                                  height: 37.0,
                                  width: 37.0,
                                )
                              : InkWell(
                                  onTap: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                FullImageView(
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .schools[index]
                                                      .logo,
                                                  pageName: MessageConstant
                                                      .EDUCATION_HEDING,
                                                )));
                                  },
                                  child: CachedNetworkImage(
                                    height: 37.0,
                                    width: 37.0,
                                    imageUrl: Constant.IMAGE_PATH +
                                        _mPublicProfileDataModel.result
                                            .educations.schools[index].logo,
                                    fit: BoxFit.cover,
                                    placeholder: (context, url) => _loader(
                                        context,
                                        "assets/profile/img_default.png'"),
                                    errorWidget: (context, url, error) =>
                                        _error(
                                            "assets/profile/img_default.png'"),
                                  ))),
                      flex: 0,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              Text(
                                _mPublicProfileDataModel
                                    .result.educations.schools[index].institute,
                                maxLines: 5,
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: ColorValues.HEADING_COLOR_EDUCATION,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 16.0),
                              )),
                          RichText(
                            maxLines: 15,
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              text: _mPublicProfileDataModel.result.educations
                                              .schools[index].toYear ==
                                          null ||
                                      _mPublicProfileDataModel.result.educations
                                              .schools[index].toYear ==
                                          "null" ||
                                      _mPublicProfileDataModel.result.educations
                                              .schools[index].toYear ==
                                          ""
                                  ? _mPublicProfileDataModel.result.educations
                                          .schools[index].fromYear +
                                      " - " +
                                      "Ongoing" +
                                      " | "
                                  : _mPublicProfileDataModel.result.educations
                                          .schools[index].fromYear +
                                      " - " +
                                      _mPublicProfileDataModel.result.educations
                                          .schools[index].toYear +
                                      " | ",
                              style: TextStyle(
                                  color: ColorValues.GREY__COLOR,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 14.0),
                              children: [
                                TextSpan(
                                    text: _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .schools[index]
                                            .fromGrade +
                                        " - " +
                                        _mPublicProfileDataModel.result
                                            .educations.schools[index].toGrade,
                                    style: TextStyle(
                                        color: ColorValues.GREY__COLOR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0)),
                                TextSpan(
                                    text:
                                        _mPublicProfileDataModel.result.isGpa &&
                                                _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .schools[index]
                                                        .gpa !=
                                                    null &&
                                                _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .schools[index]
                                                        .gpa !=
                                                    ''
                                            ? " | GPA: " +
                                                _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .schools[index]
                                                    .gpa
                                                    .toString()
                                            : '',
                                    style: TextStyle(
                                        color: ColorValues.GREY__COLOR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                  ],
                )),
            onTap: () {},
            /*onLongPress: () {
              if (widget.isEditable) {
                showDialogDeleteAchievment(userEducationList[index].educationId,
                    userEducationList[index].institute, index);
              }
            },*/
          ));
  }

  Container getCollegeEducationListItem22(index) {
    return !_mPublicProfileDataModel
            .result.educations.colleges[index].isProfileDisplay
        ? Container(
            height: 0.0,
          )
        : Container(
            child: InkWell(
            child: PaddingWrap.paddingfromLTRB(
                17.0,
                0.0,
                13.0,
                10.0,
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          10.0,
                          0.0,
                          _mPublicProfileDataModel.result.educations
                                          .colleges[index].logo ==
                                      "" ||
                                  _mPublicProfileDataModel.result.educations
                                          .colleges[index].logo ==
                                      "null"
                              ? Image.asset(
                                  "assets/profile/img_default.png",
                                  height: 37.0,
                                  width: 37.0,
                                )
                              : InkWell(
                                  onTap: () {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                FullImageView(
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .colleges[index]
                                                      .logo,
                                                  pageName: MessageConstant
                                                      .EDUCATION_HEDING,
                                                )));
                                  },
                                  child: CachedNetworkImage(
                                    height: 37.0,
                                    width: 37.0,
                                    imageUrl: Constant.IMAGE_PATH +
                                        _mPublicProfileDataModel.result
                                            .educations.colleges[index].logo,
                                    fit: BoxFit.cover,
                                    placeholder: (context, url) => _loader(
                                        context,
                                        "assets/profile/img_default.png'"),
                                    errorWidget: (context, url, error) =>
                                        _error(
                                            "assets/profile/img_default.png'"),
                                  )) /*new Container(
                                  height: 37.0,
                                  width: 37.0,
                                  child: FadeInImage.assetNetwork(
                                    fit: BoxFit.cover,
                                    placeholder:
                                        'assets/profile/img_default.png',
                                    image: Constant.IMAGE_PATH +
                                        _mPublicProfileDataModel.result
                                            .educations.colleges[index].logo,
                                  ))*/
                          ),
                      flex: 0,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              Text(
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].institute,
                                maxLines: 5,
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: ColorValues.HEADING_COLOR_EDUCATION,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 16.0),
                              )),
                          /*         _mPublicProfileDataModel.result.educations
                                          .colleges[index].degree !=
                                      null &&
                                  _mPublicProfileDataModel.result.educations
                                          .colleges[index].degree !=
                                      "null" &&
                                  _mPublicProfileDataModel.result.educations
                                          .colleges[index].degree !=
                                      ""
                              ? RichText(
                                  maxLines: 15,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: _mPublicProfileDataModel.result
                                            .educations.colleges[index].degree +
                                        ", ",
                                    style:   TextStyle(
                                        color:
                                              ColorValues.GREY__COLOR,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                    children: [
                                        TextSpan(
                                          text: _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .colleges[index]
                                                      .degree !=
                                                  'Professional Certificate'
                                              ? "Major: " +
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .colleges[index]
                                                      .major
                                              */ /*" | " +
                                    collegesInfoList[index].minor*/ /*
                                              : "Certification Name: " +
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .colleges[index]
                                                      .certifications,
                                          style:   TextStyle(
                                              color:   ColorValues.GREY__COLOR,
                                              fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 14.0)),
                                        TextSpan(
                                          text: _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .colleges[index]
                                                          .minor !=
                                                      '' &&
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .colleges[index]
                                                          .minor !=
                                                      null &&
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .colleges[index]
                                                          .minor !=
                                                      'null' &&
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .colleges[index]
                                                          .degree !=
                                                      'Professional Certificate'
                                              ? ", Minor: " +
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .colleges[index]
                                                      .minor
                                              */ /*" | " +
                                    collegesInfoList[index].minor*/ /*
                                              : '',
                                          style:   TextStyle(
                                              color:   ColorValues.GREY__COLOR,
                                              fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 14.0)),
                                    ],
                                  ),
                                )
                              : Container(
                                  width: 0,
                                  height: 0,
                                ),*/

                          _mPublicProfileDataModel.result.educations
                                          .colleges[index].degree !=
                                      null &&
                                  _mPublicProfileDataModel.result.educations
                                          .colleges[index].degree !=
                                      "null" &&
                                  _mPublicProfileDataModel.result.educations
                                          .colleges[index].degree !=
                                      ""
                              ? Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    RichText(
                                      maxLines: 15,
                                      textAlign: TextAlign.start,
                                      text: TextSpan(
                                        text: _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .degree, //+ ", ",
                                        style: TextStyle(
                                            color: ColorValues.GREY__COLOR,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0),
                                      ),
                                    ),
                                    Text(
                                        _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .degree !=
                                                'Professional Certificate'
                                            ? "Major: " +
                                                _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .major
                                                    .trim()
                                            /*" | " +
                                    collegesInfoList[index].minor*/
                                            : "Certification Name: " +
                                                _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .certifications
                                                    .trim(),
                                        style: TextStyle(
                                            color: ColorValues.GREY__COLOR,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0)),
                                    _mPublicProfileDataModel.result.educations
                                                    .colleges[index].minor !=
                                                '' &&
                                            _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .minor !=
                                                null &&
                                            _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .minor !=
                                                'null' &&
                                            _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .degree !=
                                                'Professional Certificate'
                                        ? Text(
                                            "Minor: " +
                                                _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .minor
                                                    .trim(),
                                            /*" | " +
                                    collegesInfoList[index].minor*/

                                            style: TextStyle(
                                                color: ColorValues.GREY__COLOR,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                fontSize: 14.0))
                                        : Container(
                                            width: 0,
                                            height: 0,
                                          ),
                                  ],
                                )
                              : Container(
                                  width: 0,
                                  height: 0,
                                ),
                          Row(
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Text(
                                    _mPublicProfileDataModel.result.educations
                                                    .colleges[index].toYear ==
                                                null ||
                                            _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .toYear ==
                                                "null" ||
                                            _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .toYear ==
                                                ""
                                        ? _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .fromYear +
                                            " - " +
                                            "Ongoing"
                                        : _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .fromYear +
                                            " - " +
                                            _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .toYear,
                                    style: TextStyle(
                                        color: ColorValues.GREY__COLOR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  )),
                              /* PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                    Text(
                                    _mPublicProfileDataModel.result.educations
                                        .colleges[index].graduationYear,
                                    style:   TextStyle(
                                        color:
                                              ColorValues.GREY__COLOR,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  )),*/
                              _mPublicProfileDataModel.result.isGpa &&
                                      _mPublicProfileDataModel.result.educations
                                              .colleges[index].gpa !=
                                          null &&
                                      _mPublicProfileDataModel.result.educations
                                              .colleges[index].gpa !=
                                          ''
                                  ? PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                      Text(
                                        _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .gpa !=
                                                null
                                            ? " | GPA: " +
                                                _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .gpa
                                                    .toString()
                                            : '',
                                        style: TextStyle(
                                            color: ColorValues.GREY__COLOR,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0),
                                      ))
                                  : Container(
                                      height: 0.0,
                                    ),
                            ],
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                  ],
                )),
            onTap: () {},
            /*onLongPress: () {
              if (widget.isEditable) {
                showDialogDeleteAchievment(userEducationList[index].educationId,
                    userEducationList[index].institute, index);
              }
            },*/
          ));
  }

  Container getTestScoreListItem(index) {
    return Container(
        child: PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            0.0,
            0.0,
            Column(
                children: List.generate(
                    _mPublicProfileDataModel
                        .result.testScores[index].scores.length, (index3) {
              return !_mPublicProfileDataModel
                      .result.testScores[index].scores[index3].isProfileDisplay
                  ? Container(
                      height: 0.0,
                    )
                  : PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      0.0,
                      0.0,
                      Container(
                        decoration: BoxDecoration(
                          color: ColorValues.WHITE,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        margin: EdgeInsets.only(
                            left: 12, right: 12, top: 5, bottom: 5),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 12.0, right: 12.0, top: 12),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    flex: 1,
                                    child: BaseText(
                                      text: _mPublicProfileDataModel
                                          .result.testScores[index].name,
                                      textColor:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 16,
                                      maxLines: 3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                                padding: const EdgeInsets.only(
                                    left: 12.0, right: 12.0, bottom: 12),
                                child: Container(
                                    child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Column(
                                        children: List.generate(
                                            _mPublicProfileDataModel
                                                .result
                                                .testScores[index]
                                                .scores[index3]
                                                .subjects
                                                .length, (index2) {
                                      return Padding(
                                          padding:
                                              const EdgeInsets.only(top: 9.0),
                                          child: Container(
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      5.0,
                                                      0.0,
                                                      0.0,
                                                      Row(
                                                        children: <Widget>[
                                                          Expanded(
                                                            child: BaseText(
                                                              text: _mPublicProfileDataModel
                                                                  .result
                                                                  .testScores[
                                                                      index]
                                                                  .scores[
                                                                      index3]
                                                                  .subjects[
                                                                      index2]
                                                                  .subject,
                                                              textColor: ColorValues
                                                                  .HEADING_COLOR_EDUCATION_1,
                                                              fontFamily: AppConstants
                                                                  .stringConstant
                                                                  .latoRegular,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontSize: 14,
                                                              maxLines: 3,
                                                            ),
                                                            flex: 1,
                                                          ),
                                                          Expanded(
                                                            child: BaseText(
                                                              text: _mPublicProfileDataModel
                                                                  .result
                                                                  .testScores[
                                                                      index]
                                                                  .scores[
                                                                      index3]
                                                                  .subjects[
                                                                      index2]
                                                                  .score
                                                                  .toString(),
                                                              textColor: ColorValues
                                                                  .HEADING_COLOR_EDUCATION_1,
                                                              fontFamily: AppConstants
                                                                  .stringConstant
                                                                  .latoRegular,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              fontSize: 16,
                                                              maxLines: 3,
                                                            ),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      ))));
                                    })),
                                  ],
                                ))),
                            PaddingWrap.paddingfromLTRB(
                                12.0,
                                0.0,
                                12.0,
                                16.0,
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          9.0,
                                          0.0,
                                          0.0,
                                          BaseText(
                                            text: getConvertedDateStamp2(
                                                _mPublicProfileDataModel
                                                    .result
                                                    .testScores[index]
                                                    .scores[index3]
                                                    .dateTaken
                                                    .toString()),
                                            textColor: ColorValues.labelColor,
                                            fontFamily: AppConstants
                                                .stringConstant.latoItalic,
                                            fontWeight: FontWeight.w400,
                                            fontSize: 12,
                                            maxLines: 3,
                                          )),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: _mPublicProfileDataModel
                                                      .result
                                                      .testScores[index]
                                                      .scores[index3]
                                                      .docUrl
                                                      .length >
                                                  0 ||
                                              _mPublicProfileDataModel
                                                      .result
                                                      .testScores[index]
                                                      .scores[index3]
                                                      .imageUrl
                                                      .length >
                                                  0
                                          ? InkWell(
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      9.0,
                                                      0.0,
                                                      0.0,
                                                      BaseText(
                                                        text: 'View attachment',
                                                        textColor: ColorValues
                                                            .HEADING_COLOR_EDUCATION_2,
                                                        fontFamily: AppConstants
                                                            .stringConstant
                                                            .latoRegular,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 12,
                                                        maxLines: 3,
                                                      )),
                                              onTap: () {
                                                var score =
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .testScores[index]
                                                        .scores[index3];

                                                ScoreDataModel model =
                                                    ScoreDataModel(
                                                        sId: score.sId,
                                                        userTestId:
                                                            score.userTestId,
                                                        testId: score.testId,
                                                        userId: score.userId,
                                                        dateTaken:
                                                            score.dateTaken,
                                                        imageUrl:
                                                            score.imageUrl,
                                                        docUrl: score.docUrl,
                                                        name: score.name,
                                                        subjects:
                                                            score.subjects,
                                                        isProfileDisplay: score
                                                            .isProfileDisplay);
                                                Navigator.of(context).push(
                                                    new MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                            DocumentPerformance(
                                                              null,
                                                              model: model,
                                                              subjectName: score
                                                                          .subjects
                                                                          .length ==
                                                                      1
                                                                  ? score
                                                                      .subjects[
                                                                          0]
                                                                      .subject
                                                                  : '',
                                                            )));
                                              },
                                            )
                                          : SizedBox(),
                                      flex: 0,
                                    ),
                                  ],
                                )),
                          ],
                        ),
                      ));
            }))));
  }

  badgeList2() {
    return Container(
      decoration: BoxDecoration(
        color: ColorValues.SELECTION_BG,
        borderRadius: new BorderRadius.only(
            bottomLeft: const Radius.circular(10.0),
            bottomRight: const Radius.circular(10.0)),
      ),
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 5),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List.generate(
                    _mPublicProfileDataModel.result.badges.collections.length,
                    (int index) {
                  return !_mPublicProfileDataModel
                          .result.badges.collections[index].isProfileDisplay
                      ? Container(
                          height: 0.0,
                        )
                      : Column(
                          children: <Widget>[
                            Container(
                              decoration: BoxDecoration(
                                color: ColorValues.WHITE,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              margin: EdgeInsets.only(
                                  top: 6, bottom: 6, left: 10, right: 10),
                              padding: EdgeInsets.only(
                                  top: 9, bottom: 9, left: 9, right: 5),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    flex: 0,
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 0.0,
                                          top: 7.0,
                                          right: 10.0,
                                          bottom: 7.0),
                                      child: Container(
                                        height: 78.0,
                                        width: 76.0,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                              color: ColorValues
                                                  .BORDER_GENERATE_SCRIPT),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(12)),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(3.0),
                                              child: FadeInImage.assetNetwork(
                                                fit: BoxFit.contain,
                                                placeholder:
                                                    'assets/profile/user_on_user.png',
                                                image: Constant
                                                        .IMAGE_PATH_SMALL +
                                                    ParseJson.getMediumImage(
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .badges
                                                            .collections[index]
                                                            .image),
                                                height: 94.0,
                                                width: 86.0,
                                              )),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Expanded(
                                          flex: 0,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                top: 3, bottom: 4),
                                            child: Text(
                                              _mPublicProfileDataModel
                                                  .result
                                                  .badges
                                                  .collections[index]
                                                  .name
                                                  .toString(),
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w600,
                                                fontFamily:
                                                    Constant.latoRegular,
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 0,
                                          child: _mPublicProfileDataModel
                                                      .result
                                                      .badges
                                                      .collections[index]
                                                      .companyName
                                                      .toString() ==
                                                  ""
                                              ? new Container(height: 0.0)
                                              : Text(
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .badges
                                                      .collections[index]
                                                      .companyName
                                                      .toString(),
                                                  style: TextStyle(
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    color:
                                                        ColorValues.labelColor,
                                                  ),
                                                ),
                                        ),
                                        Expanded(
                                          flex: 0,
                                          child: InkWell(
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.only(top: 4),
                                              child: Text(
                                                _mPublicProfileDataModel
                                                                .result
                                                                .badges
                                                                .collections[
                                                                    index]
                                                                .type ==
                                                            "request" &&
                                                        _mPublicProfileDataModel
                                                                .result
                                                                .badges
                                                                .collections[
                                                                    index]
                                                                .status ==
                                                            "accepted"
                                                    ? 'Issued on: ' +
                                                        getConvertedDateStamp2(
                                                            _mPublicProfileDataModel
                                                                .result
                                                                .badges
                                                                .collections[
                                                                    index]
                                                                .date
                                                                .toString())
                                                    : 'Issued on: ' +
                                                        getConvertedDateStamp2(
                                                            _mPublicProfileDataModel
                                                                .result
                                                                .badges
                                                                .collections[
                                                                    index]
                                                                .date
                                                                .toString()),
                                                style: TextStyle(
                                                  color: ColorValues.labelColor,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  fontFamily:
                                                      Constant.latoRegular,
                                                ),
                                              ),
                                            ),
                                            onTap: () {},
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        );
                })),
          ),
        ],
      ),
    );
  }

  Widget getRecommendation() {
    return PaddingWrap.paddingfromLTRB(
        20.0,
        24.0,
        20.0,
        0.0,
        Container(
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                color: ColorValues.LIST_BOTTOM_BG,
                borderRadius: new BorderRadius.only(
                    topLeft: const Radius.circular(10.0),
                    topRight: const Radius.circular(10.0)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Row(
                    children: [
                      PaddingWrap.paddingfromLTRB(
                          6.0,
                          10.0,
                          10.0,
                          10.0,
                          Image.asset(
                            "assets/profile/skills/ic_recommendation.png",
                            width: 35,
                            height: 35,
                          )),
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          10.0,
                          0.0,
                          10.0,
                          BaseText(
                            text: 'Recommendations',
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w600,
                            fontSize: 18,
                            maxLines: 1,
                          )),
                    ],
                  ),
                  SizedBox()
                ],
              ),
            ),
            Container(
                decoration: BoxDecoration(
                  color: ColorValues.SELECTION_BG,
                  borderRadius: new BorderRadius.only(
                      bottomLeft: const Radius.circular(10.0),
                      bottomRight: const Radius.circular(10.0)),
                ),
                child: Column(
                  children: [
                    _mPublicProfileDataModel
                                ?.result?.recommendations?.isNotEmpty ??
                            false
                        ? ListView.separated(
                            itemBuilder: (_, index) {
                              final item = _mPublicProfileDataModel
                                  .result.recommendations[index];
                              return _recommendationItem(item, index);
                            },
                            separatorBuilder: (_, index) =>
                                const SizedBox(height: 0),
                            itemCount: (_mPublicProfileDataModel
                                ?.result?.recommendations?.length),
                            shrinkWrap: true,
                            padding: EdgeInsets.symmetric(
                                horizontal: 12, vertical: 12),
                            physics: const NeverScrollableScrollPhysics(),
                          )
                        : const SizedBox.shrink(),
                  ],
                ))
          ],
        )));
  }

  Widget _recommendationItem(Recommendations item, int index) {
    return !item.isProfileDisplay
        ? Container(
            height: 0.0,
          )
        : Padding(
            padding: const EdgeInsets.only(top: 10.0),
            child: Container(
              padding: EdgeInsets.fromLTRB(12, 12, 12, 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  item.recommenderFile != "null" && item.recommenderFile != ""
                      ? InkWell(
                          onTap: () {
                            launch(Constant.IMAGE_PATH + item.recommenderFile);
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 14),
                            child: Row(
                              children: [
                                Image.asset(
                                  'assets/recommendation/ic_list_recommendation.png',
                                  width: 16,
                                  height: 20,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: BaseText(
                                    text: 'Recommendation letter',
                                    textColor: Color(0xff4684EB),
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : const SizedBox.shrink(),
                  const SizedBox(height: 12),
                  ReadMoreText(
                    item.stage == "Added" || item.stage == "Replied"
                        ? item.recommendation ?? ''
                        : item.request,
                    trimLines: 3,
                    delimiter: '..',
                    colorClickableText: Color(0xff4684EB),
                    style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                    trimMode: TrimMode.Line,
                    trimCollapsedText: 'More',
                    trimExpandedText: '',
                    delimiterStyle: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                    moreStyle: TextStyle(
                      color: Color(0xff4684EB),
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  const SizedBox(height: 12),
                  BaseText(
                    text:
                        "${item?.recommender[0]?.firstName ?? ''} ${item?.recommender[0]?.lastName ?? ''}",
                    textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    maxLines: 1,
                  ),
                  const SizedBox(height: 5),
                  BaseText(
                    text: '${item.title ?? ''}',
                    textColor: ColorValues.labelColor,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    maxLines: 1,
                  ),
                  const SizedBox(height: 11),
                  Divider(
                    height: 0,
                    thickness: 1,
                    color: Color(0xffE8ECFF),
                  ),
                  const SizedBox(height: 11),
                  item?.level3Competency?.toString() != 'null' &&
                      (item?.level3Competency?.isNotEmpty ?? false)
                      ? Row(
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'For',
                              textColor: ColorValues.labelColor,
                              fontFamily: AppConstants.stringConstant.latoRegular,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              maxLines: 1,
                            ),
                            const SizedBox(height: 5),
                            BaseText(
                              text: item?.level3Competency?.toString() !=
                                  'null' &&
                                  item?.level3Competency?.isNotEmpty ??
                                  false
                                  ? "${item.level3Competency}"
                                  : '',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily: AppConstants.stringConstant.latoRegular,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              maxLines: 1,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'Sent On:',
                              textColor: ColorValues.labelColor,
                              fontFamily: AppConstants.stringConstant.latoRegular,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              maxLines: 1,
                            ),
                            const SizedBox(height: 5),
                            BaseText(
                              text: Util.getConvertedDateStampNew(
                                  item.requestedDate),
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily: AppConstants.stringConstant.latoRegular,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              maxLines: 1,
                            ),
                          ],
                        ),
                      ),
                    ],
                  )
                      : Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Expanded(
                      //   child: Column(
                      //     mainAxisSize: MainAxisSize.min,
                      //     crossAxisAlignment: CrossAxisAlignment.start,
                      //     children: [
                      //       BaseText(
                      //         text: item.title,
                      //         textColor: ColorValues.labelColor,
                      //         fontFamily: AppConstants.stringConstant.latoRegular,
                      //         fontSize: 12,
                      //         fontWeight: FontWeight.w500,
                      //         maxLines: 1,
                      //       ),
                      //       const SizedBox(height: 5),
                      //
                      //     ],
                      //   ),
                      // ),

                      BaseText(
                        text: 'Sent On:',
                        textColor: ColorValues.labelColor,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        maxLines: 1,
                      ),
                      const SizedBox(height: 5),
                      BaseText(
                        text: Util.getConvertedDateStampNew(item.requestedDate),
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        maxLines: 1,
                      ),
                    ],
                  ),
                  /*
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'For',
                              textColor: ColorValues.labelColor,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              maxLines: 1,
                            ),
                            const SizedBox(height: 5),
                            BaseText(
                              text: item?.level3Competency?.toString() !=
                                          'null' &&
                                      (item?.level3Competency?.isNotEmpty ??
                                          false)
                                  ? "${item.level3Competency}"
                                  : 'N/A',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              maxLines: 1,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'Sent On:',
                              textColor: ColorValues.labelColor,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              maxLines: 1,
                            ),
                            const SizedBox(height: 5),
                            BaseText(
                              text: Util.getConvertedDateStampNew(
                                  item.requestedDate),
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              maxLines: 1,
                            ),
                          ],
                        ),
                      ),
                    ],
                  )

                   */
                ],
              ),
            ),
          );
  }

  Widget skillView() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: ColorValues.LIST_BOTTOM_BG,
              borderRadius: new BorderRadius.only(
                  topLeft: const Radius.circular(10.0),
                  topRight: const Radius.circular(10.0)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Row(
                  children: [
                    PaddingWrap.paddingfromLTRB(
                        6.0,
                        10.0,
                        10.0,
                        10.0,
                        Image.asset(
                          "assets/newDesignIcon/icon/skills_certi.png",
                          width: 35,
                          height: 35,
                        )),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        BaseText(
                          text: 'Skills & certifications',
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w600,
                          fontSize: 18,
                          maxLines: 1,
                        )),
                  ],
                ),
                SizedBox()
              ],
            ),
          ),
          Container(
            width: double.maxFinite,
            decoration: BoxDecoration(
              color: ColorValues.SELECTION_BG,
              borderRadius: new BorderRadius.only(
                  bottomLeft: const Radius.circular(10.0),
                  bottomRight: const Radius.circular(10.0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                _mPublicProfileDataModel.result != null &&
                        _mPublicProfileDataModel.result.skills != null &&
                        _mPublicProfileDataModel.result.skills.length > 0
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          PaddingWrap.paddingfromLTRB(
                              17.0,
                              10.0,
                              0.0,
                              0.0,
                              TextViewWrap.textViewSingleLine(
                                  "Skills",
                                  TextAlign.start,
                                  ColorValues.HEADING_COLOR_EDUCATION,
                                  16.0,
                                  FontWeight.w500)),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(13, 12, 13, 16),
                            child: _skillsItem(
                                _mPublicProfileDataModel.result.skills),
                          ),
                        ],
                      )
                    : const SizedBox.shrink(),
                _mPublicProfileDataModel.result.toJsonCertificate().length == 0
                    ? const SizedBox.shrink()
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          PaddingWrap.paddingfromLTRB(
                              17.0,
                              10.0,
                              0.0,
                              0.0,
                              TextViewWrap.textViewSingleLine(
                                  "Certifications",
                                  TextAlign.start,
                                  ColorValues.HEADING_COLOR_EDUCATION,
                                  16.0,
                                  FontWeight.w500)),
                          Column(
                            children: List.generate(
                              _mPublicProfileDataModel
                                  .result.certificates.length,
                              (int index) {
                                return !_mPublicProfileDataModel.result
                                        .certificates[index].isProfileDisplay
                                    ? const SizedBox.shrink()
                                    : getCertificateItem(index);
                              },
                            ),
                          ),
                        ],
                      )
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _skillsItem(skills) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: List<Widget>.generate(skills.length, (index) {
        return Container(
          padding: const EdgeInsets.fromLTRB(10, 7, 10, 7),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            '${skills[index].name}',
            style: const TextStyle(
              fontSize: 12.0,
              fontFamily: Constant.latoRegular,
              fontWeight: FontWeight.w400,
              color: const Color(0xff4684EB),
            ),
          ),
        );
      }).toList(),
    );
  }

  Container getCertificateItem(index) {
    return Container(
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          borderRadius: BorderRadius.circular(10),
        ),
        margin: EdgeInsets.only(top: 10, bottom: 10, left: 12, right: 12),
        child: InkWell(
          child: PaddingWrap.paddingfromLTRB(
              5.0,
              8.0,
              5.0,
              8.0,
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        7.0,
                        3.0,
                        10.0,
                        5.0,
                        _mPublicProfileDataModel
                                        .result.certificates[index].image ==
                                    "" ||
                                _mPublicProfileDataModel
                                        .result.certificates[index].image ==
                                    "null"
                            ? Image.asset(
                                "assets/portfolio/certificate.png",
                                height: 28.0,
                                width: 23.0,
                              )
                            : InkWell(
                                child: Container(
                                    height: 28.0,
                                    width: 23.0,
                                    child: FadeInImage.assetNetwork(
                                      fit: BoxFit.cover,
                                      placeholder:
                                          'assets/portfolio/certificate.png',
                                      image: Constant.IMAGE_PATH +
                                          _mPublicProfileDataModel
                                              .result.certificates[index].image,
                                    )),
                                onTap: () {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          FullImageView(_mPublicProfileDataModel
                                              .result
                                              .certificates[index]
                                              .image)));
                                },
                              )),
                    flex: 0,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            5.0,
                            0.0,
                            5.0,
                            0.0,
                            Text(
                              _mPublicProfileDataModel
                                  .result.certificates[index].title,
                              maxLines: 5,
                              style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.CERTIFICATE_TEXT_COLOR,
                                  fontFamily: Constant.latoMedium,
                                  fontSize: 10.0),
                            )),
                        PaddingWrap.paddingfromLTRB(
                            5.0,
                            0.0,
                            0.0,
                            0.0,
                            Text(
                              'Received on: ' +
                                  Util.getConvertedDateStamp(
                                      _mPublicProfileDataModel
                                          .result.certificates[index].date
                                          .toString()),
                              style: TextStyle(
                                  color:
                                      ColorValues.CERTIFICATE_DATE_TEXT_COLOR,
                                  fontFamily: Constant.latoRegular,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 8.0),
                            )),
                      ],
                    ),
                    flex: 1,
                  ),
                ],
              )),
          onTap: () {},
        ));
  }

  Container getSelectedWidgets() {
    return Container(
      //color: Colors.redAccent,
      child: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: ListView(
          physics: const NeverScrollableScrollPhysics(),
          primary: true,
          shrinkWrap: true,
          children: <Widget>[
            Wrap(
              spacing: 5.0,
              runSpacing: 0.0,
              children: List<Widget>.generate(
                  _mPublicProfileDataModel.result.skills.length,
                  // place the length of the array here
                  (int index) {
                //int h = _items[index].name.toString().length % 36;
                //print('Height h:::: $h');
                return InputChip(
                  label: Text(
                    '${_mPublicProfileDataModel.result.skills[index].name}',
                    overflow: TextOverflow.clip,
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  // softWrap: true,maxLines: 100,
                  //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  backgroundColor: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                  shape: StadiumBorder(
                    side: BorderSide(
                      color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                    ),
                  ),
                  onSelected: (bool value) {},

                  labelStyle: TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16,
                  ),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 5.0, vertical: 3.0),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget getUserInterestAndGoals() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 24, 20, 0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: ColorValues.LIST_BOTTOM_BG,
              borderRadius: new BorderRadius.only(
                  topLeft: const Radius.circular(10.0),
                  topRight: const Radius.circular(10.0)),
            ),
            child: Row(
              children: [
                PaddingWrap.paddingfromLTRB(
                    6.0,
                    10.0,
                    10.0,
                    10.0,
                    Image.asset(
                      "assets/newDesignIcon/icon/intrest_icon.png",
                      width: 35,
                      height: 35,
                    )),
                Expanded(
                  child: BaseText(
                    text: 'Interests ',
                    textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                    maxLines: 1,
                  ),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: ColorValues.SELECTION_BG,
              borderRadius: new BorderRadius.only(
                  bottomLeft: const Radius.circular(10.0),
                  bottomRight: const Radius.circular(10.0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _mPublicProfileDataModel.result.goalInterests.length > 0
                    ? PaddingWrap.paddingfromLTRB(
                        17.0,
                        10.0,
                        17.0,
                        5.0,
                        TextViewWrap.textViewSingleLine(
                            "Interests",
                            TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.w500))
                    : const SizedBox.shrink(),
                PaddingWrap.paddingfromLTRB(
                  17.0,
                  12.0,
                  17.0,
                  16.0,
                  getUserInterestChips(
                      _mPublicProfileDataModel.result.loveOtherInterests),
                ),
                _mPublicProfileDataModel.result.goalInterests.length > 0
                    ? Padding(
                        padding: const EdgeInsets.fromLTRB(17, 0, 17, 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Divider(
                              color: const Color(0xffE8ECFF),
                              thickness: 1,
                              height: 0,
                            ),
                            const SizedBox(height: 10),

                            TextViewWrap.textViewSingleLine(
                              'Future goals',
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              16.0,
                              FontWeight.w500,
                            ),
                            const SizedBox(height: 10),
                            TextViewWrap.textViewSingleLine(
                              "What’s next after high school?",
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              16.0,
                              FontWeight.w500,
                            ),
                            const SizedBox(height: 12),
                            getUserInterestChips(
                                _mPublicProfileDataModel.result.goalInterests),
                            _mPublicProfileDataModel
                                            .result.goalInterestInstitute !=
                                        null &&
                                    _mPublicProfileDataModel
                                            .result.goalInterestInstitute !=
                                        'null' &&
                                    _mPublicProfileDataModel
                                            .result.goalInterestInstitute !=
                                        ''
                                ? PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    16.0,
                                    0.0,
                                    12.0,
                                    TextViewWrap.textViewSingleLine(
                                        "Institute(s)",
                                        TextAlign.start,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                        16.0,
                                        FontWeight.w500))
                                : const SizedBox.shrink(),
                            _mPublicProfileDataModel
                                            .result.goalInterestInstitute !=
                                        null &&
                                    _mPublicProfileDataModel
                                            .result.goalInterestInstitute !=
                                        'null' &&
                                    _mPublicProfileDataModel
                                            .result.goalInterestInstitute !=
                                        ''
                                ? TextViewWrap.textViewSingleLine(
                                    "${_mPublicProfileDataModel.result.goalInterestInstitute}",
                                    TextAlign.start,
                                    ColorValues.HEADING_COLOR_EDUCATION,
                                    14.0,
                                    FontWeight.normal,
                                  )
                                : const SizedBox.shrink(),
                            const SizedBox(height: 12),
                          ],
                        ),
                      )
                    : const SizedBox.shrink(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  getUserInterestChips(List<SkillID> _items) {
    return _items != null
        ? MediaQuery.removePadding(
            context: context,
            removeTop: true,
            removeBottom: true,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              primary: true,
              shrinkWrap: true,
              children: <Widget>[
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: List<Widget>.generate(
                      _items.length, // place the length of the array here
                      (int index) {
                    return Container(
                      padding: const EdgeInsets.fromLTRB(10, 7, 10, 7),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Visibility(
                            visible:
                                (_items[index]?.image?.isNotEmpty ?? false) &&
                                    _items[index]?.image != 'null',
                            child: Padding(
                              padding: const EdgeInsets.only(right: 5),
                              child: SvgPicture.network(
                                Constant.IMAGE_PATH +
                                    ParseJson.getMediumImage(
                                        _items[index].image),
                                width: 16,
                                height: 16,
                                color: AppConstants.colorStyle.lightBlue,
                                placeholderBuilder: (context) => Container(
                                    width: 16,
                                    height: 16,
                                    alignment: Alignment.center,
                                    child: const CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                    )), //placeholder while downloading file.
                              ),
                            ),
                          ),
                          Text(
                            '${_items[index].name}',
                            style: const TextStyle(
                              fontSize: 12.0,
                              fontFamily: Constant.latoRegular,
                              fontWeight: FontWeight.w500,
                              color: Color(0xff4684EB),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          )
        : Container(
            height: 0,
            width: 0,
          );
  }

  Widget isImageOrVideo(FileDataModel _mPortFolioAssest, heigt, type) {
    return _mPortFolioAssest.type == "image"
        ? Container(
            height: heigt,
            child: CachedNetworkImage(
              width: double.infinity,
              height: heigt,
              imageUrl: Constant.IMAGE_PATH + _mPortFolioAssest.filePath,
              fit: BoxFit.cover,
              placeholder: (context, url) => _loader(
                  context,
                  type == "Sports"
                      ? "assets/portfolio/sport_default.png"
                      : "assets/portfolio/arts_default.png"),
              errorWidget: (context, url, error) => _error(type == "Sports"
                  ? "assets/portfolio/sport_default.png"
                  : "assets/portfolio/arts_default.png"),
            ))
        : Container(
            height: heigt,
            width: double.infinity,
            child: VideoView(
              Constant.IMAGE_PATH + _mPortFolioAssest.filePath,
              "",
              false,
              type,
            ));
  }

  getVideoThumb(path, int index) async {
    final thumbnailFile =
        await uploadMedia.getVideoThumbnailFromUrl(Constant.IMAGE_PATH + path);
    return Image.file(
      thumbnailFile,
      fit: BoxFit.contain,
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      //  var formatter =   DateFormat('MMM dd, yyyy');
      //return formatter.format(new DateTime.now());
      return "Ongoing";
    }
  }

  void getShowExternalLinks(List<AccomplimentData> narrativeList) {
    if (narrativeList != null && narrativeList.length > 0) {
      for (var item in narrativeList) {
        //[index1].achivmentList[index].externalLinksList
        for (var ach in item.achievement) {
          for (var link in ach.externalLinks) {
            if (link.url.toString().trim() != '' &&
                link.url.toString().trim() != 'null') {
              setState(() {
                ach.showExternalLinkText = true;
              });
              break;
            }
          }
        }
      }
      setState(() {});
    }
  }
}
