// Updated COde

import 'dart:async';

import 'package:flutter/gestures.dart';
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';
import 'dart:convert';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/gateway/TakeATour.dart';
import 'package:spike_view_project/gateway/parent_signup/parent_proofile_view.dart';
import 'package:spike_view_project/gateway/partner_signup/partner_profile_view.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/common/crashlytics_widget.dart';

import 'Login_Widget.dart';

class EmailVerification extends StatefulWidget {
  static String tag = 'login-page';
  String sasToken = '';
  ProfileInfoModal profileInfoModal;
  final LoginRole loginRole;
  final String firstName;
  final String lastName;
  final String email;
  final bool isRedirectToRecommendation;
  final String pageName;

  EmailVerification(
    this.profileInfoModal,
    this.sasToken, {
    @required this.loginRole,
    this.firstName,
    this.lastName,
    this.email,
    this.isRedirectToRecommendation,
    this.pageName,
  });

  @override
  EmailVerificationState createState() => EmailVerificationState();
}

final formKey = GlobalKey<FormState>();
String _email = "";
bool _isLoading = false;

class EmailVerificationState extends State<EmailVerification> {
  Color borderColor = Colors.amber;
  SharedPreferences prefs;
  String roleId, userId, email;

  void _checkValidation() {
    final form = formKey.currentState;
    setState(() => _isLoading = true);
    form.save();
    if (form.validate()) {
      forgotpassworApiCalling();
    } else {
      setState(() => _isLoading = false);
      print("Failure 00");
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userId = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    email = prefs.getString(UserPreference.EMAIL);
  }

  @override
  void initState() {
    getSharedPreferences();
    _timerStart();
    super.initState();
  }

  onBack() {
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginPage(null)));
  }

  showSucessMsg(msg, context, push) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");
      Navigator.pop(context);
      if (push) {
        apiCallingUpdate();
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  forgotpassworApiCalling() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data

        var map = {
          "userId": userId,
          "verificationType": "emailOTP",
          "otp": _code
        };
        print('map+++$map');
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_OTP_VERIFICATION,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            print("stage++++++++" + widget.profileInfoModal.stage.toString());
            if (widget.profileInfoModal.stage == null ||
                widget.profileInfoModal.stage == 'null' ||
                widget.profileInfoModal.stage == '' ||
                int.parse(widget.profileInfoModal.stage) < 5) {
              apiCallingUpdate();
            } else {
              Navigator.of(context).popUntil((route) => route.isFirst);
              Navigator.of(context).pushReplacement(new MaterialPageRoute(
                  builder: (BuildContext context) => DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE))));
            }

            // showSucessMsg(message, context, true);
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          setState(() => _isLoading = false);
          // If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
        CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      setState(() => _isLoading = false);
      // CustomProgressLoader.cancelLoader(context);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  resendOtpApi() async {
    if (_second == 0) {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        try {
          CustomProgressLoader.showLoader(context);
          var dio = Dio();
          dio.onHttpClientCreate = (HttpClient client) {
            client.badCertificateCallback =
                (X509Certificate cert, String host, int port) {
              return true;
            };
          };
          dio.options.baseUrl = Constant.BASE_URL;
          dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
          dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
          dio.options.headers = {'user-agent': 'dio'};
          dio.options.headers = {'Accept': 'application/json'};
          dio.options.headers = {'Content-Type': 'application/json'};
          // Prepare Data

          var map = {"userId": userId, "email": email, "type": "emailOTP","actionType": "resend"};
          print('map+++$map');
          // Make API call
          Response response = await dio.post(Constant.ENDPOINT_OTP_RESEND,
              data: json.encode(map));
          CustomProgressLoader.cancelLoader(context);
          setState(() => _isLoading = false);
          print(response.toString());
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String message = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              _timerStart();
              //  showSucessMsg(message, context, false);
            } else {
              ToastWrap.showToastLongNew(message, context);
            }
          } else {
            //  CustomProgressLoader.cancelLoader(context);
            setState(() => _isLoading = false);
            // If that call was not successful, throw an error.
            throw Exception('Something went wrong!!');
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
          CustomProgressLoader.cancelLoader(context);
          print(e);
          ToastWrap.showToast(e.toString(), context);
        }
      } else {
        setState(() => _isLoading = false);
        // CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    }
  }

  Future apiCallingUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {"userId": userId, "stage": "1"};
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            print("update data+++ apiCallingUpdate");
            if (status == "Success") {
              Navigator.of(context).popUntil((route) => route.isFirst);
              switch (widget.loginRole) {
                case LoginRole.student:
                  if (widget.profileInfoModal.profileCreatedByParent != null &&
                      widget.profileInfoModal.profileCreatedByParent) {
                    StudentOnBoarding().getStudentOnBoardingInit(
                        context,
                        widget.profileInfoModal,
                        widget.sasToken,
                        widget.profileInfoModal.userId);
                  } else {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => TakeATour(
                                widget.profileInfoModal, widget.sasToken)));
                  }

                  break;
                case LoginRole.parent:
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return ParentProfileView(
                          signUpUsing: SignUpUsing.email,
                          isRedirectToRecommendation:
                              widget.isRedirectToRecommendation,
                        );
                      },
                    ),
                  );
                  break;
                case LoginRole.partner:
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PartnerProfileView(
                        signUpUsing: SignUpUsing.email,
                        pageName: widget.pageName,
                        lastName: widget.lastName,
                        firstName: widget.firstName,
                        email: widget.email,
                        action: PartnerProfileAction.add,
                        isRedirectToRecommendation:
                            widget.isRedirectToRecommendation,
                      ),
                    ),
                  );
                  break;
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  bool _onEditing = true;
  String _code = '';

  onTapSignOut() async {
    // setState(() {
    Constant.isAlreadyLoggedIn = false;
    //});
    try {
      Map map = {
        "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
        "deviceId": prefs.getString("deviceId")
      };
      GlobalSocketConnection.socket
          .emitWithAck("disconnect1", [map]).then((data) {
        print("chat-login++++" + data.toString());
      });

      GlobalSocketConnection.socket.emit("disconnect2", []);

      prefs.setString(UserPreference.NAME, "");
      prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
      prefs.setBool(UserPreference.LOGIN_STATUS, false);
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
      prefs.setBool(UserPreference.IS_USER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
      prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
      bloc.resetData(prefs);
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage(null)),
      );
    } catch (e) {
      prefs.setString(UserPreference.NAME, "");
      prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
      prefs.setBool(UserPreference.LOGIN_STATUS, false);
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
      prefs.setBool(UserPreference.IS_USER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
      prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
      bloc.resetData(prefs);
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage(null)),
      );
    }
  }

  Future apiCallForLogout() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {
          "deviceId": prefs.getString("deviceId"),
        };

        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_LOGOUT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              onTapSignOut();
            } else {
              ToastWrap.showToast(msg, context);
            }
          } else {
            if (response.statusCode == 401) {
              onTapSignOut();
            }
          }
        } else {
          onTapSignOut();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      onTapSignOut();
      CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "PartnerDashboard", context);
    }
  }

  TextEditingController textController = TextEditingController();
  int _second = 120;
  Timer _timer;

  void _timerStart() {
    if (_timer?.isActive ?? false) {
      _timer?.cancel();
    }
    _second = 120;
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_second > 0) {
        _second--;
        setState(() {});
      } else {
        _timer?.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _printDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "$twoDigitMinutes:$twoDigitSeconds minutes";
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return WillPopScope(
      onWillPop: () {
        apiCallForLogout();
      },
      child: GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: customAppbar(
            context,
            Form(
                key: formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 0.0, top: 24.0, bottom: 30),
                        child: RichText(
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            text: 'Verify',
                            style: AppConstants
                                .txtStyle.heading400LatoRegularDarkBlue
                                .copyWith(
                                    fontSize: 28, fontWeight: FontWeight.w700),
                            children: [
                              TextSpan(
                                  text: ' email',
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {},
                                  style: AppConstants
                                      .txtStyle.heading40018LatoRegularDarkBlue
                                      .copyWith(
                                          fontSize: 28,
                                          fontWeight: FontWeight.w700)),
                            ],
                          ),
                        )),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(height: 20),
                            Center(
                              child: SizedBox(
                                width: 230,
                                child: PinCodeTextField(
                                  length: 4,
                                  keyboardType: TextInputType.number,
                                  obscureText: true,
                                  animationType: AnimationType.fade,
                                  pinTheme: PinTheme(
                                      shape: PinCodeFieldShape.underline,
                                      activeColor: Color(0xffE5EBF0),
                                      inactiveColor: Color(0xffE5EBF0),
                                      disabledColor: Color(0xffE5EBF0),
                                      activeFillColor: Color(0xffE5EBF0),
                                      selectedFillColor: Color(0xffE5EBF0),
                                      inactiveFillColor: Color(0xffE5EBF0),
                                      fieldWidth: 49),
                                  textStyle: TextStyle(
                                      fontSize: 16.0,
                                      color: AppConstants.colorStyle.darkBlue),
                                  animationDuration:
                                      Duration(milliseconds: 300),
                                  backgroundColor: Colors.transparent,
                                  enableActiveFill: false,
                                  controller: textController,
                                  onCompleted: (v) {
                                    setState(() {
                                      _code = v;
                                    });
                                  },
                                  onChanged: (value) {
                                    setState(() {
                                      _code = value;
                                    });
                                  },
                                  beforeTextPaste: (text) {
                                    print("Allowing to paste $text");
                                    //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                                    //but you can show anything you want here, like your pop up saying wrong paste format or etc
                                    return true;
                                  },
                                  appContext: context,
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsets.fromLTRB(20.0, 10, 20.0, 50.0),
                              child: InkWell(
                                child: Center(
                                  child: BaseText(
                                    text:
                                        'Enter verification code sent to your email.',
                                    textColor:
                                        AppConstants.colorStyle.lightPurple,
                                    textAlign: TextAlign.center,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                  ),
                                ),
                                onTap: () {},
                              ),
                            ),
                            Container(
                                child: Padding(
                                    padding: EdgeInsets.only(
                                        left: 20.0, top: 0.0, right: 20.0),
                                    child: Stack(
                                      children: <Widget>[
                                        Container(
                                            height: 44.0,
                                            width: double.infinity,
                                            child: FlatButton(
                                              onPressed: () async {
                                                _checkValidation();
                                              },
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          10)),
                                              color: AppConstants
                                                  .colorStyle.lightBlue,
                                              child: Row(
                                                // Replace with a Row for horizontal icon + text
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text('Next',
                                                      style: AppConstants
                                                          .txtStyle
                                                          .heading18600LatoRegularWhite),
                                                ],
                                              ),
                                            )),
                                        _code.length == 4
                                            ? SizedBox(
                                                height: 0,
                                              )
                                            : Container(
                                                height: 44.0,
                                                width: double.infinity,
                                                color: Colors.white
                                                    .withOpacity(0.75),
                                              )
                                      ],
                                    )))
                          ],
                        ),
                      ),
                    ),
                  ],
                )), () {
          apiCallForLogout();
        },
            bottomNavigation: Container(
              margin: const EdgeInsets.fromLTRB(20, 0, 20, 50),
              color: Colors.white,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Visibility(
                      visible: _second != 0,
                      child: BaseText(
                        text: _printDuration(Duration(seconds: _second)),
                        textAlign: TextAlign.center,
                        textColor: const Color(0xff27275A),
                        fontWeight: FontWeight.w400,
                        fontSize: 18,
                        fontFamily: Constant.latoRegular,
                      )),
                  const SizedBox(height: 14),
                  RichText(
                    maxLines: 1,
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      text: 'Didn\'t receive verification code? ',
                      style:
                          AppConstants.txtStyle.heading400LatoRegularDarkBlue,
                      children: [
                        TextSpan(
                          text: 'Resend',
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              resendOtpApi();
                            },
                          style: AppConstants
                              .txtStyle.heading400LatoRegularLightBlue
                              .copyWith(
                                  color: _second != 0
                                      ? const Color(0x304684EB)
                                      : AppConstants.colorStyle.lightBlue),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            signupType: widget.loginRole == LoginRole.parent
                ? 'parent'
                : widget.loginRole == LoginRole.partner
                    ? 'partner'
                    : ''),
      ),
    );
  }
}
