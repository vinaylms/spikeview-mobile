import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:spike_view_project/home_page/resources/home_api_provider.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';



class HomeRepositry {
  final _homeApiProvider = HomeApiProvider();

  Future<List<UserPostModal>> fetchPost(String userId,String roleId,BuildContext context) => _homeApiProvider.fetchPostData(userId,roleId,context);


}