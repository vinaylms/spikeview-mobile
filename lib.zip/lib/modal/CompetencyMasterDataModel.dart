import 'dart:io';

/*class CompetencyMasterDataModel {
  String level2;

  List<Level3CompetenciesMaster> level3Competencieslist;

  CompetencyMasterDataModel(this.level2, this.level3Competencieslist);
}



class Level3Competencies {
  String name, key;

  Level3Competencies(this.name, this.key);
}*/
