class CollegeDegreeModel {
  String status;
  List<CollegeDegreeResult> result;
  List<CollegeDegreeResult> inactiveRresult =  List();

  CollegeDegreeModel({this.status, this.result});

  CollegeDegreeModel.fromJson(Map<String, dynamic> json) {
   try{
     status = json['status'];
     if (json['result'] != null) {
       result =  List<CollegeDegreeResult>();
       json['result'].forEach((v) {
         //result.add(new CollegeDegreeResult.fromJson(v));
         if (v['status'].toString() == "Active")
           result.add(new CollegeDegreeResult.fromJson(v));
         else
           inactiveRresult.add(new CollegeDegreeResult.fromJson(v));
       });
     }
   } catch (e) {
     print("CollegeDegreeModel model Error+++++++++" + e.toString());
   }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CollegeDegreeResult {
  int degreeId;
  String name;
  String status;

  CollegeDegreeResult({this.degreeId, this.name, this.status});

  CollegeDegreeResult.fromJson(Map<String, dynamic> json) {
    degreeId = json['degreeId'];
    name = json['name'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['degreeId'] = this.degreeId;
    data['name'] = this.name;
    data['status'] = this.status;
    return data;
  }
}
