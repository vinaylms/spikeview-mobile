import 'dart:io';

class OrganizationModal{
  String organizationId,name,description,type,logo, schoolCode, city, state;
  String address ="";

  OrganizationModal(this.organizationId, this.name, this.description, this.type,
      this.logo, this.schoolCode, this.city, this.state, this.address);

}