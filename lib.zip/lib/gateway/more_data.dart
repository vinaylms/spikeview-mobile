// Updated COde

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/MaskedTextInputFormatter.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/parent_detail_more.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/parentProfile/wizard/AddProfileImage.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/profile/ParentProfileImage.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:http/http.dart' as http;
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/gateway/ReferalCodeResponse.dart';

class MoreData extends StatefulWidget {
  //ProfileInfoModal profileInfoModal;

  @override
  MoreDataState createState() => MoreDataState();
}

class MoreDataState extends State<MoreData> {
  final formKey = GlobalKey<FormState>();
  final formKeyReferal = GlobalKey<FormState>();

  Color borderColor = Colors.amber;
  BuildContext context;
  bool isAgree = false;
  SharedPreferences prefs;

  int strDateOfBirth = 0;
  int diffrenceInDob = 14;
  DateTime pickedDate;
  bool isValid = true;
  bool isUnderAge = true;
  bool isGenderSelected = true;
  String isParentGender;
  String strParentZip = "";
  String strFirstName = "", strLastName = "";
  FocusNode zipcodeFocusNode = FocusNode();
  ShareProfileModal shareProfileModal;
  TextEditingController parentZipController = TextEditingController(text: "");
  TextEditingController emailTxtController = TextEditingController(text: "");
  final _formKey2 = GlobalKey<FormState>();
  TextEditingController otpTxtController = TextEditingController(text: "");

  TextEditingController numberTxtController = TextEditingController(text: "");
  TextEditingController dobController = TextEditingController(text: "");

  static const platform = const MethodChannel('samples.flutter.io/battery');
  TextEditingController referalController = TextEditingController();
  TextEditingController firstNameController = TextEditingController(text: "");
  TextEditingController lastNameController = TextEditingController(text: "");

  bool isValidateReferal = false;

  ReferalCodeResponse referalCodeResponse;
  FocusNode referalFocusNode = FocusNode();

  String strCountryName = "";
  bool isStudentCountrySelected = true;
  CountryList _mCountryItem;
  CountryListModel _mCountryListModel;
  List<CountryList> countryList = List();
  final searchCountryController = TextEditingController();
  List<Item> countries = List();
  Item selectedCityItem;
  bool isShowStudentCitySelectionError = true;
  bool showList = false;

  bool password_error_lenght = false;
  bool password_error_number = false;
  bool password_error_lower = false;
  bool password_error_upper = false;
  bool password_error_specile = false;

  goto() {
    prefs.setString(UserPreference.PATHURL, "");
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
  }

  showSucessMsgLong(msg, context) {
    Timer _timer;
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      Navigator.pop(context);
      if (roleId == '2') {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>
                ParentProfileImage("", "parent")));
      } else {
        Navigator.pop(context, strDateOfBirth.toString());
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  loginServiceCall(isUnder13) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        Address address2;
        if (selectedCityItem == null) {
          try {
            Response response1 = await Util.getDetailUsingZipCodeNew(
                false, context, parentZipController.text);

            //apurva added for zip code validation start
            if (response1 == null) {
              print('apurva address2.country:: response:: $response1');
              CustomProgressLoader.cancelLoader(context);
              ToastWrap.showToast2Sec(
                  MessageConstant.ENTER_VALID_ZIP_CODE_VAL, context);
              return;
            } else {
              print('apurva address2.country:: response:: elseee $response1');
            }
            //apurva added for zip code validation end

            final data = response1.data['results'][0]["address_components"];

            String city = "", state = "", country = "";
            if (data.length > 3) {
              city = data[data.length - 3]['long_name'];
              state = data[data.length - 2]['long_name'];
              country = data[data.length - 1]['long_name'];
            } else if (data.length > 0) {
              //city=json[1]['long_name'];
              state = data[data.length - 2]['long_name'];
              country = data[data.length - 1]['long_name'];
            }
            //Apurva Added for match country and zipode start
            if (country.toString().trim() !=
                _mCountryItem.name.toString().trim()) {
              //////////
              //print('apurva address2.country:: country:: $country');
              //print('apurva address2.country:: _mCountryItem.name:: ${_mCountryItem.name}');
              CustomProgressLoader.cancelLoader(context);
              ToastWrap.showToast2Sec(
                  MessageConstant.ENTER_VALID_COUNTRY_ZIP_CODE_VAL, context);
              return;
            }
            //Apurva Added for match country and zipode end
            address2 = Address("", "", city, state, country, "", "");
          } catch (e) {}
        }

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {
          'Authorization': prefs.getString(UserPreference.USER_TOKEN)
        };
        // Prepare Data
        print("prefs.getString(UserPreference.USER_TOKEN)..." +
            prefs.getString(UserPreference.USER_TOKEN));

        Map map = name == null || name.trim() == "null"
            ? {
                "firstName": strFirstName,
                "lastName": strLastName,
                "userId": userId,
                "zipCode": parentZipController.text,
                "gender": isParentGender == "Non-Binary"
                    ? "NonBinary"
                    : isParentGender,
                "roleId": roleId,
                "dob": strDateOfBirth,
                "state": selectedCityItem != null
                    ? selectedCityItem.state
                    : address2 != null ? address2.state.trim() : "",
                "city": selectedCityItem != null
                    ? selectedCityItem.city
                    : address2 != null ? address2.city.trim() : "",
                "country": _mCountryItem == null ? "" : _mCountryItem.name,
                "isAddedDob": true
              }
            : {
                "userId": userId,
                "zipCode": parentZipController.text,
                "gender": isParentGender == "Non-Binary"
                    ? "NonBinary"
                    : isParentGender,
                "roleId": roleId,
                "dob": strDateOfBirth,
                "state": selectedCityItem != null
                    ? selectedCityItem.state
                    : address2 != null ? address2.state.trim() : "",
                "city": selectedCityItem != null
                    ? selectedCityItem.city
                    : address2 != null ? address2.city.trim() : "",
                "country": _mCountryItem == null ? "" : _mCountryItem.name,
                "isAddedDob": true
              };

        print("map+++++11111111" + map.toString());

        Response response =
            await dio.put(Constant.UPDATE_SIGNUP_DATA, data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        print("response+++++11111111" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            prefs.setString(UserPreference.DOB, strDateOfBirth.toString());
            prefs.setBool(UserPreference.IS_ADDED_DOB, true);
            if (isUnder13) {
              prefs.setBool(UserPreference.IS_ADDED_DOB, false);
              onTapContinueAge();
            } else {
              if (roleId == '2') {
                //Navigator.of(context).popUntil((route) => route.isFirst);
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                        ParentProfileImage("", "parent")));
              } else {
                if (isEducatorAllowedDomain) {
                  AddSecondaryEmailDialog();
                } else {
                  StudentOnBoarding()
                      .getStudentOnBoardingInit(context, null, "", userId);
                }
              }
            }
          } else {
            ToastWrap.showToastLong(message, context);
          }
        } else {
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        if (mounted) CustomProgressLoader.cancelLoader(context);

        print(e);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  secondryEmailApi() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        Address address2;

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {
          'Authorization': prefs.getString(UserPreference.USER_TOKEN)
        };

        Map map = {
          "secondaryEmail": emailTxtController.text,
          "userId": userId,
          "roleId": '1',
          "countryCode": '+1',
          "mobileNo": numberTxtController.text.replaceAll('-', ''),
          //  "otp": otpTxtController.text
        };

        print("map+++++11111111" + map.toString());

        Response response =
            await dio.put(Constant.ADD_PERSONAL_EMAIL, data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        print("response+++++11111111" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            Navigator.pop(context);
            StudentOnBoarding()
                .getStudentOnBoardingInit(context, null, "", userId);
          } else {
            ToastWrap.showToast(message, context);
          }
        } else {
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        if (mounted) CustomProgressLoader.cancelLoader(context);

        print(e);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  loginServiceCallSetFalse() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {
          'Authorization': prefs.getString(UserPreference.USER_TOKEN)
        };
        // Prepare Data

        Map map = {
          "userId": userId,
          "zipCode": parentZipController.text,
          "gender":
              isParentGender == "Non-Binary" ? "NonBinary" : isParentGender,
          "roleId": roleId,
          "dob": strDateOfBirth,
          "state": "",
          "city": "",
          "country": _mCountryItem == null ? "" : _mCountryItem.name,
          "isAddedDob": false
        };
        print("map+++++" + map.toString());
        // Make API call
        Response response =
            await dio.put(Constant.UPDATE_SIGNUP_DATA, data: json.encode(map));

        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            prefs.setBool(UserPreference.IS_ADDED_DOB, false);
          } else {}
        } else {
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {}
    } else {}
  }

  onTapContinueAge() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            ParentData(isEducatorAllowedDomain)));
    if (result == "pop") {
      loginServiceCallSetFalse();
    } else {}
  }

  void showConformation() {
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      builder: (BuildContext context) {
        return Container(
          height: 420.0,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                  padding: EdgeInsets.only(top: 5),
                  child: Container(
                    width: 58,
                    height: 4.0,
                    color: ColorValues.GREY_TEXT_COLOR,
                  )),
              Padding(
                padding: EdgeInsets.fromLTRB(10.0, 35.0, 10.0, 10.0),
                child: Image.asset(
                  "assets/more_age.png",
                  height: 120.0,
                  width: 90.0,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(45, 5, 45, 0),
                child: Text(
                  "Wait !",
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      height: 1.2,
                      fontSize: 20.0,
                      fontWeight: FontWeight.w700,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(45, 3, 45, 0),
                child: Text(
                  "Are you under 13?",
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      height: 1.2,
                      fontSize: 20.0,
                      fontWeight: FontWeight.w700,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(45, 20, 45, 0),
                child: TextViewWrap.textViewMultiLine(
                    "Your date of birth suggests you are under 13! If that is not correct, go back and change it.",
                    TextAlign.center,
                    ColorValues.search_error_text,
                    14.0,
                    FontWeight.normal,
                    5),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 30.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 13.0, right: 8.0),
                        child: Container(
                            height: 40.0,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(
                                  color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  width: 0.5),
                            ),
                            child: FlatButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(0)),
                              child: Row(
                                // Replace with a Row for horizontal icon + text
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text('Back',
                                      style: TextStyle(
                                          fontSize: 20.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR,
                                          color: ColorValues
                                              .BLUE_COLOR_BOTTOMBAR)),
                                ],
                              ),
                            )),
                      ),
                      flex: 1,
                    ),
                    Expanded(
                      child: Padding(
                          padding:
                              const EdgeInsets.only(left: 8.0, right: 13.0),
                          child: Container(
                              height: 40.0,
                              child: FlatButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  //  onTapContinueAge();

                                  loginServiceCall(true);
                                },
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(0)),
                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                child: Row(
                                  // Replace with a Row for horizontal icon + text
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text('Confirm',
                                        style: TextStyle(
                                            fontSize: 20.0,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            color: Colors.white)),
                                  ],
                                ),
                              ))),
                      flex: 1,
                    )
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _checkValidation() async {
    try {
      final form = formKey.currentState;
      form.save();

      if (strDateOfBirth == 0) {
        setState(() {
          isValid = false;
        });
      }

      if (_mCountryItem == null) {
        setState(() {
          isStudentCountrySelected = false;
        });
      } else {
        setState(() {
          isStudentCountrySelected = true;
        });
      }

      if (_mCountryItem != null &&
          (!_mCountryItem.isZipcode) &&
          selectedCityItem == null) {
        isShowStudentCitySelectionError = false;
      } else {
        isShowStudentCitySelectionError = true;
      }

      if (form.validate()) {
        if (strDateOfBirth != 0) {
          setState(() {
            isValid = true;
          });
          if (isParentGender == null || isParentGender == "") {
            setState(() {
              isGenderSelected = false;
            });
          } else if (!isStudentCountrySelected) {
            setState(() {
              isStudentCountrySelected = false;
            });
          } else if (!isShowStudentCitySelectionError) {
          } else {
            setState(() {
              isValid = true;
            });

            if (roleId == '1' && !isUnderAge && diffrenceInDob < 13) {
              showConformation();
            } else {
              if (roleId == '2' && diffrenceInDob < 18) {
                ToastWrap.showToast(
                    MessageConstant.SORRY_OVER_18_BECOME_PARENT_ERROR, context);
              } else {
                loginServiceCall(false);
              }
            }
          }
        } else {
          setState(() {
            isValid = false;
          });

          // ToastWrap.showToast("Please select date of birth.");
        }
      } else {
        setState(() {
          isGenderSelected = false;
        });
      }
    } catch (e) {
      print("error+++" + e.toString());
    }
  }

  bool _newPassObscureText = true;

  String strNewPassword = "";

  String token;
  String roleId, userId;
  String name = " ";
  List<String> educatorAllowedDomain = List();
  bool isEducatorAllowedDomain = false;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    token = prefs.getString(UserPreference.USER_TOKEN);
    userId = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    name = prefs.getString(UserPreference.NAME).toString();
    String email = prefs.getString(UserPreference.EMAIL);
    isUnderAge = prefs.getBool(UserPreference.IS_UNDER_AGE);
    try {
      educatorAllowedDomain =
          prefs.getStringList(UserPreference.EDU_ALLOWED_DOMAIN);
      for (String domain in educatorAllowedDomain) {
        print("domain+++" + domain);
        if (email.endsWith(domain)) {
          isEducatorAllowedDomain = true;
        }
      }
    } catch (e) {
      isEducatorAllowedDomain = false;
    }

    print("name++++" + educatorAllowedDomain.toString());
  }

  Future getCountry() async {
    print('inside getPreLoginData() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCallWithouAuth(context, Constant.ENDPOINT_GET_COUNTRY, "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mCountryListModel = CountryListModel.fromJson(response.data);
              setState(() {
                _mCountryListModel;
                countryList.addAll(_mCountryListModel.countryList);
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  initCountryList(text, sortname) async {
    countries.clear();
    countries = await API.fetchCountryListForSignup(text, 'cities', sortname);
    if (countries.length > 0) {
      setState(() {});
    }
  }

  @override
  void initState() {
    // genderList.add("Gender");
    getSharedPreferences();
    searchCountryController.addListener(() {
      if (searchCountryController.text.isEmpty) {
        setState(() {
          countries.clear();
        });
      } else {
        if (searchCountryController.text.trim().length >= 1) {
          initCountryList(
              searchCountryController.text.trim(), _mCountryItem.sortname);
        }
      }
    });

    setState(() {
      genderList = genderList.reversed.toList();
    });
    dobController = TextEditingController(text: '');

    getCountry();
  }

  List<String> genderList = [
    "NA",
    "Non-Binary",
    "Female",
    "Male",
  ].toList();

  Future<bool> sendOtpEmail() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        Address address2;

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {
          'Authorization': prefs.getString(UserPreference.USER_TOKEN)
        };

        Map map = {
          "secondaryEmail": emailTxtController.text,
          "userId": userId,
          "roleId": '1',
        };
        print("map+++++11111111" + map.toString());

        Response response =
            await dio.put(Constant.SEND_OTP_ON_EMAIL, data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        print("response+++++11111111" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            ToastWrap.showToasSucess(message.toString(), context);
            return true;
          } else {
            ToastWrap.showToast(message, context);
            return false;
          }
        } else {
          return false;
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        if (mounted) CustomProgressLoader.cancelLoader(context);
        return false;
        print(e);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      return false;
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  //String gender;
  bool isOtpSend = false;

  AddSecondaryEmailDialog() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        Container(
                          child: Column(
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Container(
                                    padding: EdgeInsets.all(12.0),
                                    width: double.infinity,
                                    color: Colors.white,
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 15.0, bottom: 25),
                                            child: Center(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5.0),
                                                ),
                                                height: 4.0,
                                                width: 55,
                                              ),
                                            ),
                                          ),
                                          Form(
                                            key: _formKey2,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                  MessageConstant
                                                      .CHANGE_EXISTING_EMAIL,
                                                  style: TextStyle(
                                                      fontSize: 16.0,
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontWeight:
                                                          FontWeight.w700),
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                  MessageConstant
                                                      .CHANGE_EXISTING_EMAIL_TEXT_ONBOARDING,
                                                  style: TextStyle(
                                                      fontSize: 12.0,
                                                      color: ColorValues
                                                          .GREY__COLOR,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontWeight:
                                                          FontWeight.w400),
                                                ),
                                                SizedBox(
                                                  height: 20,
                                                ),

                                                TextFormField(
                                                  controller:
                                                      emailTxtController,
                                                  keyboardType: TextInputType
                                                      .emailAddress,
                                                  textInputAction:
                                                      TextInputAction.done,
                                                  validator: (val) => val
                                                              .trim()
                                                              .length ==
                                                          0
                                                      ? MessageConstant
                                                          .ENTER_EMAIL_VAL
                                                      : /* !ValidationWidget.isEmail(val)
                                                            ? MessageConstant.ENTER_CORRECRT_EMAIL_VAL
                                                            : !*/
                                                      ValidationWidget
                                                          .isSecondaryEmail(val,
                                                              educatorAllowedDomain)
                                                  /* ? MessageConstant
                                                                    .ENTER_CORRECRT_DOMAIN_VAL
                                                                : null*/
                                                  ,
                                                  cursorColor:
                                                      Constant.CURSOR_COLOR,
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontFamily:
                                                          "customRegular"),
                                                  decoration: InputDecoration(
                                                      contentPadding:
                                                          const EdgeInsets.fromLTRB(
                                                              0.0, 0.0, 0.0, 0.0),
                                                      focusedBorder: UnderlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: ColorValues
                                                                  .GREY__COLOR_DIVIDER)),
                                                      enabledBorder: UnderlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: ColorValues
                                                                  .GREY__COLOR_DIVIDER)),
                                                      errorStyle:
                                                          Util.errorTextStyle,
                                                      labelText:
                                                          "Personal Email Address",
                                                      errorMaxLines: 2,
                                                      labelStyle: TextStyle(
                                                          color:
                                                              ColorValues.black,
                                                          fontFamily:
                                                              "customRegular"),
                                                      border: UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.GREY__COLOR_DIVIDER))),
                                                ),

                                                SizedBox(
                                                  height: 20,
                                                ),

                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .baseline,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  textBaseline:
                                                      TextBaseline.ideographic,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 12.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: <Widget>[
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      0.0,
                                                                      17,
                                                                      13,
                                                                      10),
                                                              child:
                                                                  Image.asset(
                                                                "assets/us.png",
                                                                width: 30.0,
                                                                height: 20.0,
                                                              ),
                                                            ),
                                                            Container(
                                                              color: ColorValues
                                                                  .GREY__COLOR_DIVIDER,
                                                              height: 1.2,
                                                              width: 45,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      flex: 0,
                                                    ),
                                                    Expanded(
                                                      child: TextFormField(
                                                        controller:
                                                            numberTxtController,
                                                        keyboardType:
                                                            TextInputType
                                                                .number,
                                                        textInputAction:
                                                            TextInputAction
                                                                .done,
                                                        maxLength: 20,
                                                        validator:
                                                            (String arg) {
                                                          if (arg.length > 0) {
                                                            if (arg.length >
                                                                7) {
                                                              return null;
                                                            } else {
                                                              return MessageConstant
                                                                  .ENTER_VALID_PHONE_NUMBER_VAL;
                                                            }
                                                          } else {
                                                            return null;
                                                          }
                                                        },
                                                        inputFormatters: [
                                                          WhitelistingTextInputFormatter
                                                              .digitsOnly,
                                                          MaskedTextInputFormatter(),
                                                        ],
                                                        cursorColor: Constant
                                                            .CURSOR_COLOR,
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontFamily:
                                                                "customRegular"),
                                                        decoration: InputDecoration(
                                                            counterText: '',
                                                            contentPadding:
                                                                const EdgeInsets.fromLTRB(
                                                                    0.0,
                                                                    -5.0,
                                                                    0.0,
                                                                    0.0),
                                                            focusedBorder: UnderlineInputBorder(
                                                                borderSide: BorderSide(
                                                                    color: ColorValues
                                                                        .GREY__COLOR_DIVIDER)),
                                                            enabledBorder: UnderlineInputBorder(
                                                                borderSide: BorderSide(
                                                                    color: ColorValues
                                                                        .GREY__COLOR_DIVIDER)),
                                                            errorStyle: Util
                                                                .errorTextStyle,
                                                            labelText:
                                                                'Cell Phone Number (Optional)',
                                                            labelStyle: TextStyle(
                                                                color: ColorValues
                                                                    .black,
                                                                fontFamily:
                                                                    "customRegular"),
                                                            border: UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.GREY__COLOR_DIVIDER))),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 15,
                                                ),
                                                //  prefs.getString(UserPreference.EMAIL)
                                              ],
                                            ),
                                          ),
                                          PaddingWrap.paddingfromLTRB(
                                              13.0,
                                              20.0,
                                              13.0,
                                              15.0,
                                              Center(
                                                child: Container(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    padding:
                                                        EdgeInsets.all(10.0),
                                                    width: 222,
                                                    height: 45.0,
                                                    child: Row(
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: InkWell(
                                                            child: Container(
                                                                child: Text(
                                                              "Save",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .customRegular),
                                                            )),
                                                            onTap: () {
                                                              final form1 =
                                                                  _formKey2
                                                                      .currentState;

                                                              form1.save();
                                                              if (form1
                                                                  .validate()) {
                                                                secondryEmailApi();
                                                              }
                                                            },
                                                          ),
                                                          flex: 1,
                                                        ),
                                                      ],
                                                    )),
                                              ))
                                        ]),
                                  )),
                            ],
                          ),
                        ),
                      ],
                    )))));
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;

    final dropdownGraduationYear = genderList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Text(
                  item,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ))))
        .toList();

    final upperLogo = Image(
      image: AssetImage("assets/logo.png"),
      color: null,
      width: 130.0,
      height: 70.0,
      fit: BoxFit.contain,
    );

    final dropdownCountry = countryList
        .map((CountryList item) => DropdownMenuItem<CountryList>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Text(
                  item.name,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ))))
        .toList();

    Text getTextLab(txt, size, color, fontWeight) {
      return Text(
        txt,
        textAlign: TextAlign.start,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final genderUi = PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        0.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            PaddingWrap.paddingfromLTRB(
                13.0,
                15.0,
                13.0,
                0.0,
                isParentGender == null || isParentGender == ''
                    ? getTextLab("", 11.0, ColorValues.GREY_TEXT_COLOR,
                        FontWeight.normal)
                    : getTextLab("Gender", 11.0, ColorValues.GREY_TEXT_COLOR,
                        FontWeight.normal)),
            PaddingWrap.paddingfromLTRB(
                13.0,
                0.0,
                13.0,
                0.0,
                Container(
                    height: 28.0,
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                    decoration: BoxDecoration(
                        border: Border(
                            bottom: BorderSide(
                                color: isGenderSelected
                                    ? ColorValues.DARK_GREY
                                    : Colors.red[600],
                                width: 1.0))),
                    width: double.infinity,
                    child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                            hint: Text(
                              "Gender",
                              style: TextStyle(
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  color: ColorValues.GREY_TEXT_COLOR),
                            ),
                            value: isParentGender,
                            items: dropdownGraduationYear,
                            onChanged: (s) {
                              setState(() {
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());
                                if (s != "Gender") {
                                  isParentGender = s;
                                  isParentGender = s;
                                }
                              });
                            })))),
            isGenderSelected
                ? Container(
                    height: 0.0,
                  )
                : PaddingWrap.paddingfromLTRB(
                    13.0,
                    5.0,
                    13.0,
                    0.0,
                    Text(
                      "Please select gender",
                      style: TextStyle(color: Colors.red[600], fontSize: 12.0),
                    ))
          ],
        ));

    final countryUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            strCountryName != '' && strCountryName != 'Select Country'
                ? getTextLab("Select Country", 11.0,
                    ColorValues.GREY_TEXT_COLOR, FontWeight.normal)
                : getTextLab(
                    "", 11.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal),
            Container(
                height: 28.0,
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: isStudentCountrySelected
                                ? ColorValues.DARK_GREY
                                : Colors.red[600],
                            width: 1.0))),
                width: double.infinity,
                child: DropdownButtonHideUnderline(
                    child: DropdownButton<CountryList>(
                        hint: Text(
                          "Select Country",
                          style: TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: ColorValues.GREY_TEXT_COLOR),
                        ),
                        value: _mCountryItem,
                        items: dropdownCountry,
                        onChanged: (s) {
                          setState(() {
                            FocusScope.of(context)
                                .requestFocus(new FocusNode());
                            _mCountryItem = s;
                            strCountryName = s.name;
                            searchCountryController.text = "";
                            parentZipController.text = "";
                            selectedCityItem = null;
                            countries.clear();
                            showList = false;
                            isStudentCountrySelected = true;
                          });
                        }))),
          ],
        ));

    Future<Null> selectDob(BuildContext context) async {
      FocusScope.of(context).unfocus();
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: DateTime.parse("1800-01-01"),
        pickerMode: DateTimePickerMode.date,
        maxDateTime: DateTime.now(),
        initialDateTime: pickedDate == null ? DateTime.now() : pickedDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {},
        onConfirm: (dateTime, List<int> index) {
          if (dateTime != null) {
            pickedDate = dateTime;
            strDateOfBirth = dateTime.millisecondsSinceEpoch;
            String date = Util.getDate(dateTime);
            String date2 = DateFormat("yyyy-MM-dd").format(dateTime);

            diffrenceInDob = Util.currentAge(dateTime, 18);

            setState(() {
              isValid = true;
              pickedDate;
              diffrenceInDob;
              dobController = TextEditingController(text: date);
            });
          } else {
            FocusScope.of(context).requestFocus(new FocusNode());
          }
        },
      );
    }

    final dateOBUI = InkWell(
      child: Container(
        padding:
            EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 0.0),
        child: Theme(
            data: ThemeData(
                backgroundColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
                indicatorColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
                cursorColor: ColorValues.HEADING_COLOR_EDUCATION,
                textSelectionColor: Colors.black54,
                accentColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
                hintColor: ColorValues.LIGHT_GREY_TEXT_COLOR),
            child: TextField(
              keyboardType: TextInputType.text,
              controller: dobController,
              onTap: () {
                selectDob(context);
              },
              readOnly: true,
              style: TextStyle(
                  color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                suffixIcon: GestureDetector(
                    child: Padding(
                  padding: EdgeInsets.fromLTRB(20.0, 10.0, 5.0, 0.0),
                  child: Image.asset(
                    "assets/newDesignIcon/login/calander.png",
                    width: 20.0,
                    height: 20.0,
                  ),
                )),
                labelText: "Date of Birth",
                errorStyle: Util.errorTextStyle,
                contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                errorText: (!isValid) ? MessageConstant.SELECT_DOB_VAL : null,
                focusedBorder: UnderlineInputBorder(
                    borderSide:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                enabledBorder: UnderlineInputBorder(
                    borderSide:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                border: UnderlineInputBorder(
                    borderSide:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
              ),
            )),
      ),
      onTap: () {
        selectDob(context);
      },
    );

    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final userFirstNameUi = Padding(
      padding: EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 0.0),
      child: Theme(
          data: ThemeData(
              backgroundColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor: ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor: ColorValues.LIGHT_GREY_TEXT_COLOR),
          child: TextFormField(
            keyboardType: TextInputType.text,
            controller: firstNameController,
            textInputAction: TextInputAction.done,
            textCapitalization: TextCapitalization.sentences,
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_FIRST_NAME_VAL
                : !ValidationWidget.isName(val.trim())
                    ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                    : null,
            onSaved: (val) => strFirstName = val.trim(),
            cursorColor: Constant.CURSOR_COLOR,
            style: TextStyle(
                color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              suffixIcon: GestureDetector(
                  child: Padding(
                padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),
                child: Image.asset(
                  "assets/newDesignIcon/login/user.png",
                  width: 13.0,
                  height: 13.0,
                ),
              )),
              focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              border: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              labelText: "First Name",
              errorStyle: Util.errorTextStyle,
              counterText: "",
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    final lastNameUi = Padding(
      padding: EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 0.0),
      child: Theme(
          data: ThemeData(
              backgroundColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor: ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor: ColorValues.LIGHT_GREY_TEXT_COLOR),
          child: TextFormField(
            keyboardType: TextInputType.text,
            maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
            controller: lastNameController,
            textInputAction: TextInputAction.done,
            cursorColor: Constant.CURSOR_COLOR,
            textCapitalization: TextCapitalization.sentences,
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_LAST_NAME_VAL
                : null,
            onSaved: (val) => strLastName = val.trim(),
            style: TextStyle(
                color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              suffixIcon: GestureDetector(
                  child: Padding(
                padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),
                child: Image.asset(
                  "assets/newDesignIcon/login/user.png",
                  width: 13.0,
                  height: 13.0,
                ),
              )),
              focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              border: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              labelText: "Last Name",
              errorStyle: Util.errorTextStyle,
              counterText: "",
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    final parentZipUi = Padding(
      padding: EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 0.0),
      child: Theme(
          data: ThemeData(
              backgroundColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor: ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor: ColorValues.LIGHT_GREY_TEXT_COLOR),
          child: TextFormField(
            keyboardType: TextInputType.text,
            focusNode: zipcodeFocusNode,
            controller: parentZipController,
            textInputAction: TextInputAction.done,
            maxLength: TextLength.ZIPCODE_MAX_LENGTH,
            cursorColor: Constant.CURSOR_COLOR,
            validator: (val) => !ValidationWidget.isZipCode(val)
                ? MessageConstant.ENTER_VALID_ZIP_CODE_VAL
                : null,
            onSaved: (val) => strParentZip = val,
            style: TextStyle(
                color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              counterText: "",
              focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              border: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              labelText: "Zip Code",
              errorStyle: Util.errorTextStyle,
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    final loginButton = Container(
        child: Padding(
            padding: EdgeInsets.only(
                left: 13.0, top: 35.0, right: 13.0, bottom: 10.0),
            child: Container(
                height: 44.0,
                width: double.infinity,
                child: FlatButton(
                  onPressed: () {
                    FocusScope.of(context).unfocus();
                    final form = formKey.currentState;
                    form.save();
                    //editCategoryDialog();
                    _checkValidation();
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(0)),
                  color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                  child: Row(
                    // Replace with a Row for horizontal icon + text
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text('Continue',
                          style: TextStyle(
                              fontSize: 20.0,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: Colors.white)),
                    ],
                  ),
                ))));

    textFormFieldDecorationWithNoBorders(String name, {String helperText}) {
      return InputDecoration(
        contentPadding: const EdgeInsets.fromLTRB(
          0.0,
          5.0,
          5.0,
          5.0,
        ),
        labelText: name,
        errorStyle: TextStyle(
            fontFamily: AppTextStyle.getFont(FontType.Regular),
            color: Palette.redColor),
        helperText: helperText,
        helperStyle: AppTextStyle.getDynamicFontStyle(
            Palette.secondaryTextColor, 12, FontType.Regular),
        hintStyle: AppTextStyle.getDynamicFontStyle(
            Palette.secondaryTextColor, 14, FontType.Regular),
        labelStyle: TextStyle(
            color: ColorValues.GREY_TEXT_COLOR,
            fontFamily: Constant.TYPE_CUSTOMREGULAR),
        enabledBorder: InputBorder.none,
        focusedBorder: InputBorder.none,
        border: InputBorder.none,
      );
    }

    selectCountryCityTextField() {
      return TextFormField(
        decoration: textFormFieldDecorationWithNoBorders('Select City'),
        controller: searchCountryController,
        onChanged: (value) {
          setState(() {
            showList = true;
          });
        },
      );
    }

    Widget _buildAddedItem(Item item, Animation animation, type) {
      return FadeTransition(
        opacity: CurvedAnimation(curve: Curves.linear, parent: animation),
        child: SizeTransition(
          axis: Axis.vertical,
          sizeFactor: CurvedAnimation(curve: Curves.linear, parent: animation),
          child: InkWell(
            onTap: () {
              print("item++++" + item.name);
              print("item++++" + item.city);
              print("item++++" + item.country);
              print("item++++" + item.state);

              searchCountryController.text = item.name;
              selectedCityItem = item;
              showList = !showList;

              //searchCountryController.clear();
              setState(() {});
            },
            child: AnimatedContainer(
              curve: Curves.easeIn,
              duration: Duration(milliseconds: 500),
              width: MediaQuery.of(context).size.width,
              child: Text(item.name,
                  style: TextStyle(fontFamily: Constant.customRegular)),
              padding: EdgeInsets.all(8),
            ),
          ),
        ),
      );
    }

    countryOrCityListWidget() {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          showList
              ? countries.length > 0
                  ? Container(
                      height: countries.length == 1
                          ? 40.0
                          : countries.length == 2
                              ? 90.0
                              : countries.length == 3 ? 130 : 200.0,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(13.0, 0, 13, 0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                                color: ColorValues.BORDER_COLOR, width: 0.5),
                          ),
                          padding: countries.length > 0
                              ? EdgeInsets.all(0)
                              : EdgeInsets.all(0),
                          child: ListView(
                            children: [
                              AnimatedList(
                                physics: NeverScrollableScrollPhysics(),
                                initialItemCount: countries.length,
                                shrinkWrap: true,
                                itemBuilder: (context, index, animation) {
                                  return _buildAddedItem(
                                      countries.length == 1
                                          ? countries[0]
                                          : countries[index],
                                      animation,
                                      "student");
                                },
                              )
                            ],
                          ),
                        ),
                      ),
                    )
                  : Container()
              : Container(),
        ],
      );
    }

    final bottomBarView = Container(
      // color:  ColorValues.HEADING_COLOR_EDUCATION,
      padding: EdgeInsets.only(left: 4.0, right: 4.0),
      height: 140.0 + MediaQuery.of(context).padding.bottom,
      child: Container(
          child: Column(
        children: <Widget>[
          Container(
              padding: EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 60.0),
              child: Column(
                children: <Widget>[
                  loginButton,
                ],
              )),
        ],
      )),
    );

    onBack() {
      prefs.setBool(UserPreference.LOGIN_STATUS, false);
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => LoginPage(null)));
    }

    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child: GestureDetector(
            onTap: () {
              //  FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                backgroundColor: ColorValues.WHITE,
                body: Container(
                  child: Column(
                    children: <Widget>[
                      Expanded(
                        child: Container(
                            color: ColorValues.WHITE,
                            height: double.infinity,
                            child: Container(
                                color: ColorValues.WHITE,
                                child: Container(
                                  padding: EdgeInsets.all(0.0),
                                  child: FormKeyboardActions(
                                      nextFocus: false,
                                      keyboardActionsPlatform:
                                          KeyboardActionsPlatform.IOS,
                                      //optional
                                      keyboardBarColor: Colors.grey[200],
                                      //optional
                                      actions: [
                                        KeyboardAction(
                                          focusNode: zipcodeFocusNode,
                                        ),
                                      ],
                                      child: Form(
                                          key: formKey,
                                          child: ListView(
                                            children: <Widget>[
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        InkWell(
                                                          child: SizedBox(
                                                            height: 40.0,
                                                            width: 30.0,
                                                            child: PaddingWrap.paddingfromLTRB(
                                                                0.0,
                                                                10.0,
                                                                0.0,
                                                                3.0,
                                                                Center(
                                                                    child: Image.asset(
                                                                        "assets/newDesignIcon/navigation/back.png",
                                                                        height:
                                                                            20.0,
                                                                        width:
                                                                            10.0,
                                                                        fit: BoxFit
                                                                            .fitHeight))),
                                                          ),
                                                          onTap: () {
                                                            onBack();
                                                          },
                                                        ),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
                                                  Expanded(
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              10.0,
                                                              20.0,
                                                              10.0,
                                                              0.0),
                                                      child: Image.asset(
                                                        "assets/more_data.png",
                                                        height: 50.0,
                                                        width: 50.0,
                                                      ),
                                                    ),
                                                    flex: 1,
                                                  ),
                                                  Expanded(
                                                    child: Container(),
                                                    flex: 1,
                                                  ),
                                                ],
                                              ),
                                              Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          0, 10, 0, 15),
                                                  child: Column(
                                                    children: <Widget>[
                                                      Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          Text(
                                                              "Registration Information",
                                                              style: new TextStyle(
                                                                  color: ColorValues
                                                                      .HEADING_COLOR_EDUCATION,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR,
                                                                  fontSize:
                                                                      22.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700))
                                                        ],
                                                      ),
                                                    ],
                                                  )),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  name == null ||
                                                          name.trim() == "null"
                                                      ? userFirstNameUi
                                                      : Container(height: 0.0),
                                                  name == null ||
                                                          name.trim() == "null"
                                                      ? lastNameUi
                                                      : Container(height: 0.0),
                                                  genderUi,
                                                  dateOBUI,
                                                  countryUi,
                                                  isStudentCountrySelected
                                                      ? Container(
                                                          height: 0.0,
                                                        )
                                                      : PaddingWrap
                                                          .paddingfromLTRB(
                                                              13.0,
                                                              5.0,
                                                              13.0,
                                                              0.0,
                                                              Text(
                                                                "Please select country",
                                                                style: TextStyle(
                                                                    color: Colors
                                                                            .red[
                                                                        600],
                                                                    fontSize:
                                                                        12.0),
                                                              )),
                                                  _mCountryItem == null
                                                      ? parentZipUi
                                                      : _mCountryItem.isZipcode
                                                          ? parentZipUi
                                                          : PaddingWrap
                                                              .paddingfromLTRB(
                                                              13.0,
                                                              15.0,
                                                              13.0,
                                                              0.0,
                                                              Container(
                                                                  decoration: BoxDecoration(
                                                                      border: Border(
                                                                          bottom:
                                                                              BorderSide(color: isShowStudentCitySelectionError ? Palette.dividerColor : Colors.red[600]))),
                                                                  child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: <
                                                                        Widget>[
                                                                      Row(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.spaceBetween,
                                                                        children: <
                                                                            Widget>[
                                                                          Expanded(
                                                                            flex:
                                                                                1,
                                                                            child:
                                                                                selectCountryCityTextField(),
                                                                          ),
                                                                          searchCountryController.text.length > 0
                                                                              ? IconButton(
                                                                                  onPressed: () {
                                                                                    showList = !showList;
                                                                                    setState(() {});
                                                                                  },
                                                                                  icon: Padding(
                                                                                    padding: const EdgeInsets.only(left: 15.0),
                                                                                    child: Icon(showList ? Icons.arrow_drop_up : Icons.arrow_drop_down),
                                                                                  ),
                                                                                )
                                                                              : Container(height: 0.0),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  )),
                                                            ),
                                                  isShowStudentCitySelectionError
                                                      ? Container(
                                                          height: 0.0,
                                                        )
                                                      : PaddingWrap
                                                          .paddingfromLTRB(
                                                              13.0,
                                                              5.0,
                                                              13.0,
                                                              0.0,
                                                              Text(
                                                                "Please select city",
                                                                style: TextStyle(
                                                                    color: Colors
                                                                            .red[
                                                                        600],
                                                                    fontSize:
                                                                        12.0),
                                                              )),
                                                  countryOrCityListWidget(),
                                                ],
                                              ),
                                              loginButton
                                            ],
                                          ))),
                                ))),
                        flex: 1,
                      )
                    ],
                  ),
                  color: ColorValues.LIGHT_GRAY_BG,
                ))));
  }
}
