// Create a Form Widget
import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfile.dart';
import 'package:spike_view_project/parentProfile/wizard/AddEducation_Widget.dart';
import 'package:spike_view_project/parentProfile/wizard/AllEducationListWidget.dart';
import 'package:spike_view_project/parentProfile/wizard/AddChildEducationInitial.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AddSummary_Widget extends StatefulWidget {
  String title, parentName;
  String studentId;
  StudentDataModel studModel;

  AddSummary_Widget(StudentDataModel studModel) {
    this.studModel = studModel;
  }

  @override
  AddSummaryState createState() {
    return  AddSummaryState(studModel);
  }
}

class AddSummaryState extends State<AddSummary_Widget> {
  SharedPreferences prefs;

  AddSummaryState(this.studModel);
  FocusNode skillFocusNode = FocusNode();

  String userIdPref, token;
  File imagePath = null;
  TextEditingController addSummary;
  int typedCharacterLimit = 0;
  StudentDataModel studModel;
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String strPrefixPathforCoverPhoto,
      strPrefixPathforProfilePhoto = "sv_532/profile/",
      strAzureCoverImageUploadPath = "",
      strAzureProfileImageUploadPath = "";
  String strNetworkImage = "No";

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    // userIdPref = prefs.getString(UserPreference.PARENT_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    addSummary =  TextEditingController(
        text: studModel.summary == "null" ? "" : studModel.summary);
    setState(() {
      addSummary;
    });

    addSummary.addListener(() {
      setState(() {
        addSummary;
      });
    });
    // TODO: implement initState
    super.initState();
  }

  // API Calling here

  Future apiSummary() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "summary": addSummary.text,
          "userId": prefs.getString(UserPreference.PARENT_WIZARD_USERID)
        };
        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_USER_COVER_PHOTO_UPDATE, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              setState(() {
                studModel.summary = addSummary.text;
              });
              if (ParentProfilePageState.isEducationAdded == "true") {
                Navigator.of(context).push(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                         AllEducationListWidget(studModel)));
              } else {
                /*Navigator.of(context).push(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                         AddEducation_Widget(studModel, "yes","")));*/

                Navigator.of(context).push(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                         AddChildEducationInitial(studModel, "yes", "")));
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above

    Row getUpperDots() {
      return  Row(
        children: <Widget>[
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
        ],
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
      );
    }

    Container getBottomBar() {
      return  Container(
          child:  Row(
        children: <Widget>[
           InkWell(
            child:  Padding(
                padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                child: Image.asset(
                  'assets/newDesignIcon/parentProfile/backword.png',
                  height: 45.0,
                  width: 45.0,
                )),
            onTap: () {
              onBackwordClick();
            },
          ),
           Expanded(
            child:  InkWell(
              child:  Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                  child:  Text(
                    "",
                    style: TextStyle(
                        fontSize: 16.0,
                        fontFamily: Constant.customRegular,
                        color: ColorValues.GREY_TEXT_COLOR),
                    textAlign: TextAlign.center,
                  )),
              onTap: () {
                // skipOnClick();
              },
            ),
            flex: 1,
          ),
          addSummary.text.trim().length > 0
              ?  InkWell(
                  child:  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                      child: Image.asset(
                        'assets/newDesignIcon/parentProfile/next.png',
                        height: 45.0,
                        width: 45.0,
                      )),
                  onTap: () {
                    onNextClick();
                  },
                )
              :  Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                  child: Image.asset(
                    'assets/newDesignIcon/parentProfile/next_gray.png',
                    height: 45.0,
                    width: 45.0,
                  ))
        ],
      ));
    }

    final skillUi = Padding(
        padding:
             EdgeInsets.only(left: 0.0, top: 23.0, right: 0.0, bottom: 7.0),
        child:  Container(
          decoration:  BoxDecoration(
              color: Colors.white,
              border:  Border.all(
                  color:  ColorValues.DARK_GREY, width: 1.0)),
          child:  TextFormField(
            maxLines: 8,
            maxLength: TextLength.SUMMARY_MSG_LENGTH,
            cursorColor: Constant.CURSOR_COLOR,
            textAlign: TextAlign.start,
            controller: addSummary,
            focusNode: skillFocusNode,
            style:  TextStyle(
                color:  ColorValues.HEADING_COLOR_EDUCATION,
                fontSize: 16.0,
                height: 1.2,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            textCapitalization: TextCapitalization.sentences,
            keyboardType: TextInputType.multiline,
            autofocus: true,
            decoration:  InputDecoration(
              filled: false,
              isDense: false,
              labelText: "",errorStyle:Util.errorTextStyle,
              contentPadding:  EdgeInsets.fromLTRB(10.0, 0.0, 10, 15),
              hintText:
                  "I am a talented fashion designer with strong interest in arts, painting and fashion trends. I am also passionate about fencing and math. In my free time, I love to read, participate in unique building experiences and watch movies.",
              border: InputBorder.none,
              counterText: "",
              fillColor: Colors.transparent,
            ),
          ),
        ));
    final double statusBarHeight = MediaQuery.of(context).padding.top;
    return  GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child:  WillPopScope(
            onWillPop: () {},
            child:  Scaffold(
                backgroundColor:  Color(0XFFF4F2F2),
                body:  Stack(
                  children: <Widget>[

                  Positioned(
                  bottom: 0.0,
                  right: 13.0,
                  left: 13.0,
                  top: 0.0,
                  child:  FormKeyboardActions(
                      nextFocus: false,
                      keyboardActionsPlatform:
                      KeyboardActionsPlatform.ALL,
                      //optional
                      keyboardBarColor: Colors.grey[200],
                      //optional
                      actions: [
                        KeyboardAction(
                          focusNode: skillFocusNode,
                        ),
                      ],
                      child: SingleChildScrollView(
                      child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[

                        Padding(
                          padding: EdgeInsets.only(
                              top: statusBarHeight + 20,
                              left: 13.0,
                              right: 13.0,
                              bottom: 7),
                          child: Center(
                            child:  Image.asset(
                                "assets/progress_indecator/indicator_step2.png",
                                height: 26.0,
                                width: 250.0,
                                fit: BoxFit.fitWidth),
                          ),
                        ),
                        Column(
                          children: <Widget>[
                            /* Padding(
                                  padding: const EdgeInsets.fromLTRB(0.0, 80, 0, 10),
                                  child:  Image.asset("assets/profile/student/st12.png",
                                      height: 10.0, width: 100.0, fit: BoxFit.fitHeight),
                                ),*/Padding(
                              padding:
                              const EdgeInsets.fromLTRB(0.0, 30, 0, 10),
                              child:  Image.asset(
                                  "assets/profile/student/add_summary.png",
                                  height: 50.0,
                                  width: 50.0,
                                  fit: BoxFit.fitHeight),
                            ),
                            PaddingWrap.paddingfromLTRB(
                                20.0,
                                0.0,
                                20.0,
                                5.0,
                                TextViewWrap.textViewMultiLine(
                                    "Add Summary",
                                    TextAlign.center,
                                    ColorValues.HEADING_COLOR_EDUCATION,
                                    18.0,
                                    FontWeight.bold,
                                    6)),
                            PaddingWrap.paddingfromLTRB(
                                20.0,
                                0.0,
                                20.0,
                                11.0,
                                TextViewWrap.textViewMultiLine(
                                    "Your child unique 15 second elevator pitch. Make it clear and specific.",

                                    //  "Share some of your child’s experiences, achievements, accomplishments or anything they are proud of. This can also include extracurricular activities, clubs, hobbies, work or volunteering experiences, awards, hand-on projects, performance videos, blogs etc. Things done at school, outside or online.",
                                    TextAlign.center,
                                    ColorValues.HEADING_COLOR_EDUCATION,
                                    14.0,
                                    FontWeight.normal,
                                    6)),
                            skillUi,
                            Align(alignment: Alignment.centerRight,child:  TextViewWrap.textViewSingleLine(
                                addSummary.text.length.toString()+'/'+TextLength.SUMMARY_MSG_LENGTH.toString(),
                                TextAlign.center,
                                ColorValues.HEADING_COLOR_EDUCATION,
                                14.0,
                                FontWeight.normal)
                              ,)
                           ,
                          ],
                        )
                      ],
                    )))),
                    Positioned(
                        bottom: 0.0, left: 0, right: 0, child: MediaQuery.of(context)
                        .viewInsets.bottom==0?getBottomBar():new Container(height: 0.0,))
                /*     Positioned(
                        bottom: 0.0,
                        right: 13.0,
                        left: 13.0,
                        top: 0.0,
                        child: FormKeyboardActions(
                            nextFocus: false,
                            keyboardActionsPlatform: KeyboardActionsPlatform.ALL,
                            //optional
                            keyboardBarColor: Colors.grey[200],
                            //optional
                            actions: [
                              KeyboardAction(
                                focusNode: skillFocusNode,
                              ),

                            ],
                            child:  SingleChildScrollView(
                            child: ))),*/
                    /**/
                  ],
                ))));
  }

  void skipOnClick() async {
    if (ParentProfilePageState.isEducationAdded == "true") {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               AllEducationListWidget(studModel)));
    } else {
      /*await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               AddEducation_Widget(studModel, "yes","")));*/

      await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               AddChildEducationInitial(studModel, "yes", "")));

      setState(() {});
    }
  }

  void onNextClick() {
    // make Api Call
    if (studModel.tagline != addSummary.text)
      apiSummary();
    else {
      if (ParentProfilePageState.isEducationAdded == "true") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                 AllEducationListWidget(studModel)));
      } else {
        /*Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
             AddEducation_Widget(studModel, "yes","")));*/

        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                 AddChildEducationInitial(studModel, "yes", "")));
      }
    }
  }

  void onBackwordClick() {
    Navigator.pop(context);
  }
}
