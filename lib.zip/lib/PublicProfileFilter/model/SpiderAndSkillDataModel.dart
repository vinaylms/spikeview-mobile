import 'package:flutter/cupertino.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';

class SpiderAndSkillDataModel {
  String status;
  SpiderAndSkillData result;

  SpiderAndSkillDataModel({this.status, this.result});

  SpiderAndSkillDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    result = json['result'] != null
        ?   SpiderAndSkillData.fromJson(json['result'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class SpiderAndSkillData {
  List<SpiderDataChart> spiderChart;
  List<SkillDataChart> skillChart;

  SpiderAndSkillData({this.spiderChart, this.skillChart});

  SpiderAndSkillData.fromJson(Map<String, dynamic> json) {
    spiderChart =   List<SpiderDataChart>();
    skillChart =   List<SkillDataChart>();
    if (json['spiderChart'] != null) {

      json['spiderChart'].forEach((v) {
        spiderChart.add(new SpiderDataChart.fromJson(v));
      });
    }
    if (json['skillChart'] != null) {

      json['skillChart'].forEach((v) {
        skillChart.add(new SkillDataChart.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    if (this.spiderChart != null) {
      data['spiderChart'] = this.spiderChart.map((v) => v.toJson()).toList();
    }
    if (this.skillChart != null) {
      data['skillChart'] = this.skillChart.map((v) => v.toJson()).toList();
    }
    return data;
  }

  List<String> toName() {
    List<String> spiderName =   List<String>();
    if (this.spiderChart != null) {
      this.spiderChart.map((v) {
        spiderName.add(v.name);
      }).toList();
    }

    return spiderName;
  }

  List<double> toValue() {
    List<double> spiderChartValue =   List<double>();
    if (this.spiderChart != null) {
      this.spiderChart.map((v) {
        spiderChartValue.add(v.importance);
      }).toList();
    }

    return spiderChartValue;
  }
}

class SpiderDataChart {
  String iId;
  double importance;
  String name;
  String level1;
  String importanceTitle;

  SpiderDataChart(
      {this.iId,
      this.importance,
      this.name,
      this.level1,
      this.importanceTitle});

  SpiderDataChart.fromJson(Map<String, dynamic> json) {
    try {

      iId = json['_id'].toString();
      if (json['importance'] == null) {
        importance = 0.0;
      } else {
        importance = double.parse(json['importance'].toString());
      }
      name = json['name'];
      level1 = json['level1'];
      importanceTitle = json['importanceTitle'];
    } catch (e) {
      print("error+++++" + e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.iId;
    data['importance'] = this.importance;
    data['name'] = this.name;
    data['level1'] = this.level1;
    data['importanceTitle'] = this.importanceTitle;
    return data;
  }
}

class SkillDataChart {
  int skillId;
  String title;
  String description;
  double value;
  String name;
  Color color;

  SkillDataChart(
      {this.skillId, this.title, this.description, this.value, this.name});

  SkillDataChart.fromJson(Map<String, dynamic> json) {
    skillId = json['skillId'];
    title = json['title'];
    description = json['description'];
    value = double.parse(json['value'].toString());
    name = json['name'];

    if (json['value'].toString().length == 1) {
      value = value / 10;
    } else if (json['value'].toString().length == 2) {
      double offset = value / 100;
      value = .9 + offset;
      if (value >= 1) {
        value = .95;
      }
    } else if (json['value'].toString().length == 3) {
      double offset = value / 1000;
      value = .9 + offset;
      if (value >= 1) {
        value = .95;
      }
    }
     color = Color(0xff85D6F0);
    if (skillId == 1) {
      color = Color(0xff85D6F0);
    } else if (skillId == 2) {
      color = Color(0xffFD9D75);
    } else if (skillId == 3) {
      color = Color(0xffFD7575);
    } else if (skillId == 4) {
      color = Color(0xffFDC675);
    } else if (skillId == 5) {
      color = Color(0xff41BEC2);
    } else if (skillId == 6) {
      color = Color(0xff93DFE3);
    } else if (skillId == 7) {
      color = Color(0xffB06F49);
    } else if (skillId == 8) {
      color = Color(0xffAEE173);
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['skillId'] = this.skillId;
    data['title'] = this.title;
    data['description'] = this.description;
    data['value'] = this.value;
    data['name'] = this.name;
    return data;
  }
}
