import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';

class ProfileShareModel {
String _id,sharedId,sharedType,profileOwner,shareTime,isActive,isViewed,
    shareTo,shareToFirstName,shareToLastName,shareToEmail,shareToprofilePicture,roleId;
String profileOwnerRole;
String badge;
String badgeImage;
int gamificationPoints;
ProfileShareModel(this._id, this.sharedId, this.sharedType, this.profileOwner,
    this.shareTime, this.isActive, this.isViewed, this.shareTo,
    this.shareToFirstName, this.shareToLastName, this.shareToEmail,this.shareToprofilePicture,this.roleId,this.profileOwnerRole,this.badge,this.gamificationPoints,this.badgeImage);


}

