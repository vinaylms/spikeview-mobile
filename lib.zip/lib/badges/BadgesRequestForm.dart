import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/positive_button.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/component/custom_multiline_text_form.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class BadgesRequestForm extends StatefulWidget {
  int badgeId;
  String partnerId;

  BadgesRequestForm(this.partnerId, this.badgeId);

  @override
  BadgesRequestFormState createState() => BadgesRequestFormState();
}

class BadgesRequestFormState extends State<BadgesRequestForm> {
  var _messageController = TextEditingController();
  String message;
  SharedPreferences prefs;
  String userIdPref, userProfilePath, name, tagline;
  static StreamController syncDoneController = StreamController.broadcast();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    name = prefs.getString(UserPreference.NAME);
    tagline = prefs.getString(UserPreference.TAGLINE).trim();
    if (tagline == null || tagline == "null") tagline = "";

    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    setState(() {
      userProfilePath;
    });
  }



  void showSucessMsg(msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: msg,
          onNegativeTap: (){
          //  apiCallForDeleteOppo();
          Navigator.pop(context);

        },
          isSucessPopup: true ,
        );
      },

    );

  }

  showSucessMsgold(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");
      syncDoneController.add("msg");
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "badgeId": widget.badgeId,
          "partnerId": int.parse(widget.partnerId),
          "requestedBy": userIdPref,
          "message": _messageController.text.trim().toString()
        };
        print("map++++" + map.toString());
        response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_BADGE_REQUEST, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              showSucessMsg(msg);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {


    var messageBox = Padding(
      padding: EdgeInsets.only(left: 20, right: 20, top: 18),
      child: Container(
        //alignment: Alignment.topLeft,
        margin: const EdgeInsets.only(
            top: 5, bottom: 0),

        width: double.infinity,
        //MediaQuery.of(context).size.width,
        height: 120,

        child: CustomMultilineTextForm(
          maxLines: 6,
          maxLength: TextLength.BADGE_MSG_LENGTH,
          // focusNode:  issuerMessage,
          controller: _messageController,
          // focusNode: detailNode,
          textAlign: TextAlign.start,
          hint:
          "I participated in your program in the spring of 2020 and was a leader of the team. Please issue a leader badge so I can add to my profile",        label: '',
          //  errorText:isShowErrorRequested?errorMsg:null ,
          alignLabelWithHint: true,
          textInputAction:
          TextInputAction.done,
          textInputType:
          TextInputType.multiline,
          validation: (value) {
            // if (value
            //     .toString()
            //     .trim()
            //     .isEmpty) {
            //   return 'Please add text';
            // }
            return null;
          },
          onSaved: (val) {
            // onLoad();

          },
          onType: (val) {
            // onLoad();
          },
        ),

      ),
    );












    var submitBtn =  Padding(
        padding: EdgeInsets.fromLTRB(14.0, 15.0, 14.0, 0.0),
        child:  GestureDetector(
          child:  Container(
            width: MediaQuery.of(context).size.width,
            height: 50.0,
            alignment: FractionalOffset.center,
            decoration:  BoxDecoration(
              border: Border.all(color: ColorValues.BLUE_COLOR_BOTTOMBAR),
              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
              borderRadius:  BorderRadius.all(const Radius.circular(0.0)),
            ),
            child:  Text(
              "SUBMIT REQUEST",
              style:  TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          ),
          onTap: () {
            if (_messageController.text.trim() == "") {
              ToastWrap.showToast(MessageConstant.BADGE_VALIDATION, context);
            } else {
              apiCalling();
            }
          },
        ));

    approveRejectButtonsNew() {
      return
        Container(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
          height: 90,
          //currentStep == 0 ? 0 : 90,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromRGBO(204, 220, 247, 0.46),
                blurRadius: 13,
                spreadRadius: 10,
              ),
            ],
          ),
          child: Row(
            children: [

              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(left: 0),
                  child: SizedBox(
                    height: 44,
                    child: PositiveButton(
                      onTap: () {
                        print("Submit request");
                        if (_messageController.text.trim() == "") {
                          ToastWrap.showToast(MessageConstant.BADGE_VALIDATION, context);
                        } else {
                          apiCalling();
                        }
                      },
                      // isEnable: true,
                      isEnable:true,
                      title: "Submit request",
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:
        customAppbar(
          context,
          GestureDetector(

              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child:
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20, top: 20, bottom: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox()
                        ],
                      ),
                    ),
                    flex: 0,
                  ),

                  Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0,
                          right: 0.0,
                          top: 0.0,
                          bottom: 0),
                      child: RichText(
                        maxLines: 1,
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          text: 'Badges',
                          style: AppConstants.txtStyle
                              .heading400LatoRegularDarkBlue
                              .copyWith(
                              fontSize: 28,
                              fontWeight: FontWeight.w700),
                          children: [
                            TextSpan(
                                text: '',
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {},
                                style: AppConstants.txtStyle
                                    .heading40018LatoRegularDarkBlue
                                    .copyWith(
                                    fontSize: 28,
                                    fontWeight:
                                    FontWeight.w700)),
                          ],
                        ),
                      )),

                  Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0,
                        right: 10.0,
                        top: 15.0,
                        bottom: 0),
                    child:Text(
                      "Send a note to the partner requesting a badge that can be added to your profile",
                      textAlign:
                      TextAlign.left,
                      maxLines: 5,
                      style: TextStyle(
                          color: ColorValues
                              .labelColor,
                          fontSize: 16.0,
                          fontWeight:
                          FontWeight.w500,
                          fontFamily: Constant
                              .latoRegular),
                    ),
                  ),

                  Expanded(
                    child: ListView(
                      padding: EdgeInsets.zero,
                      children: <Widget>[

                        Row(
                          children: <Widget>[
                            Expanded(
                              flex: 0,
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 20.0, top: 15, right: 10.0),
                                child:

                                // Container(
                                //   height: 60.0,
                                //   width: 60.0,
                                //   child:
                                //   ClipRRect(
                                //     borderRadius: BorderRadius.circular(100),
                                //     child: FadeInImage(
                                //       fit: BoxFit.cover,
                                //       placeholder: AssetImage(
                                //         'assets/profile/user_on_user.png',
                                //       ),
                                //       image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                                //           ParseJson.getSmallImage(userProfilePath)),
                                //     ),
                                //   ),
                                // ),
                                 InkWell(
                              child:  ProfileImageView(
                              imagePath:Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getSmallImage(userProfilePath),
                             placeHolderImage: 'assets/profile/user_on_user.png',
                             height: 50.0,
                             width:50.0,

                             onTap: () async {},
                             borderRadius: 10,

                         ),
                    onTap: () {},
                  ),


                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Expanded(
                                    flex: 0,
                                    child: Padding(
                                      padding: const EdgeInsets.only(top: 13.0),
                                      child: Text(
                                        name,
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                        color: ColorValues.HEADING_COLOR_EDUCATION_1),
                                      ),
                                    ),
                                  ),

                                 tagline == "" ? const SizedBox() :
                                  Expanded(
                                    flex: 0,
                                    child: Text(
                                      tagline,
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.w400,
                                          color: ColorValues.labelColor)
                                    ),
                                  ),
                                ],
                              ),
                             )
                           ],
                          ),

                        Padding(
                          padding: const EdgeInsets.only(
                              left: 20.0,
                              right: 10.0,
                              top: 20.0,
                              bottom: 0),
                          child:Text(
                            "Description",
                            textAlign:TextAlign.left,
                            maxLines: 5,
                            style: TextStyle(
                                color: ColorValues
                                    .labelColor,
                                fontSize: 18.0,
                                fontWeight:
                                FontWeight.w500,
                                fontFamily: Constant
                                    .latoRegular),
                          ),
                        ),


                        messageBox,
                       // submitBtn
                      ],
                    ),
                  ),
                ],
              )
          ),
              () {
            Navigator.pop(context);
          },
          isShowIcon: false,

          bottomNavigation:  approveRejectButtonsNew() ,
          //approveRejectButtons()
        )
    );

    return Scaffold(
        appBar:  AppBar(
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          brightness: Brightness.light,
          leading:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               InkWell(
                child:  SizedBox(
                  height: 40.0,
                  width: 40.0,
                  child: PaddingWrap.paddingfromLTRB(
                      10.0,
                      5.0,
                      0.0,
                      3.0,
                       Center(
                          child:  Image.asset(
                              "assets/newDesignIcon/navigation/back.png",
                              height: 20.0,
                              width: 10.0,
                              fit: BoxFit.fitHeight))),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              )
            ],
          ),
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               Text(
                "Badges",
                style:  TextStyle(
                    fontSize: 18.0,
                    fontFamily: Constant.customRegular,
                    color:  ColorValues.HEADING_COLOR_EDUCATION),
              )
            ],
          ),
          actions: <Widget>[
             Container(
              width: 35.0,
            ),
          ],
          backgroundColor: Colors.white,
          elevation: 0.0,
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              height: 1.0,
              color: ColorValues.GREY__COLOR_DIVIDER,
            ),
            Expanded(
              child: ListView(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.fromLTRB(13.0, 11.0, 13.0, 10.0),
                    child: Text(
                      "Send a note to the partner requesting a badge that can be added to your profile",
                      style: TextStyle(
                          color: ColorValues.GREY_TEXT_COLOR,
                          fontSize: 12,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          fontWeight: FontWeight.normal),
                    ),
                  ),
                   Row(
                    children: <Widget>[
                      Expanded(
                        flex: 0,
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 13.0, top: 12.50, right: 10.0),
                          child:  Container(
                            height: 60.0,
                            width: 60.0,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(100),
                              child: FadeInImage(
                                fit: BoxFit.cover,
                                placeholder: AssetImage(
                                  'assets/profile/user_on_user.png',
                                ),
                                image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                                    ParseJson.getSmallImage(userProfilePath)),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Expanded(
                              flex: 0,
                              child: Padding(
                                padding: const EdgeInsets.only(top: 10.0),
                                child: Text(
                                  name,
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 0,
                              child: Text(
                                tagline,
                                style: TextStyle(
                                  color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  fontSize: 12,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  messageBox,
                  submitBtn
                ],
              ),
            ),
          ],
        ));
  }
}
