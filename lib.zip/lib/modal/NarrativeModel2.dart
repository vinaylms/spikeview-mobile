import 'dart:io';

import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/LinkUrlModel.dart';

class NarrativeModel {
  String id, name, level1, orderBy;
  double imoportanceValue = 0.0;
  double imoportanceValueCopy = 0.0;
  List<Achivment> achivmentList;
  List<Recomdation> recommendationtList;
  List<String> certificateListAll;
  List<String> badgeListAll;
  List<String> trophyListAll;
  bool isVisible;
  bool isShowAll = false;

  NarrativeModel(
      this.id,
      this.name,
      this.level1,
      this.orderBy,
      this.achivmentList,
      this.recommendationtList,
      this.badgeListAll,
      this.trophyListAll,
      this.certificateListAll,
      this.isVisible,
      this.imoportanceValue,
      this.imoportanceValueCopy,
      this.isShowAll);

  Map<String, dynamic> toJson() => {
        'competencyTypeId': int.parse(id),
        'importance': imoportanceValue.toInt(),
      };

  NarrativeModel.clone(NarrativeModel source)
      : this.id = source.id,
        this.name = source.name,
        this.level1 = source.level1,
        this.orderBy = source.orderBy,
        this.achivmentList = source.achivmentList
            .map((item) =>  Achivment.clone(item))
            .toList(),
        this.recommendationtList = source.recommendationtList
            .map((item) =>  Recomdation.clone(item))
            .toList(),
        this.certificateListAll =
            source.certificateListAll.map((item) => (item)).toList(),
        this.badgeListAll = source.badgeListAll.map((item) => (item)).toList(),
        this.trophyListAll =
            source.trophyListAll.map((item) => (item)).toList(),
        this.isVisible = source.isVisible,
        this.isShowAll = source.isShowAll,
        this.imoportanceValue = source.imoportanceValue,
        this.imoportanceValueCopy = source.imoportanceValueCopy;
}

class Recomdation {
  String _id,
      recommendationId,
      userId,
      recommenderId,
      competencyTypeId,
      level3Competency,
      level2Competency,
      title,
      request,
      recommendation,
      stage,
      interactionStartDate,
      interactionEndDate,
      requestedDate,
      repliedDate,
      isActive = "true",
      __v;
  bool isShowMore = false;
  List<Likes2> likeList;

  Recomdation(
      this._id,
      this.recommendationId,
      this.userId,
      this.recommenderId,
      this.competencyTypeId,
      this.level3Competency,
      this.level2Competency,
      this.title,
      this.request,
      this.recommendation,
      this.stage,
      this.interactionStartDate,
      this.interactionEndDate,
      this.requestedDate,
      this.repliedDate,
      this.isActive,
      this.__v,
      this.likeList,
      this.skillList,
      this.assestList,
      this.certificateList,
      this.badgeList,
      this.recommender,
      this.user,
      this.isShowMore,
      this.trophyList,
      this.mediaList);

  List<Skill> skillList;
  List<Assest> assestList;
  List<String> certificateList;
  List<String> badgeList;
  List<String> trophyList;
  List<String> mediaList;
  Recommender recommender;
  User user;

  Recomdation.clone(Recomdation source)
      : this._id = source._id,
        this.recommendationId = source.recommendationId,
        this.userId = source.userId,
        this.recommenderId = source.recommenderId,
        this.competencyTypeId = source.competencyTypeId,
        this.level3Competency = source.level3Competency,
        this.level2Competency = source.level2Competency,
        this.title = source.title,
        this.request = source.request,
        this.recommendation = source.recommendation,
        this.stage = source.stage,
        this.interactionStartDate = source.interactionStartDate,
        this.interactionEndDate = source.interactionEndDate,
        this.requestedDate = source.requestedDate,
        this.repliedDate = source.repliedDate,
        this.isActive = source.isActive,
        this.__v = source.__v,
        this.isShowMore = source.isShowMore,
        this.likeList =
            source.likeList.map((item) =>  Likes2.clone(item)).toList(),
        this.skillList =
            source.skillList.map((item) =>  Skill.clone(item)).toList(),
        this.assestList =
            source.assestList.map((item) =>  Assest.clone(item)).toList(),
        this.certificateList =
            source.certificateList.map((item) => (item)).toList(),
        this.badgeList = source.badgeList.map((item) => (item)).toList(),
        this.recommender =  Recommender.clone(source.recommender),
        this.user =  User.clone(source.user),
        this.trophyList = source.trophyList.map((item) => (item)).toList(),
        this.mediaList = source.mediaList.map((item) => (item)).toList();
}

class User {
  String firstName, lastName, profilePicture, email, tagline, title;

  User(this.firstName, this.lastName, this.profilePicture, this.email,
      this.tagline, this.title);

  User.clone(User source)
      : this.firstName = source.firstName,
        this.lastName = source.lastName,
        this.profilePicture = source.profilePicture,
        this.email = source.email,
        this.tagline = source.tagline,
        this.title = source.title;
}

class Achivment {
  String _id,
      achievementId,
      competencyTypeId,
      level2Competency,
      level3Competency,
      userId,
      title,
      description,
      fromDate,
      toDate,
      isActive,
      importance,
      guidePromptRecommendation,
      hoursWorkedPerWeek,
      allSkill,
      __v,
      sheight,
      sweight;

  bool isShowMore = false;
  List<String> storiesList;
  List<Likes2> likeList;
  List<Skill> skillList;
  List<Assest> assestList;
  List<String> mediaList;
  //List<String> mediaList;
  List<String> certificateList;
  List<String> badgeList;
  List<String> trophyList;
  List<String> allCer_Badge_Trophy;
  String coachEmail,
      coachLastName,
      coachFirstName,
      recommendationTitle,
      recommenderTitle,
      recommenderRequest;

  String createdTimestamp, parentId;
  String personalStatement, city, state, age, type, userImage;
  List<Stats> statsList;
  List<Team> teamList;
  List<PortFolioAssest> portFolioAssestList;
  //List<ExternalLinks> externalLinksList;
  List<LinkUrlModel> externalLinksList;

  Achivment(
      this._id,
      this.achievementId,
      this.competencyTypeId,
      this.level2Competency,
      this.level3Competency,
      this.userId,
      this.title,
      this.description,
      this.fromDate,
      this.toDate,
      this.isActive,
      this.importance,
      this.allSkill,
      this.__v,
      this.guidePromptRecommendation,
      this.storiesList,
      this.likeList,
      this.skillList,
      this.assestList,
      this.certificateList,
      this.badgeList,
      this.trophyList,
      this.mediaList,
      this.coachFirstName,
      this.coachLastName,
      this.coachEmail,
      this.recommendationTitle,
      this.recommenderTitle,
      this.isShowMore,
      this.allCer_Badge_Trophy,
      this.recommenderRequest,
      this.hoursWorkedPerWeek,
      this.sheight,
      this.sweight,
      this.createdTimestamp,
      this.parentId,
      this.personalStatement,
      this.city,
      this.state,
      this.age,
      this.type,
      this.userImage,
      this.statsList,
      this.teamList,
      this.externalLinksList,
      this.portFolioAssestList);

  Achivment.clone(Achivment source)
      : this._id = source._id,
        this.achievementId = source.achievementId,
        this.competencyTypeId = source.competencyTypeId,
        this.level2Competency = source.level2Competency,
        this.level3Competency = source.level3Competency,
        this.userId = source.userId,
        this.title = source.title,
        this.description = source.description,
        this.fromDate = source.fromDate,
        this.toDate = source.toDate,
        this.isActive = source.isActive,
        this.importance = source.importance,
        this.allSkill = source.allSkill,
        this.__v = source.__v,
        this.guidePromptRecommendation = source.guidePromptRecommendation,
        this.coachFirstName = source.coachFirstName,
        this.coachLastName = source.coachLastName,
        this.coachEmail = source.coachEmail,
        this.recommendationTitle = source.recommendationTitle,
        this.recommenderTitle = source.recommenderTitle,
        this.recommenderRequest = source.recommenderRequest,
        this.isShowMore = source.isShowMore,
        this.storiesList = source.storiesList.map((item) => (item)).toList(),
        this.likeList =
            source.likeList.map((item) =>  Likes2.clone(item)).toList(),
        this.skillList =
            source.skillList.map((item) =>  Skill.clone(item)).toList(),
        this.assestList =
            source.assestList.map((item) =>  Assest.clone(item)).toList(),
        this.certificateList =
            source.certificateList.map((item) => (item)).toList(),
        this.badgeList = source.badgeList.map((item) => (item)).toList(),
        this.trophyList = source.trophyList.map((item) => (item)).toList(),
        this.allCer_Badge_Trophy =
            source.allCer_Badge_Trophy.map((item) => (item)).toList(),
        this.mediaList = source.mediaList.map((item) => (item)).toList(),
        this.hoursWorkedPerWeek = source.hoursWorkedPerWeek,
        this.sheight = source.sheight,
        this.sweight = source.sweight;
}

class Stats {
  String value, label, playingPosition;

  Stats(this.value, this.label, this.playingPosition);
}

class Team {
  String teamType;
  List<TeamData> teamDataList;

  Team(this.teamType, this.teamDataList);
}

class TeamData {
  String coachCountryCode,
      coachPhoneNo,
      coachEmail,
      coachName,
      jersey,
      state,
      city,
      teamName,
      orgName;

  TeamData(
      this.coachCountryCode,
      this.coachPhoneNo,
      this.coachEmail,
      this.coachName,
      this.jersey,
      this.state,
      this.city,
      this.teamName,
      this.orgName);
}

class ExternalLinks {
  String description, url, label;

  ExternalLinks(this.description, this.url, this.label);
}

class Likes2 {
  String userId, name, profilePicture, title;

  Likes2(this.userId, this.name, this.profilePicture, this.title);

  Likes2.clone(Likes2 source)
      : this.userId = source.userId,
        this.name = source.name,
        this.profilePicture = source.profilePicture,
        this.title = source.title;
}

class PortFolioAssest {
  String type, tag, file, statistics, description, label;

  PortFolioAssest(this.type, this.tag, this.file, this.statistics,
      this.description, this.label);
}

class Assest {
  String type, tag, file, statistics, description, label;
  bool isSelected = false;

  Assest(
    this.type,
    this.tag,
    this.file,
    this.isSelected,
  );

  Map<String, dynamic> toJson() => {
        'type': type,
        'tag': tag,
        'file': file,
      };

  Assest.clone(Assest source)
      : this.type = source.type,
        this.tag = source.tag,
        this.file = source.file;

  static Map<String, dynamic> toMap(Assest assetObject) {
    Map<String, dynamic> assetMap = Map();
    assetMap['type'] = assetObject.type;
    assetMap['tag'] = assetObject.tag;
    assetMap['file'] = assetObject.file;

    return assetMap;
  }

  static List<Map<String, dynamic>> mapList(List<Assest> assets) {
    List<Map<String, dynamic>> listOfAsset = assets
        .map((asset) => {
              "type": asset.type,
              "tag": asset.tag,
              "file": asset.file,
            })
        .toList();
    return listOfAsset;
  }
}

class OtherCategory {
  String name, categoryId, isOther;

  OtherCategory(this.name, this.categoryId, this.isOther);

  String toMapString() {
    String data = "";

    data = data + this.name;

    return data;
  }
}

class AssestWithFile {
  String path;

  File file;

  AssestWithFile(this.path, this.file);
}

class Assest2 {
  String type, tag, file;
  bool isSelected = false;

  Assest2(this.type, this.tag, this.file, this.isSelected);

  Map<String, dynamic> toJson() => {
        'type': type,
        'tag': tag,
        'file': file,
      };

  Assest2.clone(Assest source)
      : this.type = source.type,
        this.tag = source.tag,
        this.file = source.file;
}

class TagsPost {
  String userId, roleId;

  TagsPost(this.userId, this.roleId);

  Map<String, dynamic> toJson() =>
      {'userId': int.parse(userId), 'roleId': int.parse(roleId)};
}

class AssestForPost {
  String imagePath;
  String type, file;
  bool isSelected = false;

  AssestForPost(this.imagePath, this.type, this.file, this.isSelected);

  Map<String, dynamic> toJson() => {
        'type': type,
        'file': file,
      };
}

class Guide {
  String email, lastName, firstName;
  bool promptRecommendation = false;

  Guide(this.email, this.lastName, this.firstName, this.promptRecommendation);
}

class Images {
  String imagePath;

  Images(this.imagePath);
}

class Skill {
  String label, skillId;
  int index;

  Skill(this.label, this.skillId, this.index);

  Map<String, dynamic> toJson() => {
        'label': label,
        'skillId': skillId,
      };

  Skill.clone(Skill source)
      : this.label = source.label,
        this.skillId = source.skillId;
}

class Recommender {
  String _id,
      userId,
      firstName,
      lastName,
      email,
      password,
      salt,
      mobileNo,
      roleId,
      isActive,
      isPasswordChanged,
      organizationId,
      dob,
      title,
      tempPassword,
      isArchived,
      profilePicture,
      __v;

  Recommender(
      this._id,
      this.userId,
      this.firstName,
      this.lastName,
      this.email,
      this.password,
      this.salt,
      this.mobileNo,
      this.roleId,
      this.isActive,
      this.isPasswordChanged,
      this.organizationId,
      this.dob,
      this.title,
      this.tempPassword,
      this.isArchived,
      this.profilePicture,
      this.__v);

  Recommender.clone(Recommender source)
      : this._id = source._id,
        this.userId = source.userId,
        this.firstName = source.firstName,
        this.lastName = source.lastName,
        this.email = source.email,
        this.password = source.password,
        this.salt = source.salt,
        this.mobileNo = source.mobileNo,
        this.roleId = source.roleId,
        this.isActive = source.isActive,
        this.isPasswordChanged = source.isPasswordChanged,
        this.organizationId = source.organizationId,
        this.dob = source.dob,
        this.title = source.title,
        this.tempPassword = source.tempPassword,
        this.isArchived = source.isArchived,
        this.profilePicture = source.profilePicture,
        this.__v = source.__v;
}
