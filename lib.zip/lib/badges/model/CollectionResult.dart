class Result {
  Result({
      this.badgeReqId, 
      this.message, 
      this.status, 
      this.date, 
      this.type, 
      this.name, 
      this.image, 
      this.badgeId, 
      this.companyName,
      this.userImage,
      this.userName,
      this.isActive,


     this.userTagline,this.userId, this.userRoleId});

  Result.fromJson(dynamic json) {
    badgeReqId = json['badgeReqId'];
    message = json['message'];
    status = json['status'];
    date = json['date'];
    type = json['type'];
    name = json['name'];
    image = json['image'];
    badgeId = json['badgeId'];
    companyName = json['companyName'];
    userImage = json['userImage'];
    userName = json['userName'];
    userTagline = json['userTagline'];
    userId = json['userId'].toString();
    userRoleId = json['userRoleId'].toString();
    userName = json['userName'];
    isActive = json['isActive'].toString();



  }
  int badgeReqId;
  String message;
  String status;
  int date;
  String type;
  String name;
  String image;
  int badgeId;
  String isActive;

  String companyName, userImage, userName, userTagline;
  bool isMore = false;

  String userId;
  String userRoleId;
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['badgeReqId'] = badgeReqId;
    map['message'] = message;
    map['status'] = status;
    map['date'] = date;
    map['type'] = type;
    map['name'] = name;
    map['image'] = image;
    map['badgeId'] = badgeId;
    map['companyName'] = companyName;
    map['userImage'] = userImage;
    map['userName'] = userName;
    map['userTagline'] = userTagline;
    map['isActive'] = isActive;
    map['userId'] = userId;
    map['userRoleId'] = userRoleId;
    return map;
  }

}