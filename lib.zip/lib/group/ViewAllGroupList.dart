import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ViewAllGroupListWidget extends StatefulWidget {
  GroupListModel groupListModel;
  String listType, sasToken, containerName, title;

  ViewAllGroupListWidget(this.groupListModel, this.listType, this.sasToken,
      this.containerName, this.title);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    // ignore: return_of_invalid_type
    return  MainView();
  }
}

class MainView extends State<ViewAllGroupListWidget> {
  BuildContext context;
  SharedPreferences prefs;
  String userIdPref, roleId, userProfilePath;
  String isPerformChanges = "pop";

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }

  // -------------------  API ------------------------------

  @override
  Widget build(BuildContext context) {
    this.context = context;

    Paint paint = Paint()
      ..color =  ColorValues.LIGHT_GREY_TEXT_COLOR
      ..style = PaintingStyle.fill
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 0.0;

    Future apiCallingForAccept(groupId, index, type) async {
      try {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          Map map = {
            "groupId": int.parse(groupId),
            "userId": int.parse(userIdPref),
            "status": type,     "isAdmin": false,
            "roleId": int.parse(roleId)
          };
          Response response = await  ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

          print("response:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                // ToastWrap.showToast(msg);
                isPerformChanges = "push";

                widget.groupListModel.groupInvitationList.removeAt(index);

                setState(() {
                  isPerformChanges;
                  widget.groupListModel.groupInvitationList;
                });
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      } catch (e) {
        e.toString();
      }
    }



    Future apiCallForDelete(groupId, index) async {
      try {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          Map map = {
            "groupId": groupId,
            "status": "Rejected",
            "isAdmin": true,
            "roleId": int.parse(roleId),
            "userId": int.parse(userIdPref),
          };

          Response response = await  ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_DELETE_GROUP_MEMBER, map);

          print("response:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                //ToastWrap.showToast(msg);
                isPerformChanges = "push";
                if (mounted) {
                  widget.groupListModel.groupRequestList.removeAt(index);

                  setState(() {
                    isPerformChanges;
                    widget.groupListModel.groupRequestList;
                  });
                }
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      } catch (e) {
        e.toString();
      }
    }

    onTapGroupTile(groupModel) async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>  GroupDetailWidget(
              groupModel.groupId,
              "",
              widget.sasToken,
              widget.containerName,
              "")));
      if (result == "push") {
        Navigator.pop(context, "push");
      } else {
        Navigator.pop(context, isPerformChanges);
      }
    }

    Widget getListview(groupModel, index) {
      return PaddingWrap.paddingAll(
        10.0,
         InkWell(
          child:  Container(
              color: Colors.white,
              padding:  EdgeInsets.fromLTRB(10.0, 15.0, 10.0, 15.0),
              child:  Card(
                  color: Colors.transparent,
                  elevation: 0.0,
                  child:  Column(
                    children: <Widget>[
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  InkWell(
                              child:  Container(
                                height: 60.0,
                                width: 60.0,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(100),
                                  child: FadeInImage(
                                    fit: BoxFit.cover,
                                    placeholder: AssetImage(
                                      'assets/newDesignIcon/group/default_circle_bg.png',
                                    ),
                                    image: NetworkImage(
                                        Constant.IMAGE_PATH_SMALL +
                                            ParseJson.getSmallImage(
                                                groupModel.groupImage)),
                                  ),
                                ),
                              ),
                            ),
                            flex: 0,
                          ),
                           Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                0.0,
                                0.0,
                                 Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        2.0,
                                        2.0,
                                        5.0,
                                        RichText(
                                          maxLines: 2,
                                          textAlign: TextAlign.start,
                                          text: TextSpan(
                                            text: groupModel.groupName + "  ",
                                            style:  TextStyle(
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                            children: (!groupModel.isAdmin)
                                                ? null
                                                : <TextSpan>[
                                                    TextSpan(
                                                        text: '(Owner)',
                                                        style: TextStyle(
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR,
                                                            fontSize: 12.0,
                                                            color:  Color(
                                                                0xFF404040)))
                                                  ],
                                          ),
                                        )),
                                     Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  Row(
                                            children: <Widget>[
                                               Image.asset(
                                                groupModel.type == "private"
                                                    ? "assets/newDesignIcon/group/private_grey.png"
                                                    : "assets/newDesignIcon/group/public_grey.png",
                                                height: 15.0,
                                                width: 15.0,
                                              ),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  3.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap
                                                      .textViewMultiLine(
                                                          groupModel.type ==
                                                                  MessageConstant.ABOUT_GROUP_PRIVATE
                                                              ? MessageConstant.ABOUT_GROUP_PRIVATE_GROUP
                                                              : MessageConstant.ABOUT_GROUP_PUBLIC_GROUP,
                                                          TextAlign.center,
                                                            ColorValues.GREY_TEXT_COLOR,
                                                          12.0,
                                                          FontWeight.normal,
                                                          1))
                                            ],
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    )
                                  ],
                                )),
                            flex: 1,
                          ),
                        ],
                      ),
                      groupModel.status == MessageConstant.INVITE_EMAIL_INVITED
                          ?  Column(children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  10.0,
                                  20.0,
                                  10.0,
                                  0.0,
                                   Divider(
                                    color:   ColorValues.DEVIDER_COLOR,
                                    height: 1.0,
                                  )),
                               Row(
                                children: <Widget>[
                                   Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        20.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                        TextViewWrap.textView(
                                            MessageConstant.ABOUT_GROUP_RESPOND_GROUP_INVITATION,
                                            TextAlign.start,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.normal)),
                                    flex: 1,
                                  ),
                                   Expanded(
                                    child:  InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          10.0,
                                          0.0,
                                          0.0,
                                           Image.asset(
                                            "assets/newDesignIcon/connections/tick_blue.png",
                                            height: 35.0,
                                            width: 35.0,
                                          )),
                                      onTap: () {
                                        apiCallingForAccept(
                                            groupModel.groupId, 0, "Accepted");
                                      },
                                    ),
                                    flex: 0,
                                  ),
                                   Expanded(
                                    child:  InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          2.0,
                                          10.0,
                                          5.0,
                                          0.0,
                                           Image.asset(
                                            "assets/newDesignIcon/navigation/cancel_circle.png",
                                            height: 35.0,
                                            width: 35.0,
                                          )),
                                      onTap: () {
                                        apiCallingForAccept(
                                            groupModel.groupId, 0, MessageConstant.ABOUT_GROUP_REJECTED);
                                      },
                                    ),
                                    flex: 0,
                                  )
                                ],
                              ),
                            ])
                          : groupModel.status == MessageConstant.ABOUT_GROUP_REQUESTED
                              ?  Column(children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      20.0,
                                      10.0,
                                      0.0,
                                       Divider(
                                        color:  ColorValues.DEVIDER_COLOR,
                                        height: 1.0,
                                      )),
                                   Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: PaddingWrap.paddingfromLTRB(
                                            20.0,
                                            10.0,
                                            0.0,
                                            0.0,
                                            TextViewWrap.textView(
                                                MessageConstant.ABOUT_GROUP_REQUEST_PENDING,
                                                TextAlign.start,
                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                14.0,
                                                FontWeight.normal)),
                                        flex: 1,
                                      ),
                                       Expanded(
                                        child:  InkWell(
                                          child: PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              10.0,
                                              0.0,
                                              0.0,
                                               Text(
                                                "Revoke",
                                                style:  TextStyle(
                                                    color:   ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                                    fontSize: 12.0,
                                                    fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                          onTap: () {
                                            apiCallForDelete(
                                                groupModel.groupId, index);
                                          },
                                        ),
                                        flex: 0,
                                      ),
                                    ],
                                  ),
                                ])
                              :  Container(
                                  height: 0.0,
                                )
                    ],
                  ))),
          onTap: () {
            onTapGroupTile(groupModel);
          },
        ),
      );
    }

    Widget getListviewForChild(groupModel, index) {
      print("url" + groupModel.groupImage);

      return PaddingWrap.paddingfromLTRB(
        10.0,
        0.0,
        10.0,
        0.0,
         InkWell(
          child:  Container(
              padding:  EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 5.0),
              child:  Card(
                  color: Colors.transparent,
                  elevation: 0.0,
                  child:  Column(
                    children: <Widget>[

                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  InkWell(
                              child:  Container(
                                height: 60.0,
                                width: 60.0,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(100),
                                  child: groupModel.groupImage == "" ||
                                      groupModel.groupImage == "null"
                                      ?  Image.asset(
                                      'assets/newDesignIcon/group/default_circle_bg.png')
                                      : FadeInImage(
                                    fit: BoxFit.cover,
                                    placeholder: AssetImage(
                                      'assets/newDesignIcon/group/default_circle_bg.png',
                                    ),
                                    image: NetworkImage(
                                        Constant.IMAGE_PATH_SMALL +
                                            ParseJson.getSmallImage(
                                                groupModel.groupImage)),
                                  ),
                                ),
                              ),
                            ),
                            flex: 0,
                          ),
                           Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                0.0,
                                0.0,
                                 Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        7.0,
                                        2.0,
                                        2.0,
                                        5.0,
                                        RichText(
                                          maxLines: 2,
                                          textAlign: TextAlign.start,
                                          text: TextSpan(
                                            text: groupModel.groupName + " ",
                                            style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            children: (!groupModel.isAdmin)
                                                ? null
                                                : <TextSpan>[
                                              TextSpan(
                                                  text: '(Owner)',
                                                  style: TextStyle(
                                                      fontWeight:
                                                      FontWeight
                                                          .normal,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 12.0,
                                                      color:  Color(
                                                          0xFF404040)))
                                            ],
                                          ),
                                        )),
                                     Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                7.0,
                                                3.0,
                                                0.0,
                                                0.0,
                                                 Image.asset(
                                                  groupModel.type == "private"
                                                      ? "assets/newDesignIcon/group/private_grey.png"
                                                      : "assets/newDesignIcon/group/public_grey.png",
                                                  height: 15.0,
                                                  width: 15.0,
                                                ),
                                              ),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  3.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap
                                                      .textViewMultiLine(
                                                      groupModel.type ==
                                                          "private"
                                                          ? " Private Group"
                                                          : " Public Group",
                                                      TextAlign.center,
                                                       ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal,
                                                      1))
                                            ],
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    )
                                  ],
                                )),
                            flex: 1,
                          ),
                           Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                              5.0,
                              0.0,
                              0.0,
                              0.0,
                               Column(children: <Widget>[
                                 Row(
                                  children: <Widget>[
                                     Expanded(
                                      child:  InkWell(
                                        child: PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            10.0,
                                            0.0,
                                            0.0,
                                             Image.asset(
                                              "assets/newDesignIcon/connections/tick_blue.png",
                                              height: 40.0,
                                              width: 40.0,
                                            )),
                                        onTap: () {
                                          apiCallingForAccept(
                                              groupModel.groupId,
                                              0,
                                              "Accepted");
                                        },
                                      ),
                                      flex: 0,
                                    ),
                                     Expanded(
                                      child:  InkWell(
                                        child: PaddingWrap.paddingfromLTRB(
                                            2.0,
                                            10.0,
                                            5.0,
                                            0.0,
                                             Image.asset(
                                              "assets/newDesignIcon/navigation/cancel_circle.png",
                                              height: 40.0,
                                              width: 40.0,
                                            )),
                                        onTap: () {
                                          apiCallingForAccept(
                                              groupModel.groupId,
                                              0,
                                              "Rejected");
                                        },
                                      ),
                                      flex: 0,
                                    )
                                  ],
                                ),
                              ]),
                            ),
                            flex: 0,
                          ),
                        ],
                      ),

                      PaddingWrap.paddingfromLTRB(
                          10.0,
                          16.0,
                          10.0,
                          0.0,
                           Divider(
                            color:  ColorValues.GREY_TEXT_COLOR,
                            height: 0.5,
                          )),
                    ],
                  ))),
          onTap: () {
            onTapGroupTile(groupModel);
          },
        ),
      );
    }



    return MaterialApp(
      home:  WillPopScope(
          onWillPop: () {
            Navigator.pop(context, isPerformChanges);
          },
          child: Scaffold(
            backgroundColor:  ColorValues.singin_bg_color,
            appBar: AppBar(
                backgroundColor: Colors.white,
                automaticallyImplyLeading: true,
                elevation: 0.0,
                centerTitle: true,
                title: Text(widget.title,
                    style: TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16.0,
                        fontFamily: Constant.customRegular)),
                leading:  InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0, 0.0, 15.0, 0.0, CustomViews.getBackButton()),
                  onTap: () {
                    Navigator.pop(context, isPerformChanges);
                  },
                )),
            body:  ListView(children: <Widget>[
              CustomViews.getSepratorLine(),
               Column(children: <Widget>[
                widget.listType == "groupList"
                    ?  Column(
                        children:  List.generate(
                            widget.groupListModel.groupList.length,
                            (int index) {
                          return getListview(
                              widget.groupListModel.groupList[index], index);
                        }),
                      )
                    : widget.listType == "requestedList"
                        ?  Column(
                            children:  List.generate(
                                widget.groupListModel.groupRequestList.length,
                                (int index) {
                              return getListview(
                                  widget.groupListModel.groupRequestList[index],
                                  index);
                            }),
                          )
                        : widget.listType == 'CHILD_Invited'
                            ?  Column(
                                children:  List.generate(
                                    widget.groupListModel.childInvitationList
                                        .length, (int index) {
                                  return   PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      10.0,Column(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          12.0,
                                          10.0,
                                          12.0,
                                          0.0,  Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              10.0,
                                              10.0,
                                              0.0,
                                              0.0,
                                               RichText(
                                                textAlign: TextAlign.start,
                                                text:  TextSpan(
                                                  children: <TextSpan>[
                                                     TextSpan(
                                                        text: "For ",
                                                        style:  TextStyle(
                                                            fontFamily: Constant.customBold,
                                                            fontSize: 14.0,
                                                            color: ColorValues.HEADING_COLOR_EDUCATION)),
                                                     TextSpan(
                                                        text: widget.groupListModel
                                                            .childInvitationList[
                                                        index].studentName,
                                                        style:  TextStyle(
                                                            fontFamily: Constant.customBold,
                                                            fontSize: 16.0,
                                                            color: ColorValues.HEADING_COLOR_EDUCATION)),
                                                  ],
                                                ),
                                              )),

                                          PaddingWrap.paddingfromLTRB(
                                              10.0,
                                              10.0,
                                              10.0,
                                              16.0,
                                               Divider(
                                                color:  ColorValues.GREY_TEXT_COLOR,
                                                height: 0.5,
                                              )),
                                        ],)),


                                       Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .start,
                                          children:  List
                                              .generate(
                                              widget.groupListModel
                                                  .childInvitationList[
                                              index]
                                                  .invitationList
                                                  .length,
                                                  (int index2) {
                                                return getListviewForChild(
                                                    widget.groupListModel
                                                        .childInvitationList[
                                                    index]
                                                        .invitationList[index2],
                                                    index);
                                              })),
                                    ],
                                  ));
                                }),
                              )
                            :  Column(
                                children:  List.generate(
                                    widget.groupListModel.groupInvitationList
                                        .length, (int index) {
                                  return getListview(
                                      widget.groupListModel
                                          .groupInvitationList[index],
                                      index);
                                }),
                              )
              ])
            ]),
          )),
    );
  }
}
