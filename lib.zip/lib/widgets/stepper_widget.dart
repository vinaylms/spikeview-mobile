import 'package:flutter/material.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class StepperWidget extends StatelessWidget {
  final int length;
  final int currentStep;

  const StepperWidget({
    @required this.length,
    @required this.currentStep,
});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(
        length,
            (index) => Expanded(
          child: Container(
            margin: EdgeInsets.only(right: length - 1 == index ? 0 : 6),
            height: 6,
            decoration: BoxDecoration(
              color: index <= currentStep
                  ? ColorValues.DARK_YELLOW
                  : ColorValues.LIGHT_GREY,
              borderRadius: const BorderRadius.all(Radius.circular(4)),
            ),
          ),
        ),
      ),
    );
  }
}
