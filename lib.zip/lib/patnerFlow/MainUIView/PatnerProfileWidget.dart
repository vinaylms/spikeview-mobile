import 'dart:async';
import 'dart:io';
import 'package:package_info/package_info.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_friend_list_with_header.dart';
import 'package:spike_view_project/group/group_list_share_flow.dart';
import 'package:spike_view_project/home/AddPost.dart';
import 'package:spike_view_project/patnerFlow/opportunity/opportunity_selection.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/home_page/blocs/home_bloc.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/ImageUpdate/EditCompanyImages.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/Company_Edit_Widget.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/ManageOfferingWidget.dart';
import 'package:spike_view_project/patnerFlow/opportunity/OpportunityDetailWidget.dart';
import 'package:spike_view_project/patnerFlow/opportunity/advisor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/mentor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/tutor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_advisor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_mentor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_tutor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';

import 'package:spike_view_project/rating/RatingModel.dart';
import 'package:spike_view_project/recommendation/manageRecommendation/manage_recommendation.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/modal/patner/OpportunityTypeModel.dart';
import 'package:spike_view_project/modal/patner/opportunity_category_model.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import '../../main.dart';

class MenuItemDataPartener {
  final String unselectedAssetImagePath;
  final String selectedAssetImagePath;
  final String title;
  bool isSelected;

  MenuItemDataPartener(this.unselectedAssetImagePath,
      this.selectedAssetImagePath, this.title, this.isSelected);
}

class PatnerProfileWidget extends StatefulWidget {
  static String tag = 'login-page';
  GlobalKey<ScaffoldState> _scaffoldKey;
  int notificationCount = 0;
  CompanyProfileModel companyModel;

  PatnerProfileWidget(this._scaffoldKey, this.notificationCount,
      {this.companyModel});

  @override
  PatnerProfileWidgetState createState() =>
      PatnerProfileWidgetState(notificationCount);
}

class PatnerProfileWidgetState extends State<PatnerProfileWidget>
    with AutomaticKeepAliveClientMixin, WidgetsBindingObserver {
  int notificationCount = 0;

  //List<String> opportunityTypeList = ['callApiOpporunityCategoryInternship', 'Job', 'Volunteering', 'Programs', 'Services', 'Tutor', 'Mentors', 'Advisors'];
  List<OpportunityTypeObj> opportunityTypeObjList = [];
  List<OpportunityCategoriesResult> opportunityCategoryList = [];
  Timer _timer1;
  bool isPartnerApprovedByAdmin = false;
  bool isRejected = false;
  bool isApproved = false;
  bool isPending = false;
  PatnerProfileWidgetState(this.notificationCount);

  Color borderColor = Colors.amber;
  bool isRememberMe = false;
  bool isDataRember = false;
  File imagePath, imagePathCover;
  String strNetworkImage = "";
  String userIdPref, skip_value, roleId, token;
  TextEditingController passwordCtrl, emailCtrl;
  ProfileInfoModal profileInfoModal;
  PackageInfo packageInfo;

  // BuildContext context;
  SharedPreferences prefs;
  bool isNarativeShow = false;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String sasToken, containerName;
  String strPrefixPathforCoverPhoto,
      strPrefixPathforProfilePhoto,
      strAzureCoverImageUploadPath = "",
      strAzureProfileImageUploadPath = "";
  String strSummary;
  String strAccCount = "", strRecCount = "";
  bool isActive = false;
  StreamSubscription<dynamic> _streamSubscription;
  StreamSubscription<dynamic> _streamSubscriptionEditProfile;
  ScrollController _scrollController = ScrollController();
  bool isTitleVisible = false;
  bool _isAppbar = true;
  final _formKey = GlobalKey<FormState>();
  TextEditingController fromDateController;
  String strDoB = "";
  String strFirstName = "", strLastName = "", strEmail = "";
  bool isLoading = true;
  bool isRatingLodaing = true;
  static String isAchivmentAdded = "false";
  static String isEducationAdded = "false";

  bool isShowAllActiveOpportunity = true;
  bool isShowAllRejectOpportunity = true;
  bool isShowAllPendingOpportunity = true;
  bool isShowAllExpireOpportunity = true;
  static StreamController syncDoneController = StreamController.broadcast();
  bool isDialogVisible = false;
  CompanyProfileModel companyModel;
  List<OpportunityModel> activeOpportunityList = List();
  List<OpportunityModel> expireOpportunityList = List();
  List<OpportunityModel> pendingOpportunityList = List();
  List<OpportunityModel> rejectOpportunityList = List();
  String rejectionReason = '';

  //-----------for rating------------
  var rating = 4.0;
  bool isSelectTap = false;
  var ratingCalculation = 0.0;
  String creationDate = "";
  bool isView = false;
  List<RatingModel> reviewList = List();

  //-------------For load more -----

  String strLoadMoreOpportuniesFor = "";

//----------------------for Badges----------------
  int skip = 0;
  int skipActive = 0;
  int skipPending = 0;
  int skipExpired = 0;
  int skipRejected = 0;

  bool isViewAllBadges = false;

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    try {
      DateTime dateFormat = DateTime.now();
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      print("response parent" +
          Constant.ENDPOINT_PERSONAL_INFO +
          userIdPref +
          "/false");
      Response response = await ApiCalling2().apiCall(context,
          Constant.ENDPOINT_PERSONAL_INFO + userIdPref + "/false", "get");
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

      if (response != null) {
        if (response.statusCode == 200) {
          DateTime dateFormat1 = DateTime.now();
          print(dateFormat1);
          final final_time = dateFormat1.difference(dateFormat).inSeconds;

          if (final_time > Constant.PARENT_PROFILE_RESPONSE_MAX_TIME) {
            API.ApiForUpdateReportStatus(
                context,
                "get",
                Constant.ENDPOINT_PERSONAL_INFO,
                userIdPref + "/false",
                final_time.toString());
          }

          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            profileInfoModal =
                ParseJson.parseMapUserProfile(response.data['result']);
            if (profileInfoModal.isActive == "true") {
              isActive = true;
            }

            if (profileInfoModal != null) {
              prefs.setString(UserPreference.NAME,
                  profileInfoModal.firstName + " " + profileInfoModal.lastName);

              prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                  profileInfoModal.profilePicture);

              prefs.setString(
                  UserPreference.CREATION_TIME, profileInfoModal.creationTime);

              strNetworkImage = profileInfoModal.profilePicture;
              setState(() {
                prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
                strNetworkImage;
                profileInfoModal;
              });
            }
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future getVersion() async {
    try {
      print("------------SPIKE BOAT");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (Platform.isAndroid) {
          print("------------getVersion" +
              Constant.ENDPOINT_APP_VERSION +
              "?version=" +
              packageInfo.version.toString() +
              "&appType=android");
        } else {
          print("------------getVersion" +
              Constant.ENDPOINT_APP_VERSION +
              "?version=" +
              packageInfo.version.toString() +
              "&appType=ios");
        }
        Response response = await ApiCalling2().apiCall3(
            context,
            Platform.isAndroid
                ? Constant.ENDPOINT_APP_VERSION +
                    "?version=" +
                    packageInfo.version.toString() +
                    "&appType=android"
                : Constant.ENDPOINT_APP_VERSION +
                    "?version=" +
                    packageInfo.version.toString() +
                    "&appType=ios",
            "get");
        print("------------getVersion" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              double versionForAbndroid;
              double versionForIos;

              String isIosRestrict = "false";
              String isAndroidRestrict = "false";

              try {
                versionForAbndroid = double.parse(
                    response.data['result']['androidVersion'].toString());
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "PatnerProfileWidget", context);
              }

              try {
                versionForIos = double.parse(
                    response.data['result']['iosVersion'].toString());
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "PatnerProfileWidget", context);
              }

              try {
                isIosRestrict =
                    response.data['result']['isIosRestrict'].toString();
                isAndroidRestrict =
                    response.data['result']['isAndroidRestrict'].toString();
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "PatnerProfileWidget", context);
              }

              String upgradeMessage =
                  response.data['result']['upgradeMessage'].toString();

              print("------------getVersionANdroid" +
                  versionForAbndroid.toString());
              print("---------getVersion---IOS" + versionForIos.toString());
              print("------------getVersion" + packageInfo.version.toString());
              print("------------getVersionios" + isIosRestrict);
              print("------------getVersionAndroid" + isAndroidRestrict);
              print("------------getVersion" +
                  response.data['result']['isRestrict'].toString());
              if (Platform.isAndroid) {
                if (double.parse(packageInfo.version) < versionForAbndroid) {
                  print("------------getVersion true" + packageInfo.version);
                  if (_timer1 != null) {
                    _timer1.cancel();
                  }
                  if (mounted) {
                    //  syncDoneController.add("dialogVisible");
                    Util.showUpdateDialog(
                        context,
                        isAndroidRestrict == "true" ? true : false,
                        upgradeMessage);
                  }
                }
              } else {
                if (double.parse(packageInfo.version) < versionForIos) {
                  if (_timer1 != null) {
                    _timer1.cancel();
                  }
                  if (mounted) {
                    // syncDoneController.add("dialogVisible");
                    Util.showUpdateDialog(context,
                        isIosRestrict == "true" ? true : false, upgradeMessage);
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      print("error++++++++++++" + e.toString());
      e.toString();
    }
  }

  Future companyInfoApi(isShowLaoder) async {
    try {
      setState(() {
        isLoading = true;
      });
      DateTime dateFormat = DateTime.now();
      if (isShowLaoder) CustomProgressLoader.showLoader(context);

      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=" + roleId,
          "get");
      print(
          'company URL::: ${Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=" + roleId}');
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response comapny" + response.toString());
      print("response comapny userIdPref" + userIdPref + " &roleId " + roleId);
      if (response != null) {
        if (response.statusCode == 200) {
          DateTime dateFormat1 = DateTime.now();
          print(dateFormat1);
          final final_time = dateFormat1.difference(dateFormat).inSeconds;

          if (final_time > Constant.COMPANY_RESPONSE_MAX_TIME) {
            API.ApiForUpdateReportStatus(
                context,
                "get",
                Constant.ENDPOINT_COMPANY_INFO,
                userIdPref + "&roleId=" + roleId,
                final_time.toString());
          }

          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            var map = response.data['result'];
            if (map != null) {
              companyModel = ParseJson.parseCompanyInfoData(map);

              print("company model dob - ${companyModel.dob}");

              if (companyModel != null) {
                try {
                  if (companyModel != null)
                    initOpporunityTypeSelected(companyModel);
                } catch (e) {
                  crashlytics_bloc.recordCrashlyticsError(
                      e, "PatnerProfileWidget", context);
                }
                SplashScreenState.companyModelNew = companyModel;
                prefs.setString(UserPreference.COMPANY_IMAGE_PATH,
                    companyModel.profilePicture);

                prefs.setString(
                    UserPreference.COMPANY_NAME_PATH, companyModel.name);

                if (companyModel.partnerStatus.toString() == 'Pending') {
                  isApproved = false;
                  isRejected = false;
                  isPending = true;
                  isPartnerApprovedByAdmin = false;
                } else if (companyModel.partnerStatus.toString() == 'Active') {
                  isApproved = true;
                  isRejected = false;
                  isPending = false;
                  isPartnerApprovedByAdmin = true;
                  //ToastWrap.showToastLong(MessageConstant.ACTIVE_PARTNER_VAL, context);
                } else if (companyModel.partnerStatus.toString() == 'Decline') {
                  isApproved = false;
                  isRejected = true;
                  isPending = false;
                  isPartnerApprovedByAdmin = false;
                }
                setState(() {
                  rejectionReason = companyModel.declineReason;
                });
                prefs.setBool(
                    UserPreference.IS_PARTNER_ACTIVE, isPartnerApprovedByAdmin);
                prefs.setString(UserPreference.PARTNER_STATUS,
                    companyModel.partnerStatus.toString());
                print(
                    'Apurva isPartnerApprovedByAdmin:: $isPartnerApprovedByAdmin');
                syncDoneController.add(companyModel.dob);
              }
            }
          }

          setState(() {
            isLoading = false;
          });
        }
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //shubham
  Future getOpportuinity(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      print(
          "APurva get Opportunity URL::: ${Constant.ENDPOINT_OPPORTUNITY + userIdPref + "&roleId=" + roleId}");
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_OPPORTUNITY +
              userIdPref +
              "&roleId=" +
              roleId +
              "&skip=0&status=expired&status=active&status=pending&status=rejected",
          "get");

      //userId=5294&roleId=4&skip=0&status=expired&status=active&status=pending&limit=10
      print("getOpportuinity url " +
          Constant.ENDPOINT_OPPORTUNITY +
          userIdPref +
          "&roleId=" +
          roleId +
          "&skip=0&status=expired&status=active&status=pending&status=rejected");

      print("response getOpportuinity" + response.toString());

      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            var activmap = response.data['result']["activeOpportunities"];
            if (activmap != null)
              activeOpportunityList = ParseJson.parseOpportunityData(activmap);

            var expmap = response.data['result']["expiredOpportunities"];
            if (expmap != null)
              expireOpportunityList = ParseJson.parseOpportunityData(expmap);

            var penmap = response.data['result']["pendingOpportunities"];
            if (penmap != null)
              pendingOpportunityList = ParseJson.parseOpportunityData(penmap);

            var rejectmap = response.data['result']["declinedOpportunities"];
            if (rejectmap != null)
              rejectOpportunityList = ParseJson.parseOpportunityData(rejectmap);

            if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
            print("activeOpportunityList.length:::: " +
                activeOpportunityList.length.toString());
            print("expireOpportunityList.length:::: " +
                expireOpportunityList.length.toString());

            setState(() {
              activeOpportunityList;
              expireOpportunityList;
              pendingOpportunityList;
              rejectOpportunityList;
            });
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future getOpportuinityForLoadMore(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);

      if (strLoadMoreOpportuniesFor == 'active') {
        skip = skipActive;
      } else if (strLoadMoreOpportuniesFor == 'pending') {
        skip = skipPending;
      } else if (strLoadMoreOpportuniesFor == 'expired') {
        skip = skipExpired;
      }else if (strLoadMoreOpportuniesFor == 'rejected') {
        skip = skipRejected;
      }



      print(
          "APurva get Opportunity URL::: ${Constant.ENDPOINT_OPPORTUNITY + userIdPref + "&roleId=" + roleId}");
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_OPPORTUNITY +
              userIdPref +
              "&roleId=" +
              roleId +
              "&skip=" +
              skip.toString() +
              "&status=" +
              strLoadMoreOpportuniesFor,
          "get");

      //userId=5294&roleId=4&skip=0&status=expired&status=active&status=pending&limit=10
      print("getOpportuinity url " +
          Constant.ENDPOINT_OPPORTUNITY +
          userIdPref +
          "&roleId=" +
          roleId +
          "skip=" +
          skip.toString() +
          "&status=" +
          strLoadMoreOpportuniesFor);

      print("response getOpportuinityForLoadMore" + response.toString());

      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            if (strLoadMoreOpportuniesFor == 'active') {
              var activmap = response.data['result']["activeOpportunities"];
              if (activmap != null)
                activeOpportunityList
                    .addAll(ParseJson.parseOpportunityData(activmap));

              print(
                  "activeOpportunityList count - ${activeOpportunityList.length}");
            } else if (strLoadMoreOpportuniesFor == 'pending') {
              var penmap = response.data['result']["pendingOpportunities"];
              if (penmap != null)
                pendingOpportunityList
                    .addAll(ParseJson.parseOpportunityData(penmap));
              print(
                  "pendingOpportunityList count - ${pendingOpportunityList.length}");
            } else if (strLoadMoreOpportuniesFor == 'expired') {
              var expmap = response.data['result']["expiredOpportunities"];
              if (expmap != null)
                expireOpportunityList
                    .addAll(ParseJson.parseOpportunityData(expmap));
              print(
                  "expireOpportunityList count - ${expireOpportunityList.length}");
            }
            else if (strLoadMoreOpportuniesFor == 'rejected') {
              var expmap = response.data['result']["declineOpportunities"];
              if (expmap != null)
                rejectOpportunityList
                    .addAll(ParseJson.parseOpportunityData(expmap));
              print(
                  "expireOpportunityList count - ${expireOpportunityList.length}");
            }

            // var rejectmap = response.data['result']["declineOpportunities"];
            // if (rejectmap != null)
            //   rejectOpportunityList = ParseJson.parseOpportunityData(rejectmap);

            if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
            print("activeOpportunityList.length:::: " +
                activeOpportunityList.length.toString());
            print("expireOpportunityList.length:::: " +
                expireOpportunityList.length.toString());
            print("pendingOpportunityList.length:::: " +
                pendingOpportunityList.length.toString());

            setState(() {
              activeOpportunityList;
              expireOpportunityList;
              pendingOpportunityList;
              rejectOpportunityList;
            });
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  List<RatingModel> parseRating(map) {
    ratingCalculation = 0;
    List<RatingModel> tagList = List();
    try {
      for (int k = 0; k < map.length; k++) {
        String reviewId = map[k]['reviewId'].toString();
        var rating = map[k]['rating'];
        String review = map[k]['review'].toString();
        int date = map[k]['date'];
        String senderId = map[k]['senderId'].toString();
        String receiverId = map[k]['receiverId'].toString();
        String profilePicture = map[k]['profilePicture'].toString();
        String name = map[k]['name'].toString();
        var pointRating = 0.0;
        pointRating = pointRating + rating;
        ratingCalculation = rating + ratingCalculation;
        setState(() {
          ratingCalculation;
        });
        print("totalRating=====" + ratingCalculation.toString());

        tagList.add(new RatingModel(reviewId, pointRating, review, date,
            senderId, receiverId, name, profilePicture));
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
    }
    return tagList;
  }

  Future reviewApi() async {
    print("api call");
    try {
      setState(() {
        isRatingLodaing = true;
      });
      var isConnect = await ConectionDetecter.isConnected();
      SharedPreferences prefs = await SharedPreferences.getInstance();

      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_REVIEW_API + userIdPref, "get");
        print(response);
        setState(() {
          isRatingLodaing = false;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data["status"];

            if (status == "Success") {
              reviewList = parseRating(response.data['result']);
            }
          }
        }
      } else {}
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      setState(() {
        isRatingLodaing = false;
      });
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;

            print("sastoken:===" + sasToken);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      e.toString();
    }
  }

//***************************************************************************************************************

  List<OpportunityTypeObj> initOpporunityType() {
    for (int i = 0; i < opportunityCategoryList.length; i++) {
      //if(i != 0){
      opportunityTypeObjList.add(new OpportunityTypeObj(
          false,
          opportunityCategoryList[i].name,
          i,
          opportunityCategoryList[i].oppCategoryId));
      /*}else{
        opportunityTypeObjList.add(new OpportunityTypeObj(true, opportunityCategoryList[i].name,i,opportunityCategoryList[i].oppCategoryId));
      }*/
    }

    return opportunityTypeObjList;
  }

  Future callApiOpporunityCategory() async {
    print('inside callApiOpporunityCategory() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCallWithAuthToken(
            context, Constant.ENDPOINT_OPPORTUNITY_CATEGORY, "get");

        print(
            'Apurva callApiOpporunityCategory() Response:::: ${response.toString()}');

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              OpportunityCategoriesModel apiResponse =
                  OpportunityCategoriesModel.fromJson(response.data);
              setState(() {
                opportunityCategoryList = apiResponse.result;

                if (opportunityCategoryList != null &&
                    opportunityCategoryList.isNotEmpty) {
                  //print('opportunityCategoryList[opportunityCategoryList.length - 1].businessCategoryId:: ${opportunityCategoryList[opportunityCategoryList.length - 1].name}');
                }
                //initOpporunityType();
              });

              print(
                  'Apurva opportunityCategoryList size::::: ${opportunityCategoryList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      e.toString();
    }
  }

  String linkData;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    isUserRepoted = UserPreference.getIsUserReported();

    try {
      skip_value = prefs.getString(UserPreference.chat_skip_count);
      if (skip_value == null || skip_value == "") {
        skip_value = "0";
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      skip_value = "0";
    }

    var isConnect = await ConectionDetecter.isConnected();
    packageInfo = await PackageInfo.fromPlatform();
    try {
      linkData = prefs.getString(UserPreference.LINK);
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      linkData = "";
    }
    // var model=await DbHelper().getCount();
    // print("userPostList+++++++"+model.length.toString());
    homeBloc.fetcPost(userIdPref, roleId, context);
    bloc.fetchConnection(userIdPref, context, prefs, true);
    bloc.fetchGroup(userIdPref, context, prefs, true);
    /*   DBHelper dbHelper =  DBHelper();
    List<Student> studentList =  List<Student>();
    var model = await dbHelper.getStudents();
    if (model != null) {
      studentList.addAll(model);
    }
    if (studentList.length == 0 || studentList == null) {
      print("studentList length is blank///////?????????????");
      bloc.fetchChatList(userIdPref, context, prefs, true, "0");
    }else  {
      print("?????????????????????????????????????????????");
    }*/
    int skip = int.parse(skip_value);
    DbHelper().deleteChatTable();
    for (var i = 0; i <= skip; i++) {
      bloc.fetchChatList(userIdPref, context, prefs, true, i.toString());
    }

    if (isConnect) {
      if (isConnect) {
        await getVersion();
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }

      if (!isDialogVisible) {
        //  CustomProgressLoader.showLoader(context);
      }
      profileApi(true);
      //if (widget.companyModel == null) {
      companyInfoApi(true);
      //}
      reviewApi();
      getOpportuinity(true);

      callApiOpporunityCategory();
      if (companyModel != null) initOpporunityTypeSelected(companyModel);
      if (!isDialogVisible) {
        //   CustomProgressLoader.cancelLoader(context);
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }

    if (isConnect) {
      callApiForSaas();
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }

    strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_COVER +
        "/";

    strPrefixPathforProfilePhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_PROFILE +
        "/";

    if (prefs.getBool(UserPreference.IS_SHOW_REJECTION_POPUP)) {
      showRejectionAlert();
    }
    try {
      if (linkData != null && linkData != "") {
        prefs.setString(UserPreference.LINK, "");
        print("linkData++++open " + linkData.toString());
        shareUrlOption(linkData);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
    }
    try {
      setState(() {
        rejectionReason = companyModel.declineReason;
      });
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
    }
  }

  void shareUrlOption(link) {
    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 24.0,
                            child: Container(
                                height:
                                    prefs.getString(UserPreference.ROLE_ID) ==
                                            "4"
                                        ? 248.0
                                        : 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          "Chat",
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                        )),
                                                    onTap: () {
                                                      if (prefs.getString(
                                                              UserPreference
                                                                  .ISACTIVE) ==
                                                          "true") {
                                                        Navigator.pop(Constant
                                                            .applicationContext);
                                                        Navigator.of(Constant
                                                                .applicationContext)
                                                            .push(
                                                                MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        ChatFriendListWithHeader(
                                                                          link,
                                                                          "",
                                                                          userIdPref,
                                                                          pageName:
                                                                              "notification",
                                                                          roleId:
                                                                              roleId,
                                                                        )));
                                                      } else {
                                                        Navigator.pop(Constant
                                                            .applicationContext);
                                                        ToastWrap.showToast(
                                                            MessageConstant
                                                                .PENDING_PROFILE_ACTIVATION,
                                                            Constant
                                                                .applicationContext);
                                                      }
                                                    },
                                                  ),
                                                  Column(
                                                    children: <Widget>[
                                                      Container(
                                                        color: ColorValues
                                                            .BORDER_COLOR,
                                                        height: 1.0,
                                                      ),
                                                      InkWell(
                                                        child: Container(
                                                            height: 50.0,
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    0.0,
                                                                    13.0,
                                                                    0.0,
                                                                    13.0),
                                                            child: Text(
                                                              "Feed",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 1,
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            )),
                                                        onTap: () async {
                                                          if (prefs.getString(
                                                                  UserPreference
                                                                      .ISACTIVE) ==
                                                              "true") {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            Navigator.of(Constant
                                                                    .applicationContext)
                                                                .push(
                                                                    MaterialPageRoute(
                                                                        builder: (BuildContext
                                                                                context) =>
                                                                            AddPost(
                                                                              profileInfoModal,
                                                                              "",
                                                                              groupDetailModel: null,
                                                                              link: link,
                                                                            )));
                                                          } else {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            ToastWrap.showToast(
                                                                MessageConstant
                                                                    .PENDING_PROFILE_ACTIVATION,
                                                                Constant
                                                                    .applicationContext);
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  Column(
                                                    children: <Widget>[
                                                      Container(
                                                        color: ColorValues
                                                            .BORDER_COLOR,
                                                        height: 1.0,
                                                      ),
                                                      InkWell(
                                                        child: Container(
                                                            height: 50.0,
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    0.0,
                                                                    13.0,
                                                                    0.0,
                                                                    13.0),
                                                            child: Text(
                                                              "Group",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 1,
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            )),
                                                        onTap: () async {
                                                          if (prefs.getString(
                                                                  UserPreference
                                                                      .ISACTIVE) ==
                                                              "true") {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            Navigator.of(Constant
                                                                    .applicationContext)
                                                                .push(new MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        GroupListShareFlow(
                                                                            profileInfoModal,
                                                                            link)));
                                                          } else {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            ToastWrap.showToast(
                                                                MessageConstant
                                                                    .PENDING_PROFILE_ACTIVATION,
                                                                Constant
                                                                    .applicationContext);
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  prefs.getString(UserPreference
                                                              .ROLE_ID) ==
                                                          "4"
                                                      ? Column(
                                                          children: <Widget>[
                                                            Container(
                                                              color: ColorValues
                                                                  .BORDER_COLOR,
                                                              height: 1.0,
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                  height: 50.0,
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          13.0,
                                                                          0.0,
                                                                          13.0),
                                                                  child: Text(
                                                                    "Opportunity",
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 1,
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR,
                                                                        height:
                                                                            1.2,
                                                                        fontSize:
                                                                            16.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                              onTap: () async {
                                                                if (prefs.getString(
                                                                        UserPreference
                                                                            .ISACTIVE) ==
                                                                    "true") {
                                                                  Navigator.pop(
                                                                      Constant
                                                                          .applicationContext);
                                                                  Navigator.of(
                                                                          Constant
                                                                              .applicationContext)
                                                                      .push(new MaterialPageRoute(
                                                                          builder: (BuildContext context) => OpportunitySelection(
                                                                              companyModel,
                                                                              link: link)));
                                                                } else {
                                                                  Navigator.pop(
                                                                      Constant
                                                                          .applicationContext);
                                                                  ToastWrap.showToast(
                                                                      MessageConstant
                                                                          .PENDING_PROFILE_ACTIVATION,
                                                                      Constant
                                                                          .applicationContext);
                                                                }

                                                                //}
                                                              },
                                                            ),
                                                          ],
                                                        )
                                                      : Container(height: 0.0),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(
                                                  Constant.applicationContext);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void appBarStatus(bool status) {
    setState(() {
      _isAppbar = status;
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print('state partner profile+++++++++ = $state');

    if (mounted) {
      Constant.applicationContext = context1;
    }
  }

  bool isUserRepoted = true;
  MenuItemData selectedMenuItem;

  List<MenuItemData> menuItems = [
    MenuItemData('assets/recommendation/Unselected.png',
        'assets/recommendation/Selected.png', 'Active'),
    MenuItemData('assets/recommendation/Unselected.png',
        'assets/recommendation/Selected.png', 'Pending'),
    MenuItemData('assets/recommendation/Unselected.png',
        'assets/recommendation/Selected.png', 'Expired'),
  ];

  List<MenuItemDataPartener> dropDownMenulist = [
    MenuItemDataPartener('isTitle', '', 'Opportunity status', false),
    MenuItemDataPartener('assets/recommendation/Unselected.png',
        'assets/recommendation/Selected.png', 'Active', true),
    MenuItemDataPartener('assets/recommendation/Unselected.png',
        'assets/recommendation/Selected.png', 'Pending', true),
    MenuItemDataPartener('assets/recommendation/Unselected.png',
        'assets/recommendation/Selected.png', 'Expired', true),
    MenuItemDataPartener('assets/recommendation/Unselected.png',
        'assets/recommendation/Selected.png', 'Rejected', true),
  ];

  @override
  void initState() {

    print("Apurva initState() Pratner profile");

    selectedMenuItem = MenuItemData('assets/recommendation/Unselected.png',
        'assets/recommendation/Selected.png', 'test');

    WidgetsBinding.instance.addObserver(this);
    //initOpporunityType();
    _streamSubscription =
        ManageOfferingWidgetState.syncDoneController.stream.listen((value) {
      print("value changes" + value);
      companyInfoApi(false);
    });
    _streamSubscriptionEditProfile =
        Company_Edit_WidgetState.syncDoneController.stream.listen((value) {
      print("value changes" + value);
      companyInfoApi(false);
    });
    //anaylytics.setCurrentSreen(ScreenNameConstant.parent_dasboard);
    _streamSubscription =
        DashBoardStatePartner.syncDoneController.stream.listen((value) {
      print("api called profile");
      if (value == "success") {
        apiUpdated(value);
      } else if (value == "dialogVisible") {
        isDialogVisible = true;
      } else if (value == "partnerStatus") {
        print('DashBoardStatePartner.syncDoneController partnerStatus');
        companyInfoApi(false);
      } else {
        try {
          notificationCount = int.parse(value);
          if (mounted)
            setState(() {
              notificationCount;
            });
        } catch (e) {}
      }
    });

    /*   DashBoardStatePartner.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted)
          setState(() {
            notificationCount;
          });
      }
    });*/

    _scrollController.addListener(() {
      if (_scrollController.offset < 150.0) {
        if (isTitleVisible) {
          setState(() {
            isTitleVisible = false;
          });
        }
      } else {
        if (!isTitleVisible) {
          setState(() {
            isTitleVisible = true;
          });
        }
      }

      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (_isAppbar) {
          setState(() {
            _isAppbar = false;
          });
        }
      }
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (!_isAppbar) {
          setState(() {
            _isAppbar = true;
          });
        }
      }
    });
    if (widget.companyModel != null) {
      companyModel = widget.companyModel;
      print("profileInfoModal++++not null+");

      setState(() {});
    }
    getSharedPreferences();

    super.initState();
  }

  //-------------listener for refresh profile info -------------------------
  void apiUpdated(String result) async {
    profileApi(true);
  }

  BuildContext context1;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    this.context1 = context;
    Constant.applicationContext = context;
    return SafeArea(
        child: Scaffold(
      appBar: CustomViews.getAppBar(
          '', widget._scaffoldKey, context, prefs, notificationCount),
      body: Stack(
        children: <Widget>[
          Positioned(
              left: 0.0,
              right: 0.0,
              top: 0.0,
              bottom: 0.0,
              child: RefreshIndicator(
                  onRefresh: _refreshPageHere,
                  displacement: 0.0,
                  child: Container(
                    color: Colors.white,
                    child: SingleChildScrollView(
                      controller: _scrollController,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8,right: 8),

                        child: Column(
                          children: <Widget>[
                            headerUiDesign(),
                            activeOpportunityList.length == 0 &&
                                    pendingOpportunityList.length == 0 &&
                                    rejectOpportunityList.length == 0 &&
                                    expireOpportunityList.length == 0
                                ? SizedBox()
                                : InkWell(
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          13.0, 5.0, 13.0, 20.0),
                                      child: Container(
                                          height: 50.0,
                                          decoration: BoxDecoration(
                                              color: ColorValues.BLUE_COLOR,
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 8, right: 10),
                                                child: Container(
                                                    height: 35,
                                                    width: 35,
                                                    decoration: BoxDecoration(
                                                        color: Colors.white,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                10.5)),
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              5.0),
                                                      child: Image.asset(
                                                        "assets/newDesignIcon/parentProfile/createOpportunity.png",
                                                        height: 15,
                                                        width: 15,
                                                      ),
                                                    )),
                                              ),
                                              Text(
                                                "Create opportunity",
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontFamily: Constant.latoMedium,
                                                    fontSize: 18.0,
                                                    fontWeight: FontWeight.w600),
                                              ),
                                              Spacer(),
                                              Container(
                                                  height: 20,
                                                  width: 20,
                                                  child: Image.asset(
                                                    "assets/newDesignIcon/parentProfile/createPlus.png",
                                                    height: 15,
                                                    width: 15,
                                                  )),
                                              SizedBox(
                                                width: 15,
                                              )
                                            ],
                                          )),
                                    ),
                                    onTap: () {
                                      if (isUserRepoted) {
                                        if (companyModel != null)
                                          print(
                                              "companyMode DOB - ${companyModel.dob}");
                                        //createOportunityOptions();
                                        _navigateToOpportunitySelection();
                                      } else {
                                        ToastWrap.showToast(
                                            "User Repoted..", context);
                                      }
                                    },
                                  ),
                            activeOpportunityList.length == 0 &&
                                    pendingOpportunityList.length == 0 &&
                                    rejectOpportunityList.length == 0 &&
                                    expireOpportunityList.length == 0
                                ? SizedBox()
                                : isRatingLodaing
                                    ? Container(
                                        height: 0.0,
                                      )
                                    : Container(
                                        color: Colors.white,
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              13, 0, 13, 0),
                                          child: Container(
                                              width: double.infinity,
                                              decoration: BoxDecoration(
                                                  color: ColorValues.SELECTION_BG,
                                                  // border: Border.all(
                                                  //     color: ColorValues
                                                  //         .BORDER_COLOR,
                                                  //     width: 0.5)
                                                  borderRadius:
                                                      BorderRadius.circular(10)),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Container(
                                                    height: 50,
                                                    decoration: BoxDecoration(
                                                        color: ColorValues
                                                            .LIST_BOTTOM_BG,
                                                        borderRadius:
                                                            BorderRadius.only(
                                                                topLeft: Radius
                                                                    .circular(10),
                                                                topRight: Radius
                                                                    .circular(
                                                                        10))),
                                                    child: Row(
                                                      children: <Widget>[
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  left: 8,
                                                                  right: 10),
                                                          child: Container(
                                                              height: 35,
                                                              width: 35,
                                                              decoration: BoxDecoration(
                                                                  color: Colors
                                                                      .white,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              10.5)),
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(5.0),
                                                                child:
                                                                    Image.asset(
                                                                  "assets/newDesignIcon/parentProfile/partnerRatingReview.png",
                                                                  height: 15,
                                                                  width: 15,
                                                                ),
                                                              )),
                                                        ),
                                                        Expanded(
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 0.0,
                                                                    left: 0),
                                                            child: Text(
                                                              "Ratings and Reviews",
                                                              style: TextStyle(
                                                                  fontSize: 18,
                                                                  fontFamily: Constant
                                                                      .latoSemibold,
                                                                  color: ColorValues
                                                                      .HEADING_COLOR_EDUCATION_1),
                                                            ),
                                                          ),
                                                        ),
                                                        reviewList.length == 0
                                                            ? Container(
                                                                height: 0.0,
                                                              )
                                                            : Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        top: 0.0,
                                                                        right: 0),
                                                                child: IconButton(
                                                                    onPressed:
                                                                        () {
                                                                      if (isSelectTap) {
                                                                        isSelectTap =
                                                                            false;
                                                                      } else {
                                                                        isSelectTap =
                                                                            true;
                                                                      }
                                                                      setState(
                                                                          () {
                                                                        isSelectTap;
                                                                      });
                                                                      print(
                                                                          isSelectTap);
                                                                    },
                                                                    icon: isSelectTap
                                                                        ? Image.asset(
                                                                            "assets/new_onboarding/arrow_up.png",
                                                                            height:
                                                                                25,
                                                                            width:
                                                                                25,
                                                                          )
                                                                        : Image.asset(
                                                                            "assets/new_onboarding/arrow_down.png",
                                                                            height:
                                                                                25,
                                                                            width:
                                                                                25,
                                                                          ))),
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 15.0, left: 15,right: 10),
                                                    child: Text(
                                                      "Encourage your customers to provide reviews. It will help build your brand and customer interest. ",
                                                      style: TextStyle(
                                                          fontSize: 12,
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontFamily: Constant
                                                              .latoRegular,
                                                          fontWeight:
                                                              FontWeight.w400),
                                                    ),
                                                  ),
                                                  Row(
                                                    children: <Widget>[
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets.only(
                                                                top: 5.0,
                                                                left: 15),
                                                        child: Text(
                                                          reviewList.length == 0
                                                              ? "0.0"
                                                              : (ratingCalculation /
                                                                      reviewList
                                                                          .length)
                                                                  .toStringAsFixed(
                                                                      1)
                                                                  .toString(),
                                                          style: TextStyle(
                                                              fontSize: 47,
                                                              fontWeight:
                                                                  FontWeight.w800,
                                                              fontFamily: Constant
                                                                  .latoRegular,
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION_1),
                                                        ),
                                                      ),
                                                      Column(
                                                        children: <Widget>[
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 8.0,
                                                                    left: 8),
                                                            child: Center(
                                                                child:
                                                                    SmoothStarRating(
                                                              rating: reviewList
                                                                          .length ==
                                                                      0
                                                                  ? 0
                                                                  : (ratingCalculation /
                                                                      reviewList
                                                                          .length),
                                                              allowHalfRating:
                                                                  false,
                                                              size: 20,
                                                              color: Color(
                                                                  0xffFEC901),
                                                              filledIconData:
                                                                  Icons.star,
                                                              borderColor: Color(
                                                                  0xffFDEDEDE),
                                                              defaultIconData:
                                                                  Icons.star,
                                                              starCount: 5,
                                                              spacing: 1.0,
                                                            )),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    left: 10,
                                                                    bottom: 5,
                                                                    top: 5),
                                                            child: Text(
                                                              "Based on " +
                                                                  reviewList
                                                                      .length
                                                                      .toString() +
                                                                  " reviews",
                                                              style: TextStyle(
                                                                  fontSize: 12,
                                                                  fontFamily: Constant
                                                                      .latoRegular,
                                                                  color: ColorValues
                                                                      .labelColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                  generateDropDownList(),
                                                ],
                                              )),
                                        ),
                                      ),
                            activeOpportunityList.length == 0 &&
                                    pendingOpportunityList.length == 0 &&
                                    rejectOpportunityList.length == 0 &&
                                    expireOpportunityList.length == 0
                                ? Container()
                                : Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15, right: 15, top: 25, bottom: 5),
                                    child: Row(
                                      children: [
                                        Text(
                                          "Opportunities",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontFamily: Constant.latoMedium,
                                              fontSize: 18.0,
                                              fontWeight: FontWeight.w600),
                                        ),
                                        Spacer(),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 10),
                                          child: InkWell(
                                            onTap: () {
                                              // if (strTabValue == 'Pending'){
                                              //
                                              // }else{
                                              // }
                                              //   showPopupMenu(context);

                                              showPopupMenuDropDown(context);
                                            },
                                            child: Image.asset(
                                              "assets/recommendation/Manage_Recomendation_Filter.png",
                                              //   strTabValue == 'Pending'?
                                              // "assets/recommendation/Manage_Recomendation_Filter_Disable.png" : "assets/recommendation/Manage_Recomendation_Filter.png",

                                              height: 35.0,
                                              width: 35.0,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                            isLoading
                                ? SizedBox()
                                : activeOpportunityList.length == 0 &&
                                        pendingOpportunityList.length == 0 &&
                                        rejectOpportunityList.length == 0 &&
                                        expireOpportunityList.length == 0
                                    ? getGridView()
                                    : Column(
                                        children: generateCardListItems(),
                                      )
                          ],
                        ),
                      ),
                    ),
                  ))),
          // Positioned(
          //     left: 0.0,
          //     right: 0.0,
          //     top: 0.0,
          //     child: AnimatedContainer(
          //       height: _isAppbar ? 55.0 : 0.0,
          //       duration: Duration(milliseconds: 200),
          //       child: getView(),
          //     )),
        ],
      ),
    ));
  }

  activateAgain(index, List<OpportunityModel> list, type) async {
    print('inside activateAgain index;:: $index');
    int switchIndex = int.parse(list[index].offerId);
    String name = opportunityCategoryList[switchIndex - 1].name;
    print('inside activateAgain switchIndex;:: $switchIndex');
    switch (switchIndex) {
      case 1:
        callUpdateOldForms(index, name, list, type);
        break;
      case 2:
        callUpdateOldForms(index, name, list, type);
        break;
      case 3:
        callUpdateOldForms(index, name, list, type);
        break;
      case 4:
        callUpdateOldForms(index, name, list, type);
        break;
      case 5:
        callUpdateOldForms(index, name, list, type);
        break;
      case 6:
        updateTutorOpportunity(index, list, type);
        break;
      case 7:
        updateMentorOpportunity(index, list, type);
        break;
      case 8:
        updateAdvisorOpportunity(index, list, type);
        break;
    }
  }

  getCharForName(name) {
    String s = "";
    for (int i = 0; i < name.length; i++) {
      s = s + "";
    }
    return s;
  }

  onTapEditActiveopportunity(index, List<OpportunityModel> list) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            OpportunityDetailWidget(list[index], "Active")));
    if (result == "push") {
      getOpportuinity(true);
    }
  }

  onTapEditRejectedopportunity(index, List<OpportunityModel> list) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            OpportunityDetailWidget(list[index], "Rejected")));
    if (result == "push") {
      getOpportuinity(true);
    }
  }

  onTapEditPendingopportunity(index, List<OpportunityModel> list) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            OpportunityDetailWidget(list[index], "Pending")));
    if (result == "push") {
      getOpportuinity(true);
    }
  }


  onTapEditExpiredopportunity(index, List<OpportunityModel> list) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
      builder: (BuildContext context) =>
          OpportunityDetailWidget(list[index], "Expired"),
    ));
    if (result == "push") {
      getOpportuinity(true);
    }
  }

  Widget headerUiDesign() {
    return Container(
      height: 100.0,
      color: Colors.white,
      //ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
      child: Stack(
        children: <Widget>[
          /*
            Positioned(
              top: 0.0,
              bottom: 0.0,
              left: 0.0,
              right: 0.0,
              child: imagePathCover == null
                  ? companyModel != null &&
                  (companyModel.coverPicture != "" &&
                      companyModel.coverPicture != "null")
                  ? Stack(
                children: <Widget>[
                  Positioned(
                    child:
                    /* FadeInImage.assetNetwork(
                                fit: BoxFit.cover,
                                placeholder: '',
                                image: Constant.IMAGE_PATH_SMALL +
                                    ParseJson.getMediumImage(
                                        companyModel.coverPicture),
                              )*/

                    CachedNetworkImage(
                      imageUrl: Constant.IMAGE_PATH_SMALL +
                          ParseJson.getMediumImage(
                              companyModel.coverPicture),
                      fit: BoxFit.cover,
                      placeholder: (context, url) =>
                          _loader(context, ""),
                      errorWidget: (context, url, error) =>
                          _error(""),
                    ),
                    top: 0.0,
                    bottom: 0.0,
                    left: 0.0,
                    right: 0.0,
                  ),

                  /*
                  Positioned(
                    child: Container(
                      child: Image.asset(
                        "assets/newDesignIcon/navigation/layer_cover.png",
                        fit: BoxFit.fill,
                      ),
                    ),
                    top: 0.0,
                    bottom: 0.0,
                    left: 0.0,
                    right: 0.0,
                  )

                   */
                ],
              )
                  : activeOpportunityList.length > 0 ||
                  expireOpportunityList.length > 0 ||
                  pendingOpportunityList.length > 0 ||
                  rejectOpportunityList.length > 0
                  ? Container(
                color: Color(0xff5E5E5E),
              )
                  : Container(
                child:
                Image.asset(
                  "assets/newDesignIcon/patner/patnerbg.png",
                  fit: BoxFit.fill,
                ),
              )
                  : Stack(
                children: <Widget>[
                  Positioned(
                    child: Image.file(
                      imagePathCover,
                      fit: BoxFit.fitWidth,
                    ),
                    top: 0.0,
                    bottom: 0.0,
                    left: 0.0,
                    right: 0.0,
                  ),
                  Positioned(
                    child: Container(
                      child: Image.asset(
                        "assets/newDesignIcon/navigation/layer_cover.png",
                        fit: BoxFit.fill,
                      ),
                    ),
                    top: 0.0,
                    bottom: 0.0,
                    left: 0.0,
                    right: 0.0,
                  )
                ],
              ),
            ),

             */
          Positioned(
              bottom: 10.0,
              left: 0.0,
              right: 0.0,
              child: Column(
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                      13.0,
                      20.0,
                      13.0,
                      0.0,
                      Container(
                          child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                1.0, 10.0, 13.0, 10.0, isImageSelectedView()),
                            flex: 0,
                          ),
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                0.0,
                                8.0,
                                Container(
                                    child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingAll(
                                      2.0,
                                      TextViewWrap.textViewMultiLine(
                                          companyModel == null
                                              ? ""
                                              : companyModel.name,
                                          TextAlign.start,
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                          getLenthOfName() > 24 ? 22.0 : 24.0,
                                          FontWeight.normal,
                                          2),
                                    ),
                                    isLoading
                                        ? SizedBox()
                                        : Padding(
                                            padding:
                                                const EdgeInsets.only(top: 5.0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: isApproved
                                                      ? Color(0xffD1E7DD)
                                                      : Color(0xffFCEAE2),
                                                  // border: Border.all(
                                                  //     color: isApproved
                                                  //         ? ColorValues
                                                  //         .BUTTON_ACTIVE
                                                  //         : ColorValues
                                                  //         .BUTTON_PENDING,
                                                  //     width: 0.0),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          12)),
                                              height: 22.0,
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                12.0,
                                                3.0,
                                                12.0,
                                                3.0,
                                                TextViewWrap.textViewSingleLine(
                                                    isApproved
                                                        ? "Active".toUpperCase()
                                                        : "Pending Approval"
                                                            .toUpperCase(),
                                                    TextAlign.start,
                                                    isApproved
                                                        ? Color(0xff198754)
                                                        : Color(0xffC87C5B),
                                                    12.0,
                                                    FontWeight.normal),
                                              ),
                                            ),
                                          ),
                                  ],
                                ))),
                            flex: 1,
                          )
                        ],
                      ))),
                ],
              )),
        ],
      ),
    );
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  generateDropDownList() {
    return isSelectTap
        ? Padding(
            padding: EdgeInsets.only(top: 5, bottom: 8, left: 15, right: 15),
            child: ListView.builder(
                itemCount: isView
                    ? reviewList.length
                    : reviewList.length > 2
                        ? 2
                        : reviewList.length,
                physics: ScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context, iteam) {
                  return Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                    child: isSelectTap
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            // Align children to the left

                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    // Align children to the left

                                    children: [
                                      Expanded(
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Container(
                                                  width: 40.0,
                                                  height: 40.0,
                                                  child: ClipOval(
                                                      child: CachedNetworkImage(
                                                    width: 40.0,
                                                    height: 40.0,
                                                    imageUrl:
                                                        Constant.IMAGE_PATH +
                                                            reviewList[iteam]
                                                                .profilePicture,
                                                    fit: BoxFit.cover,
                                                    placeholder: (context,
                                                            url) =>
                                                        _loader(context,
                                                            "assets/profile/user_on_user.png"),
                                                    errorWidget: (context, url,
                                                            error) =>
                                                        _error(
                                                            "assets/profile/user_on_user.png"),
                                                  ))),
                                              flex: 0,
                                            ),
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Row(children: <Widget>[
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 0.0,
                                                                left: 11),
                                                        child: Text(
                                                          reviewList[iteam]
                                                              .name,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: TextStyle(
                                                              fontSize: 16,
                                                              fontFamily: Constant
                                                                  .latoSemibold,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION_1),
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 0.0,
                                                                right: 0.0),
                                                        child: Text(
                                                          Util.getConvertedDateStamp(
                                                                  reviewList[
                                                                          iteam]
                                                                      .date
                                                                      .toString())
                                                              .toString(),
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              fontFamily: Constant
                                                                  .latoRegular,
                                                              color: ColorValues
                                                                  .labelColor),
                                                        ),
                                                      ),
                                                      flex: 0,
                                                    )
                                                  ]),
                                                  Row(
                                                    children: <Widget>[
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 5.0,
                                                                left: 11),
                                                        child: Text(
                                                          '${reviewList[iteam].rating}',
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: TextStyle(
                                                            fontSize: 14,
                                                            fontFamily: Constant
                                                                .latoSemibold,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            color: ColorValues
                                                                .labelColor,
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  top: 5.0,
                                                                  left: 5),
                                                          child:
                                                              SmoothStarRating(
                                                            rating: reviewList[
                                                                    iteam]
                                                                .rating,
                                                            allowHalfRating:
                                                                false,
                                                            size: 20,
                                                            color: Color(
                                                                0xffFEC901),
                                                            filledIconData:
                                                                Icons.star,
                                                            borderColor: Color(
                                                                0xffFDEDEDE),
                                                            defaultIconData:
                                                                Icons.star,
                                                            starCount: 5,
                                                            spacing: 1.0,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                        flex: 0,
                                      ),

                                      reviewList[iteam].review != null &&
                                              reviewList[iteam].review != ""
                                          ? Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 13,
                                                  bottom: 10,
                                                  left: 0,
                                                  right: 0),
                                              child: Container(
                                                height: 1.0,
                                                color: ColorValues
                                                    .BORDER_COLOR_NEW,
                                              ),
                                            )
                                          : Container(),

                                      reviewList[iteam].review != null &&
                                              reviewList[iteam].review != ""
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0.0, 5.0, 0.0, 5.0),
                                              child: Text(
                                                reviewList[iteam].review,
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  fontFamily:
                                                      Constant.latoRegular,
                                                  color: Colors.black,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            )
                                          : SizedBox(
                                              height: 0,
                                            )

                                      // isView
                                      //     ? reviewList.length - 1 != iteam
                                      //     ? Padding(
                                      //   padding: const EdgeInsets.all(8.0),
                                      //   child: Container(
                                      //     height: 1.0,
                                      //     color: ColorValues
                                      //         .GREY__COLOR_DIVIDER,
                                      //   ),
                                      // )
                                      //     : Container()
                                      //     : iteam == 0
                                      //     ? Padding(
                                      //   padding: const EdgeInsets.all(8.0),
                                      //   child: Container(
                                      //     height: 1.0,
                                      //     color: ColorValues
                                      //         .GREY__COLOR_DIVIDER,
                                      //   ),
                                      // )
                                      //     : Container(),
                                    ],
                                  ),
                                ),
                              ),
                              reviewList.length > 2
                                  ? InkWell(
                                      onTap: () {
                                        if (isView) {
                                          isView = false;
                                        } else {
                                          isView = true;
                                        }
                                        setState(() {
                                          isView;
                                        });
                                      },
                                      child: !isView
                                          ? iteam == 1
                                              ? PaddingWrap.paddingfromLTRB(
                                                  5.0,
                                                  25.0,
                                                  5.0,
                                                  8.0,
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(7),
                                                          border: Border.all(
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR)),
                                                      height: 30.0,
                                                      width:
                                                          reviewList.length > 2
                                                              ? 90.0
                                                              : 90,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 5),
                                                        child: Text("View all",
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: TextStyle(
                                                                color: ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR,
                                                                fontFamily: Constant
                                                                    .latoRegular,
                                                                fontSize:
                                                                    14.0)),
                                                      ),
                                                    ),
                                                  ))
                                              : Container()
                                          : iteam == reviewList.length - 1
                                              ? PaddingWrap.paddingfromLTRB(
                                                  5.0,
                                                  23.0,
                                                  5.0,
                                                  8.0,
                                                  Center(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(7),
                                                          border: Border.all(
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR)),
                                                      height: 30.0,
                                                      width:
                                                          reviewList.length > 2
                                                              ? 90.0
                                                              : 90,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 5),
                                                        child: Text("View less",
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: TextStyle(
                                                                color: ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR,
                                                                fontFamily: Constant
                                                                    .latoRegular,
                                                                fontSize:
                                                                    14.0)),
                                                      ),
                                                    ),
                                                  ))
                                              : Container(),
                                    )
                                  : Container(
                                      height: 0.0,
                                    )
                            ],
                          )
                        : Container(
                            height: 0.0,
                          ),
                  );
                }),
          )
        : Container(
            height: 10.0,
          );
  }

  onTapEditProfile() async {
    if (companyModel != null) {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => EditCompanyImages(
                companyModel,
                sasToken,
                strPrefixPathforCoverPhoto,
                strPrefixPathforProfilePhoto,
              )));
      if (result != "pop") {
        bloc.personalInfoInstanceUpdateToNull();
        bloc.fetchPersonalInfo(userIdPref, context, prefs);
      }
    }
  }

  InkWell isImageSelectedView() {
    return InkWell(
      child: Container(
        width: 65.0,
        height: 65.0,
        child: Stack(
          children: <Widget>[

            Center(
              child: Stack(
                children: [

                  Container(
                    width: 65.0,
                    height: 65.0,
                    decoration: BoxDecoration(
                      color: ColorValues.DARK_YELLOW,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: ColorValues.DARK_YELLOW,
                          offset: Offset(0, 0),
                          blurRadius: 6,
                        ),
                      ],
                      border: Border.all(
                        color: ColorValues.DARK_YELLOW,
                        width: 5,
                      ),
                    ),
                  ),




                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: companyModel != null
                          ? CachedNetworkImage(
                              imageUrl: companyModel != null
                                  ? Constant.IMAGE_PATH_SMALL +
                                      ParseJson.getMediumImage(
                                          companyModel.profilePicture)
                                  : "",
                              fit: BoxFit.cover,
                              placeholder: (context, url) => _loader(
                                  context, "assets/profile/partner_img.png"),
                              errorWidget: (context, url, error) =>
                                  _error("assets/profile/partner_img.png"),
                            )
                          : Image.asset("assets/profile/partner_img.png"),
                    ),
                  ),

                  // ProfileImageView(
                  //   imagePath:Constant.IMAGE_PATH_SMALL +
                  //       ParseJson.getMediumImage(
                  //           companyModel.profilePicture),
                  //   placeHolderImage: "assets/profile/partner_img.png",
                  //   width: 46.0,
                  //   height: 46.0,
                  //   // onTap: () async{
                  //   //   onTapImageTile(
                  //   //       userPostModal.postedBy, userPostModal.roleId);
                  //   // },
                  // ),


                ],
              ),
            ),
            // Align(
            //     alignment: Alignment.bottomRight,
            //     child: Container(
            //       padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            //       child: Image.asset("assets/newDesignIcon/edit_img.png"),
            //       height: 35.0,
            //       width: 35.0,
            //     )
            // )
          ],
        ),
      ),
      onTap: () {
      //  onTapEditProfile();
      },
    );
  }

  int getLenthOfName() {
    int lenght = 0;
    if (companyModel == null) {
      return 0;
    } else {
      lenght = companyModel.name.length;
    }

    return lenght;
  }

  showLoadMore(List<OpportunityModel> list, index) {
    if (list[index].offerId == "1" ||
        list[index].offerId == "2" ||
        list[index].offerId == "3") {
      return list[index].project.length > 180;
    } else if (list[index].offerId == "4" || list[index].offerId == "5") {
      return list[index].serviceDesc.length > 180;
    } else {
      return list[index].description.length > 180;
    }
  }

  showLoadMoreExpire(index) {
    if (expireOpportunityList[index].offerId == "1" ||
        expireOpportunityList[index].offerId == "2" ||
        expireOpportunityList[index].offerId == "3") {
      return expireOpportunityList[index].project.length > 180;
    } else if (expireOpportunityList[index].offerId == "4" ||
        expireOpportunityList[index].offerId == "5") {
      return expireOpportunityList[index].serviceDesc.length > 180;
    } else {
      return expireOpportunityList[index].description.length > 180;
    }
  }

  Widget getOportunityPending() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(13.0, 18.0, 13.0, 0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color: ColorValues.SELECTION_BG,
            // border: Border.all(
            //     color: ColorValues
            //         .BORDER_COLOR,
            //     width: 0.5)
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              height: 50,
              decoration: BoxDecoration(
                  color: ColorValues.LIST_BOTTOM_BG,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 0.0, left: 15),
                      child: Text(
                        "Pending opportunities",
                        style: TextStyle(
                            fontSize: 18,
                            fontFamily: Constant.latoSemibold,
                            color: ColorValues.HEADING_COLOR_EDUCATION_1),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List.generate(
                    //
                    // pendingOpportunityList.length > 2
                    //     ? isShowAllPendingOpportunity
                    //         ? pendingOpportunityList.length
                    //         : 2
                    //     : pendingOpportunityList.length
                    pendingOpportunityList.length, (int index) {
                  int lastIndex = pendingOpportunityList.length - 1;

                  return Column(
                    children: <Widget>[
                      InkWell(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                15.0,
                                16.0,
                                15.0,
                                10.0,
                                //

                                pendingOpportunityList[index]
                                            .assestVideoAndImage
                                            .length >
                                        0
                                    ? SizedBox(
                                        // Pager view
                                    height: 190.50,
                                        child: PageIndicatorContainer(
                                          pageView: PageView.builder(
                                            itemCount:
                                                pendingOpportunityList[index]
                                                    .assestVideoAndImage
                                                    .length,
                                            controller: PageController(),
                                            itemBuilder: (context, index2) {
                                              Future<String> thumbnailFile;
                                              if (pendingOpportunityList[index]
                                                      .assestVideoAndImage[
                                                          index2]
                                                      .type ==
                                                  "video") {
                                                thumbnailFile =
                                                    getVideoThumbnail(
                                                        context,
                                                        pendingOpportunityList[
                                                                index]
                                                            .assestVideoAndImage[
                                                                index2]
                                                            .file);
                                                print(
                                                    'view thumbnailFile:: ${thumbnailFile}');
                                              }

                                              return Stack(
                                                children: <Widget>[

                                              ClipRRect(
                                              borderRadius: BorderRadius.circular(10), // Apply a radius of 10
                                              child :
                                                  pendingOpportunityList[index]
                                                              .assestVideoAndImage[
                                                                  index2]
                                                              .type ==
                                                          "image"
                                                      ? Container(
                                                          decoration: BoxDecoration(
                                                              color:
                                                                  Colors.black,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10)),
                                                          child:
                                                              CachedNetworkImage(
                                                            width:
                                                                double.infinity,
                                                                height: 190.50,
                                                            imageUrl: Constant
                                                                    .IMAGE_PATH +
                                                                pendingOpportunityList[
                                                                        index]
                                                                    .assestVideoAndImage[
                                                                        index2]
                                                                    .file,
                                                            fit: BoxFit.contain,
                                                            placeholder: (context,
                                                                    url) =>
                                                                _loader(context,
                                                                    "assets/aerial/default_img.png"),
                                                            errorWidget: (context,
                                                                    url,
                                                                    error) =>
                                                                _error(
                                                                    "assets/aerial/default_img.png"),
                                                          ))
                                                      : InkWell(
                                                          child: Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors.black,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10),
                                                          ),
                                                            height: 190.50,
                                                          child: Center(
                                                            child: VideoPlayPause(
                                                                pendingOpportunityList[
                                                                        index]
                                                                    .assestVideoAndImage[
                                                                        index2]
                                                                    .file,
                                                                "",
                                                                true),
                                                          ),
                                                        )),
                                              ),
                                              ClipRRect(
                                              borderRadius: BorderRadius.circular(10), // Apply a radius of 10
                                              child :
                                                  pendingOpportunityList[index]
                                                                  .assestVideoAndImage
                                                                  .length ==
                                                              1 ||
                                                          pendingOpportunityList[
                                                                      index]
                                                                  .assestVideoAndImage[
                                                                      index2]
                                                                  .type ==
                                                              "video"
                                                      ? Container(
                                                          height: 0.0,
                                                        )
                                                      : Container(
                                                    height: 190.50,
                                                          width:
                                                              double.infinity,
                                                          child: Image.asset(
                                                            "assets/newDesignIcon/navigation/layer_image.png",
                                                            fit: BoxFit.fill,
                                                          ),
                                                        )

                                              )
                                                ],
                                              );
                                            },
                                            onPageChanged: (index) {},
                                          ),
                                          align: IndicatorAlign.bottom,
                                          length: pendingOpportunityList[index]
                                              .assestVideoAndImage
                                              .length,
                                          indicatorSpace: 10.0,
                                          indicatorColor:
                                              pendingOpportunityList[index]
                                                          .assestVideoAndImage
                                                          .length ==
                                                      1
                                                  ? Colors.transparent
                                                  : Color(0xffc4c4c4),
                                          indicatorSelectorColor:
                                              pendingOpportunityList[index]
                                                          .assestVideoAndImage
                                                          .length ==
                                                      1
                                                  ? Colors.transparent
                                                  : ColorValues.WHITE,
                                          shape:
                                              IndicatorShape.circle(size: 5.0),
                                        ))
                                    : Stack(children: <Widget>[
                                        Image.asset(
                                          "assets/profile/default_achievement.png",
                                          fit: BoxFit.cover,
                                          height: 190.50,
                                          width: double.infinity,
                                        ),
                                        Container(
                                          height: 190.50,
                                          color: Colors.black54.withOpacity(.4),
                                        )
                                      ])),
                            PaddingWrap.paddingfromLTRB(
                                15.0,
                                5.0,
                                15.0,
                                6.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            pendingOpportunityList[index]
                                                            .offerId ==
                                                        "4" ||
                                                    pendingOpportunityList[
                                                                index]
                                                            .offerId ==
                                                        "5"
                                                ? pendingOpportunityList[index]
                                                    .serviceTitle
                                                : pendingOpportunityList[index]
                                                            .jobTitle !=
                                                        "null"
                                                    ? pendingOpportunityList[
                                                            index]
                                                        .jobTitle
                                                    : "",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                fontWeight: FontWeight.w600,
                                                fontFamily: Constant.latoMedium),
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            onTap: () {
                                              activateAgain(
                                                  index,
                                                  pendingOpportunityList,
                                                  "edit");
                                            },
                                            child: Image.asset(
                                              "assets/png/edit_blue.png",
                                              height: 20.0,
                                              width: 20.0,
                                            ),
                                          ),
                                          flex: 0,
                                        ),
                                      ],
                                    ),

                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        0.0,
                                        5.0,
                                        Text(
                                          pendingOpportunityList[index]
                                                          .offerId ==
                                                      "1" ||
                                                  pendingOpportunityList[index]
                                                          .offerId ==
                                                      "2" ||
                                                  pendingOpportunityList[index]
                                                          .offerId ==
                                                      "3"
                                              ? pendingOpportunityList[index]
                                                  .project
                                              : pendingOpportunityList[index]
                                                              .offerId ==
                                                          "4" ||
                                                      pendingOpportunityList[
                                                                  index]
                                                              .offerId ==
                                                          "5"
                                                  ? pendingOpportunityList[
                                                          index]
                                                      .serviceDesc
                                                  : pendingOpportunityList[
                                                          index]
                                                      .description,
                                          maxLines:
                                              pendingOpportunityList[index]
                                                      .isViewMore
                                                  ? 100
                                                  : 3,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 12.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant.latoRegular),
                                        )),

                                    showLoadMore(pendingOpportunityList, index)
                                        ? PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            5.0,
                                            0.0,
                                            5.0,
                                            InkWell(
                                              child: Text(
                                                pendingOpportunityList[index]
                                                        .isViewMore
                                                    ? "Less"
                                                    : "More",
                                                maxLines: 3,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily:
                                                        Constant.latoRegular),
                                              ),
                                              onTap: () {
                                                pendingOpportunityList[index]
                                                        .isViewMore =
                                                    !pendingOpportunityList[
                                                            index]
                                                        .isViewMore;
                                                setState(() {});
                                              },
                                            ))
                                        : Container(
                                            height: 0.0,
                                          ),
                                    pendingOpportunityList[index].offerId ==
                                                "6" ||
                                            pendingOpportunityList[index]
                                                    .offerId ==
                                                "7" ||
                                            pendingOpportunityList[index]
                                                    .offerId ==
                                                "8"
                                        ? Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Row(
                                                children: <Widget>[
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      Text(
                                                        "Scheduled for  ",
                                                        textAlign:
                                                            TextAlign.left,
                                                        maxLines: null,
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontWeight:
                                                            FontWeight
                                                                .w600,
                                                            fontFamily: Constant.latoRegular,
                                                            fontSize: 14.0),
                                                      )),
                                                ],
                                              ),
                                              getScheduleWidget(
                                                  pendingOpportunityList[
                                                      index]),
                                            ],
                                          )
                                        : Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  0.0,
                                                  0.0,
                                                  Text(
                                                    'Scheduled for ',
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 14.0),
                                                  )),

                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  8.0,
                                                  0.0,
                                                  5.0,
                                                  Text(
                                                    getConvertedDateStamp2(
                                                            pendingOpportunityList[
                                                                    index]
                                                                .fromDate) +
                                                        " - " +
                                                        getConvertedDateStamp2(
                                                            pendingOpportunityList[
                                                                    index]
                                                                .toDate),
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .labelColor,
                                                        fontFamily: Constant.latoRegular,
                                                        fontWeight:
                                                        FontWeight.w600,
                                                        fontSize: 12.0),
                                                  )),

                                            ],
                                          ),
                                  ],
                                )),
                            Row(
                              children: <Widget>[
                                InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      16.0,
                                      5.0,
                                      18.0,
                                      5.0,
                                      Text(
                                        "View more",
                                        textAlign: TextAlign.left,
                                        maxLines: null,
                                        style: TextStyle(
                                            color: ColorValues
                                                .BLUE_COLOR_BOTTOMBAR,
                                            fontFamily: Constant.latoRegular,
                                            fontSize: 14.0),
                                      )),
                                  onTap: () {
                                    onTapEditPendingopportunity(
                                        index, pendingOpportunityList);
                                  },
                                ),
                              ],
                            ),

                            index == lastIndex ? const SizedBox() :
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  18.0, 12.0, 18.0, 10.0),
                              child: Container(
                                height: 1.0,
                                color: ColorValues.BORDER_COLOR,
                              ),
                            )
                          ],
                        ),
                        onTap: () {},
                      )
                    ],
                  );
                })),


            pendingOpportunityList.length > 4 ?
            Column(
              mainAxisAlignment:
              MainAxisAlignment.start,
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                      0.0, 5.0, 0.0, 5.0),
                  child: Container(
                    height: 1.0,
                    color: ColorValues.BORDER_COLOR,
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // expireOpportunityList.length > 2
                    //  ?
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          6.0,
                          6.0,
                          6.0,
                          10.0,
                          Text(
                            "Load More",
                            style: TextStyle(
                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                fontSize: 14.0,
                                fontFamily: Constant.latoRegular),
                          )
                        // isShowAllExpireOpportunity
                        //     ? Text(
                        //         "View Less",
                        //         style: TextStyle(
                        //             color:
                        //                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                        //             fontSize: 14.0,
                        //             fontFamily:
                        //                 Constant.latoRegular),
                        //       )
                        //     : Text(
                        //         "View All " +
                        //             expireOpportunityList.length
                        //                 .toString() +
                        //             " Expired Opportunities",
                        //         style: TextStyle(
                        //             color:
                        //                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                        //             fontSize: 14.0,
                        //             fontFamily:
                        //                 Constant.TYPE_CUSTOMREGULAR),
                        //       )
                      ),
                      onTap: () {
                        setState(() {


                          skipPending = skipPending + 1;
                          strLoadMoreOpportuniesFor = 'pending';
                          getOpportuinityForLoadMore(true);
                        });
                      },
                    )
                    //     :
                    // Container(
                    //         height: 0.0,
                    //         color: Colors.black,
                    //       ),
                  ],
                ),
              ],
            ) : const SizedBox(height: 5,)

          ],
        ),
      ),
    );
  }

  Widget getOportunityrejected() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(13.0, 18.0, 13.0, 0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color: ColorValues.SELECTION_BG,
            // border: Border.all(
            //     color: ColorValues
            //         .BORDER_COLOR,
            //     width: 0.5)
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Column(children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                    height: 50,
                    decoration: BoxDecoration(
                        color: ColorValues.LIST_BOTTOM_BG,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10))),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 0.0, left: 15),
                            child: Text(
                              "Rejected opportunities",
                              style: TextStyle(
                                  fontSize: 18,
                                  fontFamily: Constant.latoSemibold,
                                  color: ColorValues.HEADING_COLOR_EDUCATION_1),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                ],
              )
            ]),
            Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List.generate(
                    // rejectOpportunityList.length > 2
                    //     ? isShowAllRejectOpportunity
                    //         ? rejectOpportunityList.length
                    //         : 2
                    //     : rejectOpportunityList.length
                    rejectOpportunityList.length, (int index) {
                  int lastIndex = rejectOpportunityList.length - 1;

                  return Column(
                    children: <Widget>[
                      InkWell(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                15.0,
                                10.0,
                                15.0,
                                0.0,
                                //
                                rejectOpportunityList[index]
                                            .assestVideoAndImage
                                            .length >
                                        0
                                    ? SizedBox(
                                        // Pager view
                                    height: 190.50,
                                        child: PageIndicatorContainer(
                                          pageView: PageView.builder(
                                            itemCount:
                                                rejectOpportunityList[index]
                                                    .assestVideoAndImage
                                                    .length,
                                            controller: PageController(),
                                            itemBuilder: (context, index2) {
                                              Future<String> thumbnailFile;
                                              if (rejectOpportunityList[index]
                                                      .assestVideoAndImage[
                                                          index2]
                                                      .type ==
                                                  "video") {
                                                thumbnailFile =
                                                    getVideoThumbnail(
                                                        context,
                                                        rejectOpportunityList[
                                                                index]
                                                            .assestVideoAndImage[
                                                                index2]
                                                            .file);
                                                print(
                                                    'view thumbnailFile:: ${thumbnailFile}');
                                              }

                                              return Stack(
                                                children: <Widget>[

                                              ClipRRect(
                                              borderRadius: BorderRadius.circular(10), // Apply a radius of 10
                                              child :

                                                  rejectOpportunityList[index]
                                                              .assestVideoAndImage[
                                                                  index2]
                                                              .type ==
                                                          "image"
                                                      ? Container(
                                                          decoration: BoxDecoration(
                                                              color:
                                                                  Colors.black,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10)),
                                                          child:
                                                              CachedNetworkImage(
                                                            width:
                                                                double.infinity,
                                                                height: 190.50,
                                                            imageUrl: Constant
                                                                    .IMAGE_PATH +
                                                                rejectOpportunityList[
                                                                        index]
                                                                    .assestVideoAndImage[
                                                                        index2]
                                                                    .file,
                                                            fit: BoxFit.contain,
                                                            placeholder: (context,
                                                                    url) =>
                                                                _loader(context,
                                                                    "assets/aerial/default_img.png"),
                                                            errorWidget: (context,
                                                                    url,
                                                                    error) =>
                                                                _error(
                                                                    "assets/aerial/default_img.png"),
                                                          ))
                                                      : InkWell(
                                                          child: Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors.black,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10),
                                                          ),
                                                            height: 190.50,
                                                          child: Center(
                                                            child: VideoPlayPause(
                                                                rejectOpportunityList[
                                                                        index]
                                                                    .assestVideoAndImage[
                                                                        index2]
                                                                    .file,
                                                                "",
                                                                true),
                                                          ),
                                                        )),
                                              ),
                                              ClipRRect(
                                              borderRadius: BorderRadius.circular(10), // Apply a radius of 10
                                              child :
                                                  rejectOpportunityList[index]
                                                                  .assestVideoAndImage
                                                                  .length ==
                                                              1 ||
                                                          rejectOpportunityList[
                                                                      index]
                                                                  .assestVideoAndImage[
                                                                      index2]
                                                                  .type ==
                                                              "video"
                                                      ? Container(
                                                          height: 0.0,
                                                        )
                                                      : Container(
                                                    height: 190.50,
                                                          width:
                                                              double.infinity,
                                                          child: Image.asset(
                                                            "assets/newDesignIcon/navigation/layer_image.png",
                                                            fit: BoxFit.fill,
                                                          ),
                                                        )
                                              )
                                                ],
                                              );
                                            },
                                            onPageChanged: (index) {},
                                          ),
                                          align: IndicatorAlign.bottom,
                                          length: rejectOpportunityList[index]
                                              .assestVideoAndImage
                                              .length,
                                          indicatorSpace: 10.0,
                                          indicatorColor:
                                              rejectOpportunityList[index]
                                                          .assestVideoAndImage
                                                          .length ==
                                                      1
                                                  ? Colors.transparent
                                                  : Color(0xffc4c4c4),
                                          indicatorSelectorColor:
                                              rejectOpportunityList[index]
                                                          .assestVideoAndImage
                                                          .length ==
                                                      1
                                                  ? Colors.transparent
                                                  : ColorValues.WHITE,
                                          shape:
                                              IndicatorShape.circle(size: 5.0),
                                        ))
                                    : Stack(children: <Widget>[
                                        Image.asset(
                                          "assets/profile/default_achievement.png",
                                          fit: BoxFit.cover,
                                          height: 190.50,
                                          width: double.infinity,
                                        ),
                                        Container(
                                          height: 190.50,
                                          color: Colors.black54.withOpacity(.4),
                                        )
                                      ])),
                            PaddingWrap.paddingfromLTRB(
                                15.0,
                                10.0,
                                15.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            rejectOpportunityList[index]
                                                            .offerId ==
                                                        "4" ||
                                                    rejectOpportunityList[index]
                                                            .offerId ==
                                                        "5"
                                                ? rejectOpportunityList[index]
                                                    .serviceTitle
                                                : rejectOpportunityList[index]
                                                            .jobTitle !=
                                                        "null"
                                                    ? rejectOpportunityList[
                                                            index]
                                                        .jobTitle
                                                    : "",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                fontWeight: FontWeight.w600,
                                                fontFamily: Constant.latoMedium),
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            onTap: () {
                                              activateAgain(
                                                  index,
                                                  rejectOpportunityList,
                                                  "edit");

                                              // activateAgain(
                                              //     index,
                                              //     rejectOpportunityList,
                                              //     "repost");
                                            },
                                            child: Image.asset(
                                              "assets/png/edit_blue.png",
                                              height: 20.0,
                                              width: 20.0,
                                            ),
                                          ),
                                          flex: 0,
                                        ),
                                      ],
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        0.0,
                                        5.0,
                                        Text(
                                          rejectOpportunityList[index]
                                                          .offerId ==
                                                      "1" ||
                                                  rejectOpportunityList[index]
                                                          .offerId ==
                                                      "2" ||
                                                  rejectOpportunityList[index]
                                                          .offerId ==
                                                      "3"
                                              ? rejectOpportunityList[index]
                                                  .project
                                              : rejectOpportunityList[index]
                                                              .offerId ==
                                                          "4" ||
                                                      rejectOpportunityList[
                                                                  index]
                                                              .offerId ==
                                                          "5"
                                                  ? rejectOpportunityList[index]
                                                      .serviceDesc
                                                  : rejectOpportunityList[index]
                                                      .description,
                                          maxLines: rejectOpportunityList[index]
                                                  .isViewMore
                                              ? 100
                                              : 3,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 12.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant.latoRegular),
                                        )),
                                    showLoadMore(rejectOpportunityList, index)
                                        ? PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            5.0,
                                            0.0,
                                            5.0,
                                            InkWell(
                                              child: Text(
                                                rejectOpportunityList[index]
                                                        .isViewMore
                                                    ? "Less"
                                                    : "More",
                                                maxLines: 3,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily:
                                                        Constant.latoRegular),
                                              ),
                                              onTap: () {
                                                rejectOpportunityList[index]
                                                        .isViewMore =
                                                    !rejectOpportunityList[
                                                            index]
                                                        .isViewMore;
                                                setState(() {});
                                              },
                                            ))
                                        : Container(
                                            height: 0.0,
                                          ),
                                    rejectOpportunityList[index].offerId ==
                                                "6" ||
                                            rejectOpportunityList[index]
                                                    .offerId ==
                                                "7" ||
                                            rejectOpportunityList[index]
                                                    .offerId ==
                                                "8"
                                        ? Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Row(
                                                children: <Widget>[
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      Text(
                                                        "Scheduled for  ",
                                                        textAlign:
                                                            TextAlign.left,
                                                        maxLines: null,
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontWeight:
                                                            FontWeight
                                                                .w600,
                                                            fontFamily: Constant.latoRegular,
                                                            fontSize: 14.0),
                                                      )),
                                                ],
                                              ),
                                              getScheduleWidget(
                                                  rejectOpportunityList[index]),
                                            ],
                                          )
                                        : Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  0.0,
                                                  5.0,
                                                  Text(
                                                    "Scheduled for  ",
                                                    textAlign: TextAlign.left,
                                                    maxLines: null,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontWeight:
                                                          FontWeight
                                                              .w600,
                                                          fontFamily: Constant.latoRegular,
                                                          fontSize: 14.0),
                                                  )),

                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  5.0,
                                                  0.0,
                                                  9.0,
                                                  Text(
                                                    getConvertedDateStamp2(
                                                            rejectOpportunityList[
                                                                    index]
                                                                .fromDate) +
                                                        " - " +
                                                        getConvertedDateStamp2(
                                                            rejectOpportunityList[
                                                                    index]
                                                                .toDate),
                                                    textAlign: TextAlign.left,
                                                    maxLines: null,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .labelColor,
                                                        fontFamily: Constant.latoRegular,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 12.0),
                                                  )),
                                              //
                                              // PaddingWrap.paddingfromLTRB(
                                              //   0.0,
                                              //   10.0,
                                              //   0.0,
                                              //   9.0,
                                              //   AppTextStyle.getLableTextForDetail(
                                              //       'Scheduled for: ',
                                              //       getConvertedDateStamp2(
                                              //               rejectOpportunityList[
                                              //                       index]
                                              //                   .fromDate) +
                                              //           " - " +
                                              //           getConvertedDateStamp2(
                                              //               rejectOpportunityList[
                                              //                       index]
                                              //                   .toDate)),
                                              // ),
                                            ],
                                          ),
                                  ],
                                )),


                            Row(
                              children: <Widget>[
                                InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      15.0,
                                      5.0,
                                      0.0,
                                      5.0,
                                      Text(
                                        "View more",
                                        textAlign: TextAlign.left,
                                        maxLines: null,
                                        style: TextStyle(
                                            color: ColorValues
                                                .BLUE_COLOR_BOTTOMBAR,
                                            fontFamily:
                                            Constant.latoRegular,
                                            fontSize: 14.0),
                                      )),
                                  onTap: () {
                                    onTapEditRejectedopportunity(
                                        index, rejectOpportunityList);
                                  },
                                ),
                              ],
                            ),

                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  15.0, 12.0, 15.0, 10.0),
                              child: Container(
                                height: 1.0,
                                color: ColorValues.BORDER_COLOR,
                              ),
                            )
                          ],
                        ),

                        onTap: () {
                          // onTapEditRejectedopportunity(
                          //     index, rejectOpportunityList);
                        },
                      )
                    ],
                  );
                })),

            rejectOpportunityList.length > 4 ?
            Column(

              mainAxisAlignment:
            MainAxisAlignment.start,
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                      0.0, 5.0, 0.0, 10.0),
                  child: Container(
                    height: 1.0,
                    color: ColorValues.BORDER_COLOR,
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // expireOpportunityList.length > 2
                    //  ?
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          6.0,
                          6.0,
                          6.0,
                          10.0,
                          Text(
                            "Load More",
                            style: TextStyle(
                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                fontSize: 14.0,
                                fontFamily: Constant.latoRegular),
                          )
                        // isShowAllExpireOpportunity
                        //     ? Text(
                        //         "View Less",
                        //         style: TextStyle(
                        //             color:
                        //                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                        //             fontSize: 14.0,
                        //             fontFamily:
                        //                 Constant.latoRegular),
                        //       )
                        //     : Text(
                        //         "View All " +
                        //             expireOpportunityList.length
                        //                 .toString() +
                        //             " Expired Opportunities",
                        //         style: TextStyle(
                        //             color:
                        //                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                        //             fontSize: 14.0,
                        //             fontFamily:
                        //                 Constant.TYPE_CUSTOMREGULAR),
                        //       )
                      ),
                      onTap: () {
                        setState(() {


                          skipRejected = skipRejected + 1;
                          strLoadMoreOpportuniesFor = 'rejected';
                          getOpportuinityForLoadMore(true);
                        });
                      },
                    )
                    //     :
                    // Container(
                    //         height: 0.0,
                    //         color: Colors.black,
                    //       ),
                  ],
                ),
              ],
            ) : const SizedBox(),

            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                rejectOpportunityList.length > 2
                    ? InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                            6.0,
                            6.0,
                            6.0,
                            10.0,
                            isShowAllRejectOpportunity
                                ? Text(
                                    "View Less",
                                    style: TextStyle(
                                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontSize: 14.0,
                                        fontFamily: Constant.latoRegular),
                                  )
                                : Text(
                                    "View All " +
                                        rejectOpportunityList.length
                                            .toString() +
                                        " Reject Opportunities",
                                    style: TextStyle(
                                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontSize: 14.0,
                                        fontFamily: Constant.latoRegular),
                                  )),
                        onTap: () {
                          setState(() {
                            if (isShowAllRejectOpportunity)
                              isShowAllRejectOpportunity = false;
                            else
                              isShowAllRejectOpportunity = true;
                          });
                        },
                      )
                    : Container(
                        height: 0.0,
                        color: Colors.black,
                      ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget getOportunityActive() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(13.0, 18.0, 13.0, 0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color: ColorValues.SELECTION_BG,
            // border: Border.all(
            //     color: ColorValues
            //         .BORDER_COLOR,
            //     width: 0.5)
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              height: 50,
              decoration: BoxDecoration(
                  color: ColorValues.LIST_BOTTOM_BG,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 0.0, left: 15),
                      child: Text(
                        "Active opportunity",
                        style: TextStyle(
                            fontSize: 18,
                            fontFamily: Constant.latoSemibold,
                            color: ColorValues.HEADING_COLOR_EDUCATION_1),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10,right: 15,left: 15,bottom:4),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List.generate(
                      // activeOpportunityList.length > 2
                      //     ? isShowAllActiveOpportunity
                      //         ? activeOpportunityList.length
                      //         : 2
                      //     : activeOpportunityList.length
                      activeOpportunityList.length, (int index) {

                    int lastIndex = expireOpportunityList.length - 1;

                    return Column(
                      children: <Widget>[
                        InkWell(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[


                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  10.0,
                                  //
                                  activeOpportunityList[index]
                                              .assestVideoAndImage
                                              .length >
                                          0
                                      ? SizedBox(
                                          // Pager view
                                      height: 190.50,
                                          child: PageIndicatorContainer(
                                            pageView: PageView.builder(
                                              itemCount:
                                                  activeOpportunityList[index]
                                                      .assestVideoAndImage
                                                      .length,
                                              controller: PageController(),
                                              itemBuilder: (context, index2) {


                                                Future<String> thumbnailFile;
                                                if (activeOpportunityList[index]
                                                        .assestVideoAndImage[
                                                            index2]
                                                        .type ==
                                                    "video") {
                                                  thumbnailFile =
                                                      getVideoThumbnail(
                                                          context,
                                                          activeOpportunityList[
                                                                  index]
                                                              .assestVideoAndImage[
                                                                  index2]
                                                              .file);
                                                  print(
                                                      'view thumbnailFile:: ${thumbnailFile}');
                                                }



                                                return Stack(
                                                  children: <Widget>[

                                                ClipRRect(
                                                borderRadius: BorderRadius.circular(10), // Apply a radius of 10
                                                child: activeOpportunityList[index]
                                                                .assestVideoAndImage[
                                                                    index2]
                                                                .type ==
                                                            "image"
                                                        ? Container(
                                                            decoration: BoxDecoration(
                                                                color: Colors
                                                                    .black,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10)),
                                                            child:
                                                                CachedNetworkImage(
                                                              width: double
                                                                  .infinity,
                                                                  height: 190.50,
                                                              imageUrl: Constant
                                                                      .IMAGE_PATH +
                                                                  activeOpportunityList[
                                                                          index]
                                                                      .assestVideoAndImage[
                                                                          index2]
                                                                      .file,
                                                              fit: BoxFit
                                                                  .contain,
                                                              placeholder: (context,
                                                                      url) =>
                                                                  _loader(
                                                                      context,
                                                                      "assets/aerial/default_img.png"),
                                                              errorWidget: (context,
                                                                      url,
                                                                      error) =>
                                                                  _error(
                                                                      "assets/aerial/default_img.png"),
                                                            ))
                                                        : InkWell(
                                                            child: Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color:
                                                                  Colors.black,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10),
                                                            ),
                                                              height: 190.50,
                                                            child: Center(
                                                              child: VideoPlayPause(
                                                                  activeOpportunityList[
                                                                          index]
                                                                      .assestVideoAndImage[
                                                                          index2]
                                                                      .file,
                                                                  "",
                                                                  true),
                                                              /*new Container(
                                                              child:  Stack(
                                                                children: <Widget>[

                                                                  Container(
                                                                    height: 215.0,
                                                                    color: Colors.black,
                                                                    margin: EdgeInsets.only(left: 0, right: 0),
                                                                    child:  VideoViewBlack(
                                                                        Constant.IMAGE_PATH + activeOpportunityList[
                                                                        index]
                                                                            .assestVideoAndImage[
                                                                        index2]
                                                                            .file, "", false, ""),
                                                                  ),
                                                                  */
                                                              /*new Container(
                                                                                        height: 54.0,
                                                                                        width: 80.0,
                                                                                        color:  Color(0XFFC0C0C0).withOpacity(.4),
                                                                                      ),*/
                                                              /*
                                                                   Center(
                                                                      child:  Row(
                                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                                        children: <Widget>[
                                                                           InkWell(
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                0.0,
                                                                                0.0,
                                                                                0.0,
                                                                                0.0,
                                                                                 Image.asset(
                                                                                  //'assets/pre_login/video_play_button.png',
                                                                                  'assets/newDesignIcon/circle_play.png',
                                                                                  width: 50.0,
                                                                                  height: 50.0,
                                                                                )),
                                                                          )
                                                                        ],
                                                                      )),
                                                                ],
                                                              )),*/
                                                            ),
                                                          )),

                                                ),

                                                ClipRRect(
                                                borderRadius: BorderRadius.circular(10), // Apply a radius of 10
                                                child :activeOpportunityList[index]
                                                                    .assestVideoAndImage
                                                                    .length ==
                                                                1 ||
                                                            activeOpportunityList[
                                                                        index]
                                                                    .assestVideoAndImage[
                                                                        index2]
                                                                    .type ==
                                                                "video"
                                                        ? Container(
                                                            height: 0.0,
                                                          )
                                                        : Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              // color:
                                                              //     Colors.black,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10),
                                                            ),
                                                  height: 190.50,
                                                            width:
                                                                double.infinity,
                                                            child: Image.asset(
                                                              "assets/newDesignIcon/navigation/layer_image.png",
                                                              fit: BoxFit.contain,
                                                            ),
                                                          )

                                                )

                                                  ],
                                                );


                                              },
                                              onPageChanged: (index) {},
                                            ),
                                            align: IndicatorAlign.bottom,
                                            length: activeOpportunityList[index]
                                                .assestVideoAndImage
                                                .length,
                                            indicatorSpace: 10.0,
                                            indicatorColor:
                                                activeOpportunityList[index]
                                                            .assestVideoAndImage
                                                            .length ==
                                                        1
                                                    ? Colors.transparent
                                                    : Color(0xffc4c4c4),
                                            indicatorSelectorColor:
                                                activeOpportunityList[index]
                                                            .assestVideoAndImage
                                                            .length ==
                                                        1
                                                    ? Colors.transparent
                                                    : ColorValues.WHITE,
                                            shape: IndicatorShape.circle(
                                                size: 5.0),
                                          ))
                                      : Stack(children: <Widget>[
                                          Image.asset(
                                            "assets/profile/default_achievement.png",
                                            fit: BoxFit.contain,
                                            height: 190.50,
                                            width: double.infinity,
                                          ),
                                          Container(
                                            height: 190.50,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              color: Colors.black54
                                                  .withOpacity(.4),
                                            ),
                                          )
                                        ])),

                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  8.0,
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: Text(
                                              activeOpportunityList[index]
                                                              .offerId ==
                                                          "4" ||
                                                      activeOpportunityList[
                                                                  index]
                                                              .offerId ==
                                                          "5"
                                                  ? activeOpportunityList[index]
                                                      .serviceTitle
                                                  : activeOpportunityList[index]
                                                              .jobTitle !=
                                                          "null"
                                                      ? activeOpportunityList[
                                                              index]
                                                          .jobTitle
                                                      : "",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontSize: 16.0,
                                                  fontWeight: FontWeight.w600,
                                                  fontFamily: Constant.latoMedium),
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          10.0,
                                          0.0,
                                          5.0,
                                          Text(
                                            activeOpportunityList[index]
                                                            .offerId ==
                                                        "1" ||
                                                    activeOpportunityList[index]
                                                            .offerId ==
                                                        "2" ||
                                                    activeOpportunityList[index]
                                                            .offerId ==
                                                        "3"
                                                ? activeOpportunityList[index]
                                                    .project
                                                : activeOpportunityList[index]
                                                                .offerId ==
                                                            "4" ||
                                                        activeOpportunityList[
                                                                    index]
                                                                .offerId ==
                                                            "5"
                                                    ? activeOpportunityList[
                                                            index]
                                                        .serviceDesc
                                                    : activeOpportunityList[
                                                            index]
                                                        .description,
                                            maxLines:
                                                activeOpportunityList[index]
                                                        .isViewMore
                                                    ? 100
                                                    : 3,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 12.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily:
                                                    Constant.latoRegular),
                                          )),

                                      showLoadMore(activeOpportunityList, index)
                                          ? PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              5.0,
                                              0.0,
                                              5.0,
                                              InkWell(
                                                child: Text(
                                                  activeOpportunityList[index]
                                                          .isViewMore
                                                      ? "Less"
                                                      : "More",
                                                  maxLines: 3,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.start,
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 14.0,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontFamily:
                                                          Constant.latoRegular),
                                                ),
                                                onTap: () {
                                                  activeOpportunityList[index]
                                                          .isViewMore =
                                                      !activeOpportunityList[
                                                              index]
                                                          .isViewMore;
                                                  setState(() {});
                                                },
                                              ))
                                          : Container(
                                              height: 0.0,
                                            ),
                                      activeOpportunityList[index].offerId ==
                                                  "6" ||
                                              activeOpportunityList[index]
                                                      .offerId ==
                                                  "7" ||
                                              activeOpportunityList[index]
                                                      .offerId ==
                                                  "8"
                                          ? Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Row(
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        10.0,
                                                        0.0,
                                                        5.0,
                                                        Text(
                                                          "Scheduled for  ",
                                                          textAlign:
                                                              TextAlign.left,
                                                          maxLines: null,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION_1,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              fontFamily: Constant.latoRegular,
                                                              fontSize: 14.0),
                                                        )),
                                                  ],
                                                ),
                                                getScheduleWidget(
                                                    activeOpportunityList[
                                                        index]),
                                              ],
                                            )
                                          : Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    10.0,
                                                    0.0,
                                                    5.0,
                                                    Text(
                                                      "Scheduled for ",
                                                      textAlign: TextAlign.left,
                                                      maxLines: null,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontWeight:
                                                          FontWeight
                                                              .w600,
                                                          fontFamily: Constant.latoRegular,
                                                          fontSize: 14.0),
                                                    )),

                                                PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    5.0,
                                                    0.0,
                                                    0.0,
                                                    Text(
                                                      getConvertedDateStamp2(
                                                              activeOpportunityList[
                                                                      index]
                                                                  .fromDate) +
                                                          " - " +
                                                          getConvertedDateStamp2(
                                                              activeOpportunityList[
                                                                      index]
                                                                  .toDate),
                                                      textAlign: TextAlign.left,
                                                      maxLines: null,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .labelColor,
                                                          fontFamily: Constant.latoRegular,
                                                          fontWeight:
                                                          FontWeight.w600,
                                                          fontSize: 12.0),
                                                    )),

                                                // PaddingWrap.paddingfromLTRB(
                                                //   0.0,
                                                //   10.0,
                                                //   0.0,
                                                //   9.0,
                                                //
                                                //   AppTextStyle.getLableTextForDetail(
                                                //       'Scheduled for: ',
                                                //       getConvertedDateStamp2(
                                                //               activeOpportunityList[
                                                //                       index]
                                                //                   .fromDate) +
                                                //           " - " +
                                                //           getConvertedDateStamp2(
                                                //               activeOpportunityList[
                                                //                       index]
                                                //                   .toDate)),
                                                // ),
                                              ],
                                            ),
                                      /*    Row(
                                          children: <Widget>[
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                0.0,
                                                16.0,
                                                 Text(
                                                  "Interests: " +
                                                      activeOpportunityList[index]
                                                          .numberOfClick,
                                                  textAlign: TextAlign.left,
                                                  maxLines: null,
                                                  style:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                )),
                                          ],
                                        ),*/
                                    ],
                                  )),
                              Row(
                                children: <Widget>[
                                  InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        0.0,
                                        10.0,
                                        Text(
                                          "View more",
                                          textAlign: TextAlign.left,
                                          maxLines: null,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontFamily: Constant.latoRegular,
                                              fontSize: 14.0),
                                        )),
                                    onTap: () {
                                      onTapEditActiveopportunity(
                                          index, activeOpportunityList);
                                    },
                                  ),
                                ],
                              ),

                             // index ==  lastIndex ? const SizedBox() :
                              Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 5.0, 0.0, 8.0),
                                child: Container(
                                  height: 1.0,
                                  color: ColorValues.BORDER_COLOR,
                                ),
                              )
                            ],
                          ),
                          onTap: () {},
                        )
                      ],
                    );
                  })),
            ),

            activeOpportunityList.length > 4 ?

            Column(
              mainAxisAlignment:
            MainAxisAlignment.start,
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                // Padding(
                //   padding: const EdgeInsets.fromLTRB(
                //       0.0, 5.0, 0.0, 5.0),
                //   child: Container(
                //     height: 1.0,
                //     color: ColorValues.BORDER_COLOR,
                //   ),
                // ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // expireOpportunityList.length > 2
                    //  ?
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          6.0,
                          0.0,
                          6.0,
                          10.0,
                          Text(
                            "Load More",
                            style: TextStyle(
                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                fontSize: 14.0,
                                fontFamily: Constant.latoRegular),
                          )
                        // isShowAllExpireOpportunity
                        //     ? Text(
                        //         "View Less",
                        //         style: TextStyle(
                        //             color:
                        //                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                        //             fontSize: 14.0,
                        //             fontFamily:
                        //                 Constant.latoRegular),
                        //       )
                        //     : Text(
                        //         "View All " +
                        //             expireOpportunityList.length
                        //                 .toString() +
                        //             " Expired Opportunities",
                        //         style: TextStyle(
                        //             color:
                        //                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                        //             fontSize: 14.0,
                        //             fontFamily:
                        //                 Constant.TYPE_CUSTOMREGULAR),
                        //       )
                      ),
                      onTap: () {
                        setState(() {
                          // if (isShowAllExpireOpportunity)
                          //   isShowAllExpireOpportunity = false;
                          // else
                          //   isShowAllExpireOpportunity = true;

                          skipActive = skipActive + 1;
                          strLoadMoreOpportuniesFor = 'active';
                          getOpportuinityForLoadMore(true);
                        });
                      },
                    )
                    //     :
                    // Container(
                    //         height: 0.0,
                    //         color: Colors.black,
                    //       ),
                  ],
                ),
              ],
            ) : const SizedBox(height: 5,)

          ],
        ),
      ),
    );
  }

  Widget getOportunityInActive() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(13.0, 18.0, 13.0, 0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color: ColorValues.SELECTION_BG,
            // border: Border.all(
            //     color: ColorValues
            //         .BORDER_COLOR,
            //     width: 0.5)
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              height: 50,
              decoration: BoxDecoration(
                  color: ColorValues.LIST_BOTTOM_BG,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 0.0, left: 15),
                      child: Text(
                        "Expired opportunities",
                        style: TextStyle(
                            fontSize: 18,
                            fontFamily: Constant.latoSemibold,
                            color: ColorValues.HEADING_COLOR_EDUCATION_1),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List.generate(
                    expireOpportunityList.length, (int index) {
                  int lastIndex = expireOpportunityList.length - 1;

                  return Column(
                    children: <Widget>[
                      PaddingWrap.paddingfromLTRB(
                          15.0,
                          16.0,
                          15.0,
                          10.0,
                          //
                          expireOpportunityList[index]
                                      .assestVideoAndImage
                                      .length >
                                  0
                              ? SizedBox(
                                  // Pager view
                              height: 190.50,
                                  child: PageIndicatorContainer(
                                    pageView: PageView.builder(
                                      itemCount: expireOpportunityList[index]
                                          .assestVideoAndImage
                                          .length,
                                      controller: PageController(),
                                      itemBuilder: (context, index2) {
                                        Future<String> thumbnailFile;
                                        if (expireOpportunityList[index]
                                                .assestVideoAndImage[index2]
                                                .type ==
                                            "video") {
                                          thumbnailFile = getVideoThumbnail(
                                              context,
                                              expireOpportunityList[index]
                                                  .assestVideoAndImage[index2]
                                                  .file);
                                          print(
                                              'view thumbnailFile:: ${thumbnailFile}');
                                        }

                                        return Stack(
                                          children: <Widget>[

                                        ClipRRect(
                                        borderRadius: BorderRadius.circular(10), // Apply a radius of 10
                                        child :
                                            expireOpportunityList[index]
                                                        .assestVideoAndImage[
                                                            index2]
                                                        .type ==
                                                    "image"
                                                ?   Container(
                                                decoration: BoxDecoration(
                                                    color: Colors.black,
                                                    borderRadius:
                                                    BorderRadius
                                                        .circular(10)),
                                                child:
                                                CachedNetworkImage(
                                                  width: double.infinity,
                                                  height: 190.50,
                                                  imageUrl: Constant
                                                      .IMAGE_PATH +
                                                      expireOpportunityList[
                                                      index]
                                                          .assestVideoAndImage[
                                                      index2]
                                                          .file,
                                                  fit: BoxFit.contain,
                                                  placeholder: (context,
                                                      url) =>
                                                      _loader(context,
                                                          "assets/aerial/default_img.png"),
                                                  errorWidget: (context,
                                                      url, error) =>
                                                      _error(
                                                          "assets/aerial/default_img.png"),
                                                )
                                            )

                                                /*
                                            Container(
                                                    decoration: BoxDecoration(
                                                        color: Colors.black,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10)),
                                                    child:
                                                    CachedNetworkImage(
                                                      width: double.infinity,
                                                      height: 215.50,
                                                      imageUrl: Constant
                                                              .IMAGE_PATH +
                                                          expireOpportunityList[
                                                                  index]
                                                              .assestVideoAndImage[
                                                                  index2]
                                                              .file,
                                                      fit: BoxFit.contain,
                                                      placeholder: (context,
                                                              url) =>
                                                          _loader(context,
                                                              "assets/aerial/default_img.png"),
                                                      errorWidget: (context,
                                                              url, error) =>
                                                          _error(
                                                              "assets/aerial/default_img.png"),
                                                    ))

                                                 */

                                                : InkWell(
                                                    child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Colors.black,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                    ),
                                                      height: 190.50,
                                                    child: Center(
                                                      child: VideoPlayPause(
                                                          expireOpportunityList[
                                                                  index]
                                                              .assestVideoAndImage[
                                                                  index2]
                                                              .file,
                                                          "",
                                                          true),
                                                    ),
                                                  )),
                                        ),
                                        ClipRRect(
                                        borderRadius: BorderRadius.circular(10), // Apply a radius of 10
                                        child :
                                            expireOpportunityList[index]
                                                            .assestVideoAndImage
                                                            .length ==
                                                        1 ||
                                                    expireOpportunityList[index]
                                                            .assestVideoAndImage[
                                                                index2]
                                                            .type ==
                                                        "video"
                                                ? Container(
                                                    height: 0.0,
                                                  )
                                                : Container(
                                                    decoration: BoxDecoration(
                                                     // color: Colors.black,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                    ),
                                              height: 190.50,
                                                    width: double.infinity,
                                                    child: Image.asset(
                                                      "assets/newDesignIcon/navigation/layer_image.png",
                                                      fit: BoxFit.contain,
                                                    ),
                                                  )
                                              )
                                          ],
                                        );
                                      },
                                      onPageChanged: (index) {},
                                    ),
                                    align: IndicatorAlign.bottom,
                                    length: expireOpportunityList[index]
                                        .assestVideoAndImage
                                        .length,
                                    indicatorSpace: 10.0,
                                    indicatorColor: expireOpportunityList[index]
                                                .assestVideoAndImage
                                                .length ==
                                            1
                                        ? Colors.transparent
                                        : Color(0xffc4c4c4),
                                    indicatorSelectorColor:
                                        expireOpportunityList[index]
                                                    .assestVideoAndImage
                                                    .length ==
                                                1
                                            ? Colors.transparent
                                            : ColorValues.WHITE,
                                        //ColorValues.WHITE

                                    shape: IndicatorShape.circle(size: 5.0),

                                  )

                          )
                              : Stack(children: <Widget>[
                                  Image.asset(
                                    "assets/profile/default_achievement.png",
                                    fit: BoxFit.cover,
                                    height: 190.50,
                                    width: double.infinity,
                                  ),

                                 Container(
                                   height: 190.50,
                                    decoration: BoxDecoration(
                                      color: Colors.black54.withOpacity(.4),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  )

                                ])),
                      InkWell(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                15.0,
                                5.0,
                                15.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            expireOpportunityList[index]
                                                            .offerId ==
                                                        "1" ||
                                                    expireOpportunityList[index]
                                                            .offerId ==
                                                        "2" ||
                                                    expireOpportunityList[index]
                                                            .offerId ==
                                                        "3"
                                                ? expireOpportunityList[index]
                                                            .jobTitle !=
                                                        "null"
                                                    ? expireOpportunityList[
                                                            index]
                                                        .jobTitle
                                                    : ""
                                                : expireOpportunityList[index]
                                                                .offerId ==
                                                            "4" ||
                                                        expireOpportunityList[
                                                                    index]
                                                                .offerId ==
                                                            "5"
                                                    ? expireOpportunityList[
                                                            index]
                                                        .serviceTitle
                                                    : expireOpportunityList[
                                                                    index]
                                                                .jobTitle !=
                                                            "null"
                                                        ? expireOpportunityList[
                                                                index]
                                                            .jobTitle
                                                        : "",
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                fontWeight: FontWeight.w600,
                                                fontFamily: Constant.latoMedium),
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            onTap: () {
                                              activateAgain(
                                                  index,
                                                  expireOpportunityList,
                                                  "repost");
                                            },

                                            ///Users/admin/Downloads/spikeview-5.5/assets/png/edit_blue.png
                                            child: Image.asset(
                                              "assets/png/edit_blue.png",
                                              height: 20.0,
                                              width: 20.0,
                                            ),
                                          ),
                                          flex: 0,
                                        ),
                                      ],
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                        Text(
                                          expireOpportunityList[index]
                                                          .offerId ==
                                                      "1" ||
                                                  expireOpportunityList[index]
                                                          .offerId ==
                                                      "2" ||
                                                  expireOpportunityList[index]
                                                          .offerId ==
                                                      "3"
                                              ? expireOpportunityList[index]
                                                  .project
                                              : expireOpportunityList[index]
                                                              .offerId ==
                                                          "4" ||
                                                      expireOpportunityList[
                                                                  index]
                                                              .offerId ==
                                                          "5"
                                                  ? expireOpportunityList[index]
                                                      .serviceDesc
                                                  : "${expireOpportunityList[index].description}",
                                          maxLines: expireOpportunityList[index]
                                                  .isViewMore
                                              ? 100
                                              : 3,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 12.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant.latoRegular),
                                        )),
                                    showLoadMoreExpire(index)
                                        ? PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            5.0,
                                            0.0,
                                            5.0,
                                            InkWell(
                                              child: Text(
                                                expireOpportunityList[index]
                                                        .isViewMore
                                                    ? "Less"
                                                    : "More",
                                                maxLines: 3,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily:
                                                        Constant.latoRegular),
                                              ),
                                              onTap: () {
                                                expireOpportunityList[index]
                                                        .isViewMore =
                                                    !expireOpportunityList[
                                                            index]
                                                        .isViewMore;
                                                setState(() {});
                                              },
                                            ))
                                        : Container(
                                            height: 0.0,
                                          ),
                                    expireOpportunityList[index].offerId ==
                                                "6" ||
                                            expireOpportunityList[index]
                                                    .offerId ==
                                                "7" ||
                                            expireOpportunityList[index]
                                                    .offerId ==
                                                "8"
                                        ? Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  15.0,
                                                  0.0,
                                                  .0,
                                                  Text(
                                                    "Scheduled for ",
                                                    textAlign: TextAlign.left,
                                                    maxLines: null,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontWeight:
                                                        FontWeight
                                                            .w600,
                                                        fontFamily: Constant.latoRegular,
                                                        fontSize: 14.0),
                                                  )),
                                              getScheduleWidget(
                                                  expireOpportunityList[index]),
                                            ],
                                          )
                                        : Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  15.0,
                                                  0.0,
                                                  5.0,
                                                  /*new Text(
                                                      "Scheduled for: " +
                                                          getConvertedDateStamp2(
                                                              expireOpportunityList[
                                                                      index]
                                                                  .fromDate) +
                                                          " - " +
                                                          getConvertedDateStamp2(
                                                              expireOpportunityList[index]
                                                                  .toDate),
                                                      textAlign: TextAlign.left,
                                                      maxLines: null,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                          fontSize: 14.0),
                                                    ),*/
                                                  Text(
                                                    'Scheduled for ',
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontFamily: Constant
                                                            .latoRegular,
                                                        fontSize: 14,
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1),
                                                  )),

                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  5.0,
                                                  0.0,
                                                  5.0,
                                                  /*new Text(
                                                      "Scheduled for: " +
                                                          getConvertedDateStamp2(
                                                              expireOpportunityList[
                                                                      index]
                                                                  .fromDate) +
                                                          " - " +
                                                          getConvertedDateStamp2(
                                                              expireOpportunityList[index]
                                                                  .toDate),
                                                      textAlign: TextAlign.left,
                                                      maxLines: null,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                          fontSize: 14.0),
                                                    ),*/
                                                  Text(
                                                    getConvertedDateStamp2(
                                                            expireOpportunityList[
                                                                    index]
                                                                .fromDate) +
                                                        " - " +
                                                        getConvertedDateStamp2(
                                                            expireOpportunityList[
                                                                    index]
                                                                .toDate),
                                                    style: TextStyle(
                                                        fontWeight: FontWeight.w600,
                                                        fontFamily: Constant.latoRegular,
                                                        fontSize: 12,
                                                        color: ColorValues.labelColor),
                                                  )),

                                              // PaddingWrap.paddingfromLTRB(
                                              //   0.0,
                                              //   10.0,
                                              //   0.0,
                                              //   9.0,
                                              //   /*new Text(
                                              //       "Scheduled for: " +
                                              //           getConvertedDateStamp2(
                                              //               expireOpportunityList[
                                              //                       index]
                                              //                   .fromDate) +
                                              //           " - " +
                                              //           getConvertedDateStamp2(
                                              //               expireOpportunityList[index]
                                              //                   .toDate),
                                              //       textAlign: TextAlign.left,
                                              //       maxLines: null,
                                              //       style:  TextStyle(
                                              //           color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              //           fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                              //           fontSize: 14.0),
                                              //     ),*/
                                              //   AppTextStyle.getLableTextForDetail(
                                              //       'Scheduled for: ',
                                              //       getConvertedDateStamp2(
                                              //               expireOpportunityList[
                                              //                       index]
                                              //                   .fromDate) +
                                              //           " - " +
                                              //           getConvertedDateStamp2(
                                              //               expireOpportunityList[
                                              //                       index]
                                              //                   .toDate)),
                                              // ),
                                            ],
                                          ),
                                    Row(
                                      children: <Widget>[
                                        InkWell(
                                          child: PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              10.0,
                                              0.0,
                                              15.0,
                                              Text(
                                                "View more",
                                                textAlign: TextAlign.left,
                                                maxLines: null,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    fontSize: 14.0),
                                              )),
                                          onTap: () {
                                            onTapEditExpiredopportunity(
                                                index, expireOpportunityList);
                                          },
                                        ),
                                      ],
                                    ),
                                  ],
                                )),


                          index == lastIndex ? const SizedBox() :
                             Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  15.0, 0.0, 15.0, 5.0),
                              child: Container(
                                  height: 1.0, color: ColorValues.BORDER_COLOR),
                            )
                          ],
                        ),
                        onTap: () {},
                      )
                    ],
                  );
                })),

            expireOpportunityList.length > 4 ?
            Column(
              mainAxisAlignment:
            MainAxisAlignment.start,
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                      0.0, 5.0, 0.0, 5.0),
                  child: Container(
                    height: 1.0,
                    color: ColorValues.BORDER_COLOR,
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // expireOpportunityList.length > 2
                    //  ?

                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          6.0,
                          6.0,
                          6.0,
                          10.0,
                          Text(
                            "Load More",
                            style: TextStyle(
                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                fontSize: 14.0,
                                fontFamily: Constant.latoRegular),
                          )
                        // isShowAllExpireOpportunity
                        //     ? Text(
                        //         "View Less",
                        //         style: TextStyle(
                        //             color:
                        //                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                        //             fontSize: 14.0,
                        //             fontFamily:
                        //                 Constant.latoRegular),
                        //       )
                        //     : Text(
                        //         "View All " +
                        //             expireOpportunityList.length
                        //                 .toString() +
                        //             " Expired Opportunities",
                        //         style: TextStyle(
                        //             color:
                        //                 ColorValues.BLUE_COLOR_BOTTOMBAR,
                        //             fontSize: 14.0,
                        //             fontFamily:
                        //                 Constant.TYPE_CUSTOMREGULAR),
                        //       )
                      ),
                      onTap: () {
                        setState(() {
                          // if (isShowAllExpireOpportunity)
                          //   isShowAllExpireOpportunity = false;
                          // else
                          //   isShowAllExpireOpportunity = true;

                          skipExpired = skipExpired + 1;
                          strLoadMoreOpportuniesFor = 'expired';
                          getOpportuinityForLoadMore(true);
                        });
                      },
                    )
                    //     :
                    // Container(
                    //         height: 0.0,
                    //         color: Colors.black,
                    //       ),
                  ],
                ),
              ],
            ) : const SizedBox(height: 5,)

          ],
        ),
      ),
    );
  }

  Future<Null> _refreshPageHere() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
     // CustomProgressLoader.showLoader(context);
      await profileApi(false);
      await companyInfoApi(false);
      await getOpportuinity(false);
      await reviewApi();
    //  CustomProgressLoader.cancelLoader(context);
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  void showPopupMenuDropDown(BuildContext context) {
    //shubham
    final RenderBox button = context.findRenderObject() as RenderBox;
    final RenderBox overlay =
        Overlay.of(context).context.findRenderObject() as RenderBox;
    final RelativeRect position = RelativeRect.fromRect(
      Rect.fromPoints(
        button.localToGlobal(Offset.zero, ancestor: overlay),
        button.localToGlobal(button.size.bottomRight(Offset.zero),
            ancestor: overlay),
      ),
      Offset.zero & overlay.size,
    );

    showMenu<MenuItemDataPartener>(
      context: context,
      position: RelativeRect.fromLTRB(
        MediaQuery.of(context).size.width * 0.6,
        MediaQuery.of(context).size.height * 0.34,
        MediaQuery.of(context).size.width,
        0,
      ),
      elevation: 8,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
      items: dropDownMenulist.map((MenuItemDataPartener item) {
        return PopupMenuItem<MenuItemDataPartener>(
          value: item,
          child: item.unselectedAssetImagePath == "isTitle"
              ? Padding(
                padding: const EdgeInsets.only(top: 15,left: 10),
                child: Text(item.title,style:  TextStyle(
            fontWeight: FontWeight.normal,
            color: ColorValues.HEADING_COLOR_EDUCATION_1,
            fontSize: 12,
            fontFamily: Constant.latoRegular,
          ),),
              )
              : SizedBox(
                  // width: 20,
                  child: Padding(
                  padding: const EdgeInsets.all(0.0),
                  child: InkWell(
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        print("dropDownMenulist -  ${dropDownMenulist.length}");
                        //selectedMenuItem = item;
                        // Set the selected item
                        if (item.isSelected == true) {
                          item.isSelected = false;
                        } else {
                          item.isSelected = true;
                        }
                      });
                    },
                    child: Column(
                      mainAxisAlignment:
                      MainAxisAlignment.start,
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left :10),
                          child: Row(
                            children: [
                              Image.asset(
                                item.isSelected
                                    ? item.selectedAssetImagePath
                                    : item.unselectedAssetImagePath,
                                width: 24,
                                height: 24,
                              ),
                             // Optional spacing between the image and text

                              const SizedBox(width: 10,),

                              Padding(
                               padding: const EdgeInsets.all(0.0),
                                child: Text(
                                  item.title,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w400,
                                    color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 14,
                                    fontFamily: Constant.latoRegular,
                                  ),
                                ),
                              ),

                              Spacer()
                            ],
                          ),
                        ),

                        item.title == "Rejected" ? const SizedBox() :
                        Padding(
                          padding: const EdgeInsets.only(top: 12,bottom: 5),
                          child: Container(
                            height:1,
                            color: Color(0xffE8ECFF),
                          ),
                        ),
                      ],
                    ),
                  ),
                )),
        );
      }).toList(),
    ).then((MenuItemDataPartener value) {
      if (value != null) {
        setState(() {
          // selectedMenuItem = value;
        });
      }
    });
  }

  List<Widget> generateCardListItems() {
    List<Widget> items = [];
    //shubham
    // activeOpportunityList.length == 0 &&
    //     pendingOpportunityList.length == 0 &&
    //     rejectOpportunityList.length == 0 &&
    //     expireOpportunityList.length == 0

    for (var item in dropDownMenulist) {
      if (item.title == "Active" && item.isSelected == true) {
        if (activeOpportunityList.length == 0) {
          //items.add(getOportunityActive());
        } else {
          //commented for multiple selction   items.clear();
          items.add(getOportunityActive());
        }
      } else if (item.title == "Pending" && item.isSelected == true) {
        if (pendingOpportunityList.length == 0) {
          //items.add(getOportunityActive());
        } else {
          //commented for multiple selction - items.clear();
          items.add(getOportunityPending());
        }
      } else if (item.title == "Expired" && item.isSelected == true) {
        if (expireOpportunityList.length == 0) {
          //items.add(getOportunityActive());
        } else {
          //commented for multiple selction items.clear();
          items.add(getOportunityInActive());
        }
      } else if (item.title == "Rejected" && item.isSelected == true) {
        if (rejectOpportunityList.length == 0) {
          //items.add(getOportunityActive());
        } else {
          //commented for multiple selction items.clear();
          items.add(getOportunityrejected());
        }
      }
    }
    return items;
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;

  Widget getGridView() {
    return Container(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(0, 5, 0, 24.0),
        child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.white,
              // border:
              //     Border.all(color: ColorValues.BORDER_COLOR, width: 0.5)
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 0.0, left: 15),
                  child: Text(
                    "Create opportunity",
                    style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        fontFamily: Constant.latoSemibold),
                  ),
                ),
                // Padding(
                //   padding: const EdgeInsets.only(top: 5.0, left: 15),
                //   child: Text(
                //     "Let's create the service you want to offer to our community.",
                //     style: TextStyle(
                //         fontSize: 14,
                //         color: ColorValues.GREY_TEXT_COLOR,
                //         fontFamily: Constant.TYPE_CUSTOMREGULAR),
                //   ),
                // ),
                Container(
                  //margin: ,
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 8.0, left: 15, bottom: 2.0),
                    child: Text(
                      "Please select a category",
                      style: TextStyle(
                        fontSize: 16,
                        color: ColorValues.labelColor,
                        fontFamily: Constant.latoRegular,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                ),
                getGridWidget(),
              ],
            )),
      ),
    );
  }

  String getIcon(String name) {
    switch (name) {
      case 'Internship':
        return 'assets/newDesignIcon/patner/internshipOpportunity.png';
      case 'Job':
        return 'assets/newDesignIcon/patner/jobOpportunity.png';
      case 'Volunteering':
        return 'assets/newDesignIcon/patner/volunteeringOpportunity.png';
      case 'Programs':
        return 'assets/newDesignIcon/patner/programOpportunity.png';
      case 'Services':
        return 'assets/newDesignIcon/patner/serviceOpportunity.png';
      case 'Tutors':
        return 'assets/newDesignIcon/patner/tutorOpportunity.png';
      case 'Mentors':
        return 'assets/newDesignIcon/patner/mentorOpportunity.png';
      case 'Advisors':
        return 'assets/newDesignIcon/patner/AdvisorsOpportunity.png';

      default:
        return 'assets/experience/ic_academic.png';
    }
  }

  getGridWidget() {
    return Padding(
      padding:
          const EdgeInsets.only(left: 7.0, right: 7.0, bottom: 0.0, top: 0.0),
      child: Container(
        child: SingleChildScrollView(
          child: Column(
            children: opportunityTypeObjList.map((OpportunityTypeObj value) {
              return InkWell(
                child: Container(
                    height: 70,
                    margin: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                        color: Color(0xffE9ECFD),
                        borderRadius: BorderRadius.circular(10)),
                    child: Row(
                      children: [
                        // Padding(
                        //   padding: EdgeInsets.all(8.0),
                        //   child: Icon(
                        //     Icons.arrow_forward,
                        //     color: value.isSelected
                        //         ? ColorValues.BLUE_COLOR
                        //         : ColorValues.SELECTION_GRAY,
                        //   ),
                        // ),

                        Container(
                          width: value.OpportunityType == "Volunteering"
                              ? 17
                              : value.OpportunityType == "Programs" ||
                                      value.OpportunityType == "Services"
                                  ? 22
                                  : 20,
                        ),
                        Image.asset(
                          getIcon(value.OpportunityType),
                          height: value.OpportunityType == "Volunteering"
                              ? 45
                              : value.OpportunityType == "Programs" ||
                                      value.OpportunityType == "Services"
                                  ? 24
                                  : 30,
                          width: value.OpportunityType == "Volunteering"
                              ? 40
                              : value.OpportunityType == "Programs" ||
                                      value.OpportunityType == "Services"
                                  ? 24
                                  : 30,
                        ),
                        SizedBox(
                          width: value.OpportunityType == "Volunteering"
                              ? 5
                              : value.OpportunityType == "Programs" ||
                                      value.OpportunityType == "Services"
                                  ? 18
                                  : 14,
                        ),

                        Expanded(
                          child: Text(
                            value.OpportunityType,
                            style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.w500,
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily: Constant.latoRegular),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(right: 15),
                          child: Image.asset(
                            'assets/newDesignIcon/patner/leftnavigateArrow.png',
                            width: 33.0,
                            height: 33.0,
                          ),
                        ),
                      ],
                    )),
                onTap: () {
                  selectOpportunity(value.index);
                  _navigateToOpportunity(value.index);
                },
              );
            }).toList(),
          ),
        ),

        // GridView.count(
        //   crossAxisCount: 2,
        //   childAspectRatio: (153 / 50),
        //   controller: ScrollController(keepScrollOffset: false),
        //   shrinkWrap: true,
        //   scrollDirection: Axis.vertical,
        //   children: opportunityTypeObjList.map((OpportunityTypeObj value) {
        //     return InkWell(
        //       child: Container(
        //         color: value.isSelected
        //             ? ColorValues.BLUE_COLOR
        //             : ColorValues.SELECTION_GRAY,
        //         margin: EdgeInsets.all(8.0),
        //         child: Center(
        //           child: Text(
        //             value.OpportunityType,
        //             style: TextStyle(
        //               fontSize: 16.0,
        //               fontWeight: FontWeight.w600,
        //               color: value.isSelected
        //                   ? ColorValues.WHITE
        //                   : ColorValues.GREY_TEXT_COLOR,
        //             ),
        //           ),
        //         ),
        //       ),
        //       onTap: () {
        //         selectOpportunity(value.index);
        //         _navigateToOpportunity(value.index);
        //       },
        //     );
        //   }).toList(),
        // ),
      ),
    );
  }

  _navigateToOpportunitySelection() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => OpportunitySelection(companyModel)));
    if (result == "push") {
      getOpportuinity(true);
    }
  }

  void _navigateToOpportunity(int index) {
    print('inside _navigateToOpportunity index;:: $index');
    switch (opportunityTypeObjList[index].offerId) {
      case 1:
        onTapOpportunity(0, index);
        break;
      case 2:
        onTapOpportunity(0, index);
        break;
      case 3:
        onTapOpportunity(0, index);
        break;
      case 4:
        onTapOpportunity(1, index);
        break;
      case 5:
        onTapOpportunity(1, index);
        break;
      case 6:
        onTapTutorOpportunity(index);
        break;
      case 7:
        onTapMentorOpportunity(index);
        break;
      case 8:
        onTapAdvisorOpportunity(index);
        break;
    }
  }

  onTapOpportunity(indexType, int index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => Opportunity(
            companyModel.companyId,
            companyModel.offers[indexType].offerId.toString(),
            opportunityTypeObjList[index].offerId.toString(),
            opportunityTypeObjList[index].OpportunityType.toString())));
    if (result == "push") {
      getOpportuinity(true);
    }
  }

  onTapTutorOpportunity(int index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => TutorOpportunity(
            companyModel.companyId,
            opportunityTypeObjList[index].offerId.toString())));

    if (result == "push") {
      getOpportuinity(true);
    }
  }

  onTapMentorOpportunity(int index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => MentorOpportunity(
            companyModel.companyId,
            opportunityTypeObjList[index].offerId.toString())));

    if (result == "push") {
      getOpportuinity(true);
    }
  }

  onTapAdvisorOpportunity(int index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => AdvisorOpportunity(
            companyModel.companyId,
            opportunityTypeObjList[index].offerId.toString())));

    if (result == "push") {
      getOpportuinity(true);
    }
  }

  void selectOpportunity(int index) {
    for (int i = 0; i < opportunityTypeObjList.length; i++) {
      setState(() {
        if (i != index) {
          opportunityTypeObjList[i].isSelected = false;
        } else {
          opportunityTypeObjList[i].isSelected = true;
        }
      });
    }
  }

  callUpdateOldForms(
      int index, String title, List<OpportunityModel> list, type) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            UpdateOpportunity(list[index], title, type)));

    if (result == "push") {
      getOpportuinity(true);
    }
  }

  updateMentorOpportunity(int index, List<OpportunityModel> list, type) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            UpdateMentorOpportunity(list[index], type)));

    if (result == "push") {
      getOpportuinity(true);
    }
  }

  updateTutorOpportunity(int index, List<OpportunityModel> list, type) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            UpdateTutorOpportunity(list[index], type)));

    if (result == "push") {
      getOpportuinity(true);
    }
  }

  updateAdvisorOpportunity(int index, List<OpportunityModel> list, type) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            UpdateAdvisorOpportunity(list[index], type)));

    if (result == "push") {
      getOpportuinity(true);
    }
  }

  getHoursData(index, OpportunityModel opportunity) {
    return RichText(
      textAlign: TextAlign.start,
      maxLines: null,
      text: TextSpan(
        text: opportunity.scheduleModelParam[index].day +
            ": " +
            getHours(index, opportunity),

        style: TextStyle(
            color: ColorValues.labelColor,
            fontFamily: Constant.latoRegular,
            fontWeight: FontWeight.w600,
            fontSize: 13.0),
        children: <TextSpan>[
          TextSpan(
            text: opportunity.timeZone == null ||
                    opportunity.timeZone == "" ||
                    opportunity.timeZone == "null"
                ? ""
                : "(" + opportunity.timeZone + ")",
            style: TextStyle(
                color: ColorValues.labelColor,
                fontSize: 12.0,
                fontWeight: FontWeight.normal,
                fontFamily: Constant.latoRegular),
          )
        ],
      ),
    );
  }

  Widget getScheduleWidget(OpportunityModel opportunity) {
    print(
        'opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: List.generate(opportunity.scheduleModelParam.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
          child: getHoursData(index, opportunity),
        );
      }),
    );
  }

  String getHours(index, OpportunityModel opportunity) {
    String timeReturn = "";
    try {
      for (HoursData hours in opportunity.scheduleModelParam[index].hours) {
        timeReturn = Util.getConvertedTimeForScheduleDate(hours.timeFrom) +
            " - " +
            Util.getConvertedTimeForScheduleDate(
                hours.timeTo == null ? hours.timeFrom : hours.timeTo) +
            " | " +
            timeReturn;
      }

      return timeReturn.substring(0, timeReturn.lastIndexOf("|"));
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "PatnerProfileWidget", context);
      return timeReturn;
    }
  }

  String getConvertedTime1(int time) {
    if (time != null) {
      var now = DateTime.fromMillisecondsSinceEpoch(time);
      var formatter = DateFormat('hh:mm a');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      return "";
    }
  }

  String getConvertedTime(int time) {
    String timeReturn = "";
    if (time != null) {
      int startTimeHour = DateTime.fromMillisecondsSinceEpoch(time).hour;
      int startTimeMinute = DateTime.fromMillisecondsSinceEpoch(time).minute;

      if (startTimeHour > 12) {
        String startTimeH = (startTimeHour - 12).toString();

        startTimeH = startTimeH.toString().length == 2
            ? startTimeH.toString()
            : "0" + startTimeH.toString();
        String startTimeM = startTimeMinute.toString().length == 2
            ? startTimeMinute.toString()
            : "0" + startTimeMinute.toString();

        return timeReturn = startTimeH.toString() + ":" + startTimeM + " pm";
      } else {
        String startTimeH = startTimeHour.toString().length == 2
            ? startTimeHour.toString()
            : "0" + startTimeHour.toString();
        String startTimeM = startTimeMinute.toString().length == 2
            ? startTimeMinute.toString()
            : "0" + startTimeMinute.toString();

        return timeReturn =
            startTimeH.toString() + ":" + startTimeM.toString() + " am";
      }
    } else {
      return "";
    }
  }

  void initOpporunityTypeSelected(CompanyProfileModel companyModel) {
    opportunityTypeObjList.clear();
    for (int i = 0; i < companyModel.offers.length; i++) {
      opportunityTypeObjList.add(new OpportunityTypeObj(false,
          companyModel.offers[i].name, i, companyModel.offers[i].offerId));

      print('Apurva Oppo name:: ${companyModel.offers[i].name}');
    }
  }

  showRejectionAlert() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 292.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 245.0,

                                            ///145
                                            padding: EdgeInsets.all(15.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Container(
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      "Account not approved",
                                                      textAlign: TextAlign.left,
                                                      //maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 10.0,
                                                              bottom: 20.0),
                                                      child: Text(
                                                        "Please see comments below, make the updates and resubmit for approval.",
                                                        textAlign:
                                                            TextAlign.left,
                                                        maxLines: 5,
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .GREY__COLOR,
                                                            height: 1.2,
                                                            fontSize: 12.0,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 0.0,
                                                              bottom: 7.0),
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                                context)
                                                            .size
                                                            .width,
                                                        height: 105,
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.white,
                                                          border: Border.all(
                                                              color: ColorValues
                                                                  .BORDER_COLOR,
                                                              width: 1.0),
                                                        ),
                                                        padding:
                                                            const EdgeInsets
                                                                    .symmetric(
                                                                horizontal:
                                                                    13.0,
                                                                vertical: 15.0),
                                                        child:
                                                            SingleChildScrollView(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        top:
                                                                            0.0,
                                                                        bottom:
                                                                            15.0),
                                                                child: Text(
                                                                  "Reason :",
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: TextStyle(
                                                                      color: ColorValues
                                                                          .RADIO_BLACK,
                                                                      fontSize:
                                                                          16.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      fontFamily:
                                                                          Constant
                                                                              .TYPE_CUSTOMREGULAR),
                                                                ),
                                                              ),
                                                              Text(
                                                                rejectionReason
                                                                            .toString() !=
                                                                        'null'
                                                                    ? "$rejectionReason"
                                                                    : "",
                                                                //'Please check the reason and update your profile details and we’ll send back to admin for their approval. Please check the reason and update your profile details and we’ll send back to admin for their approval. Please check the reason and update your profile details and we’ll send back to admin for their approval. Please check the reason and update your profile details and we’ll send back to admin for their approval. Please check the reason and update your profile details and we’ll send back to admin for their approval. Please check the reason and update your profile details and we’ll send back to admin for their approval. Please check the reason and update your profile details and we’ll send back to admin for their approval.Please check the reason and update your profile details and we’ll send back to admin for their approval.Please check the reason and update your profile details and we’ll send back to admin for their approval. ',
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .RADIO_BLACK,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 0.0,
                                                              bottom: 8.0),
                                                      child: RichText(
                                                        maxLines: 2,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.start,
                                                        text: TextSpan(
                                                          text:
                                                              'For any further questions email ',
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .GREY__COLOR,
                                                              fontSize: 12.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                          children: <TextSpan>[
                                                            TextSpan(
                                                              text:
                                                                  'team@spikeview.com',
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .GREY__COLOR,
                                                                  fontSize:
                                                                      12.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ]),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Close",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color:
                                                      ColorValues.GREY__COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              //Navigator.of(context, rootNavigator: true).pop('dialog');
                                              prefs.setBool(
                                                  UserPreference
                                                      .IS_SHOW_REJECTION_POPUP,
                                                  false);
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Edit",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              prefs.setBool(
                                                  UserPreference
                                                      .IS_SHOW_REJECTION_POPUP,
                                                  false);
                                              Navigator.pop(context);
                                              goToProfileUpdate();
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future<String> getVideoThumbnail(context, imagePath) async {
    return await UploadMedia(context).getVideoThumbnailFromUrl(imagePath);
  }

  Future<void> goToProfileUpdate() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            Company_Edit_Widget(userIdPref, pageName: "rejectionReason")));
  }
}
