import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/home/group_list_for_post.dart';
import 'package:spike_view_project/home_page/blocs/home_bloc.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/patnerFlow/opportunity/group_list_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:video_compress/video_compress.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/AddTagGroupWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:path/path.dart' as path;
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

// Create a Form Widget
class AddPostOld extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  String groupId, link;
  GroupDetailModel groupDetailModel;

  AddPostOld(this.profileInfoModal, this.groupId,
      {this.groupDetailModel, this.link});

  @override
  AddPostOldState createState() {
    return  AddPostOldState();
  }
}

class AddPostOldState extends State<AddPostOld> {
  SharedPreferences prefs;
  String userIdPref,
      roleId,
      token,
      userProfilePath,
      companyImagePath,
      companyName;
  final _formKey = GlobalKey<FormState>();
  String isType = "Community";
  List<AssestForPost> assestList =  List();
  VoidCallback listener;
  File videoPath;
  String strVideo;
  TextEditingController edtController;

  String sasToken, containerName, strPrefixPathforFeed;
  String strFirstName, strLastName, strEmail;
  List<dynamic> images;

  Future<File> videoFile;
  List<String> azureImageUploadList =  List();
  VideoPlayerController _controller;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<TagsPost> selectedUerTagLIst =  List();

  List<TagModel> selectedUerTagLIst1 =  List();
  List<TagsPost> selectedtScopeList =  List();
  File imagePath;
  List<String> groupidList =  List();
  bool isGroupPost = false;

  Future apiCallingUpdateDialogStatus() async {
    try {
      Response response;
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "featureKey": ["communityPost"],
        "display": false
      };

      response = await  ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_DIALOG_STATUS, map);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setBool(UserPreference.IS_COMMUNITY_POPUP, false);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    companyImagePath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    companyName = prefs.getString(UserPreference.COMPANY_NAME_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);

    if (widget.groupId != "") {
      setState(() {
        isType = "Group";
        isGroupPost = true;
      });
    }


    setState(() {
      userProfilePath;
    });

    strPrefixPathforFeed = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
    await callApiForSaas();
    if (widget.link != null && widget.link != "") {

      edtController.selection =
          TextSelection
              .fromPosition(
              TextPosition(
                  offset:
                  0));
    }
    //anaylytics.setCurrentSreen(ScreenNameConstant.add_post);
  }

  Future<Null> _cropImage(File imageFile) async {
    imagePath = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      ratioX: 1.6,
      ratioY: 0.9,
    );
  }

  @override
  void initState() {
    edtController =  TextEditingController(text: '');
    if (widget.link != null && widget.link != "") {
      edtController.text = widget.link;
      edtController.selection =
          TextSelection
              .fromPosition(
              TextPosition(
                  offset:
                  0));
    }
    getSharedPreferences();

    // TODO: implement initState
    listener = () {
      setState(() {});
    };

    super.initState();
  }

  @override
  void deactivate() {
    if (_controller != null) {
      _controller.setVolume(0.0);
      _controller.removeListener(listener);
    }
    super.deactivate();
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await  ApiCalling().apiCall2(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  //static final _flutterVideoCompress = FlutterVideoCompress();

  Future<String> compressonVideoFile(File file, String targetPath) async {
    File uploadingFile;

    final info = await VideoCompress.compressVideo(
      file.path,
      quality: VideoQuality.MediumQuality,
      deleteOrigin: false,
    );

    debugPrint(info.toJson().toString());
//uploadingFile =  File(info.path);

    return info.path;
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath, isImage) async {

    try {
      if (sasToken != "" && containerName != "") {
        final String result = await platform.invokeMethod('getBatteryLevel', {
          "sasToken": sasToken,
          "imagePath": imagePath,
          "uploadPath": Constant.IMAGE_PATH + prefixPath
        });

        return result;
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  //-------------------------------------Api Calling for feed--------------------------

  Future apiCalling() async {
    try {
      if (assestList.length > 0) {
        for (int i = 0; i < assestList.length; i++) {
          String azureUploadPath = await uploadImgOnAzure(
              assestList[i].imagePath, strPrefixPathforFeed, true);
          azureImageUploadList.add(strPrefixPathforFeed + azureUploadPath);
        }

        String s = "ss";
      } else if (videoPath != null) {
        strVideo = await uploadImgOnAzure(
            videoPath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            strPrefixPathforFeed,
            false);

        String s = "";
      }
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map;

        bool isCommunityPost = false;
        if (isType == "Community") {
          isCommunityPost = true;
        }

        if (edtController.text != "" ||
            assestList.length > 0 ||
            videoPath != null) {
          if (assestList.length > 0) {
            map = {
              "post": {
                "text": edtController.text,
                "images": azureImageUploadList.map((item) => item).toList(),
                "media": ""
              },
              "postedBy": int.parse(userIdPref),
              "dateTime":  DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": widget.profileInfoModal.isActive,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
              "isCommunityPost": isCommunityPost,
              "groupIds": groupidList.map((item) => int.parse(item)).toList(),
            };
          } else if (videoPath != null) {
            map = {
              "post": {
                "text": edtController.text,
                "images": [],
                "media": strPrefixPathforFeed + strVideo
              },
              "postedBy": int.parse(userIdPref),
              "dateTime":  DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": false,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
              "isCommunityPost": isCommunityPost,
              "groupIds": groupidList.map((item) => int.parse(item)).toList(),
            };
          } else {
            map = {
              "post": {"text": edtController.text, "images": [], "media": ""},
              "postedBy": int.parse(userIdPref),
              "dateTime":  DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": false,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
              "isCommunityPost": isCommunityPost,
              "groupIds": groupidList.map((item) => int.parse(item)).toList(),
            };
          }
          Response response = await  ApiCalling()
              .apiCallPostWithMapData(context, Constant.ENDPOINT_ADD_FEED, map);
          if (widget.link != null && widget.link != null){
            if (widget.groupId == null || widget.groupId == "") {

            }else{
              CustomProgressLoader.cancelLoader(context);
            }
          }else {
            CustomProgressLoader.cancelLoader(context);
          }
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];

              if (status == "Success") {
                //ToastWrap.showToast(msg);
                if (widget.link != null && widget.link != null) {
                  if (roleId == "1") {
                    // For Studenet
                    DbHelper().deleteTable();
                    homeBloc.fetcPost(userIdPref, roleId, context);
                    if (widget.groupId == null || widget.groupId == "") {
                      Timer(const Duration(milliseconds: 2000), () async {
                        CustomProgressLoader.cancelLoader(context);
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) =>  DashBoardWidget(
                                    prefs.getString(
                                        UserPreference.IS_PARENT_ROLE),
                                    prefs.getString(
                                        UserPreference.IS_PARTNER_ROLE),
                                    prefs
                                        .getString(UserPreference.IS_USER_ROLE),
                                    currentPage: widget.groupId == null ||
                                        widget.groupId == ""
                                        ? Constant.FEED_TYPE
                                        : Constant.GROUP_TYPE)));
                      });
                    } else {
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) =>  DashBoardWidget(
                                  prefs
                                      .getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(
                                      UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: widget.groupId == null ||
                                      widget.groupId == ""
                                      ? Constant.FEED_TYPE
                                      : Constant.GROUP_TYPE)));
                    }
                  } else if (roleId == "2") {
                    DbHelper().deleteTable();
                    homeBloc.fetcPost(userIdPref, roleId, context);
                    if (widget.groupId == null || widget.groupId == "") {
                      Timer(const Duration(milliseconds: 2000), () async {
                        CustomProgressLoader.cancelLoader(context);
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) =>  DashBoardWidgetParent(
                                    prefs.getString(
                                        UserPreference.IS_PARENT_ROLE),
                                    prefs.getString(
                                        UserPreference.IS_PARTNER_ROLE),
                                    prefs
                                        .getString(UserPreference.IS_USER_ROLE),
                                    currentPage: widget.groupId == null ||
                                        widget.groupId == ""
                                        ? Constant.FEED_TYPE
                                        : Constant.GROUP_TYPE)));
                      });
                    } else {
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) =>  DashBoardWidgetParent(
                                  prefs
                                      .getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(
                                      UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: widget.groupId == null ||
                                      widget.groupId == ""
                                      ? Constant.FEED_TYPE
                                      : Constant.GROUP_TYPE)));
                    }

                    // For Parent
                  } else if (roleId == "4") {
                    DbHelper().deleteTable();
                    homeBloc.fetcPost(userIdPref, roleId, context);
                    if (widget.groupId == null || widget.groupId == "") {
                      Timer(const Duration(milliseconds: 2000), () async {
                        CustomProgressLoader.cancelLoader(context);
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) =>
                                    DashBoardWidgetPartner(
                                        prefs.getString(
                                            UserPreference.IS_PARENT_ROLE),
                                        prefs.getString(
                                            UserPreference.IS_PARTNER_ROLE),
                                        prefs.getString(
                                            UserPreference.IS_USER_ROLE),
                                        currentPage: widget.groupId == null ||
                                            widget.groupId == ""
                                            ? Constant.FEED_TYPE
                                            : Constant.GROUP_TYPE)));
                      });
                    } else {
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            //   builder: (context) =>  DashBoardWidget()));
                              builder: (context) =>  DashBoardWidgetPartner(
                                  prefs
                                      .getString(UserPreference.IS_PARENT_ROLE),
                                  prefs.getString(
                                      UserPreference.IS_PARTNER_ROLE),
                                  prefs.getString(UserPreference.IS_USER_ROLE),
                                  currentPage: widget.groupId == null ||
                                      widget.groupId == ""
                                      ? Constant.FEED_TYPE
                                      : Constant.GROUP_TYPE)));
                    }

                    // For Partner
                  }
                } else {
                  RewardStatusResponse apiResponse =
                  RewardStatusResponse.fromJson(response.data);
                  Navigator.pop(context, apiResponse);
                  // Util.showRewardPointPush(apiResponse.rewardStatus, context);
                  //Navigator.pop(context, "push");
                }
              }
            }
          }
        } else {
          ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  void conformationDialogForCommunityPost() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "spikeview community post has to be reviewed by the community admin. It will be visible once approved.",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                        Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.GREY_TEXT_COLOR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Post",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              CustomProgressLoader.showLoader(
                                                  context);
                                              apiCalling();
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  @override
  void dispose() {
    super.dispose();
    if (_controller != null) _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    void onTapTagBtn() async {
      if (widget.groupId == "") {
        List<TagModel> result = await Navigator.of(context).push(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    AddTagWidget("Tag connections", selectedUerTagLIst1)));

        if (result != null) {
          selectedUerTagLIst1.clear();
          selectedUerTagLIst.clear();
          selectedUerTagLIst1 = result;
        }

        // Create List for API Calling

        setState(() {
          for (int i = 0; i < selectedUerTagLIst1.length; i++) {
            selectedUerTagLIst.add(new TagsPost(
                selectedUerTagLIst1[i].userId, selectedUerTagLIst1[i].roleId));
          }
        });
      } else {
        List<TagModel> result = await Navigator.of(context).push(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    AddTagGroupWidget("Tagging", widget.groupId, selectedUerTagLIst1)));

        if (result != null) {
          selectedUerTagLIst1.clear();
          selectedUerTagLIst.clear();
          selectedUerTagLIst1 = result;
        }

        // Create List for API Calling

        setState(() {
          for (int i = 0; i < selectedUerTagLIst1.length; i++) {
            selectedUerTagLIst.add(new TagsPost(
                selectedUerTagLIst1[i].userId, selectedUerTagLIst1[i].roleId));
          }
        });
      }
    }

    void onTapTagSelectedConnection() async {
      List<TagsPost> result = await Navigator.of(context).push(
          MaterialPageRoute(
              builder: (BuildContext context) =>  AddMyConnectionSharePost(
                  "Select Connections", selectedtScopeList)));

      if (result != null) {
        if (result != null && result.length > 0) {
          isType = "SelectedConnections";

          selectedtScopeList.clear();
          groupidList.clear();
          selectedtScopeList = result;
          setState(() {
            isType;
          });
        }
      }
    }

    onTapPostButton() async {
      if (assestList.length > 0 ||
          edtController.text.trim() != "" ||
          videoPath != null) {
        if (isType == "Community" && (!isGroupPost)) {
          CustomProgressLoader.cancelLoader(context);
          conformationDialogForCommunityPost();
        } else {
          apiCalling();
        }
      } else {
        ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
      }
    }


    getVideo() async {
      try {
        String getFileExtension(File file) {
          return path.extension(file.path);
        }

        await ImagePicker.pickVideo(source: ImageSource.gallery)
            .then((File file) {
          if (file != null &&
              getFileExtension(file) != null &&
              getFileExtension(file).length > 0) {
            setState(() {
              _controller = VideoPlayerController.file(file)
                ..addListener(listener)
                ..setVolume(1.0)
                ..initialize()
                ..setLooping(false);
              videoPath = file;
            });
          } else if (file != null) {
            ToastWrap.showToast(
                MessageConstant.VIDEO_SOURCE_INCORRECT_ERROR, context);
          } else {
            setState(() {
              _controller = null;
              videoPath = null;
            });
          }
        });
      } catch (e) {
      }
    }

    getInitVideo() async {
      try {
        if (_controller == null && videoPath == null) {
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getVideo();
          } else {
            checkPermissionPhoto(context);
          }
        } else if (_controller != null && (videoPath != null)) {
          // If there was a controller, we need to dispose of the old one first
          final oldController = _controller;

          // Registering a callback for the end of next frame
          // to dispose of an old controller
          // (which won't be used anymore after calling setState)
          WidgetsBinding.instance.addPostFrameCallback((_) async {
            await oldController.dispose();

            // Initing  controller
            var status = await Permission.photos.status;
            if (status.isGranted) {
              getVideo();
            } else {
              checkPermissionPhoto(context);
            }
          });

          // Making sure that controller is not used by setting it to null
          setState(() {
            _controller = null;
            videoPath = null;
          });
        }
      } catch (e) {
      }
    }

    getImage(type) async {
      if (assestList.length < 8) {
        int numberOfItems = 8 - assestList.length;
        // if (numberOfItems == 1) {

        if (type == ImageSource.gallery) {
          imagePath = await UploadMedia(context).pickImageFromGallery();
         // imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);

          if (imagePath != null) {
            String strPath = imagePath.toString().substring(
                imagePath.toString().lastIndexOf("/") + 1,
                imagePath.toString().length);
            if (strPath.toString().contains(".") &&
                (!strPath.toString().contains(".gif"))) {
              // await _cropImage(imagePath);
              if (imagePath != null) {
                assestList.add(new AssestForPost(
                    imagePath
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    "image",
                    "",
                    false));
                setState(() {
                  assestList;
                });
                // }
              }
            } else {
              ToastWrap.showToast(
                  MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
            }
          }
        } else if (type == ImageSource.camera) {
          imagePath = await ImagePicker.pickImage(source: ImageSource.camera);

          if (imagePath != null) {
            String strPath = imagePath.toString().substring(
                imagePath.toString().lastIndexOf("/") + 1,
                imagePath.toString().length);
            if (strPath.toString().contains(".") &&
                (!strPath.toString().contains(".gif"))) {
              //  await _cropImage(imagePath);
              if (imagePath != null) {
                assestList.add(new AssestForPost(
                    imagePath
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    "image",
                    "",
                    false));
                setState(() {
                  FocusScope.of(context).requestFocus(FocusNode());
                  assestList;
                });
                // }
              }
            } else {
              ToastWrap.showToast(
                  MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.MAXIMUM_8_IMAGE_UPLOADED_VAL, context);
      }
    }

    onClickGroup() async {
      List<String> groupData = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) =>
                GroupListForPost(groupidList, widget.groupId)),
      );
      if (groupData != null && groupData.length > 0) {
        selectedtScopeList.clear();
        groupidList.clear();
        groupidList.addAll(groupData);
        isType = "Group";
        setState(() {
          isType;
        });
      }
    }

    void _settingModalBottomSheet(context) {

      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Container(
                            child: Column(children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  20.0,
                                  13.0,
                                  0.0,
                                  Container(
                                    padding: EdgeInsets.all(10.0),
                                    width: double.infinity,
                                    color: Colors.white,
                                    child:  Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              13.0,
                                              0.0,
                                              13.0,
                                              15.0,
                                              TextViewWrap.textView(
                                                  "Who can see your Post?",
                                                  TextAlign.center,
                                                  ColorValues.HEADING_COLOR_EDUCATION,
                                                  16.0,
                                                  FontWeight.normal)),
                                          /*  PaddingWrap.paddingfromLTRB(
                                                        13.0,
                                                        0.0,
                                                        13.0,
                                                        20.0,
                                                         Text(
                                                          "Lorem Ipsum is simply dummy text of the printing and typesetting simply dummy text of. ",
                                                          style:  TextStyle(
                                                              color:  ColorValues.GREY__COLOR,
                                                              fontSize: 12.0,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                        )),*/
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                      13.0,
                                                      10.0,
                                                      19.0,
                                                      10.0,
                                                      Image
                                                          .asset(
                                                        "assets/profile/post/community.png",
                                                        width:
                                                        25.0,
                                                        height:
                                                        25.0,
                                                        color: isType ==
                                                            "Community"
                                                            ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                            :  ColorValues.HEADING_COLOR_EDUCATION,
                                                      )),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          8.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Community",
                                                              TextAlign
                                                                  .center,
                                                              isType ==
                                                                  "Community"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                  :  ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          13.0,
                                                          Text(
                                                              "Visible to all spikeview community members",
                                                              textAlign:
                                                              TextAlign
                                                                  .start,
                                                              style:  TextStyle(
                                                                  color:  ColorValues.GREY__COLOR,
                                                                  fontSize:
                                                                  14.0,
                                                                  fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR))
                                                        /*  TextViewWrap.textViewMultiLine(
                                                                        "Visible to all spikeview community members",
                                                                        TextAlign
                                                                            .center,
                                                                         ColorValues.GREY__COLOR,
                                                                        14.0,
                                                                        FontWeight
                                                                            .normal,2)*/
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              selectedtScopeList
                                                  .clear();
                                              groupidList.clear();
                                              isType = "Community";
                                              setState(() {
                                                isType;
                                              });
                                            },
                                          ),
                                          CustomViews
                                              .getSepratorLine(),
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap.paddingfromLTRB(
                                                      13.0,
                                                      10.0,
                                                      19.0,
                                                      10.0,
                                                      Image.asset(
                                                          "assets/profile/post/group_data.png",
                                                          width: 25.0,
                                                          height:
                                                          25.0,
                                                          color: isType ==
                                                              "Group"
                                                              ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                              :  ColorValues.HEADING_COLOR_EDUCATION)),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          8.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Group",
                                                              TextAlign
                                                                  .center,
                                                              isType ==
                                                                  "Group"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                  :  ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          4.0,
                                                          13.0,
                                                          TextViewWrap.textViewMultiLine(
                                                              "Visible to all members in selected groups",
                                                              TextAlign
                                                                  .start,
                                                              ColorValues.GREY__COLOR,
                                                              14.0,
                                                              FontWeight
                                                                  .normal,
                                                              2)),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              onClickGroup();
                                            },
                                          ),
                                          CustomViews
                                              .getSepratorLine(),
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap.paddingfromLTRB(
                                                      13.0,
                                                      10.0,
                                                      19.0,
                                                      10.0,
                                                      Image.asset(
                                                          "assets/profile/post/connection.png",
                                                          width: 25.0,
                                                          height:
                                                          25.0,
                                                          color: isType ==
                                                              "AllConnections"
                                                              ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                              :  ColorValues.HEADING_COLOR_EDUCATION)),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          10.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Connections",
                                                              TextAlign
                                                                  .center,
                                                              isType ==
                                                                  "AllConnections"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                  :  ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          13.0,
                                                          TextViewWrap.textView(
                                                              "Your connections on spikeview",
                                                              TextAlign
                                                                  .center,
                                                              ColorValues.GREY__COLOR,
                                                              14.0,
                                                              FontWeight
                                                                  .normal)),
                                                    ],
                                                  ),
                                                  flex: 0,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              selectedtScopeList
                                                  .clear();
                                              groupidList.clear();
                                              isType =
                                              "AllConnections";
                                              setState(() {
                                                isType;
                                              });
                                            },
                                          ),
                                          CustomViews
                                              .getSepratorLine(),
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                      13.0,
                                                      10.0,
                                                      19.0,
                                                      10.0,
                                                      Image
                                                          .asset(
                                                        isType ==
                                                            "SelectedConnections"
                                                            ? "assets/profile/post/selected_blue.png"
                                                            : "assets/profile/post/selected_connection.png",
                                                        width:
                                                        25.0,
                                                        height:
                                                        25.0,
                                                      )),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          10.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Selected Connections",
                                                              TextAlign
                                                                  .center,
                                                              isType ==
                                                                  "SelectedConnections"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                  : null,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          13.0,
                                                          TextViewWrap.textView(
                                                              "Only visible to some connections",
                                                              TextAlign
                                                                  .center,
                                                              ColorValues.GREY__COLOR,
                                                              14.0,
                                                              FontWeight
                                                                  .normal)),
                                                    ],
                                                  ),
                                                  flex: 0,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              onTapTagSelectedConnection();
                                            },
                                          ),
                                          CustomViews
                                              .getSepratorLine(),
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap.paddingfromLTRB(
                                                      13.0,
                                                      15.0,
                                                      19.0,
                                                      10.0,
                                                      Image.asset(
                                                          "assets/profile/post/private_new.png",
                                                          width: 20.0,
                                                          height:
                                                          20.0,
                                                          color: isType ==
                                                              "Private"
                                                              ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                              :  ColorValues.HEADING_COLOR_EDUCATION)),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          10.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Make it Private",
                                                              TextAlign
                                                                  .center,
                                                              isType ==
                                                                  "Private"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                  :  ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          13.0,
                                                          TextViewWrap.textView(
                                                              "Only visible to me",
                                                              TextAlign
                                                                  .center,
                                                              ColorValues.GREY__COLOR,
                                                              14.0,
                                                              FontWeight
                                                                  .normal)),
                                                    ],
                                                  ),
                                                  flex: 0,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              selectedtScopeList
                                                  .clear();
                                              groupidList.clear();
                                              selectedUerTagLIst1
                                                  .clear();
                                              selectedUerTagLIst
                                                  .clear();
                                              isType = "Private";
                                              setState(() {
                                                isType;
                                                selectedUerTagLIst1;
                                                selectedUerTagLIst;
                                              });
                                            },
                                          ),
                                        ]),
                                  )),
                              PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  10.0,
                                  13.0,
                                  10.0,
                                  Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                          Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.customRegular),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      )))

                            ],)
                            ,
                          ),
                        ],
                      )))));



      /* showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child:  Container(
                                  height: 500.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        13.0,
                                                        0.0,
                                                        13.0,
                                                        15.0,
                                                        TextViewWrap.textView(
                                                            "Who can see your Post?",
                                                            TextAlign.center,
                                                             ColorValues.HEADING_COLOR_EDUCATION,
                                                            16.0,
                                                            FontWeight.normal)),
                                                    *//*  PaddingWrap.paddingfromLTRB(
                                                        13.0,
                                                        0.0,
                                                        13.0,
                                                        20.0,
                                                         Text(
                                                          "Lorem Ipsum is simply dummy text of the printing and typesetting simply dummy text of. ",
                                                          style:  TextStyle(
                                                              color:  ColorValues.GREY__COLOR,
                                                              fontSize: 12.0,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                        )),*//*
                                                     InkWell(
                                                      child:  Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child: PaddingWrap
                                                                .paddingfromLTRB(
                                                                    13.0,
                                                                    10.0,
                                                                    19.0,
                                                                    10.0,
                                                                     Image
                                                                        .asset(
                                                                      "assets/profile/post/community.png",
                                                                      width:
                                                                          25.0,
                                                                      height:
                                                                          25.0,
                                                                      color: isType ==
                                                                              "Community"
                                                                          ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                          :  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    )),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: [
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    8.0,
                                                                    0.0,
                                                                    3.0,
                                                                    TextViewWrap.textView(
                                                                        "Community",
                                                                        TextAlign
                                                                            .center,
                                                                        isType ==
                                                                                "Community"
                                                                            ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                            :  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        16.0,
                                                                        FontWeight
                                                                            .normal)),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    13.0,
                                                                     Text(
                                                                        "Visible to all spikeview community members",
                                                                        textAlign:
                                                                            TextAlign
                                                                                .start,
                                                                        style:  TextStyle(
                                                                            color:  ColorValues.GREY__COLOR,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontFamily:
                                                                                Constant.TYPE_CUSTOMREGULAR))
                                                                    *//*  TextViewWrap.textViewMultiLine(
                                                                        "Visible to all spikeview community members",
                                                                        TextAlign
                                                                            .center,
                                                                         ColorValues.GREY__COLOR,
                                                                        14.0,
                                                                        FontWeight
                                                                            .normal,2)*//*
                                                                    ),
                                                              ],
                                                            ),
                                                            flex: 1,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        selectedtScopeList
                                                            .clear();
                                                        groupidList.clear();
                                                        isType = "Community";
                                                        setState(() {
                                                          isType;
                                                        });
                                                      },
                                                    ),
                                                    CustomViews
                                                        .getSepratorLine(),
                                                     InkWell(
                                                      child:  Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child: PaddingWrap.paddingfromLTRB(
                                                                13.0,
                                                                10.0,
                                                                19.0,
                                                                10.0,
                                                                 Image.asset(
                                                                    "assets/profile/post/group_data.png",
                                                                    width: 25.0,
                                                                    height:
                                                                        25.0,
                                                                    color: isType ==
                                                                            "Group"
                                                                        ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                        :  ColorValues.HEADING_COLOR_EDUCATION)),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: [
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    8.0,
                                                                    0.0,
                                                                    3.0,
                                                                    TextViewWrap.textView(
                                                                        "Group",
                                                                        TextAlign
                                                                            .center,
                                                                        isType ==
                                                                                "Group"
                                                                            ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                            :  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        16.0,
                                                                        FontWeight
                                                                            .normal)),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    0.0,
                                                                    4.0,
                                                                    13.0,
                                                                    TextViewWrap.textViewMultiLine(
                                                                        "Visible to all members in selected groups",
                                                                        TextAlign
                                                                            .start,
                                                                         ColorValues.GREY__COLOR,
                                                                        14.0,
                                                                        FontWeight
                                                                            .normal,
                                                                        2)),
                                                              ],
                                                            ),
                                                            flex: 1,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        onClickGroup();
                                                      },
                                                    ),
                                                    CustomViews
                                                        .getSepratorLine(),
                                                     InkWell(
                                                      child:  Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child: PaddingWrap.paddingfromLTRB(
                                                                13.0,
                                                                10.0,
                                                                19.0,
                                                                10.0,
                                                                 Image.asset(
                                                                    "assets/profile/post/connection.png",
                                                                    width: 25.0,
                                                                    height:
                                                                        25.0,
                                                                    color: isType ==
                                                                            "AllConnections"
                                                                        ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                        :  ColorValues.HEADING_COLOR_EDUCATION)),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: [
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    10.0,
                                                                    0.0,
                                                                    3.0,
                                                                    TextViewWrap.textView(
                                                                        "Connections",
                                                                        TextAlign
                                                                            .center,
                                                                        isType ==
                                                                                "AllConnections"
                                                                            ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                            :  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        16.0,
                                                                        FontWeight
                                                                            .normal)),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    13.0,
                                                                    TextViewWrap.textView(
                                                                        "Your connections on spikeview",
                                                                        TextAlign
                                                                            .center,
                                                                         ColorValues.GREY__COLOR,
                                                                        14.0,
                                                                        FontWeight
                                                                            .normal)),
                                                              ],
                                                            ),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        selectedtScopeList
                                                            .clear();
                                                        groupidList.clear();
                                                        isType =
                                                            "AllConnections";
                                                        setState(() {
                                                          isType;
                                                        });
                                                      },
                                                    ),
                                                    CustomViews
                                                        .getSepratorLine(),
                                                     InkWell(
                                                      child:  Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child: PaddingWrap
                                                                .paddingfromLTRB(
                                                                    13.0,
                                                                    10.0,
                                                                    19.0,
                                                                    10.0,
                                                                     Image
                                                                        .asset(
                                                                      isType ==
                                                                              "SelectedConnections"
                                                                          ? "assets/profile/post/selected_blue.png"
                                                                          : "assets/profile/post/selected_connection.png",
                                                                      width:
                                                                          25.0,
                                                                      height:
                                                                          25.0,
                                                                    )),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: [
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    10.0,
                                                                    0.0,
                                                                    3.0,
                                                                    TextViewWrap.textView(
                                                                        "Selected Connections",
                                                                        TextAlign
                                                                            .center,
                                                                        isType ==
                                                                                "SelectedConnections"
                                                                            ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                            : null,
                                                                        16.0,
                                                                        FontWeight
                                                                            .normal)),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    13.0,
                                                                    TextViewWrap.textView(
                                                                        "Only visible to some connections",
                                                                        TextAlign
                                                                            .center,
                                                                         ColorValues.GREY__COLOR,
                                                                        14.0,
                                                                        FontWeight
                                                                            .normal)),
                                                              ],
                                                            ),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        onTapTagSelectedConnection();
                                                      },
                                                    ),
                                                    CustomViews
                                                        .getSepratorLine(),
                                                     InkWell(
                                                      child:  Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child: PaddingWrap.paddingfromLTRB(
                                                                13.0,
                                                                15.0,
                                                                19.0,
                                                                10.0,
                                                                 Image.asset(
                                                                    "assets/profile/post/private_new.png",
                                                                    width: 20.0,
                                                                    height:
                                                                        20.0,
                                                                    color: isType ==
                                                                            "Private"
                                                                        ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                        :  ColorValues.HEADING_COLOR_EDUCATION)),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: [
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    10.0,
                                                                    0.0,
                                                                    3.0,
                                                                    TextViewWrap.textView(
                                                                        "Make it Private",
                                                                        TextAlign
                                                                            .center,
                                                                        isType ==
                                                                                "Private"
                                                                            ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                                                            :  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        16.0,
                                                                        FontWeight
                                                                            .normal)),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    13.0,
                                                                    TextViewWrap.textView(
                                                                        "Only visible to me",
                                                                        TextAlign
                                                                            .center,
                                                                         ColorValues.GREY__COLOR,
                                                                        14.0,
                                                                        FontWeight
                                                                            .normal)),
                                                              ],
                                                            ),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        selectedtScopeList
                                                            .clear();
                                                        groupidList.clear();
                                                        selectedUerTagLIst1
                                                            .clear();
                                                        selectedUerTagLIst
                                                            .clear();
                                                        isType = "Private";
                                                        setState(() {
                                                          isType;
                                                          selectedUerTagLIst1;
                                                          selectedUerTagLIst;
                                                        });
                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:
                                                        Constant.customRegular),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));*/
    }

    _buildChoiceList() {
      List<Widget> choices = List();
      selectedUerTagLIst1.forEach((item) {
        if (item.isSelected) {
          choices.add(PaddingWrap.paddingAll(
              5.0,
              Container(
                decoration:  BoxDecoration(
                    border:  Border.all(
                        width: 1.0, color:  ColorValues.DARK_GREY)),
                padding: const EdgeInsets.all(3.0),
                child: Wrap(
                  children: <Widget>[
                    Text(
                      item.firstName + " " + item.lastName,
                      overflow: TextOverflow.ellipsis,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 14.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          5.0,
                          3.0,
                          0.0,
                          0.0,
                          Icon(
                            Icons.clear,
                            color: Colors.black,
                            size: 17.0,
                          )),
                      onTap: () {
                        setState(() {
                          selectedUerTagLIst1.remove(item);
                          selectedUerTagLIst.remove(item);
                        });
                      },
                    )
                  ],
                ), /*  Row(
              children: <Widget>[
                 Text(
                    item.firstName,
                    overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),

              */ /*   Expanded(
                  child:  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                         Icon(
                          Icons.cancel,
                          color: Colors.transparent,
                          size: 17.0,
                        )),
                    onTap: () {
                      setState(() {
                        item.isSelected = false;
                      });
                    },
                  ),
                  flex: 0,
                ),*/ /*
              ],
            ) */ /*ChoiceChip(
            selectedColor: Colors.transparent,

            label: Wrap(
              children: <Widget>[
                 Row(children: <Widget>[
                   Flexible(child:     Text(
                   item.label,overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),flex: 1,)
                  ,
           Expanded(child:   PaddingWrap.paddingfromLTRB(
                      5.0,
                      3.0,
                      0.0,
                      0.0,
                       Icon(
                        Icons.cancel,
                        color:  ColorValues.BG_CIRCLE_COLOR,
                        size: 17.0,
                      )),flex: 0,),
                ],)

              ],
            ),
            selected: true,
            onSelected: (selected) {
              setState(() {
                skeelSelectedList.remove(item);
                filterStatus[item.index] = false;
              });
              filterData = "";
              appliedFilter = "";
              skeelSelectedList.clear();
              filterStatus.forEach(iterateFilters);
            },
          ),*/
              )));
        }
      });
      return choices;
    }

    Padding getTextView(String text) {
      return  Padding(
          padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
          child:  Align(
              alignment: Alignment.centerLeft,
              child:  Text(
                text,
                style: TextStyle(
                    fontSize: 12.0,
                    fontFamily: Constant.customRegular,
                    color:  ColorValues.GREY_TEXT_COLOR),
                textAlign: TextAlign.left,
              )));
    }

    Padding gridSelectedImages() {
      return assestList != null && assestList.length > 0
          ? PaddingWrap.paddingfromLTRB(
          15.0,
          15.0,
          15.0,
          0.0,
          Container(
              height: 200.0,
              child:  GridView.count(
                primary: true,
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.all(0.0),
                crossAxisCount: 1,
                childAspectRatio: assestList.length < 2 ? 0.60 : 0.85,
                mainAxisSpacing: 15.0,
                crossAxisSpacing: 2.0,
                children:  List.generate(assestList.length, (int index) {
                  return  Stack(
                    children: <Widget>[
                      InkWell(
                        child:  Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Stack(
                              children: <Widget>[
                                Image.file(
                                  File(assestList[index].imagePath),
                                  fit: BoxFit.fitWidth,
                                  height: 180.0,
                                  width: MediaQuery.of(context).size.width -
                                      30,
                                ),
                                Container(
                                  height: 180.0,
                                  width: MediaQuery.of(context).size.width -
                                      30,
                                  color: Colors.black54.withOpacity(.4),
                                ),
                                Center(
                                    child:  Container(
                                      height: 180.0,
                                      child:  Align(
                                          alignment: Alignment.center,
                                          child:  InkWell(
                                              child:
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  0.0,
                                                  assestList.length == 1
                                                      ? 20.0
                                                      : 0.0,
                                                  0.0,
                                                  Image.asset(
                                                    "assets/profile/post/add_post_delete.png",
                                                    width: 50.0,
                                                    height: 50.0,
                                                  )),
                                              onTap: () {
                                                assestList.removeAt(index);
                                                setState(() {
                                                  assestList;
                                                });
                                              })),
                                    )),
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  );
                }).toList(),
              )))
          : PaddingWrap.paddingfromLTRB(
          5.0,
          0.0,
          5.0,
          0.0,
          Container(
            height: 0.0,
          ));
    }

    Widget _previewVideo(VideoPlayerController controller) {
      if (controller == null) {
        return Text(
          'You have not yet picked a video',
          textAlign: TextAlign.center,
        );
      } else if (controller.value.initialized) {
        return PaddingWrap.paddingfromLTRB(
            15.0,
            15.0,
            15.0,
            25.0,
            Container(
              height: 200.0,
              child:  Stack(
                children: <Widget>[
                  Container(
                      height: 200.0,
                      child:  Align(
                        alignment: Alignment.center,
                        child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: AspectRatio(
                              aspectRatio: controller.value.aspectRatio,
                              child: VideoPlayer(_controller),
                            )),
                      )),
                  Container(
                    color:  Color(0XFFC0C0C0).withOpacity(.4),
                  ),
                  Container(
                      height: 200.0,
                      child:  Align(
                          alignment: Alignment.center,
                          child:  InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  7.0,
                                  0.0,
                                  Image.asset(
                                    "assets/newDesignIcon/achievment/remove.png",
                                    width: 35.0,
                                    height: 35.0,
                                  )),
                              onTap: () {
                                /*videoPath = null;

                                if (_controller != null) {
                                  _controller.setVolume(0.0);
                                  _controller.removeListener(listener);
                                }
                                setState(() {
                                  _controller;
                                  videoPath;
                                });*/

                                if (_controller != null &&
                                    (videoPath != null)) {
                                  // If there was a controller, we need to dispose of the old one first
                                  final oldController = _controller;

                                  // Registering a callback for the end of next frame
                                  // to dispose of an old controller
                                  // (which won't be used anymore after calling setState)
                                  WidgetsBinding.instance
                                      .addPostFrameCallback((_) async {
                                    await oldController.dispose();

                                    // Initing  controller
                                    //getVideo();
                                  });

                                  // Making sure that controller is not used by setting it to null
                                  setState(() {
                                    _controller = null;
                                    videoPath = null;
                                  });
                                }
                              })))
                ],
              ),
            ));
      } else {
        return Text(
          'Error Loading Video',
          textAlign: TextAlign.center,
        );
      }
    }

    return  Stack(
      children: [
        WillPopScope(
            onWillPop: () {
              if (widget.link != null && widget.link != null) {
                if (roleId == "1") {
                  // For Studenet
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) =>  DashBoardWidget(
                              prefs.getString(UserPreference.IS_PARENT_ROLE),
                              prefs.getString(UserPreference.IS_PARTNER_ROLE),
                              prefs.getString(UserPreference.IS_USER_ROLE),
                              currentPage:widget.groupId == null ||
                                  widget.groupId == ""
                                  ? Constant.FEED_TYPE
                                  : Constant.GROUP_TYPE)));
                } else if (roleId == "2") {
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) =>  DashBoardWidgetParent(
                              prefs.getString(UserPreference.IS_PARENT_ROLE),
                              prefs.getString(UserPreference.IS_PARTNER_ROLE),
                              prefs.getString(UserPreference.IS_USER_ROLE),
                              currentPage: widget.groupId == null ||
                                  widget.groupId == ""
                                  ? Constant.FEED_TYPE
                                  : Constant.GROUP_TYPE)));

                  // For Parent
                } else if (roleId == "4") {
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) =>  DashBoardWidgetPartner(
                              prefs.getString(UserPreference.IS_PARENT_ROLE),
                              prefs.getString(UserPreference.IS_PARTNER_ROLE),
                              prefs.getString(UserPreference.IS_USER_ROLE),
                              currentPage: widget.groupId == null ||
                                  widget.groupId == ""
                                  ? Constant.FEED_TYPE
                                  : Constant.GROUP_TYPE)));

                  // For Partner
                }
              } else {
                Navigator.pop(context, null);
              }
            },
            child:  Scaffold(
                backgroundColor:  ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
                appBar:  AppBar(
                  elevation: 0.0,
                  automaticallyImplyLeading: false,
                  titleSpacing: 2.0,
                  brightness: Brightness.light,
                  leading:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      InkWell(
                        child:  SizedBox(
                          height: 40.0,
                          width: 40.0,
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              5.0,
                              0.0,
                              3.0,
                              Center(
                                  child:  Image.asset(
                                      "assets/newDesignIcon/navigation/back.png",
                                      height: 20.0,
                                      width: 10.0,
                                      fit: BoxFit.fitHeight))),
                        ),
                        onTap: () {
                          if (widget.link != null && widget.link != null) {
                            if (roleId == "1") {
                              // For Studenet
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    //   builder: (context) =>  DashBoardWidget()));
                                      builder: (context) =>  DashBoardWidget(
                                          prefs.getString(
                                              UserPreference.IS_PARENT_ROLE),
                                          prefs.getString(
                                              UserPreference.IS_PARTNER_ROLE),
                                          prefs.getString(
                                              UserPreference.IS_USER_ROLE),
                                          currentPage: widget.groupId == null ||
                                              widget.groupId == ""
                                              ? Constant.FEED_TYPE
                                              : Constant.GROUP_TYPE)));
                            } else if (roleId == "2") {
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    //   builder: (context) =>  DashBoardWidget()));
                                      builder: (context) =>
                                          DashBoardWidgetParent(
                                              prefs.getString(UserPreference
                                                  .IS_PARENT_ROLE),
                                              prefs.getString(UserPreference
                                                  .IS_PARTNER_ROLE),
                                              prefs.getString(
                                                  UserPreference.IS_USER_ROLE),
                                              currentPage: widget.groupId ==
                                                  null ||
                                                  widget.groupId == ""
                                                  ? Constant.FEED_TYPE
                                                  : Constant
                                                  .GROUP_TYPE)));

                              // For Parent
                            } else if (roleId == "4") {
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    //   builder: (context) =>  DashBoardWidget()));
                                      builder: (context) =>
                                          DashBoardWidgetPartner(
                                              prefs.getString(UserPreference
                                                  .IS_PARENT_ROLE),
                                              prefs.getString(UserPreference
                                                  .IS_PARTNER_ROLE),
                                              prefs.getString(
                                                  UserPreference.IS_USER_ROLE),
                                              currentPage: widget.groupId ==
                                                  null ||
                                                  widget.groupId == ""
                                                  ? Constant.FEED_TYPE
                                                  : Constant
                                                  .GROUP_TYPE)));

                              // For Partner
                            }
                          } else {
                            Navigator.pop(context, null);
                          }
                        },
                      )
                    ],
                  ),
                  actions: <Widget>[
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          13.0,
                          0.0,
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                "Post",
                                style:  TextStyle(
                                    fontSize: 16.0,
                                    fontFamily: Constant.customRegular,
                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                              )
                            ],
                          )),
                      onTap: () {
                        if (assestList.length > 0 ||
                            edtController.text.trim() != "" ||
                            videoPath != null) {
                          CustomProgressLoader.showLoader(context);
                          Timer _timer =
                          Timer(const Duration(milliseconds: 400), () {
                            onTapPostButton();
                          });
                        } else {
                          ToastWrap.showToast(
                              MessageConstant.WRITE_SOMETHING_ERROR, context);
                        }
                      },
                    )
                  ],
                  title:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        "Create",
                        style:  TextStyle(
                            fontSize: 18.0,
                            fontFamily: Constant.customRegular,
                            color:
                            ColorValues.HEADING_COLOR_EDUCATION),
                      )
                    ],
                  ),
                  backgroundColor: Colors.white,
                ),
                body:  Column(
                  children: <Widget>[
                    CustomViews.getSepratorLine(),
                    Expanded(
                      child:  ListView(
                        children: <Widget>[
                          Container(
                            child:  Column(
                              children: <Widget>[
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Expanded(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              14.0, 15.0, 10.0, 0.0),
                                          child:  Container(
                                            height: 60.0,
                                            width: 60.0,
                                            child: ClipRRect(
                                              borderRadius:
                                              BorderRadius.circular(100),
                                              child: FadeInImage(
                                                fit: BoxFit.cover,
                                                placeholder: AssetImage(
                                                  roleId == "4"
                                                      ? "assets/profile/partner_img.png"
                                                      : 'assets/profile/user_on_user.png',
                                                ),
                                                image: NetworkImage(Constant
                                                    .IMAGE_PATH_SMALL +
                                                    ParseJson.getSmallImage(
                                                        roleId == "4"
                                                            ? companyImagePath
                                                            : userProfilePath)),
                                              ),
                                            ),
                                          )),
                                      flex: 0,
                                    ),
                                    Expanded(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          35.0,
                                          13.0,
                                          0.0,
                                          Row(
                                            children: <Widget>[
                                              Text(
                                                roleId == "4"
                                                    ? companyName
                                                    : widget.profileInfoModal !=
                                                    null
                                                    ? widget.profileInfoModal.lastName ==
                                                    null ||
                                                    widget.profileInfoModal
                                                        .lastName ==
                                                        "null" ||
                                                    widget
                                                        .profileInfoModal
                                                        .lastName ==
                                                        ""
                                                    ? widget
                                                    .profileInfoModal
                                                    .firstName
                                                    : widget.profileInfoModal
                                                    .firstName +
                                                    " " +
                                                    widget
                                                        .profileInfoModal
                                                        .lastName
                                                    : "",
                                                overflow: TextOverflow.ellipsis,
                                                style:  TextStyle(
                                                    fontFamily:
                                                    Constant.customRegular,
                                                    fontWeight: FontWeight.bold,
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontSize: 14.0),
                                              ),
                                              widget.profileInfoModal != null
                                                  ? widget.profileInfoModal
                                                  .roleId ==
                                                  "1"
                                                  ?
                                              //true ?
                                              Util.getStudentBadge12(
                                                  widget
                                                      .profileInfoModal
                                                      .badge,
                                                  widget
                                                      .profileInfoModal
                                                      .badgeImage)
                                                  : Container()
                                                  : Container(),
                                            ],
                                          )),
                                      flex: 1,
                                    )
                                  ],
                                ), // User Image and Name
                                Container(
                                    child:  Card(
                                        elevation: 0.0,
                                        color: Colors.transparent,
                                        child:  Column(
                                          children: <Widget>[
                                            PaddingWrap.paddingfromLTRB(
                                                3.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                TextField(
                                                  cursorColor:
                                                  Constant.CURSOR_COLOR,
                                                  style: TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily: Constant
                                                          .customRegular,
                                                      fontWeight:
                                                      FontWeight.normal),
                                                  maxLines: 5,
                                                  textCapitalization:
                                                  TextCapitalization
                                                      .sentences,
                                                  maxLength: TextLength
                                                      .POST_MSG_MAX_LENGTH,
                                                  controller: edtController,
                                                  autofocus: true,
                                                  keyboardType:
                                                  TextInputType.multiline,
                                                  textAlign: TextAlign.start,
                                                  decoration:
                                                  InputDecoration(
                                                    border: InputBorder.none,
                                                    filled: true,
                                                    hintText:
                                                    "Share your thoughts",
                                                    counterStyle:  TextStyle(
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                    hintStyle:  TextStyle(
                                                        color: ColorValues.hintColor),
                                                    fillColor:
                                                    Colors.transparent,
                                                  ),
                                                )),
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                5.0,
                                                0.0,
                                                Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    gridSelectedImages(),
                                                    // Image GRID
                                                    assestList.length > 1
                                                        ? PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        getTextView("Uploads(" +
                                                            assestList
                                                                .length
                                                                .toString() +
                                                            ")"))
                                                        :  Container(
                                                      height: 0.0,
                                                    ),

                                                    videoPath != null &&
                                                        _controller != null
                                                        ? _previewVideo(
                                                        _controller)
                                                        : Container(
                                                      height: 1.0,
                                                    ),

                                                    selectedUerTagLIst1.length >
                                                        0
                                                        ? PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        getTextView("Tags(" +
                                                            selectedUerTagLIst1
                                                                .length
                                                                .toString() +
                                                            ")"))
                                                        :  Container(
                                                      height: 0.0,
                                                    ),
                                                    Container(
                                                        alignment: Alignment
                                                            .centerLeft,
                                                        child:  Padding(
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                              10.0,
                                                              10.0,
                                                              0.0,
                                                              0.0),
                                                          child: Wrap(
                                                            children:
                                                            _buildChoiceList(),
                                                          ),
                                                        )),
                                                  ],
                                                )),
                                          ],
                                        ))), // Selected Image and Text View
                              ],
                            ),
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                    Container(
                      height: 60.0,
                      color: Colors.white,
                      child: Column(
                        children: <Widget>[
                          Container(
                            height: 1.0,
                            color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child:  Row(
                                  children: <Widget>[
                                    InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          14.0,
                                          15.0,
                                          10.0,
                                          10.0,
                                          Image.asset(
                                            "assets/profile/post/camera.png",
                                            fit: BoxFit.cover,
                                            color: ColorValues.GREY_TEXT_COLOR,
                                            height: 25.0,
                                            width: 25.0,
                                          )),
                                      onTap: () async {
                                        if (videoPath == null) {
                                          var status =
                                          await Permission.photos.status;
                                          if (status.isGranted) {
                                            getImage(ImageSource.camera);
                                          } else {
                                            checkPermissionPhoto(context);
                                          }
                                        } else
                                          null;
                                      },
                                    ),
                                    assestList == null || assestList.length == 0
                                        ?  InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          10.0,
                                          10.0,
                                          10.0,
                                          5.0,
                                          Image.asset(
                                            "assets/profile/post/video.png",
                                            fit: BoxFit.cover,
                                            color: ColorValues.GREY_TEXT_COLOR,
                                            height: 28.0,
                                            width: 28.0,
                                          )),
                                      onTap: () {
                                        assestList == null ||
                                            assestList.length == 0
                                            ? getInitVideo()
                                            : null;
                                      },
                                    )
                                        :  Container(
                                      height: 0.0,
                                    ),
                                    isType == "Private"
                                        ?  Container(
                                      height: 0.0,
                                    )
                                        :  InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          10.0,
                                          15.0,
                                          10.0,
                                          10.0,
                                          Image.asset(
                                            "assets/profile/post/tagging.png",
                                            fit: BoxFit.cover,
                                            color: ColorValues.GREY_TEXT_COLOR,
                                            height: 26.0,
                                            width: 26.0,
                                          )),
                                      onTap: () {
                                        onTapTagBtn();
                                      },
                                    ),
                                    videoPath == null
                                        ?  InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          10.0,
                                          15.0,
                                          10.0,
                                          10.0,
                                          Image.asset(
                                            "assets/profile/post/gallery.png",
                                            fit: BoxFit.cover,
                                            color: ColorValues.GREY_TEXT_COLOR,
                                            height: 26.0,
                                            width: 26.0,
                                          )),
                                      onTap: () async {
                                        if (videoPath == null) {
                                          var status = await Permission
                                              .photos.status;
                                          if (status.isGranted) {
                                            getImage(ImageSource.gallery);
                                          } else {
                                            checkPermissionPhoto(context);
                                          }
                                        } else
                                          null;
                                      },
                                    )
                                        :  Container(
                                      height: 0.0,
                                    ),
                                  ],
                                ),
                                flex: 1,
                              ),
                              widget.groupId != ""
                                  ?  Container(
                                height: 0.0,
                              )
                                  :

                              /*   Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                                  child:  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: <Widget>[
                                      isType == "Public"
                                          ?  InkWell(
                                              child:  Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: <Widget>[
                                                   Image.asset(
                                                    "assets/newDesignIcon/connections/public.png",
                                                    width: 25.0,
                                                    height: 25.0,
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  ),
                                                  PaddingWrap.paddingfromLTRB(
                                                      5.0,
                                                      5.0,
                                                      10.0,
                                                      5.0,
                                                      TextViewWrap.textView(
                                                          "Public",
                                                          TextAlign.center,
                                                           ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                          12.0,
                                                          FontWeight.normal))
                                                ],
                                              ),
                                              onTap: () {
                                                _settingModalBottomSheet(
                                                    context);
                                              })
                                          : isType == "Private"
                                              ?  InkWell(
                                                  child:  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: <Widget>[
                                                       Image.asset(
                                                        "assets/newDesignIcon/connections/private.png",
                                                        fit: BoxFit.cover,
                                                        height: 25.0,
                                                        width: 25.0,
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      ),
                                                      PaddingWrap.paddingfromLTRB(
                                                          5.0,
                                                          5.0,
                                                          10.0,
                                                          5.0,
                                                          TextViewWrap.textView(
                                                              "Private",
                                                              TextAlign.center,
                                                               Color(ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR),
                                                              12.0,
                                                              FontWeight
                                                                  .normal))
                                                    ],
                                                  ),
                                                  onTap: () {
                                                    _settingModalBottomSheet(
                                                        context);
                                                  })
                                              : isType == "AllConnections"
                                                  ?  InkWell(
                                                      child:  Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child:
                                                                 Image.asset(
                                                              "assets/profile/post/all_connections.png",
                                                              height: 14.0,
                                                              width: 35.0,
                                                            ),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child:  Container(
                                                                width: 85.0,
                                                                child: PaddingWrap.paddingAll(
                                                                    5.0,
                                                                    TextViewWrap.textViewMultiLine(
                                                                        "Connections",
                                                                        TextAlign
                                                                            .start,
                                                                         ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                        12.0,
                                                                        FontWeight
                                                                            .normal,
                                                                        2))),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        _settingModalBottomSheet(
                                                            context);
                                                      })
                                                  :  InkWell(
                                                      child:  Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child:
                                                                 Image.asset(
                                                              "assets/profile/post/selected_connections.png",
                                                              height: 14.0,
                                                              width: 35.0,
                                                            ),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child:  Container(
                                                                width: 85.0,
                                                                child: PaddingWrap.paddingAll(
                                                                    5.0,
                                                                    TextViewWrap.textViewMultiLine(
                                                                        "Selected Connections",
                                                                        TextAlign
                                                                            .start,
                                                                         ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                        12.0,
                                                                        FontWeight
                                                                            .normal,
                                                                        2))),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        _settingModalBottomSheet(
                                                            context);
                                                      }),
                                    ],
                                  ),
                                )
*/

                              Padding(
                                padding: EdgeInsets.fromLTRB(
                                    0.0, 5.0, 20.0, 0.0),
                                child:  Container(
                                  child:  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.end,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.end,
                                    children: <Widget>[
                                      isType == "Public"
                                          ?  InkWell(
                                          child:  Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <Widget>[
                                              Expanded(
                                                child:  Container(
                                                    width: 65.0,
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        5.0,
                                                        5.0,
                                                        5.0,
                                                        TextViewWrap.textViewMultiLine(
                                                            "Public",
                                                            TextAlign
                                                                .start,
                                                            ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            12.0,
                                                            FontWeight
                                                                .normal,
                                                            2))),
                                                flex: 0,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding:
                                                  const EdgeInsets
                                                      .fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:
                                                  Image.asset(
                                                    "assets/profile/post/arrow.png",
                                                    height: 14.0,
                                                    width: 14.0,
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          : isType == "Private"
                                          ?  InkWell(
                                          child:  Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <Widget>[
                                              Expanded(
                                                child:  Container(
                                                    width: 65.0,
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        5.0,
                                                        5.0,
                                                        5.0,
                                                        TextViewWrap.textViewMultiLine(
                                                            "Private",
                                                            TextAlign
                                                                .start,
                                                            ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            12.0,
                                                            FontWeight
                                                                .normal,
                                                            2))),
                                                flex: 0,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding:
                                                  const EdgeInsets
                                                      .fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:  Image
                                                      .asset(
                                                    "assets/profile/post/arrow.png",
                                                    height: 14.0,
                                                    width: 14.0,
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          : isType == "AllConnections"
                                          ?  InkWell(
                                          child:  Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                              Expanded(
                                                child:  Container(
                                                    width:
                                                    90.0,
                                                    child: PaddingWrap.paddingAll(
                                                        5.0,
                                                        TextViewWrap.textViewMultiLine(
                                                            "Connections",
                                                            TextAlign.start,
                                                            ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            12.0,
                                                            FontWeight.normal,
                                                            2))),
                                                flex: 0,
                                              ),
                                              Expanded(
                                                child:
                                                Padding(
                                                  padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:  Image
                                                      .asset(
                                                    "assets/profile/post/arrow.png",
                                                    height:
                                                    14.0,
                                                    width:
                                                    14.0,
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          : isType == "Community"
                                          ?  InkWell(
                                          child:  Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                              Expanded(
                                                child:  Container(
                                                    width:
                                                    90.0,
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        5.0,
                                                        5.0,
                                                        5.0,
                                                        TextViewWrap.textViewMultiLine("Community", TextAlign.start,  ColorValues.BLUE_COLOR_BOTTOMBAR, 12.0, FontWeight.normal, 2))),
                                                flex: 0,
                                              ),
                                              Expanded(
                                                child:
                                                Padding(
                                                  padding: const EdgeInsets.fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:  Image
                                                      .asset(
                                                    "assets/profile/post/arrow.png",
                                                    height:
                                                    14.0,
                                                    width:
                                                    14.0,
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          : isType == "Group"
                                          ?  InkWell(
                                          child:
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                              Expanded(
                                                child:  Container(
                                                    width: 67.0,
                                                    child: PaddingWrap.paddingfromLTRB(10.0, 5.0, 5.0, 5.0, TextViewWrap.textViewMultiLine("Group", TextAlign.start,  ColorValues.BLUE_COLOR_BOTTOMBAR, 12.0, FontWeight.normal, 2))),
                                                flex:
                                                0,
                                              ),
                                              Expanded(
                                                child:
                                                Padding(
                                                  padding: const EdgeInsets.fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:
                                                  Image.asset(
                                                    "assets/profile/post/arrow.png",
                                                    height: 14.0,
                                                    width: 14.0,
                                                  ),
                                                ),
                                                flex:
                                                0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          :  InkWell(
                                          child:
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                              Expanded(
                                                child:  Container(
                                                    width: 92.0,
                                                    child: PaddingWrap.paddingAll(5.0, TextViewWrap.textViewMultiLine("Selected Connections", TextAlign.start,  ColorValues.BLUE_COLOR_BOTTOMBAR, 12.0, FontWeight.normal, 2))),
                                                flex:
                                                0,
                                              ),
                                              Expanded(
                                                child:
                                                Padding(
                                                  padding: const EdgeInsets.fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:
                                                  Image.asset(
                                                    "assets/profile/post/arrow.png",
                                                    height: 14.0,
                                                    width: 14.0,
                                                  ),
                                                ),
                                                flex:
                                                0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          }),
                                    ],
                                  ),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Color(0xfff4684EB),
                                      width: 1.0,
                                    ),
                                    borderRadius:
                                    BorderRadius.circular(0),
                                  ),
                                ),
                              )
                            ],
                          )
                        ],
                      ),
                    )
                  ],
                ))),
      ],
    );
  }

// Updated View for POST TYPE

}
