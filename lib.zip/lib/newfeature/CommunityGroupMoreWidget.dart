import 'dart:async';

import 'package:adhara_socket_io/manager.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/OpportunityViewOnNotificationClick.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/notification/model/NotificationModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parentProfile/RecommendationListForParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';

import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';

import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:url_launcher/url_launcher.dart';

class CommunityGroupMoreWidget extends StatefulWidget {
  String pageName;

  CommunityGroupMoreWidget(this.pageName);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  CommunityGroupMoreWidgetState();
  }
}

class CommunityGroupMoreWidgetState extends State<CommunityGroupMoreWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor:  ColorValues.WHITE,
        appBar:  AppBar(
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          brightness: Brightness.light,
          leading:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               InkWell(
                child:  SizedBox(
                  height: 40.0,
                  width: 40.0,
                  child: PaddingWrap.paddingfromLTRB(
                      10.0,
                      5.0,
                      0.0,
                      3.0,
                       Center(
                          child:  Image.asset(
                              "assets/newDesignIcon/navigation/back.png",
                              height: 20.0,
                              width: 10.0,
                              fit: BoxFit.fitHeight))),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              )
            ],
          ),
          backgroundColor:  ColorValues.WHITE,
          elevation: 0.0,
        ),
        body: Container(
          margin: const EdgeInsets.only(left: 17, top: 54),
          child: widget.pageName == "Skills"
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.asset('assets/coach_mark/skills_icon.png',
                        height: 24, width: 24),
                    SizedBox(height: 24, width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Skills & Certifications',
                            style: TextStyle(
                                fontSize: 18,
                                fontFamily: 'Nunito',
                                fontWeight: FontWeight.w600)),
                        SizedBox(height: 5),
                        Container(
                            width: 293,
                            child: RichText(
                                text: TextSpan(
                              text:
                                  "Highlight special skills and upload any certifications that you have completed",
                              style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: 'Nunito',
                                  color: Colors.black),
                            ))),
                        SizedBox(height: 15),
                        /*Container(
                            width: 293,
                            child: RichText(
                                text: TextSpan(
                              text:
                                  "Earn reward points when you engage on the spikeview platform."
                                      " You will be rewarded points for adding to your profile, building a "
                                      "network, inviting friends, and for contributing content. Reward points "
                                      "will enable you to build your reputation on spikeview and get early "
                                      "access to features and many other benefits. You will also be able to "
                                      "compete to be on the leaderboard and get showcased."
                                    ,
                              style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: 'Nunito',
                                  color: Colors.black),
                            ))),*/

                      ],
                    )
                  ],
                )
              : widget.pageName == "Interest"
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Image.asset('assets/coach_mark/interest_icon.png',
                            height: 24, width: 24),
                        SizedBox(height: 24, width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Interest and Future Goals',
                                style: TextStyle(
                                    fontSize: 18,
                                    fontFamily: 'Nunito',
                                    fontWeight: FontWeight.w600)),
                            SizedBox(height: 5),
                            Container(
                                width: 293,
                                child: RichText(
                                    text: TextSpan(
                                  text:
                                      "Share your unique interest and reflect on your future goals.",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: 'Nunito',
                                      color: Colors.black),
                                ))),
                            SizedBox(height: 15),
                            /*Container(
                                width: 293,
                                child: RichText(
                                    text: TextSpan(
                                  text:
                                      "spikeview will now enable members to post to everyone in the community."
                                          " If you decide to use this feature, please be sure it is appropriate "
                                          "for the community. Community managers will review and approve the post "
                                          "before it is visible.",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: 'Nunito',
                                      color: Colors.black),
                                ))),*/

                          ],
                        )
                      ],
                    )
           : widget.pageName == "Social Link"
              ? Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset('assets/coach_mark/social_link_icon.png',
                  height: 24, width: 24),
              SizedBox(height: 24, width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Social Link',
                      style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Nunito',
                          fontWeight: FontWeight.w600)),
                  SizedBox(height: 5),
                  Container(
                      width: 293,
                      child: RichText(
                          text: TextSpan(
                            text:
                            "Link to your social accounts to easily access and manage your online presence",
                            style: TextStyle(
                                fontSize: 14,
                                fontFamily: 'Nunito',
                                color: Colors.black),
                          ))),
                  SizedBox(height: 15),
                  /*Container(
                      width: 293,
                      child: RichText(
                          text: TextSpan(
                            text:
                            "spikeview will now enable members to post to everyone in the community."
                                " If you decide to use this feature, please be sure it is appropriate "
                                "for the community. Community managers will review and approve the post "
                                "before it is visible.",
                            style: TextStyle(
                                fontSize: 14,
                                fontFamily: 'Nunito',
                                color: Colors.black),
                          ))),*/

                ],
              )
            ],
          )
              : widget.pageName == "Portfolio"
              ? Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset('assets/coach_mark/portfolio_icon.png',
                  height: 24, width: 24),
              SizedBox(height: 24, width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Portfolio',
                      style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Nunito',
                          fontWeight: FontWeight.w600)),
                  SizedBox(height: 5),
                  Container(
                      width: 293,
                      child: RichText(
                          text: TextSpan(
                            text:
                            "Build a detailed sports portfolio or an arts portfolio and add it to your spikeview in addition to all your experiences",
                            style: TextStyle(
                                fontSize: 14,
                                fontFamily: 'Nunito',
                                color: Colors.black),
                          ))),
                  SizedBox(height: 15),
                  /*Container(
                      width: 293,
                      child: RichText(
                          text: TextSpan(
                            text:
                            "spikeview will now enable members to post to everyone in the community."
                                " If you decide to use this feature, please be sure it is appropriate "
                                "for the community. Community managers will review and approve the post "
                                "before it is visible.",
                            style: TextStyle(
                                fontSize: 14,
                                fontFamily: 'Nunito',
                                color: Colors.black),
                          ))),*/

                ],
              )
            ],
          )
                  : Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Image.asset('assets/newFeature/suitcase 1.png',
                            height: 24, width: 24),
                        SizedBox(height: 24, width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Opportunities',
                                style: TextStyle(
                                    fontSize: 18,
                                    fontFamily: 'Nunito',
                                    fontWeight: FontWeight.w600)),
                            SizedBox(height: 5),
                            Container(
                                width: 293,
                                child: RichText(
                                    text: TextSpan(
                                  text:
                                      "View active opportunities on the spikeview platform an easily find what you are looking for.",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: 'Nunito',
                                      color: Colors.black),
                                ))),
                            SizedBox(height: 15),
                            Container(
                                width: 293,
                                child: RichText(
                                    text: TextSpan(
                                      text:
                                      "From the search bar, click on the explore opportunities button to navigate to the active opportunities on the spikeview platform.",
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontFamily: 'Nunito',
                                          color: Colors.black),
                                    ))),
                          ],
                        )
                      ],
                    ),
        ));
  }
}
