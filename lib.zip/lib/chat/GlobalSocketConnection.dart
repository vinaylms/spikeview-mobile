import 'dart:async';

import 'package:adhara_socket_io/adhara_socket_io.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/db/db_helper_new.dart';


class GlobalSocketConnection {
  static StreamController updateChatController = StreamController.broadcast();
  static StreamController startTypingController = StreamController.broadcast();
  static StreamController stopTypingController = StreamController.broadcast();
  static StreamController onlineStatusController = StreamController.broadcast();
  static StreamController reportController = StreamController.broadcast();
  static StreamController groupController = StreamController.broadcast();


     // static FirebaseAnalytics analytics = FirebaseAnalytics();
    // static FirebaseAnalyticsObserver observer =
   //  FirebaseAnalyticsObserver(analytics: analytics);
  //static SocketIO socketIO;

  //=====================FOR PRODUCTION==========================
 // static String ip = "https://app.spikeview.com:3003/";
  //=====================For QA==========================

 // static String ip = "http://125.99.189.202:3001/";
  static String ip = "http://125.99.189.202:3003/";
  static SocketIOManager manager = SocketIOManager();
  static SocketIO socket;
  SharedPreferences sharePreferences;

  static void addUser(userIdPref) {
    Map map = {
      "userId": int.parse(userIdPref),
      //"deviceId": deviceId,
      //"roleId": roleId,
    };
    print("data for addUser" + map.toString());
    GlobalSocketConnection.socket.emitWithAck("chat-login", [map]).then((data) {
      // this callback runs when this specific message is acknowledged by the server
      print("chat-login++++" + data.toString());
    });
  }

  static Future<String> initSocket() async {
    print("inside initSocket() GlobalSocketConnection ");
    socket = await SocketIOManager().createInstance(SocketOptions(
        GlobalSocketConnection.ip,
        enableLogging: true,
        transports: const [Transports.WEB_SOCKET]));
    GlobalSocketConnection.socket.onConnect((data) {
      print("GlobalSocketConnection connected...");
      print(data);
    });

    GlobalSocketConnection.socket.onDisconnect((data) {
      print(
          "========================================GlobalSocketConnection Disconnected...============================================");
      print(data);
    });

    GlobalSocketConnection.socket.onConnectError((data) {
      print(
          "========================================GlobalSocketConnection onConnectError...============================================");
      print(data);
    });
    GlobalSocketConnection.socket.onError((data) {
      print(
          "========================================GlobalSocketConnection onError...============================================");
      print(data);
    });

    GlobalSocketConnection.socket.on("updatechat", (data) {
      print("GlobalSocketConnection updatechat event++++++++++++++++" +
          data.toString());
           updateChatController.add(data);
    });

    GlobalSocketConnection.socket.on("startTyping", (data) {
      startTypingController.add(data);
      print("GlobalSocketConnection startTyping++++++++++++++++" +
          data.toString());
    });

    GlobalSocketConnection.socket.on("stopTyping", (data) {
      stopTypingController.add(data);
      print("GlobalSocketConnection stopTyping++++++++++++++++" +
          data.toString());
    });

    GlobalSocketConnection.socket.on("changeUserOnlineStatus", (data) {
      print("GlobalSocketConnection changeUserOnlineStatus++++++++++++++++" +
          data.toString());
      onlineStatusController.add(data);
    });

    GlobalSocketConnection.socket.on("updateFeed", (data) async{
      print("GlobalSocketConnection updateFeed++++++++++++++++" +
          data.toString());
      await DbHelper().deleteitem(data.toString());
      reportController.add(data.toString());
    });

    GlobalSocketConnection.socket.on("updateGroup", (data) async{
      print("GlobalSocketConnection groupController++++++++++++++++" +
          data.toString());
      groupController.add(data.toString());
    });

    GlobalSocketConnection.socket.connect();
  }

}
