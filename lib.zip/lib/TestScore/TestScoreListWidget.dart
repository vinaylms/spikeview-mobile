import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/TestScore/AddTestScoreWidget.dart';
import 'package:spike_view_project/TestScore/EditTestScoreWidget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:spike_view_project/customViews/CustomViews.dart';

import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TestDataModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';


import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class TestScoreListWidget extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  List<MainScoreModel> userTestList;


  TestScoreListWidget(
      this.profileInfoModal, this.userTestList);

  @override
  TestScoreListWidgetState createState() {
    return     TestScoreListWidgetState(userTestList);
  }
}

class TestScoreListWidgetState extends State<TestScoreListWidget> {
  String userIdPref, token;
  List<MainScoreModel> userTestList;
  String isPerformChnges = "pop";
  SharedPreferences prefs;

  TestScoreListWidgetState(this.userTestList);

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    token = prefs.getString(UserPreference.USER_TOKEN);
    // narrativeApi();
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    super.initState();
  }

  Future testScoreApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        Response response = await     ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_GET_TEST_SCORE_DATA + userIdPref, "get");

        print("response education" + response.toString());

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {

              List<MainScoreModel> testScoreListNew =
                  ParseJson.parseTestList(response.data['result']);
              if (testScoreListNew.length > 0) {
                userTestList.clear();
                userTestList.addAll(testScoreListNew);
                if (mounted) {
                  setState(() {
                    userTestList;
                  });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------Delete Education Data ------------------
  Future deleteTest(testId,userTestId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": userIdPref,
          "userTestId": userTestId,
        };
        print("map++++"+map.toString());
        Response response = await     ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_DELETE_TEST_SCORE_DATA, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              userTestList.removeAt(index);
              setState(() {
                userTestList;
                isPerformChnges = "push";
              });

              if (userTestList.length == 0) Navigator.pop(context, "push");

              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    void educationRemoveConfromationDialog(testId,userTestId,  index) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>     WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:     SafeArea(
                  child:     Scaffold(
                      backgroundColor: Colors.black38,
                      body:     Stack(
                        children: <Widget>[
                              Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:     Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child:     Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                                Container(
                                              height: 145.0,
                                              padding:     EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:     Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                        Text(
                                                     MessageConstant.TEXT_SCORE_REMOVE_SCRORE,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:    AppTextStyle.getDynamicStyleGroupHEIGHT(ColorValues.HEADING_COLOR_EDUCATION,16.0,FontType.Regular, 1.2),  /*TextStyle(
                                                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),*/
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                              Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:     Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                      Container(
                                      color: Colors.white,
                                      padding:     EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:     Row(
                                        children: <Widget>[
                                              Expanded(
                                            child:     InkWell(
                                              child:     Container(
                                                  child:     Text(
                                                MessageConstant.CANCEL,

                                                textAlign: TextAlign.center,
                                                style:    AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,16.0,FontType.Regular),  /*TextStyle(
                                                    color:     ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                              Expanded(
                                            child:     InkWell(
                                              child:     Container(
                                                  child:     Text(
                                                MessageConstant.REMOVE,
                                                textAlign: TextAlign.center,
                                                style:    AppTextStyle.getDynamicStyleGroup(ColorValues.BLUE_COLOR_BOTTOMBAR,16.0,FontType.Regular), /* TextStyle(
                                                    color:     ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                deleteTest(
                                                    testId,userTestId, index);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    onTapEducationItemEditBtn(TestDataModel model) async {
      print("clicked edit");
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>     EditTestScoreWidget(
              model,widget.profileInfoModal.userId)));
      print(result);
      if (result == "push") {
        setState(() {
          isPerformChnges = "push";
        });
        testScoreApi(true);
      }
    }
    Container getTestScoreListItem(index) {
      return     Container(
          color: Colors.white,
          child: PaddingWrap.paddingfromLTRB(
              0.0,
              10.0,
              0.0,
              13.0,
                  Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  index != 0
                      ?     Container(
                    height: 0.0,
                  )
                      : PaddingWrap.paddingfromLTRB(
                      14.0,
                      0.0,
                      13.0,
                      0.0,
                          Text(
                        MessageConstant.TEXT_SCORE_USER_WONT_ABLE,
                        style:    AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,12.0,FontType.Regular),   /*TextStyle(
                            fontWeight: FontWeight.normal,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                            color:     ColorValues.GREY_TEXT_COLOR,
                            fontSize: 12.0),*/
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      0.0,
                          Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                              Expanded(
                            child:     Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                    Container(
                                    width:double.infinity,
                                    padding:     EdgeInsets.all(5.0),
                                    color: ColorValues.DARK_GREY,
                                    child:PaddingWrap.paddingfromLTRB(
                                        11.0,
                                        0.0,
                                        5.0,
                                        0.0,
                                            Text(
                                          userTestList[index].testName,
                                          maxLines: 1,
                                          style:   AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,16.0,FontType.Regular),     /*TextStyle(
                                              fontWeight: FontWeight.normal,
                                              color:     ColorValues.HEADING_COLOR_EDUCATION,fontFamily: Constant.customRegular,
                                              fontSize: 16.0),*/
                                        )))
                                ,
                                /*   */
                              ],
                            ),
                            flex: 5,
                          ),
                        ],
                      )),
                  PaddingWrap.paddingfromLTRB(
                      14.0,
                      10.0,
                      14.0,
                      0.0,
                          Column(
                          children:     List.generate(
                              userTestList[index].mainTestList.length,
                                  (index3) {
                                return  PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                        Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[
                                            Row(children: <Widget>[
                                        Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              20.0,
                                              0.0,
                                              20.0,     Text(
                                            userTestList[index].mainTestList[index3]
                                                .dateTaken,
                                            style:      AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,14.0,FontType.Regular),  /*TextStyle(
                                                color:     ColorValues.HEADING_COLOR_EDUCATION,fontFamily: Constant.customRegular,
                                                fontSize: 14.0),*/
                                          )),flex: 1,),
                                              Expanded(
                                            child:     InkWell(
                                              child: PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  5.0,
                                                  0.0,
                                                  5.0,
                                                      Image.asset(
                                                    "assets/newDesignIcon/edit_circl.png",
                                                    height: 30.0,
                                                    width: 30.0,
                                                  )),
                                              onTap: () {
                                                onTapEducationItemEditBtn(userTestList[index].mainTestList[index3]);
                                              },
                                            ),
                                            flex: 0,
                                          ),
                                              Expanded(
                                            child:     InkWell(
                                              child: PaddingWrap.paddingfromLTRB(
                                                  18.0,
                                                  5.0,
                                                  0.0,
                                                  5.0,
                                                      Image.asset(
                                                    "assets/newDesignIcon/cancel_circl.png",
                                                    height: 30.0,
                                                    width: 30.0,
                                                  )),
                                              onTap: () {
                                                educationRemoveConfromationDialog(
                                                    userTestList[index].mainTestList[index3].testId, userTestList[index].mainTestList[index3].userTestId,
                                                    index);

                                              },
                                            ),
                                            flex: 0,
                                          )
                                        ],),



                                            Container(
                                            decoration:     BoxDecoration(
                                                color: Colors.white,
                                                border:     Border.all(
                                                    color:     ColorValues.BORDER_COLOR,
                                                    width: 0.5)), child:new Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: <Widget>[

                                                Column(

                                                children:     List.generate(
                                                    userTestList[index].mainTestList[index3].isShowMore?
                                                    userTestList[index].mainTestList[index3].subjectListModel.length
                                                        :  userTestList[index].mainTestList[index3].subjectListModel.length>2
                                                        ?3:
                                                    userTestList[index].mainTestList[index3].subjectListModel.length,
                                                        (index2) {
                                                      return  Container(
                                                          color:index2%2==0?     ColorValues.singin_bg_color:Colors.white,
                                                          child: PaddingWrap.paddingfromLTRB(
                                                              10.0,
                                                              10.0,
                                                              10.0,
                                                              10.0,
                                                                  Row(
                                                                children: <Widget>[
                                                                      Expanded(
                                                                    child:     Text(
                                                                      userTestList[index].mainTestList[index3]
                                                                          .subjectListModel[index2]
                                                                          .subjectName,
                                                                      style:    AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,14.0,FontType.Regular),   /*TextStyle(
                                                                          color:     ColorValues.GREY_TEXT_COLOR,fontFamily: Constant.customRegular,
                                                                          fontSize: 14.0),*/
                                                                    ),
                                                                    flex: 1,
                                                                  ),
                                                                      Expanded(
                                                                    child:     Text(
                                                                      userTestList[index].mainTestList[index3]
                                                                          .subjectListModel[index2]
                                                                          .score
                                                                          .toString(),
                                                                      style:     AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,14.0,FontType.Regular),  /*TextStyle(
                                                                          color:     ColorValues.HEADING_COLOR_EDUCATION,fontFamily: Constant.customRegular,
                                                                          fontSize: 14.0),*/
                                                                    ),
                                                                    flex: 0,
                                                                  )
                                                                ],
                                                              )));
                                                    })),
                                            userTestList[index].mainTestList[index3].subjectListModel.length > 2
                                                ? PaddingWrap.paddingfromLTRB(
                                                11.0,
                                                10.0,
                                                13.0,
                                                10.0,
                                                    InkWell(
                                                  child:     Text(
                                                    userTestList[index].mainTestList[index3].isShowMore ? "Less" : "More",
                                                    style:      AppTextStyle.getDynamicStyleGroup(ColorValues.BLUE_COLOR_BOTTOMBAR,16.0,FontType.Regular), /*TextStyle(
                                                        color:     ColorValues.BLUE_COLOR_BOTTOMBAR,fontFamily: Constant.customRegular,
                                                        fontSize: 16.0),*/
                                                  ),
                                                  onTap: () {
                                                    if (userTestList[index].mainTestList[index3].isShowMore)
                                                      userTestList[index].mainTestList[index3].isShowMore = false;
                                                    else
                                                      userTestList[index].mainTestList[index3].isShowMore = true;
                                                    setState(() {});
                                                  },
                                                ))
                                                :     Container(
                                              height: 0.0,
                                            ),

                                          ],) )
                                      ],));
                              }))),



                  // CustomViews.getSepratorLine()
                ],
              )));
    }


//============================================ grid view achevements nd core logic =====================================
    onTapAddEducationBtn() async {
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>     AddTestScoreWidget(widget.profileInfoModal
          )));;

      print(result);
      if (result == "push") {
        setState(() {
          isPerformChnges = "push";
        });
        testScoreApi(true);
      }
    }

    return     WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChnges);
        },
        child:     Scaffold(
            backgroundColor:     ColorValues.SCREEN_BG_COLOR,
            appBar:     AppBar(
              elevation: 0.0,
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              title:     Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                      Expanded(
                    child:     InkWell(
                      child:     SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                                Center(
                                child:     Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context, isPerformChnges);
                      },
                    ),
                    flex: 0,
                  ),
                      Expanded(
                    child:     Text(
                      MessageConstant.TEXT_SCORE_TEST_SCORE,
                      textAlign: TextAlign.center,
                      style:     AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,18.0,FontType.Regular), /*TextStyle(
                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                    Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                       InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          5.0,
                          0.0,
                          13.0,
                          0.0,
                              Image.asset(
                            "assets/newDesignIcon/navigation/add.png",
                            height: 20.0,
                            width: 20.0,
                          )),
                      onTap: () {

                          onTapAddEducationBtn();

                      },
                    )
                  ],
                )
              ],
              backgroundColor: Colors.white,
            ),
            body:     Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),

                    Expanded(
                    child:     ListView(
                  children: <Widget>[
                        Column(
                        children:     List
                            .generate(
                            userTestList.length,
                                (int
                            index) {
                              return getTestScoreListItem(
                                  index);
                            }))
                  ],
                ))
              ],
            )));
  }
}
