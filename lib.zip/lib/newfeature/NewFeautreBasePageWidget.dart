import 'dart:async';

import 'package:adhara_socket_io/manager.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/OpportunityViewOnNotificationClick.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/notification/model/NotificationModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parentProfile/RecommendationListForParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';

import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';

import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:url_launcher/url_launcher.dart';

import 'CommunityGroupMoreWidget.dart';
import 'ParticipateInLeaderBoardWidget.dart';

class NewFeautreBasePageWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  NewFeautreBasePageWidgetState();
  }
}

class NewFeautreBasePageWidgetState extends State<NewFeautreBasePageWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isPreLoginSetting = false;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    isPreLoginSetting = prefs.getBool(UserPreference.IS_PRE_LOGIN);
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getSharedPreferences();
  }

  Future apiCallingForPreLogin(value) async {
    try {
      Response response;
      print("DatatCallingmap:-");
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "isLeaderboardDisplay": value
      };
      print("map:-" + map.toString());

      response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_LEADERBOARD_SETTING, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setBool(UserPreference.IS_PRE_LOGIN, value);
            isPreLoginSetting = value;
            setState(() {});
          }
        }
      }
    } catch (e) {
      print("Errorr:-" + e.toString());
      e.toString();
    }
  }

  Future apiCallingUpdateDialogStatus() async {
    try {
      Response response;
      print("DatatCallingmap:-");
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "featureKey": [],
        "display": false
      };

      print("map   ENDPOINT_UPDATE_DIALOG_STATUS:-" + map.toString());
      response = await  ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_DIALOG_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            setState(() {});
          }
        }
      }
    } catch (e) {
      print("Errorr:-" + e.toString());
      e.toString();
    }
  }

  onTapPreLogin() async {
    await Navigator.push(
        Constant.applicationContext,
         MaterialPageRoute(
            //   builder: (context) =>  DashBoardWidget()));
            builder: (context) =>  ParticipateInLeaderBoardWidget()));
    isPreLoginSetting = prefs.getBool(UserPreference.IS_PRE_LOGIN);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        apiCallingUpdateDialogStatus();
      },
      child: Scaffold(
          backgroundColor:  ColorValues.WHITE,
          appBar: AppBar(
              elevation: 0.0,
              backgroundColor:  ColorValues.WHITE,
              leading:  InkWell(
                child: Container(
                    child: Image.asset('assets/newFeature/Vector.png',
                        height: 15, width: 15)),
                onTap: () {
                  Navigator.pop(context, 'coachMarkProfile');
                  apiCallingUpdateDialogStatus();
                },
              )),
          body: ListView(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                            margin: const EdgeInsets.only(
                                left: 20, right: 20, top: 29.98),
                            child: Text('Introducing  Features',
                                style: TextStyle(
                                    fontSize: 25,
                                    fontFamily: 'Nunito',
                                    fontWeight: FontWeight.bold))),
                        roleId == "1"
                            ? Container(
                                margin:
                                    const EdgeInsets.only(left: 20, top: 20),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(top: 2.0),
                                      child: Image.asset(
                                          'assets/coach_mark/intro_video.png',
                                          height: 29,
                                          width: 29),
                                    ),
                                    SizedBox(height: 24, width: 12),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text('Introductory Video',
                                            style: TextStyle(
                                                fontSize: 18,
                                                fontFamily:Constant.TYPE_CUSTOMREGULAR,color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontWeight: FontWeight.w600)),
                                        SizedBox(height: 5),
                                        Container(
                                            //height: 57,
                                            width: 293,
                                            child: RichText(
                                                text: TextSpan(
                                                    text:
                                                        "Include a brief video recording introducing yourself. Make sure its brief and clear.",
                                                    style: TextStyle(
                                                      fontSize: 14,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    ),
                                                    children: [

                                                ])))
                                      ],
                                    )
                                  ],
                                ),
                              )
                            :  Container(
                                height: 0.0,
                              ),
                        Container(
                          margin: const EdgeInsets.only(left: 20, top: 20),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 2.0),
                                child: Image.asset(
                                    'assets/coach_mark/end_user.png',
                                    height: 30,
                                    width: 30),
                              ),
                              SizedBox(height: 20, width: 12),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Profile Visibility To End User',
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontFamily:Constant.TYPE_CUSTOMREGULAR,color:  ColorValues.HEADING_COLOR_EDUCATION,
                                          fontWeight: FontWeight.w600)),
                                  SizedBox(height: 5),
                                  Container(
                                      //height: 57,
                                      width: 293,
                                      child: RichText(
                                          text: TextSpan(
                                              text:
                                                  'Define and set exactly what parts of your profile you want other users to see.',
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,),
                                              children: [

                                          ])))
                                ],
                              )
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                              margin: const EdgeInsets.only(left: 20, top: 30),
                              child: Text('Feature Enhancement',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontFamily: Constant.TYPE_CUSTOMBOLD,color:  ColorValues.HEADING_COLOR_EDUCATION,
                                      ))),
                          roleId == "1"
                              ? Container(
                                  margin:
                                      const EdgeInsets.only(left: 20, top: 20),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(top: 2.0),
                                        child: Image.asset(
                                            'assets/coach_mark/youtube.png',
                                            height: 30,
                                            width: 28.5),
                                      ),
                                      SizedBox(height: 20, width: 12),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.fromLTRB(0.0,3,0,0),
                                            child: Container(
                                              //width: 295,
                                              child: Text('Presentation View',
                                                  style: TextStyle(
                                                      fontSize: 18,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                      fontWeight:
                                                          FontWeight.w600)),
                                            ),
                                          ),
                                          SizedBox(height: 5),
                                          Container(
                                              //height: 57,
                                              width: 293,
                                              child: RichText(
                                                  text: TextSpan(
                                                      text:
                                                          'With a simple toggle, convert your profile into a presentation and share a custom view to meet your needs.',
                                                      style: TextStyle(
                                                          fontSize: 14,
                                                          fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION),
                                                      children: [])))
                                        ],
                                      )
                                    ],
                                  ),
                                )
                              :  Container(
                                  height: 0.0,
                                ),

                        ],
                      ),
                    ),
                  )
                ],
              ),
            ],
          )),
    );
  }
}
