import 'dart:io';

class SpiderChartModel {
  String _id,importance,name,importanceTitle;

  SpiderChartModel(this._id, this.importance, this.name, this.importanceTitle);


}

