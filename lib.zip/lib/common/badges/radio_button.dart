import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/style.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class MyRadioOption<T> extends StatelessWidget {
  final T value;
  final T groupValue;
  final String text;
  final ValueChanged<T> onChanged;

  const MyRadioOption({
    this.value,
    this.groupValue,
    this.text,
    this.onChanged,
  });

  Widget _buildLabel() {
    final bool isSelected = value == groupValue;

    return SizedBox(
      height: 5,
      child: Theme(
          data: ThemeData(
           // unselectedWidgetColor: Color(0xff151515).withOpacity(0.8),

          ),
          child: Radio<T>(

            activeColor: Color(0xff4684EB),
            hoverColor: ColorValues.WHITE,
            value: value,

            groupValue: groupValue,
            onChanged: (T value) {
              onChanged(value);
            },
          )),
    );
  }

  Widget _buildText() {
    return Container(
      transform: Matrix4.translationValues(-8.0, 0.0, 0.0),
      child: Text(
        text,
        style: TxtStyle.nunito_14_400Black,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onChanged(value),
      splashColor: Colors.cyan.withOpacity(0.5),
      child: Row(
        children: [
          _buildLabel(),
          _buildText(),
        ],
      )
    );
  }
}
