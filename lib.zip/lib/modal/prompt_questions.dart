class PromptQuestions {
  String status;
  Result result;

  PromptQuestions({this.status, this.result});

  PromptQuestions.fromJson(Map<String, dynamic> json) {
    status = json['status']??"";
    result =
    json['result'] != null ? new Result.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class Result {
  int promptId;
  List<Questions> questions;

  Result({this.promptId, this.questions});

  Result.fromJson(Map<String, dynamic> json) {
    promptId = json['prompt_id']??0;
    if (json['questions'] != null) {
      questions = <Questions>[];
      json['questions'].forEach((v) {
        questions.add(new Questions.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['prompt_id'] = this.promptId;
    if (this.questions != null) {
      data['questions'] = this.questions.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Questions {
  var sId;
  var promptQuestionId;
  String promptQuestion;
  var promptQuestionSequence;

  Questions(
      {this.sId,
        this.promptQuestionId,
        this.promptQuestion,
        this.promptQuestionSequence});

  Questions.fromJson(Map<String, dynamic> json) {
    sId = json['_id']??"";
    promptQuestionId = json['prompt_question_id']??0;
    promptQuestion = json['prompt_question']??"";
    promptQuestionSequence = json['prompt_question_sequence']??0;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['prompt_question_id'] = this.promptQuestionId;
    data['prompt_question'] = this.promptQuestion;
    data['prompt_question_sequence'] = this.promptQuestionSequence;
    return data;
  }
}