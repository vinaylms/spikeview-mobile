import 'dart:async';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:adhara_socket_io/manager.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/home/TagDetailWidget.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/linkPreview/whatsapp/view.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/notification/model/UserDetailForReport.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class StudentProfileReportWidgetBoat extends StatefulWidget {
  String feedId, pageName,requestId,roleId;

  StudentProfileReportWidgetBoat(this.feedId, this.pageName,this.requestId,this.roleId);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  StudentProfileReportWidgetBoatState();
  }
}

class StudentProfileReportWidgetBoatState extends State<StudentProfileReportWidgetBoat> {
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isLoading = true;
  UserDetailForReport userDetailForReport;
  String dob;
  RegExp exp =  RegExp(
      r"(http|ftp|https|Https|Http)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");

  showSucessMsg(msg, context, duration, maxLine) {
    /*Timer _timer;

    print("timer on");
    _timer =  Timer(Duration(milliseconds: duration), () async {
      print("timer off");
      Navigator.pop(context);
     onBack();
    });

    showDialog(
        context: context,
        builder: (_) =>
         WillPopScope(
            onWillPop: () {
            },
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: maxLine == 2 ? 65.0 : 85.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: maxLine,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            negativeText: 'OK',
            msg: msg,
            isSucessPopup: true,
            onNegativeTap: (){
              onBack();
            },
          );
        });
  }


  void conformationDialogForCommunityPost(msg,value) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    msg,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.GREY_TEXT_COLOR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "OK",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallingForUpdate();
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  showErrorMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: 'ERROR: ',
                                    style:  TextStyle(
                                      color:  Color(0xffFF0101),
                                      height: 1.2,
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: msg,
                                        style:  TextStyle(
                                            color:  Color(0xffFF0101),
                                            fontSize: 13.0,
                                            fontWeight: FontWeight.normal,
                                            fontFamily: Constant.customRegular),
                                      )
                                    ],
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }



  Future apiCallingForGetData() async {
    try {
      Response response;

      Map map = {

        "userId": widget.feedId,

        "roleId": widget.roleId,

        "requestId":widget. requestId

      };
      print("map:-" + map.toString());

      response = await  ApiCalling().apiCallPostWithMapData(
          context, Constant.REPORT_FEED_DATA, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
           userDetailForReport=    UserDetailForReport.fromJson(response.data);
           setState(() {

           });
        }
      }
    } catch (e) {
      e.toString();
    }
  }
  Future apiCallingForUpdate() async {
    try {
      Response response;

      Map map = {
        "userId": userIdPref,
        "roleId": roleId,
        "id": widget.feedId,
        "reportType": "Profile",
      };
      print("map:-" + map.toString());

      response = await  ApiCalling().apiCallPutWithMapData(
          context, Constant.REPORT_FEED_UNBLOCK, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
if(widget.requestId!=null&&widget.requestId!="null"&&widget.requestId!="") {
  apiCallingForGetData();
}
  }

  onBack() async {
    if (widget.pageName == "") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);

      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
             DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
             DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>
             DashBoardWidget(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    getSharedPreferences();
    print("==================== INIT STATE");
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    Widget _loader(BuildContext context, String placeHolderImage) =>
        Center(
            child: Container(
              child:   Image.asset(
                placeHolderImage,
                fit: BoxFit.cover,
              ),
            ));

    Widget _error(String placeHolderImage) {
      return Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.fill,
        ),
      );
    }

    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {} else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }


    Container getSelectedWidgets() {


      return  Container(
        //color: Colors.redAccent,
        child: MediaQuery.removePadding(
          context: context,
          removeTop: true,
          removeBottom: true,
          child: ListView(
            physics: const NeverScrollableScrollPhysics(),
            primary: true,
            shrinkWrap: true,
            children: <Widget>[
              Wrap(
                spacing: 5.0,
                runSpacing: 0.0,
                children: List<Widget>.generate(
                    userDetailForReport.result.report.reasonType.length,
                    // place the length of the array here
                        (int index) {
                      //int h = _items[index].name.toString().length % 36;
                      //print('Height h:::: $h');
                      return InputChip(
                        shape: RoundedRectangleBorder(borderRadius:
                        BorderRadius.all(Radius.circular(0))),


                        label: Text(
                          '${userDetailForReport.result.report.reasonType[index]}',
                          overflow: TextOverflow.clip,
                          style: TextStyle(
                            fontSize: 14.0,fontFamily:
                          Constant.TYPE_CUSTOMREGULAR,
                          ),
                        ),
                        // softWrap: true,maxLines: 100,
                        //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        backgroundColor:    Color(0xffC1E3FC),

                        onSelected: (bool value) {},


                        labelStyle: AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,16.0,FontType.Regular),/*TextStyle(
                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 16,fontFamily:
                        Constant.TYPE_CUSTOMREGULAR,
                        ),*/
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5.0, vertical: 3.0),
                      );
                    }).toList(),
              ),
            ],
          ),
        ),
      );


    }



    return  WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:  Scaffold(
            backgroundColor: Color(0xffE5E5E5),
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      onBack();
                    },
                  )
                ],
              ),
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Profile Report",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              actions: <Widget>[
                 Container(
                  width: 35.0,
                ),
              ],
              backgroundColor: Colors.white,
              elevation: 1.0,
            ),bottomNavigationBar:

        userDetailForReport!=null&&userDetailForReport.result.isArchived?Container(
          color: Colors.white,
          child: PaddingWrap
              .paddingfromLTRB(
              0.0,
              10.0,
              0.0,
              10.0,  Container(
                  color: Colors.white,
                  padding:  EdgeInsets.all(0.0),
                  child:    PaddingWrap
          .paddingfromLTRB(
    13.0,
    0.0,
    13.0,
    0.0,Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                      Expanded(
                        child:  InkWell(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(
                                0, 0.0, 0, 0),
                            child:  Container(
                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                width: 120.0,
                                height: 40.0,
                                child: Center(
                                  child:  Text(
                                    "Unblock",
                                    textAlign: TextAlign.center,
                                    style:  TextStyle(
                                        color: Colors.white,
                                        fontSize: 16.0,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                  ),
                                )),
                          ),
                          onTap: () {
                            apiCallingForUpdate();
                          },
                        ),
                        flex: 1,
                      )
                    ],
                  )))),
        ):SizedBox(),
            body: userDetailForReport==null?new Container(): Column(
              children: <Widget>[
                Container(
                  height: 180.0,
                  child: Stack(
                    children: [
                       Positioned(
                        top: 0.0,

                        left: 0.0,
                        right: 0.0,
                        child: Container(
                          height: 180.0,
                          color:   ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
                          child:   Stack(
                            children: <Widget>[
                              Positioned(
                                top: 0.0,
                                bottom: 0.0,
                                left: 0.0,
                                right: 0.0,
                                child: userDetailForReport != null &&
                                    userDetailForReport.result != null &&
                                    userDetailForReport.result.coverImage != ""
                                    ?   Stack(
                                  children: <Widget>[
                                    Positioned(
                                      child:

                                      CachedNetworkImage(
                                        imageUrl: Constant.IMAGE_PATH_SMALL +
                                            ParseJson.getMediumImage(
                                                userDetailForReport
                                                    .result.coverImage),
                                        fit: BoxFit.cover,
                                        placeholder: (context, url) =>
                                            _loader(context, ""),
                                        errorWidget: (context, url, error) =>
                                            _error(""),
                                      ),
                                      top: 0.0,
                                      bottom: 0.0,
                                      left: 0.0,
                                      right: 0.0,
                                    ),
                                    Positioned(
                                      child:   Container(
                                        child:   Image.asset(
                                          "assets/newDesignIcon/navigation/layer_cover.png",
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                      top: 0.0,
                                      bottom: 0.0,
                                      left: 0.0,
                                      right: 0.0,
                                    )
                                  ],
                                )
                                    :   Container(
                                  child:   Image.asset(
                                    "assets/newDesignIcon/navigation/layer_cover.png",
                                    fit: BoxFit.fill,
                                  ),
                                )

                              ),
                              Positioned(
                                  top: 0.0,

                                  left: 0.0,
                                  right: 0.0,
                                  child:   Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          10.0,
                                          25.0,
                                          0.0,
                                          0.0,
                                          Container(
                                              child:   Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap.paddingAll(
                                                        10.0,
                                                        Container(
                                                          width: 111.0,
                                                          height: 111.0,
                                                          child:   Stack(
                                                            children: <Widget>[
                                                              Center(
                                                                  child:   InkWell(
                                                                    onTap: (){
                                                                      Util.onTapImageTile(
                                                                          tapedUserRole: widget.roleId,
                                                                          partnerUserId: widget.feedId
                                                                              .toString(),
                                                                          context: context);          },
                                                                    child: Container(
                                                                      child:   ClipOval(
                                                                        child: userDetailForReport
                                                                            .result !=
                                                                            null
                                                                            ?   CachedNetworkImage(
                                                                          imageUrl:
                                                                          /*profileInfoModal != null
                              ?*/
                                                                          Constant
                                                                              .IMAGE_PATH_SMALL +
                                                                              ParseJson
                                                                                  .getMediumImage(
                                                                                  userDetailForReport
                                                                                      .result
                                                                                      .profilePicture)
                                                                          /*: ""*/,
                                                                          fit: BoxFit.cover,
                                                                          placeholder: (context,
                                                                              url) =>
                                                                              _loader(context,
                                                                                 widget.roleId=="4"?"assets/profile/partner_img.png": "assets/profile/user_on_user.png"),
                                                                          errorWidget: (context,
                                                                              url,
                                                                              error) =>
                                                                              _error(
                                                                                  widget.roleId=="4"?"assets/profile/partner_img.png": "assets/profile/user_on_user.png"),
                                                                        )
                                                                            :   Image.asset(
                                                                          widget.roleId=="4"?"assets/profile/partner_img.png": "assets/profile/user_on_user.png",
                                                                        ),
                                                                      ),
                                                                      width: 111.0,
                                                                      height: 111.0,
                                                                      padding:   EdgeInsets
                                                                          .fromLTRB(
                                                                          0.0, 0.0, 0.0, 0.0),
                                                                    ),
                                                                  )),
                                                            ],
                                                          ),
                                                        )),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        5.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        Container(
                                                            child:   Column(
                                                              mainAxisAlignment: MainAxisAlignment
                                                                  .center,
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                              children: <Widget>[
                                                                userDetailForReport == null
                                                                    ?   Container(
                                                                  height: 0.0,
                                                                )
                                                                    : Container(
                                                                  child: Padding(
                                                                      padding: const EdgeInsets
                                                                          .only(
                                                                          top: 2.0, right: 0.0),
                                                                      child: RichText(
                                                                          maxLines: 3,
                                                                          textAlign: TextAlign
                                                                              .start,
                                                                          text: TextSpan(
                                                                              text: userDetailForReport
                                                                                  .result ==
                                                                                  null
                                                                                  ? ""
                                                                                  : userDetailForReport
                                                                                  .result
                                                                                  .lastName ==
                                                                                  null ||
                                                                                  userDetailForReport
                                                                                      .result
                                                                                      .lastName ==
                                                                                      "" ||
                                                                                  userDetailForReport
                                                                                      .result
                                                                                      .lastName ==
                                                                                      "null"
                                                                                  ? userDetailForReport
                                                                                  .result
                                                                                  .firstName ==
                                                                                  null
                                                                                  ? ""
                                                                                  : userDetailForReport
                                                                                  .result
                                                                                  .firstName
                                                                                  : userDetailForReport
                                                                                  .result
                                                                                  .firstName +
                                                                                  " " +
                                                                                  userDetailForReport
                                                                                      .result
                                                                                      .lastName,
                                                                              style:   TextStyle(
                                                                                color: Colors
                                                                                    .white,
                                                                                fontSize:24.0,
                                                                                fontWeight:
                                                                                FontWeight
                                                                                    .normal,
                                                                              ),
                                                                              ))),
                                                                ),
                                                                userDetailForReport.result ==
                                                                    null ||
                                                                    userDetailForReport
                                                                        .result.tagline ==
                                                                        "" ||
                                                                    userDetailForReport
                                                                        .result.tagline ==
                                                                        "null"
                                                                    ?   Container(
                                                                  height: 0.0,
                                                                )
                                                                    : PaddingWrap.paddingfromLTRB(
                                                                    5.0,
                                                                    0.0,
                                                                    10.0,
                                                                    15.0,
                                                                    Text(
                                                                      userDetailForReport
                                                                          .result ==
                                                                          null ||
                                                                          userDetailForReport
                                                                              .result
                                                                              .tagline ==
                                                                              "" ||
                                                                          userDetailForReport
                                                                              .result
                                                                              .tagline ==
                                                                              "null"
                                                                          ? ""
                                                                          : userDetailForReport
                                                                          .result.tagline,
                                                                      textAlign: TextAlign.start,
                                                                      maxLines: 3,
                                                                      overflow: TextOverflow
                                                                          .ellipsis,
                                                                      style:   TextStyle(
                                                                        /*  shadows: <Shadow>[
                                                            Shadow(
                                                              offset: Offset(0.0, 2.0),
                                                              blurRadius: 2.0,
                                                              color: Colors.black.withOpacity(.2),
                                                            ),
                                                          ],*/
                                                                          color:
                                                                          ColorValues.SEARCH_CATEGORY_BOX_BG,
                                                                          fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                                          fontSize: 18.0),
                                                                    ))
                                                              ],
                                                            ))),
                                                    flex: 1,
                                                  )
                                                ],
                                              ))),
                                    ],
                                  )),

                            ],
                          ),
                        ),
                      ),

                    ],
                  ),
                ),
                userDetailForReport.result.summary == null ||userDetailForReport.result.summary == "" ||
                    userDetailForReport.result.summary == "null"
                    ?Container(height: 0.0,):
                PaddingWrap.paddingfromLTRB(
                    13.0,
                    15.0,
                    13.0,
                    0.0,
                    Container(
                        child: Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                    color: ColorValues.BORDER_COLOR, width: 0.5)),
                            child: Container(
                                color: Colors.white,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  17.0,
                                                  10.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap.textViewSingleLine(
                                                      "Summary",
                                                      TextAlign.start,
                                                      ColorValues
                                                          .HEADING_TEXT_CUSTOMPROFILE,
                                                      20.0,
                                                      FontWeight.normal)),
                                              PaddingWrap.paddingfromLTRB(
                                                  19.0,
                                                  10.0,
                                                  0.0,
                                                  12.0,
                                                  Image.asset(
                                                    "assets/newDesignIcon/userprofile/line.png",
                                                    height: 3.0,
                                                    width: 40.0,
                                                  )),
                                            ],
                                          ),
                                        ),

                                      ],
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        17.0,
                                        0.0,
                                        17.0,
                                        13.0,
                                        Text(
                                            userDetailForReport.result.summary == "" ||      userDetailForReport.result.summary == null ||
                                                userDetailForReport.result.summary == "null"
                                                ? "No Information Available"
                                                :  userDetailForReport.result.summary,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines:  userDetailForReport.result.isShowSummary ? 100 : 3,
                                            style: TextStyle(
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                                fontSize: 14.0))),
                                    userDetailForReport.result.summary.length > 130 ||
                                        userDetailForReport.result.summary.split('\n').length > 2
                                        ? Align(
                                        alignment: Alignment.bottomLeft,
                                        child: InkWell(
                                          child: PaddingWrap.paddingfromLTRB(
                                              17.0,
                                              2.0,
                                              10.0,
                                              10.0,
                                              Text(
                                                userDetailForReport.result.isShowSummary ? "Less" : "More",
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.end,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 14.0,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                          onTap: () {
                                            if (userDetailForReport.result.isShowSummary) {
                                              setState(() {
                                                userDetailForReport.result.isShowSummary = false;
                                              });
                                            } else {
                                              setState(() {
                                                userDetailForReport.result.isShowSummary = true;
                                              });
                                            }
                                          },
                                        ))
                                        : Container(
                                      height: 10.0,
                                    )
                                  ],
                                ))))),


                userDetailForReport != null &&
                    userDetailForReport.result.report.reasonType.length > 0
                    ?
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap
                        .paddingfromLTRB(
                        13.0,
                        14.0,
                        13.0,
                        8.0,  Text(
                      "Reason Category",
                      textAlign: TextAlign.start,
                      style:  TextStyle(
                          color: Colors.black,
                          fontSize: 16.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    )),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(
                            13.0, 0, 13, 0),child: getSelectedWidgets()),


                    PaddingWrap.paddingfromLTRB(
                        13.0,
                        15.0,
                        13.0,
                        0.0,
                        Container(
                            child: Container(
                              width: double.infinity,
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(
                                        color: ColorValues.BORDER_COLOR, width: 0.5)),
                                child: Container(
                                    color: Colors.white,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[

                                        PaddingWrap.paddingfromLTRB(
                                            13.0,
                                            13.0,
                                            13.0,
                                            13.0,
                                            Text(
                                                 userDetailForReport.result.report.reason,
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: null,
                                                style: TextStyle(
                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                    color: ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontSize: 14.0))),

                                      ],
                                    ))))),
                  ],
                )



                    :     Container(
                  height: 0.0,
                )
              ],
            )));
  }

  Widget getText(String s, int color) {
    return Padding(
      padding: const EdgeInsets.only(left: 0.0),
      child:  Text(s,
          style: TextStyle(
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: Color(color),
              fontSize: 14.0)),
    );
  }
}
