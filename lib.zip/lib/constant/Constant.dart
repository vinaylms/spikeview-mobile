import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/painting.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class Constant {
  static bool V_CONTROL = true; // If true then Feature will
  // be visible to users applicable only for
  // V-1.1, for Below Version it would be false.

  //=====================FOR PRODUCTION==========================ENDPOINT_PROFILE_DATA
  /* static const String BASE_URL = "https://app.spikeview.com:3003/v1.12/";
  static const String ENDPOINT_SHARE_PROFILE_DOWNLOAD =
      "https://app.spikeview.com/userprofile_dwd/";
  static String CONTAINER_NAME = "spikeview-media-production";
  static const String REFER_BASE_URL = "https://app.spikeview.com/";
  static String CONTAINER_NAME_NEW = "spikeview-media-production-thumbnails";
  static String PUBLIC_URL_PATH = "https://app.spikeview.com/sv/";*/

  //=====================FOR DEVELOPMENT==========================
 //static const String BASE_URL = "http://125.99.189.202:3001/v1.14/";
  static const String BASE_URL = "http://125.99.189.202:3003/v1.14/";

  static const String ENDPOINT_SHARE_PROFILE_DOWNLOAD = "http://103.187.101.54:8001/userprofile_dwd/";
  static String CONTAINER_NAME = "spikeview-media-production";
  // static String CONTAINER_NAME = "spikeview-media-development";
  static const String REFER_BASE_URL = "http://103.21.53.11:3000/";
  static String CONTAINER_NAME_NEW = "spikeview-media-development-thumbnails";
  static String PUBLIC_URL_PATH = "https://app.spikeview.com/sv/";

  //=====================For QA/staging server ==========================

  //static const String BASE_URL = "http://103.21.53.11:3001/"; //dev
  /*static const String BASE_URL = "http://103.21.53.11:3004/"; //staging
  static String CONTAINER_NAME = "spikeview-media-development";
  static const String REFER_BASE_URL = "http://103.21.53.11:3000/";
   static  String CONTAINER_NAME_NEW ="spikeview-media-development-thumbnails";*/

  // ignore: missing_identifier, const_initialized_with_non_constant_value
  static const String ENCRYPTIONKEY = "sd5b75nb7577#^%\$%*&G#CGF*&%@#%*&";

  //old kGoogleApiKey key
  //static const kGoogleApiKey = "AIzaSyBmHbr9LxE6t5TbTriu_Vkgd8BdFU8A67w";

  static const String kGoogleApiKey = "AIzaSyA4219f1rGQ9YmvfjVWhDOnHN22mVoyu08";

  static const String VALIDATION_PASSWORD_LENGTH =
      "Password length must be 6 digit";

  static const int SERVICE_TIME_OUT = 30000;
  static const opportunityPredefinedType = 5;
  static const int CONNECTION_TIME_OUT = 60000;

  //http://103.21.53.11:3001/v1/ui/profile/share/updateStatus
  //   {userId: 304, roleId: 1, profileType: "Public", isActive: false}

  static String ROLE_ID = "";

/*  static const String IMAGE_PATH =  "http://server1.lmsin.com/rentalnew/uploads/property/";
  static const String BASE_IMAGE_PATH =  "http://server1.lmsin.com/rentalnew/uploads/";
  static const String COMMON_PATH =  "http://server1.lmsin.com/rentalnew/uploads/";
  static const String PROFILE_IMAGE_PATH =  "http://server1.lmsin.com/rentalnew/uploads/userProfile/";*/
  // http://spikeviewmediastorage.blob.core.windows.net/spikeview-media-development-thumbnails/sv_1031/profile/m-1546002856165hbShE.jpg

  static String PATH_FOR_VIDEO =
      "https://spikeview.azureedge.net/" + CONTAINER_NAME + "/";

  static String IMAGE_PATH =
      "https://spikeview.azureedge.net/" + CONTAINER_NAME + "/";
  static String IMAGE_PATH_SMALL =
      "https://spikeview.azureedge.net/" + CONTAINER_NAME + "/";
  static const String ENDPOINT_universities_list = "app/masters/universities";

  // static  String IMAGE_PATH_SMALL =  "http://spikeviewmediastorage.blob.core.windows.net/"+CONTAINER_NAME+"-thumbnails/";
  //static  String IMAGE_PATH_SMALL =  "http://spikeviewmediastorage.blob.core.windows.net/"+CONTAINER_NAME+"/";

  static const String ENDPOINT_Opportunity_detail_api =
      "ui/opportunity/opportunityDetails?opportunityId=";

  //static const String IMAGE_PATH =  "https://spikeviewmediastorage.blob.core.windows.net/spikeview-media-production/";
  static const String CONTAINER_COVER = "cover";
  static const String CONTAINER_FEED = "feeds";
  static const String CONTAINER_MEDIA = "media";
  static const String CONTAINER_ORGANIZATION = "oragnization";
  static const String CONTAINER_PROFILE = "profile";
  static const String CONTAINER_PREFIX = "sv_";
  static const String CONTAINER_PARTNER = "partnerMedia";
  static const String ENDPOINT_CATEGORY = "ui/category"; //GET TYPE
  static const String ENDPOINT_TIMEZONE = "ui/timeZone"; //GET TYPE
  static const String ENDPOINT_SUBJECTS = "ui/subjects"; //GET TYPE
  static const String ENDPOINT_QUALIFICATIONS = "ui/qualifications"; //GET TYPE
  static const String ENDPOINT_PROMPT_QUESTIONS =
      "ui/chatgpt/getQuestionByPrompt?prompt_id="; //GET TYPE
  static const String ENDPOINT_PROMPTS_IDS = "ui/chatgpt/prompts"; //GET TYPE
  static const String ENDPOINT_CATEGORY_SUBJECT =
      "ui/categorySubjects?oppCategoryId=";
  static const String COMMON_PATH =
      "http://server1.lmsin.com/rentalApp/uploads/";

  static const String ENDPOINT_RESET_PASSWORD = "app/resetPassword";

  static const String PROFILE_IMAGE_PATH =
      "http://server1.lmsin.com/rentalApp/uploads/userProfile/";
  static const String ENDPOINT_PROFILE_DATA = "ui/user/userProfileData?userId=";

  // REGISTRATION API KEY'S
  static const String ENDPOINT_REGISTRATION = "register";
  static const String ENDPOINT_SKIP_EMAIL = "ui/user/updateInvitedUser";
  static const String ENDPOINT_UPDATE_EMAIL_PROFILE =
      "ui/admin/addPersonalEmail";
  static const String ENDPOINT_BADGESCHANGESTATUS = "ui/badges";

  static const String ENDPOINT_RESEND_PROFILE = "ui/profile/resendProfile";
  static const String ENDPOINT_WELCOME_EMAIL = "ui/sendWelcomeMail/";
  static const String ENDPOINT_USER_ACTIVITY = "ui/userActivity";
  static const String ENDPOINT_FEED_DATA = "ui/feed/postList?userId=";
  static const String ENDPOINT_UPDATE_PARTNER_PROFILE =
      "ui/company/compuserAndcompanyProfile";
  static const String ENDPOINT_LOGIN = "app/login";

  // static const String ENDPOINT_LOGIN = "app/userLogin";
  static const String ENDPOINT_apiPerformanceDetail = "ui/apiPerformanceDetail";
  static const String ENDPOINT_UPDATE_EMAIL = "ui/user/changeEmail";
  static const String ENDPOINT_PARTNER_SIGNUP = "app/signup/partner";
  static const String ENDPOINT_NOTIFICATION_COUNT = "ui/header?userId=";
  static const String ENDPOINT_PARENT_SIGNUP = "app/signup";
  static const String CHANGE_EMAIL = "ui/user/changeEmail/";
  static const String ENDPOINT_FORGOT_PASSWORD = "app/forgotPassword?email=";
  static const String ENDPOINT_UPDATE_PUBLIC_PROFILE_STATUS =
      "ui/profile/share/updateStatus";
  static const String ENDPOINT_APP_VERSION = "ui/appVersion";
  static const String SETTINGS = "ui/setting";
  static const String ENDPOINT_GET_META_DATA = "ui/profile/getUrlMetaData";
  static const String ENDPOINT_SPIKE_BOT_USER =
      "ui/message/spikeViewBotFriend/info?userId=";
  static const String ENDPOINT_VALIDATE_REFERAL_CODE_API =
      "ui/user/checkReferalCode?referCode="; //wLJzOI3j1
  static const String ENDPOINT_GET_HOBBY_TYPE_API =
      "ui/hobbies?type="; //?type=goal_interests/ love_interests / other_interests /skills

  static const String ENDPOINT_FOROT_PASSWORD = "app/forgotPassword";
  static const String ENDPOINT_ADMIN_UPDATED_GROUP_REQUEST =
      "ui/group/updateMemberStatus";

  static const STUDENT_PROFILE_REPORTED = 'studentProfileReported';
  static const PARENT_PROFILE_REPORTED = 'parentProfileReported';
  static const PARTNER_PROFILE_REPORTED = 'partnerProfileReported';
  static const OPPORTUNITY_APPROVED = 'opportunity_approved';
  static const OPPORTUNITY_DECLINE = 'opportunity_decline';
  static const GROUP_REPORTED = 'groupReported';
  static const String ENDPOINT_CHANGE_PASSWORD = "ui/update/password";
  static const String ENDPOINT_PERSONAL_INFO = "ui/personalInfo/";
  static const String ENDPOINT_PERSONAL_INFO_NEW = "ui/personalInfoNew/";
  static const String ENDPOINT_GET_PREVIEW_DETAIL_IN_PUBLIC =
      "ui/getProfileView?publicUrl=";
  static const String ENDPOINT_GET_DATA_UPDATE =
      "ui/user/checkProfileUpdateFlag?userId=";
  static const String ENDPOINT_PROFILE_DETAIL =
      "ui/user/userProfileDetail?userId=";
  static const String ENDPOINT_PROFILE_SHARE_LOG =
      "ui/profile/sharedList?userId=";
  static const String ENDPOINT_CUSTOM_PROFILE_DETAIL =
      "ui/user/customProfileDetail?profileId=";
  static const String ENDPOINT_PROFILE_STATUS =
      "ui/profile/profileStatus?profileId=";
  static const String ENDPOINT_FOR_CONNECTED_USER =
      "ui/user/customProfileDetail?userId=";
  static const String ENDPOINT_ACCOMPLISHMENT_DETAIL =
      "ui/achievement/studentAchievementByLevel2?userId=";
  static const String ENDPOINT_SPIDER_AND_SKILL_DETAIL =
      "ui/achievement/spiderSkillChart?profileType=Custom&profileId=";
  static const String ENDPOINT_PUBLIC_AND_SKILL_DETAIL =
      "ui/achievement/spiderSkillChart?profileId=";
  static const String ENDPOINT_CONNECTED_AND_SKILL_DETAIL =
      "ui/achievement/spiderSkillChart?profileType=";
  static const String ENDPOINT_SPIDER_AND_SKILL_DETAIL_PUBLIC =
      "ui/achievement/spiderSkillChart?profileType=";
  static const String ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL =
      "ui/achievement/studentAchievementByLevel2?profileId=";
  static const String ENDPOINT_UPDATE_PROFILEL =
      "ui/profile/updateProfileSetting";
  static const String ENDPOINT_MEDIA = "ui/media/profile";
  static const String ENDPOINT_MEDIA_PARENT = "ui/mediaParent";
  static const String ENDPOINT_MEDIA_ACCOM = "/ui/mediaAccomplishment/";
  static const String ENDPOINT_SKILL = "ui/spider/skills/chart/";
  static const String ENDPOINT_COMPANY_INFO = "ui/company?userId=";
  static const String ENDPOINT_COMPANY_AND_PROFILE =
      "ui/company/compuserAndcompanyProfile";
  static const String ENDPOINT_UPDATE_ROLE = "ui/user/updateRole";
  static const String ENDPOINT_SKILL_API = "ui/hobbies?type=skills";
  static const String ENDPOINT_GET_SKILL_API = "ui/userHobby?userId=";
  static const String ENDPOINT_ADD_CERTIFICATE = "ui/certificates";
  static const String ENDPOINT_DELETE_SOCIAL_LINK =
      "ui/social/deleteSocialLink";
  static const String ENDPOINT_ADD_SKILL_API = "ui/userHobby";
  static const String ENDPOINT_SOCIAL_LINK = "ui/social/getSocialList";
  static const String ENDPOINT_ADD_SOCIAL_LINK = "ui/social/addSocialLink";
  static const String ENDPOINT_UPDATE_SOCIAL_LINK =
      "ui/social/updateSocialLink";
  static const String ENDPOINT_GET_SOCIAL_LINK_DATA =
      "ui/user/getUserSocialLinks?userId=";
  static const String ENDPOINT_REFER_POINTS =
      "ui/gamification?gamificationId=2";

//  static const String ENDPOINT_COMPANY_UPDATE = "app/company";
  static const String ENDPOINT_COMPANY_UPDATE = "ui/company";
  static const String ENDPOINT_COMPANY_DATA = "app/company";
  static const String ENDPOINT_OPPORTUNITY = "ui/opportunity?userId=";
  static const String ENDPOINT_CHAT_LIST = "ui/message/friendList/info?userId=";
  static const String ENDPOINT_NEW_CHAT_LIST =
      "ui/message/getFriendList/info?userId=";
  static const String UPDATE_SIGNUP_DATA = "ui/user/updateUserProfile";
  static const String ADD_PERSONAL_EMAIL = "ui/admin/addPersonalEmail";
  static const String SEND_OTP_ON_EMAIL = "ui/admin/verifySecEmail";

  //static const String ENDPOINT_CHAT_HISTORY = "ui/message?connectorId=";
  static const String ENDPOINT_CHAT_HISTORY = "ui/allMessage?connectorId=";

  static const String ENDPOINT_SHARE_ID = "ui/share/profile?sharedId=";
  static const String ENDPOINT_LOGOUT = "ui/logout";
  static const String ENDPOINT_GENERATE_PROMPT = "ui/chatgpt/generatePrompt";
  static const String ENDPOINT_SEARCH_GROUP_EMAIL =
      "ui/search/searchUsersForGroupByEmail?name=";
  static const String ENDPOINT_GET_BUSINESS_CATEGORY_API =
      "ui/businessCategory";

  ///----------------- aPURVA aDDED FOR COLLEGE MODULE START
  static const String ENDPOINT_GET_DEGREE = "ui/degree";
  static const String ENDPOINT_YEAR_LIST = "ui/education/yearList";
  static const String ENDPOINT_GET_USER_COLLOGE =
      "ui/education/getUserCollege?userId=";
  static const String ENDPOINT_UPDATE_COLLEGE_INFO = "ui/education/college";
  static const String ENDPOINT_COLLEGE_ORGANIZATION_LIST =
      "ui/organization?type=College";
  static const String ENDPOINT_EDUCATION_SCHOOL_COLLEGE =
      "ui/education/getUserEducation?userId=";

  ///-----------------aPURVA aDDED FOR COLLEGE MODULE END

  // static const String ENDPOINT_CHAT_LIST= "ui/connect/chatList?userId=";
  static const String ENDPOINT_NOTIFICATION_ALL_NEW =
      "ui/notification/getNotificationList?userId=";
  static const String ENDPOINT_CONNECTION_B_H_ZIPCODE =
      "ui/search/zipcode?userId=";
  static const String ENDPOINT_DISCOVER_GROUP =
      "ui/group/discoverGroups?userId=";
  static const String GET_GROUP_BY_TYPE = "ui/group/listByStatus?userId=";
  static const String GET_GROUP_STUDENT = "ui/group/getStudentGroupRequest?userId=";
  static const String ENDPOINT_NOTIFICATION_ALL = "ui/notification?userId=";
  static const String ENDPOINT_CHECK_IS_FRIEND = "ui/connect/status?userId=";
  static const String ENDPOINT_CHILD_LIST =
      "/ui/connect/getChildRequest?userId=";
  static const String ENDPOINT_CHILD_CONNECTION_STATUS =
      "/ui/connect/requestActionStatus?connectId=";
  static const String ENDPOINT_SHARE_LOG =
      "ui/share/profile/list?profileOwner=";
  static const String ENDPOINT_GROUPS = "ui/group/mygroups/";
  static const String ENDPOINT_GROUPS_ALL = "ui/group/mygroupdata/";
  static const String ENDPOINT_GROUPS_MEMBERS = "ui/group/members/";
  static const String ENDPOINT_CHECK_IS_SUBSCRIBE = "ui/subscription?userId=";
  static const String ENDPOINT_SHARE_PROFILE = "ui/share/profile";
  static const String ENDPOINT_FRIEND_LIST = "ui/mutual/friendlist?userId=";
  static const String ENDPOINT_SEARCH = "ui/search?name=";
  static const String ENDPOINT_REMOVE_COMMENT = "ui/remove/comment";
  static const String ENDPOINT_SUBSCRIBE = "/ui/subscription";

  static const String ENDPOINT_USER_CONNECTION_LIST =
      "ui/connect/chatList?userId=";
  static const String ENDPOINT_GROUP_MEMBER_LIST = "ui/group/members/";

  //static const String ENDPOINT_CONNECTION_LIST = "ui/connect/list?userId=";
  static const String ENDPOINT_CONNECTION_LIST_NEW_WITH_THREE_ENTRY =
      "ui/connect/commonList?userId=";

  static const String ENDPOINT_CONNECTION_LIST_VIEW_ALL =
      "ui/connect/listByStaus?userId=";

  static const String ENDPOINT_PENDING = "ui/referral";

  static const String ENDPOINT_CONNECTION_UPDATE = "ui/connect";
  static const String ENDPOINT_UPDATE_PARTNER_COMPANY =
      "ui/company/updateStatus";
  static const String ENDPOINT_CONNECTION_DELETE_UPDATE =
      "ui/connect/cancelRequest";
  static const String ENDPOINT_DELETE_GROUP_MEMBER =
      "/ui/group/updateMemberStatus";

  static const String ENDPOINT_CONNECTION_DETACH = "ui/user/detach";
  static const String ENDPOINT_ADD_RECOMMENDATION = "ui/recommendation";
  static const String ENDPOINT_UPDATE_GROUP_REQUEST =
      "ui/group/updateMemberStatus";
  static const String ENDPOINT_INVITE_BY_EMAIL = "ui/group/inviteMembers";
  static const String ENDPOINT_LEAVE_GROUP = "ui/group/leave";
  static const String ENDPOINT_FEED_UPDATE = "ui/feed/update";
  static const String ENDPOINT_NOTIFICATION_UPDATE = "ui/header";
  static const String ENDPOINT_UNSUBSCRIBE = "ui/emailSubscription";
  static const String ENDPOINT_FEED_DELETE = "ui/feed";
  static const String ENDPOINT_OPPORTUNITY_DELETE = "ui/opportunity/remove";
  static const String ENDPOINT_FEED_FORWARD = "ui/opportunity/forWardToParent";
  static const String ENDPOINT_NOTIFICATION_DELETE = "ui/notification";
  static const String ENDPOINT_ADD_LIKE = "ui/feed/addLike";
  static const String ENDPOINT_PARENT_PERSONAL_INFO = "ui/personalInfoByParent";
  static const String ENDPOINT_ADD_STUDENT = "ui/add/student";
  static const String ENDPOINT_COUNTRY_API = "ui/country";
  static const String ENDPOINT_NOTIFICATION_SETTING_UPDATY =
      "ui/user/notificationSetting";
  static const String ENDPOINT_LEADERBOARD_SETTING =
      "ui/updateLeaderBoardDisplayStatus";
  static const String ENDPOINT_UPDATE_DIALOG_STATUS =
      "ui/updateIntroducingFeatures";
  static const String ENDPOINT_COMMUNITY_SETTING =
      "ui/communityPostSubscription";
  static const String ENDPOINT_COMMUNITY_APPROVE = "ui/feed/updateStatus";
  static const String REPORT_FEED_UNBLOCK = "ui/report/validateReportedRequest";
  static const String REPORT_GROUP_UNBLOCK = "ui/group/reportedGroup?groupId=";
  static const String REPORT_FEED_DATA = "ui/reportedUser";
  static const String ENDPOINT_GET_NOTIFICATION_SETTING =
      "ui/user/notificationSetting?userId=";
  static const String ENDPOINT_OPPORTUNITY_APPROVE = "ui/opportunity/verify";
  static const String ENDPOINT_PARENT_PERSONAL_UPDATEUSER_STATUS =
      "ui/user/updateUserStatus";
  static const String ENDPOINT_SHARE_UPDATE = "ui/share/profile";
  static const String ENDPOINT_UPDATE_META_DATA = "ui/user/updateUser";
  static const String ENDPOINT_UPLOAD_RESUME = "ui/uploadResume";
  static const String ENDPOINT_UPDATE_SORT_ORDER_GROUP =
      "ui/achievement/updateSortOrder";
  static const String ENDPOINT_PROFILE_SHARE_UPDATE =
      "ui/profile/share/updateStatus";
  static const String ENDPOINT_PARENT_STUDENTSBYPARENT =
      "ui/user/studentsbyparent/";
  static const String ENDPOINT_EDUCATION = "ui/education?userId=";
  static const String ENDPOINT_TEST_SCORE_DATA = "ui/testCategory";
  static const String ENDPOINT_ADD_TEST_SCORE_DATA = "ui/addUserTestScore";
  static const String ENDPOINT_UPDATE_TEST_SCORE_DATA =
      "ui/updateUserTestScore";
  static const String ENDPOINT_GET_TEST_SCORE_DATA = "ui/getUserTestScore/";
  static const String ENDPOINT_DELETE_TEST_SCORE_DATA = "ui/userTest/";
  static const String ENDPOINT_RECOMMENDATION =
      "ui/user/recommendations?userId=";
  static const String ENDPOINT_SHARED_RECOMMENDATION =
      "ui/recommendation?recommendationId=";
  static const String ENDPOINT_ACC_REC_COUNT = "ui/counts/";

  //static const String ENDPOINT_ORGANIZATION_LIST = "ui/organization";
  static const String ENDPOINT_ORGANIZATION_LIST = "/ui/master/schools";
  static const String SCHOOL_SEACRH_API = "ui/master/schoolList";
  static const String ENDPOINT_GET_ALLEDUCATION_LIST = "/ui/education";
  static const String ENDPOINT_GET_hobbies_LIST = "/ui/hobbies";

  // static const String SCHOOL_SEACRH_LIST_API = "ui/master/schoolList";
  static const String SCHOOL_DETAIL_SCHOOLCODE =
      "ui/school/schoolByCode?schoolCode=";
  static const String ENDPOINT_ACHIEVMENT_LEVEL_LIST = "ui/importance";
  static const String ENDPOINT_ACHIEVMENT_SKILLS = "ui/skills";
  static const String ENDPOINT_MASTER_DATA = "app/masters/data";
  static const String ENDPOINT_ADD_ACHEVMENT = "ui/achievement";
  static const String ENDPOINT_ADD_INTRODUCTIO_VIDEO =
      "ui/profile/uploadIntroVideo";
  static const String ENDPOINT_UPDATE_UNDRER13_PROFILE_FILTER =
      "ui/profile/share/updateStatus";
  static const String ENDPOINT_UPDATE_STAGE = "ui/user/updateStage";
  static const String ENDPOINT_UPDATE_ADDED_ACHEVMENT =
      "ui/achievement/updateMedia";
  static const String ENDPOINT_REPORT = "ui/report";
  static const String ENDPOINT_DELETE_STUDENT = "ui/user/detach";
  static const String ENDPOINT_UPDATE_RECOMENDATION = "ui/recommendation";
  static const String ENDPOINT_EDIT_RECOMENDATION = "ui/edit/recommendation";

  static const String ENDPOINT_DELETE_RECOMMENDATION = "ui/recommendation";

  static const String ENDPOINT_DELETE_RECOMMENDATION_New =
      "ui/deleteRecommendation";
  static const String ENDPOINT_ADD_RECOOMENDATION = "ui/recommendation";

  static const String ENDPOINT_ADD_RECOOMENDATION_New =
      "ui/createRecommendation";
  static const String ENDPOINT_COMPENTENCY = "ui/competencyAllLevel";
  static const String ENDPOINT_ADD_ORGANIZATION = "ui/education";
  static const String ENDPOINT_USER_COVER_PHOTO_UPDATE = "ui/user";
  static const String ENDPOINT_GROUP_PHOTO_UPDATE = "ui/group";
  static const String ENDPOINT_JOIN_GROUP = "ui/group/join";
  static const String ENDPOINT_JOIN_GROUP_FORWARD =
      "ui/group/joinGroupForForwardToParent";
  static const String ENDPOINT_PARENT_ADD = "ui/add/parent";
  static const String ENDPOINT_ADD_GROUP = "ui/group";
  static const String ENDPOINT_ADD_INQUIRY = "ui/opportunity/inquireForm";
  static const String ENDPOINT_OPPORTUNITY_ADD_GROUP =
      "ui/opportunity/addGroup";
  static const String ENDPOINT_FEED_ADD_GROUP = "ui/feed/groupShare";
  static const String ENDPOINT_OPPORTUNITY_ADD_CONNECTION =
      "ui/opportunity/shareOpportunity";
  static const String ENDPOINT_UPDATE_GROUP = "ui/group/updateGroupInfo";
  static const String ENDPOINT_DETAIL_DASHBOARD = "ui/adminDashboardCategory";
  static const String ENDPOINT_SAS = "ui/azure/sas";
  static const String ENDPOINT_APP_SAS = "app/azure/sas";
  static const String ENDPOINT_NARRATIVE = "ui/narratives/";
  static const String ENDPOINT_SPIDER_CHART = "ui/spider/chart/";
  static const String ENDPOINT_ADD_FEED_COMMENT = "ui/feed/addComment";
  static const String ENDPOINT_INVITE_MEMBER = "ui/group/inviteMembers";

  static const String ENDPOINT_ADD_FEED = "ui/feed";
  static const String ENDPOINT_EDIT_FEED = "ui/feed/edit";
  static const String ENDPOINT_SHARE_FEED = "ui/share/feed";
  static const String ENDPOINT_REVIEW_API = "ui/review/";

  static const String ENDPOINT_GET_PRELOGIN_API = "ui/theme/prelogintheme";
  static const String ENDPOINT_GET_COUNTRY = "ui/country";
  static const String ENDPOINT_GET_HIGHLIGHTS_API =
      "ui/theme/preloginpagination?key=highlights&limit";
  static const String ENDPOINT_GET_EXPLORE_API =
      "ui/theme/preloginpagination?key=explore&limit=";
  static const String ENDPOINT_CREATE_PUBLIC_URL = "ui/createPublicUrl";

  static const String ENDPOINT_SEND_REMINDER = "ui/sendRecommendationReminder";
  static const String ENDPOINT_SEND_REMINDER_BADGES = "ui/sendBadgeReminder";
  static const String ENDPOINT_RECOMMENDATIONCount = "ui/recommendCount?";

  static const String ENDPOINT_BADGESCOUNT = "ui/badgeCount?";

  static bool IS_INDIVIDUAL = true;

  static BuildContext applicationContext;
  static String pageNameFr;
  static bool isAlreadyLoggedIn = false;
  static bool isBackVisible = false;
  static int currentIndex = 0;

  static String customRegular = Constant.TYPE_CUSTOMREGULAR;
  static String customItalic = "customItalic";
  static String customBold = Constant.TYPE_CUSTOMBOLD;

  static String REQUESTED = "2";
  static String ACCEPTED = "3";
  static String INVITED = "4";
  static String NON_CONNECTION = "1";
  static String SENT_REQUEST = "5";
  static String PEOPLE_YOU_MAY_KNOW = "6";
  static String PENDING = "7";
  static String RECIEVED = "8";
  static String DISCOVER = "9";
  static String CHILD_RECIEVED = "11";
  static String CHILD_SENT = "10";

  static String LINK_URL = "1";
  static String JOIN_GROUP = "2";
  static String CALL_NOW = "3";
  static String INQUIRE_NOW = "4";

  static String LEARN_MORE = "1";
  static String GET_OFFER = "2";
  static String APPLY_NOW = "3";

  static String CONST_REQUESTED = "Requested";
  static String CONST_REPLIED = "Replied";
  static String CONST_PENDING = "Pending";

  static String GROUP_TYPE_PUBLIC = "public";
  static String GROUP_TYPE_PRIVATE = "private";
  static Color CURSOR_COLOR = ColorValues.HEADING_COLOR_EDUCATION_2;

  static const String ENDPOINT_SEARCH_RESKIN = "ui/search/reskin?name=";

  static const String ENDPOINT_SEARCH_RESKIN_OPPORTUNITY =
      "ui/opportunitySearchList?name=";
  static const String ENDPOINT_OPPORTUNITY_CATEGORY =
      "ui/opportunityCategories";
  static const String ENDPOINT_SEARCH_RESKIN_BY_STATUS =
      "ui/search/reskinByStatus?name=";
  static const String ENDPOINT_PREVIOUS_OPORTUNITY =
      "ui/opportunity/previousOpportunity?userId=";

  static const String ENDPOINT_SEARCH_NON_SPIKE_VIEW_USER =
      "ui/search/reskinAllUser?name=";
  static const String ENDPOINT_COMPLETED_WIZARD = "ui/user/wizard/";
  static const String ENDPOINT_INCREASE_NUMBER_OF_COUNT =
      "ui/feed/numberOfClick?feedId=";
  static const String ENDPOINT_SEARCH_RESKIN_INVITE =
      "ui/search/notConnectedUser?name=";

  static const String ENDPOINT_SEARCH_INVITE_GROUP_MEMBER =
      "ui/group/inviteMultipleMemberForGroup";
  static const String ENDPOINT_SEARCH_INVITE_CONNECTION =
      "ui/connect/referNowForNonSpikeUser";

  static const String ENDPOINT_SEARCH_GROUP =
      "ui/search/inviteUsers?name=";

  static const String SPIKEVIEW_URL = "https://www.spikeview.com/";

  //-------------------------Badges-----------------
  static const String ENDPOINT_BADGES = "ui/badges/";
  static const String ENDPOINT_BADGE_REQUEST = "ui/requestBadges";
  static const String ENDPOINT_BADGE_LIST = "ui/getUserBadges";
  static const String ENDPOINT_BADGE_STATUS_UPDATE =
      "ui/updateBadgeRequestStatus";
  static const String ENDPOINT_GROUP_REQUESTED_BY_USER =
      "ui/group/groupRequestByUser?userId=";

  //---------------------------------------------------------

  static const String PRIVACY_POLICY =
      "https://app.spikeview.com/TermsPrivacyPolicy";

  /* static const String PRIVACY_POLICY =  "https://spikeviewmediastorage.blob.core.windows.net/spikeview-media-production/sv_1/PrivacyPolicy.html";
*/
  static const String ABOUT_US =
      "https://spikeviewmediastorage.blob.core.windows.net/spikeview-media-production/sv_1/About.html";

  static const String CARRER = "https://www.spikeview.com/careers/";
  static const String FAQ = "https://www.spikeview.com/faqs/";
  static const String TERMS =
      "https://spikeviewmediastorage.blob.core.windows.net/spikeview-media-production/sv_1/TermsAndConditions.html";

  static const String ENDPOINT_GET_ROLE = "app/roleType";
  static const String ENDPOINT_ASSIGN_ROLE_TO_GUEST =
      "ui/user/assignRoleToGuest";
  static const String ENDPOINT_RESEND_ACCOUNT_VERIFICATION =
      "ui/company/resendAccountVerification";

  static const String ENDPOINT_OTP_VERIFICATION = "ui/user/validateOTP";
  static const String ENDPOINT_OTP_RESEND = "ui/user/sendOTP";
  static const String ENDPOINT_UPDATE_PROFILE = "ui/userProfile";

  static const GROUP_TYPE = 'Group';
  static const GROUP_TYPE_INVITE = 'GroupInvite';
  static const PROFILE_TYPE = 'Profile';
  static const FEED_TYPE = 'Feed';
  static const FEED_TYPE_APPROVE = 'FeedApproval';
  static const CHAT_TYPE = 'Chat';
  static const SHARED_TYPE = 'Shared';
  static const USER_TYPE = 'Users';
  static const CONNECTIONS_TYPE = 'Connection';
  static const CONNECTIONS_PROFILE = 'ConnectionProfile';
  static const BADGE_TYPE = 'Badge';
  static const UNDER_13_TYPE = 'Under13Profile';
  static const UNDER_13_FILTER_PAGE = 'ProfileFilterPage';
  static const UNDER_13_GROUP_SCREEN = 'Under13GroupScreen';
  static const UNDER_13_PROFILE_VISIBILITY = 'ProfileVisibility';
  static const OPPORTUNITY_APPROVAL = 'OpportunityApproval';
  static const FEED_REPORTED = 'feedReported';

  static const ADMIN_TYPE = 'ADMIN_MSG';
  static const GROUP_SCREEN = 'GroupScreen';
  static const GROUP_PROFILE_TYPE = 'GroupProfile';
  static const PREVIEW_PROFILE_TYPE = 'previewprofile';
  static const PUBLIC_PROFILE_TYPE = 'publicprofile';
  static const REWARD_TYPE = 'Reward';
  static const Opportunity_TYPE = 'Opportunity';
  static const UNDER_13_FILTER_PAGE_Enabled = 'Under13ProfileEnable';

  //------------notification type for partner approval----------start
  static const partner_approved_TYPE = 'partner_approved';
  static const partner_decline_TYPE = 'partner_decline';
  static const partner_approval_TYPE = 'partner_approval';

  static const TYPE_CUSTOMREGULAR = 'LatoRegular';
  static const TYPE_CUSTOMBOLD = 'LatoSemibold';
  static const TYPE_CUSTOMITALIC = "customItalic";

  static const String latoRegular = 'LatoRegular';
  static const String latoMedium = 'LatoMedium';
  static const String latoSemibold = 'LatoSemibold';

  static const int PARENT_PROFILE_RESPONSE_MAX_TIME = 5;
  static const int COMPANY_RESPONSE_MAX_TIME = 6;
  static const int GROUP_RESPONSE_MAX_TIME = 5;
  static const int CHAT_RESPONSE_MAX_TIME = 5;
  static const int CONNECTION_RESPONSE_MAX_TIME = 6;
  static const int PROFILE_DATA_RESPONSE_MAX_TIME = 8;
  static const int FEED_DATA_RESPONSE_MAX_TIME = 5;

//------------notification type for partner approval----------end

//------------Link Redirection----------
  static const LINK_REDIRECTION_CONNECTION_REQUEST =
      "https://app.spikeview.com/student/connectionrequest/?connectId=";
  static const LINK_VIEWPROFILE =
      "https://app.spikeview.com/viewprofile/?connectId=";

//------------Link URL TYPE----------
  static const CONNECTION_REQUEST = 'connectionrequest';
  static const SUSCRIPTION = 'subscription';
  static const PREVIEWPROFILE = 'previewprofile';
  static const VIEWPROFILE = 'viewprofile';
  static String CURRENT_PAGE_NAME = 'Login';

  static const String ACCESS_CONTROL = "ui/user/accessControl?schoolCode=";

  //====================Firebase option ==========
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyBSgPtgZtJEqW1uNW2UO_5Jc4O0-KfqNtw',
    appId: '1:362044060578:ios:7bee5205456bb11afeb8fb',
    messagingSenderId: '362044060578',
    projectId: 'spikeview-6e41b',
    databaseURL: 'https://spikeview-6e41b.firebaseio.com',
    storageBucket: 'spikeview-6e41b.appspot.com',
    androidClientId:
        '362044060578-14l6jnskff81hs24ua5k0ml7ihf4glr3.apps.googleusercontent.com',
    iosClientId:
        '362044060578-cqjg4cgcdn7amp3h5c0j5om56lqb1jll.apps.googleusercontent.com',
    iosBundleId: 'com.spikeview.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBSgPtgZtJEqW1uNW2UO_5Jc4O0-KfqNtw',
    appId: '1:362044060578:android:160c66f392441b9afeb8fb',
    messagingSenderId: '362044060578',
    projectId: 'spikeview-6e41b',
    databaseURL: 'https://spikeview-6e41b.firebaseio.com',
    storageBucket: 'spikeview-6e41b.appspot.com',
  );

  static String RECOMMENDATIONBYTYPE = '/ui/recommendationByType?';
  static String BADGEBYTYPE = '/ui/badgeByType?';

  static const String ENDPOINT_LIKE_LIST_ALL ="ui/feed/like?userId=";
  static const String ENDPOINT_COMMENT_LIST_ALL ="ui/feed/comment?userId=";

  static const String ENDPOINT_STUDENT_PROFILE_PERSENT = "ui/user/profilePercent?";
}
