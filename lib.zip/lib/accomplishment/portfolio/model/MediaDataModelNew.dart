import 'dart:io';

import 'package:flutter/material.dart';

class MediaDataModelNew {
  String type = "";
  bool isSelectMedia = true;
  TextEditingController labelController =  TextEditingController(),
      statisticsController =  TextEditingController(),
      descController =  TextEditingController();

  List<FileDataModel> fileDataModelList =  List();

  MediaDataModelNew(
      this.labelController, this.statisticsController, this.descController,
      {this.type, this.isSelectMedia, this.fileDataModelList});

  getFileDateMdoe(){
    List<FileDataModel> fileDataModelListLocal =  List();
    for(FileDataModel data in fileDataModelList){
      if(data.filePath!=""){
        fileDataModelListLocal.add(data);
      }
    }

    return fileDataModelListLocal;
  }

  Map<String, dynamic> toJson() => {
        "label": labelController.text,
        "description": descController.text,
        "statistics": statisticsController.text,
        "file": getFileDateMdoe().map((item) =>item.toJson())
        .toList(),
        "type": this.type,
      };
}

class FileDataModel {
  String type = "", filePath;
  File thumbnailFile, imagePath;
  TextEditingController linkController;

  FileDataModel(
      {this.type,
      this.filePath,
      this.thumbnailFile,
      this.imagePath,
      this.linkController});

  Map<String, dynamic> toJson() => {
        "type": type,
        "file": filePath,

      };
}
