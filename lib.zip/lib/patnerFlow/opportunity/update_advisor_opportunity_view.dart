import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/component/CustomDropdownButtonNew.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_multiline_text_form.dart';
import 'package:spike_view_project/experiences/add_story_view.dart';
import 'package:spike_view_project/experiences/external_link_view.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/home/video_player_offline.dart';
import 'package:spike_view_project/modal/LinkUrlModel.dart';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geocoder/model.dart';
import 'package:geolocator/geolocator.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/home/OpportunityView.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/group/AddGroupWidget.dart';
import 'package:spike_view_project/modal/LocationData.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/TimeZoneModal.dart';
import 'package:spike_view_project/modal/patner/CategoryFormModel.dart';
import 'package:spike_view_project/modal/patner/DayTimeModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/age_between.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/modal/patner/designation_model_param.dart';
import 'package:spike_view_project/modal/patner/qualification_model_param.dart';
import 'package:spike_view_project/modal/patner/qualifications_model.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/modal/patner/user_image_model_param.dart';

import 'package:spike_view_project/modal/patner/subject_model_param.dart';
import 'package:spike_view_project/modal/patner/subjects_model.dart';
import 'package:spike_view_project/modal/patner/designation_model.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/SelectedCategoryModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/SelectedDesignationModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/add_google_doc_link_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/add_phone_number_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/call_to_action.dart';
import 'package:spike_view_project/patnerFlow/opportunity/create_link_url_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/group_list_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/interest.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/patnerFlow/opportunity/target_audience_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/patnerFlow/opportunity/Service.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';

import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/presoView/simple_animations/controlled_animation.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/list_external_link_item.dart';
import 'package:spike_view_project/widgets/list_image_view.dart';
import 'package:spike_view_project/widgets/list_video_item.dart';
import 'package:spike_view_project/widgets/positive_button.dart';
import 'package:spike_view_project/widgets/remove_button.dart';
import 'package:spike_view_project/widgets/stepper_widget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:spike_view_project/modal/patner/time_between.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart' as student;

import 'opportunity_view.dart';

class ModalBottomSheet extends StatefulWidget {
  List<CompetencyModel> listCompetency;

  ModalBottomSheet(this.listCompetency);

  _ModalBottomSheetState createState() =>
      _ModalBottomSheetState(listCompetency);
}

class _ModalBottomSheetState extends State<ModalBottomSheet>
    with SingleTickerProviderStateMixin {

  ScrollController _controller = ScrollController();
  List<CompetencyModel> listCompetency;
  _ModalBottomSheetState(this.listCompetency);

  Widget build(BuildContext context) {
    getIntrestDialog(List<Level2Competencies> level2Competencylist,
        CompetencyModel model) {
      return Container();

    }

/*    Widget getSelectedWidgets(List<Level2Competencies> level2Competencylist) {
      List<Widget> widgets = [];
      for (Level2Competencies item in level2Competencylist) {
        if (item.isSelected) {
          double width = item.name.length.toDouble() * 11;
          print('before width -> ' + width.toString());
          // if (width <= 60) {
          //   width = 80;
          // } else
          if (width > 100) {
            width = 100;
          }
          print('after width -> ' + width.toString());
          widgets.add(
            ControlledAnimation(
              duration: Duration(milliseconds: 0),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 0.0, end: width),
              builder: (context, value) {
                return ControlledAnimation(
                  duration: Duration(milliseconds: 500),
                  curve: Curves.linearToEaseOut,
                  delay: Duration(milliseconds: 700),
                  tween: Tween(begin: 50.0, end: width),
                  builder: (context, value) {
                    return Container(
                      margin: EdgeInsets.all(5),
                      child: Chip(
                        */
    /*shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5),
                          side: BorderSide(
                            color: Palette.accentColor,
                          ),
                        ),*/
    /*
                        backgroundColor: Palette.white,
                        deleteIcon: value >= (width)
                            ? Icon(Icons.cancel,
                                color:  ColorValues.BG_CIRCLE_COLOR)
                            : Icon(Icons.cancel,
                                color:  ColorValues.BG_CIRCLE_COLOR),
                        onDeleted: () {
                          setState(() {
                            item.isSelected = false;
                          });
                        },
                        label: Container(
                          alignment: AlignmentDirectional.center,
                          height: item.name.length > 16 &&
                                  item.name.length <= 40
                              ? 55
                              : item.name.length > 40 && item.name.length <= 50
                                  ? 80
                                  : item.name.length > 50 ? 110 : 30,
                          width: value + 5,
                          child: Text(
                            item.name,
                            maxLines: 6,
                            softWrap: true,
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          );
        }
      }

      return widgets.length == 0
          ?  Container(
              height: 0.0,
            )
          : PaddingWrap.paddingfromLTRB(
              13.0,
              0.0,
              13.0,
              0.0,
               Container(
                width: double.infinity,
                decoration:  BoxDecoration(
                    color: Colors.white,
                    border:  Border.all(
                        color:   ColorValues.DEVIDER_COLOR,
                        width: 1.0)),
                child: Wrap(children: widgets),
              ));

      //return widgets;
    }*/

    customCheckBox(bool isChecked) {
      return Image.asset(
        isChecked ? ImagePath.ICON_CHECKED : ImagePath.ICON_UNCHECKED,
        height: 20,
        width: 20,
        color: Palette.primaryTextColor,
      );
    }

    Column getCompetencyItem(position) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
              0.0,
              10.0,
              0.0,
              0.0,
              Container(
                  height: 50.0,
                  decoration: BoxDecoration(
                      color: ColorValues.TAB_BACKGROUND_COLOR,
                      // border:  Border.all(
                      //     color:   ColorValues.TAB_BACKGROUND_COLOR,
                      //     width: 1.0),
                      borderRadius: BorderRadius.circular(10)),
                  child: InkWell(
                      child: ListTile(
                        trailing: Padding(
                          padding: const EdgeInsets.only(bottom: 5),
                          child: Container(
                              padding: EdgeInsets.all(8.0),
                              height: 40.0,
                              width: 30.0,
                              child: Image.asset(
                                listCompetency[position].isSelected
                                    ? "assets/newDesignIcon/competency/up_arrow.png"
                                    : "assets/newDesignIcon/competency/down_arrow.png",
                                height: 15.0,
                                width: 15.0,
                              )),
                        ),
                        title: Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Text(
                            listCompetency[position].level1,
                            style: TextStyle(
                                fontFamily: Constant.latoRegular,
                                fontSize: 16.0,
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                      onTap: () {
                        print("clicked++++" +
                            listCompetency[position].isSelected.toString());

                        if (listCompetency[position].isSelected) {
                          listCompetency[position].isSelected = false;
                        } else {
                          listCompetency[position].isSelected = true;
                        }
                        setState(() {
                          listCompetency[position].isSelected;
                        });
                      }))),

          ///show selected list on collapse row
          // listCompetency[position].isSelected
          //     ?  Container(
          //         height: 0.0,
          //       )
          //     : getIntrestDialog(listCompetency[position].level2Competencylist,
          //         listCompetency[position]),

          listCompetency[position].isSelected
              ? PaddingWrap.paddingfromLTRB(
              0.0,
              10.0,
              0.0,
              5.0,
              Container(
                  decoration: BoxDecoration(
                    //color: Colors.white,
                    // border:  Border.all(
                    //     color:   ColorValues.DEVIDER_COLOR,
                    //     width: 1.0)
                  ),
                  child: Wrap(
                    spacing: 0.0,
                    runSpacing: 0.0,
                    children: listCompetency[position]
                        .level2Competencylist
                        .map((level) {
                      return Padding(
                          padding: const EdgeInsets.all(5),
                          child: Container(
                            decoration: BoxDecoration(
                              color: level.isSelected == true
                                  ? ColorValues.DARK_YELLOW
                                  : ColorValues.TAB_BACKGROUND_COLOR,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      if (level.isSelected) {
                                        level.isSelected = false;
                                      } else {
                                        level.isSelected = true;
                                      }
                                      bool isSelected = true;

                                      for (Level2Competencies level
                                      in listCompetency[position]
                                          .level2Competencylist) {
                                        if (!level.isSelected) {
                                          isSelected = false;
                                          break;
                                        }
                                      }

                                      setState(() {
                                        listCompetency[position].selectAll =
                                            isSelected;
                                        level.isSelected;
                                      });
                                    },
                                    child: Text(
                                      '${level.name}',
                                      style: TextStyle(
                                        fontSize: 16.0,
                                        fontFamily: Constant.latoRegular,
                                        fontWeight: FontWeight.w500,
                                        color: level.isSelected
                                            ? Colors.white
                                            : ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )

                        /*
                    child: InputChip(
                      label: Text(
                        '${_items[index].name}',
                        softWrap: true,
                      ),
                      backgroundColor: ColorValues.WHITE,
                      shape: StadiumBorder(
                        side: BorderSide(
                            color: ColorValues.BORDER_COLOR),
                      ),
                      onSelected: (bool value) {
                        if (!isSelected) {
                          //print("selected index:: $index");
                          toggalSelection1(isSelected, index);
                        }
                      },
                      labelStyle: TextStyle(
                        color:
                        ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12.0, vertical: 3.0),
                    )
                    ,
                     */

                      );
                    }).toList(),
                  )

                ///old
                /*
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children:  List.generate(
                              listCompetency[position]
                                      .level2Competencylist
                                      .length +
                                  1, (int index) {

                            return index == 0
                                ? PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                     Column(
                                      children: <Widget>[
                                         Container(
                                            height: 50.0,
                                            padding:  EdgeInsets.fromLTRB(
                                                13.0, 0, 13.0, 0),
                                            child:  InkWell(
                                              child: Row(
                                                children: <Widget>[
                                                  customCheckBox(
                                                      listCompetency[position]
                                                          .selectAll),
                                                  UIHelper
                                                      .horizontalGapBetweenBox,
                                                  Text(
                                                    "Select All",
                                                    style: AppTextStyle
                                                        .getDynamicFontStyle(
                                                            Palette
                                                                .primaryTextColor,
                                                            15,
                                                            FontType.Bold),
                                                  ),
                                                ],
                                              ),
                                              onTap: () {
                                                if (listCompetency[position]
                                                    .selectAll) {
                                                  setState(() {
                                                    listCompetency[position]
                                                        .selectAll = false;
                                                    for (Level2Competencies level
                                                        in listCompetency[
                                                                position]
                                                            .level2Competencylist) {
                                                      level.isSelected = false;
                                                    }
                                                  });
                                                } else {
                                                  setState(() {
                                                    listCompetency[position]
                                                        .selectAll = true;
                                                    for (Level2Competencies level
                                                        in listCompetency[
                                                                position]
                                                            .level2Competencylist) {
                                                      level.isSelected = true;
                                                    }
                                                  });
                                                }
                                              },
                                            )),

                                      ],
                                    ))
                                :
                            PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                     Column(
                                      children: <Widget>[
                                         Container(
                                            height: 50.0,
                                            padding:  EdgeInsets.fromLTRB(
                                                13.0, 0, 13.0, 0),
                                            child:  InkWell(
                                              child: Row(
                                                children: <Widget>[
                                                  customCheckBox(
                                                      listCompetency[position]
                                                          .level2Competencylist[
                                                              index - 1]
                                                          .isSelected),
                                                  UIHelper
                                                      .horizontalGapBetweenBox,
                                                  Text(
                                                    listCompetency[position]
                                                        .level2Competencylist[
                                                            index - 1]
                                                        .name,
                                                    style: AppTextStyle
                                                        .getDynamicFontStyle(
                                                            Palette
                                                                .primaryColor,
                                                            15,
                                                            FontType.Regular),
                                                  ),
                                                ],
                                              ),
                                              onTap: () {
                                                if (listCompetency[position]
                                                    .level2Competencylist[
                                                        index - 1]
                                                    .isSelected) {
                                                  listCompetency[position]
                                                      .level2Competencylist[
                                                          index - 1]
                                                      .isSelected = false;
                                                } else {
                                                  listCompetency[position]
                                                      .level2Competencylist[
                                                          index - 1]
                                                      .isSelected = true;
                                                }
                                                bool isSelected = true;

                                                for (Level2Competencies level
                                                    in listCompetency[position]
                                                        .level2Competencylist) {
                                                  if (!level.isSelected) {
                                                    isSelected = false;
                                                    break;
                                                  }
                                                }

                                                setState(() {
                                                  listCompetency[position]
                                                      .selectAll = isSelected;
                                                  listCompetency[position]
                                                      .level2Competencylist[
                                                          index - 1]
                                                      .isSelected;
                                                });
                                              },
                                            )),

                                        // (listCompetency[position]
                                        //                 .level2Competencylist
                                        //                 .length -
                                        //             2) ==
                                        //         index
                                        //     ?  Container(
                                        //         height: 0.0,
                                        //       )
                                        //     :  Divider(
                                        //         color:  ColorValues.DEVIDER_COLOR,
                                        //         height: 1.0,
                                        //       )
                                      ],
                                    ));
                          })
                      )



     */

                ///old

              ))
              : Container(
            height: 0.0,
          ),
        ],
      );
    }

    return Column(
      children: List.generate(listCompetency.length, (position) {
        return getCompetencyItem(position);
      }),
    );

    /*  ListView.builder(
        controller: _controller,
        itemCount: listCompetency.length,
        itemBuilder: (BuildContext context, int position) {
          return getCompetencyItem(position);
        });*/
  }
}


class UpdateAdvisorOpportunity extends StatefulWidget {
  /*String companyId, offerId;

  UpdateAdvisorOpportunity(this.companyId, this.offerId);*/

  OpportunityModel opportunityModel;
  String type, opportunityId;

  UpdateAdvisorOpportunity(this.opportunityModel, this.type,
      {this.opportunityId});

  @override
  State<StatefulWidget> createState() => UpdateAdvisorOpportunityState();
}

class UpdateAdvisorOpportunityState extends State<UpdateAdvisorOpportunity>
    with BaseCommonWidget {
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();
  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: Constant.kGoogleApiKey);
  List<LinkUrlModel> linkUrlListData = [];

  OpportunityModelForFeed selectedDataOpportunityPreview;

  bool scrollEnabled = true;
  ScrollController _roleListController =  ScrollController();
  ScrollPhysics scrollPhysics =  ScrollPhysics();
  NeverScrollableScrollPhysics neverScrollPhysics =
       NeverScrollableScrollPhysics();
  DateTime toDate, fromDate, toTime, fromTime, expiryDateTime;
  bool showList = false;
  DateFormat dateFormat = DateFormat('hh:mm a');

  bool isDeactivate = true;
  bool isMediaExpanded = false, isMediaSelected = false;
  bool isMetorImageSelected = false;
  String selectedGroupId;
  bool isGroupPublic = true;
  String googleDocLink,
      googleDocTitle,
      selectedGroup,
      selectedLink,
      selectedOfferLink,
      selectedApplyNowLink,
      selectedPhoneNumber;
  bool chooseExistingGroup = false;
  bool createNewGroup = false;

  bool isActionSelected = false;

  bool learnMore = true;
  bool getOffer = false;
  bool applyNow = false;
  bool isSelectInterestList = true;
  bool isTargetAudience = false;
  bool expiryValidation = false;

  // bool isSelectAction = false;
  var _locationArray = [
    "Select location",
    "Countries",
    "Cities",
    "Current city",
  ];
  var _genderArray = ["Select gender", "Male", "Female", "Non-Binary", "NA"];
  var _linkUrlArray = ["Learn more", "Get offer", "Apply now"];
  String selectedUrlOption = "Learn more";

  String selectAdvisorSupportOffered = "Advisor Support Offered";
  List<String> advisorSupportOfferedList = [
    "Advisor Support Offered",
    "Advisor Support Offered 1",
    "Advisor Support Offered 2",
    "Advisor Support Offered 3",
    "Advisor Support Offered 4"
  ];
  String selectedLocation = 'Select location';
  String selectedGender = "Select gender";
  String selectedAction;
  List<String> actionList = [
    "Link URL",
    "Join Group",
    "Call Now",
    "Inquire Now",
  ];
  List<IntrestModel> selectedIntrestDataList =  List();
  List<String> googleDoclinkList =  List();
  List<Item> countries =  List();
  List<Item> selectedCountries = [];

  final linkUrlController = TextEditingController();
  final linkFormKey = GlobalKey<FormState>();
  final FocusNode linkTitleFocus = FocusNode();


  final jobTitleController = TextEditingController();
  final serviceTitleController = TextEditingController();
  final serviceDescriptionController = TextEditingController();
  final jobTypeController = TextEditingController();
  final jobLocationController = TextEditingController();

  final bioController = TextEditingController();
  final projectAreasController = TextEditingController();
  final descriptionController = TextEditingController();
  final feesController = TextEditingController();
  final durationController = TextEditingController();
  final statusController = TextEditingController();

  final jobDateFromController = TextEditingController();
  final jobDateToController = TextEditingController();

  final titleController = TextEditingController();

  TextEditingController ageFromController = TextEditingController();
  TextEditingController ageToController = TextEditingController();

  final timeFromController = TextEditingController();
  final timeToController = TextEditingController();

  TextEditingController expiryDateController = TextEditingController();

  final searchCountryController = TextEditingController();

  final callToActionController = TextEditingController();

  final FocusNode _jobTitleFocus = FocusNode();
  final FocusNode serviceTitleFocus = FocusNode();
  final FocusNode serviceDescFocus = FocusNode();

  final FocusNode _jobTypeFocus = FocusNode();
  final FocusNode _jobLocationFocus = FocusNode();
  final FocusNode _bioFocus = FocusNode();
  final FocusNode _projectAreasFocus = FocusNode();
  final FocusNode _durationFocus = FocusNode();
  final FocusNode _statusFocus = FocusNode();
  final FocusNode _titleFocus = FocusNode();
  final FocusNode _descriptionFocus = FocusNode();
  final FocusNode _feesFocus = FocusNode();

  final GlobalKey<FormState> _jobFormKey = GlobalKey<FormState>();

  //final GlobalKey<FormState>  _audienceFormKey = GlobalKey<FormState>();
  List<AgeBetween> toFromAge = [];

  int dateFrom = 0;
  int timeFrom = 0;
  int dateTo = 0;
  int timeTo = 0;
  int expiryDate = 0;

 // CustomDropdownButton customDropdownButton;
  List<String> mediaAndVideoList =  List();
  List<String> mediaImagesList =  List();
  List<String> mentorImagesList =  List();
  List<FileModel> mediaVideosList =  List();
  List<String> mediaDocumentList = [];
  File mediaImage, mediaVideo, mediaDoc;
  File userImageFile;
  String userImageString = '';
  UploadMedia uploadMedia;
  DateTime startDate;
  List<AssetModel> assetModelMap = [];
  SharedPreferences prefs;
  String userIdPref, token;
  String sasToken, sasContainer;
  File imagePath;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String strPrefixPathforPhoto;
  List<CompetencyModel> listCompetency =  List();

  List<DesignationModelResult> designationList =  List();
  List<SubjectsModelResult> subjectList =  List();

  List<QualificationsModelResult> qualificationsList =  List();

  /*String selectedSubject='Select All';
  String selectedQualification='Select All';
  String selectedDesignation='Select All';*/
  bool isDesignationError = false;
  bool isQualificationError = false;
  bool isSubjectError = false;

  Color designationBottomViewColor = Palette.dividerColor;
  Color subjectBottomViewColor = Palette.dividerColor;
  Color qualificationBottomViewColor = Palette.dividerColor;
  final GlobalKey<AnimatedListState> _listDKey = GlobalKey();
  final GlobalKey<AnimatedListState> _listSKey = GlobalKey();
  final GlobalKey<AnimatedListState> _listQKey = GlobalKey();

  List<OperationNewClass> listData = [
    //OperationNewClass("12:00 PM","7:00 PM","All Days",false),
    OperationNewClass("Monday", false, false,  List<DayScheduleData>()),
    OperationNewClass("Tuesday", false,  false, List<DayScheduleData>()),
    OperationNewClass("Wednesday", false,false,   List<DayScheduleData>()),
    OperationNewClass("Thursday", false, false,  List<DayScheduleData>()),
    OperationNewClass("Friday", false, false,  List<DayScheduleData>()),
    OperationNewClass("Saturday", false, false,  List<DayScheduleData>()),
    OperationNewClass("Sunday", false,  false, List<DayScheduleData>()),
  ];

  String timeFromText = '';

  bool isDesignationOtherSelected = false;
  bool isSubjectOtherSelected = false;
  bool isQualificationOtherSelected = false;

  bool isShowMoreDesignation = true;
  bool isShowMoreSubject = true;
  bool isShowMoreQualification = true;

  bool showDesignationList = false;
  bool showSubjectList = false;
  bool showQualificationList = false;

  bool isShowMoreDesignationOther = true;
  bool isShowMoreSubjectOther = true;
  bool isShowMoreQualificationOther = true;

  CategoryFormModel _mCategoryFormModel;
  bool isCareerSelected = false;
  List<String> selectedDesignationCareerOption = [];
  bool isShowMoreCareerOther = true;
  final careerController = TextEditingController();
  final FocusNode _careerFocus = FocusNode();

  List<String> selectedDesignationOtherOption = [];
  List<String> selectedSubjectOtherOption = [];
  List<String> selectedQualificationOtherOption = [];

  List<SelectedDesignationModel> selectedDesignationOption = [];
  List<SelectedCategoryModel> selectedSubjectOption = [];
  List<String> selectedQualificationOption = [];

  final designationController = TextEditingController();
  final subjectController = TextEditingController();
  final qualificationController = TextEditingController();

  final FocusNode _otherDesignationFocus = FocusNode();
  final FocusNode _otherSubjectFocus = FocusNode();
  final FocusNode _otherQualificationFocus = FocusNode();

  List<DesignationModelResult> removedDesignationList =
       List<DesignationModelResult>();
  List<SubjectsModelResult> removedSubjectList =
       List<SubjectsModelResult>();
  List<QualificationsModelResult> removedQualificationList =
       List<QualificationsModelResult>();

  List<DesignationModelResult> orignalDesignationList =
       List<DesignationModelResult>();
  List<SubjectsModelResult> orignalSubjectList =
       List<SubjectsModelResult>();
  List<QualificationsModelResult> orignalQualificationList =
       List<QualificationsModelResult>();

  List<DesignationModelParam> selectedDesignationList =
       List<DesignationModelParam>();
  List<SubjectModelParam> selectedSubjectList =  List<SubjectModelParam>();
  List<QualificationModelParam> selectedQualificationList =
       List<QualificationModelParam>();

  List<ScheduleModelParam> selectedDayData =  List();
  List<UserImageModelParam> selecteduserImageData =  List();

  bool isAtleastOneTimeSlotSelected = false;

  bool isMenteeError = false;

  Color menteeBottomViewColor = Palette.dividerColor;


  /// variables -
  int currentStep = 0;
  PageController _pageController = PageController(keepPage: true);
  bool _isProcessEnable = false;
  bool _isProcessForStepTwoEnable = false;

  bool _showMediaError = false,
      _showLinkUrlError = false,
      _showAdvisorError = false,
      _showInvalidFormatePDFError = false,
      _showMentorImageError = false ,
      _showCreateGroupError = false,
      _showSelectGroupError = false,
      _showEmptyNumberError = false,
      _showSelectedDayError = false,
      _showAvailablityError = false,
      _showEmptyCallToError = false;

  ///Step Four on preview screen - \\
  String firstHalf = '';
  String secondHalf = '';
  bool flag = true;
  String firstHalfDesc = '';
  String secondHalfDesc = '';
  String location = "";
  String descVal = '';
  bool flagDesc = true;
  String categoryString = '';
  String subjectString = '';
  List<Assest> googleLinkList =  List();


  ///age from to selection
  bool visibleAgeFromToPrimary = false;
  // bool visiblePrimary = false;
  bool duplicateYear = false;
  List<int> years;
  int startAge, endAge;
  //int startYear, endYear;

  final ageYearFrom = TextEditingController();
  final ageYearTo = TextEditingController();

  int getEndYear() => endAge ?? startAge + 4;

  int get startIndex => years.indexWhere((e) => e == startAge);

  int get endIndex => years.indexWhere((e) => e == endAge);

  Color getFontColour(int index) {
    final year = years[index];
    if (startAge == year || endAge == year) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorder(index)) {
      return Color(0xFF4684EB);
    }
    return violetColor;
  }

  Color getBoxColour(int index) {
    final year = years[index];
    if (startAge == year || endAge == year) {
      return blueColor;
    } else if (showBorder(index)) {
      return Color(0xFFF3F5FF);
    }
    return Colors.white;
  }

  void setIndex(int index) {
    print('checking Index $index');
    setState(() {
      if (startIndex == -1) {
        startAge = years[index];
      } else if (startIndex == index) {
        startAge = null;
        endAge = null;
      } else if (endIndex == -1) {
        if (startIndex > index) {
        } else {
          endAge = years[index];
        }
      } else if (endIndex == index) {
        endAge = null;
      } else if (endIndex < index) {
        endAge = years[index];
      } else if (startIndex > index) {
        startAge = years[index];
      } else if (endIndex > index) {
        endAge = years[index];
      }
    });

    if (startAge != null && endAge != null) {
    } else {
      setState(() {
        ageYearFrom.text = "";
      });
    }

    if (duplicateYear) {
      setState(() {
        duplicateYear = false;
      });
    }
  }

  void setTextFieldValue() {
    if (endAge == null) {
      if (startAge == null) {
        ageYearFrom.text = "";
      } else {
        ageYearFrom.text = '$startAge';
      }
    } else {
      if (startAge == null || startAge == 0 || startAge == "null") {
        ageYearFrom.text = "";
      } else {

        ageYearFrom.text = '$startAge-$endAge';
      }
    }
    setState(() {});
  }

  bool showBorder(int index) {
    if (index > startIndex && index < endIndex) {
      return true;
    }
    return false;
  }



  Widget _loader(BuildContext context) => Center(
      child: Container(
        child:  Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.cover,
        ),
      ));

  Widget _error() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill,
      ),
    );
  }

  Widget getAgeList() {
    return

      Container(
          decoration: BoxDecoration(
            //color: Colors.white,
            // border:  Border.all(
            //     color:   ColorValues.DEVIDER_COLOR,
            //     width: 1.0)
          ),
          child: Wrap(
            spacing: 0.0,
            runSpacing: 0.0,
            children: selectedDataOpportunityPreview.ageList.map((level) {
              return Padding(
                  padding: const EdgeInsets.only(left: 0,right: 5,top: 5,bottom: 0),
                  child: Container(

                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          InkWell(
                            onTap: () {

                            },
                            child:

                            otherInformationValue(
                                level.from +
                                    "-" +
                                    level.to +
                                    " Years;"
                            ),
                            //   Text(
                            //     level.from +
                            //         "-" +
                            //         level.to +
                            //         " years;",
                            //     style: TextStyle(
                            //         fontFamily: Constant.latoRegular,
                            //         fontSize: 12,
                            //         color: ColorValues.labelColor,
                            //         fontWeight: FontWeight.w600
                            //     ),
                            //
                            //
                            // ),
                          )
                        ],
                      ),
                    ),
                  )


              );
            }).toList(),
          )


      );

    /*
      Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(selectedDataOpportunityPreview.ageList.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 2.0, 0.0, 0.0),
          child: Text(
            selectedDataOpportunityPreview.ageList[index].from +
                "-" +
                selectedDataOpportunityPreview.ageList[index].to +
                " years ",
            style: TextStyle(
                fontFamily: Constant.latoRegular,
                fontSize: 14,
                color: ColorValues.labelColor,
                fontWeight: FontWeight.w600
            ),
          ),
        );
      }),
    );
      */
  }

  otherInformationHeader(String title) {
    return Text(
      title,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 12,
          color: ColorValues.HEADING_COLOR_EDUCATION_1,
          fontWeight: FontWeight.w600
      ),
    );
  }

  otherInformationHeaderBold(String title) {
    return Text(
      title,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 12,
          color: ColorValues.HEADING_COLOR_EDUCATION_1,
          fontWeight: FontWeight.w600
      ),
    );
  }

  otherInformationValue(String value) {
    return Text(
      value,
      textAlign: TextAlign.start,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 14,
          color: ColorValues.labelColor,
          fontWeight: FontWeight.w600
      ),
    );
  }

  String getHours(index) {
    String timeReturn = "";
    try {
      for (HoursData hours in selectedDataOpportunityPreview.scheduleModelParam[index].hours) {
        timeReturn = Util.getConvertedTimeForScheduleDate(hours.timeFrom) +
            " - " +
            Util.getConvertedTimeForScheduleDate(
                hours.timeTo == null ? hours.timeFrom : hours.timeTo) +
            " | " +
            timeReturn;
      }

      return timeReturn.substring(0, timeReturn.lastIndexOf("|"));
    } catch (e) {
      return timeReturn;
    }
  }

  getHoursData(index) {
    return RichText(
      textAlign: TextAlign.start,
      maxLines: null,
      text:

      TextSpan(
        text:
        selectedDataOpportunityPreview.scheduleModelParam[index].day + ": " + getHours(index),
        style:
        TextStyle(
            fontFamily: Constant.latoRegular,
            fontSize: 14,
            color: ColorValues.labelColor,
            fontWeight: FontWeight.w600
        ),



        children: <TextSpan>[
          TextSpan(
            text: selectedDataOpportunityPreview.timeZone == null ||
                selectedDataOpportunityPreview.timeZone == "" ||
                selectedDataOpportunityPreview.timeZone == "null"
                ? ""
                : "(" + selectedDataOpportunityPreview.timeZone + ")",
            style: TextStyle(
                fontFamily: Constant.latoRegular,
                fontSize: 14,
                color: ColorValues.labelColor,
                fontWeight: FontWeight.w600
            ),
          )
        ],
      ),
    );
  }

  userImageListUI() {
    return Container(
      child: selectedDataOpportunityPreview != null && selectedDataOpportunityPreview.userImageModelParam.length > 0
          ? PaddingWrap.paddingfromLTRB(
          0.0,
          10.0,
          15.0,
          10.0,
          Container(
              child:  GridView.count(
                  primary: false,
                  shrinkWrap: true,
                  padding: const EdgeInsets.all(0.0),
                  crossAxisSpacing: 10.0,
                  childAspectRatio: 1.5,
                  scrollDirection: Axis.vertical,
                  crossAxisCount: 3,
                  children:  List.generate(
                      selectedDataOpportunityPreview.userImageModelParam.length, (index2) {
                    return  Container(
                        child:  Stack(
                          children: <Widget>[
                            InkWell(
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  placeholder: 'assets/aerial/default_img.png',
                                  image: Constant.IMAGE_PATH +
                                      selectedDataOpportunityPreview
                                          .userImageModelParam[index2].file,
                                  height: 80.0,
                                  width: 120.0,
                                ),
                                onTap: () {
                                  Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          CommonFullViewWidget(
                                              selectedDataOpportunityPreview.userImageModelParam,
                                              MessageConstant.HOME_HEDING,
                                              index2,
                                              MessageConstant
                                                  .VIEWER_END_REWCOMMENDATION_HEDING)));

                                }),
                          ],
                        ));
                  })

              )))
          :  Container(
        height: 0.0,
      ),
    );
  }


  Widget getScheduleWidget(OpportunityModelForFeed opportunity) {
    print(
        'opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            otherInformationHeader('Scheduled For: '),

            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children:
              List.generate(opportunity.scheduleModelParam.length, (index) {
                return Padding(
                  padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  child:

                  getHoursData(index),
                );
              }),
            )
          ],
        ));
  }

  Future getCategorySubject() async {
    print('inside getCategorySubject() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCallWithAuthToken(
            context,
            Constant.ENDPOINT_CATEGORY_SUBJECT +
                widget.opportunityModel.offerId,
            "get");

        print(
            'Apurva ui/ENDPOINT_CATEGORY_SUBJECT Response:::: ${response.toString()}');

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mCategoryFormModel =
                   CategoryFormModel.fromJson(response.data);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  TimeZoneModal _mTimeZoneModal;
  List<TimeZone> timeZoneList =  List();
  TimeZone _mTimeZoneSelected;
  String _mTimeZoneValue = "";
  String _mTimeZoneHintValue = "Timezone";
  bool isTimeZoneSelected = true;

  Future getTimeZone() async {
    print('inside getSubjects() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2()
            .apiCallWithAuthToken(context, Constant.ENDPOINT_TIMEZONE, "get");

        print('Apurva ui/category() Response:::: ${response.toString()}');

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mTimeZoneModal =  TimeZoneModal.fromJson(response.data);
              setState(() {
                timeZoneList.addAll(_mTimeZoneModal.timeZoneList);
                /*   if (widget.opportunityModel.timeZone != "" &&
                    widget.opportunityModel.timeZone != "null") {
                  _mTimeZoneValue = widget.opportunityModel.timeZone;
                  _mTimeZoneHintValue = widget.opportunityModel.timeZone;
                } else {
                  if (timeZoneList.length > 0) {
                    _mTimeZoneSelected = timeZoneList[0];
                    _mTimeZoneValue = timeZoneList[0].offset;
                  }
                }*/
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future callGetOpportunityDetailsAPI() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'callGetOpportunityDetailsAPI URL:: ${Constant.ENDPOINT_Opportunity_detail_api}${widget.opportunityId}');

        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_Opportunity_detail_api + widget.opportunityId,
            "get");

        print("callGetOpportunityDetailsAPI data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            print('Status:: $status');
            widget.opportunityModel =
                ParseJson.parseOpportunityModel(response.data['result']);

            setState(() {
              widget.opportunityModel;
            });
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    String dob = prefs.getString(UserPreference.DOB);

    CustomProgressLoader.showLoader(context);
    if (widget.opportunityId != null &&
        widget.opportunityId != "null" &&
        widget.opportunityId != "") {
      await callGetOpportunityDetailsAPI();
    }
    await getCategorySubject();
    await getTimeZone();
    await competencyApiCall();

    //   await getSubjects();
    await getQualifications();
    CustomProgressLoader.cancelLoader(context);

    generateSasToken(token);

    setData();

    print('Apurva Constant.CONTAINER_PREFIX:: ${Constant.CONTAINER_PREFIX}');
    print('Apurva userIdPref:: $userIdPref');
    print('Apurva Constant.CONTAINER_MEDIA:: ${Constant.CONTAINER_MEDIA}');
    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";

    print('Apurva strPrefixPathforPhoto:: $strPrefixPathforPhoto');

    try {
      if (dob != null) {
        print('Apurva dob:: $dob');
        int d = int.tryParse(dob);
        print('Apurva d:: $d');
        startDate =  DateTime.fromMillisecondsSinceEpoch(d);
        print('Apurva startDate:: $startDate');
        setState(() {
          startDate;
        });
      }
    } catch (Exception) {
      print('Apurva inside exception DOB');
    }

    try {
      String currentCity = await API.getUserCity();
      print('inside getSha currentCity:: $currentCity');
    } catch (Exception) {
      print('Apurva inside exception location');
    }

    /*   final thumbnailFile = await uploadMedia
        .getVideoThumbnailFromUrl(
            "http://spikeviewmediastorage.blob.core.windows.net/spikeview-media-development/sv_1359/media/20191126_153847.mp4");
    mediaVideosList.add(thumbnailFile);
    setState(() {
      mediaVideosList;
    });*/
    //await competencyApiCall();
  }

  Future<Null> _cropImage(File imageFile) async {
    imagePath = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      ratioX: 1.6,
      ratioY: 0.9,
    );
  }

  generateSasToken(token) async {
    Map<String, dynamic> result = await API.generateSasToken(token);

    sasToken = result['sasToken'];
    sasContainer = result['container'];

    //Navigator.of(context).pop();
  }

  Future competencyApiCall() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_COMPENTENCY, "get");
        print(response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              listCompetency.clear();
              listCompetency =
                  ParseJson.parseMapCompetency(response.data['result']);
              if (listCompetency.length > 0) {
                setState(() {
                  listCompetency;
                  print("competency:-" + listCompetency.toString());
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  void initState() {
// TODO: implement initState
    super.initState();

    years = List<int>.generate(100, (index) => index + 1);
    print('inside mentor initstate');
    getSharedPreferences();

    uploadMedia = UploadMedia(context);
    //toFromAge.add(AgeBetween(toAge: 0, fromAge: 0));
    //toFromTime.add(TimeBetween(toTime: "", fromTime: ""));
    for (int i = 0; i < listData.length; i++) {
      listData[i].dayScheduleData.add(DayScheduleData(
          toTime: "",
          fromTime: "",
          timeTo: 0,
          timeFrom: 0,
          startTimeController:  TextEditingController(),
          endTimeController:  TextEditingController()));
    }
    searchCountryController.addListener(() {
      if (searchCountryController.text.isEmpty) {
        setState(() {
          countries.clear();
        });
      } else {
        if (searchCountryController.text.trim().length >= 1) {
          initCountryList(searchCountryController.text.trim());
        }
      }
    });

    bioController.addListener(() {
      setState(() {
        bioController.text;
      });
    });

    serviceDescriptionController.addListener(() {
      setState(() {
        bioController.text;
      });
    });

    //initCountryList(); //age: [{to: 15, from: 10}, {to: 15, from: 10}]
    //age: [{to: 10, from: 5}, {to: 20, from: 15}]
  }

  initCountryList(text) async {
    countries.clear();
    countries = await API.fetchCountryList(text, 'regions');
    if (countries.length > 0) {
      setState(() {});
    }
  }

  enableScroll() {
    setState(() {
      scrollEnabled = true;
    });
  }

  disableScroll() {
    setState(() {
      scrollEnabled = false;
    });
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && sasContainer != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  onTapCancel() {
    for (CompetencyModel model in listCompetency) {
      model.selectAll = false;
      for (Level2Competencies level2 in model.level2Competencylist) {
        level2.isSelected = false;
      }
    }

    setState(() {
      selectedIntrestDataList.clear();
      listCompetency;
    });
  }

  getIntrestDialog(
      List<Level2Competencies> level2Competencylist, CompetencyModel model) {
    return  Column(
      children:  List.generate(level2Competencylist.length, (index) {
        if (level2Competencylist[index].isSelected) {
          return  Container(
            child:  Row(
              children: <Widget>[
                 Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10.0, 10, 10, 10),
                    child: Text(
                      level2Competencylist[index].name,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 6,
                      softWrap: true,
                    ),
                  ),
                  flex: 0,
                ),
                 Expanded(
                  child:  InkWell(
                    child: Icon(Icons.cancel,
                        size: 25.0,
                        color:  ColorValues.BG_CIRCLE_COLOR),
                    onTap: () {
                      setState(() {
                        selectedIntrestDataList.removeLast();
                        model.selectAll = false;
                        level2Competencylist[index].isSelected = false;
                      });
                    },
                  ),
                  flex: 0,
                )
              ],
            ),
          );
        } else
          return  Container(
            height: 0.0,
          );
      }),
    );
  }

  showSelectedInterest2() {
    return  Column(
        children:  List.generate(listCompetency.length, (index) {
      return getIntrestDialog(
          listCompetency[index].level2Competencylist, listCompetency[index]);
    }));

    /* return ListView.builder(
      itemCount: listCompetency.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        return getSelectedIntrest(
            listCompetency[index].level2Competencylist, listCompetency[index]);
      },
    );*/
  }

  onTapDone() {
    selectedIntrestDataList.clear();
    for (CompetencyModel model in listCompetency) {
      for (Level2Competencies level2 in model.level2Competencylist) {
        if (level2.isSelected) {
          selectedIntrestDataList
              .add(new IntrestModel(level2.competencyTypeId, level2.name));
        }
      }
    }
    setState(() {
      selectedIntrestDataList;
      listCompetency;
    });
    if (selectedIntrestDataList != null) {
      print(
          'Apurva selectedIntrestDataList size:: ${selectedIntrestDataList.length}');
      print(
          'Apurva onTapDone() _jobFormKey.currentState:: ${_jobFormKey.currentState}');
    }
    if (listCompetency != null) {
      print('Apurva listCompetency size:: ${listCompetency.length}');
    }
  }

  showCompetencySelection() async {
    await showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 12.0,
                            left: 12.0,
                            bottom: 48.0,
                            top: 10.0,
                            child:  Container(
                                color: Colors.white,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            color:  ColorValues.BORDER_COLOR,
                                            child: PaddingWrap.paddingfromLTRB(
                                                16.0,
                                                15.0,
                                                16.0,
                                                15.0,
                                                 Text(
                                                  "Select all the interests you feel to get maximum audience interaction on your opportunity.",
                                                  textAlign: TextAlign.start,
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 14.0,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                          ),
                                          ModalBottomSheet(listCompetency)
                                        ]))
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                12.0,
                                0.0,
                                12.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                padding:
                                                     EdgeInsets.fromLTRB(
                                                        10.0, 0.0, 0.0, 0.0),
                                                child:  Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.start,
                                                  style:  TextStyle(
                                                      color:   ColorValues.GREY_TEXT_COLOR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              onTapCancel();
                                            },
                                          ),
                                          flex: 0,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                padding:
                                                     EdgeInsets.fromLTRB(
                                                        0.0, 0.0, 10.0, 0.0),
                                                child:  Text(
                                                  "Done",
                                                  textAlign: TextAlign.end,
                                                  style:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              onTapDone();
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void _showRemoveDialog(int index, AssetsType assetsType) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: 'Are you sure? You want to remove this file?',
          onPositiveTap: () {
            switch (assetsType) {
              case AssetsType.image:
                mediaImagesList.removeAt(index);
                break;

              case AssetsType.video:
                mediaVideosList.removeAt(index);
                break;

              case AssetsType.externalLink:
                linkUrlListData.removeAt(index);
                break;

              case AssetsType.trophy:
                mentorImagesList.removeAt(index);
                break;

              case AssetsType.profileImage:
              // TODO: Handle this case.
                break;
            }
           // _checkAccomplishmentsValidation();
            setState(() {});
          },
        );
      },
    );
  }

  showIntrestNew() {
    return SingleChildScrollView(
      child: Column(
        children: <Widget>[
          ModalBottomSheet(listCompetency),
        ],
      ),
    );
  }


  void _checkStepOneValidaiton() {

    print(" step one validation Current Step - ${currentStep}");
    print("opportunityModel.offerId - ${widget.opportunityModel.offerId}");
    print("jobTitleController.text - ${jobTitleController.text}");

        if (selectedDesignationOption.length < 1) {
          setState(() {
            isDesignationError = true;
            designationBottomViewColor = Colors.red[700];
            _isProcessEnable = false ;
          });

        } else if (selectedSubjectOption.length < 1) {
          setState(() {
            isSubjectError = true;
            _isProcessEnable = false ;

            subjectBottomViewColor = Colors.red[700];
          });
        } else if (selectedQualificationOption.length < 1) {
          setState(() {
            isQualificationError = true;
            qualificationBottomViewColor = Colors.red[700];
            _isProcessEnable = false ;

          });
        }else{
          isDesignationError = false;
          isSubjectError = false;
          isQualificationError = false;
          _isProcessEnable = true ;

          if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
            _showMediaError = true;
            _isProcessForStepTwoEnable = false;
          }else if (mentorImagesList.length == 0) {
            _showMediaError = true;
            _isProcessForStepTwoEnable = false;
          } else {
            _isProcessForStepTwoEnable = true;
            _showMediaError = false;
          }
        }


    setState(() {
      print("set state call");
    });

  }

  void _checkStepTwoValidaiton() {
    if (currentStep == 1) {
      if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
        _isProcessForStepTwoEnable = false;
        _showMediaError = true;
        setState(() {
        });

      }else if (mentorImagesList.length == 0) {
        _isProcessForStepTwoEnable = false;
        _showMediaError = true;
        setState(() {
        });

      } else {
        _showMediaError = false;
        _isProcessForStepTwoEnable = true;
        setState(() {
        });
      }
    }

  }

  void _checkStepThreeValidaiton() {
    if (currentStep == 1) {
      if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
        _isProcessForStepTwoEnable = false;
        _showMediaError = true;

      } else {
        _showMediaError = false;
        _isProcessForStepTwoEnable = true;
      }
    }
    setState(() {
    });
  }

  void _checkAccomplishmentsValidation() {
    // if (_jobFormKey?.currentState?.validate() ?? false) {
    print("Current Step - ${currentStep}");

    if (currentStep == 0) {
      if (widget.opportunityModel.offerId == "1") {

        if (jobTitleController.text.isEmpty || jobTypeController.text.isEmpty ||
            jobLocationController.text.isEmpty
            // ||
            // describeRoleController.text.isEmpty
        ) {
          print("Both fields are empty");
          _isProcessEnable = false;
        } else if (jobTitleController.text.isNotEmpty ||
            jobTypeController.text.isNotEmpty ||
            jobLocationController.text.isNotEmpty
            // ||
            // describeRoleController.text.isNotEmpty
        ) {
          print(" fields have values");
          _isProcessEnable = true;

          if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
            _showMediaError = false;
            _isProcessForStepTwoEnable = false;
          }else {
            _isProcessForStepTwoEnable = true;
            _showMediaError = false;
          }
        }
      } else {
        if (serviceTitleController.text.isEmpty &&
            serviceDescriptionController.text.isEmpty) {
          print("Both fields are empty");
          _isProcessEnable = false;
        } else if (serviceTitleController.text.isNotEmpty &&
            serviceDescriptionController.text.isEmpty) {
          print("Service description is empty");
          _isProcessEnable = false;
        } else if (serviceTitleController.text.isEmpty &&
            serviceDescriptionController.text.isNotEmpty) {
          print("Service title is empty");
          _isProcessEnable = false;
        } else {
          print("Both fields have values");
          _isProcessEnable = true;

          if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
            _showMediaError = true;
            _isProcessForStepTwoEnable = false;

          } else {
            _isProcessForStepTwoEnable = true;
            _showMediaError = false;
          }
        }
      }

    } else if (currentStep == 1) {
      if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
        _isProcessForStepTwoEnable = false;
        _showMediaError = true;
      } else {
        _isProcessForStepTwoEnable = true;
      }
    } else if (currentStep == 2) {

    }
    setState(() {});
  }


  @override
  Widget build(BuildContext context) {


    Constant.applicationContext = context;
    final dropdownForTime = Util.timeList
        .map((String item) =>  DropdownMenuItem<String>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                 Text(
                  item,
                  style:  TextStyle(
                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ))))
        .toList();

    Widget getDayRecord(int outerIndex, OperationNewClass data) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 0.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            //Text('${data.dayName}'),
            UIHelper.verticalGapBetweenBox,
            InkWell(
              child: Row(
                children: <Widget>[
                  // customCheckBox(data.isSelect),
                  Image.asset(
                    data.isSelect ? 'assets/experience/ic_checked.png'
                        : 'assets/experience/ic_unchecked.png',
                    height: 20,
                    width: 20,
                    //  color: Palette.primaryTextColor,
                  ),

                  UIHelper.horizontalGapBetweenBox,

                  Text(
                    '${data.dayName}',
                    style:TextStyle(
                        fontFamily: Constant.latoRegular,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: ColorValues.HEADING_COLOR_EDUCATION_1
                    ),
                  )

                  //  checkBoxLabelText('${data.dayName}'),
                ],
              ),
              onTap: () {
                setState(() {
                  data.isSelect = !data.isSelect;
                  if (data.isSelect) {
                    //selectedIntrestDataList.clear();
                  } else {}
                });
              },
            ),
            /*data.isSelect
              ? UIHelper.verticalGapBetweenBox
              : Container(),*/
            data.isSelect
                ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                UIHelper.verticalGapBetweenBox,

                //////////////////////////////////
                ListView.builder(
                  itemCount: listData[outerIndex].dayScheduleData.length,
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,

                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    final timeFrom = listData[outerIndex]
                        .dayScheduleData[index]
                        .startTimeController; //TextEditingController();
                    final timeTo = listData[outerIndex]
                        .dayScheduleData[index]
                        .endTimeController; //TextEditingController();

                    if (listData[outerIndex]
                        .dayScheduleData[index]
                        .toTime ==
                        null ||
                        listData[outerIndex]
                            .dayScheduleData[index]
                            .toTime ==
                            "") {
                      listData[outerIndex].dayScheduleData[index].toTime =
                      null;
                    }

                    if (listData[outerIndex]
                        .dayScheduleData[index]
                        .fromTime ==
                        null ||
                        listData[outerIndex]
                            .dayScheduleData[index]
                            .fromTime ==
                            "") {
                      listData[outerIndex]
                          .dayScheduleData[index]
                          .fromTime = null;
                    }

                    return Container(
                      padding: EdgeInsets.only(top: 0),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                                padding: EdgeInsets.only(
                                  bottom: UIHelper.screenPadding,
                                  top: 5,
                                ),
                                child: Container(
                                  child:
                                  CustomDropdownButtonFormFieldNew(
                                    icon: Image.asset(
                                      'assets/recommendation/ic_arrow_down.png',
                                      height: 20,
                                      width: 20,
                                    ),

                                    //shubham
                                    items : Util.timeList.map((String value) {
                                      return CustomDropdownMenuItem<String>(
                                        value: value,
                                        child: Text(
                                          // listData[outerIndex].dayScheduleData[index].fromTime,
                                          value,
                                          style: textFormFieldValueStyle(),
                                        ),
                                      );
                                    }).toList(),

                                    onChanged: (s) {

                                      FocusScope.of(context).requestFocus(FocusNode());
                                      //  focusArea = newValue;
                                      print("Time++++" +
                                          (dateFormat.parse(s))
                                              .millisecondsSinceEpoch
                                              .toString());

                                      if (listData[outerIndex]
                                          .dayScheduleData[
                                      index]
                                          .toTime !=
                                          null) {
                                        if ((dateFormat.parse(listData[
                                        outerIndex]
                                            .dayScheduleData[
                                        index]
                                            .toTime))
                                            .millisecondsSinceEpoch >
                                            (dateFormat
                                                .parse(s))
                                                .millisecondsSinceEpoch) {
                                          listData[outerIndex]
                                              .dayScheduleData[
                                          index]
                                              .fromTime = s;
                                        } else {
                                          ToastWrap.showToast(
                                              MessageConstant
                                                  .FROM_TIME_LESS_THAN_TO_TIME_VAL,
                                              context);
                                        }
                                      } else {
                                        listData[outerIndex]
                                            .dayScheduleData[
                                        index]
                                            .fromTime = s;
                                      }

                                      setState(() {});

                                    },

                                    value: listData[outerIndex].dayScheduleData[index].fromTime,
                                    labelText: "Time from",
                                  ),


                                  /*
                                      DropdownButtonHideUnderline(
                                          child: Container(
                                            height: 100.0,
                                            child:  DropdownButton<
                                                String>(
                                                hint:  Text(
                                                  "Time From",
                                                  style: TextStyle(
                                                      fontFamily: Constant.latoRegular,
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.w500,
                                                      color: ColorValues.HEADING_COLOR_EDUCATION_1
                                                  ),
                                                ),
                                                value: listData[outerIndex]
                                                    .dayScheduleData[index]
                                                    .fromTime,
                                                items: dropdownForTime,
                                                onChanged: (s) {
                                                  print("Time++++" +
                                                      (dateFormat.parse(s))
                                                          .millisecondsSinceEpoch
                                                          .toString());

                                                  if (listData[outerIndex]
                                                      .dayScheduleData[
                                                  index]
                                                      .toTime !=
                                                      null) {
                                                    if ((dateFormat.parse(listData[
                                                    outerIndex]
                                                        .dayScheduleData[
                                                    index]
                                                        .toTime))
                                                        .millisecondsSinceEpoch >
                                                        (dateFormat
                                                            .parse(s))
                                                            .millisecondsSinceEpoch) {
                                                      listData[outerIndex]
                                                          .dayScheduleData[
                                                      index]
                                                          .fromTime = s;
                                                    } else {
                                                      ToastWrap.showToast(
                                                          MessageConstant
                                                              .FROM_TIME_LESS_THAN_TO_TIME_VAL,
                                                          context);
                                                    }
                                                  } else {
                                                    listData[outerIndex]
                                                        .dayScheduleData[
                                                    index]
                                                        .fromTime = s;
                                                  }

                                                  setState(() {});
                                                }
                                                ),
                                          )),

                                        */
                                )
                            ),
                          ),
                          SizedBox(width: 15),
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.only(
                                  top: 5,
                                  bottom: UIHelper.screenPadding,
                                  right: 0),
                              child: CustomDropdownButtonFormFieldNew(
                                icon: Image.asset(
                                  'assets/recommendation/ic_arrow_down.png',
                                  height: 20,
                                  width: 20,
                                ),

                                items : Util.timeList.map((String value) {
                                  return CustomDropdownMenuItem<String>(
                                    value: value,
                                    child: Text(
                                      // listData[outerIndex].dayScheduleData[index].fromTime,
                                      value,
                                      style: textFormFieldValueStyle(),
                                    ),
                                  );
                                }).toList(),

                                onChanged: (s) {
                                  FocusScope.of(context).requestFocus(FocusNode());
                                  //  focusArea = newValue;
                                  print("Time++++" +
                                      (dateFormat
                                          .parse(s))
                                          .millisecondsSinceEpoch
                                          .toString());
                                  if (listData[
                                  outerIndex]
                                      .dayScheduleData[
                                  index]
                                      .fromTime !=
                                      null) {
                                    if ((dateFormat.parse(listData[
                                    outerIndex]
                                        .dayScheduleData[
                                    index]
                                        .fromTime))
                                        .millisecondsSinceEpoch <
                                        (dateFormat
                                            .parse(
                                            s))
                                            .millisecondsSinceEpoch) {
                                      listData[
                                      outerIndex]
                                          .dayScheduleData[
                                      index]
                                          .toTime = s;
                                    } else {
                                      ToastWrap.showToast(
                                          MessageConstant
                                              .FROM_TIME_LESS_THAN_TO_TIME_VAL,
                                          context);
                                    }
                                  } else {
                                    listData[outerIndex]
                                        .dayScheduleData[
                                    index]
                                        .toTime = s;
                                  }
                                  setState(() {});
                                },

                                value: listData[outerIndex].dayScheduleData[index].toTime,
                                labelText: "Time to",
                              ),
                            ),
                          ),
                          const SizedBox(width: 8,),
                          InkWell(
                            child: index > 0
                                ? Container(
                              padding: EdgeInsets.only(bottom: 5),
                              child:  Image.asset(
                                'assets/experience/ic_remove.png',
                                height: 15,
                                width: 15,
                              ),
                            )
                                :  Container(
                              height: 15,
                              width: 15,
                            ),
                            onTap: () {
                              if (listData[outerIndex]
                                  .dayScheduleData
                                  .length >
                                  1) {
                                print(
                                    'toFromTime Index is =======>  $index');
                                listData[outerIndex]
                                    .dayScheduleData
                                    .removeAt(index);
                              }
                              setState(() {});
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),

                ////////////////////////////

                InkWell(
                  child: Padding(
                    padding: EdgeInsets.only(top: 0, bottom: 5),
                    child: Text(
                      '+ Add additional hours',
                      style:TextStyle(
                          fontFamily: Constant.latoRegular,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: ColorValues.BLUE_COLOR
                      ),
                    ),
                  ),
                  onTap: () {
                    setState(() {
                      listData[outerIndex].dayScheduleData.add(
                          DayScheduleData(
                              toTime: "",
                              fromTime: "",
                              timeTo: 0,
                              timeFrom: 0,
                              startTimeController:
                              TextEditingController(),
                              endTimeController:
                              TextEditingController()));
                    });
                  },
                ),

                listData[outerIndex].duplicateValue
                    ? Text(
                  'Dublicate Schedule',
                  style:TextStyle(
                      fontFamily: Constant.latoRegular,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: ColorValues.RED
                  ),
                )
                    : Container(
                  height: 0,
                ),
              ],
            )
                : Container(),
          ],
        ),
      );
    }


    Widget getDayRecordold(int outerIndex, OperationNewClass data) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 0.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            //Text('${data.dayName}'),
            UIHelper.verticalGapBetweenBox,
            InkWell(
              child: Row(
                children: <Widget>[
                  // customCheckBox(data.isSelect),
                  Image.asset(
                    data.isSelect ? 'assets/experience/ic_checked.png'
                        : 'assets/experience/ic_unchecked.png',
                    height: 20,
                    width: 20,
                    //  color: Palette.primaryTextColor,
                  ),

                  UIHelper.horizontalGapBetweenBox,

                  Text(
                    '${data.dayName}',
                    style:TextStyle(
                        fontFamily: Constant.latoRegular,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: ColorValues.HEADING_COLOR_EDUCATION_1
                    ),
                  )

                  //  checkBoxLabelText('${data.dayName}'),
                ],
              ),
              onTap: () {
                setState(() {
                  data.isSelect = !data.isSelect;
                  if (data.isSelect) {
                    //selectedIntrestDataList.clear();
                  } else {}
                });
              },
            ),
            /*data.isSelect
              ? UIHelper.verticalGapBetweenBox
              : Container(),*/
            data.isSelect
                ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                UIHelper.verticalGapBetweenBox,

                //////////////////////////////////
                ListView.builder(
                  itemCount: listData[outerIndex].dayScheduleData.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    final timeFrom = listData[outerIndex]
                        .dayScheduleData[index]
                        .startTimeController; //TextEditingController();
                    final timeTo = listData[outerIndex]
                        .dayScheduleData[index]
                        .endTimeController; //TextEditingController();

                    if (listData[outerIndex]
                        .dayScheduleData[index]
                        .toTime ==
                        null ||
                        listData[outerIndex]
                            .dayScheduleData[index]
                            .toTime ==
                            "") {
                      listData[outerIndex].dayScheduleData[index].toTime =
                      null;
                    }

                    if (listData[outerIndex]
                        .dayScheduleData[index]
                        .fromTime ==
                        null ||
                        listData[outerIndex]
                            .dayScheduleData[index]
                            .fromTime ==
                            "") {
                      listData[outerIndex]
                          .dayScheduleData[index]
                          .fromTime = null;
                    }

                    return Container(
                      padding: EdgeInsets.only(top: 0),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.only(
                                bottom: UIHelper.screenPadding,
                                top: 5,
                              ),
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Container(
                                      height: 28.0,
                                      padding:  EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 5.0),
                                      decoration:  BoxDecoration(
                                          border:  Border(
                                              bottom: BorderSide(
                                                  color:  ColorValues.DARK_GREY,
                                                  width: 1.0))),
                                      width: double.infinity,
                                      child: Container(
                                        child:
                                        DropdownButtonHideUnderline(
                                            child: Container(
                                              height: 100.0,
                                              child:  DropdownButton<
                                                  String>(
                                                  hint:  Text(
                                                    "Time From",
                                                    style: TextStyle(
                                                        fontFamily: Constant.latoRegular,
                                                        fontSize: 16,
                                                        fontWeight: FontWeight.w500,
                                                        color: ColorValues.HEADING_COLOR_EDUCATION_1
                                                    ),
                                                  ),
                                                  value: listData[outerIndex]
                                                      .dayScheduleData[index]
                                                      .fromTime,
                                                  items: dropdownForTime,
                                                  onChanged: (s) {
                                                    print("Time++++" +
                                                        (dateFormat.parse(s))
                                                            .millisecondsSinceEpoch
                                                            .toString());

                                                    if (listData[outerIndex]
                                                        .dayScheduleData[
                                                    index]
                                                        .toTime !=
                                                        null) {
                                                      if ((dateFormat.parse(listData[
                                                      outerIndex]
                                                          .dayScheduleData[
                                                      index]
                                                          .toTime))
                                                          .millisecondsSinceEpoch >
                                                          (dateFormat
                                                              .parse(s))
                                                              .millisecondsSinceEpoch) {
                                                        listData[outerIndex]
                                                            .dayScheduleData[
                                                        index]
                                                            .fromTime = s;
                                                      } else {
                                                        ToastWrap.showToast(
                                                            MessageConstant
                                                                .FROM_TIME_LESS_THAN_TO_TIME_VAL,
                                                            context);
                                                      }
                                                    } else {
                                                      listData[outerIndex]
                                                          .dayScheduleData[
                                                      index]
                                                          .fromTime = s;
                                                    }

                                                    setState(() {});
                                                  }),
                                            )),
                                      ))),
                            ),
                          ),
                          SizedBox(width: 15),
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.only(
                                  top: 5,
                                  bottom: UIHelper.screenPadding,
                                  right: 0),
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Container(
                                      height: 28.0,
                                      padding:  EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 5.0),
                                      decoration:  BoxDecoration(
                                          border:  Border(
                                              bottom: BorderSide(
                                                  color:  ColorValues.DARK_GREY,
                                                  width: 1.0))),
                                      width: double.infinity,
                                      child:
                                      DropdownButtonHideUnderline(
                                          child:  DropdownButton<
                                              String>(
                                              hint:  Text(
                                                "Time To",
                                                style: TextStyle(
                                                    fontFamily: Constant.latoRegular,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                    color: ColorValues.HEADING_COLOR_EDUCATION_1
                                                ),

                                              ),
                                              value: listData[
                                              outerIndex]
                                                  .dayScheduleData[
                                              index]
                                                  .toTime,
                                              items: dropdownForTime,

                                              onChanged: (s) {
                                                print("Time++++" +
                                                    (dateFormat
                                                        .parse(s))
                                                        .millisecondsSinceEpoch
                                                        .toString());
                                                if (listData[
                                                outerIndex]
                                                    .dayScheduleData[
                                                index]
                                                    .fromTime !=
                                                    null) {
                                                  if ((dateFormat.parse(listData[
                                                  outerIndex]
                                                      .dayScheduleData[
                                                  index]
                                                      .fromTime))
                                                      .millisecondsSinceEpoch <
                                                      (dateFormat
                                                          .parse(
                                                          s))
                                                          .millisecondsSinceEpoch) {
                                                    listData[
                                                    outerIndex]
                                                        .dayScheduleData[
                                                    index]
                                                        .toTime = s;
                                                  } else {
                                                    ToastWrap.showToast(
                                                        MessageConstant
                                                            .FROM_TIME_LESS_THAN_TO_TIME_VAL,
                                                        context);
                                                  }
                                                } else {
                                                  listData[outerIndex]
                                                      .dayScheduleData[
                                                  index]
                                                      .toTime = s;
                                                }
                                                setState(() {});
                                              })))),
                            ),
                          ),
                          const SizedBox(width: 8,),
                          InkWell(
                            child: index > 0
                                ? Container(
                              padding: EdgeInsets.only(bottom: 5),
                              child:  Image.asset(
                                'assets/experience/ic_remove.png',
                                height: 15,
                                width: 15,
                              ),
                            )
                                :  Container(
                              height: 15,
                              width: 15,
                            ),
                            onTap: () {
                              if (listData[outerIndex]
                                  .dayScheduleData
                                  .length >
                                  1) {
                                print(
                                    'toFromTime Index is =======>  $index');
                                listData[outerIndex]
                                    .dayScheduleData
                                    .removeAt(index);
                              }
                              setState(() {});
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),

                ////////////////////////////

                InkWell(
                  child: Padding(
                    padding: EdgeInsets.only(top: 0, bottom: 5),
                    child: Text(
                      '+ Add additional hours',
                      style:TextStyle(
                          fontFamily: Constant.latoRegular,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: ColorValues.BLUE_COLOR
                      ),
                    ),
                  ),
                  onTap: () {
                    setState(() {
                      listData[outerIndex].dayScheduleData.add(
                          DayScheduleData(
                              toTime: "",
                              fromTime: "",
                              timeTo: 0,
                              timeFrom: 0,
                              startTimeController:
                              TextEditingController(),
                              endTimeController:
                              TextEditingController()));
                    });
                  },
                ),

                listData[outerIndex].duplicateValue
                    ? Text(
                  'Dublicate Schedule',
                  style:TextStyle(
                      fontFamily: Constant.latoRegular,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: ColorValues.RED
                  ),
                )
                    : Container(
                  height: 0,
                ),
              ],
            )
                : Container(),
          ],
        ),
      );
    }

    void _showRemoveDialog(int index, AssetsType assetsType) {
      showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: 'Are you sure? You want to remove this file?',
            onPositiveTap: () {
              switch (assetsType) {
                case AssetsType.image:
                  mediaImagesList.removeAt(index);
                  break;

                case AssetsType.video:
                  mediaVideosList.removeAt(index);
                  break;

                case AssetsType.externalLink:
                  linkUrlListData.removeAt(index);
                  break;

                case AssetsType.trophy:
                  mentorImagesList.removeAt(index);
                  break;

                case AssetsType.profileImage:
                // TODO: Handle this case.
                  break;
              }
              _checkStepOneValidaiton();
             // _checkAccomplishmentsValidation();
              setState(() {});
            },
          );
        },
      );
    }


    void _goToNextStep() {
      print("_pageController.initialPage step- ${_pageController.initialPage}");


      _pageController.nextPage(
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
    void _goToPreviousStep() {
      _pageController.previousPage(
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }

    void _videoPlayPopUp(String filePath) {
      if (filePath?.isNotEmpty ?? false) {
        showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => SafeArea(
            child: Scaffold(
              backgroundColor: Colors.black38,
              body: Center(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  height: 215.50,
                  width: double.infinity,
                  child: Stack(
                    overflow: Overflow.visible,
                    children: [
                      VideoPlayPauseOffline(filePath, "", true,
                          pageName: "profile"),
                      Align(
                        alignment: Alignment(1.12, -1.10),
                        child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 5),
                            child: Image.asset(
                              "assets/generateScript/cross_close.png",
                              height: 40.0,
                              width: 40.0,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      }
    }

    Future<Null> expiryDatePickerNew(BuildContext context) async {
      showDatePicker(
        context: context,
        initialDate: expiryDateTime ?? DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime((new DateTime.now().year + 5)),
        //DateTime.now(),
        confirmText: 'Apply',

        cancelText: 'Cancel',
      ).then((value) {
        print("Expireance date - ${value}");

        if (value != null) {
          setState(() {
            if (value != null) {
              DateTime dateTime =
                  value; // Assuming dateTime is the variable you want to compare with
              //DateTime toDate = DateTime.now(); // This is the date you want to compare with



              String date = Util.getDate(
                  dateTime); // Assuming Util.getDate() formats the date
              String date2 = DateFormat("yyyy-MM-dd").format(dateTime);
              print(date);

              setState(() {
                expiryValidation = false;
                expiryDateTime = dateTime;
                expiryDateController.text = date;
                expiryDate = dateTime.millisecondsSinceEpoch;
              });
            }
          });
        }
      });
    }


    Widget _myAdapterView(BuildContext context) {
      return ListView.builder(
        physics: NeverScrollableScrollPhysics(),
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: listData.length,
        itemBuilder: (context, index) {
          return getDayRecord(index, listData[index]);
        },
      );
    }

    // TODO: implement build
    showSucessMsg(msg, context) {
      Timer _timer;

      print("timer on");
      _timer =  Timer(const Duration(milliseconds: 2000), () async {
        print("timer off");
       // Navigator.pop(context);
        Navigator.pop(context, "push");
      });

      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {},
              child:  GestureDetector(
                child:  Scaffold(
                  backgroundColor: Colors.transparent,
                  body:  Stack(
                    children: <Widget>[
                       Positioned(
                          right: 0.0,
                          top: 55.0,
                          left: 0.0,
                          child:  Container(
                            height: 65.0,
                            padding:
                                 EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                            color:  Color(0xffF1EDC3),
                            child:  Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  RichText(
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.start,
                                    text: TextSpan(
                                      text: msg,
                                      style:  TextStyle(
                                          color:  Color(0xff408738),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    ),
                                  )
                                ]),
                          )),
                    ],
                  ),
                ),
                onTap: () {},
              )));
    }

    List<Map<String, dynamic>> otherCatList(List<String> categories, catId) {
      List<Map<String, dynamic>> listOfCategory = categories
          .map((category) => {
                "name": category,
                "categoryId": catId,
                "isOther": true,
              })
          .toList();
      return listOfCategory;
    }

    List<Map<String, dynamic>> otherSubList(List<String> categories) {
      List<Map<String, dynamic>> listOfCategory = categories
          .map((category) => {
                "name": category,
                "categoryId": 0,
                "isOther": true,
              })
          .toList();
      return listOfCategory;
    }

    void _showInfoDialog(String msg) {
      showModalBottomSheet(
          isDismissible: false,
          backgroundColor: Colors.transparent,
          context: context,
          builder: (_) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 35),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.all(10.0),
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [

                        // const SizedBox(height: 10),
                        //
                        // BaseText(
                        //   text: "Opportunity created successfully",
                        //   textAlign: TextAlign.center,
                        //   textColor: Color(0xff27275A),
                        //   fontSize: 16,
                        //   fontFamily: Constant.latoRegular,
                        //   fontWeight: FontWeight.w700,
                        // ),
                        const SizedBox(height: 10),
                        BaseText(
                          text: msg,
                          textAlign: TextAlign.center,
                          textColor: Color(0xff666B9A),
                          fontSize: 14,
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.w400,
                        ),
                        const SizedBox(height: 10),

                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  InkWell(
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      alignment: Alignment.center,
                      child: BaseText(
                        text: "OK",
                        textAlign: TextAlign.center,
                        textColor: Color(0xff27275A),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular,
                      ),
                    ),
                    onTap: () {
                      Timer _timer;
                      _timer = Timer(const Duration(milliseconds: 1000), () async {
                        print("timer off");
                        Navigator.pop(context);
                        Navigator.pop(context, "push");
                      });
                    },
                  ),
                ],
              ),
            );
          });
    }

    onTapPreview() async {
      print('Apurva inside onTapPreview');

      setState(() {
        listData[0].duplicateValue= false;
        listData[1].duplicateValue= false;
        listData[2].duplicateValue= false;
        listData[3].duplicateValue= false;
        listData[4].duplicateValue= false;
        listData[5].duplicateValue= false;
        listData[6].duplicateValue= false;
      });


      getScheduleData();
      if (_jobFormKey.currentState.validate()) {
        _jobFormKey.currentState.save();

        if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
          _showMediaError = true;
          // ToastWrap.showToast(
          //     MessageConstant.SELECT_1_PHOTO_VIDEO_VAL, context);
        } else if (mentorImagesList == null || mentorImagesList.length == 0) {

          setState(() {
            _showAdvisorError = true;
          });
          // ToastWrap.showToast(
          //     MessageConstant.SELECT_ADVISOR_PHOTO_VAL, context);
        } else if (selectedAction == null) {
          setState(() {
            _showEmptyCallToError = true;
          });
          print("_showEmptyCallToError");

          // ToastWrap.showToast(
          //     MessageConstant.SELECT_TYPE_OF_CALL_TO_ACTION_VAL, context);
        } else if (selectedDesignationOption.length < 1) {
          setState(() {
            isDesignationError = true;
            designationBottomViewColor = Colors.red[700];
          });
          print("isDesignationError");
        } else if (selectedSubjectOption.length < 1) {
          setState(() {
            isSubjectError = true;
            subjectBottomViewColor = Colors.red[700];
          });


          print("isSubjectError");

        } else if (selectedQualificationOption.length < 1) {
          setState(() {
            isQualificationError = true;
            qualificationBottomViewColor = Colors.red[700];
          });
          print("isQualificationError");

        } else if (selectedDayData.length < 1) {

          print("selectedDayData");

          setState(() {
            _showAvailablityError = true ;

            qualificationBottomViewColor = Colors.red[700];
          });

          // ToastWrap.showToast(MessageConstant.SELECT_DAY_VAL, context);
        }
        /*else if (isTimeSlotSelected()) {
          ToastWrap.showToast(MessageConstant.SELECT_time_slot_VAL, context);
        }*/
        else {
          getSelectedDesignationDetail();
          getSelectedSubjectDetail();
          getSelectedQualificationDetail();
          //mentorImagesList.removeAt(0);
          getSelectedUserImageDetail();

          if (isTargetAudience) {
            if (selectedCountries.length == 0 &&
                selectedIntrestDataList.length == 0 &&
                selectedGender == "Select gender" &&
                toFromAge.length == 0) {
              // ToastWrap.showToast(
              //     "Please select at least one filter for targeting audience.",
              //     context);
            } else {
              //++++++++++++++++++++++++++++++++++
              int actionId = 1;

              if (selectedAction == "Link URL") {
                actionId = 1;
              } else if (selectedAction == "Join Group") {
                actionId = 2;
              } else if (selectedAction == "Call Now") {
                actionId = 3;
              } else if (selectedAction == "Inquire Now") {
                actionId = 4;
              }

              int optionLinkSelected;

              String selectedUrl = "";

              if (learnMore) {
                optionLinkSelected = 1;
                selectedUrl = selectedLink;
              } else if (getOffer) {
                optionLinkSelected = 2;
                selectedUrl = selectedOfferLink;
              } else if (applyNow) {
                optionLinkSelected = 3;
                selectedUrl = selectedApplyNowLink;
              }
              print("selectedUrl ${selectedUrl}");

              if (actionId == 1 && (selectedUrl == "" || selectedUrl == null)) {
                print("_showLinkUrlError");

                setState(() {
                  _showLinkUrlError = true;

                });
                // ToastWrap.showToast(MessageConstant.INSERT_LINK_VAL, context);
                return;
              }
              if (actionId == 2 &&
                  (selectedGroup == "" || selectedGroup == null)) {
                if (createNewGroup) {

                  setState(() {
                    _showCreateGroupError = true;
                  });

                  // ToastWrap.showToast(
                  // MessageConstant.CREATE_GROUP_VAL, context);
                } else {
                  setState(() {
                    _showSelectGroupError = true;
                  });
                  print("_showSelectGroupError");
                  // ToastWrap.showToast(
                  //     MessageConstant.SELECT_GROUP_VAL, context);
                }
                return;
              }
              if (actionId == 3 &&
                  (selectedPhoneNumber == "" || selectedPhoneNumber == null)) {
                _showEmptyNumberError = true;
                print("_showEmptyNumberError");
                //  ToastWrap.showToast(MessageConstant.ENTER_NUMBER_VAL, context);
                return;
              }

              List<AgeModel> ageList =  List<AgeModel>();


              for (int i = 0; i < toFromAge.length; i++) {
                if (toFromAge[i].fromAge == null || toFromAge[i].toAge == null || toFromAge[i].fromAge == 0) {
                  // Do nothing, skip this object
                } else {
                  ageList.add(new AgeModel(toFromAge[i].toAge.toString(), toFromAge[i].fromAge.toString()));
                }
              }


              List<IntrestModel> interestTypeList =  List<IntrestModel>();
              selectedIntrestDataList.clear();
              for (CompetencyModel model in listCompetency) {
                for (Level2Competencies level2 in model.level2Competencylist) {
                  if (level2.isSelected) {
                    selectedIntrestDataList.add(
                        IntrestModel(level2.competencyTypeId, level2.name));
                    interestTypeList.add(
                        IntrestModel(level2.competencyTypeId, level2.name));
                  }
                }
              }

              List<Assest> assestList =  List<Assest>();
              List<Assest> assestVideoAndImage =  List<Assest>();
              List<Assest> videoList =  List<Assest>();
              List<Assest> docList =  List<Assest>();
              List<Assest> googleLinkLists =  List<Assest>();
              List<Assest> mediaList =  List<Assest>();

              for (int i = 0; i < mediaImagesList.length; i++) {
                // if (0 == i) {
                // } else {
                assestList.add(new Assest(
                    "image", 'media', mediaImagesList[i], "", false));
                assestVideoAndImage.add(new Assest(
                    "image", 'media', mediaImagesList[i], "", false));
                mediaList.add(new Assest(
                    "image", 'media', mediaImagesList[i], "", false));
                // }
              }

              for (int i = 0; i < mediaDocumentList.length; i++) {
                // if (0 == i) {
                // } else {
                assestList.add(new Assest(
                    "doc", 'media', mediaDocumentList[i], "", false));
                docList.add(new Assest(
                    "doc", 'media', mediaDocumentList[i], "", false));
                // }
              }

              for (int i = 0; i < mediaVideosList.length; i++) {
                // if (0 == i) {
                // } else {
                assestList.add(new Assest(
                    "video", 'media', mediaVideosList[i].path, "", false));
                assestVideoAndImage.add(new Assest(
                    "video", 'media', mediaVideosList[i].path, "", false));
                videoList.add(new Assest(
                    "video", 'media', mediaVideosList[i].path, "", false));
                // }
              }

              for (int i = 0; i < linkUrlListData.length; i++) {
                assestList.add(new Assest(
                    "google",
                    'media',
                    linkUrlListData[i].urlController.text == null
                        ? ""
                        : linkUrlListData[i].urlController.text,
                    linkUrlListData[i].labelController.text == null
                        ? ""
                        : linkUrlListData[i].labelController.text,
                    false));

                googleLinkLists.add(new Assest(
                    "google",
                    'media',
                    linkUrlListData[i].urlController.text == null
                        ? ""
                        : linkUrlListData[i].urlController.text,
                    linkUrlListData[i].labelController.text == null
                        ? ""
                        : linkUrlListData[i].labelController.text,
                    false));
              }

              print("googleLinkList+++" + googleLinkList.length.toString());
              print(
                  "googleDoclinkList+++" + googleDoclinkList.length.toString());

              List<MainCategory> _mMainCategoryList =  List();
              List<SubCategory> _mSubCategoryList =  List();
              int categoryId;
              int careerId;
              for (MainCategory cat in _mCategoryFormModel.mainCategoryList) {
                if (cat.isSelected) {
                  _mMainCategoryList.add(cat);
                  if (cat.name == "Career") {
                    careerId = cat.categoryId;
                  }
                  for (SubCategory sub in cat.subCategoryList) {
                    if (sub.isSelected) {
                      _mSubCategoryList.add(sub);
                    }
                  }
                }
              }
              OpportunityModelForFeed opp = OpportunityModelForFeed(
                  "",
                  userIdPref,
                  roleId,
                  jobTitleController.text,
                  jobTypeController.text,
                  jobLocationController.text,
                  bioController.text,
                  durationController.text,
                  statusController.text,
                  dateFrom.toString(),
                  dateTo.toString(),
                  selectedGroupId,
                  isTargetAudience.toString(),
                  titleController.text,
                  isTargetAudience
                      ? selectedGender == "Select gender"
                      ? ""
                      : selectedGender
                      : "",
                  widget.opportunityModel.companyId,
                  widget.opportunityModel.offerId,
                  serviceTitleController.text,
                  serviceDescriptionController.text,
                  expiryDate.toString(),
                  prefs.getString(UserPreference.COMPANY_IMAGE_PATH),
                  prefs.getString(UserPreference.COMPANY_NAME_PATH),
                  prefs.getString(UserPreference.COMPANY_IMAGE_PATH),
                  Util.getLoCation(selectedCountries),
                  interestTypeList,
                  isTargetAudience ? ageList : [],
                  assestList,
                  assestVideoAndImage,
                  videoList,
                  docList,
                  mediaList,
                  googleLinkLists,
                  actionId.toString(),
                  selectedUrl,
                  selectedGroupId.toString(),
                  selectedPhoneNumber,
                  "",
                  optionLinkSelected.toString(),
                  true,
                  "",
                  feesController.text != '' && feesController.text != null
                      ? feesController.text
                      : "0",
                  descriptionController.text.trim(),
                  bioController.text.trim(),
                  "",
                  "",
                  //selectAdvisorSupportOffered,
                  "",
                  //projectAreasController.text.trim(),
                  //userImageString,
                  selecteduserImageData,
                  selectedQualificationOption[0],
                  selectedQualificationList,
                  _mMainCategoryList,
                  _mSubCategoryList,
                  selectedDayData,
                  "",
                  "",
                  "",
                  "",
                  "",
                  selectedSubjectOtherOption,
                  selectedDesignationOtherOption,
                  selectedDesignationCareerOption,
                  _mTimeZoneValue,
                  "",
                  "","");

              print('target is selected - ${isTargetAudience}');


              selectedDataOpportunityPreview = opp;

              print(selectedDataOpportunityPreview);


              googleLinkList.clear();

              googleLinkList.addAll(selectedDataOpportunityPreview.googleLinkList);

              for ( student.Address adress in selectedDataOpportunityPreview.locationList) {
                location = "";
                if (location == "") {
                  location = location + " " + adress.street1;
                } else {
                  location = location + " | " + adress.street1;
                }
              }

              if (selectedDataOpportunityPreview.bio != null) {
                if (selectedDataOpportunityPreview.bio.length > 150) {
                  firstHalf = selectedDataOpportunityPreview.bio.substring(0, 150);
                  secondHalf = selectedDataOpportunityPreview.bio.substring(150, selectedDataOpportunityPreview.bio.length);
                } else {
                  firstHalf = selectedDataOpportunityPreview.bio;
                  secondHalf = "";
                }
              }

              descVal = '';
              if (selectedDataOpportunityPreview.offerId == "1" ||
                  selectedDataOpportunityPreview.offerId == "2" ||
                  selectedDataOpportunityPreview.offerId == "3") {
                descVal = selectedDataOpportunityPreview.project;
              } else if (selectedDataOpportunityPreview.offerId == "4" || selectedDataOpportunityPreview.offerId == "5") {
                descVal = selectedDataOpportunityPreview.serviceDesc;
              } else {
                descVal = selectedDataOpportunityPreview.description;
              }

              if (descVal != null) {
                if (descVal.length > 150) {
                  firstHalfDesc = descVal.substring(0, 150);
                  secondHalfDesc = descVal.substring(150, descVal.length);
                } else {
                  firstHalfDesc = descVal;
                  secondHalfDesc = "";
                }
              }

              categoryString = selectedDataOpportunityPreview.toMapStringForDesignation();
              if (selectedDataOpportunityPreview.selectedDesignationCareerOption != null &&
                  selectedDataOpportunityPreview.selectedDesignationCareerOption.length > 0) {
                if (categoryString != "")
                  categoryString = categoryString +
                      " | " +
                      selectedDataOpportunityPreview.toMapStringForDesignationCareer();
                else
                  categoryString = selectedDataOpportunityPreview.toMapStringForDesignationCareer();
              }
              if (selectedDataOpportunityPreview.selectedDesignationOtherOption != null &&
                  selectedDataOpportunityPreview.selectedDesignationOtherOption.length > 0) {
                if (categoryString != "")
                  categoryString = categoryString +
                      " | " +
                      selectedDataOpportunityPreview.toMapStringForDesignationOther();
                else
                  categoryString = selectedDataOpportunityPreview.toMapStringForDesignationOther();
              }

              //Subject
              subjectString = selectedDataOpportunityPreview.toMapStringSubject();
              if (selectedDataOpportunityPreview.selectedSubjectOtherOption != null &&
                  selectedDataOpportunityPreview.selectedSubjectOtherOption.length > 0) {
                if (subjectString != "")
                  subjectString =
                      subjectString + " | " + selectedDataOpportunityPreview.toMapStringSubjectOther();
                else
                  subjectString = selectedDataOpportunityPreview.toMapStringSubjectOther();
              }

              setState(() {

              });
              _goToNextStep();

            }
          } else {
            //++++++++++++++++++++++++++++++++++
            int actionId = 1;

            if (selectedAction == "Link URL") {
              actionId = 1;
            } else if (selectedAction == "Join Group") {
              actionId = 2;
            } else if (selectedAction == "Call Now") {
              actionId = 3;
            } else if (selectedAction == "Inquire Now") {
              actionId = 4;
            }

            int optionLinkSelected;

            String selectedUrl = "";

            if (learnMore) {
              optionLinkSelected = 1;
              selectedUrl = selectedLink;
            } else if (getOffer) {
              optionLinkSelected = 2;
              selectedUrl = selectedOfferLink;
            } else if (applyNow) {
              optionLinkSelected = 3;
              selectedUrl = selectedApplyNowLink;
            }

            if (actionId == 1 && (selectedUrl == "" || selectedUrl == null)) {
              setState(() {
                _showLinkUrlError = true ;
              });

              print("_showLinkUrlError");

              //  ToastWrap.showToast(MessageConstant.INSERT_LINK_VAL, context);
              return;
            }
            if (actionId == 2 &&
                (selectedGroup == "" || selectedGroup == null)) {
              if (createNewGroup) {
                setState(() {
                  _showCreateGroupError = true ;
                });
                print("_showCreateGroupError");

                //  ToastWrap.showToast(MessageConstant.CREATE_GROUP_VAL, context);
              } else {

                setState(() {
                  _showSelectGroupError = true ;
                });
                print("_showSelectGroupError");


                //  ToastWrap.showToast(MessageConstant.SELECT_GROUP_VAL, context);
              }
              return;
            }
            if (actionId == 3 &&
                (selectedPhoneNumber == "" || selectedPhoneNumber == null)) {

              setState(() {
                _showEmptyNumberError = true ;
              });

              print("_showEmptyNumberError");


              // ToastWrap.showToast(MessageConstant.ENTER_NUMBER_VAL, context);
              return;
            }




            List<AgeModel> ageList =  List<AgeModel>();

            // for (int i = 0; i < toFromAge.length; i++) {
            //   if (toFromAge[i].fromAge == 0) {
            //   } else {
            //     ageList.add(new AgeModel(toFromAge[i].toAge.toString(),
            //         toFromAge[i].fromAge.toString()));
            //   }
            // }

            for (int i = 0; i < toFromAge.length; i++) {
              if (toFromAge[i].fromAge == null || toFromAge[i].toAge == null || toFromAge[i].fromAge == 0) {
                // Do nothing, skip this object
              } else {
                ageList.add(new AgeModel(toFromAge[i].toAge.toString(), toFromAge[i].fromAge.toString()));
              }
            }


            List<IntrestModel> interestTypeList =  List<IntrestModel>();
            selectedIntrestDataList.clear();
            for (CompetencyModel model in listCompetency) {
              for (Level2Competencies level2 in model.level2Competencylist) {
                if (level2.isSelected) {
                  selectedIntrestDataList.add(
                      IntrestModel(level2.competencyTypeId, level2.name));
                  interestTypeList.add(
                      IntrestModel(level2.competencyTypeId, level2.name));
                }
              }
            }

            List<Assest> assestList =  List<Assest>();
            List<Assest> assestVideoAndImage =  List<Assest>();
            List<Assest> videoList =  List<Assest>();
            List<Assest> docList =  List<Assest>();
            List<Assest> googleLinkLists =  List<Assest>();
            List<Assest> mediaList =  List<Assest>();
            for (int i = 0; i < mediaImagesList.length; i++) {
              // if (0 == i) {
              // } else {
              assestList.add(new Assest(
                  "image", 'media', mediaImagesList[i], "", false));
              assestVideoAndImage.add(new Assest(
                  "image", 'media', mediaImagesList[i], "", false));
              mediaList.add(new Assest(
                  "image", 'media', mediaImagesList[i], "", false));
              // }
            }

            for (int i = 0; i < mediaDocumentList.length; i++) {
              // if (0 == i) {
              // } else {
              assestList.add(new Assest(
                  "doc", 'media', mediaDocumentList[i], "", false));
              docList.add(new Assest(
                  "doc", 'media', mediaDocumentList[i], "", false));
              // }
            }

            for (int i = 0; i < mediaVideosList.length; i++) {
              // if (0 == i) {
              // } else {
              assestList.add(new Assest(
                  "video", 'media', mediaVideosList[i].path, "", false));
              assestVideoAndImage.add(new Assest(
                  "video", 'media', mediaVideosList[i].path, "", false));
              videoList.add(new Assest(
                  "video", 'media', mediaVideosList[i].path, "", false));
              //}
            }

            for (int i = 0; i < linkUrlListData.length; i++) {
              assestList.add(new Assest(
                  "google",
                  'media',
                  linkUrlListData[i].urlController.text == null
                      ? ""
                      : linkUrlListData[i].urlController.text,
                  linkUrlListData[i].labelController.text == null
                      ? ""
                      : linkUrlListData[i].labelController.text,
                  false));

              googleLinkLists.add(new Assest(
                  "google",
                  'media',
                  linkUrlListData[i].urlController.text == null
                      ? ""
                      : linkUrlListData[i].urlController.text,
                  linkUrlListData[i].labelController.text == null
                      ? ""
                      : linkUrlListData[i].labelController.text,
                  false));
            }

            List<MainCategory> _mMainCategoryList =  List();
            List<SubCategory> _mSubCategoryList =  List();
            int categoryId;
            int careerId;
            for (MainCategory cat in _mCategoryFormModel.mainCategoryList) {
              if (cat.isSelected) {
                if (cat.name == "Other") {
                  categoryId = cat.categoryId;
                } else {
                  _mMainCategoryList.add(cat);
                  if (cat.name == "Career") {
                    careerId = cat.categoryId;
                  }
                  for (SubCategory sub in cat.subCategoryList) {
                    if (sub.isSelected) {
                      _mSubCategoryList.add(sub);
                    }
                  }
                }
              }
            }
            print("googleLinkList+++" + googleLinkList.length.toString());
            print("googleDoclinkList+++" + googleDoclinkList.length.toString());

            OpportunityModelForFeed opp = OpportunityModelForFeed(
                "",
                userIdPref,
                roleId,
                jobTitleController.text,
                jobTypeController.text,
                jobLocationController.text,
                bioController.text,
                durationController.text,
                statusController.text,
                dateFrom.toString(),
                dateTo.toString(),
                selectedGroupId,
                isTargetAudience.toString(),
                titleController.text,
                isTargetAudience
                    ? selectedGender == "Select gender"
                    ? ""
                    : selectedGender
                    : "",
                widget.opportunityModel.companyId,
                widget.opportunityModel.offerId,
                serviceTitleController.text,
                serviceDescriptionController.text,
                expiryDate.toString(),
                prefs.getString(UserPreference.COMPANY_IMAGE_PATH),
                prefs.getString(UserPreference.COMPANY_NAME_PATH),
                prefs.getString(UserPreference.COMPANY_IMAGE_PATH),
                Util.getLoCation(selectedCountries),
                interestTypeList,
                isTargetAudience ? ageList : [],
                assestList,
                assestVideoAndImage,
                videoList,
                docList,
                mediaList,
                googleLinkLists,
                actionId.toString(),
                selectedUrl,
                selectedGroupId.toString(),
                selectedPhoneNumber,
                "",
                optionLinkSelected.toString(),
                true,
                "",
                feesController.text != '' && feesController.text != null
                    ? feesController.text
                    : "0",
                //feesController.text.trim(),
                descriptionController.text.trim(),
                bioController.text.trim(),
                "",
                "",
                //selectAdvisorSupportOffered,
                "",
                //projectAreasController.text.trim(),
                //userImageString,
                selecteduserImageData,
                selectedQualificationOption[0],
                selectedQualificationList,
                _mMainCategoryList,
                _mSubCategoryList,
                selectedDayData,
                "",
                "",
                "",
                "",
                "",
                selectedSubjectOtherOption,
                selectedDesignationOtherOption,
                selectedDesignationCareerOption,
                _mTimeZoneValue,
                "",
                "","");

            selectedDataOpportunityPreview = opp;

            googleLinkList.clear();

            googleLinkList.addAll(selectedDataOpportunityPreview.googleLinkList);

            for ( student.Address adress in selectedDataOpportunityPreview.locationList) {
              location = "";
              if (location == "") {
                location = location + " " + adress.street1;
              } else {
                location = location + " | " + adress.street1;
              }
            }
            if (selectedDataOpportunityPreview.bio != null) {
              if (selectedDataOpportunityPreview.bio.length > 150) {
                firstHalf = selectedDataOpportunityPreview.bio.substring(0, 150);
                secondHalf = selectedDataOpportunityPreview.bio.substring(150, selectedDataOpportunityPreview.bio.length);
              } else {
                firstHalf = selectedDataOpportunityPreview.bio;
                secondHalf = "";
              }
            }

            descVal = '';
            if (selectedDataOpportunityPreview.offerId == "1" ||
                selectedDataOpportunityPreview.offerId == "2" ||
                selectedDataOpportunityPreview.offerId == "3") {
              descVal = selectedDataOpportunityPreview.project;
            } else if (selectedDataOpportunityPreview.offerId == "4" || selectedDataOpportunityPreview.offerId == "5") {
              descVal = selectedDataOpportunityPreview.serviceDesc;
            } else {
              descVal = selectedDataOpportunityPreview.description;
            }

            if (descVal != null) {
              if (descVal.length > 150) {
                firstHalfDesc = descVal.substring(0, 150);
                secondHalfDesc = descVal.substring(150, descVal.length);
              } else {
                firstHalfDesc = descVal;
                secondHalfDesc = "";
              }
            }

            categoryString = selectedDataOpportunityPreview.toMapStringForDesignation();
            if (selectedDataOpportunityPreview.selectedDesignationCareerOption != null &&
                selectedDataOpportunityPreview.selectedDesignationCareerOption.length > 0) {
              if (categoryString != "")
                categoryString = categoryString +
                    " | " +
                    selectedDataOpportunityPreview.toMapStringForDesignationCareer();
              else
                categoryString = selectedDataOpportunityPreview.toMapStringForDesignationCareer();
            }
            if (selectedDataOpportunityPreview.selectedDesignationOtherOption != null &&
                selectedDataOpportunityPreview.selectedDesignationOtherOption.length > 0) {
              if (categoryString != "")
                categoryString = categoryString +
                    " | " +
                    selectedDataOpportunityPreview.toMapStringForDesignationOther();
              else
                categoryString = selectedDataOpportunityPreview.toMapStringForDesignationOther();
            }

            //Subject
            subjectString = selectedDataOpportunityPreview.toMapStringSubject();
            if (selectedDataOpportunityPreview.selectedSubjectOtherOption != null &&
                selectedDataOpportunityPreview.selectedSubjectOtherOption.length > 0) {
              if (subjectString != "")
                subjectString =
                    subjectString + " | " + selectedDataOpportunityPreview.toMapStringSubjectOther();
              else
                subjectString = selectedDataOpportunityPreview.toMapStringSubjectOther();
            }

            setState(() {

            });
            _goToNextStep();


            // Navigator.of(context).push(new MaterialPageRoute(
            //     builder: (BuildContext context) =>  OpportunityViewWidget(
            //         opp, "", userIdPref, roleId, 14, "preview")));

            //++++++++++++++++++++++++++++++++++

          }
          //}
        }
      } else {
        print('Apurva onTapPreview() _jobFormKey form key is not validating');
      }
    }

    onTapCreate() async {

      setState(() {
        listData[0].duplicateValue= false;
        listData[1].duplicateValue= false;
        listData[2].duplicateValue= false;
        listData[3].duplicateValue= false;
        listData[4].duplicateValue= false;
        listData[5].duplicateValue= false;
        listData[6].duplicateValue= false;
      });
      generateChipsForOther();
      print('Apurva inside onTapCreate');
      /*if (isTargetAudience && _audienceFormKey.currentState.validate()) {
        _audienceFormKey.currentState.save();
      }else{
        print('Apurva onTapCreate() _audienceFormKey form key is not validating');
      }*/
      getScheduleData();
      if (_mTimeZoneValue == "") {
        setState(() {
          isTimeZoneSelected = false;
        });
      } else {
        setState(() {
          isTimeZoneSelected = true;
        });
      }
      if (_jobFormKey.currentState.validate() && isTimeZoneSelected) {
        _jobFormKey.currentState.save();
        if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
          // ToastWrap.showToast(
          //     MessageConstant.SELECT_1_PHOTO_VIDEO_VAL, context);
          //} else if (userImageString == null || userImageString == "") {
        } else if (mentorImagesList == null || mentorImagesList.length == 0) {
          // ToastWrap.showToast(
          //     MessageConstant.SELECT_ADVISOR_PHOTO_VAL, context);
        } else if (selectedAction == null) {
          // ToastWrap.showToast(
          //     MessageConstant.SELECT_TYPE_OF_CALL_TO_ACTION_VAL, context);
        } else if (selectedDesignationOption.length < 1) {
          setState(() {
            isDesignationError = true;
            designationBottomViewColor = Colors.red[700];
          });
        } else if (selectedSubjectOption.length < 1) {
          setState(() {
            isSubjectError = true;
            subjectBottomViewColor = Colors.red[700];
          });
        } else if (selectedQualificationOption.length < 1) {
          setState(() {
            isQualificationError = true;
            qualificationBottomViewColor = Colors.red[700];
          });
        } else if (selectedDayData.length < 1) {
        //  ToastWrap.showToast(MessageConstant.SELECT_DAY_VAL, context);
        }
        else if (listData[0].duplicateValue) {


        }else if (listData[1].duplicateValue) {


        }
        else if (listData[2].duplicateValue) {


        }
        else if (listData[3].duplicateValue) {


        }
        else if (listData[4].duplicateValue) {

        }
        else if (listData[5].duplicateValue) {


        }else if (listData[6].duplicateValue) {
        }
        /*else if (isTimeSlotSelected()) {
          ToastWrap.showToast(MessageConstant.SELECT_time_slot_VAL, context);
        }*/
        else {
          getSelectedDesignationDetail();
          getSelectedSubjectDetail();
          getSelectedQualificationDetail();

          //mentorImagesList.removeAt(0);
          getSelectedUserImageDetail();

          if (isTargetAudience) {
            if (selectedCountries.length == 0 &&
                selectedIntrestDataList.length == 0 &&
                selectedGender == "Select gender" &&
                toFromAge[0].toAge == 0) {
              // ToastWrap.showToast(
              //     "Please select at least one filter for targeting audience.",
              //     context);
            } else {
              //++++++++++++++++++++++++++++++++++
              int actionId = 1;

              if (selectedAction == "Link URL") {
                actionId = 1;
              } else if (selectedAction == "Join Group") {
                actionId = 2;
              } else if (selectedAction == "Call Now") {
                actionId = 3;
              } else if (selectedAction == "Inquire Now") {
                actionId = 4;
              }

              int optionLinkSelected;

              String selectedUrl = "";

              if (learnMore) {
                optionLinkSelected = 1;
                selectedUrl = selectedLink;
              } else if (getOffer) {
                optionLinkSelected = 2;
                selectedUrl = selectedOfferLink;
              } else if (applyNow) {
                optionLinkSelected = 3;
                selectedUrl = selectedApplyNowLink;
              }

              if (actionId == 1 && (selectedUrl == "" || selectedUrl == null)) {
                //ToastWrap.showToast(MessageConstant.INSERT_LINK_VAL, context);
                return;
              }
              if (actionId == 2 &&
                  (selectedGroup == "" || selectedGroup == null)) {
                if (createNewGroup) {
                  // ToastWrap.showToast(
                  //     MessageConstant.CREATE_GROUP_VAL, context);
                } else {
                  // ToastWrap.showToast(
                  //     MessageConstant.SELECT_GROUP_VAL, context);
                }
                return;
              }
              if (actionId == 3 &&
                  (selectedPhoneNumber == "" || selectedPhoneNumber == null)) {
                // ToastWrap.showToast(MessageConstant.ENTER_NUMBER_VAL, context);
                return;
              }

              for (int i = 0; i < toFromAge.length; i++) {
                if (toFromAge[i].fromAge == 0) {
                  toFromAge.removeAt(i);
                }
              }

              selectedIntrestDataList.clear();
              for (CompetencyModel model in listCompetency) {
                for (Level2Competencies level2 in model.level2Competencylist) {
                  if (level2.isSelected) {
                    selectedIntrestDataList.add(
                         IntrestModel(level2.competencyTypeId, level2.name));
                  }
                }
              }

              /*if (mediaImagesList.length > 0) {
                mediaImagesList.removeAt(0);
              }
              if (mediaDocumentList.length > 0) {
                mediaDocumentList.removeAt(0);
              }
              if (mediaVideosList.length > 0) {
                mediaVideosList.removeAt(0);
              }
              for (var file in mediaImagesList) {
                assetModelMap.add(AssetModel(
                  file: file,
                  tag: 'media',
                  type: "image",
                ));
              }

              for (var file in mediaDocumentList) {
                assetModelMap.add(AssetModel(
                  file: file,
                  tag: 'media',
                  type: "doc",
                ));
              }

              for (var file in mediaVideosList) {
                assetModelMap.add(AssetModel(
                  file: file.path,
                  tag: 'media',
                  type: "video",
                ));
              }*/
              for (int i = 0; i < mediaImagesList.length; i++) {
                // if (0 == i) {
                // } else {
                  assetModelMap.add(AssetModel(
                    file: mediaImagesList[i],
                    tag: 'media',
                    type: "image",
                  ));
                // }
              }

              for (int i = 0; i < mediaDocumentList.length; i++) {
                // if (0 == i) {
                // } else {
                  assetModelMap.add(AssetModel(
                    file: mediaDocumentList[i],
                    tag: 'media',
                    type: "doc",
                  ));
                // }
              }

              for (int i = 0; i < mediaVideosList.length; i++) {
                // if (0 == i) {
                // } else {
                  assetModelMap.add(AssetModel(
                    file: mediaVideosList[i].path,
                    tag: 'media',
                    type: "video",
                  ));
                // }
              }

              if (linkUrlListData.length == 0 ) {
                //linkUrlListData[0].urlController.text.trim() == '';
                linkUrlListData.clear();
                print('linkUrlListData len::: ${linkUrlListData.length}');
              }
              for (var file1 in linkUrlListData) {
                assetModelMap.add(AssetModel(
                  label: file1.labelController.text == null
                      ? ""
                      : file1.labelController.text,
                  file: file1.urlController.text == null
                      ? ""
                      : file1.urlController.text,
                  tag: 'media',
                  type: "google",
                ));
              }

              List<MainCategory> _mMainCategoryList =  List();
              List<SubCategory> _mSubCategoryList =  List();
              int categoryId;
              int careerId;
              for (MainCategory cat in _mCategoryFormModel.mainCategoryList) {
                if (cat.isSelected) {
                  _mMainCategoryList.add(cat);
                  if (cat.name == "Career") {
                    careerId = cat.categoryId;
                  }
                  for (SubCategory sub in cat.subCategoryList) {
                    if (sub.isSelected) {
                      _mSubCategoryList.add(sub);
                    }
                  }
                }
              }
              CustomProgressLoader.showLoader(context);

              Map map = {
                "userId": int.parse(userIdPref),
                "roleId": 4,
                "jobTitle": jobTitleController.text,
                "companyId": widget.opportunityModel.companyId,
                "offerId": widget.opportunityModel.offerId,
                "bio": bioController.text,
                "description": descriptionController.text,
                "fees": feesController.text != '' && feesController.text != null
                    ? feesController.text
                    : "0", //int.parse(feesController.text),
                "asset": AssetModel.mapList(assetModelMap),
                "targetAudience": isTargetAudience,
                "title": titleController.text,
                "callToAction": [
                  actionId == 1
                      ? {
                          "id": actionId,
                          "url": selectedUrl,
                          "position": optionLinkSelected,
                        }
                      : actionId == 2
                          ? {
                              "id": actionId,
                              "groupId": selectedGroupId,
                              "groupName": selectedGroup,
                              "isPublic": isGroupPublic,
                            }
                          : actionId == 3
                              ? {"id": actionId, "number": selectedPhoneNumber}
                              : {"id": actionId, "formId": ""}
                ],
                "location": selectedCountries
                    .map((v) => v.toJson2(selectedLocation == "Current city"
                        ? "Cities"
                        : selectedLocation))
                    .toList(),
                "gender": isTargetAudience
                    ? selectedGender == "Select gender"
                        ? ""
                        : selectedGender == "Non-Binary"
                            ? "NonBinary"
                            : selectedGender
                    : "",
                "age": isTargetAudience
                    ? toFromAge.map((v) => v.toJson2()).toList()
                    : [],

                "interestType": selectedIntrestDataList
                    .map((item) => item.toJson2())
                    .toList(),
                "expiresOn": expiryDate,
                "visibility": "Public",
                "lastActivityType": "CreateOpportunity",

                "schedule": ScheduleModelParam.mapList(selectedDayData),
                //"qualification": selectedQualificationOption[0],
                "qualification":
                    QualificationModelParam.mapList(selectedQualificationList),
                "category": _mMainCategoryList.map((v) {
                  return v.toJson2(isDesignationOtherSelected);
                }).toList(),
                "otherCategory":
                    otherCatList(selectedDesignationOtherOption, categoryId),
                "otherSubject": otherSubList(selectedSubjectOtherOption),
                "otherCareer":
                    otherCatList(selectedDesignationCareerOption, careerId),
                "subjects": _mSubCategoryList.map((v) {
                  return v.toJson2();
                }).toList(),
                "timeZone": _mTimeZoneValue,

                //"supportedOffer": selectAdvisorSupportOffered,
                //"projectArea": projectAreasController.text.trim(),
              };

              print('Apurva Request data =======> $map');
              bool response = await API.createOpportunityNew(map, token);
              CustomProgressLoader.cancelLoader(context);
              if (response) {
                _showInfoDialog(MessageConstant.MSG_FOR_OPPORTUNITY_APPROVAL);

              }
              //++++++++++++++++++++++++++++++++++
            }
          } else {
            //++++++++++++++++++++++++++++++++++
            int actionId = 1;

            if (selectedAction == "Link URL") {
              actionId = 1;
            } else if (selectedAction == "Join Group") {
              actionId = 2;
            } else if (selectedAction == "Call Now") {
              actionId = 3;
            } else if (selectedAction == "Inquire Now") {
              actionId = 4;
            }

            int optionLinkSelected;

            String selectedUrl = "";

            if (learnMore) {
              optionLinkSelected = 1;
              selectedUrl = selectedLink;
            } else if (getOffer) {
              optionLinkSelected = 2;
              selectedUrl = selectedOfferLink;
            } else if (applyNow) {
              optionLinkSelected = 3;
              selectedUrl = selectedApplyNowLink;
            }

            if (actionId == 1 && (selectedUrl == "" || selectedUrl == null)) {
            //  ToastWrap.showToast(MessageConstant.INSERT_LINK_VAL, context);
              return;
            }
            if (actionId == 2 &&
                (selectedGroup == "" || selectedGroup == null)) {
              if (createNewGroup) {
             //   ToastWrap.showToast(MessageConstant.CREATE_GROUP_VAL, context);
              } else {
              //  ToastWrap.showToast(MessageConstant.SELECT_GROUP_VAL, context);
              }
              return;
            }
            if (actionId == 3 &&
                (selectedPhoneNumber == "" || selectedPhoneNumber == null)) {
              //ToastWrap.showToast(MessageConstant.ENTER_NUMBER_VAL, context);
              return;
            }

            for (int i = 0; i < toFromAge.length; i++) {
              if (toFromAge[i].fromAge == 0) {
                toFromAge.removeAt(i);
              }
            }

            selectedIntrestDataList.clear();
            for (CompetencyModel model in listCompetency) {
              for (Level2Competencies level2 in model.level2Competencylist) {
                if (level2.isSelected) {
                  selectedIntrestDataList.add(
                       IntrestModel(level2.competencyTypeId, level2.name));
                }
              }
            }

            for (int i = 0; i < mediaImagesList.length; i++) {
              // if (0 == i) {
              // } else {
                assetModelMap.add(AssetModel(
                  file: mediaImagesList[i],
                  tag: 'media',
                  type: "image",
                ));
             // }
            }

            for (int i = 0; i < mediaDocumentList.length; i++) {
              // if (0 == i) {
              // } else {
                assetModelMap.add(AssetModel(
                  file: mediaDocumentList[i],
                  tag: 'media',
                  type: "doc",
                ));
            //  }
            }

            for (int i = 0; i < mediaVideosList.length; i++) {
              // if (0 == i) {
              // } else {
                assetModelMap.add(AssetModel(
                  file: mediaVideosList[i].path,
                  tag: 'media',
                  type: "video",
                ));
             // }
            }
            if (linkUrlListData.length == 0) {
              //linkUrlListData[0].urlController.text.trim() == '';
              linkUrlListData.clear();
              print('linkUrlListData len::: ${linkUrlListData.length}');
            }
            for (var file1 in linkUrlListData) {
              assetModelMap.add(AssetModel(
                label: file1.labelController.text == null
                    ? ""
                    : file1.labelController.text,
                file: file1.urlController.text == null
                    ? ""
                    : file1.urlController.text,
                tag: 'media',
                type: "google",
              ));
            }
            //=========other Link change==============
            /*for (var file in googleDoclinkList) {
              assetModelMap.add(AssetModel(
                file: file,
                tag: 'media',
                type: "google",
              ));
            }*/
            List<MainCategory> _mMainCategoryList =  List();
            List<SubCategory> _mSubCategoryList =  List();
            int categoryId;
            int careerId;
            for (MainCategory cat in _mCategoryFormModel.mainCategoryList) {
              if (cat.isSelected) {
                _mMainCategoryList.add(cat);
                if (cat.name == "Career") {
                  careerId = cat.categoryId;
                }
                for (SubCategory sub in cat.subCategoryList) {
                  if (sub.isSelected) {
                    _mSubCategoryList.add(sub);
                  }
                }
              }
            }
            CustomProgressLoader.showLoader(context);

            Map map = {
              "userId": int.parse(userIdPref),
              "roleId": 4,
              "jobTitle": jobTitleController.text,
              "companyId": widget.opportunityModel.companyId,
              "offerId": widget.opportunityModel.offerId,
              "bio": bioController.text,

              "description": descriptionController.text,
              "fees": feesController.text != '' && feesController.text != null
                  ? feesController.text
                  : "0", //int.parse(feesController.text),
              "asset": AssetModel.mapList(assetModelMap),
              "targetAudience": isTargetAudience,
              "title": titleController.text,
              "callToAction": [
                actionId == 1
                    ? {
                        "id": actionId,
                        "url": selectedUrl,
                        "position": optionLinkSelected,
                      }
                    : actionId == 2
                        ? {
                            "id": actionId,
                            "groupId": selectedGroupId,
                            "groupName": selectedGroup,
                            "isPublic": isGroupPublic,
                          }
                        : actionId == 3
                            ? {"id": actionId, "number": selectedPhoneNumber}
                            : {"id": actionId, "formId": ""}
              ],
              "location": selectedCountries
                  .map((v) => v.toJson2(selectedLocation == "Current city"
                      ? "Cities"
                      : selectedLocation))
                  .toList(),
              "gender": isTargetAudience
                  ? selectedGender == "Select gender"
                      ? ""
                      : selectedGender == "Non-Binary"
                          ? "NonBinary"
                          : selectedGender
                  : "",
              "age": isTargetAudience
                  ? toFromAge.map((v) => v.toJson2()).toList()
                  : [],
              /* [
              {"from": 5, "to": 10},
              {"from": 15, "to": 20}
            ]*/
              "interestType": selectedIntrestDataList
                  .map((item) => item.toJson2())
                  .toList(),

              "expiresOn": expiryDate,
              "visibility": "Public",
              "lastActivityType": "CreateOpportunity",

              "schedule": ScheduleModelParam.mapList(selectedDayData),
              //"qualification": selectedQualificationOption[0],
              "qualification":
                  QualificationModelParam.mapList(selectedQualificationList),
              "category": _mMainCategoryList.map((v) {
                return v.toJson2(isDesignationOtherSelected);
              }).toList(),
              "otherCategory":
                  otherCatList(selectedDesignationOtherOption, categoryId),
              "otherSubject": otherSubList(selectedSubjectOtherOption),
              "otherCareer":
                  otherCatList(selectedDesignationCareerOption, careerId),
              "subjects": _mSubCategoryList.map((v) {
                return v.toJson2();
              }).toList(),
              "timeZone": _mTimeZoneValue,
              //"supportedOffer": selectAdvisorSupportOffered,
              //"projectArea": projectAreasController.text.trim(),
            };

            print('Apurva Request data without =======> $map');
            bool response = await API.createOpportunityNew(map, token);
            CustomProgressLoader.cancelLoader(context);
            if (response) {

              _showInfoDialog(MessageConstant.MSG_FOR_OPPORTUNITY_APPROVAL);

            }

            //++++++++++++++++++++++++++++++++++

          }
          //}
        }
      } else {
        print('Apurva onTapCreate() _jobFormKey form key is not validating');
      }
    }

    onTapEdit() async {

      setState(() {
        listData[0].duplicateValue= false;
        listData[1].duplicateValue= false;
        listData[2].duplicateValue= false;
        listData[3].duplicateValue= false;
        listData[4].duplicateValue= false;
        listData[5].duplicateValue= false;
        listData[6].duplicateValue= false;
      });

      generateChipsForOther();
      print('Apurva inside onTapCreate');

      getScheduleData();
      if (_mTimeZoneValue == "") {
        setState(() {
          isTimeZoneSelected = false;
        });
      } else {
        setState(() {
          isTimeZoneSelected = true;
        });
      }
      if (_jobFormKey.currentState.validate() && isTimeZoneSelected) {
        _jobFormKey.currentState.save();
        if (mediaImagesList.length == 0 && mediaVideosList.length == 0) {
          // ToastWrap.showToast(
          //     MessageConstant.SELECT_1_PHOTO_VIDEO_VAL, context);
          // //} else if (userImageString == null || userImageString == "") {
        } else if (mentorImagesList == null || mentorImagesList.length == 0) {
          // ToastWrap.showToast(
          //     MessageConstant.SELECT_ADVISOR_PHOTO_VAL, context);
        } else if (selectedAction == null) {
          // ToastWrap.showToast(
          //     MessageConstant.SELECT_TYPE_OF_CALL_TO_ACTION_VAL, context);
        } else if (selectedDesignationOption.length < 1) {
          setState(() {
            isDesignationError = true;
            designationBottomViewColor = Colors.red[700];
          });
        } else if (selectedSubjectOption.length < 1) {
          setState(() {
            isSubjectError = true;
            subjectBottomViewColor = Colors.red[700];
          });
        } else if (selectedQualificationOption.length < 1) {
          setState(() {
            isQualificationError = true;
            qualificationBottomViewColor = Colors.red[700];
          });
        } else if (selectedDayData.length < 1) {
          setState(() {
            _showAvailablityError = true ;
          });
         // ToastWrap.showToast(MessageConstant.SELECT_DAY_VAL, context);
        } else if (listData[0].duplicateValue) {
        }else if (listData[1].duplicateValue) {
        }
        else if (listData[2].duplicateValue) {
        }
        else if (listData[3].duplicateValue) {
        }
        else if (listData[4].duplicateValue) {
        }
        else if (listData[5].duplicateValue) {
        }else if (listData[6].duplicateValue) {
        }


        else {
          getSelectedDesignationDetail();
          getSelectedSubjectDetail();
          getSelectedQualificationDetail();

          //mentorImagesList.removeAt(0);
          getSelectedUserImageDetail();

          if (isTargetAudience) {
            if (selectedCountries.length == 0 &&
                selectedIntrestDataList.length == 0 &&
                selectedGender == "Select gender" &&
                toFromAge.length == 0) {
              // ToastWrap.showToast(
              //     "Please select at least one filter for targeting audience.",
              //     context);
            } else {
              //++++++++++++++++++++++++++++++++++
              int actionId = 1;

              if (selectedAction == "Link URL") {
                actionId = 1;
              } else if (selectedAction == "Join Group") {
                actionId = 2;
              } else if (selectedAction == "Call Now") {
                actionId = 3;
              } else if (selectedAction == "Inquire Now") {
                actionId = 4;
              }

              int optionLinkSelected;

              String selectedUrl = "";

              if (learnMore) {
                optionLinkSelected = 1;
                selectedUrl = selectedLink;
              } else if (getOffer) {
                optionLinkSelected = 2;
                selectedUrl = selectedOfferLink;
              } else if (applyNow) {
                optionLinkSelected = 3;
                selectedUrl = selectedApplyNowLink;
              }

              if (actionId == 1 && (selectedUrl == "" || selectedUrl == null)) {
                ToastWrap.showToast(MessageConstant.INSERT_LINK_VAL, context);
                return;
              }
              if (actionId == 2 &&
                  (selectedGroup == "" || selectedGroup == null)) {
                if (createNewGroup) {
                  ToastWrap.showToast(
                      MessageConstant.CREATE_GROUP_VAL, context);
                } else {
                  ToastWrap.showToast(
                      MessageConstant.SELECT_GROUP_VAL, context);
                }
                return;
              }
              if (actionId == 3 &&
                  (selectedPhoneNumber == "" || selectedPhoneNumber == null)) {
                ToastWrap.showToast(MessageConstant.ENTER_NUMBER_VAL, context);
                return;
              }

              for (int i = 0; i < toFromAge.length; i++) {
                if (toFromAge[i].fromAge == 0) {
                  toFromAge.removeAt(i);
                }
              }

              selectedIntrestDataList.clear();
              for (CompetencyModel model in listCompetency) {
                for (Level2Competencies level2 in model.level2Competencylist) {
                  if (level2.isSelected) {
                    selectedIntrestDataList.add(
                         IntrestModel(level2.competencyTypeId, level2.name));
                  }
                }
              }

              /*if (mediaImagesList.length > 0) {
                mediaImagesList.removeAt(0);
              }
              if (mediaDocumentList.length > 0) {
                mediaDocumentList.removeAt(0);
              }
              if (mediaVideosList.length > 0) {
                mediaVideosList.removeAt(0);
              }
              for (var file in mediaImagesList) {
                assetModelMap.add(AssetModel(
                  file: file,
                  tag: 'media',
                  type: "image",
                ));
              }

              for (var file in mediaDocumentList) {
                assetModelMap.add(AssetModel(
                  file: file,
                  tag: 'media',
                  type: "doc",
                ));
              }

              for (var file in mediaVideosList) {
                assetModelMap.add(AssetModel(
                  file: file.path,
                  tag: 'media',
                  type: "video",
                ));
              }*/
              for (int i = 0; i < mediaImagesList.length; i++) {
                // if (0 == i) {
                // } else {
                  assetModelMap.add(AssetModel(
                    file: mediaImagesList[i],
                    tag: 'media',
                    type: "image",
                  ));
             //   }
              }

              for (int i = 0; i < mediaDocumentList.length; i++) {
                // if (0 == i) {
                // } else {
                  assetModelMap.add(AssetModel(
                    file: mediaDocumentList[i],
                    tag: 'media',
                    type: "doc",
                  ));
              //  }
              }

              for (int i = 0; i < mediaVideosList.length; i++) {
                // if (0 == i) {
                // } else {
                  assetModelMap.add(AssetModel(
                    file: mediaVideosList[i].path,
                    tag: 'media',
                    type: "video",
                  ));
              //  }
              }
              if (linkUrlListData.length == 0 ) {
                //linkUrlListData[0].urlController.text.trim() == '';
                linkUrlListData.clear();
                print('linkUrlListData len::: ${linkUrlListData.length}');
              }
              for (var file1 in linkUrlListData) {
                assetModelMap.add(AssetModel(
                  label: file1.labelController.text == null
                      ? ""
                      : file1.labelController.text,
                  file: file1.urlController.text == null
                      ? ""
                      : file1.urlController.text,
                  tag: 'media',
                  type: "google",
                ));
              }
              //=========other Link change==============
              /*  for (var file in googleDoclinkList) {
                assetModelMap.add(AssetModel(
                  file: file,
                  tag: 'media',
                  type: "google",
                ));
              }*/
              List<MainCategory> _mMainCategoryList =  List();
              List<SubCategory> _mSubCategoryList =  List();
              int categoryId;
              int careerId;
              for (MainCategory cat in _mCategoryFormModel.mainCategoryList) {
                if (cat.isSelected) {
                  _mMainCategoryList.add(cat);
                  if (cat.name == "Career") {
                    careerId = cat.categoryId;
                  }
                  for (SubCategory sub in cat.subCategoryList) {
                    if (sub.isSelected) {
                      _mSubCategoryList.add(sub);
                    }
                  }
                }
              }
              CustomProgressLoader.showLoader(context);

              Map map = {
                "userId": int.parse(userIdPref),
                "roleId": 4,
                "jobTitle": jobTitleController.text,
                "opportunityId": widget.opportunityModel.opportunityId,

                "companyId": widget.opportunityModel.companyId,
                "offerId": widget.opportunityModel.offerId,
                "bio": bioController.text,
                "description": descriptionController.text,
                "fees": feesController.text != '' && feesController.text != null
                    ? feesController.text
                    : "0", //int.parse(feesController.text),
                "asset": AssetModel.mapList(assetModelMap),
                "targetAudience": isTargetAudience,
                "title": titleController.text,
                "callToAction": [
                  actionId == 1
                      ? {
                          "id": actionId,
                          "url": selectedUrl,
                          "position": optionLinkSelected,
                        }
                      : actionId == 2
                          ? {
                              "id": actionId,
                              "groupId": selectedGroupId,
                              "groupName": selectedGroup,
                              "isPublic": isGroupPublic,
                            }
                          : actionId == 3
                              ? {"id": actionId, "number": selectedPhoneNumber}
                              : {"id": actionId, "formId": ""}
                ],
                "location": selectedCountries
                    .map((v) => v.toJson2(selectedLocation == "Current city"
                        ? "Cities"
                        : selectedLocation))
                    .toList(),
                "gender": isTargetAudience
                    ? selectedGender == "Select gender"
                        ? ""
                        : selectedGender == "Non-Binary"
                            ? "NonBinary"
                            : selectedGender
                    : "",
                "age": isTargetAudience
                    ? toFromAge.map((v) => v.toJson2()).toList()
                    : [],

                "interestType": selectedIntrestDataList
                    .map((item) => item.toJson2())
                    .toList(),
                "expiresOn": expiryDate,
                "visibility": "Public",
                "lastActivityType": "CreateOpportunity",

                "schedule": ScheduleModelParam.mapList(selectedDayData),
                //"qualification": selectedQualificationOption[0],
                "qualification":
                    QualificationModelParam.mapList(selectedQualificationList),
                "category": _mMainCategoryList.map((v) {
                  return v.toJson2(isDesignationOtherSelected);
                }).toList(),
                "otherCategory":
                    otherCatList(selectedDesignationOtherOption, categoryId),
                "otherSubject": otherSubList(selectedSubjectOtherOption),
                "otherCareer":
                    otherCatList(selectedDesignationCareerOption, careerId),
                "subjects": _mSubCategoryList.map((v) {
                  return v.toJson2();
                }).toList(),
                "timeZone": _mTimeZoneValue,

                //"supportedOffer": selectAdvisorSupportOffered,
                //"projectArea": projectAreasController.text.trim(),
              };

              print('Apurva Request data =======> $map');
              bool response = await API.editOpportunityNew(map, token);
              CustomProgressLoader.cancelLoader(context);
              if (response) {
                _showInfoDialog(MessageConstant.MSG_FOR_OPPORTUNITY_APPROVAL);

              }
              //++++++++++++++++++++++++++++++++++
            }
          } else {
            //++++++++++++++++++++++++++++++++++
            int actionId = 1;

            if (selectedAction == "Link URL") {
              actionId = 1;
            } else if (selectedAction == "Join Group") {
              actionId = 2;
            } else if (selectedAction == "Call Now") {
              actionId = 3;
            } else if (selectedAction == "Inquire Now") {
              actionId = 4;
            }

            int optionLinkSelected;

            String selectedUrl = "";

            if (learnMore) {
              optionLinkSelected = 1;
              selectedUrl = selectedLink;
            } else if (getOffer) {
              optionLinkSelected = 2;
              selectedUrl = selectedOfferLink;
            } else if (applyNow) {
              optionLinkSelected = 3;
              selectedUrl = selectedApplyNowLink;
            }

            if (actionId == 1 && (selectedUrl == "" || selectedUrl == null)) {
            //  ToastWrap.showToast(MessageConstant.INSERT_LINK_VAL, context);
              return;
            }
            if (actionId == 2 &&
                (selectedGroup == "" || selectedGroup == null)) {
              if (createNewGroup) {
            ///    ToastWrap.showToast(MessageConstant.CREATE_GROUP_VAL, context);
              } else {
            //    ToastWrap.showToast(MessageConstant.SELECT_GROUP_VAL, context);
              }
              return;
            }
            if (actionId == 3 &&
                (selectedPhoneNumber == "" || selectedPhoneNumber == null)) {
            //  ToastWrap.showToast(MessageConstant.ENTER_NUMBER_VAL, context);
              return;
            }

            for (int i = 0; i < toFromAge.length; i++) {
              if (toFromAge[i].fromAge == 0) {
                toFromAge.removeAt(i);
              }
            }

            selectedIntrestDataList.clear();
            for (CompetencyModel model in listCompetency) {
              for (Level2Competencies level2 in model.level2Competencylist) {
                if (level2.isSelected) {
                  selectedIntrestDataList.add(
                       IntrestModel(level2.competencyTypeId, level2.name));
                }
              }
            }

            /*if (mediaImagesList.length > 0) {
              mediaImagesList.removeAt(0);
            }
            if (mediaDocumentList.length > 0) {
              mediaDocumentList.removeAt(0);
            }
            if (mediaVideosList.length > 0) {
              mediaVideosList.removeAt(0);
            }
            for (var file in mediaImagesList) {
              assetModelMap.add(AssetModel(
                file: file,
                tag: 'media',
                type: "image",
              ));
            }

            for (var file in mediaDocumentList) {
              assetModelMap.add(AssetModel(
                file: file,
                tag: 'media',
                type: "doc",
              ));
            }

            for (var file in mediaVideosList) {
              assetModelMap.add(AssetModel(
                file: file.path,
                tag: 'media',
                type: "video",
              ));
            }*/

            for (int i = 0; i < mediaImagesList.length; i++) {
              // if (0 == i) {
              // } else {
                assetModelMap.add(AssetModel(
                  file: mediaImagesList[i],
                  tag: 'media',
                  type: "image",
                ));
            //  }
            }

            for (int i = 0; i < mediaDocumentList.length; i++) {
              // if (0 == i) {
              // } else {
                assetModelMap.add(AssetModel(
                  file: mediaDocumentList[i],
                  tag: 'media',
                  type: "doc",
                ));
             // }
            }

            for (int i = 0; i < mediaVideosList.length; i++) {
              // if (0 == i) {
              // } else {
                assetModelMap.add(AssetModel(
                  file: mediaVideosList[i].path,
                  tag: 'media',
                  type: "video",
                ));
             // }
            }

            if (linkUrlListData.length == 0 ) {
              //linkUrlListData[0].urlController.text.trim() == '';
              linkUrlListData.clear();
              print('linkUrlListData len::: ${linkUrlListData.length}');
            }
            for (var file1 in linkUrlListData) {
              assetModelMap.add(AssetModel(
                label: file1.labelController.text == null
                    ? ""
                    : file1.labelController.text,
                file: file1.urlController.text == null
                    ? ""
                    : file1.urlController.text,
                tag: 'media',
                type: "google",
              ));
            }
            //=========other Link change==============
            /*    for (var file in googleDoclinkList) {
              assetModelMap.add(AssetModel(
                file: file,
                tag: 'media',
                type: "google",
              ));
            }*/
            List<MainCategory> _mMainCategoryList =  List();
            List<SubCategory> _mSubCategoryList =  List();
            int categoryId;
            int careerId;
            for (MainCategory cat in _mCategoryFormModel.mainCategoryList) {
              if (cat.isSelected) {
                _mMainCategoryList.add(cat);
                if (cat.name == "Career") {
                  careerId = cat.categoryId;
                }
                for (SubCategory sub in cat.subCategoryList) {
                  if (sub.isSelected) {
                    _mSubCategoryList.add(sub);
                  }
                }
              }
            }
            CustomProgressLoader.showLoader(context);

            Map map = {
              "userId": int.parse(userIdPref),
              "roleId": 4,
              "opportunityId": widget.opportunityModel.opportunityId,

              "jobTitle": jobTitleController.text,
              "companyId": widget.opportunityModel.companyId,
              "offerId": widget.opportunityModel.offerId,
              "bio": bioController.text,

              "description": descriptionController.text,
              "fees": feesController.text != '' && feesController.text != null
                  ? feesController.text
                  : "0", //int.parse(feesController.text),
              "asset": AssetModel.mapList(assetModelMap),
              "targetAudience": isTargetAudience,
              "title": titleController.text,
              "callToAction": [
                actionId == 1
                    ? {
                        "id": actionId,
                        "url": selectedUrl,
                        "position": optionLinkSelected,
                      }
                    : actionId == 2
                        ? {
                            "id": actionId,
                            "groupId": selectedGroupId,
                            "groupName": selectedGroup,
                            "isPublic": isGroupPublic,
                          }
                        : actionId == 3
                            ? {"id": actionId, "number": selectedPhoneNumber}
                            : {"id": actionId, "formId": ""}
              ],
              "location": selectedCountries
                  .map((v) => v.toJson2(selectedLocation == "Current city"
                      ? "Cities"
                      : selectedLocation))
                  .toList(),
              "gender": isTargetAudience
                  ? selectedGender == "Select gender"
                      ? ""
                      : selectedGender == "Non-Binary"
                          ? "NonBinary"
                          : selectedGender
                  : "",
              "age": isTargetAudience
                  ? toFromAge.map((v) => v.toJson2()).toList()
                  : [],
              /* [
              {"from": 5, "to": 10},
              {"from": 15, "to": 20}
            ]*/
              "interestType": selectedIntrestDataList
                  .map((item) => item.toJson2())
                  .toList(),

              "expiresOn": expiryDate,
              "visibility": "Public",
              "lastActivityType": "CreateOpportunity",

              "schedule": ScheduleModelParam.mapList(selectedDayData),
              //"qualification": selectedQualificationOption[0],
              "qualification":
                  QualificationModelParam.mapList(selectedQualificationList),
              "category": _mMainCategoryList.map((v) {
                return v.toJson2(isDesignationOtherSelected);
              }).toList(),
              "otherCategory":
                  otherCatList(selectedDesignationOtherOption, categoryId),
              "otherSubject": otherSubList(selectedSubjectOtherOption),
              "otherCareer":
                  otherCatList(selectedDesignationCareerOption, careerId),
              "subjects": _mSubCategoryList.map((v) {
                return v.toJson2();
              }).toList(),
              "timeZone": _mTimeZoneValue,
              //"supportedOffer": selectAdvisorSupportOffered,
              //"projectArea": projectAreasController.text.trim(),
            };

            print('Apurva Request data without =======> $map');
            bool response = await API.editOpportunityNew(map, token);
            CustomProgressLoader.cancelLoader(context);
            if (response) {
              _showInfoDialog(MessageConstant.MSG_FOR_OPPORTUNITY_APPROVAL);

            }

            //++++++++++++++++++++++++++++++++++

          }
          //}
        }
      } else {
        print('Apurva onTapCreate() _jobFormKey form key is not validating');
      }
    }

    onTapImageAddButton() async {
      mediaImage = await uploadMedia.pickImageFromGallery();
      if (mediaImage != null) {
        // await _cropImage(mediaImage);
        imagePath = mediaImage;

        if (imagePath != null) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =  Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "image");
          });
        }
      } else {
        //ToastWrap.showToast("'No file was selected'", context);
      }
    }

    onTapMentorImageAddButton() async {
      mediaImage = await uploadMedia.pickImageFromGallery();
      if (mediaImage != null) {
        // await _cropImage(mediaImage);
        imagePath = mediaImage;

        if (imagePath != null) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =  Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "mentorimage");
          });
        }
      } else {
        //ToastWrap.showToast("'No file was selected'", context);
      }
    }
    /*onTapMentorImageAddButton() async {
        mediaImage = await uploadMedia.pickImageFromGallery();
        if (mediaImage != null) {
          await _cropImage(mediaImage);
          if (imagePath != null) {
            CustomProgressLoader.showLoader(context);
            Timer _timer =  Timer(const Duration(milliseconds: 400), () {
              checkMediaAndUpload(
                  imagePath: imagePath
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  type: "mentorimage");
            });
          }
          userImageFile = imagePath;
        } else {
          //ToastWrap.showToast("'No file was selected'", context);
        }
      }*/

    String getFileExtension2(File file) {
      return path.extension(file.path);
    }

    onTapVideoAddButton() async {
      mediaVideo = await uploadMedia.pickVideoFromGallery();
      if (mediaVideo != null) {
/*         final thumbnailFile = await uploadMedia.flutterVideoCompress
                      .getThumbnailWithFile(mediaVideo.path);
                  setState(() {
                    mediaVideosList.add(thumbnailFile);
                  });*/
        if (mediaVideo != null &&
            getFileExtension2(mediaVideo) != null &&
            getFileExtension2(mediaVideo).length > 0) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =  Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: mediaVideo
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "video");
          });
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    getDocuments() async {
      try {
        // Platform messages may fail, so we use a try/catch PlatformException.
        try {
          FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
            allowedFileExtensions: ['pdf'],
            allowedMimeTypes: ['application/pdf'],
            invalidFileNameSymbols: ['/'],
          );

          String path =
              await FlutterDocumentPicker.openDocument(params: params);
          if (path != null && path != "") {
            if ((Util.getFileExtension(path) == ".pdf") && path != null) {
              print("path+++++" + path.toString());
              setState(() {
                _showInvalidFormatePDFError = false;
              });
              CustomProgressLoader.showLoader(context);
              Timer _timer =  Timer(const Duration(milliseconds: 400), () {
                checkMediaAndUpload(
                    imagePath: path
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    type: "doc");
              });
            } else {
              setState(() {
                _showInvalidFormatePDFError = true;
              });
            }
          }
        } catch (e) {
          setState(() {
            _showInvalidFormatePDFError = true;
          });
        }
      } catch (e) {
        setState(() {
          _showInvalidFormatePDFError = true;
        });
      }
    }


    final docListUiDataNew = Container(
      height: 90, //
      width: double.maxFinite,

      // Set the desired height for the horizontal scroll area
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: mediaDocumentList.map((file) {
          print("mediaDocumentList length - ${mediaDocumentList.length}");

          print("mediaDocumentList length - ${jsonEncode(mediaDocumentList)}");

          if (file == null) {
            return Text("");
            //   InkWell(
            //   // ... Your InkWell content for when file is null ...
            // );
          } else {
            var fileName;
            String docName = "";
            if (file != null) {
              fileName = file.split("/");
              if (fileName != null && fileName.length > 0) {
                docName = fileName[fileName.length - 1];
              }
            }
            return Container(
              width: 75,
              // Set the desired width for each item in the horizontal scroll
              margin: const EdgeInsets.only(left: 5.0),
              // Add some margin between items
              child: Column(
                children: <Widget>[
                  const SizedBox(height: 5),
                  Container(
                    height: 65.0,
                    width: 65.0,
                    child: Stack(
                      children: <Widget>[
                        Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 0, 5, 0),
                            child: Container(
                                child: InkWell(
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Container(
                                      // height: 65.0,
                                      // width: 60.0,
                                        child: Image.asset(
                                          "assets/resume/ic_doc_pdf.png",
                                          height: 65.0,
                                          width: 65.0,
                                        )),
                                  ),
                                  onTap: () {
                                    launch(Constant.IMAGE_PATH + file);
                                  },
                                ))),
                        Positioned(
                            right: 5.0,
                            top: 0.0,
                            child: Container(
                                height: 15.0,
                                width: 15.0,
                                child: Center(
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment
                                          .center,
                                      mainAxisAlignment: MainAxisAlignment
                                          .center,
                                      children: <Widget>[
                                        InkWell(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                Image.asset(
                                                  "assets/profile/skills/red_close.png",
                                                  width: 15.0,
                                                  height: 15.0,
                                                )),
                                            onTap: () {
                                              conformationDialog("doc", file);
                                            })
                                      ],
                                    )))),
                      ],
                    ),
                  ),
                  Container(
                    height: 15.0,
                    child:
                    Row(
                        children: [
                          Expanded(
                            child: Text(
                              docName,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Color(0xff27275A),
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                fontFamily:
                                AppConstants.stringConstant.latoRegular,
                              ),
                            ),
                          ),
                        ]

                      // Padding(
                      //   padding: EdgeInsets.only(top: 3.0),
                      //   child: docNameLabelText('${docName}'),
                      // ),
                    ),
                  )
                ],
              ),
            );
          }
        }).toList(),
      ),
    );


    final  docListUiData = SizedBox(
      width: double.maxFinite,
      height: 110,
      child: InkWell(
        onTap: () {
          if (mediaDocumentList.length <= 5) {
            getDocuments();

          } else {
            ToastWrap.showToast(
                MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
          }
        },
        child: Stack(
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0,
              right: 0,
              top: 0,
              bottom: 14,
              child: Container(
                width: MediaQuery
                    .of(context)
                    .size
                    .width,
                child: mediaDocumentList.length > 0
                    ? SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.only(left: 14),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: mediaDocumentList.map((file) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 14),
                        child: SizedBox(
                          width: 102,
                          height: 57,
                          child: Stack(
                            alignment: Alignment.center,
                            children: <Widget>[
                              Image.asset(
                                "assets/resume/pdf_outside.png",
                                height: 57,
                                fit: BoxFit.fill,
                              ),
                              Positioned.fill(
                                child: Container(
                                  padding: const EdgeInsets.fromLTRB(7, 7, 7, 7),
                                  decoration: BoxDecoration(
                                    color: const Color(0x50000000),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      InkWell(
                                        child: Image.asset(
                                          "assets/experience/ic_play.png",
                                          height: 26,
                                          width: 26,
                                        ),
                                        onTap: () {
                                          launch(Constant.IMAGE_PATH + file);
                                        },
                                      ),
                                      RemoveButton(onTap: () =>  conformationDialog("doc", file)),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                )
                    : Column(
                  children: [
                    const SizedBox(height: 20),
                    Image.asset(
                      "assets/generateScript/pdf.png",
                      height: 20,
                      width: 20,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Upload documents',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: AppConstants.txtStyle
                          .heading14400LatoItalicLightPurple,
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
                decoration: BoxDecoration(
                  color: AppConstants.colorStyle.tabBg,
                  border: Border.all(
                    color: AppConstants.colorStyle.borderGenerateScript,
                  ),
                  borderRadius: const BorderRadius.all(
                    Radius.circular(7),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              child: Image.asset(
                "assets/generateScript/plus_icon.png",
                height: 28,
                width: 28,
              ),
            ),
          ],
        ),
      ),
    );


    Widget _imageItem(int index, AssetsType assetsType) {
      final item = mediaImagesList[index];
      print("mediaImagesList length ${mediaImagesList.length}");
      print("image item = ${item}");
      return ListImageView(
        imageUrl: item,
        onRemoveTap: () {

          _showRemoveDialog(index, assetsType);
        },
      );
    }
    final mediaImageListUIData = Container(
      child: SizedBox(
        width: double.maxFinite,
        height: 110,
        child: InkWell(
          onTap: () async {
            if (mediaAndVideoList.length <= 9) {
              var status = await Permission.photos.status;
              if (status.isGranted) {
                onTapImageAddButton();
              } else {
                checkPermissionPhoto(context);
              }
            } else {
              ToastWrap.showToast(
                  MessageConstant.MAX_10_IMAGE_VIDEO_UPLOADED_VAL, context);
            }
          },
          child: Stack(
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              Positioned(
                left: 0,
                right: 0,
                top: 0,
                bottom: 14,
                child: Container(
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: mediaImagesList.isNotEmpty
                      ? SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: List.generate(
                        mediaImagesList.length,
                            (index) => _imageItem(index, AssetsType.image),
                      ),
                    ),
                  )
                      : Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(height: 18),
                      Image.asset(
                        "assets/recommendation/ic_camera.png",
                        height: 26,
                        width: 25,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        'Your uploaded photos will appear here',
                        maxLines: 1,
                        textAlign: TextAlign.center,
                        style: AppConstants
                            .txtStyle.heading14400LatoItalicLightPurple,
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                    color: AppConstants.colorStyle.tabBg,
                    border: Border.all(
                      color: AppConstants.colorStyle.borderGenerateScript,
                    ),
                    borderRadius: const BorderRadius.all(
                      Radius.circular(7),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                child: Image.asset(
                  "assets/generateScript/plus_icon.png",
                  height: 28,
                  width: 28,
                ),
              ),
            ],
          ),
        ),
      ),
    );

    Widget userImage() {
      return Container(
        child: userImageString == ""
            ?  InkWell(
                child:  Container(
                    height: 54.0,
                    width: 80.0,
                    decoration:  BoxDecoration(
                        border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                    child:  Image.asset(
                      "assets/newDesignIcon/userprofile/add.png",
                      height: 25.0,
                      width: 25.0,
                    )),
                onTap: () async {
                  var status = await Permission.photos.status;
                  if (status.isGranted) {
                    onTapMentorImageAddButton();
                  } else {
                    checkPermissionPhoto(context);
                  }
                  //if (mentorImagesList.length <= 1) {

                  /*} else {
                  ToastWrap.showToast(
                      MessageConstant.MAX_3_PHOTO_UPLOADED_VAL, context);
                }*/
                },
              )
            : Container(
                child:  Stack(
                children: <Widget>[
                  FadeInImage.assetNetwork(
                    fit: BoxFit.cover,
                    placeholder: 'assets/aerial/default_img.png',
                    image: Constant.IMAGE_PATH + userImageString,
                    height: 54.0,
                    width: 80.0,
                  ),
                   Container(
                    height: 54.0,
                    width: 84.0,
                    color:  Color(0XFFC0C0C0).withOpacity(.4),
                  ),
                   Container(
                      height: 54.0,
                      width: 80.0,
                      child:  Center(
                          child:  Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                           InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                   Image.asset(
                                    "assets/newDesignIcon/achievment/remove.png",
                                    width: 35.0,
                                    height: 35.0,
                                  )),
                              onTap: () {
                                conformationDialog(
                                    "mentorimage", userImageFile);
                              })
                        ],
                      ))),
                ],
              )),
      );
    }

    Widget _imageItemMentor(int index, AssetsType assetsType) {
      final item = mentorImagesList[index];
      print("mediaImagesList length ${mentorImagesList.length}");
      print("image item = ${item}");
      return ListImageView(
        imageUrl: item,
        onRemoveTap: () {
          conformationDialog("mentorimage", item);

          // _showRemoveDialog(index, assetsType);
        },
      );
    }
    Widget _videoItem(int index, AssetsType assetsType) {
      final item = mediaVideosList[index];
      return ListVideoItem(
          videoUrl: item.path,
          thumbnailFile: item.file,
          onRemoveTap: () => _showRemoveDialog(index, assetsType),
          onPlayTap: () {
            _videoPlayPopUp(item.file.path);
          }
      );
    }

    final mentorImageListUIData = Container(
      child: SizedBox(
        width: double.maxFinite,
        height: 110,
        child: InkWell(
          onTap: () async {
            if (mentorImagesList.length <= 3) {
              var status = await Permission.photos.status;
              if (status.isGranted) {
                onTapMentorImageAddButton();
              }  else {
                checkPermissionPhoto(context);
              }
            } else {
              ToastWrap.showToast(
                  MessageConstant.MAX_3_PHOTO_UPLOADED_VAL, context);
            }
          },
          child: Stack(
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              Positioned(
                left: 0,
                right: 0,
                top: 0,
                bottom: 14,
                child: Container(
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: mentorImagesList.isNotEmpty
                      ? SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: List.generate(
                        mentorImagesList.length,
                            (index) => _imageItemMentor(index, AssetsType.image),
                      ),
                    ),
                  )
                      : Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(height: 18),
                      Image.asset(
                        "assets/recommendation/ic_camera.png",
                        height: 26,
                        width: 25,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        'Your uploaded advisor photos will appear here',
                        maxLines: 1,
                        textAlign: TextAlign.center,
                        style: AppConstants
                            .txtStyle.heading14400LatoItalicLightPurple,
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                    color: AppConstants.colorStyle.tabBg,
                    border: Border.all(
                      color: AppConstants.colorStyle.borderGenerateScript,
                    ),
                    borderRadius: const BorderRadius.all(
                      Radius.circular(7),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                child: Image.asset(
                  "assets/generateScript/plus_icon.png",
                  height: 28,
                  width: 28,
                ),
              ),
            ],
          ),
        ),
      ),
    );
    final videoListUi = SizedBox(
      width: double.maxFinite,
      height: 110,
      child: InkWell(
        onTap: () async {
          if (mediaAndVideoList.length <= 9) {
            var status = await Permission.photos.status;
            if (status.isGranted) {
              onTapVideoAddButton();
            } else {
              checkPermissionPhoto(context);
            }
          } else {
            ToastWrap.showToast(
                MessageConstant.MAX_10_IMAGE_VIDEO_UPLOADED_VAL, context);
          }
        },
        child: Stack(
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0,
              right: 0,
              top: 0,
              bottom: 14,
              child: mediaVideosList.isNotEmpty && mediaVideosList.length > 0
                  ? Container(
                width: MediaQuery
                    .of(context)
                    .size
                    .width,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: List.generate(
                      mediaVideosList.length,
                          (index) {

                        print(
                            "mediaVideosList.length ${mediaVideosList.length}");

                        var mediaItem = mediaVideosList[index];
                        if (mediaItem == null || mediaItem.file == null) {
                          return SizedBox(); // Or display an error message/placeholder
                        } else {
                          var file = mediaItem.file;
                          // print("mediaVideosList file - $file");
                          // return showMediaFileWidget(80, file);

                          return _videoItem(index, AssetsType.video);

                        }
                      },
                    ),
                  ),
                ),
                decoration: BoxDecoration(
                  color: AppConstants.colorStyle.tabBg,
                  border: Border.all(
                      color:
                      AppConstants.colorStyle.borderGenerateScript),
                  borderRadius: const BorderRadius.all(
                    Radius.circular(7),
                  ),
                ),
              )
                  : Container(
                width: MediaQuery
                    .of(context)
                    .size
                    .width,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(height: 18),
                    Image.asset(
                      "assets/experience/ic_video.png",
                      height: 26,
                      width: 25,
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'Your uploaded videos will appear here',
                      maxLines: 1,
                      textAlign: TextAlign.center,
                      style: AppConstants
                          .txtStyle.heading14400LatoItalicLightPurple,
                    ),
                  ],
                ),
                decoration: BoxDecoration(
                  color: AppConstants.colorStyle.tabBg,
                  border: Border.all(
                    color: AppConstants.colorStyle.borderGenerateScript,
                  ),
                  borderRadius: const BorderRadius.all(
                    Radius.circular(7),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              child: Image.asset(
                "assets/generateScript/plus_icon.png",
                height: 28,
                width: 28,
              ),
            ),
          ],
        ),
      ),
    );

    mediaPickerWidgets() {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[

          UIHelper.verticalSpaceSmall,
          mediaImageListUIData,
          UIHelper.verticalSpaceSmall,
          UIHelper.verticalSpaceSmall,
          videoListUi,
          UIHelper.verticalSpaceMedium,
        ],
      );
    }

    tutorBioWidget() {
      return GestureDetector(
        onTap: () {
          //generateChipsForOther();
        },
        child: Container(
          // decoration: rectangleDecoration(),
          child:

          Padding(
            padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
            child:
            CustomMultilineTextForm(
              textInputType: TextInputType.text,
              label: 'Bio',
              hint: 'I have been Advisor for high school students for the past 7 years.',
              maxLength:TextLength.OPPORTUNITY_DESCRIBE_MAX_LENGTH,
              maxLines:
              bioController.text.length > 60 ? 4 : 3,
              // onType: (val) => _checkStepOneValidaiton(),

              alignLabelWithHint: true,
              focusNode: _bioFocus,
              controller: bioController,
              validation: (value) {

                return ValidationChecks.validateBio(value);

              },
              onClick: (){
                generateChipsForOther();
                //add  _checkAccomplishmentsValidation();
              },

              onSaved: (term) {
                _bioFocus.unfocus();
                FocusScope.of(context)
                    .requestFocus(_descriptionFocus);
                _checkStepOneValidaiton();

                // _checkAccomplishmentsValidation();
              },
            ),
          ),
        ),
      );
    }

    descriptionWidget() {
      return Container(
        // decoration: rectangleDecoration(),
        child:Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(
                  top: 0, right: 0, bottom: 0.0),
              child:

              CustomMultilineTextForm(
                textInputType: TextInputType.text,
                label: 'Description',
                hint: 'I have 5 years of experience in advising high school students',

                maxLength:TextLength.OPPORTUNITY_DESCRIBE_MAX_LENGTH,
                maxLines:
                descriptionController.text.length > 60 ? 4 : 3,
                //  onType: (val) => _checkAccomplishmentsValidation(),

                alignLabelWithHint: true,
                focusNode: _descriptionFocus,
                controller: descriptionController,
                validation: (value) {
                  return ValidationChecks.validateDescription(value);
                },
                onClick: (){
                  //add  _checkAccomplishmentsValidation();
                  generateChipsForOther();

                },

                onSaved: (term) {
                 // _checkAccomplishmentsValidation();
                  _checkStepOneValidaiton();

                  _descriptionFocus.unfocus();
                  FocusScope.of(context).requestFocus(_feesFocus);
                },
              ),




              /*
              TextFormField(
                maxLines: descriptionController.text.length > 60 ? 5 : 2,
                focusNode: _descriptionFocus,
                maxLength: TextLength.OPPORTUNITY_DESCRIBE_MAX_LENGTH,
                textAlign: TextAlign.start,
                controller: descriptionController,
                onTap: () {
                  generateChipsForOther();
                },
                decoration: textFormFieldDecorationWithNoBorders11(
                    'Description',
                    helperText:
                    "I was formerly a lecturer in a university and my expertise includes teaching computer science and math subjects."),
                style: textFormFieldValueStyle(),
                keyboardType: TextInputType.multiline,
                textInputAction: TextInputAction.newline,
                textCapitalization: TextCapitalization.sentences,
                onFieldSubmitted: (term) {
                  _descriptionFocus.unfocus();
                  FocusScope.of(context).requestFocus(_feesFocus);
                },
                validator: (value) {
                  return ValidationChecks.validateDescription(value);
                },
              ),

               */

            ),
            UIHelper.verticalSpaceSmall,
          ],
        ),


      );
    }

    feesWidget() {
      return Container(
        // decoration: rectangleDecoration(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(
                  top: 5, right: UIHelper.screenPadding, bottom: 0.0),

              child :
              CustomFormField(
                textInputType: TextInputType.text,
                maxLength: TextLength.JOB_TITLE_MAX_LENGTH,
                focusNode: _feesFocus,
                label: 'Fees',
                hint: "Pay it forward with a free services or set a reasonable dollar amount",
                alignLabelWithHint: true,
                // onType: (val) => _checkAccomplishmentsValidation(),
                onSaved: (value) {
                  _feesFocus.unfocus();
                  FocusScope.of(context).requestFocus(_durationFocus);
                //  _checkAccomplishmentsValidation();
                },
                controller: feesController,
                // validation: (value) {
                //   return ValidationChecks.validateJobTitle(value);
                // },
                onClick: (){

                  generateChipsForOther();
                },

              ),

            ),
          ],
        ),
      );
    }

    mediaHeaderWidget() {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(UIHelper.screenPadding),
            child: colorIcon(ImagePath.ICON_MEDIA, 25, 25),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                  right: UIHelper.screenPadding,
                  bottom: UIHelper.screenPadding,
                  top: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  UIHelper.verticalSpaceExtraSmall,
                  Text(
                    'Add Media',
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.primaryTextColor, 16, FontType.Regular),
                  ),
                  UIHelper.verticalSpaceExtraSmall,
                  Text(
                    'Upload any photos or certificate to show why you are the best.',
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.secondaryTextNewColor, 14, FontType.Regular),
                  ),
                  isMediaExpanded ? mediaPickerWidgets() : Container(),
                ],
              ),
            ),
          ),
        ],
      );
    }

    mediaWidget() {
      return Container(
        decoration: rectangleDecoration(),
        child: mediaHeaderWidget(),
      );
    }

    final dropdownMenuTimeZone = timeZoneList
        .map((TimeZone item) =>  DropdownMenuItem<TimeZone>(
            value: item, child:  Text(item.offset)))
        .toList();

    final timeZoneUI =  Container(
        height: 32.0,
        width: 150.0,
        padding:  EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 5.0),
        decoration:  BoxDecoration(
            border:  Border(
                bottom: BorderSide(
                    color:  ColorValues.DARK_GREY, width: 1.0))),
        child:
          DropdownButtonHideUnderline(
            child:  DropdownButton<TimeZone>(
                hint:  Text(
                  _mTimeZoneHintValue,
                  style:  TextStyle(
                      fontSize: 16.0,
                      color:  ColorValues.GREY_TEXT_COLOR,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: _mTimeZoneSelected,
                items: dropdownMenuTimeZone,
                icon: Padding(
                  padding: const EdgeInsets.only(left: 0.0),
                  child: Icon(Icons.keyboard_arrow_down),
                ),
                onChanged: (TimeZone item) {
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    _mTimeZoneSelected = item;
                    _mTimeZoneValue = item.offset;
                    isTimeZoneSelected = true;
                  });
                })));

    timeSchedueleWidget() {
      return Container(
        // decoration: rectangleDecoration(),
        child: Padding(
          padding: EdgeInsets.only(
              right: 0,
              bottom: 0,
              top: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              UIHelper.verticalSpaceExtraSmall,
              Text(
                'Schedule ',
                style:  TextStyle(
                    fontSize: 14.0,
                    color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontFamily: Constant.latoRegular),
              ),
              UIHelper.verticalSpaceExtraSmall,
              Text(
                'Select the days with your availability',
                style:  TextStyle(
                    fontSize: 12.0,
                    color:  ColorValues.labelColor,
                    fontFamily: Constant.latoRegular),
              ),

              UIHelper.verticalSpaceMedium,
              /*Text(
                      'Selected business Hours',
                      style: AppTextStyle.getDynamicFontStyle(
                          Palette.secondaryTextNewColor, 12, FontType.Regular),
                    ),*/
              timeZoneUI,

              isTimeZoneSelected
                  ?  Container(
                height: 0.0,
              )
                  : Padding(
                padding: const EdgeInsets.fromLTRB(0.0, 3, 0, 0),
                child:  Text(
                  MessageConstant.SELECT_TIMEZONE,
                  style: TextStyle(
                      fontFamily:
                      AppTextStyle.getFont(FontType.Regular),
                      fontSize: 12.0,
                      color: Palette.redColor),
                ),
              ),

              //getWeekDaysForSelection(),
              _myAdapterView(context),
              //UIHelper.verticalSpaceMedium1,

              _showAvailablityError
                  ? Padding(
                padding: const EdgeInsets.only(top: 14),
                child: Row(
                  children: [
                    Text(
                      MessageConstant.SELECT_DAY_VAL,
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: ColorValues.ERROR_COLOR,
                      ),
                    ),
                    Spacer()
                  ],
                ),
              )
                  : const SizedBox.shrink(),

              const SizedBox(height: 8,),

              InkWell(

                child:

                CustomFormField(
                  textInputType: TextInputType.text,
                  maxLength: TextLength.JOB_TITLE_MAX_LENGTH,
                  focusNode: _jobTitleFocus,
                  label: 'Expiration date ',
                  hint: "Select date ",
                  alignLabelWithHint: true,

                  controller: expiryDateController,
                  validation: (value) {
                    return expiryValidation
                        ? MessageConstant
                        .ENTER_EXPIRATION_DATE_BETWEEN_VAL
                        : ValidationChecks.validateExpiryDate(value);                  },
                  onClick: (){
                    expiryDatePickerNew(context);
                  },

                ),


/*
                TextFormField(
                  controller: expiryDateController,
                  onTap: () {
                    expiryDatePicker(context);
                  },
                  readOnly: true,
                  // enabled: false,
                  decoration:
                  textFormFieldDecorationWithLabel('Expiration Date '),
                  style: textFormFieldValueStyle(),
                  onFieldSubmitted: (term) {},
                  validator: (value) {
                    return expiryValidation
                        ? MessageConstant
                        .ENTER_EXPIRATION_DATE_BETWEEN_VAL
                        : ValidationChecks.validateExpiryDate(value);
                  },
                ),
                */
                onTap: () {
                  /*if (ageToController.text == "") {
                        ToastWrap.showToast(
                            "Please select \"scheduled date\".", context);
                      } else {*/
                 // _checkStepThreeValidation();

                  expiryDatePickerNew(context);
                  //}
                },
              ),
              UIHelper.verticalSpaceExtraSmall,
            ],
          ),
        ),
      );
    }

    ///New Design Widget  -


    String getIcon(String name) {
      switch (name) {

        case 'Internship':
          return 'assets/newDesignIcon/patner/internshipOpportunity.png';
        case 'Job':
          return 'assets/newDesignIcon/patner/jobOpportunity.png';
        case 'Volunteering':
          return 'assets/newDesignIcon/patner/volunteeringOpportunity.png';
        case 'Programs':
          return 'assets/newDesignIcon/patner/programOpportunity.png';
        case 'Services':
          return 'assets/newDesignIcon/patner/serviceOpportunity.png';
        case 'Tutors':
          return 'assets/newDesignIcon/patner/tutorOpportunity.png';
        case 'Mentors':
          return 'assets/newDesignIcon/patner/mentorOpportunity.png';
        case 'Advisors':
          return 'assets/newDesignIcon/patner/AdvisorsOpportunity.png';

        default:
          return 'assets/experience/ic_academic.png';
      }
    }

    Widget _headerView() {
      return Container(
        padding: const EdgeInsets.fromLTRB(5, 11, 12, 12),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: const Color(0xffE9ECFD),

          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Image.asset(
                'assets/newDesignIcon/patner/arrow_left_black.png',
                height: 33,
                width: 33,
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        getIcon('Advisors'),
                        height: 30,
                        width: 30,
                      ),
                      const SizedBox(width: 8),

                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: BaseText(
                            text: 'Advisors',
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w500,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    ///Step one View
    Widget _stepOneView() {
      return
        SingleChildScrollView(
          child:
          Column(
            children: [
              currentStep == 3 ? Container() :
              _headerView(),
              UIHelper.verticalGapBetweenBox,
              tutorWidget(),
              UIHelper.verticalGapBetweenBox,
              tutorBioWidget(),
              UIHelper.verticalGapBetweenBox,
              descriptionWidget(),
            ],
          ),
        );
    }

    ///Step two View
    Widget _stepTwoView() {
      return SingleChildScrollView(
          child:
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              currentStep == 3 ? Container() :
              _headerView(),
              UIHelper.verticalSpaceMedium,

              Row(
                children: [
                  BaseText(
                    text: 'Add media',
                    textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontFamily: Constant.latoRegular,
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                  ),
                  Spacer()
                ],
              ),
              UIHelper.verticalSpaceSmall,
              docListUiData,
              _showInvalidFormatePDFError
                  ?Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5,bottom: 5),
                    child: Text(
                      MessageConstant.INVALID_FILE_FORMAT_VAL,
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: ColorValues.ERROR_COLOR,
                      ),
                    ),
                  ),
                  Spacer()
                ],
              )
                  : const SizedBox.shrink(),

              UIHelper.verticalSpaceSmall,

              UIHelper.verticalSpaceSmall,
              mentorImageListUIData, //userImage(),//docListUiData,
              UIHelper.verticalSpaceSmall,
              mediaPickerWidgets(),
              UIHelper.verticalSpaceSmall,
              externalLinkWidget(),
              UIHelper.verticalSpaceMedium
            ],
          ));
    }

    ///Step three View
    ///
    Widget getMentorAdvisorTutor() {
      print('opportunity.fees:: ${selectedDataOpportunityPreview.fees}');
      return  Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          UIHelper.verticalSpaceSmall,

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              otherInformationHeader('Category '),
              SizedBox(height: 9,),
              otherInformationValue(categoryString),

            ],),


          // AppTextStyle.getBoldLableTextForDetail('Category: ', categoryString),
          //opportunity.toMapStringForDesignation()),

          selectedDataOpportunityPreview.offerId == "7" ? Container() : UIHelper.verticalSpaceMedium,
          selectedDataOpportunityPreview.offerId == "7"
              ? Container()
              :
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              otherInformationHeader('Subject '),
              SizedBox(height: 8,),
              otherInformationValue(subjectString),

            ],),
          //opportunity.toMapStringSubject()),

          selectedDataOpportunityPreview.offerId == "7" ? Container() : UIHelper.verticalSpaceMedium,

          selectedDataOpportunityPreview.offerId == "7"
              ? Container()
              :
          //  AppTextStyle.getLableTextForDetail(
          //         'Qualification: ', opportunity.toMapStringQualification()),

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              otherInformationHeader('Qualification'),
              SizedBox(height: 8,),
              otherInformationValue(selectedDataOpportunityPreview.toMapStringQualification()),

            ],),


          UIHelper.verticalSpaceMedium,

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              otherInformationHeader('Fees '),
              SizedBox(height: 8,),
              otherInformationValue(selectedDataOpportunityPreview.fees == "0"
                  ? MessageConstant.FEE_EMPTY_VAL
                  : selectedDataOpportunityPreview.fees),

            ],),
          UIHelper.verticalSpaceSmall1,


        ],
      );
    }

    getJobInternship() {
      return  Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
         // UIHelper.verticalSpaceSmall,

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              otherInformationHeader('Job Type '),
              SizedBox(height: 8,),
              otherInformationValue(selectedDataOpportunityPreview.jobType),

            ],),
          UIHelper.verticalSpaceMedium,

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              otherInformationHeader('Job Location '),
              SizedBox(height: 8,),
              otherInformationValue(selectedDataOpportunityPreview.jobLocation),

            ],),


         // UIHelper.verticalSpaceSmall1,
        ],
      );
    }
    final docListUiDataPreview = Container(
      padding: const EdgeInsets.fromLTRB(0.0, 10.0, 15.0, 0.0),
      child:
      // selectedDataOpportunityPreview.docList != null &&
      //     selectedDataOpportunityPreview.docList.isNotEmpty

      selectedDataOpportunityPreview != null
          ?  selectedDataOpportunityPreview.docList != null &&
          selectedDataOpportunityPreview.docList.isNotEmpty ?
      Wrap(
        runSpacing: 10,
        spacing: 10,
        // primary: false,
        // shrinkWrap: true,
        // padding: const EdgeInsets.all(0.0),
        // crossAxisSpacing: 10.0,
        // childAspectRatio: 0.9,
        // scrollDirection: Axis.vertical,
        // crossAxisCount: 4,
        children: selectedDataOpportunityPreview.docList
            .map((file) {
          var fileName;
          String docName = "";

          if (file?.file != null) {
            fileName = file.file.split("/");
            if (fileName.isNotEmpty) {
              docName = fileName.last;
            }
          }

          print('Apurva docListUiData docName:: $docName, file:: $file');

          return Column(
            children: <Widget>[
              Container(
                height: 60.0,
                width: 64.0,
                child: Stack(
                  children: <Widget>[
                    InkWell(
                      onTap: () {
                        print(
                            "DOC++++" + Constant.IMAGE_PATH + file.file);
                        launch(Constant.IMAGE_PATH +
                            ((file.file)
                                .replaceAll("pdf'", 'pdf')
                                .replaceAll(" ", "%20")));
                      },
                      child: Container(
                        height: 60.0,
                        width: 62.0,
                        child: Image.asset(
                          "assets/resume/ic_doc_pdf.png",
                          height: 60.0,
                          width: 62.0,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              /*
              Expanded(
                child: Container(
                  height: 14.0,
                  child: Padding(
                    padding: EdgeInsets.only(top: 3.0),
                    child: docNameLabelText('$docName'),
                  ),
                ),
              ),
              */
            ],
          );
        })
            .toList(),
      ) : Container()

          : Container(),
    );

    String getConvertedDateStamp2(String time) {
      if (time != "null") {
        int millis = int.tryParse(time);
        var now =  DateTime.fromMillisecondsSinceEpoch(millis);
        var formatter =  DateFormat('MMM dd, yyyy');
        String formatted = formatter.format(now);
        return formatted;
      } else {
        var formatter =  DateFormat('MMM dd, yyyy');
        return formatter.format(new DateTime.now());
      }
    }


    Widget _stepThreeView() {
      return SingleChildScrollView(
        child: Column(
          children: [
            currentStep == 3 ? Container() :
            _headerView(),
            UIHelper.verticalGapBetweenBox,
            feesWidget(),
            UIHelper.verticalSpaceSmall,
            timeSchedueleWidget(),
            UIHelper.verticalSpaceSmall,
            callToAction(),
            UIHelper.verticalGapBetweenBox,
            UIHelper.verticalGapBetweenBox,

            InkWell(
              child: Row(
                children: <Widget>[
                  // customCheckBox(isTargetAudience),

                  Image.asset(
                    isTargetAudience ?? false
                        ? 'assets/experience/ic_checked.png'
                        : 'assets/experience/ic_unchecked.png',
                    width: 20,
                    height: 20,
                  ),

                  UIHelper.horizontalGapBetweenBox,
                  Expanded(
                      child: Text(
                        'Set target audience',
                        style: TextStyle(
                            fontFamily: Constant.latoRegular,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                            color: ColorValues.HEADING_COLOR_EDUCATION_1),
                      ))
                ],
              ),
              onTap: () {
                // _checkAccomplishmentsValidation();
                setState(() {
                  isTargetAudience = !isTargetAudience;
                  if (isTargetAudience) {
                    selectedIntrestDataList.clear();
                  }
                });
              },
            ),

            isTargetAudience
                ? UIHelper.verticalGapBetweenBox
                : Container(),
            isTargetAudience
                ? Padding(
              padding: const EdgeInsets.only(top: 20),
              child: InkWell(
                  child: Container(
                    height: 85,
                    margin: EdgeInsets.all(0),
                    decoration: BoxDecoration(
                        color: Color(0xffE9ECFD),
                        borderRadius: BorderRadius.circular(10)),
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 10, right: 10, top: 10, bottom: 10),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text(
                                'Select from previous preferences',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                    fontFamily: Constant.latoRegular,
                                    color: ColorValues.BLUE_COLOR),
                              ),
                              Spacer()
                            ],
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            'Please select from the below list of previously targeted audience',
                            style: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 14,
                                fontFamily: Constant.latoRegular,
                                color: ColorValues.labelColor),
                          ),
                        ],
                      ),
                    ),
                  ),
                  onTap: () async {
                    final Service result = await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Audience()),
                    );
                    if (result != null) {
                      setState(() {
                        print('Return data ==>  ${result.title}');
                        //   selectedInterestList = result.interests;
                        titleController.text = result.title;
                        //toFromAge = result.ageBetween;
                        selectedCountries.clear();
                        if (result.location != null)
                          for (int i = 0; i < result.location.length; i++) {
                            selectedCountries.add(new Item(
                                1,
                                result.location[i].street1,
                                "1",
                                result.location[i].state,
                                result.location[i].country,
                                result.location[i].city,
                                result.location[i].zip));
                          }

                        selectedIntrestDataList.clear();
                        selectedIntrestDataList.addAll(result.interests);
                        for (CompetencyModel model in listCompetency) {
                          model.isSelected = false;
                          for (Level2Competencies level2
                          in model.level2Competencylist) {
                            level2.isSelected = false;
                          }
                        }
                        if (result.interests.length > 0) {
                          for (CompetencyModel model in listCompetency) {
                            for (Level2Competencies level2
                            in model.level2Competencylist) {
                              for (IntrestModel intrest
                              in result.interests) {
                                if (intrest.name == level2.name) {
                                  level2.isSelected = true;
                                  break;
                                }
                              }
                            }
                          }
                        }
                        if (result.gender != null && result.gender != "") {
                          print(
                              'Apurva if result.gender:: ${result.gender}');
                          selectedGender = _genderArray.firstWhere((test) {
                            return result.gender.toLowerCase() ==
                                test.toLowerCase();
                          });
                        } else {
                          print(
                              'Apurva else result.gender:: ${result.gender}');
                          selectedGender = "Select gender";
                        }
                        ////////////////////
                        if (result.ageBetween.length > 0) {
                          toFromAge = result.ageBetween;

                          for (int i = 0; i < result.ageBetween.length; i++) {
                            toFromAge[i].ageYearFrom.text =
                            "${toFromAge[i].fromAge} - ${toFromAge[i].toAge}";
                          }

                        } else {
                          toFromAge.add(AgeBetween(toAge: 0, fromAge: 0));
                        }
//                                    googleDocLink = result.split('#####')[0];
//                                    googleDocTitle = result.split('#####')[1];
                      });
                    }
                  }),
            )
                : Container(),

            //isTargetAudience ? UIHelper.divider : Container(),
            isTargetAudience ? targetAudienceWidget() : Container(),
            isTargetAudience ? UIHelper.divider : Container(),
          ],
        ),
      );
    }

    Widget _stepFourView() {
      return SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 15.0),
          child: selectedDataOpportunityPreview != null
              ? Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    10.0,
                    //
                    selectedDataOpportunityPreview
                        .assestVideoAndImage.length >
                        0
                        ? SizedBox(
                      // Pager view
                        height: 215.50,
                        child: PageIndicatorContainer(
                          pageView: PageView.builder(
                            itemCount: selectedDataOpportunityPreview
                                .assestVideoAndImage.length,
                            controller: PageController(),
                            itemBuilder: (context, index2) {
                              print("image+++");
                              print("image+++" +
                                  selectedDataOpportunityPreview
                                      .assestVideoAndImage[index2]
                                      .file);
                              return InkWell(
                                child: Stack(children: <Widget>[
                                  selectedDataOpportunityPreview
                                      .assestVideoAndImage[
                                  index2]
                                      .type ==
                                      "image"
                                      ? Container(
                                      decoration: BoxDecoration(
                                        color: Colors.black,
                                      ),
                                      child: CachedNetworkImage(
                                        width: double.infinity,
                                        height: 215.50,
                                        imageUrl: Constant
                                            .IMAGE_PATH +
                                            selectedDataOpportunityPreview
                                                .assestVideoAndImage[
                                            index2]
                                                .file,
                                        fit: BoxFit.contain,
                                        placeholder:
                                            (context, url) =>
                                            _loader(context),
                                        errorWidget: (context,
                                            url, error) =>
                                            _error(),
                                      ))
                                      : Container(
                                    decoration: BoxDecoration(
                                      color: Colors.black,
                                      borderRadius:
                                      BorderRadius.circular(
                                          0),
                                    ),
                                    height: 215.50,
                                    child: Center(
                                      child: VideoPlayPause(
                                          selectedDataOpportunityPreview
                                              .assestVideoAndImage[
                                          index2]
                                              .file,
                                          "",
                                          true),
                                    ),
                                  ),
                                  InkWell(
                                      onTap: () {
                                        Navigator.of(context).push(new MaterialPageRoute(
                                            builder: (BuildContext
                                            context) =>
                                                CommonFullViewWidget(
                                                    selectedDataOpportunityPreview
                                                        .assestVideoAndImage,
                                                    MessageConstant
                                                        .ACCOMPLISHMENT_HEDING,
                                                    index2,
                                                    MessageConstant
                                                        .VIEWER_END_REWCOMMENDATION_HEDING)));
                                      },
                                      child: Container(
                                        height: 215.50,
                                        width: double.infinity,
                                        child: Image.asset(
                                          "assets/newDesignIcon/navigation/layer_image.png",
                                          fit: BoxFit.fill,
                                        ),
                                      ))
                                ]),
                                onTap: () {},
                              );
                            },
                            onPageChanged: (index) {},
                          ),
                          align: IndicatorAlign.bottom,
                          length: selectedDataOpportunityPreview
                              .assestVideoAndImage.length,
                          indicatorSpace: 10.0,
                          indicatorColor:
                          selectedDataOpportunityPreview
                              .assestVideoAndImage
                              .length ==
                              1
                              ? Colors.transparent
                              : Color(0xffc4c4c4),
                          indicatorSelectorColor:
                          selectedDataOpportunityPreview
                              .assestVideoAndImage
                              .length ==
                              1
                              ? Colors.transparent
                              : ColorValues.WHITE,
                          shape: IndicatorShape.circle(size: 5.0),
                        ))
                        : Stack(children: <Widget>[
                      Image.asset(
                        "assets/profile/default_achievement.png",
                        fit: BoxFit.cover,
                        height: 215.50,
                        width: double.infinity,
                      ),
                      Container(
                        height: 215.50,
                        color: Colors.black54.withOpacity(.4),
                      )
                    ])),
                // UIHelper.verticalSpaceSmall,

                Container(
                    width: double.infinity,
                    margin: EdgeInsets.all(0),
                    padding: EdgeInsets.only(top: 20),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            selectedDataOpportunityPreview?.offerId ==
                                "4" ||
                                selectedDataOpportunityPreview?.offerId ==
                                    "5"
                                ? selectedDataOpportunityPreview
                                ?.serviceTitle
                                : selectedDataOpportunityPreview
                                ?.jobTitle,
                            //: "College Counselling",
                            style: TextStyle(
                                fontSize: 20,
                                fontFamily: Constant.latoSemibold,
                                color: ColorValues
                                    .HEADING_COLOR_EDUCATION_1),
                          ),
                          firstHalfDesc.isEmpty
                              ? Container(width: 0, height: 6)
                              : UIHelper.verticalSpaceSmall,
                          firstHalfDesc.isEmpty
                              ? Container(width: 0, height: 0)
                              : Padding(
                            padding:
                            const EdgeInsets.only(bottom: 8),
                            child: RichText(
                              text: TextSpan(
                                  text: secondHalfDesc == null &&
                                      secondHalfDesc == ""
                                      ? firstHalfDesc
                                      : flagDesc
                                      ? (firstHalfDesc + "")
                                      : (firstHalfDesc +
                                      secondHalfDesc),
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontFamily:
                                      Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color:
                                      ColorValues.labelColor),
                                  children: [
                                    TextSpan(
                                      text: secondHalfDesc == ''
                                          ? ''
                                          : flagDesc
                                          ? " More"
                                          : " Less",
                                      style: AppTextStyle
                                          .getDynamicFont(
                                          ColorValues
                                              .BLUE_COLOR,
                                          12,
                                          FontType.Regular),
                                      recognizer:
                                      TapGestureRecognizer()
                                        ..onTap = () {
                                          print(
                                              'Tap Here onTap');
                                          setState(() {
                                            flagDesc =
                                            !flagDesc;
                                          });
                                        },
                                    )
                                  ]),
                            ),
                          ),
                          selectedDataOpportunityPreview?.offerId ==
                              "6" ||
                              selectedDataOpportunityPreview
                                  ?.offerId ==
                                  "7" ||
                              selectedDataOpportunityPreview
                                  .offerId ==
                                  "8"
                              ? getMentorAdvisorTutor()
                              : selectedDataOpportunityPreview.offerId ==
                              "1" ||
                              selectedDataOpportunityPreview
                                  .offerId ==
                                  "2" ||
                              selectedDataOpportunityPreview
                                  .offerId ==
                                  "3"
                              ? getJobInternship()
                              : Container(
                            height: 0.0,
                          ),
                          selectedDataOpportunityPreview.offerId == "6" ||
                              selectedDataOpportunityPreview
                                  .offerId ==
                                  "7" ||
                              selectedDataOpportunityPreview
                                  .offerId ==
                                  "8"
                              ? UIHelper.verticalSpaceMedium
                              : Container(height: 0.0),
                          selectedDataOpportunityPreview.offerId == "6" ||
                              selectedDataOpportunityPreview
                                  .offerId ==
                                  "7" ||
                              selectedDataOpportunityPreview
                                  .offerId ==
                                  "8"
                              ? getScheduleWidget(
                              selectedDataOpportunityPreview)
                              : Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: <Widget>[
                              UIHelper.verticalSpaceMedium,
                              otherInformationHeader(
                                  'Scheduled For '),
                              UIHelper.verticalSpaceSmall,
                              otherInformationValue(
                                getConvertedDateStamp2(
                                    selectedDataOpportunityPreview
                                        .fromDate) +
                                    " - " +
                                    getConvertedDateStamp2(
                                        selectedDataOpportunityPreview
                                            .toDate),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              /*Text(
                                      'Schedule For: ' +
                                          getConvertedDateStamp2(
                                              opportunity.fromDate) +
                                          " - " +
                                          getConvertedDateStamp2(
                                              opportunity.toDate),
                                      style: AppTextStyle.getDynamicFontStyle(
                                          Palette.primaryTextColor,
                                          14,
                                          FontType.Regular),
                                    ),*/

                              otherInformationHeader('Expiration date '),
                              UIHelper.verticalSpaceSmall,
                              otherInformationValue(
                                  getConvertedDateStamp2(
                                      selectedDataOpportunityPreview
                                          .expiresOn)),
                            ],
                          )
                        ])),
                mediaDocumentList.length == 0 ||
                    selectedDataOpportunityPreview.offerId == "6"
                    ? Container(
                  height: 0.0,
                )
                    : Padding(
                    padding: const EdgeInsets.fromLTRB(
                        0.0, 20.0, 0.0, 0.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 0),
                          child: Text(
                            'Documents',
                            style: TextStyle(
                                fontFamily: Constant.latoRegular,
                                fontSize: 12,
                                color: ColorValues
                                    .HEADING_COLOR_EDUCATION_1,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                        selectedDataOpportunityPreview != null
                            ? selectedDataOpportunityPreview
                            .docList !=
                            null &&
                            selectedDataOpportunityPreview
                                .docList.isNotEmpty
                            ? docListUiDataPreview
                            : Container()
                            : Container(),
                      ],
                    )),

                selectedDataOpportunityPreview.offerId == "7" ||
                    selectedDataOpportunityPreview.offerId == "8"
                    ? Padding(
                  padding: const EdgeInsets.fromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      selectedDataOpportunityPreview != null &&
                          selectedDataOpportunityPreview
                              .userImageModelParam.length >
                              0
                          ? PaddingWrap.paddingfromLTRB(
                          0.0,
                          20.0,
                          15.0,
                          0.0,
                          otherInformationHeader(
                              "${selectedDataOpportunityPreview.offerId == "8" ? "Advisors Photo" : "Mentor Photo"}"))
                          : Container(
                        height: 0.0,
                      ),
                      userImageListUI(),
                    ],
                  ),
                )
                    : Container(),

                selectedDataOpportunityPreview.offerId == "6" ||
                    selectedDataOpportunityPreview.offerId == "7" ||
                    selectedDataOpportunityPreview.offerId == "8"
                    ? firstHalf.isEmpty
                    ? Container(height: 8)
                    : Padding(
                  padding: const EdgeInsets.fromLTRB(
                    0.0,
                    20.0,
                    0.0,
                    5.0,
                  ),
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      otherInformationHeader("Bio"),
                      UIHelper.verticalSpaceExtraSmall,
                      RichText(
                        text: TextSpan(
                            text: secondHalf.isEmpty
                                ? firstHalf
                                : flag
                                ? (firstHalf + "")
                                : (firstHalf + secondHalf),
                            //style: underlineStyle.copyWith(decoration: TextDecoration.none),
                            style: TextStyle(
                              color: ColorValues.labelColor,
                              fontFamily: Constant.latoRegular,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                            children: [
                              TextSpan(
                                text: secondHalf.isEmpty
                                    ? ''
                                    : flag
                                    ? " More"
                                    : " Less",
                                style:
                                AppTextStyle.getDynamicFont(
                                    ColorValues.BLUE_COLOR,
                                    14,
                                    FontType.Regular),
                                recognizer:
                                TapGestureRecognizer()
                                  ..onTap = () {
                                    print('Tap Here onTap');
                                    setState(() {
                                      flag = !flag;
                                    });
                                  },
                              )
                            ]),
                      ),
                    ],
                  ),
                )
                    : Container(),

                mediaDocumentList.length != 0 &&
                    selectedDataOpportunityPreview.offerId == "6"
                    ? Padding(
                    padding: const EdgeInsets.fromLTRB(
                        0.0, 20.0, 0.0, 0.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        otherInformationHeader(
                            'Teaching Certifications'),

                        // mediaLabelText(
                        //     'Teaching Certifications'),

                        selectedDataOpportunityPreview != null
                            ? selectedDataOpportunityPreview
                            .docList !=
                            null &&
                            selectedDataOpportunityPreview
                                .docList.isNotEmpty
                            ? docListUiDataPreview
                            : Container()
                            : Container(),
                      ],
                    ))
                    : Container(
                  height: 10.0,
                ),

                googleLinkList.length == 0
                    ? Container(
                  height: 0.0,
                )
                    : googleLinkList[0].file.trim().length > 0
                    ? Padding(
                  padding: const EdgeInsets.fromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                  ),
                  child: otherInformationHeader(
                      'Additional Link(s): '),
                )
                    : new Container(
                  height: 0.0,
                ),

                Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:
                    List.generate(googleLinkList.length, (index) {
                      return Padding(
                        padding:
                        EdgeInsets.fromLTRB(0.0, 10.0, 23.0, 0.0),
                        child: InkWell(
                          child: Text(
                            googleLinkList[index].label.trim() == "null"
                                ? googleLinkList[index].file.trim()
                                : googleLinkList[index].label.trim(),
                            style: AppTextStyle.getDynamicFontStyle(
                                Palette.accentColor,
                                14,
                                FontType.Regular),
                          ),
                          onTap: () {
                            String url = "";
                            if (googleLinkList[index]
                                .file
                                .contains("http")) {
                              url = googleLinkList[index].file;
                            } else {
                              url =
                                  "http://" + googleLinkList[index].file;
                            }
                            Navigator.push(
                                Constant.applicationContext,
                                MaterialPageRoute(
                                  //   builder: (context) =>  DashBoardWidget()));
                                    builder: (context) => WebViewWidget(
                                        url, "Document Link")));
                          },
                        ),
                      );
                    })),

                selectedDataOpportunityPreview.targetAudience ==
                    "true"
                    ?
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    20.0,
                    0.0,
                    0.0,
                    location != "" || selectedDataOpportunityPreview.gender != "" || selectedDataOpportunityPreview
                        .ageList.length != 0 || selectedDataOpportunityPreview
                        .interestTypeList.length != 0 ?
                    Container(
                        decoration: BoxDecoration(
                          color: ColorValues.SELECTION_BG,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        // Border.all(color: ColorValues.BORDER_COLOR, width: 0.5)),
                        child: Column(
                            children: <Widget>[

                              Container(
                                clipBehavior: Clip.antiAlias,
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                                decoration: BoxDecoration(
                                  color:const Color(0xffE8ECFF),
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(10),
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 4,bottom: 4),
                                  child: Row(

                                    children: [
                                      const SizedBox(width: 10),

                                      Expanded(
                                        child: Text(
                                          "Other Information",
                                          style: TextStyle(
                                            color: const Color(0xff27275A),
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: AppConstants.stringConstant.latoMedium,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      const SizedBox(width: 5)
                                    ],
                                  ),
                                ),
                              ),

                              selectedDataOpportunityPreview.targetAudience ==
                                  "true"
                                  ?
                              Align(
                                  alignment: Alignment.topLeft,
                                  child:

                                  Container(
                                      padding: EdgeInsets.fromLTRB(20, 0, 0, 8),
                                      child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: <Widget>[
                                            // UIHelper.verticalSpaceSmall,

                                            location != ""
                                                ? Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 15, bottom: 5),
                                              child: Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                MainAxisAlignment.start,
                                                children: <Widget>[
                                                  otherInformationHeader(
                                                      'Location you like to cover'),
                                                  SizedBox(
                                                    height: 8,
                                                  ),
                                                  otherInformationValue(
                                                      location.trim()),
                                                ],
                                              ),
                                            )
                                                : Container(
                                              height: 0.0,
                                            ),

                                            selectedDataOpportunityPreview.gender ==
                                                ""
                                                ? Container(
                                              height: 0.0,
                                            )
                                                : Container(
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 20),
                                                child: Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    // UIHelper.verticalSpaceMedium,
                                                    otherInformationHeader(
                                                        'Gender'),
                                                    SizedBox(
                                                      height: 8,
                                                    ),
                                                    otherInformationValue(
                                                        selectedDataOpportunityPreview
                                                            .gender),
                                                  ],
                                                ),
                                              ),
                                            ),

                                            // UIHelper.verticalSpaceMedium,
                                            selectedDataOpportunityPreview
                                                .ageList.length ==
                                                0
                                                ? Container(
                                              height: 0.0,
                                            )
                                                : Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: <Widget>[
                                                SizedBox(
                                                  height: 20,
                                                ),
                                                otherInformationHeader(
                                                    'Age group'),
                                                SizedBox(
                                                  height: 3,
                                                ),
                                                getAgeList(),
                                              ],
                                            ),

                                            selectedDataOpportunityPreview
                                                .interestTypeList.length ==
                                                0
                                                ? Container(
                                              height: 0.0,
                                            )
                                                : Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                MainAxisAlignment.start,
                                                children: <Widget>[
                                                  SizedBox(
                                                    height: 20,
                                                  ),
                                                  otherInformationHeader(
                                                      'Interests'),
                                                  SizedBox(
                                                    height: 4,
                                                  ),


                                                  /*
                                          List.generate(
                                              selectedDataOpportunityPreview
                                                  .interestTypeList
                                                  .length, (index) {
                                            return otherInformationValue(
                                                selectedDataOpportunityPreview
                                                    .interestTypeList[
                                                index]
                                                    .name);
                                          }),


                                               */
                                                  Container(
                                                      decoration: BoxDecoration(
                                                        //color: Colors.white,
                                                        // border:  Border.all(
                                                        //     color:   ColorValues.DEVIDER_COLOR,
                                                        //     width: 1.0)
                                                      ),
                                                      child: Wrap(
                                                        spacing: 0.0,
                                                        runSpacing: 0.0,
                                                        children: selectedDataOpportunityPreview
                                                            .interestTypeList.map((level) {
                                                          return Padding(
                                                              padding: const EdgeInsets.only(left: 0,right: 10,top: 5,bottom: 5),
                                                              child: Container(
                                                                decoration: BoxDecoration(
                                                                  color: ColorValues.DARK_YELLOW,
                                                                  borderRadius: BorderRadius.circular(6),
                                                                ),
                                                                child: Padding(
                                                                  padding: const EdgeInsets.only(left: 8,right: 8,top: 5,bottom: 5),
                                                                  child: Row(
                                                                    mainAxisSize: MainAxisSize.min,
                                                                    children: [
                                                                      InkWell(
                                                                        onTap: () {

                                                                        },
                                                                        child: Text(
                                                                          '${level.name}',
                                                                          style: TextStyle(
                                                                            fontSize: 12.0,
                                                                            fontFamily: Constant.latoRegular,
                                                                            fontWeight: FontWeight.w400,
                                                                            color: Colors.white,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              )


                                                          );
                                                        }).toList(),
                                                      )

                                                  ),


                                                  UIHelper.verticalSpaceSmall,

                                                ]
                                            )


                                          ])

                                  )
                              ): const SizedBox()

                            ])
                    ) :const SizedBox(),

                ) : const SizedBox(),

              ],
            ),
          )
              : Container(
            child: Center(child: Text("")),
          ),
        ),
      );
    }


    Widget _negativeButton({@required String title}) {
      return InkWell(
        onTap: () {
          if  (currentStep == 0){
            Navigator.pop(context);

          }else{
            _goToPreviousStep();

          }
        },
        child: Container(
          height: 44,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: ColorValues.WHITE,
            border: Border.all(color: Color(0xffB2BDDB)),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            title,
            textAlign: TextAlign.center,
            style: AppConstants.txtStyle.heading18600LatoRegularLightPurple,

          ),
        ),
      );
    }

    void _positiveTap() {
      if (currentStep == 2) {
        onTapPreview();
      }else if (currentStep == 3){
        widget.type == "edit" ? onTapEdit() : onTapCreate();
      }
      else {
      //  _checkAccomplishmentsValidation();
        _goToNextStep();
      }
      setState(() {
        // if (currentStep < 3) {
        //   currentStep += 1;
        // }
      });

    }

    return SafeArea(
      child: Scaffold(
        /*
        appBar:  AppBar(
          elevation: 0.0,
          backgroundColor: Colors.white,
          centerTitle: true,
          title: Text('Advisors',
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.primaryTextColor, 18, FontType.Regular)),
          leading: backIcon(context),
          actions: <Widget>[
            InkWell(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 0.0, 14.0, 0.0),
                  child: Text(
                    widget.type == "edit" ? "Submit  " : 'Repost  ',
                    textAlign: TextAlign.center,
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 16, FontType.Regular),
                  ),
                ),
              ),
              onTap: () {
                widget.type == "edit" ? onTapEdit() : onTapCreate();
              },
            )
          ],
        ),
         */
        body: WillPopScope(
          onWillPop: () {
            // _onBackPressed();
            Navigator.pop(context, "pop");

            return Future.value(false);
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.fromLTRB(20, 50, 20, 14),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        BaseText(
                          text: 'Update Opportunity',
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w700,
                          fontSize: 28,
                          maxLines: 1,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top:5),
                          child:
                          InkWell(
                          child: SizedBox(
                            height: 32.0,
                            width: 32.0,
                            child: Center(
                              child: Image.asset(
                                "assets/new_onboarding/help_icon.png",
                                height: 32.0,
                                width: 32.0,
                                fit: BoxFit.fitHeight,
                              ),
                            ),
                          ),
                          onTap: () {},
                        )),
                      ],
                    ),
                    const SizedBox(height: 4),
                    BaseText(
                      text: "Share an opportunity with the community",
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontWeight: FontWeight.w400,
                      fontSize: 16,
                    ),
                    const SizedBox(height: 14),
                    StepperWidget(length: 4, currentStep: currentStep),
                  ],
                ),
              ),
              Expanded(
                child: GestureDetector(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 9, right: 9),
                    child: Container(
                     // color: Palette.white,
                      child:

                      Form(
                        key: _jobFormKey,
                        child: Container(
                          padding:

                          EdgeInsets.only(bottom: 13,left: 13,right: 13,top: 0),

                          //color: Colors.greenAccent,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: <Widget>[

                              Expanded(
                                child:
                                PageView(
                                  controller: _pageController,
                                  physics: const NeverScrollableScrollPhysics(),
                                  onPageChanged: (value) {
                                    currentStep = value;
                                    setState(() {});
                                  },

                                  children: [

                                    _stepOneView(),
                                    _stepTwoView(),
                                    _stepThreeView(),
                                    _stepFourView(),

                                  ],
                                ),
                              ),
                              ///  UIHelper.verticalGapBetweenBox,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  onTap: () {
                    FocusScope.of(context).requestFocus(FocusNode());
                  },
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: Container(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
          height: 90,
          //currentStep == 0 ? 0 : 90,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromRGBO(204, 220, 247, 0.46),
                blurRadius: 13,
                spreadRadius: 10,
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(
                flex: currentStep >= 0 ? 30 : 1,
                child: _negativeButton(
                    title: 'Back'),
              ),
              currentStep >= 0
                  ? Expanded(
                flex: 66,
                child: Padding(
                  padding: const EdgeInsets.only(left: 12),
                  child: SizedBox(
                    height: 44,
                    child: PositiveButton(
                      onTap: () => _positiveTap(),
                      // isEnable: true,
                      isEnable: currentStep == 0
                          ? _isProcessEnable
                          : currentStep == 1 ? _isProcessForStepTwoEnable : true,
                      title: currentStep == 3 ? widget.type == "edit" ? "Submit  " : 'Repost  ' : currentStep == 2
                          ? 'Preview'
                          : 'Proceed',
                    ),
                  ),
                ),
              )
                  : const SizedBox.shrink(),
            ],
          ),
        ),
      ),
    );
  }

  tutorWidget() {
    return Container(
      // decoration: rectangleDecoration(),
      child:
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          UIHelper.verticalSpaceSmall,

          CustomFormField(
            autovalidateMode: AutovalidateMode.disabled,
            textInputType: TextInputType.text,
            maxLength: TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
            focusNode: _jobTitleFocus,
            label: 'Title',
            hint: "Neurosciences research advisor",
            alignLabelWithHint: true,
            onType: (val) => _checkStepOneValidaiton(),
            onSaved: (value) {
              _jobTitleFocus.unfocus();
              _checkStepOneValidaiton();
              //  FocusScope.of(context).requestFocus(_jobTypeFocus);
            },
            controller: jobTitleController,
            validation: (value) {
              return ValidationChecks.validateJobTitle(value);
            },
          ),


          UIHelper.verticalSpaceMedium,
          designationWidget(),
          UIHelper.verticalSpaceMedium,
          subjectWidget(),
          UIHelper.verticalSpaceMedium,
          qualificationWidget(),
          UIHelper.verticalSpaceSmall,
        ],
      ),

    );
  }



  double _maxHeight = 50.0;

  // double mainMaxHeight = 120.0;

  updateUi(dynamic data) {
    setState(() {
      _maxHeight += data.delta.dy;

      // prevent overflow if height is more/less than available space
      // var maxLimit = _maxHeight - _dividerHeight - _dividerSpace;
      var minLimit = 50.0;

      // if (_height > maxLimit)
      //   _height = maxLimit;
      // else
      if (_maxHeight < minLimit) _maxHeight = minLimit;
    });
  }

  void conformationDialogold(type, file) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    "Are you sure you want to remove?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Remove",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              if (type == "mentorimage") {
                                                /*setState(() {
                                                  userImageString = '';
                                                  userImageFile = null;
                                                });*/
                                                mentorImagesList.remove(file);
                                                setState(() {
                                                  mentorImagesList;
                                                });
                                                _checkStepTwoValidaiton();

                                              } else if (type == "image") {
                                                mediaImagesList.remove(file);
                                                setState(() {
                                                  mediaAndVideoList
                                                      .removeLast();
                                                  mediaImagesList;
                                                });
                                                _checkStepTwoValidaiton();

                                              } else if (type == "video") {
                                                mediaVideosList.remove(file);
                                                setState(() {
                                                  mediaAndVideoList
                                                      .removeLast();
                                                  mediaVideosList;
                                                });
                                                _checkStepTwoValidaiton();

                                              } else if (type == "doc") {
                                                mediaDocumentList.remove(file);
                                                setState(() {
                                                  mediaDocumentList;
                                                });
                                              }

                                              _checkStepTwoValidaiton();
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void conformationDialog(type, file) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: "Are you sure you want to remove?",
          onPositiveTap: (){
            if (type == "mentorimage") {

              mentorImagesList.remove(file);
              setState(() {
                mentorImagesList;
              });
              _checkStepTwoValidaiton();

            } else if (type == "image") {
              mediaImagesList.remove(file);
              setState(() {
                mediaAndVideoList
                    .removeLast();
                mediaImagesList;
              });
              _checkStepTwoValidaiton();

            } else if (type == "video") {
              mediaVideosList.remove(file);
              setState(() {
                mediaAndVideoList
                    .removeLast();
                mediaVideosList;
              });
              _checkStepTwoValidaiton();

            } else if (type == "doc") {
              mediaDocumentList.remove(file);
              setState(() {
                mediaDocumentList;
              });
            }

            _checkStepTwoValidaiton();
          },
        );
      },
    );
  }

  interactWidget() {
    return Container(
      padding: EdgeInsets.fromLTRB(5, 8, 12, 12),
      // decoration: rectangleDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text(
            'How would you like to interact with your audience for this opportunity?',
            style: TextStyle(
                fontWeight: FontWeight.w400,
                fontSize: 14,
                fontFamily: Constant.latoRegular,
                color: ColorValues.labelColor),
          ),
          UIHelper.verticalSpaceSmall,
          InkWell(
            child: Row(
              children: <Widget>[
                // customRadioButton(chooseExistingGroup),

                Image.asset(
                    chooseExistingGroup
                        ? "assets/future_goals/future_check.png"
                        : "assets/future_goals/future_Uncheck.png",
                    height: 15,
                    width: 15),
                UIHelper.horizontalGapBetweenBox,

                Text(
                  'Choose existing group',
                  style: TextStyle(
                      color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontWeight: FontWeight.w600,
                      fontSize: 14.0,
                      fontFamily: Constant.latoMedium),
                )
              ],
            ),
            onTap: () {
              if (selectedGroup != null)
                showSelectedGroupDialog2(0);
              else {
                setState(() {
                  selectedGroup = null;
                  chooseExistingGroup = !chooseExistingGroup;
                  createNewGroup = !chooseExistingGroup;
                });
              }
            },
          ),
          chooseExistingGroup
              ? InkWell(
            onTap: () async {
              final Map<String, dynamic> result = await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => GroupList()),
              );
              if (result != null) {
                setState(() {
                  isActionSelected = true;
                  selectedGroupId = result['id'];
                  selectedGroup = result['name'];
                  isGroupPublic = result['isPublic'];
                });
              }
            },
            child: Padding(
              padding: EdgeInsets.only(left: 33,top:2),
              child: selectedGroup == null
                  ? Text(
                'Choose group',
                style: TextStyle(
                    color:  ColorValues.labelColor,
                    fontWeight: FontWeight.w600,
                    fontSize: 12.0,
                    fontFamily: Constant.latoMedium),
              )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  // mediaLabelText('Google doc link'),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          selectedGroup,
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.primaryTextColor,
                              14,
                              FontType.Bold),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            "assets/experience/ic_remove.png",
                            height: 15,
                            width: 15,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            selectedGroup = null;
                          });
                        },
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
              : Container(),
          UIHelper.verticalSpaceSmall,
          InkWell(
            child: Row(
              children: <Widget>[
                // customRadioButton(createNewGroup),

                Image.asset(
                    createNewGroup
                        ? "assets/future_goals/future_check.png"
                        : "assets/future_goals/future_Uncheck.png",
                    height: 15,
                    width: 15),
                UIHelper.horizontalGapBetweenBox,

                Text(
                  'Create group',
                  style: TextStyle(
                      color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontWeight: FontWeight.w600,
                      fontSize: 14.0,
                      fontFamily: Constant.latoMedium),
                )
              ],
            ),
            onTap: () {
              if (selectedGroup != null)
                showSelectedGroupDialog2(1);
              else {
                setState(() {
                  selectedGroup = null;
                  createNewGroup = !createNewGroup;
                  chooseExistingGroup = !createNewGroup;
                });
              }
            },
          ),
          createNewGroup
              ? Padding(
            padding: EdgeInsets.only(left: 33,),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top:4,bottom: 3),
                  child: Text(
                    /* 'You can create and manage a  public group'*/
                    'Please create a group so the users can join and interact with you regarding your opportunity.',
                    style: TextStyle(
                        fontFamily: Constant.latoRegular,
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                        color: ColorValues.labelColor),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    final Map<String, dynamic> result =
                    await Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (BuildContext context) =>
                                AddGroupWidget(sasToken, sasContainer,
                                    "create")));
                    ;
                    if (result != null) {
                      setState(() {
                        isActionSelected = true;
                        selectedGroupId = result['id'];
                        selectedGroup = result['name'];
                        isGroupPublic = result['isPublic'];
                      });
                    }
                  },
                  child: selectedGroup == null
                      ? Text(
                    'Create group',
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 12, FontType.Regular),
                  )
                      : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              selectedGroup,
                              style:
                              AppTextStyle.getDynamicFontStyle(
                                  Palette.primaryTextColor,
                                  14,
                                  FontType.Bold),
                            ),
                          ),
                          InkWell(
                            child: Container(
                              padding: EdgeInsets.all(0),
                              child: Image.asset(
                                "assets/experience/ic_remove.png",
                                height: 15,
                                width: 15,
                              ),
                            ),
                            onTap: () {
                              setState(() {
                                selectedGroup = null;
                              });
                            },
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
          )
              : Container(),
        ],
      ),
    );
  }

  targetAudienceWidget() {
    return Container(
      //color: Colors.white,
      padding: EdgeInsets.only(top: 10, bottom: 10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          CustomFormField(
            textInputType: TextInputType.text,
            focusNode: _titleFocus,
            controller: titleController,
            label: 'Title',
            hint: "",
            alignLabelWithHint: true,
            //onType: (val) => _checkAccomplishmentsValidation(),
            onSaved: (value) {
              //  _checkAccomplishmentsValidation();
              _titleFocus.unfocus();
            },
            validation: (value) {
              return ValidationChecks.validateTitle(value);
            },
          ),

          Padding(
            padding: EdgeInsets.only(top: 9),
          ),
          Text(
            'Give a title to the target audience you select. We will store it if you want to use it in the future.',
            style: TextStyle(
                fontFamily: Constant.customItalic,
                fontSize: 12,
                //  fontStyle:italic,
                fontWeight: FontWeight.w400,
                color: ColorValues.light_grey),
          ),

          UIHelper.verticalSpaceSmall1,

          FormField<String>(
            builder: (FormFieldState<String> state) {
              return InputDecorator(
                decoration: InputDecoration(
                  labelText: 'Location you like to cover',
                  errorStyle: Util.errorTextStyle,
                  alignLabelWithHint: true,
                  hintStyle: AppTextStyle.getDynamicFontStyle(
                      Palette.secondaryTextColor, 14, FontType.Regular),
                  labelStyle: AppTextStyle.getDynamicFontStyle(
                      Palette.secondaryTextColor, 16, FontType.Regular),
                  enabledBorder: UnderlineInputBorder(
                    borderSide:
                    BorderSide(color: Palette.dividerColor, width: 1.0),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide:
                    BorderSide(color: Palette.dividerColor, width: 1.0),
                  ),
                  border: UnderlineInputBorder(
                    borderSide:
                    BorderSide(color: Palette.dividerColor, width: 1.0),
                  ),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: selectedLocation,
                    icon: SizedBox(
                        width: 18.0,
                        height: 18.0,
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                          child:Image.asset(
                            'assets/new_onboarding/arrow_down.png',
                          ),

                        )),

                    isDense: true,
                    onChanged: (String newValue) async {
                      setState(() {
                        selectedLocation = newValue;
                        state.didChange(newValue);
                      });
                      selectedCountries.clear();
                      // print(
                      //     "isFirstTimeCurrentLocation:: $isFirstTimeCurrentLocation 111");
                      if (selectedLocation == _locationArray[3]) {
                        /*print("isFirstTimeCurrentLocation:: $isFirstTimeCurrentLocation 222");
                        Placemark placemark = await API.getUserLocation();
                        print("isFirstTimeCurrentLocation:: $isFirstTimeCurrentLocation, placemark.locality:: ${placemark.locality}");
                        if(isFirstTimeCurrentLocation){
                          print("isFirstTimeCurrentLocation inside:: $isFirstTimeCurrentLocation, placemark.locality:: ${placemark.locality}");
                          placemark = await API.getUserLocation();
                          isFirstTimeCurrentLocation = false;
                        }
                        print(placemark.locality);*/

                        //----------------Apurva Added
                        String currentCity = await API.getUserCity();

                        showList = false;
                        //selectedCountries.add(new Item(1, placemark.locality, "1", "", "", placemark.locality, ""));
                        selectedCountries.add(new Item(
                            1,
                            currentCity,
                            "1",
                            "",
                            "",
                            currentCity,
                            ""));
                        setState(() {});
                      } else if (selectedLocation == _locationArray[1]) {
                        showList = false;
                        setState(() {});
                        if (searchCountryController.text.isNotEmpty) {
                          countries = await API.fetchCountryList(
                              searchCountryController.text,
                              'regions'); /////////////////////////
                        } else {
                          countries =
                          await API.fetchCountryList('USA', 'regions');
                        }

                        setState(() {
                          countries; // = removeAlreadyAddedItems(countries,selectedCountries);
                        });
                      } else if (selectedLocation == _locationArray[2]) {
                        showList = false;
                        setState(() {});
                        if (searchCountryController.text.isNotEmpty) {
                          countries = await API.fetchCountryList(
                              searchCountryController.text, 'cities');
                        } else {
                          countries =
                          await API.fetchCountryList('USA', 'cities');
                        }
                        setState(() {
                          countries; // = removeAlreadyAddedItems(countries,selectedCountries);
                        });
                      }
                    },
                    items: _locationArray.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: value == _locationArray[3]
                            ? Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                value,
                                style: textFormFieldValueStyle(),
                              ),
                              Container(width: 8),
                              colorIcon(ImagePath.ICON_LOCATION, 20, 20),
                            ],
                          ),
                        )
                            : Text(
                          value,
                          style: textFormFieldValueStyle(),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              );
            },
          ),

          // add animated list of dropdown from personal info view here
          selectedLocation == _locationArray[3]
              ? Container()
              : UIHelper.verticalSpaceSmall1,
          selectedLocation == _locationArray[3]
              ? Container()
              : Container(
            decoration: bottomBorder(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                selectedCountries.length > 0
                    ? Text(
                  selectedLocation == _locationArray[1]
                      ? 'Select countries'
                      : selectedLocation == _locationArray[2]
                      ? 'Select cities'
                      : '',
                  style: AppTextStyle.getDynamicFontStyle(
                      Palette.secondaryTextColor,
                      12,
                      FontType.Regular),
                )
                    : Container(),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    selectedCountries.length > 0
                        ? Expanded(
                      flex: 1,
                      child: Wrap(
                        children: getSelectedWidgets(),
                      ),
                    )
                        : Expanded(
                      flex: 1,
                      child: selectCountryCityTextField(),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 25),
                      child: IconButton(
                        iconSize: 90,
                        onPressed: () {
                          showList = !showList;
                          setState(() {});
                        },
                        alignment: Alignment.centerRight,
                        icon: Padding(
                          padding: const EdgeInsets.only(left: 0),
                          child: SizedBox(
                              width: 18.0,
                              height: 18.0,
                              child: Padding(
                                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                child:showList == true
                                    ? new Image.asset(
                                  'assets/new_onboarding/arrow_up.png',
                                )
                                    : new Image.asset(

                                  'assets/new_onboarding/arrow_down.png',
                                ),

                              )),
                        ),



                      ),
                    ),
                  ],
                ),
                selectedCountries.length > 0
                    ? selectCountryCityTextField()
                    : Container(),
              ],
            ),
          ),
          Stack(
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  UIHelper.verticalSpaceSmall,
                  FormField<String>(
                    builder: (FormFieldState<String> state) {
                      return InputDecorator(
                        decoration: InputDecoration(
                          labelText: 'Gender',
                          errorStyle: Util.errorTextStyle,
                          alignLabelWithHint: true,
                          hintStyle: AppTextStyle.getDynamicFontStyle(
                              Palette.secondaryTextColor, 14, FontType.Regular),
                          labelStyle: AppTextStyle.getDynamicFontStyle(
                              Palette.secondaryTextColor, 16, FontType.Regular),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: Palette.dividerColor, width: 1.0),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: Palette.dividerColor, width: 1.0),
                          ),
                          border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: Palette.dividerColor, width: 1.0),
                          ),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selectedGender,
                            icon: SizedBox(
                                width: 18.0,
                                height: 18.0,
                                child: Padding(
                                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                  child:Image.asset(
                                    'assets/new_onboarding/arrow_down.png',
                                  ),

                                )),
                            isDense: true,
                            onChanged: (String newValue) {
                             // _checkAccomplishmentsValidation();

                              setState(() {
                                selectedGender = newValue;
                                state.didChange(newValue);
                              });
                            },
                            items: _genderArray.map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value,
                                  style: textFormFieldValueStyle(),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      );
                    },
                  ),


                  ListView.builder(
                    itemCount: toFromAge.length,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemBuilder: (context, index) {
                      final ageFrom = TextEditingController();
                      final ageTo = TextEditingController();

                      if (toFromAge[index].fromAge.toString() != "0") {
                        ageFrom.text = toFromAge[index].fromAge.toString();
                      }
                      if (toFromAge[index].toAge.toString() != "0") {
                        ageTo.text = toFromAge[index].toAge.toString();
                      }

                      return Container(
                        padding: EdgeInsets.only(top: 10),
                        child: Row(
                          children: <Widget>[

                            Expanded(
                              child: Column(
                                children: [
                                  PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      15.0,
                                      0.0,
                                      0.0,
                                      TextField(
                                        controller: toFromAge[index].ageYearFrom,
                                        showCursor: false,
                                        readOnly: true,
                                        onTap: () {
                                          setState(() {
                                            // organizationLstSchool.clear();
                                            visibleAgeFromToPrimary = true;
                                            //showPrimaryGradView = false;
                                            // SchoolNameFocusNode.unfocus();
                                            toFromAge[index].isShowAge = true ;
                                            FocusManager.instance.primaryFocus.unfocus();
                                            startAge  = toFromAge[index].fromAge;
                                            endAge = toFromAge[index].toAge;

                                          });
                                        },
                                        //focusNode: ageGroupFocusNode,
                                        style: TextStyle(
                                          //  color:
                                          // ageGroupFocusNode.hasFocus ?AppConstants.colorStyle.lightBlue :
                                          // ageGroupFocusNode.hasFocus
                                          //     ? AppConstants.colorStyle.lightBlue
                                          //     : AppConstants.colorStyle.darkBlue,
                                          fontSize: 18.0,
                                          fontWeight: FontWeight.w500,
                                          fontFamily: AppConstants.stringConstant.latoMedium,

                                        ),
                                        decoration: InputDecoration(
                                          contentPadding:
                                          const EdgeInsets.fromLTRB(0, 10, 0, 10),
                                          labelText: "Age",
                                        ),
                                      )),

                                  toFromAge[index].isShowAge == true ?

                                  Visibility(
                                    visible : true ,
                                    //visible: visibleAgeFromToPrimary,
                                    child: Container(
                                      padding:
                                      const EdgeInsets.only(top: 0, right: 10, left: 10),
                                      decoration: const BoxDecoration(
                                          color: Colors.white,
                                          boxShadow: [
                                            BoxShadow(
                                                color: Colors.black12,
                                                offset: Offset(0, 2),
                                                blurRadius: 12)
                                          ]),
                                      height: 150,
                                      width: double.maxFinite,
                                      child: Column(
                                        children: [
                                          Expanded(
                                            child: GridView.builder(
                                              padding: EdgeInsets.only(top: 10),
                                              itemCount: years.length,
                                              gridDelegate:
                                              const SliverGridDelegateWithFixedCrossAxisCount(
                                                crossAxisCount: 5,
                                                crossAxisSpacing: 0.5,
                                                childAspectRatio: 3 / 2,
                                              ),
                                              itemBuilder: (context, index) {
                                                final year = years[index];
                                                return InkWell(
                                                  onTap: () => setIndex(index),
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: getBoxColour(index),
                                                      border: showBorder(index)
                                                          ? const Border.symmetric(
                                                        horizontal: BorderSide(
                                                            color: Color(0xFFE5EBF0)),
                                                      )
                                                          : null,
                                                      // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                                      borderRadius: showBorder(index)
                                                          ? null
                                                          : BorderRadius.horizontal(
                                                        left: startAge == year
                                                            ? const Radius.circular(10)
                                                            : Radius.zero,
                                                        right: endAge == year
                                                            ? const Radius.circular(10)
                                                            : Radius.zero,
                                                        // right: Radius.circular(25),
                                                      ),
                                                    ),
                                                    padding: const EdgeInsets.symmetric(
                                                        vertical: 5, horizontal: 5),
                                                    margin: const EdgeInsets.symmetric(
                                                        vertical: 5, horizontal: 0),
                                                    alignment: Alignment.center,
                                                    child: Text(
                                                      years[index].toString(),
                                                      style: TextStyle(
                                                        color: getFontColour(index),
                                                        fontSize: 16,
                                                        fontFamily: Constant.latoRegular,
                                                        fontWeight: FontWeight.w600,
                                                      ),
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                          SizedBox(
                                            width: double.maxFinite,
                                            child: TextButton(
                                              onPressed: () {

                                                visibleAgeFromToPrimary = false;
                                                if (startAge != null &&
                                                    endAge != null) {
                                                  setTextFieldValue();

                                                  toFromAge[index].fromAge = startAge;
                                                  toFromAge[index].toAge = endAge;
                                                  toFromAge[index].ageYearFrom.text = "${startAge} - ${endAge}";

                                                  startAge = null;
                                                  endAge = null;
                                                  toFromAge[index].isShowAge = false ;
                                                  setState(() {});
                                                  //int.parse(startAge);
                                                } else {
                                                  setState(() {

                                                    ageFromController.text = "";
                                                    toFromAge[index].ageYearFrom.text = "";
                                                    toFromAge[index].isShowAge = false ;
                                                    toFromAge[index].toAge = null;
                                                    toFromAge[index].fromAge = null;

                                                  });
                                                }
                                                setState(() {});
                                                //  Navigator.pop(context);
                                              },
                                              child: Text(
                                                startAge != null && endAge != null
                                                    ? "Apply"
                                                    : 'Cancel',
                                                style: TextStyle(
                                                  color: startAge != null &&
                                                      endAge != null
                                                      ? AppConstants.colorStyle.lightBlue
                                                      : AppConstants
                                                      .colorStyle.lightPurple,
                                                  fontSize: 16,
                                                  fontFamily: Constant.latoRegular,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  )  : Container(),
                                ],
                              ),
                            ),



                            Padding(
                              padding: const EdgeInsets.only(top: 25),
                              child: InkWell(
                                child: index > 0
                                    ? Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    "assets/experience/ic_remove.png",
                                    height: 15,
                                    width: 15,
                                  ),
                                )
                                    : Container(
                                  height: 24.18,
                                  width: 17,
                                ),
                                onTap: () {
                                  if (toFromAge.length > 1) {
                                    print('Index is =======>  $index');
                                    //                            toFromAge.remove(toFromAge[index]);
                                    toFromAge.removeAt(index);
                                  }
                                  setState(() {});
                                },
                              ),
                            ),

                          ],
                        ),
                      );
                    },
                  ),




                  InkWell(
                    child: Padding(
                      padding: EdgeInsets.only(top: 7, bottom: 5),
                      child: Text(
                        'Add another age group',
                        style: TextStyle(
                            fontFamily: Constant.latoRegular,
                            fontSize: 14,
                            //  fontStyle:italic,
                            fontWeight: FontWeight.w700,
                            color: ColorValues.HEADING_COLOR_EDUCATION_2),
                      ),
                    ),
                    onTap: () {
                      setState(() {
                        toFromAge.add(AgeBetween(toAge: 0, fromAge: 0));
                      });
                    },
                  ),
                  UIHelper.verticalGap(40),

                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: InkWell(
                                child: TextViewWrap.textView(
                                    selectedIntrestDataList.length == 0
                                        ? "Add Interest"
                                        : "Interest",
                                    TextAlign.start,
                                    selectedIntrestDataList.length == 0
                                        ? ColorValues.labelColor
                                        : ColorValues.labelColor,
                                    selectedIntrestDataList.length == 0
                                        ? 14.0
                                        : 14.0,
                                    FontWeight.normal),
                                onTap: () {
                                  // if (selectedIntrestDataList.length == 0) {
                                  //   showCompetencySelection();
                                  // }
                                  // ;
                                }),
                            flex: 1,
                          )
                        ],
                      )),
                  UIHelper.verticalGap(5),

                  showIntrestNew(),
                  UIHelper.verticalGap(10),
                ],
              ),
              countryOrCityListWidget(),
            ],
          ),
        ],
      ),
    );
  }

  selectCountryCityTextField() {
    return TextFormField(
      decoration:
          textFormFieldDecorationWithNoBorders(selectedCountries.length <= 0
              ? selectedLocation == _locationArray[1]
                  ? 'Select countries'
                  : selectedLocation == _locationArray[2]
                      ? 'Select cities'
                      : ''
              : ''),
      controller: searchCountryController,
      onChanged: (value) {
        setState(() {
          showList = true;
        });
      },
/*      onChanged: (String keyword) async {
        if (keyword.isNotEmpty) {
          countries = await API.fetchCountryList(
              keyword,
              selectedLocation == _locationArray[0]
                  ? 'regions'
                  : selectedLocation == _locationArray[1] ? 'cities' : null);
        } else {
          countries = await API.fetchCountryList(
              'india',
              selectedLocation == _locationArray[0]
                  ? 'regions'
                  : selectedLocation == _locationArray[1] ? 'cities' : null);
        }
        setState(() {});
      },*/
    );
  }

  Future<Null> dateFromPicker(BuildContext context) async {
    DatePicker.showDatePicker(
      context,
      pickerTheme: DateTimePickerTheme(
        showTitle: true,
        confirm: Text('Done', style: TextStyle()),
        cancel: Text('Cancel', style: TextStyle()),
      ),
      minDateTime:  DateTime.now(),
      pickerMode: DateTimePickerMode.date,
      maxDateTime: DateTime((new DateTime.now().year + 5)),
      initialDateTime: fromDate == null ?  DateTime.now() : fromDate,
      dateFormat: 'MMM-dd-yyyy',
      locale: DateTimePickerLocale.en_us,
      onClose: () => print("----- onClose -----"),
      onCancel: () => print('onCancel'),
      onChange: (dateTime, List<int> index) {
        print("onchange" + dateTime.toString());
      },
      onConfirm: (dateTime, List<int> index) {
        print("onconform::: " + dateTime.toString());
        setState(() {
          FocusScope.of(context).requestFocus(new FocusNode());
        });
        if (dateTime != null) {
          fromDate = dateTime;
          // String date =  DateFormat("MM-dd-yyyy").format(picked);
          String date = Util.getDate(dateTime);
          String date2 =  DateFormat("yyyy-MM-dd").format(dateTime);
          print(date);
          setState(() {
            ageFromController.text = date;
            dateFrom = dateTime.millisecondsSinceEpoch;
            ageToController.text = "";
          });
        }
      },
    );
  }

  Future<Null> dateToPicker(BuildContext context) async {
    DateTime dateTime2;
    DatePicker.showDatePicker(
      context,
      pickerTheme: DateTimePickerTheme(
        showTitle: true,
        confirm: Text('Done', style: TextStyle()),
        cancel: Text('Cancel', style: TextStyle()),
      ),
      minDateTime:  DateTime.now(),
      pickerMode: DateTimePickerMode.date,
      maxDateTime: DateTime((new DateTime.now().year + 5)),
      initialDateTime: ageToController == null || ageToController.text == ""
          ? fromDate
          : toDate != null
              ? toDate
              : fromDate,
      dateFormat: 'MMM-dd-yyyy',
      locale: DateTimePickerLocale.en_us,
      onClose: () {
        setState(() {
          FocusScope.of(context).requestFocus(new FocusNode());
        });
        if (dateTime2 != null) {
          // String date =  DateFormat("MM-dd-yyyy").format(picked);
          String date = Util.getDate(dateTime2);

          print("date::: $date");
          var differenceStartDate = dateTime2.difference(fromDate);

          if (differenceStartDate.inDays >= 0) {
            toDate = dateTime2;
            //expiryDateController.text = "";
            setState(() {
              dateTo = (dateTime2.millisecondsSinceEpoch);
              ageToController.text = date;
              expiryDateController;
            });
          } else {
            ToastWrap.showToast(
                MessageConstant.ENTER_CORRECT_DATE_RANGE_VAL, context);
          }
        }
      },
      onCancel: () => print('onCancel'),
      onChange: (dateTime, List<int> index) {
        print("onchange" + dateTime.toString());
      },
      onConfirm: (dateTime, List<int> index) {
        print("onconform::: " + dateTime.toString());
        dateTime2 = dateTime;
      },
    );
  }

  Future<String> timeFromPicker(
      BuildContext context, int innerIndex, int outerIndex) async {
    String date = '';
    await DatePicker.showDatePicker(
      context,
      pickerTheme: DateTimePickerTheme(
        showTitle: true,
        confirm: Text('Done', style: TextStyle()),
        cancel: Text('Cancel', style: TextStyle()),
      ),
      //minDateTime:  DateTime.now(),
      pickerMode: DateTimePickerMode.time,
      //maxDateTime: DateTime((new DateTime.now().year + 5)),
      initialDateTime: fromTime == null ?  DateTime.now() : fromTime,
      //dateFormat: 'hh:mm a',
      locale: DateTimePickerLocale.en_us,
      onClose: () {
        print("----- onClose time from-----");
        return date;
      },
      onCancel: () {
        print('onCancel time from');
        return date;
      },
      onChange: (dateTime, List<int> index) {
        print("onchange time from" + dateTime.toString());
        return date;
      },
      onConfirm: (dateTime, List<int> index) {
        print("onconform time from:::: " + dateTime.toString());
        setState(() {
          FocusScope.of(context).requestFocus(new FocusNode());
        });
        if (dateTime != null) {
          fromTime = dateTime;
          // String date =  DateFormat("MM-dd-yyyy").format(picked);
          date = Util.formatTimeFromDateTime(dateTime);
          print("Time time from::: $date");
          setState(() {
            //timeFromController.text = date;
            listData[outerIndex]
                .dayScheduleData[innerIndex]
                .startTimeController
                .text = date;

            timeFrom = dateTime.millisecondsSinceEpoch;
            listData[outerIndex].dayScheduleData[innerIndex].timeFrom =
                timeFrom;
            listData[outerIndex]
                .dayScheduleData[innerIndex]
                .endTimeController
                .text = "";
          });
          return date;
        }
        return date;
      },
    );
    print("Time time from 2222222::: $date");
    return date;
  }

  Future<String> timeToPicker(
      BuildContext context, int innerIndex, int outerIndex) async {
    DateTime dateTime2;
    String date;
    await DatePicker.showDatePicker(
      context,
      pickerTheme: DateTimePickerTheme(
        showTitle: true,
        confirm: Text('Done', style: TextStyle()),
        cancel: Text('Cancel', style: TextStyle()),
      ),
      //minDateTime:  DateTime.now(),
      pickerMode: DateTimePickerMode.time,
      //maxDateTime: DateTime((new DateTime.now().year + 5)),
      initialDateTime: timeToController == null || timeToController.text == ""
          ? fromTime
          : toTime != null
              ? toTime
              : fromTime,
      //dateFormat: 'hh:mm a',
      locale: DateTimePickerLocale.en_us,
      onClose: () {
        setState(() {
          FocusScope.of(context).requestFocus(new FocusNode());
        });
        if (dateTime2 != null) {
          // String date =  DateFormat("MM-dd-yyyy").format(picked);
          //String date = Util.getDate(dateTime2);
          date = Util.formatTimeFromDateTime(dateTime2);

          print("date time::: $date");
          timeToController.text = date;
          //listData[outerIndex].startTimeController[index].text = date;
          var differenceStartDate = dateTime2.difference(fromTime);

          if (differenceStartDate.inMinutes > 0) {
            toTime = dateTime2;
            //expiryDateController.text = "";
            setState(() {
              timeTo = (dateTime2.millisecondsSinceEpoch);
              //timeToController.text = date;
              listData[outerIndex]
                  .dayScheduleData[innerIndex]
                  .endTimeController
                  .text = date;

              listData[outerIndex].dayScheduleData[innerIndex].timeTo = timeTo;
              expiryDateController;
            });
          } else {
            ToastWrap.showToast(
                MessageConstant.ENTER_CORRECT_TIME_RANGE_VAL, context);
          }
        }
      },
      onCancel: () => print('onCancel to time'),
      onChange: (dateTime, List<int> index) {
        print("onchange to time" + dateTime.toString());
      },
      onConfirm: (dateTime, List<int> index) {
        print("onconform to time" + dateTime.toString());
        dateTime2 = dateTime;
      },
    );
    return date;
  }

  Widget callToAction() {
    return Container(
      //  decoration: rectangleDecoration(),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          // Padding(
          //   padding: EdgeInsets.all(UIHelper.screenPadding),
          //   child: colorIcon(ImagePath.ICON_CALL_TO_ACTION, 21.46, 27),
          // ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                  right: UIHelper.screenPadding,
                  //bottom: UIHelper.screenPadding,
                  top: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  UIHelper.verticalSpaceExtraSmall,
                  Text(
                    'Call to action',
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                      fontFamily: Constant.latoRegular,
                      color: ColorValues.labelColor,
                    ),
                  ),

                  UIHelper.verticalSpaceSmall,

                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      InkWell(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Image.asset(
                                selectedAction == "Link URL"
                                    ? "assets/future_goals/future_check.png"
                                    : "assets/future_goals/future_Uncheck.png",
                                height: 20,
                                width: 20),
                            Padding(
                              padding: const EdgeInsets.only(left: 10.0),
                              child: Text(
                                "Link URL",
                                style: TextStyle(
                                  fontFamily: Constant.latoRegular,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                  color:
                                  ColorValues.HEADING_COLOR_EDUCATION_1,
                                ),
                              ),
                            )
                          ],
                        ),
                        onTap: () {
                          setState(() {
                            selectedAction = "Link URL";

                            _showEmptyNumberError = false;
                            _showSelectGroupError = false;
                            _showCreateGroupError = false;
                            _showEmptyCallToError = false;
                            //_showLinkUrlError = false;

                          });
                        },
                      ),
                      UIHelper.verticalSpaceSmall,

                      Padding(
                        padding: const EdgeInsets.only(left: 25),
                        child: selectedAction == actionList.elementAt(0)
                            ? actionOfferButtonWidget()
                            : Container(),
                      )
                    ],
                  ),

                  _showLinkUrlError
                      ? Padding(
                    padding: const EdgeInsets.only(top: 0,bottom: 20),
                    child: Text(
                      "Please insert link",
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: ColorValues.ERROR_COLOR,
                      ),
                    ),
                  )
                      : const SizedBox.shrink(),

                  //  UIHelper.verticalSpaceSmall,

                  Container(
                    child: Column(
                      children: [
                        InkWell(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Image.asset(
                                  selectedAction == "Join Group"
                                      ? "assets/future_goals/future_check.png"
                                      : "assets/future_goals/future_Uncheck.png",
                                  height: 20,
                                  width: 20),
                              Padding(
                                padding: const EdgeInsets.only(left: 10.0),
                                child: Text(
                                  "Join group",
                                  style: TextStyle(
                                    fontFamily: Constant.latoRegular,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    color:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                  ),
                                ),
                              )
                            ],
                          ),
                          onTap: () {
                            setState(() {
                              selectedAction = "Join Group";
                              _showEmptyNumberError = false;
                              // _showSelectGroupError = false;
                              _showCreateGroupError = false;
                              _showEmptyCallToError = false;
                              _showLinkUrlError = false;
                            });
                          },
                        ),
                        Padding(
                            padding: const EdgeInsets.only(left: 25),
                            child: Column(
                              children: [
                                selectedAction == actionList.elementAt(1)
                                    ? interactWidget()
                                    : Container()
                              ],
                            ))
                      ],
                    ),
                  ),
                  _showCreateGroupError
                      ? Padding(
                    padding: const EdgeInsets.only(top: 0,bottom: 14),
                    child: Text(
                      "Please create a group",
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: ColorValues.ERROR_COLOR,
                      ),
                    ),
                  )
                      : const SizedBox.shrink(),
                  const SizedBox(height: 5,),

                  _showSelectGroupError
                      ? Padding(
                    padding: const EdgeInsets.only(top: 0,bottom: 17),
                    child: Text(
                      "Please select a group",
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: ColorValues.ERROR_COLOR,
                      ),
                    ),
                  )
                      : const SizedBox.shrink(),

                  Container(
                    child: Column(
                      children: [
                        const SizedBox(height: 5,),

                        InkWell(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Image.asset(
                                  selectedAction == "Call Now"
                                      ? "assets/future_goals/future_check.png"
                                      : "assets/future_goals/future_Uncheck.png",
                                  height: 20,
                                  width: 20),
                              Padding(
                                padding: const EdgeInsets.only(left: 10.0),
                                child: Text(
                                  "Call now",
                                  style: TextStyle(
                                    fontFamily: Constant.latoRegular,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    color:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                  ),
                                ),
                              )
                            ],
                          ),
                          onTap: () {
                            _checkAccomplishmentsValidation();
                            setState(() {
                              selectedAction = "Call Now";

                              _showEmptyNumberError = false;
                              _showSelectGroupError = false;
                              _showCreateGroupError = false;
                              // _showEmptyCallToError = false;
                              _showLinkUrlError = false;

                            });
                          },
                        ),
                        Padding(
                            padding: const EdgeInsets.only(left: 25),
                            child: Column(
                              children: [
                                selectedAction == actionList.elementAt(2)
                                    ? callNowWidget()
                                    : Container()
                              ],
                            ))
                      ],
                    ),
                  ),

                  _showEmptyNumberError
                      ? Padding(
                    padding: const EdgeInsets.only(top: 12,bottom: 9),
                    child: Text(
                      "Please enter number",
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: ColorValues.ERROR_COLOR,
                      ),
                    ),
                  )
                      : const SizedBox.shrink(),
                  UIHelper.verticalSpaceSmall,

                  Container(
                    child: Column(
                      children: [
                        InkWell(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Image.asset(
                                  selectedAction == "Inquire Now"
                                      ? "assets/future_goals/future_check.png"
                                      : "assets/future_goals/future_Uncheck.png",
                                  height: 20,
                                  width: 20),
                              Padding(
                                padding: const EdgeInsets.only(left: 10.0),
                                child: Text(
                                  "Inquire now",
                                  style: TextStyle(
                                    fontFamily: Constant.latoRegular,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    color:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                  ),
                                ),
                              )
                            ],
                          ),
                          onTap: () {
                            _checkAccomplishmentsValidation();
                            setState(() {
                              _showEmptyNumberError = false;
                              _showSelectGroupError = false;
                              _showCreateGroupError = false;
                              _showEmptyCallToError = false;
                              _showLinkUrlError = false;
                              selectedAction = "Inquire Now";
                              // state.didChange(selectedAction);
                            });
                          },
                        ),
                        Padding(
                            padding: const EdgeInsets.only(left: 25),
                            child: Column(
                              children: [
                                selectedAction == actionList.elementAt(3)
                                    ? inquiryNowWidget()
                                    : Container()
                              ],
                            ))
                      ],
                    ),
                  ),
                  UIHelper.verticalSpaceSmall,


                  _showEmptyCallToError
                      ? Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text(
                      MessageConstant.SELECT_TYPE_OF_CALL_TO_ACTION_VAL,
                      maxLines: 3,
                      style: TextStyle(
                        fontSize: 12.0,
                        color: ColorValues.ERROR_COLOR,
                      ),
                    ),
                  )
                      : const SizedBox.shrink(),
                  // UIHelper.verticalSpaceSmall,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _externalLinkItem(int index) {
    final item = linkUrlListData[index];

    print('linkUrlListData item details - ${item.descController}, url ${item.urlController} , title ,${item.labelController}');

    return ListExternalLinkItem(
      onRemoveTap: () => _showRemoveDialog(index, AssetsType.externalLink),
      onEditTap: () async {
        final result = await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) =>
                ExternalLinkView(
                  title: item.labelController.text ?? "",
                  url: item.urlController.text ?? "",
                  desc: item.descController.text ?? "",
                  action: ExternalLinkAction.edit,
                    heading: "Add external link",
                    isFrom: "Opportunity"
                ),
          ),
        );
        if (result != null) {
          print("edit external link result ${result}");


          LinkUrlModel obj = LinkUrlModel(
            labelController:
            TextEditingController(text: result.title),
            urlController:
            TextEditingController(text: result.url),
            descController:
            TextEditingController(text: result.desc),
          );


          linkUrlListData[index] = obj;
          setState(() {
            linkUrlListData;
          });
        }
      },

      title: item.labelController.text ?? "",
      url: item.urlController.text ?? "",
      desc:  "",
      //item.descController.text ??
    );
  }

  Widget externalLinkWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BaseText(
          text: "External links",
          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
          fontFamily: AppConstants.stringConstant.latoRegular,
          fontWeight: FontWeight.w600,
          fontSize: 18,
        ),
        const SizedBox(height: 15),
        linkUrlListData.isNotEmpty
            ? Container(
          decoration: BoxDecoration(
            color: AppConstants.colorStyle.tabBg,
            border: Border.all(
              color: AppConstants.colorStyle.borderGenerateScript,
            ),
            borderRadius: const BorderRadius.all(
              Radius.circular(7),
            ),
          ),
          margin: const EdgeInsets.only(bottom: 14),
          child: Stack(
            children: [
              ListView.separated(
                itemBuilder: (_, index) => _externalLinkItem(index),
                separatorBuilder: (_, index) =>
                    Divider(
                      height: 24,
                      color: const Color(0xffE5EBF0),
                      thickness: 1,
                    ),
                itemCount: linkUrlListData.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: InkWell(
                  onTap: () async {
                    final result = await Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) =>
                            ExternalLinkView(
                              action: ExternalLinkAction.add,
                                heading: "Add external link",
                                isFrom: "Opportunity"
                            ),
                      ),
                    );
                    if (result != null) {
                      print(jsonEncode(result));

                      LinkUrlModel obj = LinkUrlModel(
                        labelController:
                        TextEditingController(text: result.title),
                        urlController:
                        TextEditingController(text: result.url),
                        descController:
                        TextEditingController(text: result.desc),
                      );

                      print("link url after added or updated  ${result.url}");

                      linkUrlListData.add(obj);

                      setState(() {});
                    }
                  },
                  child: Container(
                    transform: Matrix4.translationValues(0.0, 14.0, 0.0),
                    child: Center(
                      child: Image.asset(
                        "assets/generateScript/plus_icon.png",
                        height: 28,
                        width: 28,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        )
            : SizedBox(
          width: double.maxFinite,
          height: 110,
          child: InkWell(
            onTap: () async {
              final result = await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) =>
                      ExternalLinkView(
                        action: ExternalLinkAction.add,
                          heading: "Add external link",
                          isFrom: "Opportunity"
                      ),
                ),
              );
              if (result != null) {
                print(jsonEncode(result));

                LinkUrlModel obj = LinkUrlModel(
                  labelController:
                  TextEditingController(text: result.title),
                  urlController: TextEditingController(text: result.url),
                  descController:
                  TextEditingController(text: result.desc),
                );

                linkUrlListData.add(obj);
                setState(() {});
              }
            },
            child: Stack(
              alignment: Alignment.center,
              overflow: Overflow.visible,
              children: [
                Positioned(
                  left: 0,
                  right: 0,
                  top: 0,
                  bottom: 14,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(height: 10),
                        Image.asset(
                          "assets/experience/ic_badges.png",
                          height: 26,
                          width: 25,
                        ),
                        const SizedBox(height: 5),
                        Text(
                          'Add any links you want to include on your profile for this experience.',
                          maxLines: 2,
                          textAlign: TextAlign.center,
                          style: AppConstants
                              .txtStyle.heading14400LatoItalicLightPurple,
                        ),
                      ],
                    ),
                    decoration: BoxDecoration(
                      color: AppConstants.colorStyle.tabBg,
                      border: Border.all(
                        color:
                        AppConstants.colorStyle.borderGenerateScript,
                      ),
                      borderRadius: const BorderRadius.all(
                        Radius.circular(7),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  child: Image.asset(
                    "assets/generateScript/plus_icon.png",
                    height: 28,
                    width: 28,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  textFormFieldDecorationWithIcon(
      String name, String icon, double height, double width) {
    return  InputDecoration(
        labelText: name,
        hintStyle: AppTextStyle.getDynamicFontStyle(
            Palette.secondaryTextColor, 14, FontType.Regular),
        labelStyle: AppTextStyle.getDynamicFontStyle(
            Palette.secondaryTextColor, 16, FontType.Regular),
        enabledBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
        ),
        focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
        ),
        errorStyle: TextStyle(
            fontFamily: AppTextStyle.getFont(FontType.Regular),
            color: Palette.redColor),
        border: UnderlineInputBorder(
          borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
        ),
        suffixIcon: InkWell(
            onTap: () {
              print('suffixIcon ontap 1111');
              FocusScope.of(context).requestFocus(FocusNode());
            //  customDropdownButton.handleTap();
              setState(() {});
            },
            child: Padding(
                padding: EdgeInsets.only(left: 15, right: 15, top: 15),
                child: Image.asset(
                  icon,
                  height: height,
                  width: width,
                ))));
  }

  Widget displaySelectedActionWidgets() {
    return selectedAction == actionList.elementAt(0)
        ? actionOfferButtonWidget()
        : selectedAction == actionList.elementAt(1)
            ? interactWidget()
            : selectedAction == actionList.elementAt(2)
                ? callNowWidget()
                : selectedAction == actionList.elementAt(3)
                    ? inquiryNowWidget()
                    : Container();
  }

  /*
  actionOfferButtonWidgetold() {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 12, 12, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text(
            'Choose the appropriate action button for your offer.',
            style: TextStyle(
                fontWeight: FontWeight.w400,
                fontSize: 12,
                fontFamily: Constant.latoRegular,
                color: ColorValues.labelColor),
          ),
          UIHelper.verticalSpaceSmall,
          InkWell(
            child: Row(
              children: <Widget>[
                //  customRadioButton(learnMore),
                Image.asset(
                    learnMore
                        ? "assets/future_goals/future_check.png"
                        : "assets/future_goals/future_Uncheck.png",
                    height: 15,
                    width: 15),
                UIHelper.horizontalGapBetweenBox,
                checkBoxLabelText('Learn More'),
              ],
            ),
            onTap: () {
              if (selectedLink == null &&
                  selectedOfferLink == null &&
                  selectedApplyNowLink == null) {
                setState(() {
                  learnMore = true;
                  getOffer = false;
                  applyNow = false;
                });
              } else {
                showSelectedLinkDialog(0);
              }
            },
          ),
          learnMore
              ? InkWell(
            onTap: () async {
              final String result = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        CreateLinkUrl(
                            selectedLink: selectedLink,
                            otherLinks: [
                              null,
                              selectedOfferLink,
                              selectedApplyNowLink
                            ])),
              );
              if (result != null) {
                setState(() {
                  isActionSelected = true;
                  selectedLink = result;
                  selectedOfferLink = null;
                  selectedApplyNowLink = null;
                });
              }
            },
            child: Padding(
              padding: EdgeInsets.only(left: 28),
              child: selectedLink == null
                  ? Text(
                'Add link',
                style: AppTextStyle.getDynamicFontStyle(
                    Palette.accentColor, 12, FontType.Regular),
              )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          selectedLink,
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.primaryTextColor,
                              14,
                              FontType.Bold),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.4,
                            width: 17,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            selectedLink = null;
                          });
                        },
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
              : Container(),
          UIHelper.verticalSpaceSmall,
          InkWell(
            child: Row(
              children: <Widget>[
                Image.asset(
                    getOffer
                        ? "assets/future_goals/future_check.png"
                        : "assets/future_goals/future_Uncheck.png",
                    height: 15,
                    width: 15),
                UIHelper.horizontalGapBetweenBox,
                checkBoxLabelText('Get Offer'),
              ],
            ),
            onTap: () {
              if (selectedLink == null &&
                  selectedOfferLink == null &&
                  selectedApplyNowLink == null) {
                setState(() {
                  isActionSelected = true;
                  getOffer = true;
                  learnMore = false;
                  applyNow = false;
                });
              } else {
                showSelectedLinkDialog(1);
              }
            },
          ),
          getOffer
              ? InkWell(
            onTap: () async {
              final String result = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        CreateLinkUrl(
                            selectedLink: selectedOfferLink,
                            otherLinks: [
                              selectedLink,
                              null,
                              selectedApplyNowLink
                            ])),
              );
              if (result != null) {
                setState(() {
                  selectedOfferLink = result;
                  selectedLink = null;
                  selectedApplyNowLink = null;
                });
              }
            },
            child: Padding(
              padding: EdgeInsets.only(left: 28),
              child: selectedOfferLink == null
                  ? Text(
                'Add link',
                style: AppTextStyle.getDynamicFontStyle(
                    Palette.accentColor, 12, FontType.Regular),
              )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          selectedOfferLink,
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.primaryTextColor,
                              14,
                              FontType.Bold),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.4,
                            width: 17,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            selectedOfferLink = null;
                          });
                        },
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
              : Container(),
          UIHelper.verticalSpaceSmall,
          InkWell(
            child: Row(
              children: <Widget>[
                // customRadioButton(applyNow),

                Image.asset(
                    applyNow
                        ? "assets/future_goals/future_check.png"
                        : "assets/future_goals/future_Uncheck.png",
                    height: 15,
                    width: 15),
                UIHelper.horizontalGapBetweenBox,
                checkBoxLabelText('Apply Now'),
              ],
            ),
            onTap: () {
              if (selectedLink == null &&
                  selectedOfferLink == null &&
                  selectedApplyNowLink == null) {
                setState(() {
                  isActionSelected = true;
                  applyNow = true;
                  learnMore = false;
                  getOffer = false;
                });
              } else {
                showSelectedLinkDialog(2);
              }
            },
          ),
          applyNow
              ? InkWell(
            onTap: () async {
              final String result = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        CreateLinkUrl(
                            selectedLink: selectedApplyNowLink,
                            otherLinks: [
                              selectedLink,
                              selectedOfferLink,
                              null
                            ])),
              );
              if (result != null) {
                setState(() {
                  selectedApplyNowLink = result;
                  selectedLink = null;
                  selectedOfferLink = null;
                });
              }
            },
            child: Padding(
              padding: EdgeInsets.only(left: 28),
              child: selectedApplyNowLink == null
                  ? Text(
                'Add link',
                style: AppTextStyle.getDynamicFontStyle(
                    Palette.accentColor, 12, FontType.Regular),
              )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          selectedApplyNowLink,
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.primaryTextColor,
                              14,
                              FontType.Bold),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.4,
                            width: 17,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            selectedApplyNowLink = null;
                          });
                        },
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
              : Container(),
        ],
      ),
    );
  }

   */

  actionOfferButtonWidgetold() {
    return Container(
      padding: EdgeInsets.fromLTRB(5, 12, 9, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: Text(
              'Choose the appropriate action button for your offer.',
              style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 12,
                  fontFamily: Constant.latoRegular,
                  color: ColorValues.labelColor),
            ),
          ),

          const SizedBox(height: 5,),
          CustomDropdownButtonFormFieldNew(
            icon: Visibility(
                visible: true,
                child: Image.asset(
                  'assets/recommendation/ic_arrow_down.png',
                  height: 24,
                  width: 24,
                )),

            items: _linkUrlArray.map((String value) {
              return CustomDropdownMenuItem<String>(
                value: value,
                child: Text(
                  value,
                  style: textFormFieldValueStyle(),
                ),
              );
            }).toList(),

            onChanged: (newValue) {

              selectedUrlOption = newValue;

              print("selectedUrlOption - ${selectedUrlOption}");

              print("selectedLink - ${selectedLink}");
              print("selectedOfferLink - ${selectedOfferLink}");
              print("selectedApplyNowLink - ${selectedApplyNowLink}");

              //"Get offer"
              //"Apply now"
              if ((selectedLink == null || selectedLink == '') &&
                  (selectedOfferLink == null || selectedOfferLink == '') &&
                  (selectedApplyNowLink == null || selectedApplyNowLink == '')) {

                if (selectedUrlOption == "Learn more"){

                  print("inside of learn more selected");
                  learnMore = true;
                  getOffer = false;
                  applyNow = false;
                  linkUrlController.text = selectedLink;

                  print("linkUrlController.text - ${linkUrlController.text}");

                }else if (selectedUrlOption == "Get offer"){
                  print("inside of get offer selected");

                  isActionSelected = true;
                  getOffer = true;
                  learnMore = false;
                  applyNow = false;
                  linkUrlController.text = selectedOfferLink;
                  print("linkUrlController.text - ${linkUrlController.text}");

                } else if (selectedUrlOption == "Apply now"){
                  print("inside of get apply now selected");

                  isActionSelected = true;
                  applyNow = true;
                  learnMore = false;
                  getOffer = false;
                  linkUrlController.text = selectedApplyNowLink;
                  print("linkUrlController.text - ${linkUrlController.text}");
                }

                setState(() {

                });
              } else {
                showSelectedLinkDialog(0,newValue);
              }

              // setState(() {
              //  // selectedUrlOption;
              // });
            },
            // (selectedLink == null || selectedLink == '') &&
            //     (selectedOfferLink == null || selectedOfferLink == '') &&
            //     (selectedApplyNowLink == null || selectedApplyNowLink == '') ? selectedUrlOption : ""


            value: selectedUrlOption ,
            //labelText: 'Focus area 1',
            hintText:'Learn more',


            /*
                    decoration: InputDecoration(
                      isDense: true,

                      focusColor: AppConstants.colorStyle.lightBlue,
                      errorStyle: AppConstants.txtStyle.labelStyleTextForm,
                      counterStyle: AppConstants.txtStyle.counterStyleTextForm,
                      fillColor: Colors.transparent,
                      labelText: 'Focus area 1',
                      labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                      // hintStyle:  TxtStyle.academyType.copyWith(color: ColorStyle.midBlueGray),
                      contentPadding: EdgeInsets.fromLTRB(0.0, 7.0, 0.0, 0),
                      border: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg,
                              width: 1.0)),
                      focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.lightBlue,
                              width: 1.0)),
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg,
                              width: 1.0)),
                      disabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg,
                              width: 1.0)),
                    ),
                     */
          ),

          Form(
            key: linkFormKey,
            child: Container(
              child:  Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(
                                right: 0,
                                top: 5,
                                bottom: 0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[

/*
                                CustomFormField(
                                  controller: linkUrlController,
                                  focusNode: linkTitleFocus,
                                  textInputType: TextInputType.text,
                                  onType: (val) {},
                                  label: 'URL Of Page',
                                  hint: 'URL Of Page',
                                  alignLabelWithHint: true,
                                  onSaved: (term){

                                    linkTitleFocus.unfocus();

                                    print("linkUrlController.text onFieldSubmitted - ${term}");
                                    print("selectedUrlOption - ${selectedUrlOption}");


                                    if (selectedUrlOption == "Learn more"){
                                      isActionSelected = true;
                                      selectedLink = term;
                                      selectedOfferLink = null;
                                      selectedApplyNowLink = null;

                                    }else if (selectedUrlOption == "Get offer"){
                                      selectedOfferLink = term;
                                      selectedLink = null;
                                      selectedApplyNowLink = null;

                                    } else if (selectedUrlOption == "Apply now"){
                                      selectedApplyNowLink = term;
                                      selectedLink = null;
                                      selectedOfferLink = null;
                                    }

                                    print("selectedLink - ${selectedLink}");
                                    print("selectedOfferLink - ${selectedOfferLink}");
                                    print("selectedApplyNowLink - ${selectedApplyNowLink}");


                                    setState(() {
                                      isActionSelected ;
                                      selectedLink;
                                      selectedOfferLink ;
                                      selectedApplyNowLink;
                                    });

                                    // gotoPreviousPage();
                                  },
                                  validation: (value) {
                                    return ValidationChecks.validateWebUrl(value);
                                  },
                                ),


 */

                                TextFormField(
                                  focusNode: linkTitleFocus,
                                  controller: linkUrlController,
                                  decoration: textFormFieldDecorationWithLabel('Add link',
                                      helperText: ''),
                                  style: textFormFieldValueStyle(),
                                  keyboardType: TextInputType.text,
                                  textCapitalization: TextCapitalization.none,
                                  onFieldSubmitted: (term) {
                                    linkTitleFocus.unfocus();

                                    print("linkUrlController.text onFieldSubmitted - ${term}");
                                    print("selectedUrlOption - ${selectedUrlOption}");


                                    if (selectedUrlOption == "Learn more"){
                                      isActionSelected = true;
                                      selectedLink = term;
                                      selectedOfferLink = null;
                                      selectedApplyNowLink = null;

                                    }else if (selectedUrlOption == "Get offer"){
                                      selectedOfferLink = term;
                                      selectedLink = null;
                                      selectedApplyNowLink = null;

                                    } else if (selectedUrlOption == "Apply now"){
                                      selectedApplyNowLink = term;
                                      selectedLink = null;
                                      selectedOfferLink = null;
                                    }


                                    if  (selectedLink != null) {
                                      _showLinkUrlError = false;
                                    }else if (selectedOfferLink != null){
                                      _showLinkUrlError = false;

                                    }else if (selectedApplyNowLink != null){
                                      _showLinkUrlError = false;
                                    }


                                    print("selectedLink - ${selectedLink}");
                                    print("selectedOfferLink - ${selectedOfferLink}");
                                    print("selectedApplyNowLink - ${selectedApplyNowLink}");


                                    setState(() {
                                      isActionSelected ;
                                      selectedLink;
                                      selectedOfferLink ;
                                      selectedApplyNowLink;
                                    });

                                    // gotoPreviousPage();
                                  },
                                  validator: (value) {
                                    return ValidationChecks.validateWebUrl(value);
                                  },
                                ),


                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  //  UIHelper.verticalGapBetweenBox,
                ],
              ),
            ),
          ),


          //
          // FormField<String>(
          //   builder: (FormFieldState<String> state) {
          //     return InputDecorator(
          //       decoration: InputDecoration(
          //         labelText: 'select url',
          //
          //         errorStyle: Util.errorTextStyle,
          //         alignLabelWithHint: true,
          //         hintStyle: AppTextStyle.getDynamicFontStyle(
          //             Palette.secondaryTextColor, 14, FontType.Regular),
          //         labelStyle: AppTextStyle.getDynamicFontStyle(
          //             Palette.secondaryTextColor, 16, FontType.Regular),
          //         enabledBorder: UnderlineInputBorder(
          //           borderSide: BorderSide(
          //               color: Palette.dividerColor, width: 1.0),
          //         ),
          //         focusedBorder: UnderlineInputBorder(
          //           borderSide: BorderSide(
          //               color: Palette.dividerColor, width: 1.0),
          //         ),
          //         border: UnderlineInputBorder(
          //           borderSide: BorderSide(
          //               color: Palette.dividerColor, width: 1.0),
          //         ),
          //       ),
          //       child: DropdownButtonHideUnderline(
          //         child: DropdownButton<String>(
          //           icon: SizedBox(
          //               width: 18.0,
          //               height: 18.0,
          //               child: Padding(
          //                 padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
          //                 child:Image.asset(
          //                   'assets/new_onboarding/arrow_down.png',
          //                 ),
          //
          //               )),
          //           value: selectedUrlOption,
          //           isDense: true,
          //           onChanged: (String newValue) {
          //             _checkAccomplishmentsValidation();
          //
          //             setState(() {
          //               selectedUrlOption = newValue;
          //               state.didChange(newValue);
          //             });
          //           },
          //
          //           items: _linkUrlArray.map((String value) {
          //             return DropdownMenuItem<String>(
          //               value: value,
          //               child: Text(
          //                 value,
          //                 style: textFormFieldValueStyle(),
          //               ),
          //             );
          //           }).toList(),
          //         ),
          //       ),
          //     );
          //   },
          // ),



          /*
          //learn more
          InkWell(
            child: Row(
              children: <Widget>[
                //  customRadioButton(learnMore),
                Image.asset(
                    learnMore
                        ? "assets/future_goals/future_check.png"
                        : "assets/future_goals/future_Uncheck.png",
                    height: 15,
                    width: 15),
                UIHelper.horizontalGapBetweenBox,
                checkBoxLabelText('Learn More'),
              ],
            ),
            onTap: () {
              if (selectedLink == null &&
                  selectedOfferLink == null &&
                  selectedApplyNowLink == null) {
                setState(() {
                  learnMore = true;
                  getOffer = false;
                  applyNow = false;
                });
              } else {
                showSelectedLinkDialog(0);
              }
            },
          ),

          //shubham

          learnMore
              ? InkWell(
            onTap: () async {
              final String result = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        CreateLinkUrl(
                            selectedLink: selectedLink,
                            otherLinks: [
                              null,
                              selectedOfferLink,
                              selectedApplyNowLink
                            ])),
              );
              if (result != null) {
                setState(() {
                  isActionSelected = true;
                  selectedLink = result;
                  selectedOfferLink = null;
                  selectedApplyNowLink = null;
                });
              }
            },
            child: Padding(
              padding: EdgeInsets.only(left: 28),
              child: selectedLink == null
                  ? Text(
                'Add link',
                style: AppTextStyle.getDynamicFontStyle(
                    Palette.accentColor, 12, FontType.Regular),
              )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          selectedLink,
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.primaryTextColor,
                              14,
                              FontType.Bold),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.4,
                            width: 17,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            selectedLink = null;
                          });
                        },
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
              : Container(),
          UIHelper.verticalSpaceSmall,

        //get offer -
          InkWell(
            child: Row(
              children: <Widget>[
                Image.asset(
                    getOffer
                        ? "assets/future_goals/future_check.png"
                        : "assets/future_goals/future_Uncheck.png",
                    height: 15,
                    width: 15),
                UIHelper.horizontalGapBetweenBox,
                checkBoxLabelText('Get Offer'),
              ],
            ),
            onTap: () {
              if (selectedLink == null &&
                  selectedOfferLink == null &&
                  selectedApplyNowLink == null) {
                setState(() {
                  isActionSelected = true;
                  getOffer = true;
                  learnMore = false;
                  applyNow = false;
                });
              } else {
                showSelectedLinkDialog(1);
              }
            },
          ),
          getOffer
              ? InkWell(
            onTap: () async {
              final String result = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        CreateLinkUrl(
                            selectedLink: selectedOfferLink,
                            otherLinks: [
                              selectedLink,
                              null,
                              selectedApplyNowLink
                            ])),
              );
              if (result != null) {
                setState(() {
                  selectedOfferLink = result;
                  selectedLink = null;
                  selectedApplyNowLink = null;
                });
              }
            },
            child: Padding(
              padding: EdgeInsets.only(left: 28),
              child: selectedOfferLink == null
                  ? Text(
                'Add link',
                style: AppTextStyle.getDynamicFontStyle(
                    Palette.accentColor, 12, FontType.Regular),
              )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          selectedOfferLink,
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.primaryTextColor,
                              14,
                              FontType.Bold),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.4,
                            width: 17,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            selectedOfferLink = null;
                          });
                        },
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
              : Container(),
          UIHelper.verticalSpaceSmall,

          //apply now
          InkWell(
            child: Row(
              children: <Widget>[
                // customRadioButton(applyNow),

                Image.asset(
                    applyNow
                        ? "assets/future_goals/future_check.png"
                        : "assets/future_goals/future_Uncheck.png",
                    height: 15,
                    width: 15),
                UIHelper.horizontalGapBetweenBox,
                checkBoxLabelText('Apply Now'),
              ],
            ),
            onTap: () {
              if (selectedLink == null &&
                  selectedOfferLink == null &&
                  selectedApplyNowLink == null) {
                setState(() {
                  isActionSelected = true;
                  applyNow = true;
                  learnMore = false;
                  getOffer = false;
                });
              } else {
                showSelectedLinkDialog(2);
              }
            },
          ),
          applyNow
              ? InkWell(
            onTap: () async {
              final String result = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        CreateLinkUrl(
                            selectedLink: selectedApplyNowLink,
                            otherLinks: [
                              selectedLink,
                              selectedOfferLink,
                              null
                            ])),
              );
              if (result != null) {
                setState(() {
                  selectedApplyNowLink = result;
                  selectedLink = null;
                  selectedOfferLink = null;
                });
              }
            },
            child: Padding(
              padding: EdgeInsets.only(left: 28),
              child: selectedApplyNowLink == null
                  ? Text(
                'Add link',
                style: AppTextStyle.getDynamicFontStyle(
                    Palette.accentColor, 12, FontType.Regular),
              )
                  : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          selectedApplyNowLink,
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.primaryTextColor,
                              14,
                              FontType.Bold),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.4,
                            width: 17,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            selectedApplyNowLink = null;
                          });
                        },
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
              : Container(),
          */



        ],
      ),
    );
  }


  actionOfferButtonWidget() {
    return Container(
      padding: EdgeInsets.fromLTRB(5, 0, 0, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Text(
              'Choose the appropriate action button for your offer.',
              style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 12,
                  fontFamily: Constant.latoRegular,
                  color: ColorValues.labelColor),
            ),
          ),
          const SizedBox(height: 16),
          CustomDropdownButtonFormFieldNew(
            icon: Image.asset(
              'assets/recommendation/ic_arrow_down.png',
              height: 24,
              width: 24,
            ),
            items: _linkUrlArray.map((String value) {
              return CustomDropdownMenuItem<String>(
                value: value,
                child: Text(
                  value,
                  style: textFormFieldValueStyle(),
                ),
              );
            }).toList(),

            onChanged: (newValue) {
              selectedUrlOption = newValue;
              //"Get offer"
              //"Apply now"
              if ((selectedLink == null || selectedLink == '') &&
                  (selectedOfferLink == null || selectedOfferLink == '') &&
                  (selectedApplyNowLink == null || selectedApplyNowLink == '')) {

                if (selectedUrlOption == "Learn more"){

                  print("inside of learn more selected");
                  learnMore = true;
                  getOffer = false;
                  applyNow = false;
                  linkUrlController.text = selectedLink;

                  print("linkUrlController.text - ${linkUrlController.text}");

                }else if (selectedUrlOption == "Get offer"){
                  print("inside of get offer selected");

                  isActionSelected = true;
                  getOffer = true;
                  learnMore = false;
                  applyNow = false;
                  linkUrlController.text = selectedOfferLink;
                  print("linkUrlController.text - ${linkUrlController.text}");

                } else if (selectedUrlOption == "Apply now"){
                  print("inside of get apply now selected");

                  isActionSelected = true;
                  applyNow = true;
                  learnMore = false;
                  getOffer = false;
                  linkUrlController.text = selectedApplyNowLink;
                  print("linkUrlController.text - ${linkUrlController.text}");
                }

                setState(() {

                });
              } else {
                showSelectedLinkDialog(0,newValue);
              }

              // setState(() {
              //  // selectedUrlOption;
              // });
            },
            // (selectedLink == null || selectedLink == '') &&
            //     (selectedOfferLink == null || selectedOfferLink == '') &&
            //     (selectedApplyNowLink == null || selectedApplyNowLink == '') ? selectedUrlOption : ""


            value: selectedUrlOption ,
            //labelText: 'Focus area 1',
            hintText:'Learn more',
          ),
          const SizedBox(height: 20),
          Form(
            key: linkFormKey,
            child: TextFormField(
              focusNode: linkTitleFocus,
              controller: linkUrlController,
              decoration: textFormFieldDecorationWithLabel('URL of page',
                  helperText: ''),
              style: textFormFieldValueStyle(),
              keyboardType: TextInputType.text,
              textCapitalization: TextCapitalization.none,
              onFieldSubmitted: (term) {
                linkTitleFocus.unfocus();
                if (selectedUrlOption == "Learn more"){
                  isActionSelected = true;
                  selectedLink = term;
                  selectedOfferLink = null;
                  selectedApplyNowLink = null;

                }else if (selectedUrlOption == "Get offer"){
                  selectedOfferLink = term;
                  selectedLink = null;
                  selectedApplyNowLink = null;

                } else if (selectedUrlOption == "Apply now"){
                  selectedApplyNowLink = term;
                  selectedLink = null;
                  selectedOfferLink = null;
                }


                if  (selectedLink != null) {
                  _showLinkUrlError = false;
                }else if (selectedOfferLink != null){
                  _showLinkUrlError = false;

                }else if (selectedApplyNowLink != null){
                  _showLinkUrlError = false;
                }



                print("selectedLink - ${selectedLink}");
                print("selectedOfferLink - ${selectedOfferLink}");
                print("selectedApplyNowLink - ${selectedApplyNowLink}");

                setState(() {
                  _showLinkUrlError;
                  isActionSelected ;
                  selectedLink;
                  selectedOfferLink ;
                  selectedApplyNowLink;
                });

                // gotoPreviousPage();
              },
              validator: (value) {
                return ValidationChecks.validateWebUrl(value);
              },
            ),
          ),
        ],
      ),
    );
  }


  callNowWidget() {
    return InkWell(
      onTap: () async {
        final String result = await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  AddPhoneNumberView(number: selectedPhoneNumber)),
        );
        if (result != null) {
          setState(() {
            isActionSelected = true;
            selectedPhoneNumber = result;
          });
        }
      },
      child: Padding(
        padding: EdgeInsets.only(top: 10),
        child: selectedPhoneNumber == null
            ? Row(
          children: [
            Padding(
                padding: EdgeInsets.only(left: 10),
                child: Text(
                  'Add phone number',
                  style: AppTextStyle.getDynamicFontStyle(
                      Palette.accentColor, 12, FontType.Regular),
                )),
            Spacer()
          ],
        )
            : Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    selectedPhoneNumber,
                    style: TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        fontFamily: Constant.latoRegular,
                        color: ColorValues.HEADING_COLOR_EDUCATION_1),
                  ),
                ),
                InkWell(
                  child: Container(
                    padding: EdgeInsets.all(0),
                      child: Image.asset(
                        // ImagePath.ICON_CLEAR,
                        "assets/experience/ic_remove.png",
                        height: 15,
                        width: 15,
                      )
                  ),
                  onTap: () {
                    setState(() {
                      selectedPhoneNumber = null;
                    });
                  },
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  inquiryNowWidget() {
    return Container();
  }

  performAction(index) {
    if (index == 0) {
      setState(() {
        learnMore = true;
        getOffer = false;
        applyNow = false;
      });
    } else if (index == 1) {
      setState(() {
        getOffer = true;
        learnMore = false;
        applyNow = false;
      });
    } else if (index == 2) {
      setState(() {
        isActionSelected = true;
        applyNow = true;
        learnMore = false;
        getOffer = false;
      });
    }
  }

  Future<void> showSelectedLinkDialogold(index) async {
    if (selectedLink != null) {
      bool result =
          await showCustomDialog(MessageConstant.REMOVE_LEARN_MORE_LINK_VAL,(){
            performAction(index);
            selectedLink = null;
          },(){

          });

    } else if (selectedOfferLink != null) {
      bool result =
          await showCustomDialog(MessageConstant.REMOVE_GET_OFFER_LINK_VAL,(){
            performAction(index);
            selectedOfferLink = null;
          },(){

          });

    } else if (selectedApplyNowLink != null) {
      bool result =
          await showCustomDialog(MessageConstant.REMOVE_APPLY_NOW_LINK_VAL,(){
            performAction(index);
            selectedApplyNowLink = null;
          },(){

          });

    }

    if (index == 0) {}
  }
  Future<void> showSelectedLinkDialog(index,value) async {

    if (selectedLink != null) {
      bool result =
      await showCustomDialog(MessageConstant.REMOVE_LEARN_MORE_LINK_VAL,(){
        performAction(index);
        selectedLink = null;
        selectedOfferLink = null;
        selectedApplyNowLink = null;

        setState(() {
          linkUrlController.text = "";
        });
      },(){
        if (selectedUrlOption == "Learn more"){
          selectedLink = selectedLink;
          selectedOfferLink = null;
          selectedApplyNowLink = null;
          linkUrlController.text = selectedLink;

          print("linkUrlController.text - ${linkUrlController.text}");

        }else if (selectedUrlOption == "Get offer"){
          print("inside of get offer selected");
          selectedOfferLink = selectedLink;
          selectedLink = null;
          selectedApplyNowLink = null;
          linkUrlController.text = selectedOfferLink;

        } else if (selectedUrlOption == "Apply now"){
          print("inside of get apply now selected");
          selectedApplyNowLink = selectedLink;
          selectedOfferLink = null;
          selectedLink = null;
          linkUrlController.text = selectedApplyNowLink;
          print("linkUrlController.text - ${linkUrlController.text}");
        }
      });

    } else if (selectedOfferLink != null) {
      bool result =
      await showCustomDialog(MessageConstant.REMOVE_GET_OFFER_LINK_VAL,(){
        performAction(index);
        selectedLink = null;
        selectedOfferLink = null;
        selectedApplyNowLink = null;
        setState(() {
          linkUrlController.text = "";
        });
      },(){
        if (selectedUrlOption == "Learn more"){
          selectedLink = selectedOfferLink;
          selectedOfferLink = null;
          selectedApplyNowLink = null;


          linkUrlController.text = selectedLink;
          print("linkUrlController.text - ${linkUrlController.text}");

        }else if (selectedUrlOption == "Get offer"){
          print("inside of get offer selected");
          selectedOfferLink = selectedOfferLink;
          selectedLink = null;
          selectedApplyNowLink = null;

          linkUrlController.text = selectedOfferLink;

        } else if (selectedUrlOption == "Apply now"){
          print("inside of get apply now selected");
          selectedApplyNowLink = selectedOfferLink;
          selectedOfferLink = null;
          selectedLink = null;

          linkUrlController.text = selectedApplyNowLink;
          print("linkUrlController.text - ${linkUrlController.text}");
        }
      });

    } else if (selectedApplyNowLink != null) {
      bool result =
      await showCustomDialog(MessageConstant.REMOVE_APPLY_NOW_LINK_VAL,(){
        performAction(index);
        selectedLink = null;
        selectedOfferLink = null;
        selectedApplyNowLink = null;
        setState(() {
          linkUrlController.text = "";

        });
      },(){
          if (selectedUrlOption == "Learn more"){
            selectedLink = selectedApplyNowLink;
            selectedApplyNowLink = null;
            selectedOfferLink = null;

            linkUrlController.text = selectedLink;
            print("linkUrlController.text - ${linkUrlController.text}");

          }else if (selectedUrlOption == "Get offer"){
            print("inside of get offer selected");
            selectedOfferLink = selectedApplyNowLink;
            selectedLink = null;
            selectedApplyNowLink = null;

            linkUrlController.text = selectedOfferLink;

          } else if (selectedUrlOption == "Apply now"){
            print("inside of get apply now selected");
            selectedApplyNowLink = selectedApplyNowLink;
            selectedOfferLink = null;
            selectedLink = null;

            linkUrlController.text = selectedApplyNowLink;
            print("linkUrlController.text - ${linkUrlController.text}");
          }
      });

    }

    selectedUrlOption = value;

    if (selectedUrlOption == "Learn more"){

      print("inside of learn more selected");
      learnMore = true;
      getOffer = false;
      applyNow = false;
      linkUrlController.text = selectedLink;

      print("linkUrlController.text - ${linkUrlController.text}");

    }else if (selectedUrlOption == "Get offer"){
      print("inside of get offer selected");

      isActionSelected = true;
      getOffer = true;
      learnMore = false;
      applyNow = false;
      linkUrlController.text = selectedOfferLink;
      print("linkUrlController.text - ${linkUrlController.text}");

    } else if (selectedUrlOption == "Apply now"){
      print("inside of get apply now selected");

      isActionSelected = true;
      applyNow = true;
      learnMore = false;
      getOffer = false;
      linkUrlController.text = selectedApplyNowLink;
      print("linkUrlController.text - ${linkUrlController.text}");
    }

    setState(() {
      print("selectedLink - ${selectedLink}");
      print("selectedOfferLink - ${selectedOfferLink}");
      print("selectedApplyNowLink - ${selectedApplyNowLink}");

    });

    if (index == 0) {}
  }


  Future<void> showSelectedGroupDialog() async {
    if (selectedGroup != null && createNewGroup) {

      showCustomDialog(
          MessageConstant.REMOVE_NEW_GROUP_AND_ADD_EXISTING_GROUP_VAL,(){
        selectedGroup = null;
        createNewGroup = false;
        chooseExistingGroup = true;
        setState(() {});
      },(){

      });

    } else if (selectedGroup != null && chooseExistingGroup) {

      showCustomDialog(
          MessageConstant.REMOVE__EXISTING_GROUP_AND_CREATE_NEW_GROUP_VAL,(){
        selectedGroup = null;
        createNewGroup = true;
        chooseExistingGroup = false;
        setState(() {});
      },(){

      });

    }
  }

  void showSelectedGroupDialog2(index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    "Are you sure you want to remove  group and add existing group?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Remove",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              if (index == 0) {
                                                setState(() {
                                                  selectedGroup = null;
                                                  chooseExistingGroup =
                                                      !chooseExistingGroup;
                                                  createNewGroup =
                                                      !chooseExistingGroup;
                                                });
                                              } else {
                                                setState(() {
                                                  selectedGroup = null;
                                                  createNewGroup =
                                                      !createNewGroup;
                                                  chooseExistingGroup =
                                                      !createNewGroup;
                                                });
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future<bool> showCustomDialogold(String message) async {
    return await showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return CallToActionDialog(
          title: message,
          message: '',
        );
      },
    );
  }

  Future<bool> showCustomDialog(String message, VoidCallback onPositive,VoidCallback onNegative) async {
    return await showModalBottomSheet(
      backgroundColor:Colors.transparent,
      // barrierDismissible: false,
      isDismissible: false,
      context: context,
      builder: (context) {
        return ConfirmationDialog(
          msg:message,
          onPositiveTap: (){
            onPositive();
            // apiCallForDeleteOppo();
          },
          onNegativeTap: (){
            onNegative();
          },
        );
      },
    );
  }


  void checkMediaAndUpload({
    @required String imagePath,
    @required String type,
  }) async {
    //setState(() {});
    if (type == "video") {
      File file =
          await uploadMedia.compresssData(new File(imagePath), true, type);
      imagePath = file.path;
    } else if (type == "image") {
      File file = await uploadMedia.compressImage(new File(imagePath));
      imagePath = file.path;
    } else if (type == "mentorimage") {
      File file = await uploadMedia.compressImage(new File(imagePath));
      imagePath = file.path;
    }
    String strAzureImageUploadPath = await uploadImgOnAzure(
        imagePath
            .toString()
            .replaceAll("File: ", "")
            .replaceAll("'", "")
            .trim(),
        strPrefixPathforPhoto);

    CustomProgressLoader.cancelLoader(context);
    if (strAzureImageUploadPath != null || strAzureImageUploadPath != "false") {
      if (type == "video") {
        mediaAndVideoList.add("");
        String path = Constant.IMAGE_PATH +
            strPrefixPathforPhoto +
            strAzureImageUploadPath;
        print("path+++++" + path);
        final thumbnailFile =
            await uploadMedia.getVideoThumbnailFromUrl(imagePath);

        mediaVideosList.add(new FileModel(
            thumbnailFile, strPrefixPathforPhoto + strAzureImageUploadPath));
        setState(() {
          mediaVideosList;
        });

        _checkStepTwoValidaiton();


        if (mediaImagesList.length > 0 && mediaVideosList.length > 0) {
          isMediaSelected = true;
        } else {
          isMediaSelected = false;
        }
      } else if (type == "image") {
        mediaAndVideoList.add("");
        String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        setState(() {
          mediaImagesList.add(path);
        });
        _checkStepTwoValidaiton();

        if (mediaImagesList.length > 0 && mediaVideosList.length > 0) {
          isMediaSelected = true;
        } else {
          isMediaSelected = false;
        }
      } else if (type == "mentorimage") {
        String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        /*setState(() {
          userImageString = path;
        });*/

        setState(() {
          mentorImagesList.add(path);
          _checkStepTwoValidaiton();

        });
      } else {
        String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        mediaDocumentList.add(path);
        setState(() {
          mediaDocumentList;
        });
        _checkStepTwoValidaiton();

      }

      //assetModelMap.add(model);
    } else {
      //  showToastMessage('Upload failed. Please try again.');
    }
  }

  expiryDateWidget() {
    return Container(
      decoration: rectangleDecoration(),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(UIHelper.screenPadding),
            child: colorIcon(ImagePath.ICON_EXPIRY_DATE, 33, 29),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                  right: UIHelper.screenPadding,
                  bottom: UIHelper.screenPadding,
                  top: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  UIHelper.verticalSpaceExtraSmall,
                  Text(
                    'Opportunity Expiration Date',
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.primaryTextColor, 16, FontType.Regular),
                  ),
                  UIHelper.verticalSpaceExtraSmall,
                  /* Text(
                    'Select the expiry date to close for your audience',
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.secondaryTextColor, 14, FontType.Regular),
                  ),*/
                  InkWell(
                    child: TextFormField(
                      controller: expiryDateController,
                      onTap: () {
                        if (ageToController.text == "") {
                          ToastWrap.showToast(
                              "Please select \"scheduled date\".", context);
                        } else {
                          expiryDatePicker(context);
                        }
                      },
                      readOnly: true,
                      //  enabled: false,
                      decoration:
                          textFormFieldDecorationWithLabel('Select date'),
                      style: textFormFieldValueStyle(),
                      onFieldSubmitted: (term) {},
                      validator: (value) {
                        return expiryValidation
                            ? MessageConstant.ENTER_EXPIRATION_DATE_BETWEEN_VAL
                            : ValidationChecks.validateExpiryDate(value);
                      },
                    ),
                    onTap: () {
                      if (ageToController.text == "") {
                        ToastWrap.showToast(
                            "Please select \"scheduled date\".", context);
                      } else {
                        expiryDatePicker(context);
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<Null> expiryDatePicker(BuildContext context) async {
//DateTime date =  DateTime(2020, 2, 29);
    DateTime date =  DateTime.now();
    int day = date.day;
    if (date.month == DateTime.february) {
      if (day == 29) day = 28;
    }
    var newDate =  DateTime(date.year + 2, date.month, day);

    DatePicker.showDatePicker(
      context,
      pickerTheme: DateTimePickerTheme(
        showTitle: true,
        confirm: Text('Done', style: TextStyle()),
        cancel: Text('Cancel', style: TextStyle()),
      ),
      minDateTime:  DateTime.now(),
      pickerMode: DateTimePickerMode.date,
      maxDateTime: newDate,
      initialDateTime:
          expiryDateTime == null ?  DateTime.now() : expiryDateTime,
      dateFormat: 'MMM-dd-yyyy',
      locale: DateTimePickerLocale.en_us,
      onClose: () => print("----- onClose -----"),
      onCancel: () => print('onCancel'),
      onChange: (dateTime, List<int> index) {
        print("onchange" + dateTime.toString());
      },
      onConfirm: (dateTime, List<int> index) {
        print("onconform" + dateTime.toString());
        setState(() {
          FocusScope.of(context).requestFocus(new FocusNode());
        });
        if (dateTime != null) {
//var differenceStartDate = dateTime.difference(toDate);
//print("differenceStartDate+++" + differenceStartDate.inDays.toString());
//if (differenceStartDate.inDays <= 1) {
          String date = Util.getDate(dateTime);
//String date2 =  DateFormat("yyyy-MM-dd").format(dateTime);
          print(date);
          setState(() {
            expiryValidation = false;
            expiryDateTime = dateTime;
            expiryDateController.text = date;
            expiryDate = dateTime.millisecondsSinceEpoch;
          });
/*} else {
setState(() {
expiryValidation = true;
//_jobFormKey.currentState.validate();
expiryDateController.text = "";
});
}*/
        }
      },
    );
  }

  countryOrCityListWidget() {
    print(
        'Apurva countryOrCityListWidget countries size:: ${countries.length}');
    countries = removeAlreadyAddedItems(countries, selectedCountries);
    setState(() {
      countries;
    });
    print(
        'Apurva countryOrCityListWidget countries size:: ${countries.length}');
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? countries.length > 0
                ? Card(
                    child: Container(
                      padding: countries.length > 0
                          ? EdgeInsets.all(10)
                          : EdgeInsets.all(0),
                      child: AnimatedList(
                        key: _listKey,
                        initialItemCount: countries.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index, animation) {
                          animation = CurvedAnimation(
                              curve: Curves.linear, parent: animation);

                          return _buildAddedItem(countries[index], animation);
                        },
                      ),
                    ),
                  )
                : Container()
            : Container(),
      ],
    );
  }

  void _insertSingleItem(Item item) {
    if (countries.length <= 0) {
      countries.insert(0, item);
      _listKey.currentState
          .insertItem(0, duration: Duration(milliseconds: 1000));
    } else {
      if (item.index >= countries.length) {
        countries.insert(countries.indexOf(countries.last), item);
        _listKey.currentState.insertItem(countries.indexOf(countries.last),
            duration: Duration(milliseconds: 1000));
      } else {
        countries.insert(item.index, item);
        _listKey.currentState
            .insertItem(item.index, duration: Duration(milliseconds: 1000));
      }
    }
    countries.sort((Item a, Item b) {
      return a.index.compareTo(b.index);
    });
  }

  void _removeSingleItems(int removeIndex) {
    Item removedItem = countries.removeAt(removeIndex);
    // This builder is just so that the animation has something
    // to work with before it disappears from view since the
    // original has already been deleted.
    AnimatedListRemovedItemBuilder builder = (context, animation) {
      // A method to build the Card widget.
      return _buildRemovedItem(removedItem, animation);
    };
    _listKey.currentState.removeItem(removeIndex, builder,
        duration: Duration(milliseconds: 1000));
    if (countries.length <= 0) {
      showList = !showList;
      setState(() {});
    }
  }

  Widget _buildAddedItem(Item item, Animation animation) {
    return FadeTransition(
      opacity: animation,

      child: Padding(
        padding: const EdgeInsets.only(top: 5, bottom: 3),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: ColorValues.TAB_BACKGROUND_COLOR,
            border: Border.all(
              color: ColorValues.BORDER_COLOR_NEW, // Border color
              width: 1.0, // Border width
            ),
          ),
          // axis: Axis.vertical,
          // sizeFactor: animation,

          child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: InkWell(
                onTap: () {
                  CustomProgressLoader.showLoader(context);
                  print("item++++" + item.name);
                  displayPrediction(item.id, item.name, item.index);
                  _removeSingleItems(countries.indexOf(item));
                  showList = !showList;
                  //searchCountryController.clear();
                  setState(() {});
                },
                child: AnimatedContainer(
                  curve: Curves.easeIn,
                  duration: Duration(milliseconds: 500),
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  child: Text(item.name,
                      style: TextStyle(
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                          color: ColorValues.HEADING_COLOR_EDUCATION_1)),
                  padding: EdgeInsets.all(8),
                ),
              )),
        ),
      ),
    );
  }

  Widget _buildRemovedItem(Item item, Animation animation) {
    return FadeTransition(
      opacity: animation,
      child: SizeTransition(
        axis: Axis.vertical,
        sizeFactor: animation,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: Offset(-1, 0),
            end: Offset.zero,
          ).animate(animation),
          child: InkWell(
            onTap: () {
              selectedCountries.add(item);

              _removeSingleItems(countries.indexOf(item));
              setState(() {});
            },
            child: AnimatedContainer(
              // color: Palette.accentColor,
              color: Colors.transparent,
              curve: Curves.easeIn,
              duration: Duration(milliseconds: 500),
              width: MediaQuery.of(context).size.width,
              child: Text(item.name),
              padding: EdgeInsets.all(8),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> getSelectedWidgets() {
    List<Widget> widgets = [];
    for (Item item in selectedCountries) {
      print("Name+++++" + item.name);
      double width = item.name.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            /* if (value <= 50) {
              return Container(
                height: 35,
                width: value + 5,
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  border: Border.all(
                    color: Palette.accentColor,
                  ),
                ),
              );
            } else*/
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return
                  Padding(
                      padding: const EdgeInsets.all(2),
                      child: Container(
                        decoration: BoxDecoration(
                          color: ColorValues.DARK_YELLOW,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: InkWell(
                                  onTap: () {
                                    // Handle selection here
                                    print('Selected: ${item.name}');
                                  },
                                  child: Text(
                                    '${item.name}',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                    // maxLines: 1,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 2, left: 3),
                                child: InkWell(
                                  onTap: () {
                                    // Handle deletion here
                                    print('Deleted: ${item.name}');
                                    if (showList) {
                                      selectedCountries.remove(item);
                                      _insertSingleItem(item);
                                      setState(() {});
                                    } else {
                                      selectedCountries.remove(item);
                                      countries.add(item);
                                      countries.sort((item1, item2) {
                                        return item1.index.compareTo(item2.index);
                                      });
                                      setState(() {});
                                    }
                                    //updateList(item, index);
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.white,
                                    size: 16.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));



                Container(
                  margin: EdgeInsets.all(5),
                  child: Chip(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: BorderSide(
                        color: Palette.accentColor,
                      ),
                    ),
                    backgroundColor: Palette.white,
                    deleteIcon: value >= (width)
                        ? Icon(Icons.cancel, color: Palette.accentColor)
                        : Icon(Icons.cancel, color: Palette.accentColor),
                    onDeleted: () {
                      if (showList) {
                        selectedCountries.remove(item);
                        _insertSingleItem(item);
                        setState(() {});
                      } else {
                        selectedCountries.remove(item);
                        countries.add(item);
                        countries.sort((item1, item2) {
                          return item1.index.compareTo(item2.index);
                        });
                        setState(() {});
                      }
                    },
                    label: Container(
                      alignment: AlignmentDirectional.center,
                      /*height: item.name.length > 16 && item.name.length <= 40
                            ? 55
                            : item.name.length > 40 && item.name.length <= 50
                                ? 80
                                : item.name.length > 50 ? 110 : 30,*/
                      //width: width,
                      width: value + 5,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Text(
                          item.name,
                          style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          //'Address: 26/1 Brigade Gateway, Dr Rajkumar Rd 22nd Floor, Malleshwaram, Bengaluru, Karnataka 560055',
                          //'sd sdg sgersg rgesrgerge ergehe erhgethb erhrtdhbrtn ethrtnfrnfryn tnrnrnyn',
                          maxLines: 20,
                          softWrap: true,
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  static validZipCode(String value) {
    String patttern = r'(^(?:[0]9)?[0-9]{4,10}$)';
    RegExp regExp =  RegExp(patttern);
    if (!regExp.hasMatch(value.trim())) {
      return false;
    } else {
      return true;
    }
    /*  if (value.isNotEmpty && value.trim().length > 6 && value.trim().length < 15)
      return null;
    else
      return 'Please enter valid phone number ';*/
  }

  Future<Null> displayPrediction(placeId, name, index) async {
    try {
      print("Calling+++++");
      if (placeId != null) {
        // get detail (lat/lng)
        print("displayPrediction addres++++1");
        PlacesDetailsResponse detail =
            await _places.getDetailsByPlaceId(placeId);
        print("addres++++2");
        final lat = detail.result.geometry.location.lat;

        final lng = detail.result.geometry.location.lng;

        try {
          String city = "", state = "", country = "";
          if (detail.result.addressComponents.length > 3) {
            city = detail
                .result
                .addressComponents[detail.result.addressComponents.length - 3]
                .longName;
            state = detail
                .result
                .addressComponents[detail.result.addressComponents.length - 2]
                .longName;
            country = detail
                .result
                .addressComponents[detail.result.addressComponents.length - 1]
                .longName;
          } else if (detail.result.addressComponents.length > 0) {
            //city=json[1]['long_name'];
            try {
              state = detail
                  .result
                  .addressComponents[detail.result.addressComponents.length - 2]
                  .longName;
              country = detail
                  .result
                  .addressComponents[detail.result.addressComponents.length - 1]
                  .longName;
            } catch (e) {
              country = detail
                  .result
                  .addressComponents[detail.result.addressComponents.length - 1]
                  .longName;
            }
          }
          print("country+++" +
              country +
              "  city+++" +
              city +
              "     state++" +
              state);
          selectedCountries.add(
               Item(index, name.trim(), placeId, state, country, city, ""));
        } catch (e) {}

        setState(() {});
        CustomProgressLoader.cancelLoader(context);
      }
    } catch (e) {
      print("placepicker error+++" + e.toString());
      CustomProgressLoader.cancelLoader(context);
    }
  }

  List<Item> removeAlreadyAddedItems(
      List<Item> countries, List<Item> selectedCountries) {
    /*for(int i=0; i < selectedCountries.length; i++){
      if(countries){

      }
    }*/
    //List<double> first = [1,2,3,4,5,6,7];
    //List<double> second = [3,5,6,7,9,10];
    List<Item> finalCountry = []; //[1,2,4]

    print(
        'Apurva removeAlreadyAddedItems countries size:: ${countries.length}');
    countries.forEach((element) {
      if (!selectedCountries.contains(element)) {
        finalCountry.add(element);
      }
    });
    print(
        'Apurva removeAlreadyAddedItems finalCountry size:: ${finalCountry.length}');
    return finalCountry;

//at this point, output list should have the answer
  }

  Future getDesignation() async {
    print('inside getSubjects() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2()
            .apiCallWithAuthToken(context, Constant.ENDPOINT_CATEGORY, "get");

        print('Apurva ui/category() Response:::: ${response.toString()}');

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              DesignationModel apiResponse =
                   DesignationModel.fromJson(response.data);
              setState(() {
                designationList = apiResponse.result;
                /*if(subjectsList.length > 0){
                  selectedSubject = subjectsList[0].name;
                }*/
                orignalDesignationList.addAll(designationList);
                designationList.insert(
                    0,
                    DesignationModelResult(
                        categoryId: -1,
                        name: "Select All",
                        description: "Select All"));
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future getSubjects() async {
    print('inside getSubjects() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2()
            .apiCallWithAuthToken(context, Constant.ENDPOINT_SUBJECTS, "get");

        print('Apurva getSubjects() Response:::: ${response.toString()}');

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              SubjectsModel apiResponse =
                   SubjectsModel.fromJson(response.data);
              setState(() {
                subjectList = apiResponse.result;
                orignalSubjectList.addAll(subjectList);
                /*if(subjectsList.length > 0){
                  selectedSubject = subjectsList[0].name;
                }*/
                subjectList.insert(
                    0,
                    SubjectsModelResult(
                        subjectId: -1,
                        name: "Select All",
                        description: "Select All"));
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future getQualifications() async {
    print('inside getQualifications() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCallWithAuthToken(
            context, Constant.ENDPOINT_QUALIFICATIONS, "get");

        print('Apurva getQualifications() Response:::: ${response.toString()}');

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              QualificationsModel apiResponse =
                   QualificationsModel.fromJson(response.data);
              setState(() {
                qualificationsList = apiResponse.result;
                orignalQualificationList.addAll(qualificationsList);
                qualificationsList.insert(
                    0,
                    QualificationsModelResult(
                        qualificationId: -1,
                        name: "Select All",
                        description: "Select All"));
                /*if(qualificationsList.length > 0){
                  selectedQualification = qualificationsList[0].name;
                }*/
                print('Qualifications size:: ${qualificationsList.length}');
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  getWeekDaysForSelection() {
    return  Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(
              bottom: UIHelper.screenPadding,
              top: 5,
            ),
            child: InkWell(
              child: TextFormField(
                controller: ageFromController,
                onTap: () {
                  dateFromPicker(context);
                },
                readOnly: true,
                // enabled: false,

                decoration: textFormFieldDecorationWithLabel('Date From'),
                style: textFormFieldValueStyle(),
                onFieldSubmitted: (term) {},
                validator: (value) {
                  return ValidationChecks.validateDateFrom(value);
                },
              ),
              onTap: () {
                dateFromPicker(context);
              },
            ),
          ),
        ),
        UIHelper.horizontalGapBetweenBox,
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(
                top: 5,
                bottom: UIHelper.screenPadding,
                right: UIHelper.screenPadding),
            child: InkWell(
              child: TextFormField(
                controller: ageToController,
                onTap: () {
                  dateToPicker(context);
                },
                readOnly: true,
                //enabled: false,
                decoration: textFormFieldDecorationWithLabel('Date To'),
                style: textFormFieldValueStyle(),
                onFieldSubmitted: (term) {},
                validator: (value) {
                  return ValidationChecks.validateDateTo(value);
                },
              ),
              onTap: () {
                dateToPicker(context);
              },
            ),
          ),
        ),
      ],
    );
  }

  selectCareerTextField() {
    return
      TextFormField(
        decoration: InputDecoration(
          alignLabelWithHint:true,
          isDense: false,
          filled: false,
          errorMaxLines: 4,
          focusColor: AppConstants.colorStyle.lightBlue,
          errorStyle: AppConstants.txtStyle.labelStyleTextForm,
          counterStyle: AppConstants.txtStyle.counterStyleTextForm,
          //fillColor: Colors.transparent,
          labelText: "Career",
          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
          hintText: "",
          hintStyle: TextStyle(
            color: ColorValues.Withdraw_Button_Border,
            fontFamily: Constant.latoRegular,
          ),

          border: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.lightBlue,
                  width: 1.0)),
          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
          disabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
        ),
        style: _careerFocus.hasFocus
            ? AppConstants.txtStyle.txtStyleTextForm
            : AppConstants.txtStyle.txtStyleTextFormHGRey,


        focusNode: _careerFocus,

        controller: careerController,
        onChanged: (value) {},
        textInputAction: TextInputAction.done,
        autocorrect: false,
        onFieldSubmitted: (term) {
          if (careerController.text != null && careerController.text != "") {
            if (!selectedDesignationCareerOption
                .contains(careerController.text)) {
              selectedDesignationCareerOption.add(careerController.text);
            }
          }
          //getSelectedCategoryDetail('Other');
          //selectedCategoryList.add(new CategoryModel(designationController.text,otherCategoryId, true));
          careerController.clear();
        },
        validator: (String arg) {
          if (selectedDesignationCareerOption.length > 0) {
            return null;
          } else {
            return MessageConstant.ENTER_DESIGNATION_VAL_other;
          }
        },
      );
  }


  designationWidget() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          decoration: bottomBorderDynamic(Palette.dividerColor),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[

              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[

                  Expanded(
                      flex: 1,
                      child: InkWell(
                        onTap: () {
                          showSubjectList = false;
                          showDesignationList = !showDesignationList;
                          showQualificationList = false;
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {});
                        },
                        child: Container(
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 14.0),
                            child: Text(
                              'Category',
                              style: AppConstants.txtStyle.labelStyleTextForm,
                            ),
                          ),
                        ),
                      )),


                  IconButton(
                    onPressed: () {
                      showSubjectList = false;
                      showDesignationList = !showDesignationList;
                      showQualificationList = false;
                      FocusScope.of(context).requestFocus(FocusNode());
                      setState(() {});

                    },
                    icon: Padding(
                      padding: const EdgeInsets.only(left: 22.0),
                      child: Icon(showDesignationList
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,color: Color(0xff666B9A)),
                    ),
                  ),
                ],
              ),

            ],
          ),
        ),
        const SizedBox(height: 5,),

        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[

            selectedDesignationOption.length > 0
                ? Expanded(
              flex: 1,
              child: InkWell(
                  onTap: () {
                    showSubjectList = false;
                    showDesignationList = !showDesignationList;
                    showQualificationList = false;
                    FocusScope.of(context)
                        .requestFocus(FocusNode());
                    setState(() {});
                  },
                  child: Wrap(
                    children:
                    /*isShowMoreDesignation
                        ? getSelectedDesignationWidgets(
                        selectedDesignationOption.sublist(0, 1),
                        "mainCategory")
                        : */
                    getSelectedDesignationWidgets(
                        selectedDesignationOption,
                        "mainCategory"),
                  )),
            )
                :

            const SizedBox(),

          ],
        ),

        //isOtherSelected ?
        _mCategoryFormModel != null &&
            _mCategoryFormModel.mainCategoryList.length > 0
            ? designationCategoryListWidget()
            : Container(),

        // isDesignationError
        //     ? Padding(
        //   padding: const EdgeInsets.only(top: 6.0),
        //   child: Text(
        //     '${MessageConstant.ENTER_DESIGNATION_VAL}',
        //     style: AppTextStyle.getDynamicFontStyle(
        //       //Palette.redColor,
        //         Colors.red[700],
        //         12,
        //         FontType.Regular),
        //   ),
        // )
        //     : Container(),

        isDesignationOtherSelected
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            UIHelper.verticalSpaceSmall1,
            Container(
              //decoration: bottomBorder(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[

                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[

                      Expanded(
                        flex: 1,
                        child: isDesignationOtherSelected
                            ? selectOtherDesignationTextField()
                            : Container(),
                      ),

                    ],
                  ),

                ],
              ),
            ),
          ],
        )
            : Container(),

        const SizedBox(height: 5,),

        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[

            selectedDesignationOtherOption.length > 0
                ? Expanded(
              flex: 1,
              child: Wrap(
                //children: getSelectedWidgets(selectedOtherOption,"otherCategory"),
                children:

                getSelectedDesignationWidgetsForOther(
                    selectedDesignationOtherOption,
                    "otherCategory"),
              ),
            )
                :

            const SizedBox(),

          ],
        ),

        isCareerSelected
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            UIHelper.verticalSpaceSmall1,
            Container(
              //decoration: bottomBorder(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[

                      Expanded(
                        flex: 1,
                        child: isCareerSelected
                            ? selectCareerTextField()
                            : Container(),
                      ),

                    ],
                  ),

                  const SizedBox(height: 5,),

                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[

                      selectedDesignationCareerOption.length > 0
                          ? Expanded(
                        flex: 1,
                        child: Wrap(
                          //children: getSelectedWidgets(selectedOtherOption,"otherCategory"),
                          children:

                          getSelectedDesignationWidgetsForCareer(
                              selectedDesignationCareerOption,
                              "Career"),
                        ),
                      )
                          :

                      const SizedBox(),

                    ],
                  ),


                ],
              ),
            ),
          ],
        )
            : Container(),



        /////////////////////////////////////
      ],
    );
  }

  subjectWidget() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////////////////

        Container(
          decoration: bottomBorderDynamic(Palette.dividerColor),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // selectedSubjectOption.length > 0
              //     ? Text(
              //         'Subject',
              //         style: AppTextStyle.getDynamicFontStyle(
              //             Palette.secondaryTextColor, 12, FontType.Regular),
              //       )
              //     : Container(),
              //
              // SizedBox(height: 5,),

              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[

                  // selectedSubjectOption.length > 0
                  //     ? SizedBox()
                  //     :
                  Expanded(
                    flex: 1,
                    child: InkWell(
                        onTap: () {
                          showSubjectList = !showSubjectList;
                          showDesignationList = false;
                          showQualificationList = false;
                          FocusScope.of(context)
                              .requestFocus(FocusNode());
                          setState(() {});
                        },
                        child: Container(
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 14.0),
                            child: Text(
                              'Subject',
                              style: AppConstants.txtStyle.labelStyleTextForm,

                            ),
                          ),
                        )),
                  ),

                  IconButton(
                    onPressed: () {
                      showSubjectList = !showSubjectList;
                      showDesignationList = false;
                      showQualificationList = false;
                      FocusScope.of(context).requestFocus(FocusNode());
                      setState(() {});
                      /* showSubjectList = !showSubjectList;
                      setState(() {});*/
                    },
                    icon: Padding(
                      padding: const EdgeInsets.only(left: 22.0),
                      child: Icon(showSubjectList
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,
                        color: Color(0xff666B9A),
                      ),
                      // Replace with the desired color

                    ),
                  ),
                ],
              ),


              /*selectedOtherOption.length > 0
                          ? selectOtherCategoryTextField()
                          : Container(),*/
            ],
          ),
        ),
        //isOtherSelected ?

        const SizedBox(height: 5,),

        Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[

              selectedSubjectOption.length > 0
                  ? Expanded(
                flex: 1,
                child: InkWell(
                    onTap: () {
                      showSubjectList = !showSubjectList;
                      showDesignationList = false;
                      showQualificationList = false;
                      FocusScope.of(context)
                          .requestFocus(FocusNode());
                      setState(() {});
                    },
                    child: Wrap(
                      children:
                      // isShowMoreSubject
                      //     ? getSelectedSubjectsWidgets(
                      //     selectedSubjectOption.sublist(0, 1),
                      //     "mainCategory")
                      //     :
                      getSelectedSubjectsWidgets(
                          selectedSubjectOption, "mainCategory"),
                    )),
              )
                  :
              const SizedBox(),

            ]
        ),


        selectedDesignationOption.length > 0
            ? subjectCategoryListWidget()
            : Container(),

        SizedBox(height: 5,),



        // isSubjectError
        //     ? Padding(
        //   padding: const EdgeInsets.only(top: 6.0),
        //   child: Text(
        //     '${MessageConstant.ENTER_SUBJECT_VAL}',
        //     style: AppTextStyle.getDynamicFontStyle(
        //       //Palette.redColor,
        //         Colors.red[700],
        //         12,
        //         FontType.Regular),
        //   ),
        // )
        //     : Container(),

        isSubjectOtherSelected
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            UIHelper.verticalSpaceSmall1,
            Container(
              //decoration: bottomBorder(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[

                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[

                      Expanded(
                        flex: 1,
                        child: isShowMoreSubjectOther
                            ? selectOtherSubjectTextField()
                            : Container(),
                      ),

                    ],
                  ),

                  SizedBox(height: 5,),


                  Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[

                        selectedSubjectOtherOption.length > 0
                            ? Expanded(
                          flex: 1,
                          child: Wrap(
                            //children: getSelectedWidgets(selectedOtherOption,"otherCategory"),
                            children:

                            getSelectedSubjectWidgets(
                                selectedSubjectOtherOption,
                                "otherCategory"),
                          ),
                        )
                            :
                        const SizedBox(),


                      ]
                  ),



                ],
              ),
            ),
          ],
        )
            : Container(),
        //////////////////////////////////////////////
      ],
    );
  }

  qualificationWidget() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////////////////

        Container(
          decoration: bottomBorderDynamic(Palette.dividerColor),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[


              // selectedQualificationOption.length > 0
              //     ? Text(
              //         'Qualifications',
              //         style: AppTextStyle.getDynamicFontStyle(
              //             Palette.secondaryTextColor, 12, FontType.Regular),
              //       )
              //     : Container(),

              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[

                  Expanded(
                      flex: 1,
                      child: InkWell(
                        onTap: () {
                          showSubjectList = false;
                          showDesignationList = false;
                          showQualificationList = !showQualificationList;
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {});
                        },
                        child: Container(
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 14.0),
                            child: Text(
                              'Qualifications',
                              style: AppConstants.txtStyle.labelStyleTextForm,

                            ),
                          ),
                        ),
                      )),


                  IconButton(
                    onPressed: () {
                      showSubjectList = false;
                      showDesignationList = false;
                      showQualificationList = !showQualificationList;
                      FocusScope.of(context).requestFocus(FocusNode());
                      setState(() {});
                      /*    showQualificationList = !showQualificationList;
                      setState(() {});*/
                    },
                    icon: Padding(
                      padding: const EdgeInsets.only(left: 22.0),
                      child: Icon(showQualificationList
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,color: Color(0xff666B9A),),
                    ),
                  ),
                ],
              ),



              /*selectedOtherOption.length > 0
                          ? selectOtherCategoryTextField()
                          : Container(),*/
            ],
          ),
        ),
        //isOtherSelected ?
        const SizedBox(height: 5,),

        Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[

              selectedQualificationOption.length > 0
                  ? Expanded(
                  flex: 1,
                  child: InkWell(
                    onTap: () {
                      showSubjectList = false;
                      showDesignationList = false;
                      showQualificationList = !showQualificationList;
                      FocusScope.of(context).requestFocus(FocusNode());
                      setState(() {});
                    },
                    child: Wrap(
                      children:

                      getSelectedQualificationWidgets(
                          selectedQualificationOption,
                          "mainCategory"),
                    ),
                  ))
                  :
              const SizedBox(),


            ]
        ),



        qualificationsList != null && qualificationsList.length > 0
            ? qualificationCategoryListWidget()
            : Container(),

        // isQualificationError
        //     ? Padding(
        //   padding: const EdgeInsets.only(top: 6.0),
        //   child: Text(
        //     '${MessageConstant.ENTER_QUALIFICATION_VAL}',
        //     style: AppTextStyle.getDynamicFontStyle(
        //       //Palette.redColor,
        //         Colors.red[700],
        //         12,
        //         FontType.Regular),
        //   ),
        // )
        //     : Container(),

        isQualificationOtherSelected
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            UIHelper.verticalSpaceSmall1,
            Container(
              //decoration: bottomBorder(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[

                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[



                      Expanded(
                        flex: 1,
                        child: isShowMoreQualificationOther
                            ? selectOtherQualificationTextField()
                            : Container(),
                      ),

                    ],
                  ),


                ],
              ),
            ),

            const SizedBox(height: 5,),

            Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[

                  selectedQualificationOtherOption.length > 0
                      ? Expanded(
                    flex: 1,
                    child: Wrap(
                      //children: getSelectedWidgets(selectedOtherOption,"otherCategory"),
                      children:

                      getSelectedQualificationWidgets(
                          selectedQualificationOtherOption,
                          "otherCategory"),
                    ),
                  )
                      :
                  const SizedBox(),

                ]
            ),

          ],
        )
            : Container(),
        //////////////////////////////////////////////
      ],
    );
  }


  List<Widget> getSelectedDesignationWidgetsForCareer(
      List<String> selectedOption, String from) {
    List<Widget> widgets = [];
    for (String item in selectedOption) {
      print("Name+++++" + item);
      double width = item.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                return Container(
                    padding: const EdgeInsets.only(left: 0,right: 8,top: 5,bottom: 5),
                    child:

                    Container(
                      decoration: BoxDecoration(
                        color: ColorValues.DARK_YELLOW,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8,right: 8,top: 6,bottom: 6),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Flexible(
                              child: InkWell(
                                onTap: () {
                                  // Handle selection here
                                  print('Selected: ${item}');
                                },
                                child: Text(
                                  item,
                                  style: TextStyle(
                                    fontSize: 16.0,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                  // maxLines: 1,
                                  // overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                              const EdgeInsets.only(top: 2, left: 3),
                              child: InkWell(
                                onTap: () {
                                  // Handle deletion here
                                  selectedDesignationCareerOption.remove(item);
                                  _checkStepOneValidaiton();
                                  setState(() {});
                                  //updateList(item, index);
                                },
                                child: Icon(
                                  Icons.clear,
                                  color: Colors.white,
                                  size: 17.0,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ));

              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  //Shubham other cater
  List<Widget> getSelectedDesignationWidgetsForOther(
      List<String> selectedOption, String from) {
    List<Widget> widgets = [];
    for (String item in selectedOption) {
      print("Name+++++" + item);
      double width = item.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return
                  Padding(
                      padding: const EdgeInsets.only(left: 0,right: 8,top: 5,bottom: 5),
                      child: Container(
                        decoration: BoxDecoration(
                          color: ColorValues.DARK_YELLOW,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8,right: 8,top: 6,bottom: 6),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: InkWell(
                                  onTap: () {
                                    // Handle selection here
                                    print('Selected: ${item}');
                                  },
                                  child: Text(
                                    item,
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                    // maxLines: 1,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 2, left: 3),
                                child: InkWell(
                                  onTap: () {
                                    // Handle deletion here
                                    selectedDesignationOtherOption.remove(item);

                                    setState(() {});

                                    showDesignationList = false;
                                    _checkStepOneValidaiton();


                                    setState(() {});
                                    //updateList(item, index);
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.white,
                                    size: 17.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));


                  Container(
                  margin: EdgeInsets.all(5),

                  child: Chip(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: BorderSide(
                        color: Palette.accentColor,
                      ),
                    ),
                    backgroundColor: Palette.white,
                    deleteIcon: value >= (width)
                        ? Icon(Icons.cancel, color: Palette.accentColor)
                        : Icon(Icons.cancel, color: Palette.accentColor),
                    onDeleted: () {
                      selectedDesignationOtherOption.remove(item);

                      setState(() {});

                      showDesignationList = false;
                      _checkStepOneValidaiton();

                      setState(() {});
                    },
                    label: Container(
                      alignment: AlignmentDirectional.center,
                      /*height: item.name.length > 16 && item.name.length <= 40
                            ? 55
                            : item.name.length > 40 && item.name.length <= 50
                                ? 80
                                : item.name.length > 50 ? 110 : 30,*/
                      width: width,
                      //width: value + 5,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Text(
                          item,
                          style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          //'Address: 26/1 Brigade Gateway, Dr Rajkumar Rd 22nd Floor, Malleshwaram, Bengaluru, Karnataka 560055',
                          //'sd sdg sgersg rgesrgerge ergehe erhgethb erhrtdhbrtn ethrtnfrnfryn tnrnrnyn',
                          maxLines: 20,
                          softWrap: true,
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  //Shubham
  List<Widget> getSelectedDesignationWidgets(
      List<SelectedDesignationModel> selectedOption, String from) {
    List<Widget> widgets = [];
    for (SelectedDesignationModel item in selectedOption) {
      print("Name+++++" + item.toString());
      double width = item.name.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return
                  Padding(
                      padding: const EdgeInsets.only(left: 0,right: 8,top: 5,bottom: 5),
                      child: Container(
                        decoration: BoxDecoration(
                          color: ColorValues.DARK_YELLOW,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8,right: 8,top: 6,bottom: 6),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: InkWell(
                                  onTap: () {
                                    // Handle selection here
                                    print('Selected: ${item.name}');
                                  },
                                  child: Text(
                                    '${item.name}',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                    // maxLines: 1,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 2, left: 3),
                                child: InkWell(
                                  onTap: () {
                                    // Handle deletion here
                                    if (item.name == 'Other') {
                                      isDesignationOtherSelected = false;
                                      isShowMoreDesignationOther = true;
                                      selectedDesignationOtherOption.clear();
                                    }

                                    if (item.name == 'Career') {
                                      isCareerSelected = false;
                                      selectedDesignationCareerOption.clear();
                                      isShowMoreCareerOther = true;
                                    }

                                    selectedSubjectOption.removeWhere(
                                            (SelectedCategoryModel item1) =>
                                        item1.mainCategoryIndex == item.index);

                                    _mCategoryFormModel
                                        .mainCategoryList[item.index].isSelected = false;
                                    for (SubCategory subCat in _mCategoryFormModel
                                        .mainCategoryList[item.index].subCategoryList) {
                                      subCat.isSelected = false;
                                    }

                                    selectedDesignationOption.remove(item);

                                    if (selectedDesignationOption.length == 0) {
                                      selectedSubjectOption.clear();
                                      isSubjectOtherSelected = false;
                                    }
                                    showSubjectList = false;
                                    showDesignationList = false;

                                    _checkStepOneValidaiton();

                                    setState(() {});
                                    //updateList(item, index);
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.white,
                                    size: 16.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));

                Container(
                  margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                  child: Chip(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: BorderSide(
                        color: Palette.accentColor,
                      ),
                    ),
                    backgroundColor: Palette.white,
                    deleteIcon: value >= (width)
                        ? Icon(Icons.cancel, color: Palette.accentColor)
                        : Icon(Icons.cancel, color: Palette.accentColor),
                    onDeleted: () {
                      if (item.name == 'Other') {
                        isDesignationOtherSelected = false;
                        isShowMoreDesignationOther = true;
                        selectedDesignationOtherOption.clear();
                      }

                      if (item.name == 'Career') {
                        isCareerSelected = false;
                        selectedDesignationCareerOption.clear();
                        isShowMoreCareerOther = true;
                      }

                      selectedSubjectOption.removeWhere(
                              (SelectedCategoryModel item1) =>
                          item1.mainCategoryIndex == item.index);

                      _mCategoryFormModel
                          .mainCategoryList[item.index].isSelected = false;
                      for (SubCategory subCat in _mCategoryFormModel
                          .mainCategoryList[item.index].subCategoryList) {
                        subCat.isSelected = false;
                      }

                      selectedDesignationOption.remove(item);

                      if (selectedDesignationOption.length == 0) {
                        selectedSubjectOption.clear();
                        isSubjectOtherSelected = false;
                      }
                      showSubjectList = false;
                      showDesignationList = false;
                      setState(() {});
                    },
                    label: Container(
                      alignment: AlignmentDirectional.center,

                      width: width,
                      //width: value + 5,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Text(
                          item.name,
                          style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          maxLines: 20,
                          softWrap: true,
                        ),
                      ),
                    ),
                  ),
                );





              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  List<Widget> getSelectedSubjectWidgets(
      List<String> selectedOption, String from) {
    List<Widget> widgets = [];
    for (String item in selectedOption) {
      print("Name+++++" + item);
      double width = item.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return

                  Padding(
                      padding: const EdgeInsets.only(left: 0,right: 8,top: 5,bottom: 5),
                      child: Container(
                        decoration: BoxDecoration(
                          color: ColorValues.DARK_YELLOW,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8,right: 8,top: 6,bottom: 6),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: InkWell(
                                  onTap: () {
                                    // Handle selection here
                                    print('Selected: ${item}');
                                  },
                                  child: Text(
                                    '${item}',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                    // maxLines: 1,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 2, left: 3),
                                child: InkWell(
                                  onTap: () {
                                    // Handle deletion here
                                    if (from == "mainCategory") {
                                      if (subjectList.length == 0) {
                                        subjectList.insert(
                                            0,
                                            SubjectsModelResult(
                                                subjectId: -1,
                                                name: 'Select All',
                                                description: 'Select All'));
                                      }
                                      if (item == 'Other') {
                                        //setState(() {
                                        isSubjectOtherSelected = false;
                                        selectedSubjectOtherOption.clear();
                                        isShowMoreSubjectOther = true;
                                        //});
                                      }
                                      updateSubjectList(item);

                                      setState(() {});
                                    } else {
                                      selectedSubjectOtherOption.remove(item);

                                      setState(() {});
                                    }


                                    _checkStepOneValidaiton();

                                    showSubjectList = false;
                                    setState(() {});
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.white,
                                    size: 16.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));



                Container(
                  margin: EdgeInsets.all(5),
                  child: Chip(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: BorderSide(
                        color: Palette.accentColor,
                      ),
                    ),
                    backgroundColor: Palette.white,
                    deleteIcon: value >= (width)
                        ? Icon(Icons.cancel, color: Palette.accentColor)
                        : Icon(Icons.cancel, color: Palette.accentColor),
                    onDeleted: () {
                      if (from == "mainCategory") {
                        if (subjectList.length == 0) {
                          subjectList.insert(
                              0,
                              SubjectsModelResult(
                                  subjectId: -1,
                                  name: 'Select All',
                                  description: 'Select All'));
                        }
                        if (item == 'Other') {
                          //setState(() {
                          isSubjectOtherSelected = false;
                          selectedSubjectOtherOption.clear();
                          isShowMoreSubjectOther = true;
                          //});
                        }
                        updateSubjectList(item);

                        setState(() {});
                      } else {
                        selectedSubjectOtherOption.remove(item);

                        setState(() {});
                      }

                      /*print('onDeleted before selectedCategoryList size:: ${selectedCategoryList.length}');
                      for (var listItem in businessCategoryList) {
                        if(listItem.name == item){
                          selectedCategoryList.remove(listItem);
                        }
                      }
                      print('onDeleted after selectedCategoryList size:: ${selectedCategoryList.length}');*/
                      /*businessCategoryList.add(item);
                        businessCategoryList.sort((item1, item2) {
                          return item1.index.compareTo(item2.index);
                        });*/
                      showSubjectList = false;
                      setState(() {});
                    },
                    label: Container(
                      alignment: AlignmentDirectional.center,
                      /*height: item.name.length > 16 && item.name.length <= 40
                            ? 55
                            : item.name.length > 40 && item.name.length <= 50
                                ? 80
                                : item.name.length > 50 ? 110 : 30,*/
                      width: width,
                      //width: value + 5,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Text(
                          item,
                          style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          //'Address: 26/1 Brigade Gateway, Dr Rajkumar Rd 22nd Floor, Malleshwaram, Bengaluru, Karnataka 560055',
                          //'sd sdg sgersg rgesrgerge ergehe erhgethb erhrtdhbrtn ethrtnfrnfryn tnrnrnyn',
                          maxLines: 20,
                          softWrap: true,
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  List<Widget> getSelectedSubjectsWidgets(
      List<SelectedCategoryModel> selectedOption, String from) {
    List<Widget> widgets = [];
    for (SelectedCategoryModel item in selectedOption) {
      double width = item.name.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return

                  Padding(
                      padding: const EdgeInsets.only(left: 0,right: 8,top: 5,bottom: 5),
                      child: Container(
                        decoration: BoxDecoration(
                          color: ColorValues.DARK_YELLOW,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8,right: 8,top: 6,bottom: 6),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: InkWell(
                                  onTap: () {
                                    // Handle selection here
                                    print('Selected: ${item.name}');
                                  },
                                  child: Text(
                                    '${item.name}',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                    // maxLines: 1,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 2, left: 3),
                                child: InkWell(
                                  onTap: () {
                                    if (item.name == "Other") {
                                      selectedSubjectOption.remove(item);
                                      isSubjectOtherSelected = false;
                                    } else {
                                      selectedSubjectOption.remove(item);
                                      _mCategoryFormModel
                                          .mainCategoryList[item.mainCategoryIndex]
                                          .subCategoryList[item.subCategoryIndex]
                                          .isSelected = false;

                                      showSubjectList = false;
                                    }
                                    _checkStepOneValidaiton();

                                    setState(() {});
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.white,
                                    size: 16.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));




                Container(
                  margin: EdgeInsets.all(5),
                  child: Chip(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: BorderSide(
                        color: Palette.accentColor,
                      ),
                    ),
                    backgroundColor: Palette.white,
                    deleteIcon: value >= (width)
                        ? Icon(Icons.cancel, color: Palette.accentColor)
                        : Icon(Icons.cancel, color: Palette.accentColor),
                    onDeleted: () {
                      if (item.name == "Other") {
                        selectedSubjectOption.remove(item);
                        isSubjectOtherSelected = false;
                      } else {
                        selectedSubjectOption.remove(item);
                        _mCategoryFormModel
                            .mainCategoryList[item.mainCategoryIndex]
                            .subCategoryList[item.subCategoryIndex]
                            .isSelected = false;

                        showSubjectList = false;
                      }
                      setState(() {});
                    },
                    label: Container(
                      alignment: AlignmentDirectional.center,
                      /*height: item.name.length > 16 && item.name.length <= 40
                            ? 55
                            : item.name.length > 40 && item.name.length <= 50
                                ? 80
                                : item.name.length > 50 ? 110 : 30,*/
                      width: width,
                      //width: value + 5,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Text(
                          item.name,
                          style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          //'Address: 26/1 Brigade Gateway, Dr Rajkumar Rd 22nd Floor, Malleshwaram, Bengaluru, Karnataka 560055',
                          //'sd sdg sgersg rgesrgerge ergehe erhgethb erhrtdhbrtn ethrtnfrnfryn tnrnrnyn',
                          maxLines: 20,
                          softWrap: true,
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  List<Widget> getSelectedQualificationWidgets(
      List<String> selectedOption, String from) {
    List<Widget> widgets = [];
    for (String item in selectedOption) {
      print("Name+++++" + item);
      double width = item.length.toDouble() * 11.25;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return
                  Padding(
                      padding: const EdgeInsets.only(left: 0,right: 8,top: 5,bottom: 5),
                      child: Container(
                        decoration: BoxDecoration(
                          color: ColorValues.DARK_YELLOW,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8,right: 8,top: 6,bottom: 6),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: InkWell(
                                  onTap: () {
                                    // Handle selection here
                                    print('Selected: ${item}');
                                  },
                                  child: Text(
                                    '${item}',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                    // maxLines: 1,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 2, left: 3),
                                child: InkWell(
                                  onTap: () {
                                    // Handle deletion here

                                    if (from == "mainCategory") {
                                      if (qualificationsList.length == 0) {
                                        qualificationsList.insert(
                                            0,
                                            QualificationsModelResult(
                                                qualificationId: -1,
                                                name: 'Select All',
                                                description: 'Select All'));
                                      }
                                      if (item == 'Other') {
                                        setState(() {
                                          isQualificationOtherSelected = false;
                                          selectedQualificationOtherOption.clear();
                                          isShowMoreQualificationOther = true;
                                        });
                                      }
                                      updateQualificationList(item);

                                      setState(() {});
                                    } else {
                                      selectedQualificationOtherOption.remove(item);
                                      selectedQualificationOption.remove(item);
                                      setState(() {});
                                    }

                                    _checkStepOneValidaiton();
                                    showQualificationList = false;
                                    setState(() {});
                                    //updateList(item, index);
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.white,
                                    size: 16.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));

                Container(
                  margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                  child: Chip(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: BorderSide(
                        color: Palette.accentColor,
                      ),
                    ),
                    backgroundColor: Palette.white,
                    deleteIcon: value >= (width)
                        ? Icon(Icons.cancel, color: Palette.accentColor)
                        : Icon(Icons.cancel, color: Palette.accentColor),
                    onDeleted: () {
                      if (from == "mainCategory") {
                        if (qualificationsList.length == 0) {
                          qualificationsList.insert(
                              0,
                              QualificationsModelResult(
                                  qualificationId: -1,
                                  name: 'Select All',
                                  description: 'Select All'));
                        }
                        if (item == 'Other') {
                          setState(() {
                            isQualificationOtherSelected = false;
                            selectedQualificationOtherOption.clear();
                            isShowMoreQualificationOther = true;
                          });
                        }
                        updateQualificationList(item);

                        setState(() {});
                      } else {
                        selectedQualificationOtherOption.remove(item);
                        selectedQualificationOption.remove(item);
                        setState(() {});
                      }

                      /*print('onDeleted before selectedCategoryList size:: ${selectedCategoryList.length}');
                      for (var listItem in businessCategoryList) {
                        if(listItem.name == item){
                          selectedCategoryList.remove(listItem);
                        }
                      }
                      print('onDeleted after selectedCategoryList size:: ${selectedCategoryList.length}');*/
                      /*businessCategoryList.add(item);
                        businessCategoryList.sort((item1, item2) {
                          return item1.index.compareTo(item2.index);
                        });*/
                      showQualificationList = false;
                      setState(() {});
                    },
                    label: Container(
                      alignment: AlignmentDirectional.center,
                      /*height: item.name.length > 16 && item.name.length <= 40
                            ? 55
                            : item.name.length > 40 && item.name.length <= 50
                                ? 80
                                : item.name.length > 50 ? 110 : 30,*/
                      width: width,
                      //width: value + 5,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Text(
                          item,
                          style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          //'Address: 26/1 Brigade Gateway, Dr Rajkumar Rd 22nd Floor, Malleshwaram, Bengaluru, Karnataka 560055',
                          //'sd sdg sgersg rgesrgerge ergehe erhgethb erhrtdhbrtn ethrtnfrnfryn tnrnrnyn',
                          maxLines: 20,
                          softWrap: true,
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }


  selectOtherDesignationTextField() {
    String name = '';
    String help = '';
    //if (selectedDesignationOtherOption.length == 0) {
    name = "Other category";
    help = "Other category";
    // }
    setState(() {
      name;
      help;
    });

    return TextFormField(

      decoration: InputDecoration(

        alignLabelWithHint:true,
        isDense: false,
        filled: false,
        errorMaxLines: 4,
        focusColor: AppConstants.colorStyle.lightBlue,
        errorStyle: AppConstants.txtStyle.labelStyleTextForm,
        counterStyle: AppConstants.txtStyle.counterStyleTextForm,
        fillColor: Colors.transparent,
        labelText: name,
        labelStyle: AppConstants.txtStyle.labelStyleTextForm,
        hintText: "",
        hintStyle: TextStyle(
          color: ColorValues.Withdraw_Button_Border,
          fontFamily: Constant.latoRegular,
        ),

        border: UnderlineInputBorder(
            borderSide: BorderSide(
                color: AppConstants.colorStyle.btnBg, width: 1.0)),
        focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: AppConstants.colorStyle.lightBlue,
                width: 1.0)),
        enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: AppConstants.colorStyle.btnBg, width: 1.0)),
        disabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: AppConstants.colorStyle.btnBg, width: 1.0)),
      ),
      style: _otherDesignationFocus.hasFocus
          ? AppConstants.txtStyle.txtStyleTextForm
          : AppConstants.txtStyle.txtStyleTextFormHGRey,

      controller: designationController,
      onChanged: (value) {},
      textInputAction: TextInputAction.done,
      focusNode: _otherDesignationFocus,
      autocorrect: false,

      onFieldSubmitted: (term) {
        _otherDesignationFocus.unfocus();
        if (designationController.text != null &&
            designationController.text != "") {
          if (!selectedDesignationOtherOption
              .contains(designationController.text)) {
            selectedDesignationOtherOption.add(designationController.text);
          }
        }

        designationController.clear();
      },
      validator: (String arg) {
        if (selectedDesignationOtherOption.length > 0) {
          return null;
        } else {
          return MessageConstant.ENTER_DESIGNATION_VAL_other;
        }
      },
    );
  }

  selectOtherSubjectTextField() {
    String name = '';
    String help = '';
    //if (selectedSubjectOtherOption.length == 0) {
    name = "Other subject";
    help = "Other subject";
    // }
    setState(() {
      name;
      help;
    });
    return
      TextFormField(

        decoration: InputDecoration(

          alignLabelWithHint:true,
          isDense: false,
          filled: false,
          errorMaxLines: 4,
          focusColor: AppConstants.colorStyle.lightBlue,
          errorStyle: AppConstants.txtStyle.labelStyleTextForm,
          counterStyle: AppConstants.txtStyle.counterStyleTextForm,
          fillColor: Colors.transparent,
          labelText: name,
          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
          hintText: "",
          hintStyle: TextStyle(
            color: ColorValues.Withdraw_Button_Border,
            fontFamily: Constant.latoRegular,
          ),

          border: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.lightBlue,
                  width: 1.0)),
          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
          disabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
        ),
        style: _otherSubjectFocus.hasFocus
            ? AppConstants.txtStyle.txtStyleTextForm
            : AppConstants.txtStyle.txtStyleTextFormHGRey,

        controller: subjectController,
        onChanged: (value) {},
        textInputAction: TextInputAction.done,
        focusNode: _otherSubjectFocus,
        autocorrect: false,

        onFieldSubmitted: (term) {
          _otherSubjectFocus.unfocus();
          if (subjectController.text != null && subjectController.text != "") {
            if (!selectedSubjectOtherOption.contains(subjectController.text)) {
              selectedSubjectOtherOption.add(subjectController.text);
            }
          }

          subjectController.clear();
        },
        validator: (String arg) {
          if (selectedSubjectOtherOption.length > 0) {
            return null;
          } else {
            return MessageConstant.ENTER_SUBJECT_VAL_other;
          }
        },
      );

    /*
    TextFormField(
      /*decoration: textFormFieldDecorationWithNoBorders(
          'Other'),*/
      cursorColor: ColorValues.GREY_TEXT_COLOR,
      decoration: textFormFieldDecorationWithHint(
          name, ImagePath.ICON_COMPANY, 23, 23, help),
      controller: subjectController,
      onChanged: (value) {},
      textInputAction: TextInputAction.done,
      focusNode: _otherSubjectFocus,
      autocorrect: false,
      onFieldSubmitted: (term) {
        _otherSubjectFocus.unfocus();
        if (subjectController.text != null && subjectController.text != "") {
          if (!selectedSubjectOtherOption.contains(subjectController.text)) {
            selectedSubjectOtherOption.add(subjectController.text);
          }
        }

        subjectController.clear();
      },
      validator: (String arg) {
        if (selectedSubjectOtherOption.length > 0) {
          return null;
        } else {
          return MessageConstant.ENTER_SUBJECT_VAL_other;
        }
      },
    );

     */

  }

  selectOtherQualificationTextField() {
    String name = '';
    String help = '';
    //if (selectedQualificationOtherOption.length == 0) {
    name = "Other qualifications";
    help = "Other Qualifications";
    // }
    setState(() {
      name;
      help;
    });


    return


      /*CustomFormField(

        textInputType: TextInputType.text,
       // maxLength: TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
        focusNode: _otherQualificationFocus,
        label: 'Other qualification',
        hint: "",
        alignLabelWithHint: true,
        textInputAction: TextInputAction.done,

        //onType: (val) => _checkAccomplishmentsValidation(),
        onSaved: (value) {
          _otherQualificationFocus.unfocus();
          if (qualificationController.text != null &&
              qualificationController.text != "") {
            if (!selectedQualificationOtherOption
                .contains(qualificationController.text)) {
              selectedQualificationOtherOption.add(qualificationController.text);
            }
          }
          //getSelectedCategoryDetail('Other');
          //selectedCategoryList.add(new CategoryModel(SubjectController.text,otherCategoryId, true));
          qualificationController.clear();
        },
        controller: qualificationController,
        validation: (value) {
          // if (selectedQualificationOtherOption.length > 0) {
          //   return null;
          // } else {
          //   return MessageConstant.ENTER_QUALIFICATION_VAL_other;
          // }
          },
      );*/


      TextFormField(
        decoration: InputDecoration(

          alignLabelWithHint:true,
          isDense: false,
          filled: false,
          errorMaxLines: 4,
          focusColor: AppConstants.colorStyle.lightBlue,
          errorStyle: AppConstants.txtStyle.labelStyleTextForm,
          counterStyle: AppConstants.txtStyle.counterStyleTextForm,
          fillColor: Colors.transparent,
          labelText: name,
          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
          hintText: "",
          hintStyle: TextStyle(
            color: ColorValues.Withdraw_Button_Border,
            fontFamily: Constant.latoRegular,
          ),

          border: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.lightBlue,
                  width: 1.0)),
          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
          disabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
        ),
        style: _otherQualificationFocus.hasFocus
            ? AppConstants.txtStyle.txtStyleTextForm
            : AppConstants.txtStyle.txtStyleTextFormHGRey,

        cursorColor: ColorValues.BLUE_COLOR,
        // decoration: textFormFieldDecorationWithHint(
        //    name, ImagePath.ICON_COMPANY, 23, 23, help),
        controller: qualificationController,
        onChanged: (value) {},
        textInputAction: TextInputAction.done,
        focusNode: _otherQualificationFocus,
        autocorrect: false,
        onFieldSubmitted: (term) {
          _otherQualificationFocus.unfocus();
          if (qualificationController.text != null &&
              qualificationController.text != "") {
            if (!selectedQualificationOtherOption
                .contains(qualificationController.text)) {
              selectedQualificationOtherOption.add(qualificationController.text);
            }
          }
          //getSelectedCategoryDetail('Other');
          //selectedCategoryList.add(new CategoryModel(SubjectController.text,otherCategoryId, true));
          qualificationController.clear();
        },
        validator: (String arg) {
          if (selectedQualificationOtherOption.length > 0) {
            return null;
          } else {
            return MessageConstant.ENTER_QUALIFICATION_VAL_other;
          }
        },
      );

  }




  designationCategoryListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showDesignationList
            ? Container(
          height: _mCategoryFormModel.getUnselctedMainSubjectCount() == 0
              ? 0.0
              : _mCategoryFormModel.getUnselctedMainSubjectCount() == 1
              ? 80.0
              : _mCategoryFormModel.getUnselctedMainSubjectCount() ==
              2
              ? 160.0
              : 250.0,
          child:
          Card(
            elevation: 4,
            child: Container(
              padding: _mCategoryFormModel.mainCategoryList.length > 0
                  ? EdgeInsets.all(10)
                  : EdgeInsets.all(0),
              child: AnimatedList(
                key: _listDKey,
                initialItemCount:
                _mCategoryFormModel.mainCategoryList.length,
                shrinkWrap: true,
                itemBuilder: (context, index, animation) {
                  animation = CurvedAnimation(
                      curve: Curves.linear, parent: animation);

                  return (!_mCategoryFormModel
                      .mainCategoryList[index].isSelected)
                      ? _buildDesignationAddedItem(
                      _mCategoryFormModel.mainCategoryList[index],
                      animation,
                      index)
                      :  Container(height: 0.0);
                },
              ),
            ),
          ),
        )
            : Container(),
      ],
    );
  }

  subjectCategoryListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showSubjectList
            ? selectedDesignationOption.length > 0
            ? Container(
          height: _mCategoryFormModel.getUnselctedSubjectCount() == 0
              ? 100.0
              : _mCategoryFormModel.getUnselctedSubjectCount() == 1
              ? 100.0
              : 200.0,
          child: Card(
            elevation: 4,

            child: Container(
              padding: subjectList.length > 0
                  ? EdgeInsets.all(10)
                  : EdgeInsets.all(0),
              child: AnimatedList(
                key: _listSKey,
                initialItemCount: selectedDesignationOption.length,
                shrinkWrap: true,
                itemBuilder: (context, index1, animation) {
                  animation = CurvedAnimation(
                      curve: Curves.linear, parent: animation);
                  return  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [


                      index1 == 0
                          ? _mCategoryFormModel
                          .mainCategoryList[
                      selectedDesignationOption[
                      index1]
                          .index]
                          .subCategoryList
                          .map((v) => v.toJson11())
                          .toString()
                          .contains("false") ||
                          (!isSubjectOtherSelected)
                          ?   InkWell(
                        child:  Container(
                          width: double.infinity,
                          child: Padding(
                            padding:
                            const EdgeInsets.fromLTRB(
                                8.0, 8, 8, 3),
                            child: AnimatedContainer(
                              curve: Curves.easeIn,
                              duration: Duration(
                                  milliseconds: 500),
                              width: MediaQuery.of(context)
                                  .size
                                  .width,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: ColorValues.TAB_BACKGROUND_COLOR,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: ColorValues.BORDER_COLOR_NEW, // Border color
                                    width: 1.0, // Border width
                                  ),
                                ),

                                child: Padding(
                                  padding: const EdgeInsets.all(9.0),
                                  child: Text("Select All",style: TextStyle(
                                      color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 15,
                                      fontFamily: Constant.latoRegular
                                  ),
                                  ),
                                ),

                              ),

                              //  padding: EdgeInsets.all(8),
                            ),
                          ),
                        ),
                        onTap: () {
                          selectedSubjectOption.clear();
                          for (SelectedDesignationModel model
                          in selectedDesignationOption) {
                            var subCategoryList =
                                _mCategoryFormModel
                                    .mainCategoryList[
                                model.index]
                                    .subCategoryList;

                            for (int i = 0;
                            i < subCategoryList.length;
                            i++) {
                              subCategoryList[i]
                                  .isSelected = true;
                              selectedSubjectOption.add(
                                  SelectedCategoryModel(
                                      model.index,
                                      i,
                                      subCategoryList[i]
                                          .name));
                            }
                          }

                          selectedSubjectOption.add(
                              SelectedCategoryModel(
                                  0, 0, "Other"));
                          setState(() {
                            isSubjectOtherSelected = true;
                          });

                          showSubjectList = false;
                          _checkAccomplishmentsValidation();

                          setState(() {});
                        },
                      )
                          :  Container(
                        height: 0.0,
                      )
                          :  Container(
                        height: 0.0,
                      ),


                      _mCategoryFormModel
                          .mainCategoryList[
                      selectedDesignationOption[index1]
                          .index]
                          .subCategoryList
                          .map((v) => v.toJson11())
                          .toString()
                          .contains("false")
                          ? Container(
                        width: double.infinity,
                        // color: Colors.grey[100],
                        child: Padding(
                          padding:  const EdgeInsets.fromLTRB(
                              9.0, 4, 8, 4),
                          child:  Text(
                            _mCategoryFormModel
                                .mainCategoryList[
                            selectedDesignationOption[
                            index1]
                                .index]
                                .name,
                            style:  TextStyle(
                                color:  ColorValues.labelColor,
                                fontWeight: FontWeight.w600,
                                fontSize: 15,
                                fontFamily: Constant.latoRegular),
                          ),
                        ),
                      )
                          :  Container(
                        height: 0.0,
                      ),

                      _buildSubjectAddedItem(
                          _mCategoryFormModel
                              .mainCategoryList[
                          selectedDesignationOption[index1]
                              .index]
                              .subCategoryList,
                          animation,
                          selectedDesignationOption[index1].index),

                      (selectedDesignationOption.length == 1) ?
                      InkWell(
                        child:


                        Padding(
                          padding: const EdgeInsets.fromLTRB(
                              8.0, 3, 8, 3),
                          child: AnimatedContainer(
                            curve: Curves.easeIn,
                            duration: Duration(
                                milliseconds: 500),
                            width: MediaQuery.of(context)
                                .size
                                .width,
                            child: Container(
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: ColorValues.TAB_BACKGROUND_COLOR,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: ColorValues.BORDER_COLOR_NEW, // Border color
                                  width: 1.0, // Border width
                                ),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    5.0, 3, 5, 3),
                                child: AnimatedContainer(
                                  curve: Curves.easeIn,
                                  duration:
                                  Duration(milliseconds: 500),
                                  width: MediaQuery.of(context)
                                      .size
                                      .width,
                                  child: Text("Other",style: TextStyle(
                                      color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 15,
                                      fontFamily: Constant.latoRegular
                                  ),),
                                  padding: EdgeInsets.all(8),
                                ),
                              ),
                            ),

                            //padding: EdgeInsets.all(8),
                          ),
                        ),

                        onTap: () {

                          selectedSubjectOption.add(
                              SelectedCategoryModel(
                                  0, 0, "Other"));
                          setState(() {
                            isSubjectOtherSelected = true;
                          });

                          _checkAccomplishmentsValidation();

                          showSubjectList = false;

                          setState(() {});
                        },
                      )
                          :

                      (selectedDesignationOption.length - 1) ==
                          index1 &&
                          (!isSubjectOtherSelected)
                          ?   InkWell(
                        child:


                        Padding(
                          padding: const EdgeInsets.fromLTRB(
                              8.0, 3, 8, 3),
                          child: AnimatedContainer(
                            curve: Curves.easeIn,
                            duration: Duration(
                                milliseconds: 500),
                            width: MediaQuery.of(context)
                                .size
                                .width,
                            child: Container(
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: ColorValues.TAB_BACKGROUND_COLOR,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: ColorValues.BORDER_COLOR_NEW, // Border color
                                  width: 1.0, // Border width
                                ),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    5.0, 3, 5, 3),
                                child: AnimatedContainer(
                                  curve: Curves.easeIn,
                                  duration:
                                  Duration(milliseconds: 500),
                                  width: MediaQuery.of(context)
                                      .size
                                      .width,
                                  child: Text("Other",style: TextStyle(
                                      color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 15,
                                      fontFamily: Constant.latoRegular
                                  ),),
                                  padding: EdgeInsets.all(8),
                                ),
                              ),
                            ),

                            //padding: EdgeInsets.all(8),
                          ),
                        ),

                        onTap: () {

                          selectedSubjectOption.add(
                              SelectedCategoryModel(
                                  0, 0, "Other"));
                          setState(() {
                            isSubjectOtherSelected = true;
                          });

                          _checkAccomplishmentsValidation();

                          showSubjectList = false;

                          setState(() {});
                        },
                      )
                          :  Container(
                        height: 0.0,
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        )
            : Container()
            : Container(),
      ],
    );
  }

  qualificationCategoryListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showQualificationList
            ? qualificationsList.length > 0
            ? Container(
          height: qualificationsList.length == 1
              ? 90
              : qualificationsList.length == 2
              ? 170
              : 280.0,
          child: Card(
            elevation: 4,

            child: Container(
              padding: qualificationsList.length > 0
                  ? EdgeInsets.all(10)
                  : EdgeInsets.all(0),
              child: AnimatedList(
                key: _listQKey,
                initialItemCount: qualificationsList.length,
                shrinkWrap: true,
                itemBuilder: (context, index, animation) {
                  animation = CurvedAnimation(
                      curve: Curves.linear, parent: animation);

                  return _buildQualificationAddedItem(
                      qualificationsList[index], animation, index);
                },
              ),
            ),
          ),
        )
            : Container()
            : Container(),
      ],
    );
  }


  Widget _buildDesignationAddedItem(
      MainCategory item, Animation animation, int index) {
    return FadeTransition(
      opacity: animation,
      child: SizeTransition(
        axis: Axis.vertical,
        sizeFactor: animation,
        child: InkWell(
          onTap: () {
            //CustomProgressLoader.showLoader(context);
            print("item++++" + item.name);
            //displayPrediction(item.id, item.name, item.index);
            //_removeSingleItems(businessCategoryList.indexOf(item));
            if (_mCategoryFormModel.mainCategoryList[index].name ==
                'Select All') {
              setState(() {
                isDesignationOtherSelected = true;
              });
              for (item in _mCategoryFormModel.mainCategoryList) {
                if (item.name != 'Select All')
                  selectedDesignationOption.add(new SelectedDesignationModel(
                      index, _mCategoryFormModel.mainCategoryList[index].name));
              }
              _mCategoryFormModel.mainCategoryList.clear();

              _checkStepOneValidaiton();

            } else {
              if (_mCategoryFormModel.mainCategoryList[index].name == 'Other') {
                setState(() {
                  isDesignationOtherSelected = true;
                });
              }

              if (_mCategoryFormModel.mainCategoryList[index].name ==
                  'Career') {
                setState(() {
                  isCareerSelected = true;
                });
              }
              _mCategoryFormModel.mainCategoryList[index].isSelected = true;
              selectedDesignationOption.add(new SelectedDesignationModel(
                  index, _mCategoryFormModel.mainCategoryList[index].name));
              if (designationList.length > 0) designationList.removeAt(index);
            }

            showDesignationList = !showDesignationList;
            FocusScope.of(context).requestFocus(FocusNode());
            //searchCountryController.clear();

            //add  _checkAccomplishmentsValidation();
           // _checkAccomplishmentsValidation();
            _checkStepOneValidaiton();

            setState(() {});
            setState(() {
              isDesignationError = false;
              designationBottomViewColor = Palette.dividerColor;
            });
          },
          child: AnimatedContainer(
            curve: Curves.easeIn,
            duration: Duration(milliseconds: 500),
            width: MediaQuery.of(context).size.width,
            child:

            Container(
              decoration: BoxDecoration(
                color: ColorValues.TAB_BACKGROUND_COLOR,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: ColorValues.BORDER_COLOR_NEW, // Border color
                  width: 1.0, // Border width
                ),
              ),

              child: Padding(
                padding: const EdgeInsets.all(9.0),
                child: Text(item.name,style: TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                    fontFamily: Constant.latoRegular
                ),
                ),
              ),

            ),


            padding: EdgeInsets.all(8),
          ),
        ),
      ),
    );
  }

  Widget _buildSubjectAddedItem(
      List<SubCategory> item, Animation animation, index11) {
    return FadeTransition(
      opacity: animation,
      child: SizeTransition(
        axis: Axis.vertical,
        sizeFactor: animation,
        child:  Column(
          children:  List.generate(item.length, (index) {
            return (!item[index].isSelected)
                ? InkWell(
              onTap: () {
                selectedSubjectOption.add(SelectedCategoryModel(
                    index11, index, item[index].name));

                item[index].isSelected = true;
                if (item[index].name == 'Other') {
                  setState(() {
                    isSubjectOtherSelected = true;
                  });
                }
                showSubjectList = false;
                FocusScope.of(context).requestFocus(FocusNode());
                setState(() {});

                _checkStepOneValidaiton();

              },
              child: AnimatedContainer(

                curve: Curves.easeIn,
                duration: Duration(milliseconds: 500),
                width: MediaQuery.of(context).size.width,
                child: Container(
                  decoration: BoxDecoration(
                    color: ColorValues.TAB_BACKGROUND_COLOR,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: ColorValues.BORDER_COLOR_NEW, // Border color
                      width: 1.0, // Border width
                    ),
                  ),

                  child: Padding(
                    padding: const EdgeInsets.all(9.0),
                    child: Text(item[index].name,style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                        fontFamily: Constant.latoRegular
                    ),
                    ),
                  ),

                ),
                padding: EdgeInsets.all(8),
              ),
            )
                :  Container(
              height: 0.0,
            );
          }),
        ),
      ),
    );
  }

  Widget _buildQualificationAddedItem(
      QualificationsModelResult item, Animation animation, int index) {
    return FadeTransition(
      opacity: animation,
      child: SizeTransition(
        axis: Axis.vertical,
        sizeFactor: animation,
        child: InkWell(
          onTap: () {
            //CustomProgressLoader.showLoader(context);
            print("item++++" + item.name);
            //displayPrediction(item.id, item.name, item.index);
            //_removeSingleItems(businessCategoryList.indexOf(item));
            if (qualificationsList[index].name == 'Select All') {
              //if(qualificationsList.contains("Other")){
              setState(() {
                isQualificationOtherSelected = true;
              });
              //}
              for (item in qualificationsList) {
                if (item.name != 'Select All')
                  selectedQualificationOption.add(item.name);
                removedQualificationList.add(item);
              }
              qualificationsList.clear();
            } else {
              if (qualificationsList[index].name == 'Other') {
                setState(() {
                  isQualificationOtherSelected = true;
                });
              }
              removedQualificationList.add(qualificationsList[index]);

              selectedQualificationOption.add(qualificationsList[index].name);
              if (qualificationsList.length > 0)
                qualificationsList.removeAt(index);

            }
            FocusScope.of(context).requestFocus(FocusNode());
            showQualificationList = !showQualificationList;
            //searchCountryController.clear();

            //add _checkAccomplishmentsValidation();


            setState(() {});
            setState(() {
              isQualificationError = false;
              qualificationBottomViewColor = Palette.dividerColor;
            });

            _checkStepOneValidaiton();


            //  _checkAccomplishmentsValidation();

          },
          child: AnimatedContainer(
            curve: Curves.easeIn,
            duration: Duration(milliseconds: 500),
            width: MediaQuery.of(context).size.width,
            child:
            Container(
              decoration: BoxDecoration(
                color: ColorValues.TAB_BACKGROUND_COLOR,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: ColorValues.BORDER_COLOR_NEW, // Border color
                  width: 1.0, // Border width
                ),
              ),

              child: Padding(
                padding: const EdgeInsets.all(9.0),
                child: Text(item.name,style: TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                    fontFamily: Constant.latoRegular
                ),
                ),
              ),

            ),

            padding: EdgeInsets.all(8),
          ),
        ),
      ),
    );
  }


  void updateDesignationList(String item) {
    print('inside updateList');
    for (var removeitem in removedDesignationList) {
      print('inside updateList removeitem name:: ${removeitem.name}');
      if (item == removeitem.name) {
        print('update this inside name:: ${removeitem.name}');
        designationList.add(removeitem);
        removedDesignationList.remove(removeitem);
        selectedDesignationOption.remove(item);
      }
    }
    _checkStepOneValidaiton();

    setState(() {});
  }

  void updateSubjectList(String item) {
    print('inside updateList');
    for (var removeitem in removedSubjectList) {
      print('inside updateList removeitem name:: ${removeitem.name}');
      if (item == removeitem.name) {
        print('update this inside name:: ${removeitem.name}');
        subjectList.add(removeitem);
        removedSubjectList.remove(removeitem);
        selectedSubjectOption.remove(item);
      }
    }
    _checkStepOneValidaiton();

    setState(() {});
  }

  void updateQualificationList(String item) {
    print('inside updateList');
    for (var removeitem in removedQualificationList) {
      print('inside updateList removeitem name:: ${removeitem.name}');
      if (item == removeitem.name) {
        print('update this inside name:: ${removeitem.name}');
        qualificationsList.add(removeitem);
        removedQualificationList.remove(removeitem);
        selectedQualificationOption.remove(item);
      }
    }
    setState(() {});
  }

  void getSelectedDesignationDetail() {
    print('getSelectedDesignationDetail() ');
    selectedDesignationList.clear();
    for (var selectedItem in selectedDesignationOption) {
      for (var item in orignalDesignationList) {
        if (item.name == selectedItem) {
          //CategoryResult categoryResult = ;
          if (selectedItem != 'Other') {
            DesignationModelParam categoryModel =  DesignationModelParam(
                name: item.name, categoryId: item.categoryId, isOther: false);
            selectedDesignationList.add(categoryModel);
          } else {
            for (var option in selectedDesignationOtherOption) {
              DesignationModelParam categoryModel =  DesignationModelParam(
                  name: option, categoryId: item.categoryId, isOther: true);
              selectedDesignationList.add(categoryModel);
            }
          }
        }
      }
    }
  }

  void getSelectedSubjectDetail() {
    print('getSelectedSubjectDetail() ');
    selectedSubjectList.clear();
    for (var selectedItem in selectedSubjectOption) {
      for (var item in orignalSubjectList) {
        if (item.name == selectedItem) {
          //CategoryResult categoryResult = ;
          if (selectedItem != 'Other') {
            SubjectModelParam categoryModel =  SubjectModelParam(
                name: item.name, subjectId: item.subjectId, isOther: false);
            selectedSubjectList.add(categoryModel);
          } else {
            for (var option in selectedSubjectOtherOption) {
              SubjectModelParam categoryModel =  SubjectModelParam(
                  name: option, subjectId: item.subjectId, isOther: true);
              selectedSubjectList.add(categoryModel);
            }
          }
        }
      }
    }
  }

  void getSelectedUserImageDetail() {
    print('getSelectedUserImageDetail() ');
    selecteduserImageData.clear();
    /*for (var selectedItem in mentorImagesList) {
      selecteduserImageData.add(UserImageModelParam(file: selectedItem));
    }*/
    for (int i = 0; i < mentorImagesList.length; i++) {
      // if (0 == i) {
      // } else {
        selecteduserImageData
            .add(UserImageModelParam(file: mentorImagesList[i]));
     // }
    }
  }

  void getSelectedQualificationDetail() {
    print('getSelectedQualificationDetail() ');
    selectedQualificationList.clear();
    for (var selectedItem in selectedQualificationOption) {
      for (var item in orignalQualificationList) {
        if (item.name == selectedItem) {
          //CategoryResult categoryResult = ;
          if (selectedItem != 'Other') {
            QualificationModelParam categoryModel =  QualificationModelParam(
                name: item.name,
                qualificationId: item.qualificationId,
                isOther: false);
            selectedQualificationList.add(categoryModel);
          } else {
            for (var option in selectedQualificationOtherOption) {
              QualificationModelParam categoryModel =
                   QualificationModelParam(
                      name: option,
                      qualificationId: item.qualificationId,
                      isOther: true);
              selectedQualificationList.add(categoryModel);
            }
          }
        }
      }
    }
  }

  void getScheduleData() {
    selectedDayData.clear();
    try {
      for (var item in listData) {
        if (item.isSelect) {
          List<HoursData> hoursList =  List();
          for (var itemHour in item.dayScheduleData) {
            hoursList.add(HoursData(
                timeFrom: (dateFormat.parse(itemHour.fromTime))
                    .millisecondsSinceEpoch,
                timeTo: (dateFormat.parse(itemHour.toTime))
                    .millisecondsSinceEpoch));


            List<String> country = [];
            for (int i = 0; i < hoursList.length; i++) {
              country.add(hoursList[i].timeFrom.toString() +
                  hoursList[i].timeTo.toString());
            }

            List DupCountry = [];
            country.forEach((dup){
              if(DupCountry.contains(dup)){
                print("Duplicate in List= ${dup}");
                print("Duplicate in List= ${item.dayName}");
                if(item.dayName=="Monday"){
                  setState(() {
                    listData[0].duplicateValue= true;
                  });

                }else if(item.dayName=="Tuesday"){
                  setState(() {
                    listData[1].duplicateValue= true;
                  });

                }else if(item.dayName=="Wednesday"){
                  setState(() {
                    listData[2].duplicateValue= true;
                  });

                }else if(item.dayName=="Thursday"){
                  setState(() {
                    listData[3].duplicateValue= true;
                  });

                }else if(item.dayName=="Friday"){
                  setState(() {
                    listData[4].duplicateValue= true;
                  });

                }else if(item.dayName=="Saturday"){
                  setState(() {
                    listData[5].duplicateValue= true;
                  });

                }else if(item.dayName=="Sunday"){
                  setState(() {
                    listData[6].duplicateValue= true;
                  });
                }
              }
              else{
                DupCountry.add(dup);
              }
            });

          }
          selectedDayData
              .add(ScheduleModelParam(day: item.dayName, hours: hoursList));
          print('hoursList size::: ${hoursList.length}');
        }
      }
    } catch (e) {
      setState(() {
        _showAvailablityError = true ;
      });
     // ToastWrap.showToast(MessageConstant.SELECT_DAY_VAL, context);
    }
    print('selectedDayData size::: ${selectedDayData.length}');
  }

  bool isTimeSlotSelected() {
    for (var item in listData) {
      for (var hours in item.dayScheduleData) {
        if (hours.timeTo != 0 && hours.timeFrom != 0) {
          if (!isAtleastOneTimeSlotSelected) {
            isAtleastOneTimeSlotSelected = true;
            return isAtleastOneTimeSlotSelected;
          }
        }
      }
    }
    return isAtleastOneTimeSlotSelected;
  }

  Widget menteeSopport() {
    return Padding(
      padding: EdgeInsets.only(
        right: UIHelper.screenPadding,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          FormField<String>(
            builder: (FormFieldState<String> state) {
              return InputDecorator(
                decoration: InputDecoration(
                  labelText: 'Advisor Support Offered',
                  alignLabelWithHint: true,
                  hintStyle: AppTextStyle.getDynamicFontStyle(
                      Palette.secondaryTextColor, 14, FontType.Regular),
                  labelStyle: AppTextStyle.getDynamicFontStyle(
                      Palette.secondaryTextColor, 16, FontType.Regular),
                  enabledBorder: UnderlineInputBorder(
                    borderSide:
                        BorderSide(color: menteeBottomViewColor, width: 1.0),
                  ),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: selectAdvisorSupportOffered,
                    isDense: true,
                    icon:  Image.asset(
                      "assets/newDesignIcon/patner/down_arrow.png",
                      width: 14.0,
                      height: 7.0,
                    ),
                    onChanged: (String newValue) async {
                      setState(() {
                        selectAdvisorSupportOffered = newValue;
                        state.didChange(newValue);
                      });
                    },
                    items: advisorSupportOfferedList.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                          style: textFormFieldValueStyle(),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              );
            },
          ),
          isMenteeError
              ? Padding(
                  padding: const EdgeInsets.only(top: 6.0),
                  child: Text(
                    '${MessageConstant.ENTER_MENTEE_VAL}',
                    style: AppTextStyle.getDynamicFontStyle(
                        //Palette.redColor,
                        Colors.red[700],
                        12,
                        FontType.Regular),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }

  setData() async {
    setState(() {
      isMediaExpanded = true;
      bioController.text = widget.opportunityModel.bio;
      feesController.text = widget.opportunityModel.fees;
      //projectAreasController.text = widget.opportunityModel.projectAreas;
      jobTitleController.text = widget.opportunityModel.jobTitle;
      descriptionController.text = widget.opportunityModel.description;
      //selectAdvisorSupportOffered = widget.opportunityModel.supportOffered;
      if (widget.type == "edit") {
        print("age++++++++++" +
            Util.getConvertedDateStamp(widget.opportunityModel.toDate));
        ageFromController = TextEditingController(
            text: Util.getConvertedDateStamp(widget.opportunityModel.fromDate));
        ageToController = TextEditingController(
            text: Util.getConvertedDateStamp(widget.opportunityModel.toDate));
        expiryDateController = TextEditingController(
            text:
                Util.getConvertedDateStamp(widget.opportunityModel.expiresOn));
        toDate = widget.opportunityModel.toDate == "null" ||
                widget.opportunityModel.toDate == ""
            ?  DateTime.now()
            :  DateTime.fromMillisecondsSinceEpoch(
                int.parse(widget.opportunityModel.toDate));

        dateFrom = int.parse(widget.opportunityModel.fromDate);
        dateTo = int.parse(widget.opportunityModel.toDate);
        expiryDate = int.parse(widget.opportunityModel.expiresOn);
      }
      for (UserImageModelParam assest
          in widget.opportunityModel.userImageModelParam) {
        mentorImagesList.add(assest.file);
      }

      _mTimeZoneValue = widget.opportunityModel.timeZone;
      _mTimeZoneHintValue = widget.opportunityModel.timeZone;
      for (var item1 in widget.opportunityModel.scheduleModelParam) {
        for (var item in listData) {
          if (item.dayName == item1.day) {
            item.isSelect = true;

            var timeTo =
                Util.getConvertedTimeForScheduleDate(item1.hours[0].timeTo);
            var timeFrom =
                Util.getConvertedTimeForScheduleDate(item1.hours[0].timeFrom);

            item.dayScheduleData[0].startTimeController.text = timeTo;
            item.dayScheduleData[0].endTimeController.text = timeFrom;
            item.dayScheduleData[0].fromTime = timeFrom;
            item.dayScheduleData[0].toTime = timeTo;
            item.dayScheduleData[0].timeTo = item1.hours[0].timeTo;
            item.dayScheduleData[0].timeFrom = item1.hours[0].timeFrom;
            if (item1.hours.length > 1) {
              for (int i = 1; i < item1.hours.length; i++) {
                var timeTo =
                    Util.getConvertedTimeForScheduleDate(item1.hours[i].timeTo);
                var timeFrom = Util.getConvertedTimeForScheduleDate(
                    item1.hours[i].timeFrom);

                item.dayScheduleData.add(DayScheduleData(
                    toTime: timeTo,
                    fromTime: timeFrom,
                    timeTo: item1.hours[i].timeTo,
                    timeFrom: item1.hours[i].timeFrom,
                    startTimeController:
                         TextEditingController(text: timeTo),
                    endTimeController:
                         TextEditingController(text: timeFrom)));
              }
            }
          }
        }
      }

      for (DesignationModelParam modal
          in widget.opportunityModel.designationModelParam) {
        print("modaldata+++++" + modal.name);
        for (int i = 0; i < _mCategoryFormModel.mainCategoryList.length; i++) {
          if (modal.name == _mCategoryFormModel.mainCategoryList[i].name ||
              (_mCategoryFormModel.mainCategoryList[i].name == "other" &&
                  widget.opportunityModel.otherCategoryList.length > 0)) {
            if (widget.opportunityModel.otherCategoryList.length > 0) {
              for (OtherCategory _mOtherCategory
                  in widget.opportunityModel.otherCategoryList) {
                selectedDesignationOtherOption.add(_mOtherCategory.name);
              }

              setState(() {
                isDesignationOtherSelected = true;
              });
            }
            if (modal.name == _mCategoryFormModel.mainCategoryList[i].name) {
              print("SubModal+++++" +
                  widget.opportunityModel.subjectModelParam.length.toString());
              for (SubjectModelParam subModal
                  in widget.opportunityModel.subjectModelParam) {
                print("SubModal+++++" + subModal.name);
                for (int j = 0;
                    j <
                        _mCategoryFormModel
                            .mainCategoryList[i].subCategoryList.length;
                    j++) {
                  if (subModal.name ==
                      _mCategoryFormModel
                          .mainCategoryList[i].subCategoryList[j].name) {
                    _mCategoryFormModel.mainCategoryList[i].subCategoryList[j]
                        .isSelected = true;

                    selectedSubjectOption
                        .add(SelectedCategoryModel(i, j, subModal.name));

                    /*  if(subModal.name=="Other"){
                      for (OtherCategory _mOtherCategory
                      in widget.opportunityModel.otherSubjectList) {
                        selectedSubjectOtherOption.add(_mOtherCategory.name);
                      }
                      setState(() {
                        isSubjectOtherSelected = true;
                      });
                    }*/
                  }
                }
              }
            }

            if (_mCategoryFormModel.mainCategoryList[i].name == 'Career') {
              for (OtherCategory _mOtherCategory
                  in widget.opportunityModel.otherCareerList) {
                selectedDesignationCareerOption.add(_mOtherCategory.name);
              }
              setState(() {
                isCareerSelected = true;
              });
            }
            _mCategoryFormModel.mainCategoryList[i].isSelected = true;
            selectedDesignationOption.add(SelectedDesignationModel(
                i, _mCategoryFormModel.mainCategoryList[i].name));
          }
        }
      }

      if (widget.opportunityModel.otherSubjectList.length > 0) {
        for (OtherCategory _mOtherCategory
            in widget.opportunityModel.otherSubjectList) {
          selectedSubjectOtherOption.add(_mOtherCategory.name);
        }
        setState(() {
          isSubjectOtherSelected = true;
        });

        selectedSubjectOption.add(SelectedCategoryModel(0, 0, "Other"));
      }

      ////////////----------- previous data-------------below is same as previous
      durationController.text = widget.opportunityModel.duration;
      statusController.text = widget.opportunityModel.status;
      titleController.text = widget.opportunityModel.title;
      isGroupPublic = widget.opportunityModel.groupIsPublic;

      if (widget.opportunityModel.ageList.length > 0) {
        toFromAge = widget.opportunityModel.ageList;

        for (int i = 0; i < widget.opportunityModel.ageList.length; i++) {
          toFromAge[i].ageYearFrom.text =
          "${toFromAge[i].fromAge} - ${toFromAge[i].toAge}";
        }
      } else {
        toFromAge.add(AgeBetween(toAge: 0, fromAge: 0));
      }

      if (widget.opportunityModel.locationList != null)
        for (int i = 0; i < widget.opportunityModel.locationList.length; i++) {
          selectedCountries.add(new Item(
              1,
              widget.opportunityModel.locationList[i].street1,
              "1",
              widget.opportunityModel.locationList[i].state,
              widget.opportunityModel.locationList[i].country,
              widget.opportunityModel.locationList[i].city,
              widget.opportunityModel.locationList[i].zip));
          selectedLocation = widget.opportunityModel.locationList[i].target;
        }
      setState(() {
        selectedLocation;
      });
//this.index, this.name, this.id,this.state,this.country,this.city,this.zipcode
      selectedIntrestDataList.addAll(widget.opportunityModel.interestType);
      for (CompetencyModel model in listCompetency) {
        model.isSelected = false;
        for (Level2Competencies level2 in model.level2Competencylist) {
          level2.isSelected = false;
        }
      }
      if (widget.opportunityModel.interestType.length > 0) {
        for (CompetencyModel model in listCompetency) {
          for (Level2Competencies level2 in model.level2Competencylist) {
            for (IntrestModel intrest in widget.opportunityModel.interestType) {
              if (intrest.name == level2.name && intrest.id == level2.competencyTypeId ) {
                level2.isSelected = true;
                break;
              }
            }
          }
        }
      }

      if (widget.opportunityModel.gender.toLowerCase() == "" ||
          widget.opportunityModel.gender.toLowerCase() == "null") {
        selectedGender = "Male";
      } else {
        selectedGender = _genderArray.firstWhere((test) {
          return widget.opportunityModel.gender.toLowerCase() ==
              test.toLowerCase();
        });
      }

/*      if (widget.opportunityModel.fromDate != "" ||
          widget.opportunityModel.fromDate != null) {
        fromDate =  DateTime.fromMillisecondsSinceEpoch(
            int.parse(widget.opportunityModel.fromDate));
        dateFrom = fromDate.millisecondsSinceEpoch;
        ageFromController.text = Util.getDate(fromDate);
      } else {
        fromDate =  DateTime.now();
        dateFrom = fromDate.millisecondsSinceEpoch;
        ageFromController.text = Util.getDate(fromDate);
      }

      if (widget.opportunityModel.toDate != "" || widget.opportunityModel.toDate != null) {
        toDate =  DateTime.fromMillisecondsSinceEpoch(
            int.parse(widget.opportunityModel.toDate));
        dateTo = toDate.millisecondsSinceEpoch;
        ageToController.text = Util.getDate(toDate);
      } else {
        toDate =  DateTime.now();
        dateTo = toDate.millisecondsSinceEpoch;
        ageToController.text = Util.getDate(toDate);
      }
      if (widget.opportunityModel.toDate != "" || widget.opportunityModel.toDate != null) {
        DateTime expiry =  DateTime.fromMillisecondsSinceEpoch(
            int.parse(widget.opportunityModel.expiresOn));
        expiryDate = expiry.millisecondsSinceEpoch;
        expiryDateController.text = Util.getDate(expiry);
      } else {
        DateTime expiry =  DateTime.now();
        expiryDate = expiry.millisecondsSinceEpoch;
        expiryDateController.text = Util.getDate(expiry);
      }*/

      isTargetAudience = widget.opportunityModel.targetAudience == 'true';

      if (widget.opportunityModel.actionType == Constant.LINK_URL) {
        selectedAction = "Link URL";


        if (widget.opportunityModel.linkUrlPosition == "1") {
          learnMore = true;
          selectedLink = widget.opportunityModel.urlLinkForLearn;
          linkUrlController.text = selectedLink;
          selectedUrlOption = "Learn more";

        } else if (widget.opportunityModel.linkUrlPosition == "2") {
          selectedOfferLink = widget.opportunityModel.urlLinkForLearn;
          getOffer = true;
          linkUrlController.text = selectedOfferLink;
          selectedUrlOption = "Get offer";


        } else if (widget.opportunityModel.linkUrlPosition == "3") {
          selectedApplyNowLink = widget.opportunityModel.urlLinkForLearn;
          applyNow = true;
          linkUrlController.text = selectedApplyNowLink;
          selectedUrlOption = "Apply now";

        }
      } else if (widget.opportunityModel.actionType == Constant.JOIN_GROUP) {
        selectedAction = "Join Group";
        isActionSelected = true;
        selectedGroupId = widget.opportunityModel.groupIdAction;
        selectedGroup = widget.opportunityModel.groupName == "null"
            ? selectedGroupId
            : widget.opportunityModel.groupName;

        chooseExistingGroup = true;
      } else if (widget.opportunityModel.actionType == Constant.CALL_NOW) {
        selectedAction = "Call Now";
        isActionSelected = true;
        selectedPhoneNumber = widget.opportunityModel.callingNumber;
      } else {
        selectedAction = "Inquire Now";
      }
      for (Assest assest in widget.opportunityModel.mediaList) {
        mediaImagesList.add(assest.file);
      }
      for (Assest assest in widget.opportunityModel.docList) {
        mediaDocumentList.add(assest.file);
      }

      /* for (Assest assest in widget.opportunityModel.googleLinkList) {
        googleDoclinkList.add(assest.file);
      }*/

      if (widget.opportunityModel.googleLinkList.length > 0) {
        for (Assest assest in widget.opportunityModel.googleLinkList) {
          linkUrlListData.add(LinkUrlModel(
            labelController:  TextEditingController(text: assest.label),
            urlController:  TextEditingController(text: assest.file),
            descController:
            TextEditingController(text: assest.description),
          ));
        }
      } else {
        // linkUrlListData.add(LinkUrlModel(
        //     labelController:  TextEditingController(),
        //     urlController:  TextEditingController(),
        //     descController:  TextEditingController()));
      }

      _checkStepOneValidaiton();
    });
    await getData();
    //  await getDesignationData();
    // await getSubjectData();
    await getQualificationData();

    setState(() {
      mediaVideosList;

      //Designation
      orignalDesignationList;
      removedDesignationList;
      selectedDesignationList;
      designationList;
      selectedDesignationOption;
      selectedDesignationOtherOption;

      //Subject
      orignalSubjectList;
      removedSubjectList;
      selectedSubjectList;
      subjectList;
      selectedSubjectOption;
      selectedSubjectOtherOption;

      //Qualification
      orignalQualificationList;
      removedQualificationList;
      selectedQualificationList;
      qualificationsList;
      selectedQualificationOption;
      selectedQualificationOtherOption;
    });

    _checkStepOneValidaiton();

  }

  getData() async {
    for (Assest assest in widget.opportunityModel.videoList) {
      final thumbnailFile = await uploadMedia
          .getVideoThumbnailFromUrl(Constant.IMAGE_PATH + assest.file);

      mediaVideosList.add(new FileModel(thumbnailFile, assest.file));
    }
  }

  getQualificationData() async {
    print('inside getQualificationData()');
    if (widget.opportunityModel.qualificationModelParam != null &&
        widget.opportunityModel.qualificationModelParam.length > 0) {
      bool first = true;
      for (var categoryModel
          in widget.opportunityModel.qualificationModelParam) {
        print('categoryModel:::::: ${categoryModel.name}');

        selectedQualificationList.add(categoryModel);

        if (categoryModel.isOther) {
          selectedQualificationOtherOption.add(categoryModel.name);
          if (first) {
            print('first::: $first');
            selectedQualificationOption.add("Other");
            removedQualificationList.add(QualificationsModelResult(
                qualificationId: categoryModel.qualificationId,
                name: "Other",
                description: "Other"));
            first = false;
          }
          isQualificationOtherSelected = true;
        } else {
          selectedQualificationOption.add(categoryModel.name);
          removedQualificationList.add(QualificationsModelResult(
              qualificationId: categoryModel.qualificationId,
              name: categoryModel.name,
              description: categoryModel.name));
        }
      }

      if (removedQualificationList.length > 0) {
        qualificationsList.clear();
      }

      for (final e in orignalQualificationList) {
        bool found = false;
        for (final f in removedQualificationList) {
          if (e.qualificationId == f.qualificationId) {
            found = true;
            break;
          }
        }
        if (!found) {
          qualificationsList.add(e);
        }
      }

      if (qualificationsList.length > 0) {
        qualificationsList.insert(
            0,
            QualificationsModelResult(
                qualificationId: -1,
                name: 'Select All',
                description: 'Select All'));
      }
    } else {
      print(
          'inside else widget.opportunityModel.QualificationModelParam size:: ${widget.opportunityModel.qualificationModelParam.length}');
      print('inside else no category selected');
    }
    setState(() {});
  }

  Future apiCallForDeleteOppo() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "opportunityId":
              widget.opportunityModel.opportunityId /*, "roleId": roleId*/
        };
        print("map++++" + map.toString());
        Response response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_OPPORTUNITY_DELETE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              Navigator.pop(context, "push");
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  void generateChipsForOther() {
    //create chip for that
    print('inside generateChipsForOther() for chip creation');
    if (designationController.text != null &&
        designationController.text != "") {
      if (!selectedDesignationOtherOption
          .contains(designationController.text)) {
        selectedDesignationOtherOption.add(designationController.text);
      }
      designationController.clear();
    }
    if (subjectController.text != null && subjectController.text != "") {
      if (!selectedSubjectOtherOption.contains(subjectController.text)) {
        selectedSubjectOtherOption.add(subjectController.text);
      }
      subjectController.clear();
    }

    if (qualificationController.text != null &&
        qualificationController.text != "") {
      if (!selectedQualificationOtherOption
          .contains(qualificationController.text)) {
        selectedQualificationOtherOption.add(qualificationController.text);
      }
      qualificationController.clear();
    }
  }
}
