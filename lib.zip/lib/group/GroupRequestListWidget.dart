import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/InviteMember.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

class GroupRequestListWidget extends StatefulWidget {
  String groupId, roleId;
  String userIdPref, userProfilePath;
  GroupDetailModel modell;
  List<MemberModelDetail> requestedList;

  GroupRequestListWidget(this.groupId, this.userIdPref, this.roleId,
      this.requestedList, this.modell);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    // ignore: return_of_invalid_type
    return GroupRequestListWidgetState();
  }
}

class GroupRequestListWidgetState extends State<GroupRequestListWidget> {
  BuildContext context;
  SharedPreferences prefs;
  int item = 0;
  String isPerformChanges = "pop", roleId, searchName = "";
 bool isLoading=true;
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    roleId = prefs.getString(UserPreference.ROLE_ID);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getSharedPreferences();
  }

  // -------------------  API ------------------------------

  Future apiCalling(memberId, index, type) async {
    try {
      print("memberId" + memberId);
      print("groupid" + widget.groupId);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(memberId),
          "status": type,
          "isAdmin": false,
          "roleId": int.parse(widget.requestedList[index].roleId)
        };

        print("map++++" + map.toString());
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADMIN_UPDATED_GROUP_REQUEST, map);
        CustomProgressLoader.cancelLoader(context);
        setState(() {
          isLoading=false;
        });
        print("response accept++++:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //  ToastWrap.showToast(msg);

              widget.requestedList.removeAt(index);
              setState(() {
                isPerformChanges = "push";
              });
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == widget.userIdPref) {
      } else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }

    Widget getListview(memberModelDetail, index, bool isSentRequest) {
      setState(() {
        item++;
      });

      return InkWell(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
          child: Column(
            children: [
              Row(
                children: <Widget>[



                  Expanded(
                    child: ProfileImageView(
                      imagePath:Constant
                          .IMAGE_PATH_SMALL +
                          ParseJson.getSmallImage(
                              memberModelDetail.profilePicture) ,
                      placeHolderImage:'assets/profile/user_on_user.png',
                      height: 48.0,
                      width: 48.0,
                      onTap: () async{
                        onTapImageTile(memberModelDetail.userId,
                            memberModelDetail.roleId);
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        0.0,
                        0.0,
                        0.0,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: BaseText(
                                    text:         memberModelDetail.firstName ==
                                        null ||
                                        memberModelDetail
                                            .firstName ==
                                            "null" ||
                                        memberModelDetail
                                            .firstName ==
                                            "" ||
                                        memberModelDetail
                                            .firstName ==
                                            "NA"
                                        ? memberModelDetail.email
                                        : memberModelDetail.lastName ==
                                        null ||
                                        memberModelDetail
                                            .lastName ==
                                            "null" ||
                                        memberModelDetail
                                            .lastName ==
                                            ""
                                        ? memberModelDetail
                                        .firstName
                                        : memberModelDetail
                                        .firstName +
                                        " " +
                                        memberModelDetail
                                            .lastName,
                                    textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                    maxLines: 1,
                                    textAlign: TextAlign.start,
                                  ),
                                  flex: 0,
                                ),
                                Expanded(
                                  flex: 0,
                                  child: memberModelDetail.roleId == "1"
                                      ? Util.getStudentBadge12(
                                      memberModelDetail.badge,
                                      memberModelDetail.badgeImage)
                                      : Container(),
                                ),
                              ],
                            ),
                            memberModelDetail.tagline == null ||
                                memberModelDetail.tagline == "null" ||
                                memberModelDetail.tagline == ""
                                ? new Container(
                              height: 0.0,
                            )
                                : Padding(
                              padding:
                              const EdgeInsets.only(top: 4.0, bottom: 5),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: TextViewWrap.textView(
                                      memberModelDetail.tagline,
                                      TextAlign.start,
                                      ColorValues.GREY_TEXT_COLOR,
                                      12.0,
                                      FontWeight.normal,
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        )),
                    flex: 1,
                  ),
                  Expanded(
                    child: Row(
                      children: <Widget>[
                        isSentRequest
                            ? Text("")
                            : ButtonView(
                          btnName: 'Accept',
                          borderColor:
                          AppConstants.colorStyle.lightBlue,
                          bgColor:
                          AppConstants.colorStyle.box_bg_color,
                          txtColor: AppConstants.colorStyle.lightBlue,
                          onButtonTap: () {
                            apiCalling(
                                memberModelDetail.userId,
                                index,
                                MessageConstant.ABOUT_GROUP_ACCEPTED);
                          },
                        ),
                        InkWell(
                          child: Padding(
                              padding:
                              EdgeInsets.fromLTRB(7.0, 0.0, 0.0, 0.0),
                              child: Container(
                                  height: 23.0,
                                  width: 23.0,
                                  child: Image.asset(
                                    'assets/png/cancel_circle.png',
                                  ))),
                          onTap: () {
                            apiCalling(memberModelDetail.userId, index,
                                MessageConstant.ABOUT_GROUP_REJECTED);
                          },
                        )
                      ],
                    ),
                    flex: 0,
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16.0, bottom: 8),
                child: Container(
                  height: 1,
                  color: AppConstants.colorStyle.btnBg,
                ),
              )
            ],
          ),
        ),
        onTap: () {},
      );


      return Container(
          padding: EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 0.0),
          child: Card(
              elevation: 0.0,
              child: Column(
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[




                      Expanded(
                        child:   ProfileImageView(
                          imagePath:Constant
                              .IMAGE_PATH_SMALL +
                              ParseJson.getSmallImage(
                                  memberModelDetail.profilePicture) ,
                          placeHolderImage:'assets/profile/user_on_user.png',
                          height: 48.0,
                          width: 48.0,
                          onTap: () async{
                            onTapImageTile(memberModelDetail.userId,
                                memberModelDetail.roleId);
                          },
                        ),
                        flex: 0,
                      ),
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            0.0,
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: BaseText(
                                        text:
                                            memberModelDetail.firstName ==
                                                        null ||
                                                    memberModelDetail
                                                            .firstName ==
                                                        "null" ||
                                                    memberModelDetail
                                                            .firstName ==
                                                        "" ||
                                                    memberModelDetail
                                                            .firstName ==
                                                        "NA"
                                                ? memberModelDetail.email
                                                : memberModelDetail.lastName ==
                                                            null ||
                                                        memberModelDetail
                                                                .lastName ==
                                                            "null" ||
                                                        memberModelDetail
                                                                .lastName ==
                                                            ""
                                                    ? memberModelDetail
                                                        .firstName
                                                    : memberModelDetail
                                                            .firstName +
                                                        " " +
                                                        memberModelDetail
                                                            .lastName,
                                        textColor: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                        textAlign: TextAlign.start,
                                        maxLines: 3,
                                      ),
                                      flex: 0,
                                    ),
                                    Expanded(
                                      flex: 0,
                                      child: memberModelDetail.roleId == "1"
                                          ? Util.getStudentBadge12(
                                              memberModelDetail.badge,
                                              memberModelDetail.badgeImage)
                                          : Container(),
                                    ),
                                  ],
                                ),
                                memberModelDetail.tagline == null ||
                                        memberModelDetail.tagline == "null" ||
                                        memberModelDetail.tagline == ""
                                    ? new Container(
                                        height: 0.0,
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.only(
                                            top: 4.0, bottom: 5),
                                        child: BaseText(
                                          text: memberModelDetail.tagline ==
                                                      null ||
                                                  memberModelDetail.tagline ==
                                                      "null" ||
                                                  memberModelDetail.tagline ==
                                                      ""
                                              ? ""
                                              : memberModelDetail.tagline,
                                          textColor: AppConstants
                                              .colorStyle.lightPurple,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14,
                                          textAlign: TextAlign.start,
                                          maxLines: 3,
                                        ))
                              ],
                            )),
                        flex: 1,
                      ),
                      Expanded(
                        child: Row(
                          children: <Widget>[
                            isSentRequest
                                ? Text("")
                                : ButtonView(
                                    btnName: 'Accept',
                                    borderColor:
                                        AppConstants.colorStyle.lightBlue,
                                    bgColor:
                                        AppConstants.colorStyle.box_bg_color,
                                    txtColor: AppConstants.colorStyle.lightBlue,
                                    onButtonTap: () {
                                      apiCalling(
                                          memberModelDetail.userId,
                                          index,
                                          MessageConstant.ABOUT_GROUP_ACCEPTED);
                                    },
                                  ),
                            InkWell(
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(7.0, 0.0, 0.0, 0.0),
                                  child: Container(
                                      height: 23.0,
                                      width: 23.0,
                                      child: Image.asset(
                                        'assets/png/cancel_circle.png',
                                      ))),
                              onTap: () {
                                apiCalling(memberModelDetail.userId, index,
                                    MessageConstant.ABOUT_GROUP_REJECTED);
                              },
                            )
                          ],
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 16.0, bottom: 8),
                    child: Container(
                      height: 1,
                      color: AppConstants.colorStyle.btnBg,
                    ),
                  )
                ],
              )));
    }

    Container getListview11(
        MemberModelDetail memberModelDetail, index, bool isSentRequest) {
      return Container(
          color: Colors.transparent,
          padding: EdgeInsets.fromLTRB(11.0, 5.0, 13.0, 0.0),
          child: Card(
              color: Colors.transparent,
              elevation: 0.0,
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: InkWell(
                          child: Container(
                            height: 50.0,
                            width: 50.0,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(100),
                              child: FadeInImage(
                                fit: BoxFit.cover,
                                placeholder: AssetImage(
                                  'assets/profile/user_on_user.png',
                                ),
                                image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                                    ParseJson.getSmallImage(
                                        memberModelDetail.profilePicture)),
                              ),
                            ),
                          ),
                          onTap: () {
                            onTapImageTile(memberModelDetail.userId, "1");
                          },
                        ),
                        flex: 0,
                      ),
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            10.0,
                            0.0,
                            0.0,
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: TextViewWrap.textView(
                                          memberModelDetail.lastName == null ||
                                                  memberModelDetail.lastName ==
                                                      "null" ||
                                                  memberModelDetail.lastName ==
                                                      ""
                                              ? memberModelDetail.firstName
                                              : memberModelDetail.firstName +
                                                  " " +
                                                  memberModelDetail.lastName,
                                          TextAlign.left,
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.bold),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Flexible(
                                        child: TextViewWrap.textView(
                                      memberModelDetail.tagline == null ||
                                              memberModelDetail.tagline ==
                                                  "null" ||
                                              memberModelDetail.tagline == ""
                                          ? ""
                                          : memberModelDetail.tagline,
                                      TextAlign.start,
                                      ColorValues.GREY_TEXT_COLOR,
                                      12.0,
                                      FontWeight.normal,
                                    )),
                                  ],
                                ),
                              ],
                            )),
                        flex: 1,
                      ),
                      Expanded(
                        child: Row(
                          children: <Widget>[
                            isSentRequest
                                ? Text("")
                                : InkWell(
                                    child: Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                            height: 40.0,
                                            width: 40.0,
                                            child: Image.asset(
                                              'assets/newDesignIcon/connections/tick_blue.png',
                                            ))),
                                    onTap: () {
                                      apiCalling(
                                          memberModelDetail.userId,
                                          index,
                                          MessageConstant.ABOUT_GROUP_ACCEPTED);
                                    },
                                  ),
                            InkWell(
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                                  child: Container(
                                      height: 30.0,
                                      width: 30.0,
                                      child: Image.asset(
                                        'assets/newDesignIcon/connections/cancel.png',
                                      ))),
                              onTap: () {
                                apiCalling(memberModelDetail.userId, index,
                                    MessageConstant.ABOUT_GROUP_REJECTED);
                              },
                            )
                          ],
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                ],
              )));
    }

    invite() async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => InviteMember(
              widget.modell.groupId, "member", widget.modell.allMembersList)));

      if (result == "push") {
        Navigator.pop(context, "push");
      }
    }

    return customAppbar(
      context,
      GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 20.0, right: 20, top: 24, bottom: 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      BaseText(
                        text: 'Requests',
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ),
                    ],
                  ),
                ),
                flex: 0,
              ),
              Expanded(
                child: widget.requestedList.length == 0
                    ? Container(
                  margin: const EdgeInsets.only(bottom: 80),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                          child:  Container(
                            width: MediaQuery.of(context).size.width,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(30),
                                topRight: Radius.circular(30),
                              ),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Padding(
                                    padding: EdgeInsets.fromLTRB(15.0, 170.0, 0.0, 0.0),
                                    child: Container(
                                      width: 120.0,
                                      height: 111.0,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage(
                                                'assets/newDesignIcon/connections/man_to_guide.png'),
                                            fit: BoxFit.cover),
                                      ),
                                    )),
                                Center(
                                    child: Text(
                                      "No request found",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                          fontSize: 18.0,
                                          fontFamily: Constant.latoRegular),
                                    )),
                              ],
                            ),
                          ))
                    ],
                  ),
                )
                    : Container(
                        child: Column(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.fromLTRB(
                                20.0, 25.0, 20.0, 0.0),
                            child: SizedBox(
                              height: 40,
                              child: TextField(
                                textAlign: TextAlign.left,
                                onChanged: (value) {
                                  // Method For Searching
                                  searchName = value;
                                  if (searchName.isEmpty) {
                                    item = 0;
                                    setState(() {});
                                  }
                                  print("SSS Seacrh Name ${searchName}");
                                },
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: ColorValues.TAB_BACKGROUND_COLOR,
                                  hintText: "Search group member",
                                  hintStyle: TextStyle(
                                      fontSize: 14,color: ColorValues.hintColor,
                                      fontFamily: Constant.latoRegular),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      15.0, 10.0, 20.0, 10.0),
                                  suffixIcon: IconButton(
                                    onPressed: () {
                                      setState(() {
                                        item = 0;
                                        searchName;
                                      });
                                    },
                                    icon: Image.asset(
                                      "assets/newDesignIcon/connections/new_search.png",
                                      height: 20,
                                      width: 20,
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(10.0),
                                    ),
                                    borderSide: BorderSide(
                                        color: ColorValues.BORDER_COLOR_NEW),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(10.0),
                                    ),
                                    borderSide: BorderSide(
                                        color: ColorValues.BORDER_COLOR_NEW),
                                  ),
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                      borderSide: new BorderSide(
                                          color: ColorValues.BORDER_COLOR_NEW)),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                              child: ListView(
                            children: <Widget>[
                              Column(
                                children: List.generate(
                                    widget.requestedList.length, (int index) {
                                  return (searchName == '' ||
                                          widget.requestedList[index].firstName
                                              .toString()
                                              .toLowerCase()
                                              .startsWith(searchName))
                                      ? getListview(widget.requestedList[index],
                                          index, false)
                                      : SizedBox();
                                }),
                              ),

                            ],
                          ))
                        ],
                      )),
                flex: 1,
              ),
            ],
          )),
      () {
        Navigator.pop(context, isPerformChanges);
      },
      isShowIcon: false,
    );

    return MaterialApp(
      home: WillPopScope(
          onWillPop: () {
            Navigator.pop(context, isPerformChanges);
          },
          child: Scaffold(
            appBar: AppBar(
              elevation: 0.0,
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              title: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                            Center(
                                child: Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context, isPerformChanges);
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Text(
                      MessageConstant.ABOUT_GROUP_GROUP_REQUEST,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  ),
                ],
              ),
              actions: <Widget>[
                Container(
                  width: 40.0,
                ),
              ],
              backgroundColor: Colors.white,
            ),
            body: Container(
                color: ColorValues.LIGHT_GRAY_BG,
                child: Column(
                  children: <Widget>[
                    CustomViews.getSepratorLine(),
                    Expanded(
                        child: ListView(
                      children: <Widget>[
                        (widget.modell.isAdmin ||
                                    widget.modell.type == "public") &&
                                widget.modell.status == "Accepted" &&
                                (!widget.modell.isOpportunityAdded)
                            ? Column(children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    20.0,
                                    0.0,
                                    20.0,
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Expanded(
                                          child: PaddingWrap.paddingfromLTRB(
                                              10.0,
                                              5.0,
                                              5.0,
                                              5.0,
                                              InkWell(
                                                child: Container(
                                                    height: 31.0,
                                                    width: 151.0,
                                                    color:
                                                        ColorValues.BLUE_COLOR,
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: <Widget>[
                                                        Text(
                                                          MessageConstant
                                                              .ABOUT_GROUP_INVITE_GROUP,
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR,
                                                              fontSize: 14.0),
                                                        )
                                                      ],
                                                    )),
                                                onTap: () {
                                                  invite();
                                                },
                                              )),
                                          flex: 0,
                                        ),
                                      ],
                                    )),
                                Divider(
                                  height: 1.0,
                                  color: ColorValues.BORDER_COLOR,
                                )
                              ])
                            : Container(
                                height: 0.0,
                              ),
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            10.0,
                            0.0,
                            0.0,
                            Column(
                              children: List.generate(
                                  widget.requestedList.length, (int index) {
                                return getListview(
                                    widget.requestedList[index], index, false);
                              }),
                            ))
                      ],
                    ))
                  ],
                )),
          )),
    );
  }
}
