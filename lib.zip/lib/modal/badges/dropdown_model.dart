

import 'dart:convert';

List<DropDownModel> spinnerFromJson(String str) =>
    List<DropDownModel>.from(json.decode(str).map((x) => DropDownModel.fromJson(x)));

class DropDownModel {
  String name;
  String icon;

  DropDownModel({this.name, this.icon});

  DropDownModel.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    icon = json['icon'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['icon'] = icon;
    return data;
  }
}