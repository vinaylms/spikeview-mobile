import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/modal/TestScoreModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'AddTestScoreCategory.dart';
import 'AddTestScoreCategoryForm.dart';

// Create a Form Widget
class AddTestScore extends StatefulWidget {
  ProfileData profileInfoModal;
  final String studentId;

  AddTestScore(
    this.profileInfoModal, {
    this.studentId,
  });

  @override
  AddTestScoreState createState() {
    return AddTestScoreState();
  }
}

class AddTestScoreState extends State<AddTestScore> {
  List<TestScoreModel> testList = List();
  ScrollController _controller = ScrollController();
  String isPerformChanges = "pop";
  String userIdPref;

  bool isValid = true;
  bool isTestSelected = false;
  File mediaImage;
  int selectedPosition;
  String dob;

  getSharedPreferences() async {
    if (widget.studentId != null) {
      userIdPref = widget.studentId;
    } else {
      userIdPref = widget.profileInfoModal.userId;
    }
    dob = widget.profileInfoModal.dob;
    testDataApi(true);
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  Future testDataApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_TEST_SCORE_DATA, "get");

        print("response education" + response.toString());

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              testList.clear();
              testList = ParseJson.parseTestScoreData(response.data['result']);
              if (testList.length > 0) {
                if (mounted) {
                  setState(() {});
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------Delete Education Data ------------------

  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Column getCompetencyItem(position) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
              20.0,
              0.0,
              20.0,
              0.0,
              Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        //                   <--- left side
                        color: Color(0xffE5EBF0),
                        width: 1.0,
                      ),
                    ),
                  ),
                  child: InkWell(
                      child: Padding(
                        padding: const EdgeInsets.only(
                          top: 14.0,
                          bottom: 14,
                        ),
                        child: BaseText(
                          text: testList[position].testName,
                          textColor: testList[position].isSelected
                              ? ColorValues.BLUE_COLOR_BOTTOMBAR
                              : AppConstants.colorStyle.darkBlue,
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w500,
                          fontSize: 18,
                          maxLines: 3,
                        ),
                      ),
                      onTap: () {
                        bool currentFlag = testList[position].isSelected;

                        for (TestScoreModel model in testList) {
                          model.isSelected = false;
                        }

                        if (currentFlag) {
                          selectedPosition = null;
                          testList[position].isSelected = false;
                        } else {
                          selectedPosition = position;
                          testList[position].isSelected = true;
                        }
                        setState(() {
                          testList[position].isSelected;
                        });
                      }))),
        ],
      );
    }

    return WillPopScope(
      onWillPop: () {
        Navigator.pop(context, isPerformChanges);
      },
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          body: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              FocusScopeNode currentFocus = FocusScope.of(context);

              if (!currentFocus.hasPrimaryFocus &&
                  currentFocus.focusedChild != null) {
                FocusManager.instance.primaryFocus.unfocus();
              }
            },
            child: Column(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0, right: 20, top: 20, bottom: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            BaseText(
                              text: MessageConstant.TEST_HEDING,
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              maxLines: 1,
                            ),
                            const HelpButtonWidget(),
                          ],
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Align(
                            alignment: Alignment.topLeft,
                            child: BaseText(
                              text: MessageConstant.TEST_HEDING_TWO,
                              textColor: AppConstants.colorStyle.lightPurple,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              maxLines: 2,
                            )),
                      ],
                    ),
                  ),
                  flex: 0,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                    child: testList.length > 0
                        ? ListView.builder(
                            controller: _controller,
                            itemCount: testList.length,
                            itemBuilder: (BuildContext context, int position) {
                              return getCompetencyItem(position);
                            })
                        : Container(
                            height: 0.0,
                          ),
                  ),
                  flex: 1,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                            flex: 2,
                            child: InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  20.0,
                                  20.0,
                                  0.0,
                                  0.0,
                                  Container(
                                      height: 44,
                                      decoration: BoxDecoration(
                                        color: ColorValues.WHITE,
                                        border: Border.all(
                                            color:
                                                AppConstants.colorStyle.btnBg),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Align(
                                          alignment: Alignment.center,
                                          // Align however you like (i.e .centerRight, centerLeft)
                                          child: Text(
                                            "Cancel",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              color: AppConstants
                                                  .colorStyle.lightPurple,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoRegular,
                                              fontSize: 16.0,
                                            ),
                                          )))),
                              onTap: () async {
                                Navigator.pop(context, "push");
                              },
                            )),
                        Expanded(
                            flex: 3,
                            child: Stack(
                              children: [
                                InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      20.0,
                                      20.0,
                                      0.0,
                                      Container(
                                          height: 44,
                                          decoration: BoxDecoration(
                                            color: AppConstants
                                                .colorStyle.lightBlue,
                                            border: Border.all(
                                                color: AppConstants
                                                    .colorStyle.lightBlue),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: Align(
                                              alignment: Alignment.center,
                                              // Align however you like (i.e .centerRight, centerLeft)
                                              child: Text(
                                                "Add",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  color: ColorValues.WHITE,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoRegular,
                                                  fontSize: 16.0,
                                                ),
                                              )))),
                                  onTap: () async {
                                    if (testList[selectedPosition]
                                        .isSubCategory) {
                                      var result = await Navigator.of(context)
                                          .push(new MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  AddTestScoreCategory(
                                                      widget.profileInfoModal,
                                                      testList[selectedPosition]
                                                          .subjectListModel,
                                                      testList[selectedPosition]
                                                          .testName,
                                                      testList[selectedPosition]
                                                          .testId,
                                                      testList[
                                                          selectedPosition])));

                                      if (result != null && result) {
                                        Navigator.pop(context, result);
                                      }
                                    } else {
                                      var result = await Navigator.of(context)
                                          .push(new MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  AddTestScoreCategoryForm(
                                                      widget.profileInfoModal,
                                                      testList[selectedPosition]
                                                          .subjectListModel,
                                                      testList[selectedPosition]
                                                          .testName,
                                                      testList[selectedPosition]
                                                          .testId,
                                                      testList[
                                                          selectedPosition],
                                                      selectedPosition)));

                                      if (result != null && result) {
                                        Navigator.pop(context, result);
                                      }
                                    }
                                  },
                                ),
                                selectedPosition == null
                                    ? Container(
                                        height: 70.0,
                                        width: double.infinity,
                                        color: Colors.white.withOpacity(0.75),
                                      )
                                    : SizedBox(
                                        height: 0,
                                      )
                              ],
                            ))
                      ],
                    ),
                  ),
                  flex: 0,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
