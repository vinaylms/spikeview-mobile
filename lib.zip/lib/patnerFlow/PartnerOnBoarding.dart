import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/EmailVerification.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/gateway/partner_signup/partner_profile_view.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

class PartnerOnBoarding {
  ProfileInfoModal profileInfoModal = null;
  BuildContext context;

  String userId = '';

  SharedPreferences prefs;

  onBoardingInit(
      BuildContext context, ProfileInfoModal profileInfoModal, String userId) {
    this.context = context;
    this.profileInfoModal = profileInfoModal;
    this.userId = userId;

    getData();
  }

  bool isAdded = true;

  Future<void> getData() async {
    prefs = await SharedPreferences.getInstance();
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
    if (profileInfoModal == null) {
      await profileApi(true);
    } else {
      getStage(context);
    }
  }

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    print('profileApi userId onboarding partner++++ ::: $userId');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO + userId + "/false", "get");
        print('profileApi response++++ :::' + response.data.toString());
        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                try {
                  prefs.setString(UserPreference.DOB, profileInfoModal.dob);
                } catch (e) {}

                getStage(context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("error++++" + e.toString());
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future<void> getStage(BuildContext context) async {
    print('getStage() 111 profileInfoModal.stage:: ${profileInfoModal.stage}');
    if (profileInfoModal != null) {
      try {
        if (profileInfoModal.stage != null &&
            int.parse(profileInfoModal.stage) < 2) {
          if (profileInfoModal.stage == "0") {
            stage1();
          } else if (profileInfoModal.stage == "1") {
            stage2();
          } else {
            Navigator.of(context).popUntil((route) => route.isFirst);

            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE)),
              ),
            );
          }
        }else{
          Navigator.of(context).popUntil((route) => route.isFirst);

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => DashBoardWidgetPartner(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE)),
            ),
          );
        }
      } catch (e) {}
    }
  }

  stage2() async {
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => PartnerProfileView(
          signUpUsing: SignUpUsing.email,
          pageName: '',
          lastName: '',
          firstName: '',
          action: PartnerProfileAction.add,
          email: profileInfoModal.email,
        ),
      ),
    );
  }

  stage1() async {
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) => EmailVerification(
              profileInfoModal,
              '',
              loginRole: LoginRole.partner,
            )));
  }
}
