/*
import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestFromParent.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestRepliedParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/recommendation/AddRecommendationNew.dart';
import 'package:spike_view_project/recommendation/EditRecommendationNew.dart';
import 'package:spike_view_project/recommendation/RecommendationDetail.dart';
import 'package:spike_view_project/recommendation/ViewAllRecommendationForParent.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'dart:async';


import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

// Create a Form Widget
class RecommendationListForParent extends StatefulWidget {
  String page;
  RecommendationListForParent(this.page);
  @override
  RecommendationListForParentState createState() {
    return  RecommendationListForParentState();
  }
}

class RecommendationListForParentState
    extends State<RecommendationListForParent> {
  List<Recomdation> approvedRecommendationtList =  List();
  List<Recomdation> requestedRecommendationtList =  List();
  bool isViewAllForSentRequest = false;
  bool isViewAllForApprovedRequest = false;

  SharedPreferences prefs;
  String userIdPref, token;
  String isPerformChanges = "pop";

  //--------------------------Recommendation Info api ------------------
  Future recommendationApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(
            context, Constant.ENDPOINT_RECOMMENDATION + userIdPref, "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              approvedRecommendationtList.clear();
              requestedRecommendationtList.clear();
              approvedRecommendationtList = ParseJson.parseMapRecommdation(
                  response.data['approved'], true);

              requestedRecommendationtList = ParseJson.parseMapRecommdation(
                  response.data['requested'], true);

              setState(() {
                approvedRecommendationtList;
                requestedRecommendationtList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    recommendationApi();
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    onTapRecommendation(recommendation) async {
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               RecommendationReuest(recommendation)));
      if (result == "push") {
        recommendationApi();
      }
    }

    onTapRecommendationRepilied(recommendation) async {
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               RecommendationReuestReplied(recommendation)));
    }

    Widget getApprovedUi() {
      return  Container(
          child:  Padding(
              padding:  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 10.0),
              child:  Column(
                  children:  List.generate(
                      approvedRecommendationtList.length > 2
                          ? isViewAllForApprovedRequest
                              ? approvedRecommendationtList.length
                              : 2
                          : approvedRecommendationtList.length, (int index) {
                return  InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      0.0,
                       Container(
                          decoration:  BoxDecoration(
                              color: Colors.white,
                              border:  Border.all(
                                  color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
                                  width: 0.5)),
                          child:  Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                 Expanded(
                                  child: PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      11.0,
                                      0.0,
                                      10.0,
                                       Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                           Row(
                                            children: <Widget>[
                                               Expanded(
                                                child:  Stack(
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  ClipOval(
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                        fit: BoxFit.cover,
                                                        width: 50.0,
                                                        height: 50.0,
                                                        placeholder:
                                                            'assets/profile/user_on_user.png',
                                                        image: Constant
                                                                .IMAGE_PATH_SMALL +
                                                            ParseJson.getMediumImage(
                                                                approvedRecommendationtList[
                                                                        index]
                                                                    .user
                                                                    .profilePicture),
                                                      )),
                                                      */
/* onTap: () {
                                                    onTapStudentItem(index);
                                                  },*//*

                                                    ),
                                                  ],
                                                ),
                                                flex: 0,
                                              ),
                                               Expanded(
                                                  child:  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: <Widget>[
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              8.0,
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              RichText(
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                text: TextSpan(
                                                                  text:
                                                                      "From: ",
                                                                  style:  TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      height:
                                                                          1.2,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR),
                                                                  children: <
                                                                      TextSpan>[
                                                                    TextSpan(
                                                                      text: approvedRecommendationtList[index].user.lastName ==
                                                                              "null"
                                                                          ? approvedRecommendationtList[index]
                                                                              .user
                                                                              .firstName
                                                                          : approvedRecommendationtList[index].user.firstName +
                                                                              " " +
                                                                              approvedRecommendationtList[index].user.lastName,
                                                                      style:  TextStyle(
                                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              14.0,
                                                                          fontWeight: FontWeight
                                                                              .bold,
                                                                          fontFamily:
                                                                              Constant.customBold),
                                                                    )
                                                                  ],
                                                                ),
                                                              )),
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              7.0,
                                                              3.0,
                                                              0.0,
                                                              0.0,
                                                              PaddingWrap
                                                                  .paddingAll(
                                                                2.0,
                                                                TextViewWrap.textView(
                                                                    "View Request",
                                                                    TextAlign
                                                                        .start,
                                                                     ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    12.0,
                                                                    FontWeight
                                                                        .normal),
                                                              )),
                                                    ],
                                                  ),
                                                  flex: 1),
                                            ],
                                          ),
                                        ],
                                      )),
                                ),
                              ]))),
                  onTap: () {
                    onTapRecommendationRepilied(
                        approvedRecommendationtList[index]);
                  },
                );
              }))));
    }

    Widget getRequestedUi() {
      return  Container(
          child:  Padding(
              padding:  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 10.0),
              child:  Column(
                  children:  List.generate(
                      requestedRecommendationtList.length > 2
                          ? isViewAllForSentRequest
                              ? requestedRecommendationtList.length
                              : 2
                          : requestedRecommendationtList.length, (int index) {
                return  InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      0.0,
                       Container(
                          decoration:  BoxDecoration(
                              color: Colors.white,
                              border:  Border.all(
                                  color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
                                  width: 0.5)),
                          child:  Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                 Expanded(
                                  child: PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      11.0,
                                      0.0,
                                      10.0,
                                       Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                           Row(
                                            children: <Widget>[
                                               Expanded(
                                                child:  Stack(
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  ClipOval(
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                        fit: BoxFit.cover,
                                                        width: 50.0,
                                                        height: 50.0,
                                                        placeholder:
                                                            'assets/profile/user_on_user.png',
                                                        image: Constant
                                                                .IMAGE_PATH_SMALL +
                                                            ParseJson.getMediumImage(
                                                                requestedRecommendationtList[
                                                                        index]
                                                                    .user
                                                                    .profilePicture),
                                                      )),
                                                      */
/* onTap: () {
                                                    onTapStudentItem(index);
                                                  },*//*

                                                    ),
                                                  ],
                                                ),
                                                flex: 0,
                                              ),
                                               Expanded(
                                                  child:  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: <Widget>[
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                        8.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        RichText(
                                                          textAlign:
                                                              TextAlign.center,
                                                          text: TextSpan(
                                                            text: "From: ",
                                                            style:  TextStyle(
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                height: 1.2,
                                                                fontSize: 14.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .normal,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                            children: <
                                                                TextSpan>[
                                                              TextSpan(
                                                                text: requestedRecommendationtList[index]
                                                                            .user
                                                                            .lastName ==
                                                                        "null"
                                                                    ? requestedRecommendationtList[
                                                                            index]
                                                                        .user
                                                                        .firstName
                                                                    : requestedRecommendationtList[index]
                                                                            .user
                                                                            .firstName +
                                                                        " " +
                                                                        requestedRecommendationtList[index]
                                                                            .user
                                                                            .lastName,
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    fontFamily:
                                                                        Constant
                                                                            .customBold),
                                                              )
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              7.0,
                                                              3.0,
                                                              0.0,
                                                              0.0,
                                                              PaddingWrap
                                                                  .paddingAll(
                                                                2.0,
                                                                TextViewWrap.textView(
                                                                    "View Request",
                                                                    TextAlign
                                                                        .start,
                                                                     ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    12.0,
                                                                    FontWeight
                                                                        .normal),
                                                              )),
                                                    ],
                                                  ),
                                                  flex: 1),
                                            ],
                                          ),
                                        ],
                                      )),
                                ),
                              ]))),
                  onTap: () {
                    onTapRecommendation(requestedRecommendationtList[index]);
                  },
                );
              }))));
    }

    onTapViewAll(type, dataType) async {
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               ViewAllRecommendationForParent(userIdPref, type, dataType)));
      if (result == "push") {
        recommendationApi();
      }
    }

    onBack() async {

      if (widget.page == "login") {
        String roleId = prefs.getString(UserPreference.ROLE_ID);
        if (roleId == "2") {
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => DashBoardWidgetParent(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE))));
        } else if (roleId == "4") {
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) =>  DashBoardWidgetPartner(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE))));
        } else {
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) =>  DashBoardWidget(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE))));
        }
      } else {
        Navigator.pop(context, isPerformChanges);
      }
    }

    //-------------------------------------Main Ui ------------------------------------------
    return  WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.singin_bg_color,
            appBar:  AppBar(
              elevation: 0.0,
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Expanded(
                    child:  InkWell(
                      child: CustomViews.getBackButton(),
                      onTap: () {
                        onBack();
                      },
                    ),
                    flex: 0,
                  ),
                   Expanded(
                    child:  Text(
                      "Manage Recommendations",
                      textAlign: TextAlign.center,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                 Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                     InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          18.0,
                          0.0,
                           Image.asset(
                            "",
                            height: 20.0,
                            width: 20.0,
                          )),
                      onTap: () {},
                    )
                  ],
                )
              ],
              backgroundColor: Colors.white,
            ),
            body:  Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                 Expanded(
                  child:   approvedRecommendationtList.length > 0||requestedRecommendationtList.length > 0?  Column(
                    children: <Widget>[
                      approvedRecommendationtList.length > 0
                          ?  Padding(
                              padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                              child:  Container(
                                child:  Row(
                                  children: <Widget>[
                                     Expanded(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 0.0, 0.0, 0.0),
                                          child:  Text(
                                            "RECOMMENDATIONS REPLIED" +
                                                "(" +
                                                approvedRecommendationtList
                                                    .length
                                                    .toString() +
                                                ")",
                                            style: TextStyle(
                                                fontSize: 12.0,
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontFamily:
                                                    Constant.customRegular),
                                          )),
                                      flex: 1,
                                    ),
                                     Expanded(
                                      child:  InkWell(
                                        child:  Container(
                                            height: 40.0,
                                            child:  Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    0.0, 3.0, 10.0, 0.0),
                                                child:  Text(
                                                  approvedRecommendationtList
                                                              .length >
                                                          2
                                                      ? isViewAllForApprovedRequest
                                                          ? "Hide"
                                                          : "View All"
                                                      : "",
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily: Constant
                                                          .customRegular),
                                                ))),
                                        onTap: () {
                                          */
/*   if (isViewAllForApprovedRequest) {
                                            isViewAllForApprovedRequest = false;
                                          } else {
                                            isViewAllForApprovedRequest = true;
                                          }
                                          setState(() {
                                            isViewAllForApprovedRequest;
                                          });*//*

                                          onTapViewAll(
                                              Constant.CONST_REPLIED, 2);
                                        },
                                      ),
                                      flex: 0,
                                    )
                                  ],
                                ),
                                color: ColorValues.GREY__COLOR_DIVIDER,
                                height: 25.0,
                              ))
                          :  Container(
                              height: 0.0,
                            ),
                      getApprovedUi(),
                      requestedRecommendationtList.length > 0
                          ?  Padding(
                              padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                              child:  Container(
                                child:  Row(
                                  children: <Widget>[
                                     Expanded(
                                      child:  Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              13.0, 0.0, 0.0, 0.0),
                                          child:  Text(
                                            "RECOMMENDATIONS PENDING" +
                                                "(" +
                                                requestedRecommendationtList
                                                    .length
                                                    .toString() +
                                                ")",
                                            style: TextStyle(
                                                fontSize: 12.0,
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontFamily:
                                                    Constant.customRegular),
                                          )),
                                      flex: 1,
                                    ),
                                     Expanded(
                                      child:  InkWell(
                                        child:  Container(
                                            height: 40.0,
                                            child:  Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    0.0, 3.0, 10.0, 0.0),
                                                child:  Text(
                                                  requestedRecommendationtList
                                                              .length >
                                                          2
                                                      ? isViewAllForSentRequest
                                                          ? "Hide"
                                                          : "View All"
                                                      : "",
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily: Constant
                                                          .customRegular),
                                                ))),
                                        onTap: () {
                                          */
/*   if (isViewAllForSentRequest) {
                                            isViewAllForSentRequest = false;
                                          } else {
                                            isViewAllForSentRequest = true;
                                          }
                                          setState(() {
                                            isViewAllForSentRequest;
                                          });*//*

                                          onTapViewAll(
                                              Constant.CONST_PENDING, 1);
                                        },
                                      ),
                                      flex: 0,
                                    )
                                  ],
                                ),
                                color: ColorValues.GREY__COLOR_DIVIDER,
                                height: 25.0,
                              ))
                          :  Container(
                              height: 0.0,
                            ),
                      getRequestedUi()
                    ],
                  ):new Center(
                    child:  Column(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .center,
                      mainAxisAlignment:
                      MainAxisAlignment
                          .center,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                             Image.asset(
                              "assets/mange_rec.png",
                              width: double.infinity,
                              height: 151.0,
                            )),
                        PaddingWrap.paddingfromLTRB(
                            40.0,
                            20.0,
                            40.0,
                            20.0,
                            TextViewWrap.textViewMultiLine(
                                "No recommendation request pending",
                                TextAlign.center,
                                 ColorValues.GREY_TEXT_COLOR,
                                16.0,
                                FontWeight.bold,2)),

                      ],
                    ),
                  ),
                  flex: 1,
                )
              ],
            )));
  }
}
*/
