import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/Connection/RefferalModel.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

class RequestsSeeAllWidget extends StatefulWidget {
  String title;
  int listType;

  RequestsSeeAllWidget(
    String title,
    int listType,
  ) {
    this.title = title;
    this.listType = listType;
  }

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    // ignore: return_of_invalid_type
    return MainView(title, listType);
  }
}

class MainView extends State<RequestsSeeAllWidget> {
  String title;
  int listType;
  String statusIndex;
  BuildContext context;
  SharedPreferences prefs;
  String userIdPref, roleId, userProfilePath;
  ScrollController _scrollController = ScrollController();

  List<RequestedTagModel> tagList = List();
  List<RequestedTagModel> sendRequestList = List();
  List<PeopleYouMayKnow> peopleYouMayKnowList = List();
  List<RequestedTagModel> pendingRequestList = List();
  List<RequestedTagModel> recievedRequestList = List();
  int skip = 0;
  List<RefferalModel> refferList = List();

  Map<String, String> dataExist = Map();

  MainView(
    String title,
    int listType,
  ) {
    this.title = title;
    this.listType = listType;
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
//2 5 6
    switch (listType) {
      case 0:
        statusIndex = Constant.REQUESTED;
        break;
      case 1:
        statusIndex = Constant.SENT_REQUEST;
        break;
      case 2:
        statusIndex = Constant.PEOPLE_YOU_MAY_KNOW;
        break;
      case 3:
        statusIndex = Constant.INVITED;
        break;
      case 4:
        statusIndex = Constant.PENDING;
        break;
      case 5:
        statusIndex = Constant.RECIEVED;
        break;
    }
    if (listType == 3) {
      apiCallForPending();
    } else {
      apiToGetDetail();
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();

    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        skip = skip + 1;

        print("No Index---- " + skip.toString());
        apiToGetDetail();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  bool isNeedToRefresh = false;
  bool isLoading = true;

  Future apiCallForPending() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });

        print(Constant.ENDPOINT_PENDING +
            "/" +
            userIdPref +
            "/" +
            roleId +
            "/pending");

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_PENDING +
                "/" +
                userIdPref +
                "/" +
                roleId +
                "/pending",
            "get");
        isLoading = false;
        setState(() {
          isLoading;
        });

        print("-=------------ skip.toString()++++ " + skip.toString());
        print(response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              List<RefferalModel> referLocalList = List();

              referLocalList = ParseJson.parseRefferal(response.data['result']);

              refferList.addAll(referLocalList);

              setState(() {
                refferList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  // -------------------  API ------------------------------

  Future apiToGetDetail() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });

        print(Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
            userIdPref +
            "&status=" +
            statusIndex.toString() +
            "&roleId=" +
            roleId +
            "&skip=" +
            skip.toString());

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
                userIdPref +
                "&status=" +
                statusIndex.toString() +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString(),
            "get");
        isLoading = false;
        setState(() {
          isLoading;
        });

        print("-=------------ skip.toString()++++ " + skip.toString());
        print(response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              switch (listType) {
                case 0:
                  List<RequestedTagModel> tagListLocal = List();
                  tagListLocal = ParseJson.parseRequestedTagList(
                      response.data['result']['Requested']);

                  for (int i = 0; i < tagList.length; i++) {
                    for (int j = 0; j < tagListLocal.length; j++) {
                      if (tagList[i].userId == tagListLocal[j].userId) {
                        tagListLocal.removeAt(j);
                      }
                    }
                  }

                  tagList.addAll(tagListLocal);
                  setState(() {
                    tagList;
                  });
                  break;

                case 1:
                  List<RequestedTagModel> sendRequestListLocal = List();

                  sendRequestListLocal = ParseJson.parseRequestedTagList(
                      response.data['result']['sentRequest']);

                  print("Local List Size--------->" +
                      sendRequestListLocal.length.toString());
                  for (int i = 0; i < sendRequestList.length; i++) {
                    for (int j = 0; j < sendRequestListLocal.length; j++) {
                      if (sendRequestList[i].patner.userId ==
                          sendRequestListLocal[j].patner.userId) {
                        sendRequestListLocal.removeAt(j);
                      }
                    }
                  }

                  sendRequestList.addAll(sendRequestListLocal);
                  setState(() {
                    sendRequestList;
                  });

                  break;

                case 2:
                  List<PeopleYouMayKnow> peopleYouMayKnowListLocal = List();

                  peopleYouMayKnowListLocal = ParseJson.parsePeopleMayYouKnow(
                      response.data['result']['PeopleYouMayKnow']);

                  for (int i = 0; i < peopleYouMayKnowList.length; i++) {
                    for (int j = 0; j < peopleYouMayKnowListLocal.length; j++) {
                      if (peopleYouMayKnowList[i].userId ==
                          peopleYouMayKnowListLocal[j].userId) {
                        peopleYouMayKnowListLocal.removeAt(j);
                      }
                    }
                  }

                  peopleYouMayKnowList.addAll(peopleYouMayKnowListLocal);

                  setState(() {
                    peopleYouMayKnowList;
                  });

                  break;
                case 4:
                  List<RequestedTagModel> pendingList = List();
                  pendingList = ParseJson.parseRequestedTagList(
                      response.data['result']['Pending']);

                  for (int i = 0; i < pendingRequestList.length; i++) {
                    for (int j = 0; j < pendingList.length; j++) {
                      if (pendingRequestList[i].userId ==
                          pendingList[j].userId) {
                        pendingList.removeAt(j);
                      }
                    }
                  }

                  pendingRequestList.addAll(pendingList);
                  setState(() {
                    pendingRequestList;
                  });
                  break;

                case 5:
                  List<RequestedTagModel> recieveRequestLocalList = List();
                  recieveRequestLocalList = ParseJson.parseRequestedTagList(
                      response.data['result']['receivedRequest']);

                  for (int i = 0; i < recievedRequestList.length; i++) {
                    for (int j = 0; j < recieveRequestLocalList.length; j++) {
                      if (recievedRequestList[i].userId ==
                          recieveRequestLocalList[j].userId) {
                        recieveRequestLocalList.removeAt(j);
                      }
                    }
                  }

                  recievedRequestList.addAll(recieveRequestLocalList);
                  setState(() {
                    recievedRequestList;
                  });
                  break;
              }

              if (tagList != null) {
                if (tagList.length > 0) {
                  prefs.setString(
                      UserPreference.ISACTIVE, tagList[0].userIsActive);
                }

                setState(() {
                  print("After Success Response");
                  tagList;
                  sendRequestList;
                  pendingRequestList;
                  recievedRequestList;
                  peopleYouMayKnowList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallingForAccept(connectionId, index, type, userIsActive) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": type,
        "isActive": userIsActive,
        "roleId": int.parse(roleId)
      };
      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isNeedToRefresh = true;
            if (listType == 4) {
              pendingRequestList.removeAt(index);
              setState(() {
                pendingRequestList;
              });
            } else if (listType == 5) {
              recievedRequestList.removeAt(index);
              setState(() {
                recievedRequestList;
              });
            } else {
              tagList.removeAt(index);
              setState(() {
                tagList;
              });
            }
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForUnfriend(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId)
      };
      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            print("Cancel -----=-=-=-=-=-=-=-= " + listType.toString());

            if (listType == 0) tagList.removeAt(index);

            if (listType == 1) {
              sendRequestList[index].patner.profilePicture = "";
              setState(() {
                sendRequestList;
              });
              sendRequestList.removeAt(index);
            }

            isNeedToRefresh = true;

            //ToastWrap.showToast(msg);
            setState(() {
              tagList;
              sendRequestList;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForConnect(
      int index, String partnerId, String partnerRoleId, bool isActive) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        bool ageStatus = false;
        if (prefs.getString(UserPreference.DOB) != null &&
            prefs.getString(UserPreference.DOB) != 'null') {
          ageStatus = Util.currentAge(
                  DateTime.fromMillisecondsSinceEpoch(
                      int.tryParse(prefs.getString(UserPreference.DOB))),
                  13) <
              13;
        }
        Map map = {
          "userId": prefs.getString(UserPreference.USER_ID),
          "partnerId": int.parse(partnerId),
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "status": ageStatus ? "Pending" : "Requested",
          "isActive": isActive,
          "userRoleId": int.parse(roleId),
          "partnerRoleId": int.parse(partnerRoleId)
        };
        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg);

              String connectId =
                  response.data["result"]["connectId"].toString();
              //this.connectId = connectId;
              peopleYouMayKnowList[index].isRequested = true;
              setState(() {
                // Remove from current List

                peopleYouMayKnowList;
                isNeedToRefresh = true;
              });
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForConnectForPeopleMayKnow(
      int index, String partnerId, String partnerRoleId, bool isActive) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": prefs.getString(UserPreference.USER_ID),
          "partnerId": int.parse(partnerId),
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "status": Util.currentAge(
                      DateTime.fromMillisecondsSinceEpoch(
                          int.tryParse(prefs.getString(UserPreference.DOB))),
                      13) <
                  13
              ? "Pending"
              : "Requested",
          "isActive": isActive,
          "userRoleId": int.parse(roleId),
          "partnerRoleId": int.parse(partnerRoleId)
        };
        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg);
              peopleYouMayKnowList.removeAt(index);

              setState(() {
                // Remove from current List

                peopleYouMayKnowList;
                isNeedToRefresh = true;
              });
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;

    Container getListview(
        requestedTagModel, index, bool isSentRequest, status) {
      return Container(
          padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 5.0),
          child: Card(
              color: Colors.transparent,
              elevation: 0.0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  InkWell(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[




                        Expanded(
                          child: ProfileImageView(
                            imagePath:    Constant.IMAGE_PATH_SMALL +
                                ParseJson.getSmallImage(
                                    requestedTagModel.patner
                                        .profilePicture),
                            placeHolderImage: requestedTagModel.patner.partnerRoleId == "4"
                                ? "assets/profile/partner_img.png"
                                : 'assets/profile/user_on_user.png',
                            height: 50.0,
                            width: 50.0,
                            onTap: () async{
                              if (requestedTagModel.patner.userId ==
                                  userIdPref) {
                              } else {
                                Util.onTapImageTile(
                                    tapedUserRole:
                                    requestedTagModel.patner.roleId,
                                    partnerUserId:
                                    requestedTagModel.patner.userId,
                                    context: context);
                              }
                            },
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: BaseText(
                                          text:
                                              getName(null, requestedTagModel),
                                          textColor: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 18,
                                          maxLines: 1,
                                          textAlign: TextAlign.start,
                                        ),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        flex: 0,
                                        child: requestedTagModel
                                                    .patner.roleId ==
                                                "1"
                                            ? Util.getStudentBadge12(
                                                requestedTagModel.patner.badge,
                                                requestedTagModel
                                                    .patner.badgeImage)
                                            : Container(),
                                      ),
                                    ],
                                  ),
                                  requestedTagModel.patner.tagline == null ||
                                          requestedTagModel.patner.tagline ==
                                              "null" ||
                                          requestedTagModel.patner.tagline == ""
                                      ? Container(
                                          height: 0.0,
                                        )
                                      : PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          5.0,
                                          Row(
                                            children: <Widget>[
                                              Expanded(
                                                child: TextViewWrap.textView(
                                                  requestedTagModel.patner
                                                                  .tagline ==
                                                              null ||
                                                          requestedTagModel
                                                                  .patner
                                                                  .tagline ==
                                                              "null" ||
                                                          requestedTagModel
                                                                  .patner
                                                                  .tagline ==
                                                              ""
                                                      ? ""
                                                      : requestedTagModel
                                                          .patner.tagline,
                                                  TextAlign.start,
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  12.0,
                                                  FontWeight.normal,
                                                ),
                                                flex: 1,
                                              ),
                                            ],
                                          )),
                                ],
                              )),
                          flex: 1,
                        ),
                        Expanded(
                          child: Row(
                            children: <Widget>[
                              roleId == "2"
                                  ? isSentRequest
                                      ? Text("")
                                      : InkWell(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 0.0, 0.0),
                                              child: Container(
                                                  height: 45.0,
                                                  width: 45.0,
                                                  child: Image.asset(
                                                    'assets/newDesignIcon/connections/tick_blue.png',
                                                  ))),
                                          onTap: () {
                                            if (status != "") {
                                              apiCallingForAccept(
                                                  requestedTagModel.connectId,
                                                  index,
                                                  "Requested",
                                                  requestedTagModel
                                                      .userIsActive);
                                            } else {
                                              apiCallingForAccept(
                                                  requestedTagModel.connectId,
                                                  index,
                                                  "Accepted",
                                                  requestedTagModel
                                                      .userIsActive);
                                            }
                                          },
                                        )
                                  : listType == 1
                                      ? new Container(
                                          height: 0.0,
                                        )
                                      : InkWell(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 0.0, 0.0),
                                              child: Container(
                                                  height: 45.0,
                                                  width: 45.0,
                                                  child: Image.asset(
                                                    'assets/newDesignIcon/connections/tick_blue.png',
                                                  ))),
                                          onTap: () {
                                            if (status != "") {
                                              apiCallingForAccept(
                                                  requestedTagModel.connectId,
                                                  index,
                                                  "Requested",
                                                  requestedTagModel
                                                      .userIsActive);
                                            } else {
                                              apiCallingForAccept(
                                                  requestedTagModel.connectId,
                                                  index,
                                                  "Accepted",
                                                  requestedTagModel
                                                      .userIsActive);
                                            }
                                          },
                                        ),
                              listType == 4 && roleId == "1"
                                  ? Container(
                                      height: 0.0,
                                    )
                                  : InkWell(
                                      child: Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          child: Container(
                                              height: 35.0,
                                              width: 35.0,
                                              child: Image.asset(
                                                'assets/newDesignIcon/connections/cancel.png',
                                              ))),
                                      onTap: () {
                                        print("------- Cancel Button");

                                        String name =
                                            requestedTagModel.patner.lastName ==
                                                        null ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        "null" ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        ""
                                                ? requestedTagModel
                                                    .patner.firstName
                                                : requestedTagModel
                                                        .patner.firstName +
                                                    " " +
                                                    requestedTagModel
                                                        .patner.lastName;

                                        educationRemoveConfromationDialog(
                                            requestedTagModel.connectId,
                                            name,
                                            index);
                                      },
                                    )
                            ],
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                    onTap: () {
                      if (requestedTagModel.patner.userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: requestedTagModel.patner.roleId,
                            partnerUserId: requestedTagModel.patner.userId,
                            context: context);
                      }
                    },
                  )
//                   Padding(
//                      padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
//                      child: Divider(
//                        color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
//                        height: 0.0,
//                      )),
                ],
              )));
    }

    Container getListviewPending(
        requestedTagModel, index, bool isSentRequest, status) {
      return Container(
          padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 5.0),
          child: Card(
              color: Colors.transparent,
              elevation: 0.0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  InkWell(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          child: InkWell(
                            child: Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child:
                                    requestedTagModel.patner.profilePicture ==
                                                "null" ||
                                            requestedTagModel
                                                    .patner.profilePicture ==
                                                ""
                                        ? Image.asset(
                                            'assets/profile/user_on_user.png')
                                        : FadeInImage(
                                            fit: BoxFit.cover,
                                            placeholder: AssetImage(
                                              'assets/profile/user_on_user.png',
                                            ),
                                            image: NetworkImage(
                                                Constant.IMAGE_PATH_SMALL +
                                                    ParseJson.getSmallImage(
                                                        requestedTagModel.patner
                                                            .profilePicture)),
                                          ),
                              ),
                            ),
                            onTap: () {
                              print("partner roleId+++++" +
                                  requestedTagModel.partnerRoleId);
                              if (requestedTagModel.partnerId == userIdPref) {
                              } else {
                                Util.onTapImageTile(
                                    tapedUserRole:
                                        requestedTagModel.partnerRoleId,
                                    partnerUserId: requestedTagModel.partnerId,
                                    context: context);
                              }
                            },
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: TextViewWrap.textView(
                                            getName(null, requestedTagModel),
                                            TextAlign.left,
                                            ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        flex: 0,
                                        child: requestedTagModel
                                                    .patner.roleId ==
                                                "1"
                                            ? Util.getStudentBadge12(
                                                requestedTagModel.patner.badge,
                                                requestedTagModel
                                                    .patner.badgeImage)
                                            : Container(),
                                      ),
                                    ],
                                  ),
                                  roleId == "2"
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          0.0,
                                          RichText(
                                            maxLines: 1,
                                            textAlign: TextAlign.start,
                                            text: TextSpan(
                                              text: "For ",
                                              style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION,
                                                fontSize: 12.0,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                              ),
                                              children: <TextSpan>[
                                                TextSpan(
                                                    text: requestedTagModel
                                                                    .userData
                                                                    .lastName ==
                                                                null ||
                                                            requestedTagModel
                                                                    .userData
                                                                    .lastName ==
                                                                "null" ||
                                                            requestedTagModel
                                                                    .userData
                                                                    .lastName ==
                                                                ""
                                                        ? requestedTagModel
                                                            .userData.firstName
                                                        : requestedTagModel
                                                                .userData
                                                                .firstName +
                                                            " " +
                                                            requestedTagModel
                                                                .userData
                                                                .lastName,
                                                    style: TextStyle(
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMBOLD,
                                                        fontSize: 12.0,
                                                        color: ColorValues
                                                            .GREY_TEXT_COLOR))
                                              ],
                                            ),
                                          ))
                                      : PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          0.0,
                                          TextViewWrap.textViewMultiLine(
                                              requestedTagModel.status ==
                                                      "Pending"
                                                  ? "Your parent approval pending"
                                                  : "Pending",
                                              TextAlign.start,
                                              ColorValues.GREY_TEXT_COLOR,
                                              12.0,
                                              FontWeight.normal,
                                              1))
                                ],
                              )),
                          flex: 1,
                        ),
                        Expanded(
                          child: Row(
                            children: <Widget>[
                              roleId == "2"
                                  ? isSentRequest
                                      ? Text("")
                                      : InkWell(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 0.0, 0.0),
                                              child: Container(
                                                  height: 45.0,
                                                  width: 45.0,
                                                  child: Image.asset(
                                                    'assets/newDesignIcon/connections/tick_blue.png',
                                                  ))),
                                          onTap: () {
                                            if (status != "") {
                                              apiCallingForAccept(
                                                  requestedTagModel.connectId,
                                                  index,
                                                  "Requested",
                                                  requestedTagModel
                                                      .userIsActive);
                                            } else {
                                              apiCallingForAccept(
                                                  requestedTagModel.connectId,
                                                  index,
                                                  "Accepted",
                                                  requestedTagModel
                                                      .userIsActive);
                                            }
                                          },
                                        )
                                  : Container(
                                      height: 0.0,
                                    ),
                              InkWell(
                                child: Padding(
                                    padding:
                                        EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                    child: Container(
                                        height: 35.0,
                                        width: 35.0,
                                        child: Image.asset(
                                          'assets/newDesignIcon/connections/cancel.png',
                                        ))),
                                onTap: () {
                                  print("------- Cancel Button");

                                  String name = requestedTagModel
                                                  .patner.lastName ==
                                              null ||
                                          requestedTagModel.patner.lastName ==
                                              "null" ||
                                          requestedTagModel.patner.lastName ==
                                              ""
                                      ? requestedTagModel.patner.firstName
                                      : requestedTagModel.patner.firstName +
                                          " " +
                                          requestedTagModel.patner.lastName;

                                  educationRemoveConfromationDialog(
                                      requestedTagModel.connectId, name, index);
                                },
                              )
                            ],
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                    onTap: () {
                      if (requestedTagModel.patner.userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: requestedTagModel.patner.roleId,
                            partnerUserId: requestedTagModel.patner.userId,
                            context: context);
                      }
                    },
                  )
//                   Padding(
//                      padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
//                      child: Divider(
//                        color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
//                        height: 0.0,
//                      )),
                ],
              )));
    }

    Container recievetListView(
        requestedTagModel, index, bool isSentRequest, status) {
      return Container(
          padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 5.0),
          child: Card(
              color: Colors.transparent,
              elevation: 0.0,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  InkWell(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          child: InkWell(
                            child: Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child:
                                    requestedTagModel.userData.profilePicture ==
                                                "null" ||
                                            requestedTagModel
                                                    .userData.profilePicture ==
                                                ""
                                        ? Image.asset(
                                            'assets/profile/user_on_user.png')
                                        : FadeInImage(
                                            fit: BoxFit.cover,
                                            placeholder: AssetImage(
                                              'assets/profile/user_on_user.png',
                                            ),
                                            image: NetworkImage(
                                                Constant.IMAGE_PATH_SMALL +
                                                    ParseJson.getSmallImage(
                                                        requestedTagModel
                                                            .userData
                                                            .profilePicture)),
                                          ),
                              ),
                            ),
                            onTap: () {
                              if (requestedTagModel.userId == userIdPref) {
                              } else {
                                Util.onTapImageTile(
                                    tapedUserRole: requestedTagModel.userRoleId,
                                    partnerUserId: requestedTagModel.userId,
                                    context: context);
                              }
                            },
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: TextViewWrap.textView(
                                            getReciverName(requestedTagModel),
                                            TextAlign.left,
                                            ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        flex: 0,
                                        child:
                                            requestedTagModel.userData.roleId ==
                                                    "1"
                                                ? Util.getStudentBadge12(
                                                    requestedTagModel
                                                        .userData.badge,
                                                    requestedTagModel
                                                        .userData.badgeImage)
                                                : Container(),
                                      ),
                                    ],
                                  ),
                                  roleId == "2"
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          0.0,
                                          RichText(
                                            maxLines: 1,
                                            textAlign: TextAlign.start,
                                            text: TextSpan(
                                              text: "For ",
                                              style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION,
                                                fontSize: 12.0,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                fontWeight: FontWeight.normal,
                                              ),
                                              children: <TextSpan>[
                                                TextSpan(
                                                    text: requestedTagModel.patner
                                                                    .lastName ==
                                                                null ||
                                                            requestedTagModel.patner
                                                                    .lastName ==
                                                                "null" ||
                                                            requestedTagModel
                                                                    .patner
                                                                    .lastName ==
                                                                ""
                                                        ? requestedTagModel
                                                            .patner.firstName
                                                        : requestedTagModel
                                                                .patner
                                                                .firstName +
                                                            " " +
                                                            requestedTagModel
                                                                .patner
                                                                .lastName,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMBOLD,
                                                        fontSize: 12.0,
                                                        color: ColorValues
                                                            .GREY_TEXT_COLOR))
                                              ],
                                            ),
                                          ))
                                      : PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          5.0,
                                          0.0,
                                          0.0,
                                          TextViewWrap.textViewMultiLine(
                                              requestedTagModel.status ==
                                                      "Pending"
                                                  ? "Your parent approval pending"
                                                  : "Pending",
                                              TextAlign.start,
                                              ColorValues.GREY_TEXT_COLOR,
                                              12.0,
                                              FontWeight.normal,
                                              1))
                                ],
                              )),
                          flex: 1,
                        ),
                        Expanded(
                          child: Row(
                            children: <Widget>[
                              roleId == "2"
                                  ? isSentRequest
                                      ? Text("")
                                      : InkWell(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 0.0, 0.0),
                                              child: Container(
                                                  height: 45.0,
                                                  width: 45.0,
                                                  child: Image.asset(
                                                    'assets/newDesignIcon/connections/tick_blue.png',
                                                  ))),
                                          onTap: () {
                                            apiCallingForAccept(
                                                requestedTagModel.connectId,
                                                index,
                                                "Accepted",
                                                requestedTagModel.userIsActive);
                                          },
                                        )
                                  : Container(
                                      height: 0.0,
                                    ),
                              roleId == "1"
                                  ? Container(
                                      height: 0.0,
                                    )
                                  : InkWell(
                                      child: Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          child: Container(
                                              height: 35.0,
                                              width: 35.0,
                                              child: Image.asset(
                                                'assets/newDesignIcon/connections/cancel.png',
                                              ))),
                                      onTap: () {
                                        print("------- Cancel Button");

                                        String name = requestedTagModel
                                                        .userData.lastName ==
                                                    null ||
                                                requestedTagModel
                                                        .userData.lastName ==
                                                    "null" ||
                                                requestedTagModel
                                                        .userData.lastName ==
                                                    ""
                                            ? requestedTagModel
                                                .userData.firstName
                                            : requestedTagModel
                                                    .userData.firstName +
                                                " " +
                                                requestedTagModel
                                                    .userData.lastName;

                                        educationRemoveConfromationDialog(
                                            requestedTagModel.connectId,
                                            name,
                                            index);
                                      },
                                    )
                            ],
                          ),
                          flex: 0,
                        ),
                      ],
                    ),
                    onTap: () {
                      if (requestedTagModel.userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: requestedTagModel.userRoleId,
                            partnerUserId: requestedTagModel.userId,
                            context: context);
                      }
                    },
                  )
//                   Padding(
//                      padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
//                      child: Divider(
//                        color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
//                        height: 0.0,
//                      )),
                ],
              )));
    }

    Container getListViewForPeopleMayKnow(PeopleYouMayKnow, index) {
      return Container(
          padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 5.0),
          child: Card(
              color: Colors.transparent,
              elevation: 0.0,
              child: Column(
                children: <Widget>[
                  InkWell(
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: InkWell(
                            child: Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: PeopleYouMayKnow.profilePicture ==
                                            "null" ||
                                        PeopleYouMayKnow.profilePicture == ""
                                    ? Image.asset(
                                        'assets/profile/user_on_user.png')
                                    : FadeInImage(
                                        fit: BoxFit.cover,
                                        placeholder: AssetImage(
                                          'assets/profile/user_on_user.png',
                                        ),
                                        image: NetworkImage(
                                            Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getSmallImage(
                                                    PeopleYouMayKnow
                                                        .profilePicture)),
                                      ),
                              ),
                            ),
                            onTap: () {
                              if (PeopleYouMayKnow.userId == userIdPref) {
                              } else {
                                Util.onTapImageTile(
                                    tapedUserRole: PeopleYouMayKnow.roleId,
                                    partnerUserId: PeopleYouMayKnow.userId,
                                    context: context);
                              }
                            },
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              10.0,
                              0.0,
                              0.0,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: TextViewWrap.textView(
                                            getName(PeopleYouMayKnow, null),
                                            TextAlign.start,
                                            ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        flex: 0,
                                        child: PeopleYouMayKnow.roleId == "1"
                                            ? Util.getStudentBadge12(
                                                PeopleYouMayKnow.badge,
                                                PeopleYouMayKnow.badgeImage)
                                            : Container(),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: TextViewWrap.textView(
                                          PeopleYouMayKnow.tagline == null ||
                                                  PeopleYouMayKnow.tagline ==
                                                      "null" ||
                                                  PeopleYouMayKnow.tagline == ""
                                              ? ""
                                              : PeopleYouMayKnow.tagline,
                                          TextAlign.start,
                                          ColorValues.GREY_TEXT_COLOR,
                                          12.0,
                                          FontWeight.normal,
                                        ),
                                        flex: 1,
                                      ),
                                    ],
                                  ),
                                ],
                              )),
                          flex: 1,
                        ),
                        Expanded(
                          child: Row(children: <Widget>[
                            InkWell(
                              child: Column(
                                children: <Widget>[
                                  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          0.0, 0.0, 20.0, 0.0),
                                      child: Container(
                                          height: 30.0,
                                          width: 30.0,
                                          child: Image.asset(
                                            !PeopleYouMayKnow.isRequested
                                                ? 'assets/newDesignIcon/connections/send_repquest_gray.png'
                                                : 'assets/newDesignIcon/requested_new.png',
                                          ))),
                                  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          0.0, 2.0, 22.0, 0.0),
                                      child: Text(
                                        PeopleYouMayKnow.isRequested
                                            ? "Requested"
                                            : "Add Friend",
                                        style: TextStyle(
                                            fontFamily: Constant.customRegular,
                                            color: ColorValues.GREY_TEXT_COLOR,
                                            fontSize: 10.0),
                                      ))
                                ],
                              ),
                              onTap: () {
                                if (!PeopleYouMayKnow.isRequested) {
                                  apiCallForConnectForPeopleMayKnow(
                                      index,
                                      PeopleYouMayKnow.userId,
                                      PeopleYouMayKnow.roleId,
                                      PeopleYouMayKnow.isActive);
                                }
                              },
                            )
                          ]),
                          flex: 0,
                        ),
                      ],
                    ),
                    onTap: () {
                      if (PeopleYouMayKnow.userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: PeopleYouMayKnow.roleId,
                            partnerUserId: PeopleYouMayKnow.userId,
                            context: context);
                      }
                    },
                  ),
                  Padding(
                      padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
                      child: Divider(
                        color: Colors.transparent,
                        height: 0.0,
                      )),
                ],
              )));
    }

    Container getListviewReferl(requestedTagModel) {
      return Container(
          color: Colors.transparent,
          padding: EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
          child: Card(
              color: Colors.transparent,
              elevation: 0.0,
              child: Column(
                children: <Widget>[
                  InkWell(
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: InkWell(
                            child: Container(
                              height: 50.0,
                              width: 50.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: Image.asset(
                                    'assets/profile/user_on_user.png'),
                              ),
                            ),
                            onTap: () {},
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: TextViewWrap.textView(
                                            requestedTagModel.referredTo,
                                            TextAlign.left,
                                            ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        flex: 1,
                                      ),
                                    ],
                                  ),
                                ],
                              )),
                          flex: 1,
                        ),
                      ],
                    ),
                    onTap: () {},
                  ),
                ],
              )));
    }

    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          elevation: 0.0,
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: InkWell(
                  child: CustomViews.getBackButton(),
                  onTap: () {
                    Navigator.pop(context, isNeedToRefresh);
                  },
                ),
                flex: 0,
              ),
              Expanded(
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 18.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                flex: 1,
              )
            ],
          ),
          backgroundColor: Colors.white,
        ),
        body: Container(
            color: ColorValues.LIGHT_GRAY_BG,
            child: Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                Expanded(
                  child: ListView(
                    controller: _scrollController,
                    children: <Widget>[
                      listType == 3 || listType == 4 || listType == 5
                          ? Container(
                              height: 0.0,
                            )
                          : Padding(
                              padding:
                                  EdgeInsets.fromLTRB(14.0, 20.0, 5.0, 10.0),
                              child: Text(
                                  listType == 2
                                      ? "List of people you may know to connect with"
                                      : listType == 0
                                          ? "You have received below list of connections request(" +
                                              tagList.length.toString() +
                                              ")"
                                          : "You have sent below request(" +
                                              sendRequestList.length
                                                  .toString() +
                                              ")",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                      fontSize: 14.0,
                                      fontFamily: Constant.customRegular))),
                      listType == 5
                          ? Column(
                              children: List.generate(
                                  recievedRequestList.length, (int index) {
                                return recievetListView(
                                    recievedRequestList[index],
                                    index,
                                    roleId == "2" ? false : true,
                                    "Requested");
                              }),
                            )
                          : listType == 4
                              ? Column(
                                  children: List.generate(
                                      pendingRequestList.length, (int index) {
                                    return getListviewPending(
                                        pendingRequestList[index],
                                        index,
                                        roleId == "2" ? false : true,
                                        "Requested");
                                  }),
                                )
                              : listType == 3
                                  ? Column(
                                      children: List.generate(refferList.length,
                                          (int index) {
                                        return getListviewReferl(
                                            refferList[index]);
                                      }),
                                    )
                                  : listType == 2
                                      ? Column(
                                          children: List.generate(
                                              peopleYouMayKnowList.length,
                                              (int index) {
                                            return getListViewForPeopleMayKnow(
                                                peopleYouMayKnowList[index],
                                                index);
                                          }),
                                        )
                                      : listType == 0
                                          ? Column(
                                              children: List.generate(
                                                  tagList.length, (int index) {
                                                return getListview(
                                                    tagList[index],
                                                    index,
                                                    false,
                                                    "");
                                              }),
                                            )
                                          : Column(
                                              children: List.generate(
                                                  sendRequestList.length,
                                                  (int index) {
                                                return getListview(
                                                    sendRequestList[index],
                                                    index,
                                                    true,
                                                    "");
                                              }),
                                            )
                    ],
                  ),
                  flex: 1,
                )
              ],
            )),
      ),
    );
  }

  void educationRemoveConfromationDialog(id, name, index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        25.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
//

                                                  PaddingWrap.paddingfromLTRB(
                                                      20.0,
                                                      0.0,
                                                      20.0,
                                                      0.0,
                                                      RichText(
                                                        textAlign:
                                                            TextAlign.center,
                                                        text: TextSpan(
                                                          text:
                                                              'This connection request will be declined.',
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                        ),
                                                      )),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Remove",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              // Delete

                                              Navigator.pop(context);

                                              apiCallingForUnfriend(
                                                id,
                                                index,
                                              );
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  getReciverName(requestedTagModel) {
    String firstName = "", lastName = "";
    if (requestedTagModel.userData.lastName == null ||
        requestedTagModel.userData.lastName == "null" ||
        requestedTagModel.userData.lastName == "") {
      lastName = "";
    } else {
      lastName = requestedTagModel.userData.lastName;
    }

    if (requestedTagModel.userData.firstName == null ||
        requestedTagModel.userData.firstName == "null" ||
        requestedTagModel.userData.firstName == "") {
      firstName = requestedTagModel.userData.email;
    } else {
      firstName = requestedTagModel.userData.firstName;
    }

    return firstName + " " + lastName;
  }

  getName(PeopleYouMayKnow, requestedTagModel) {
    String firstName, lastName;

    if (PeopleYouMayKnow != null) {
      if (PeopleYouMayKnow.lastName == null ||
          PeopleYouMayKnow.lastName == "null" ||
          PeopleYouMayKnow.lastName == "") {
        lastName = "";
      } else {
        lastName = PeopleYouMayKnow.lastName;
      }

      if (PeopleYouMayKnow.firstName == null ||
          PeopleYouMayKnow.firstName == "null" ||
          PeopleYouMayKnow.firstName == "") {
        firstName = PeopleYouMayKnow.email;
      } else {
        firstName = PeopleYouMayKnow.firstName;
      }

      return firstName + " " + lastName;
    } else {
      if (requestedTagModel.patner.lastName == null ||
          requestedTagModel.patner.lastName == "null" ||
          requestedTagModel.patner.lastName == "") {
        lastName = "";
      } else {
        lastName = requestedTagModel.patner.lastName;
      }

      if (requestedTagModel.patner.firstName == null ||
          requestedTagModel.patner.firstName == "null" ||
          requestedTagModel.patner.firstName == "") {
        firstName = requestedTagModel.patner.email;
      } else {
        firstName = requestedTagModel.patner.firstName;
      }

      return firstName + " " + lastName;
    }
  }
}
