import 'dart:async';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:page_indicator/page_indicator.dart';

import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';

import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/CommentListWidget.dart';
import 'package:spike_view_project/home/LikeDetailWidget.dart';
import 'package:spike_view_project/home/SelectedGroup.dart';

import 'package:spike_view_project/home/TagDetailWidget.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';

import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';

import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:flutter/services.dart';

import 'package:spike_view_project/webview/WebViewWidget.dart';

class FeedDetailWidget extends StatefulWidget {
  String feedId, pageName;

  FeedDetailWidget(this.feedId, this.pageName);

  @override
  State<StatefulWidget> createState() {
    return FeedDetailWidgetState();
  }
}

class FeedDetailWidgetState extends State<FeedDetailWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isShowMore = false;
  bool isLoading = true;
  List<UserPostModal> userPostList = List<UserPostModal>();
  String dob;
  RegExp exp = RegExp(
      r"(http|ftp|https|Https|Http)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");

  Future apiCallingForAddComment(feedId, comment, userpostModal) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": feedId,
          "userId": int.parse(userIdPref),
          "comment": comment,
          "dateTime": DateTime
              .now()
              .millisecondsSinceEpoch,
          "name": "",
          "title": "",
          "profilePicture": "",
          "lastActivityTime": DateTime
              .now()
              .millisecondsSinceEpoch,
          "lastActivityType": "CommentOnFeed",
          "roleId": int.parse(roleId),
        };

        print("map+++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_FEED_COMMENT, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              userpostModal.isCommented = true;
              List<Likes> likesList = List();
              // userpostModal.commentList.add

              userpostModal.commentList.insert(
                  0,
                  CommentData(
                      response.data["result"]["commentId"].toString(),
                      comment,
                      userIdPref,
                      "few seconds ago",
                      roleId == "4"
                          ? prefs.getString(UserPreference.COMPANY_IMAGE_PATH)
                          : prefs.getString(UserPreference.PROFILE_IMAGE_PATH),
                      roleId == "4"
                          ? prefs.getString(UserPreference.COMPANY_NAME_PATH)
                          : prefs.getString(UserPreference.NAME),
                      "",
                      userIdPref,
                      likesList,
                      false,
                      roleId,
                      prefs.getString(UserPreference.badgeType),
                      prefs.getInt(UserPreference.gamificationPoints),
                      prefs.getString(UserPreference.badgeImage),
                      true));
              setState(() {
                userPostList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  showErrorMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>
            WillPopScope(
                onWillPop: () {},
                child: GestureDetector(
                  child: Scaffold(
                    backgroundColor: Colors.transparent,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            top: 55.0,
                            left: 0.0,
                            child: Container(
                              height: 65.0,
                              padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                              color: Color(0xffF1EDC3),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    RichText(
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.start,
                                      text: TextSpan(
                                        text: 'ERROR: ',
                                        style: TextStyle(
                                          color: Color(0xffFF0101),
                                          height: 1.2,
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        children: <TextSpan>[
                                          TextSpan(
                                            text: msg,
                                            style: TextStyle(
                                                color: Color(0xffFF0101),
                                                fontSize: 13.0,
                                                fontWeight: FontWeight.normal,
                                                fontFamily: Constant
                                                    .customRegular),
                                          )
                                        ],
                                      ),
                                    )
                                  ]),
                            )),
                      ],
                    ),
                  ),
                  onTap: () {},
                )));
  }

  Future apiCallingForUserPost() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {});
        print("userId" + userIdPref);
        print("feedPage response+++++++" +
            "ui/feed/detail?userId=" +
            userIdPref +
            "&roleId=" +
            roleId +
            "&feedId=" +
            widget.feedId);
        Response response = await ApiCalling().apiCall(
            context,
            "ui/feed/detail?userId=" +
                userIdPref +
                "&roleId=" +
                roleId +
                "&feedId=" +
                widget.feedId,
            "get");
        isLoading = false;
        setState(() {});
        print("feedPage response+++++++" +
            widget.feedId +
            "   " +
            response.toString());
        MessageConstant.printWrapped(response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              if (response.data['result'] == null) {
                //  ToastWrap. showToastWithPush(MessageConstant.AUTHOR_DELETED_POST,context);
                showErrorMsg(MessageConstant.AUTHOR_DELETED_POST, context);
              } else {
                userPostList.clear();
                userPostList.addAll(ParseJson.parseHome(
                    response.data['result'], userIdPref, roleId));
              }
            }
          }
        }
      } else {
        isLoading = false;
        setState(() {
          isLoading;
        });
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {});
      e.toString();
    }
  }

  Future apiCallingForAddLike(feedId, userpostModal) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        bool isLike = false;
        try {
          if (userpostModal.isLike) {
            isLike = false;
          } else {
            isLike = true;
          }
        }catch(e){
          isLike = true;
        }
        Map map = {
          "feedId": feedId,
          "userId": int.parse(userIdPref),
          "isLike": isLike,
          "roleId": int.parse(roleId),
          "lastActivityTime": DateTime
              .now()
              .millisecondsSinceEpoch,
          "lastActivityType": "LikeFeed"
        };

        print("map+++" + map.toString());

        Response response = await ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_ADD_LIKE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              if (userpostModal.isLike) {
                userpostModal.isLike = false;
                userpostModal.likeList.removeLast();
              } else {

                userpostModal.isLike = true;
                userpostModal.likeList.add(new Likes(
                    userIdPref,
                    roleId == "4"
                        ? prefs.getString(UserPreference.COMPANY_NAME_PATH)
                        : prefs.getString(UserPreference.NAME),
                    roleId == "4"
                        ? prefs.getString(UserPreference.COMPANY_IMAGE_PATH)
                        : prefs.getString(UserPreference.PROFILE_IMAGE_PATH),
                    "student",
                    "",
                    "",
                    prefs.getBool(UserPreference.IS_PARENT) ?? false
                        ? "2"
                        : "1",
                    prefs.getString(UserPreference.badgeType),
                    prefs.getInt(UserPreference.gamificationPoints),
                    prefs.getString(UserPreference.badgeImage)));
              }
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print('errror++++'+e.toString());
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    apiCallingForUserPost();
  }

  onBack() async {
    if (widget.pageName == "") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);

      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                DashBoardWidgetParent(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>
                DashBoardWidget(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context);
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    print("++++++++++++shubham++++++");
    super.initState();
  }

  onAddComment(feedId, comment, userPostModal) {
    apiCallingForAddComment(feedId, comment, userPostModal);
    print("Comments : " + comment + "feedid:- $feedId");
  }

  void onTapLike(userPostModal) {
    print("onTapLike+++++++++++++");


    apiCallingForAddLike(userPostModal.feedId, userPostModal);
  }

  onTapLikeText(userPostModal) {
    print(userPostModal.likeList);
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            LikeDetailWidget(userPostModal.likeList, userIdPref)));
  }

  Widget _loader(BuildContext context) =>
      Center(
          child: Container(
            child: Image.asset(
              "assets/aerial/feed_default_img.png",
              fit: BoxFit.cover,
            ),
          ));

  Widget _error() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill,
      ),
    );
  }

  onTapImageTile(tapedUserId, roleId) {
    if (tapedUserId == userIdPref) {} else {
      Util.onTapImageTile(
          tapedUserRole: roleId,
          partnerUserId: tapedUserId,
          context: context);
    }
  }

  void onTapViewAllComments(commentList, feedId, userPostModel) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            CommentListWidget(
                commentList,
                prefs.getString(UserPreference.PROFILE_IMAGE_PATH),
                feedId,
                prefs.getString(UserPreference.NAME),
                userPostModel,
                userIdPref,
                roleId,
                prefs.getString(UserPreference.badgeType),
                prefs.getInt(UserPreference.gamificationPoints),
                prefs.getString(UserPreference.badgeImage))));

    if (result == "push") {
      // apiCallingForUserPost();
    }
  }

  Widget imageViewforOpportunityStack(userPostModal) {
    return
      Container(
          decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/feed/background_imageview.png"),
              fit: BoxFit.cover,
            ),),
          child:
          PaddingWrap.paddingfromLTRB(
              17.0,
              20.0,
              10.0,
              10.0,
              Row(
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: Container(
                          child: Center(
                              child: Container(
                                  width: 50.0,
                                  height: 50.0,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: ColorValues.WHITE, width: 1),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(10))),
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(10),
                                      child: FadeInImage.assetNetwork(
                                        fit: BoxFit.cover,
                                        width: double.infinity,
                                        placeholder:
                                        userPostModal.postOwnerRoleId == "4"
                                            ? "assets/profile/partner_img.png"
                                            : 'assets/profile/user_on_user.png',
                                        image: Constant.IMAGE_PATH_SMALL +
                                            ParseJson.getSmallImage(
                                                userPostModal
                                                    .postOwnerProfilePicture),
                                      ))))),
                      onTap: () {
                        onTapImageTile(
                            userPostModal.postOwner,
                            userPostModal.postOwnerRoleId);
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        8.0,
                        0.0,
                        15.0,
                        0.0,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            InkWell(
                              child: Container(
                                  child: RichText(
                                    maxLines: 2,
                                    textAlign: TextAlign.start,
                                    text: TextSpan(
                                      text: userPostModal.postOwnerLastName ==
                                          "null"
                                          ? userPostModal.postOwnerFirstName
                                          : userPostModal.postOwnerFirstName +
                                          " " +
                                          userPostModal.postOwnerLastName,
                                      style: TextStyle(
                                        color: ColorValues.WHITE,
                                        fontSize: 16.0,
                                        fontFamily: Constant.latoRegular,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      children: userPostModal.tagList
                                          .length == 0
                                          ? [
                                        WidgetSpan(
                                          child: userPostModal
                                              .postOwnerRoleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .postOwnerBadge,
                                              userPostModal
                                                  .postOwnerBadgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        )
                                      ]
                                          : [
                                        WidgetSpan(
                                          child: userPostModal
                                              .postOwnerRoleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .postOwnerBadge,
                                              userPostModal
                                                  .postOwnerBadgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                        TextSpan(
                                            text: ' with ',
                                            style: TextStyle(
                                              color: ColorValues.WHITE,
                                              fontSize: 14.0,
                                              fontFamily: Constant
                                                  .latoRegular,
                                              fontWeight: FontWeight.w500,
                                            )),
                                        TextSpan(
                                          text: userPostModal.tagList[0]
                                              .name ==
                                              null ||
                                              userPostModal.tagList[0].name ==
                                                  "null"
                                              ? ""
                                              : userPostModal.tagList[0].name,
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: ' and ',
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontFamily:
                                            Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontFamily:
                                            Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: (userPostModal
                                              .tagList.length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontFamily:
                                            Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontFamily:
                                            Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: " others ",
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontFamily:
                                            Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontFamily:
                                            Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  )),
                              onTap: () {
                                if (userPostModal.tagList.length > 0) {
                                  Navigator.of(context).push(
                                      new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              TagDetailWidget(
                                                  userPostModal.tagList)));
                                } else {
                                  print("clicked");
                                  onTapImageTile(userPostModal.postOwner,
                                      userPostModal.postOwnerRoleId);
                                }
                              },
                            ),
                            TextViewWrap.textView(
                                userPostModal.shareTime,
                                TextAlign.center,
                                ColorValues.WHITE,
                                12.0,
                                FontWeight.normal),
                          ],
                        )),
                    flex: 4,
                  )
                ],
              )));
  }

  Padding getListViewPostForOpportuntiy(UserPostModal userPostModal, index) {
    return PaddingWrap.paddingAll(
      0.0,
      Card(
        elevation: 0.0,
        color: ColorValues.WHITE,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // getEvent(userPostModal),
            PaddingWrap.paddingfromLTRB(
                11.0,
                10.0,
                11.0,
                10.0,
                Row(
                  children: <Widget>[
                    Expanded(
                      child: InkWell(
                        child: Center(
                            child: Container(
                                width: 50.0,
                                height: 50.0,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: AppConstants
                                            .colorStyle.darkBlue,
                                        width: 1),
                                    borderRadius:
                                    const BorderRadius.all(
                                        Radius.circular(10))),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(
                                        10),
                                    child: FadeInImage.assetNetwork(
                                      fit: BoxFit.cover,
                                      width: double.infinity,
                                      placeholder: userPostModal
                                          .postOwnerRoleId ==
                                          "4"
                                          ? "assets/profile/partner_img.png"
                                          : 'assets/profile/user_on_user.png',
                                      image: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getSmallImage(
                                              userPostModal
                                                  .profilePicture),
                                    )))),
                        onTap: () {
                          onTapImageTile(userPostModal.postOwner,
                              userPostModal.postOwnerRoleId);
                        },
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          8.0,
                          0.0,
                          15.0,
                          0.0,
                          Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              InkWell(
                                child: Container(
                                    child: RichText(
                                      maxLines: 2,
                                      textAlign: TextAlign.start,
                                      text: TextSpan(
                                        text: userPostModal.lastName ==
                                            null ||
                                            userPostModal.lastName ==
                                                "null"
                                            ? userPostModal.firstName
                                            : userPostModal.firstName +
                                            " " +
                                            userPostModal.lastName,
                                        style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 16.0,
                                          fontFamily: Constant
                                              .latoRegular,
                                        ),
                                        children: [
                                          WidgetSpan(
                                            child: userPostModal
                                                .roleId ==
                                                "1"
                                                ? Util
                                                .getStudentBadgeRichTextWithPadding(
                                                userPostModal.badge,
                                                userPostModal
                                                    .badgeImage)
                                                : Container(
                                              height: 0.0,
                                              width: 0.0,
                                            ),
                                          ),
                                          TextSpan(
                                              text: ' shared ',
                                              style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontFamily:
                                                Constant.latoRegular,
                                                fontWeight:
                                                FontWeight.normal,
                                              )),
                                          TextSpan(
                                            text: userPostModal
                                                .postOwnerLastName ==
                                                ""
                                                ? userPostModal
                                                .postOwnerFirstName
                                                .trim() +
                                                "'s"
                                                : userPostModal
                                                .postOwnerFirstName +
                                                " " +
                                                userPostModal
                                                    .postOwnerLastName
                                                    .toString()
                                                    .trim() +
                                                "'s",
                                            style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontFamily:
                                              Constant.latoRegular,
                                              fontWeight: FontWeight
                                                  .bold,
                                            ),
                                          ),
                                          TextSpan(
                                            text: " post",
                                            style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontFamily:
                                              Constant.latoRegular,
                                              fontWeight: FontWeight
                                                  .normal,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )),
                                onTap: () {
                                  onTapImageTile(userPostModal.postedBy,
                                      userPostModal.roleId);
                                },
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 5, 0, 0),
                                child: Row(
                                  children: [
                                    TextViewWrap.textView(
                                        userPostModal.dateTime,
                                        TextAlign.center,
                                        ColorValues.labelColor,
                                        12.0,
                                        FontWeight.normal),
                                    userIdPref ==
                                        userPostModal
                                            .postedBy &&
                                        roleId ==
                                            userPostModal.roleId
                                                .toString()
                                        ? PaddingWrap.paddingfromLTRB(
                                        10.0,
                                        0.0,
                                        5.0,
                                        0.0,
                                        Image.asset(
                                          userPostModal
                                              .visibility ==
                                              "Private"
                                              ? "assets/profile/post/private_new.png"
                                              : userPostModal
                                              .visibility ==
                                              "SelectedConnections"
                                              ? "assets/profile/post/selected_connection.png"
                                              : userPostModal
                                              .visibility ==
                                              "AllConnections"
                                              ? "assets/profile/post/connection.png"
                                              : userPostModal
                                              .visibility ==
                                              "Group"
                                              ? "assets/profile/post/group_data.png"
                                              : "assets/profile/post/community.png",
                                          width: 13.0,
                                          color: userPostModal
                                              .visibility ==
                                              "SelectedConnections"
                                              ? null
                                              : ColorValues
                                              .GREY_TEXT_COLOR,
                                          height: 13.0,
                                        ))
                                        : Container(height: 0.0),
                                  ],
                                ),
                              )
                            ],
                          )),
                      flex: 4,
                    ),
                    Expanded(
                      child: userIdPref == userPostModal.postedBy &&
                          roleId == userPostModal.roleId.toString()
                          ? Container(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 30.0),
                          child: InkWell(
                            child: Image.asset(
                              "assets/feed/three_dot_blue.png",
                              width: 16.0,
                              height: 16.0,
                            ),
                            onTap: () {
                              // optionMenuDelete(userPostModal, index);

                            },
                          ))
                          : Container(
                          padding: EdgeInsets.fromLTRB(
                              0.0, 0.0, 0.0, 30.0),
                          child: InkWell(
                            child: Image.asset(
                              "assets/feed/three_dot_blue.png",
                              width: 16.0,
                              height: 16.0,
                            ),
                            onTap: () {
                              // optionForReport(userPostModal, index);

                            },
                          )),
                      flex: 0,
                    )
                  ],
                )),
            userPostModal.shareText == "null" ||
                userPostModal.shareText == ""
                ? Container(
              height: 0.0,
            )
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                  0.0,
                  10.0,
                  10.0,
                  0.0,
                  userPostModal.shareText == "" ||
                      userPostModal.shareText == "null" ||
                      userPostModal.shareText == "\n"
                      ? Container(
                    height: 0.0,
                  )
                      : PaddingWrap.paddingfromLTRB(
                      10.0,
                      0.0,
                      0.0,
                      0.0,
                      userPostModal.isShareMore
                          ? Container(
                        child: Linkify(
                          onOpen: (link) async {

                          },
                          text: userPostModal.shareText,
                          style: TextStyle(
                              color: ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                              Constant.latoRegular,
                              fontSize: 14.0),
                          linkStyle: TextStyle(
                              color: ColorValues
                                  .BLUE_COLOR_BOTTOMBAR,
                              fontFamily: Constant
                                  .TYPE_CUSTOMREGULAR,
                              fontSize: 14.0),
                        ),
                      )
                          : Container(
                        child: Linkify(
                          onOpen: (link) async {

                          },
                          text: userPostModal.shareText,
                          style: TextStyle(
                              color: ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                              Constant.latoRegular,
                              fontSize: 14.0),
                          linkStyle: TextStyle(
                              color: ColorValues
                                  .BLUE_COLOR_BOTTOMBAR,
                              fontFamily: Constant
                                  .TYPE_CUSTOMREGULAR,
                              fontSize: 14.0),
                        ),
                      )),
                ),
              ],
            ),
            userPostModal.postOwnerDeleted
                ? PaddingWrap.paddingfromLTRB(
                11.0,
                5.0,
                11.0,
                5.0,
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                      color: ColorValues
                          .OPPORTUNITY_GROUP_SELECTION_GRP,
                      border: Border.all(
                          width: 0.5,
                          color: ColorValues.GREY__COLOR_DIVIDER)),
                  child: PaddingWrap.paddingfromLTRB(
                      11.0,
                      17.0,
                      11.0,
                      16.0,
                      Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          TextViewWrap.textView(
                              "You can’t see this post",
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              14.0,
                              FontWeight.bold),
                          TextViewWrap.textView(
                              MessageConstant.AUTHOR_DELETED_POST,
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              14.0,
                              FontWeight.normal)
                        ],
                      )),
                ))
                : PaddingWrap.paddingfromLTRB(
                11.0,
                5.0,
                11.0,
                5.0,
                Container(
                  // decoration: BoxDecoration(
                  //     border: Border.all(
                  //         width: 0.1, color: Colors.black)),
                    child: Stack(
                      // crossAxisAlignment: CrossAxisAlignment.start,
                      // mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          child: Container(
                            width: double.infinity,
                            child: Card(
                              elevation: 0.0,
                              shape: RoundedRectangleBorder(
                                  borderRadius:
                                  BorderRadius.circular(0.0)),
                              color: ColorValues.WHITE,
                              child: Column(
                                children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      10.0,
                                      0.0,
                                      0.0,
                                      //
                                      userPostModal
                                          .opportunityModelForFeed
                                          .assestVideoAndImage
                                          .length >
                                          0
                                          ? SizedBox(
                                        // Pager view
                                          height: 250.0,
                                          child:
                                          PageIndicatorContainer(
                                            pageView:
                                            PageView.builder(
                                              itemCount: userPostModal
                                                  .opportunityModelForFeed
                                                  .assestVideoAndImage
                                                  .length,
                                              controller:
                                              PageController(),
                                              itemBuilder: (context,
                                                  index2) {
                                                return Stack(
                                                  children: <
                                                      Widget>[
                                                    userPostModal
                                                        .opportunityModelForFeed
                                                        .assestVideoAndImage[
                                                    index2]
                                                        .type ==
                                                        "image"
                                                        ? Container(
                                                      decoration:
                                                      BoxDecoration(
                                                        color:
                                                        Colors.black,
                                                      ),
                                                      child:
                                                      CachedNetworkImage(
                                                        width:
                                                        double.infinity,
                                                        height:
                                                        250.0,
                                                        imageUrl:
                                                        Constant
                                                            .IMAGE_PATH +
                                                            userPostModal
                                                                .opportunityModelForFeed
                                                                .assestVideoAndImage[index2]
                                                                .file,
                                                        fit: BoxFit
                                                            .contain,
                                                        placeholder: (context,
                                                            url) =>
                                                            _loader(
                                                                context),
                                                        errorWidget: (context,
                                                            url,
                                                            error) =>
                                                            _error(),
                                                      ),
                                                    )
                                                        : InkWell(
                                                        child:
                                                        Container(
                                                          decoration:
                                                          BoxDecoration(
                                                            color:
                                                            Colors
                                                                .black,
                                                            borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                                0),
                                                          ),
                                                          height:
                                                          250.0,
                                                          child:
                                                          Center(
                                                            child: VideoPlayPause(
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .assestVideoAndImage[index2]
                                                                    .file,
                                                                "",
                                                                true),
                                                          ),
                                                        )),
                                                    userPostModal
                                                        .opportunityModelForFeed
                                                        .assestVideoAndImage
                                                        .length ==
                                                        1 ||
                                                        userPostModal
                                                            .opportunityModelForFeed
                                                            .assestVideoAndImage[index2]
                                                            .type ==
                                                            "video"
                                                        ? Container(
                                                      height:
                                                      0.0,
                                                    )
                                                        : InkWell(
                                                        onTap:
                                                            () {
                                                          Navigator.of(
                                                              context)
                                                              .push(
                                                              new MaterialPageRoute(
                                                                  builder: (
                                                                      BuildContext context) =>
                                                                      CommonFullViewWidget(
                                                                          userPostModal
                                                                              .opportunityModelForFeed
                                                                              .assestVideoAndImage,
                                                                          MessageConstant
                                                                              .HOME_OPPORTUNITY_HEDING,
                                                                          index2,
                                                                          MessageConstant
                                                                              .COMPANY_PROFILE_HEDING)));
                                                        },
                                                        child:
                                                        Container(
                                                          height:
                                                          250.0,
                                                          width:
                                                          double
                                                              .infinity,
                                                          child:
                                                          Image.asset(
                                                            "assets/newDesignIcon/navigation/layer_image.png",
                                                            fit:
                                                            BoxFit.fill,
                                                          ),
                                                        ))
                                                  ],
                                                );
                                              },
                                              onPageChanged:
                                                  (index) {},
                                            ),
                                            align: IndicatorAlign
                                                .bottom,
                                            length: userPostModal
                                                .opportunityModelForFeed
                                                .assestVideoAndImage
                                                .length,
                                            indicatorSpace: 10.0,
                                            indicatorColor: userPostModal
                                                .opportunityModelForFeed
                                                .assestVideoAndImage
                                                .length ==
                                                1
                                                ? Colors.transparent
                                                : Color(0xffc4c4c4),
                                            indicatorSelectorColor:
                                            userPostModal
                                                .opportunityModelForFeed
                                                .assestVideoAndImage
                                                .length ==
                                                1
                                                ? Colors
                                                .transparent
                                                : Color(
                                                0XFFFFFFFF),
                                            shape: IndicatorShape
                                                .circle(size: 5.0),
                                          ))
                                          : Stack(children: <Widget>[
                                        Image.asset(
                                          "assets/profile/default_achievement.png",
                                          fit: BoxFit.cover,
                                          height: 280.0,
                                          width: double.infinity,
                                        ),
                                        Container(
                                          height: 280.0,
                                          color: Colors.black54
                                              .withOpacity(.4),
                                        )
                                      ])),
                                ],
                              ),
                            ),
                          ),
                          onTap: () {

                          },
                        ),

                        imageViewforOpportunityStack(userPostModal),
                      ],
                    ))),
            Row(children: <Widget>[
              Expanded(
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                        20.0, 5.0, 10.0, 10.0),
                    child: Text(
                      userPostModal.opportunityModelForFeed.offerId ==
                          "4" ||
                          userPostModal
                              .opportunityModelForFeed.offerId ==
                              "5"
                          ? userPostModal
                          .opportunityModelForFeed.serviceTitle
                          : userPostModal
                          .opportunityModelForFeed.jobTitle,
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontSize: 14.0,
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.w400),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                flex: 1,
              ),
            ]),

            Padding(
              padding: const EdgeInsets.only(left: 20, top: 5),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  InkWell(
                    onTap: () {
                      onTapLike(userPostModal);
                    },
                    child: userPostModal.isLike
                        ? Image.asset(
                      "assets/feed/heart_red.png",
                      height: 22.0,
                      width: 22.0,
                    )
                        : Image.asset(
                      "assets/feed/heart_blue.png",
                      height: 22.0,
                      width: 22.0,
                    ),
                  ),
                  SizedBox(
                    width: 7,
                  ),
                  InkWell(
                    onTap: () {
                      if (userPostModal.isShowCommentIcon)
                        userPostModal.isShowCommentIcon = false;
                      else {
                        userPostModal.isShowCommentIcon = true;
                      }

                      setState(() {});
                    },
                    child: Image.asset(
                      "assets/feed/comment.png",
                      height: 26.0,
                      width: 26.0,
                    ),
                  ),

                  Spacer(),
                  // Padding(
                  //   padding: const EdgeInsets.only(
                  //     right: 20,
                  //   ),
                  //   child: InkWell(
                  //     onTap: () {
                  //       print("sss like");
                  //     },
                  //     child: Image.asset(
                  //       "assets/feed/save_icon_border.png",
                  //       height: 12.0,
                  //       width: 12.0,
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),
            Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 5, 0, 0),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: (userPostModal?.likesCount ?? -1) > 0
                          ? PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          10.0,
                          0.0,
                          InkWell(
                            child: TextViewWrap.textView(
                                userPostModal.likesCount ==
                                    0
                                    ? "Like"
                                    : userPostModal.likesCount ==
                                    1
                                    ? "1 Like"
                                    : userPostModal.likesCount
                                    .toString() +
                                    " Likes",
                                TextAlign.end,
                                ColorValues.labelColor,
                                12.0,
                                FontWeight.w500),
                            onTap: () {
                              onTapLikeText(userPostModal);
                            },
                          ))
                          : const SizedBox.shrink(),
                      flex: 0,
                    ),
                    userPostModal?.commentList?.isNotEmpty ?? false
                        ? InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textView(
                            userPostModal.commentList
                                .length ==
                                0
                                ? "Comment"
                                : "" +
                                userPostModal
                                    .commentList
                                    .length
                                    .toString() +
                                " Comments",
                            TextAlign.left,
                            ColorValues.labelColor,
                            12.0,
                            FontWeight.w500),
                      ),
                      onTap: () {
                        onTapViewAllComments(
                            userPostModal.commentList,
                            userPostModal.feedId,
                            userPostModal);
                      },
                    )
                        : const SizedBox.shrink(),
                  ],
                )
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                // Comment List view
                Padding(
                    padding: EdgeInsets.fromLTRB(
                        0.0, 5.0, 0.0, 0.0),
                    child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: List.generate(
                            userPostModal.commentList
                                .length >
                                3
                                ? 3
                                : userPostModal.commentList
                                .length, (int index) {
                          return PaddingWrap
                              .paddingfromLTRB(
                              10.0,
                              5.0,
                              10.0,
                              0.0,
                              Row(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                                children: <Widget>[
                                  InkWell(
                                      child: Container(
                                          width: 40.0,
                                          height: 40.0,
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: AppConstants
                                                      .colorStyle
                                                      .darkBlue,
                                                  width:
                                                  1),
                                              borderRadius: const BorderRadius
                                                  .all(
                                                  Radius.circular(
                                                      10))),
                                          child:
                                          ClipRRect(
                                              borderRadius: BorderRadius
                                                  .circular(10),
                                              child:
                                              FadeInImage
                                                  .assetNetwork(
                                                fit: BoxFit
                                                    .cover,
                                                width: double
                                                    .infinity,
                                                placeholder: userPostModal
                                                    .commentList[index]
                                                    .roleId ==
                                                    "4"
                                                    ? "assets/profile/partner_img.png"
                                                    : 'assets/profile/user_on_user.png',
                                                image: Constant
                                                    .IMAGE_PATH_SMALL +
                                                    userPostModal
                                                        .commentList[index]
                                                        .profilePicture,
                                              ))),
                                      onTap: () {
                                        onTapImageTile(
                                            userPostModal
                                                .commentList[
                                            index]
                                                .commentedBy,
                                            userPostModal
                                                .commentList[
                                            index]
                                                .roleId);
                                      }), // User Image
                                  SizedBox(
                                    width: 20.0,
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment
                                          .start,
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .start,
                                      children: <
                                          Widget>[
                                        Padding(
                                          padding:
                                          const EdgeInsets
                                              .fromLTRB(
                                              0,
                                              0,
                                              0,
                                              0),
                                          child:
                                          Container(
                                              child:
                                              Row(
                                                children: <
                                                    Widget>[
                                                  RichText(
                                                    maxLines:
                                                    2,
                                                    textAlign:
                                                    TextAlign.start,
                                                    text:
                                                    TextSpan(
                                                      text: userPostModal
                                                          .commentList[index]
                                                          .name,
                                                      style:
                                                      TextStyle(
                                                        color:
                                                        ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontSize:
                                                        14.0,
                                                        fontWeight:
                                                        FontWeight
                                                            .bold,
                                                      ),
                                                    ),
                                                  ),
                                                  userPostModal
                                                      .commentList[index] !=
                                                      null &&
                                                      userPostModal
                                                          .commentList[index]
                                                          .roleId ==
                                                          "1"
                                                  //true
                                                      ? Util
                                                      .getStudentBadge12(
                                                      userPostModal
                                                          .commentList[index]
                                                          .badge,
                                                      userPostModal
                                                          .commentList[index]
                                                          .badgeImage)
                                                      : Container(),
                                                ],
                                              )),
                                        ),
                                        Container(
                                          child:
                                          Linkify(
                                            onOpen:
                                                (link) async {
                                              Navigator.of(context,
                                                  rootNavigator: true)
                                                  .push(
                                                  new MaterialPageRoute(
                                                      fullscreenDialog:
                                                      true,
                                                      builder: (
                                                          BuildContext context) =>
                                                          WebViewWidget(
                                                              link
                                                                  .url,
                                                              "spikeview")));
                                            },
                                            text: userPostModal
                                                .commentList[
                                            index]
                                                .comment,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize:
                                                14.0,
                                                fontWeight:
                                                FontWeight
                                                    .normal,
                                                fontFamily:
                                                Constant
                                                    .TYPE_CUSTOMREGULAR),
                                            linkStyle: TextStyle(
                                                color: ColorValues
                                                    .BLUE_COLOR_BOTTOMBAR,
                                                fontFamily:
                                                Constant
                                                    .TYPE_CUSTOMREGULAR,
                                                fontSize:
                                                14.0),
                                          ),
                                        ),
                                        Padding(
                                            padding: EdgeInsets
                                                .fromLTRB(
                                                0.0,
                                                5.0,
                                                0.0,
                                                0.0),
                                            child: Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .center,
                                              children: <
                                                  Widget>[
                                                Expanded(
                                                  child:
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: <
                                                        Widget>[
                                                      Text(
                                                        userPostModal
                                                            .commentList[index]
                                                            .dateTime,
                                                        textAlign: TextAlign
                                                            .end,
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .GREY_TEXT_COLOR,
                                                            fontSize: 12.0,
                                                            fontFamily: Constant
                                                                .customRegular),
                                                      )
                                                    ],
                                                  ),
                                                  flex:
                                                  0,
                                                ),
                                                Container(
                                                  width:
                                                  10.0,
                                                ),
                                                Expanded(
                                                  child: userIdPref ==
                                                      userPostModal
                                                          .commentList[index]
                                                          .commentedBy //&& userPostModal.commentList[index].isComment
                                                      ? InkWell(
                                                    child: Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(
                                                          0.0, 0, 0,
                                                          0),
                                                      child: Image
                                                          .asset(
                                                        "assets/feed/three_dot_blue.png",
                                                        width: 15.0,
                                                        height: 15.0,
                                                      ),
                                                    ),
                                                    onTap: () {
                                                      //optionForDelete(userPostModal.commentList, userPostModal.feedId, userPostModal, userPostModal.commentList[index].commentId, index);
                                                    },
                                                  )
                                                      : Container(
                                                    height: 1.0,
                                                  ),
                                                  flex:
                                                  0,
                                                )
                                              ],
                                            )),
                                      ],
                                    ),
                                    flex: 1,
                                  ) // Comment List Cell
                                ],
                              ));
                        }))),

                // View All Comments
                userPostModal.commentList.length > 3
                    ? InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                    10.0,
                    0.0,
                    0.0,
                    5.0,
                    TextViewWrap.textView(
                        "View All " +
                            userPostModal
                                .commentList.length
                                .toString() +
                            " Comments",
                        TextAlign.left,
                        ColorValues.labelColor,
                        12.0,
                        FontWeight.w500),
                  ),
                  onTap: () {
                    onTapViewAllComments(
                        userPostModal.commentList,
                        userPostModal.feedId,
                        userPostModal);
                  },
                )
                    : Container(
                  height: 0.0,
                ),

                // Comment Edit Text
                userPostModal.isShowCommentIcon
                    ? PaddingWrap.paddingAll(
                    10.0,
                    Row(
                      children: <Widget>[
                        //Alok Code Done
                        Container(
                          width: 40.0,
                          height: 40.0,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: AppConstants
                                      .colorStyle
                                      .darkBlue,
                                  width: 1),
                              borderRadius:
                              const BorderRadius
                                  .all(
                                  Radius.circular(10))),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: FadeInImage
                                .assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: roleId == "4"
                                  ? "assets/profile/partner_img.png"
                                  : 'assets/profile/user_on_user.png',
                              image: roleId == "4"
                                  ?
                              Constant.IMAGE_PATH +
                                  prefs.getString(
                                      UserPreference
                                          .COMPANY_IMAGE_PATH)
                                  : Constant.IMAGE_PATH +
                                  prefs.getString(
                                      UserPreference
                                          .PROFILE_IMAGE_PATH),
                              height: 45.0,
                              width: 45.0,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 20.0,
                        ),
                        Expanded(
                            child: Container(
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 1.0,
                                        color: ColorValues
                                            .LIGHT_GREY_TEXT_COLOR)),
                                child: Row(
                                  crossAxisAlignment:
                                  CrossAxisAlignment
                                      .center,
                                  mainAxisAlignment:
                                  MainAxisAlignment
                                      .center,
                                  children: <Widget>[
                                    Expanded(
                                      child: TextField(
                                        controller:
                                        userPostModal
                                            .txtController,
                                        style: TextStyle(
                                            fontFamily:
                                            Constant
                                                .TYPE_CUSTOMREGULAR),
                                        keyboardType:
                                        TextInputType
                                            .text,
                                        textCapitalization:
                                        TextCapitalization
                                            .sentences,
                                        maxLines: null,
                                        maxLength:
                                        TextLength
                                            .COMMENT_MAX_LENGTH,
                                        onChanged: (s) {
                                          if (s
                                              .trim()
                                              .length >
                                              0) {
                                            userPostModal
                                                .isCommentIconVisible =
                                            true;
                                          } else {
                                            userPostModal
                                                .isCommentIconVisible =
                                            false;
                                          }
                                          setState(() {});
                                        },
                                        decoration:
                                        InputDecoration(
                                          border:
                                          InputBorder
                                              .none,
                                          filled: true,
                                          counterStyle:
                                          TextStyle(
                                              fontFamily:
                                              Constant
                                                  .TYPE_CUSTOMREGULAR),
                                          counterText:
                                          "",
                                          hintText: roleId ==
                                              "4"
                                              ? "Add Comment as " +
                                              prefs.getString(
                                                  UserPreference
                                                      .COMPANY_NAME_PATH)
                                              : "Add Comment as " +
                                              prefs.getString(
                                                  UserPreference
                                                      .NAME)
                                                  .replaceAll(
                                                  "null",
                                                  ""),
                                          hintStyle: TextStyle(
                                              color: ColorValues
                                                  .GREY_TEXT_COLOR,
                                              fontSize:
                                              14.0,
                                              fontFamily:
                                              Constant
                                                  .TYPE_CUSTOMREGULAR),
                                          fillColor: Colors
                                              .transparent,
                                        ),
                                      ),
                                      flex: 4,
                                    ),
                                    Expanded(
                                      child:
                                      /*userPostModal
                                                    .isCommentIconVisible
                                                ?*/
                                      InkWell(
                                        child: PaddingWrap
                                            .paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            5.0,
                                            0.0,
                                            Image
                                                .asset(
                                              "assets/feed/sent_icon.png",
                                              width:
                                              22.0,
                                              height:
                                              22.0,
                                            )),
                                        onTap: () {
                                          if (userPostModal
                                              .isCommentIconVisible) {
                                            FocusScope.of(
                                                context)
                                                .requestFocus(
                                                FocusNode());
                                            userPostModal
                                                .isCommentIconVisible =
                                            false;
                                            onAddComment(
                                                userPostModal
                                                    .feedId,
                                                userPostModal
                                                    .txtController
                                                    .text,
                                                userPostModal);
                                            userPostModal
                                                .txtController
                                                .text = "";
                                            setState(
                                                    () {

                                                });
                                          }
                                        },
                                      )
                                      /*:  Container(
                                                    height: 0.0,
                                                  )*/
                                      ,
                                      flex: 0,
                                    )
                                  ],
                                )),
                            flex: 1)
                      ],
                    ))
                    : Container(
                  height: 0.0,
                ),

                (userPostList.length - 1) == index
                    ? Container(
                  height: 10.0,
                )
                    : Container(
                  height: 0.0,
                )
                // PaddingWrap.paddingfromLTRB(
                //     0.0,
                //     10.0,
                //     0.0,
                //     10.0,
                //     Divider(
                //       color:
                //           ColorValues.GREY_TEXT_COLOR,
                //       height: 1.0,
                //     ))
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget imageViewForOpportunityOwner(userPostModal, index) {
    return
      Container(
          decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/feed/background_imageview.png"),
              fit: BoxFit.cover,
            ),),
          child:
          PaddingWrap.paddingfromLTRB(
              15.0,
              15.0,
              13.0,
              10.0,
              Row(
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: Center(
                        child: Container(
                            width: 50.0,
                            height: 50.0,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: AppConstants.colorStyle.white,
                                    width: 1),
                                borderRadius:
                                const BorderRadius.all(Radius.circular(10))),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                  placeholder: userPostModal.roleId == "4"
                                      ? "assets/profile/partner_img.png"
                                      : 'assets/profile/user_on_user.png',
                                  image: Constant.IMAGE_PATH_SMALL +
                                      ParseJson.getSmallImage(userPostModal
                                          .opportunityModelForFeed
                                          .profilePicture),
                                ))),
                      ),
                      onTap: () {
                        // ToastWrap.showToast(userPostModal.postedBy);
                        onTapImageTile(
                            userPostModal.postedBy, userPostModal.roleId);
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        8.0,
                        0.0,
                        15.0,
                        0.0,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            InkWell(
                              child: Container(
                                  child: Row(
                                    children: <Widget>[
                                      RichText(
                                        maxLines: 2,
                                        textAlign: TextAlign.start,
                                        text: TextSpan(
                                          text: userPostModal
                                              .opportunityModelForFeed
                                              .companyName,
                                          style: TextStyle(
                                              color: ColorValues.WHITE,
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                      ),
                                      /*userPostModal.opportunityModelForFeed != null && userPostModal.opportunityModelForFeed.roleId == "1"
                                              //true
                                                  ? Util.getStudentBadge12(userPostModal.opportunityModelForFeed.badge,userPostModal.opportunityModelForFeed.badgeImage):Container(),*/
                                    ],
                                  )),
                              onTap: () {
                                onTapImageTile(
                                    userPostModal.postedBy,
                                    userPostModal.roleId);
                              },
                            ),
                            TextViewWrap.textView(
                                userPostModal.dateTime,
                                TextAlign.center,
                                ColorValues.WHITE,
                                12.0,
                                FontWeight.w500),
                          ],
                        )),
                    flex: 4,
                  ),
                  Expanded(
                    child: userIdPref == userPostModal.postedBy &&
                        roleId == userPostModal.roleId.toString()
                        ? Container(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,
                            userPostModal.tagList.length > 0 ? 38.0 : 15.0),
                        child: InkWell(
                          child: Image.asset(
                            "assets/feed/three_dot_white.png",
                            width: 15.0,
                            height: 15.0,
                          ),
                          onTap: () {

                          },
                        ))
                        : Container(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,
                            userPostModal.tagList.length > 0 ? 38.0 : 15.0),
                        child: InkWell(
                          child: Image.asset(
                            "assets/feed/three_dot_white.png",
                            width: 15.0,
                            height: 15.0,
                          ),
                          onTap: () {

                          },
                        )),
                    flex: 0,
                  )
                ],
              )));
  }

  Padding getListViewForOpportunity(UserPostModal userPostModal, index) {
    return PaddingWrap.paddingAll(
      0.0,
      Container(
        color: ColorValues.WHITE,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            //  getEvent(userPostModal),

            InkWell(
              child: Container(
                width: double.infinity,
                child: Stack(
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        //
                        userPostModal.opportunityModelForFeed
                            .assestVideoAndImage.length >
                            0
                            ? SizedBox(
                          // Pager view
                            height: 250.0,
                            child: PageIndicatorContainer(
                              pageView: PageView.builder(
                                itemCount: userPostModal
                                    .opportunityModelForFeed
                                    .assestVideoAndImage
                                    .length,
                                controller: PageController(),
                                itemBuilder: (context, index2) {
                                  return Stack(
                                    children: <Widget>[
                                      userPostModal
                                          .opportunityModelForFeed
                                          .assestVideoAndImage[
                                      index2]
                                          .type ==
                                          "image"
                                          ? Container(
                                        decoration:
                                        BoxDecoration(
                                          color: Colors.black,
                                        ),
                                        child:
                                        CachedNetworkImage(
                                          width:
                                          double.infinity,
                                          height: 250.0,
                                          imageUrl: Constant
                                              .IMAGE_PATH +
                                              userPostModal
                                                  .opportunityModelForFeed
                                                  .assestVideoAndImage[
                                              index2]
                                                  .file,
                                          fit: BoxFit.contain,
                                          placeholder: (context,
                                              url) =>
                                              _loader(context),
                                          errorWidget: (context,
                                              url, error) =>
                                              _error(),
                                        ),
                                      )
                                          : InkWell(
                                          child: Container(
                                            decoration:
                                            BoxDecoration(
                                              color: Colors.black,
                                              borderRadius:
                                              BorderRadius
                                                  .circular(0),
                                            ),
                                            height: 250.0,
                                            child: Center(
                                              child: VideoPlayPause(
                                                  userPostModal
                                                      .opportunityModelForFeed
                                                      .assestVideoAndImage[
                                                  index2]
                                                      .file,
                                                  "",
                                                  true),
                                            ),
                                          )),
                                      userPostModal
                                          .opportunityModelForFeed
                                          .assestVideoAndImage
                                          .length ==
                                          1 ||
                                          userPostModal
                                              .opportunityModelForFeed
                                              .assestVideoAndImage[
                                          index2]
                                              .type ==
                                              "video"
                                          ? Container(
                                        height: 0.0,
                                      )
                                          : InkWell(
                                          onTap: () {
                                            Navigator.of(context).push(
                                                new MaterialPageRoute(
                                                    builder: (
                                                        BuildContext context) =>
                                                        CommonFullViewWidget(
                                                            userPostModal
                                                                .opportunityModelForFeed
                                                                .assestVideoAndImage,
                                                            MessageConstant
                                                                .HOME_OPPORTUNITY_HEDING,
                                                            index2,
                                                            MessageConstant
                                                                .COMPANY_PROFILE_HEDING)));
                                          },
                                          child: Container(
                                            height: 250.0,
                                            width:
                                            double.infinity,
                                            child: Image.asset(
                                              "assets/newDesignIcon/navigation/layer_image.png",
                                              fit: BoxFit.fill,
                                            ),
                                          ))
                                    ],
                                  );
                                },
                                onPageChanged: (index) {},
                              ),
                              align: IndicatorAlign.bottom,
                              length: userPostModal
                                  .opportunityModelForFeed
                                  .assestVideoAndImage
                                  .length,
                              indicatorSpace: 10.0,
                              indicatorColor: userPostModal
                                  .opportunityModelForFeed
                                  .assestVideoAndImage
                                  .length ==
                                  1
                                  ? Colors.transparent
                                  : Color(0xffc4c4c4),
                              indicatorSelectorColor: userPostModal
                                  .opportunityModelForFeed
                                  .assestVideoAndImage
                                  .length ==
                                  1
                                  ? Colors.transparent
                                  : ColorValues.WHITE,
                              shape: IndicatorShape.circle(size: 5.0),
                            ))
                            : Stack(children: <Widget>[
                          Image.asset(
                            "assets/profile/default_achievement.png",
                            fit: BoxFit.cover,
                            height: 250.0,
                            width: double.infinity,
                          ),
                          Container(
                            height: 250.0,
                            color: Colors.black54.withOpacity(.4),
                          )
                        ])),
                    imageViewForOpportunityOwner(userPostModal, index),
                  ],
                ),
              ),
              onTap: () {
                // Navigator.of(context).push(new MaterialPageRoute(
                //     builder: (BuildContext context) =>
                //         OpportunityViewWidget(
                //             userPostModal.opportunityModelForFeed,
                //             userPostModal.feedId,
                //             userIdPref,
                //             roleId,
                //             diffrenceInDob,
                //             "")));
              },
            ),


            Padding(
              padding: const EdgeInsets.only(left: 20, top: 5),
              child: Row(
                children: <Widget>[
                  InkWell(
                    onTap: () {
                      onTapLike(userPostModal);
                    },
                    child: userPostModal.isLike
                        ? Image.asset(
                      "assets/feed/heart_red.png",
                      height: 22.0,
                      width: 22.0,
                    )
                        : Image.asset(
                      "assets/feed/heart_blue.png",
                      height: 22.0,
                      width: 22.0,
                    ),
                  ),
                  SizedBox(
                    width: 7,
                  ),
                  InkWell(
                    onTap: () {
                      if (userPostModal.isShowCommentIcon)
                        userPostModal.isShowCommentIcon = false;
                      else {
                        userPostModal.isShowCommentIcon = true;
                      }

                      setState(() {
                        userPostModal.isShowCommentIcon;
                      });
                    },
                    child: Image.asset(
                      "assets/feed/comment.png",
                      height: 26.0,
                      width: 26.0,
                    ),
                  ),


                  Spacer(),
                  // Padding(
                  //   padding: const EdgeInsets.only(
                  //     right: 20,
                  //   ),
                  //   child: InkWell(
                  //     onTap: () {
                  //       print("sss like");
                  //     },
                  //     child: Image.asset(
                  //       "assets/feed/save_icon_border.png",
                  //       height: 12.0,
                  //       width: 12.0,
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),


            Padding(
              padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: (userPostModal?.likesCount ?? -1) > 0
                        ? PaddingWrap.paddingfromLTRB(
                        20.0,
                        0.0,
                        10.0,
                        0.0,
                        InkWell(
                          child: TextViewWrap.textView(
                              userPostModal.likesCount ==
                                  0
                                  ? "Like"
                                  : userPostModal.likesCount ==
                                  1
                                  ? "1 Like"
                                  : userPostModal.likesCount
                                  .toString() +
                                  " Likes",
                              TextAlign.end,
                              ColorValues.labelColor,
                              12.0,
                              FontWeight.w500),
                          onTap: () {
                            onTapLikeText(userPostModal);
                          },
                        ))
                        : const SizedBox.shrink(),
                    flex: 0,
                  ),

                  userPostModal?.commentList?.isNotEmpty ?? false
                      ? InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                      10.0,
                      0.0,
                      0.0,
                      0.0,
                      TextViewWrap.textView(
                          userPostModal.commentList
                              .length ==
                              0
                              ? "Comment"
                              : "" +
                              userPostModal
                                  .commentList.length
                                  .toString() +
                              " Comments",
                          TextAlign.left,
                          ColorValues.labelColor,
                          12.0,
                          FontWeight.w500),
                    ),
                    onTap: () {
                      onTapViewAllComments(
                          userPostModal.commentList,
                          userPostModal.feedId,
                          userPostModal);
                    },
                  )
                      : const SizedBox.shrink(),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 5.0, 10.0, 10.0),
              child: Text(
                userPostModal.opportunityModelForFeed.offerId == "4" ||
                    userPostModal.opportunityModelForFeed.offerId ==
                        "5"
                    ? userPostModal.opportunityModelForFeed.serviceTitle
                    : userPostModal.opportunityModelForFeed.jobTitle,
                style: TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontSize: 14.0,
                    fontFamily: Constant.latoRegular,
                    fontWeight: FontWeight.w400),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                // Comment List view
                Padding(
                    padding: EdgeInsets.fromLTRB(
                        0.0, 5.0, 0.0, 10.0),
                    child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: List.generate(
                            userPostModal.commentList.length >
                                3
                                ? 3
                                : userPostModal.commentList
                                .length, (int index) {
                          return PaddingWrap.paddingfromLTRB(
                              10.0,
                              5.0,
                              10.0,
                              5.0,
                              Row(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: <Widget>[
                                  InkWell(
                                      child: Container(
                                          width: 40.0,
                                          height: 40.0,
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: AppConstants
                                                      .colorStyle
                                                      .darkBlue,
                                                  width: 1),
                                              borderRadius:
                                              const BorderRadius
                                                  .all(
                                                  Radius.circular(
                                                      10))),
                                          child: ClipRRect(
                                              borderRadius: BorderRadius
                                                  .circular(10),
                                              child: FadeInImage
                                                  .assetNetwork(
                                                fit: BoxFit.cover,
                                                width: double
                                                    .infinity,
                                                placeholder: userPostModal
                                                    .commentList[
                                                index]
                                                    .roleId ==
                                                    "4"
                                                    ? "assets/profile/partner_img.png"
                                                    : 'assets/profile/user_on_user.png',
                                                image: Constant
                                                    .IMAGE_PATH_SMALL +
                                                    userPostModal
                                                        .commentList[
                                                    index]
                                                        .profilePicture,
                                              ))),
                                      onTap: () {
                                        onTapImageTile(
                                            userPostModal
                                                .commentList[
                                            index]
                                                .commentedBy,
                                            userPostModal
                                                .commentList[
                                            index]
                                                .roleId);
                                      }), // User Image
                                  SizedBox(
                                    width: 20.0,
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment
                                          .start,
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .start,
                                      children: <Widget>[
                                        Padding(
                                          padding:
                                          const EdgeInsets
                                              .fromLTRB(
                                              0, 0, 0, 0),
                                          child: Container(
                                              child: Row(
                                                children: <
                                                    Widget>[
                                                  RichText(
                                                    maxLines: 2,
                                                    textAlign:
                                                    TextAlign
                                                        .start,
                                                    text:
                                                    TextSpan(
                                                      text: userPostModal
                                                          .commentList[
                                                      index]
                                                          .name,
                                                      style:
                                                      TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontSize:
                                                        14.0,
                                                        fontWeight:
                                                        FontWeight
                                                            .bold,
                                                      ),
                                                      /* children: <TextSpan>[
                                                              TextSpan(
                                                                  text: userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .comment,
                                                                  style:  TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                            ],*/
                                                    ),
                                                  ),
                                                  userPostModal
                                                      .commentList[index] !=
                                                      null &&
                                                      userPostModal
                                                          .commentList[index]
                                                          .roleId ==
                                                          "1"
                                                  //true
                                                      ? Util
                                                      .getStudentBadge12(
                                                      userPostModal
                                                          .commentList[
                                                      index]
                                                          .badge,
                                                      userPostModal
                                                          .commentList[index]
                                                          .badgeImage)
                                                      : Container(),
                                                ],
                                              )),
                                        ),
                                        Container(
                                          child: Linkify(
                                            onOpen:
                                                (link) async {
                                              Navigator.of(
                                                  context,
                                                  rootNavigator:
                                                  true)
                                                  .push(
                                                  new MaterialPageRoute(
                                                      fullscreenDialog:
                                                      true,
                                                      builder: (
                                                          BuildContext context) =>
                                                          WebViewWidget(
                                                              link
                                                                  .url,
                                                              "spikeview")));
                                            },
                                            text: userPostModal
                                                .commentList[
                                            index]
                                                .comment,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize:
                                                14.0,
                                                fontWeight:
                                                FontWeight
                                                    .normal,
                                                fontFamily:
                                                Constant
                                                    .latoRegular),
                                            linkStyle: TextStyle(
                                                color: ColorValues
                                                    .BLUE_COLOR_BOTTOMBAR,
                                                fontFamily:
                                                Constant
                                                    .TYPE_CUSTOMREGULAR,
                                                fontSize:
                                                14.0),
                                          ),
                                        ),
                                        Padding(
                                            padding:
                                            EdgeInsets
                                                .fromLTRB(
                                                0.0,
                                                5.0,
                                                0.0,
                                                0.0),
                                            child: Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .center,
                                              children: <
                                                  Widget>[
                                                Expanded(
                                                  child: Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: <
                                                        Widget>[
                                                      Text(
                                                        userPostModal
                                                            .commentList[index]
                                                            .dateTime,
                                                        textAlign:
                                                        TextAlign.end,
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .GREY_TEXT_COLOR,
                                                            fontSize: 12.0,
                                                            fontFamily: Constant
                                                                .customRegular),
                                                      )
                                                    ],
                                                  ),
                                                  flex: 0,
                                                ),
                                                Container(
                                                  width: 10.0,
                                                ),
                                                Expanded(
                                                  child: userIdPref ==
                                                      userPostModal
                                                          .commentList[index]
                                                          .commentedBy //&&
                                                  // userPostModal.commentList[index].isComment
                                                      ? InkWell(
                                                    child:
                                                    Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(
                                                          0.0, 0, 0,
                                                          0),
                                                      child: Image
                                                          .asset(
                                                        "assets/feed/three_dot_blue.png",
                                                        width: 15.0,
                                                        height: 15.0,
                                                      ),
                                                    ),
                                                    onTap:
                                                        () {
                                                      // optionForDelete(userPostModal.commentList, userPostModal.feedId, userPostModal, userPostModal.commentList[index].commentId, index);
                                                    },
                                                  )
                                                      : Container(
                                                    height:
                                                    1.0,
                                                  ),
                                                  flex: 0,
                                                )
                                              ],
                                            )),
                                      ],
                                    ),
                                    flex: 1,
                                  ) // Comment List Cell
                                ],
                              ));
                        }))),

                // View All Comments
                userPostModal.commentList.length > 3
                    ? InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                    10.0,
                    0.0,
                    0.0,
                    5.0,
                    TextViewWrap.textView(
                        "View All " +
                            userPostModal
                                .commentList.length
                                .toString() +
                            " Comments",
                        TextAlign.left,
                        ColorValues.labelColor,
                        12.0,
                        FontWeight.w500),
                  ),
                  onTap: () {
                    onTapViewAllComments(
                        userPostModal.commentList,
                        userPostModal.feedId,
                        userPostModal);
                  },
                )
                    : Container(
                  height: 0.0,
                ),

                // Comment Edit Text
                userPostModal.isShowCommentIcon
                    ? PaddingWrap.paddingAll(
                    10.0,
                    Row(
                      children: <Widget>[
                        //Alok Code Done
                        Container(
                          width: 40.0,
                          height: 40.0,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: AppConstants
                                      .colorStyle
                                      .darkBlue,
                                  width: 1),
                              borderRadius:
                              const BorderRadius
                                  .all(
                                  Radius.circular(10))),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child:
                            FadeInImage.assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: roleId == "4"
                                  ? "assets/profile/partner_img.png"
                                  : 'assets/profile/user_on_user.png',
                              image: roleId == "4"
                                  ?
                              Constant.IMAGE_PATH +
                                  prefs.getString(
                                      UserPreference
                                          .COMPANY_IMAGE_PATH)
                                  : Constant.IMAGE_PATH +
                                  prefs.getString(
                                      UserPreference
                                          .PROFILE_IMAGE_PATH)
                              ,
                              height: 45.0,
                              width: 45.0,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 20.0,
                        ),
                        Expanded(
                            child: Container(
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 1.0,
                                        color: ColorValues
                                            .LIGHT_GREY_TEXT_COLOR)),
                                child: Row(
                                  crossAxisAlignment:
                                  CrossAxisAlignment
                                      .center,
                                  mainAxisAlignment:
                                  MainAxisAlignment
                                      .center,
                                  children: <Widget>[
                                    Expanded(
                                      child: TextField(
                                        controller:
                                        userPostModal
                                            .txtController,
                                        style: TextStyle(
                                            fontFamily:
                                            Constant
                                                .TYPE_CUSTOMREGULAR),
                                        keyboardType:
                                        TextInputType
                                            .text,
                                        textCapitalization:
                                        TextCapitalization
                                            .sentences,
                                        maxLines: null,
                                        maxLength: TextLength
                                            .COMMENT_MAX_LENGTH,
                                        onChanged: (s) {
                                          if (s
                                              .trim()
                                              .length >
                                              0) {
                                            userPostModal
                                                .isCommentIconVisible =
                                            true;
                                          } else {
                                            userPostModal
                                                .isCommentIconVisible =
                                            false;
                                          }
                                          setState(() {
                                            userPostModal
                                                .isCommentIconVisible;
                                          });
                                        },
                                        decoration:
                                        InputDecoration(
                                          border:
                                          InputBorder
                                              .none,
                                          counterStyle: TextStyle(
                                              fontFamily:
                                              Constant
                                                  .TYPE_CUSTOMREGULAR),
                                          filled: true,
                                          counterText: "",
                                          hintText: roleId ==
                                              "4"
                                              ? "Add Comment as " +
                                              prefs.getString(
                                                  UserPreference
                                                      .COMPANY_NAME_PATH)
                                              : "Add Comment as " +
                                              prefs.getString(
                                                  UserPreference.NAME)
                                                  .replaceAll(
                                                  "null",
                                                  ""),
                                          hintStyle: TextStyle(
                                              color: ColorValues
                                                  .GREY_TEXT_COLOR,
                                              fontSize:
                                              14.0,
                                              fontFamily:
                                              Constant
                                                  .TYPE_CUSTOMREGULAR),
                                          fillColor: Colors
                                              .transparent,
                                        ),
                                      ),
                                      flex: 4,
                                    ),
                                    Expanded(
                                      child:
                                      /*userPostModal
                                                    .isCommentIconVisible
                                                ?*/
                                      InkWell(
                                        child: PaddingWrap
                                            .paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            5.0,
                                            0.0,
                                            Image
                                                .asset(
                                              "assets/feed/sent_icon.png",
                                              width:
                                              22.0,
                                              height:
                                              22.0,
                                            )),
                                        onTap: () {
                                          if (userPostModal
                                              .isCommentIconVisible) {
                                            FocusScope.of(
                                                context)
                                                .requestFocus(
                                                FocusNode());
                                            userPostModal
                                                .isCommentIconVisible =
                                            false;
                                            onAddComment(
                                                userPostModal
                                                    .feedId,
                                                userPostModal
                                                    .txtController
                                                    .text,
                                                userPostModal);
                                            userPostModal
                                                .txtController
                                                .text = "";
                                            setState(() {
                                              userPostModal
                                                  .txtController;
                                              userPostModal
                                                  .isCommentIconVisible;
                                            });
                                          }
                                        },
                                      )
                                      /*:  Container(
                                                    height: 0.0,
                                                  )*/
                                      ,
                                      flex: 0,
                                    )
                                  ],
                                )),
                            flex: 1)
                      ],
                    ))
                    : Container(
                  height: 0.0,
                ),

                (userPostList.length - 1) == index
                    ? Container(
                  height: 10.0,
                )
                    : Container(
                  height: 0.0,
                )
                // PaddingWrap.paddingfromLTRB(
                //     0.0,
                //     10.0,
                //     0.0,
                //     10.0,
                //     Divider(
                //       color: ColorValues.GREY_TEXT_COLOR,
                //       height: 1.0,
                //     ))
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget imageViewForGetListViewBlue(userPostModal, index) {
    return PaddingWrap.paddingfromLTRB(
        15.0,
        15.0,
        13.0,
        10.0,
        Row(
          children: <Widget>[
            Expanded(
              child: InkWell(
                child: Center(
                  child: Container(
                      width: 50.0,
                      height: 50.0,
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                              width: 1),
                          borderRadius:
                          const BorderRadius.all(Radius.circular(10))),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: FadeInImage.assetNetwork(
                            fit: BoxFit.cover,
                            width: double.infinity,
                            placeholder: userPostModal.roleId == "4"
                                ? "assets/profile/partner_img.png"
                                : 'assets/profile/user_on_user.png',
                            image: Constant.IMAGE_PATH_SMALL +
                                ParseJson.getSmallImage(
                                    userPostModal.profilePicture),
                          ))),
                ),
                onTap: () {
                  // ToastWrap.showToast(userPostModal.postedBy);
                  onTapImageTile(
                      userPostModal.postedBy, userPostModal.roleId);
                },
              ),
              flex: 0,
            ),
            Expanded(
              child: PaddingWrap.paddingfromLTRB(
                  8.0,
                  0.0,
                  15.0,
                  0.0,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: InkWell(
                              child: Container(
                                  child: RichText(
                                    maxLines: 3,
                                    textAlign: TextAlign.start,
                                    text: TextSpan(
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {
                                          if (userPostModal.tagList.length >
                                              0 &&
                                              userPostModal.groupList.length >
                                                  0) {
                                            onTapImageTile(
                                                userPostModal.postedBy,
                                                userPostModal.roleId);
                                          }
                                        },
                                      text: userPostModal.lastName == null ||
                                          userPostModal.lastName == "null"
                                          ? userPostModal.firstName
                                          : userPostModal.firstName +
                                          " " +
                                          userPostModal.lastName,
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.w500,
                                          fontFamily: Constant.latoRegular),
                                      children: userPostModal.tagList
                                          .length ==
                                          0 &&
                                          userPostModal.groupList.length == 0
                                          ? userPostModal.postedGroupName !=
                                          null &&
                                          userPostModal.postedGroupName !=
                                              "null" &&
                                          userPostModal.postedGroupName !=
                                              ""
                                          ? [
                                        WidgetSpan(
                                          child: userPostModal.roleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                        TextSpan(
                                            text: " > ",
                                            style: TextStyle(
                                                color:
                                                ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: Constant
                                                    .latoRegular)),
                                        TextSpan(
                                            recognizer:
                                            TapGestureRecognizer()
                                              ..onTap = () {
                                                Navigator.of(context).push(
                                                    new MaterialPageRoute(
                                                        builder: (BuildContext
                                                        context) =>
                                                            GroupDetailWidget(
                                                                userPostModal
                                                                    .postedGroupId,
                                                                "",
                                                                "",
                                                                "",
                                                                "")));
                                              },
                                            text: userPostModal
                                                .postedGroupName,
                                            style: TextStyle(
                                                color:
                                                ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: Constant
                                                    .latoRegular))
                                      ]
                                          : [
                                        WidgetSpan(
                                          child: userPostModal.roleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                      ]
                                          : userPostModal.tagList.length !=
                                          0 &&
                                          userPostModal
                                              .groupList.length !=
                                              0
                                          ? [
                                        WidgetSpan(
                                          child: userPostModal.roleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                        userPostModal.postedGroupName !=
                                            null &&
                                            userPostModal
                                                .postedGroupName !=
                                                "null" &&
                                            userPostModal
                                                .postedGroupName !=
                                                ""
                                            ? TextSpan(
                                            text: " > ",
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: Constant
                                                    .latoRegular))
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.postedGroupName !=
                                            null &&
                                            userPostModal
                                                .postedGroupName !=
                                                "null" &&
                                            userPostModal
                                                .postedGroupName !=
                                                ""
                                            ? TextSpan(
                                            recognizer:
                                            TapGestureRecognizer()
                                              ..onTap = () {
                                                Navigator.of(context).push(
                                                    new MaterialPageRoute(
                                                        builder: (BuildContext
                                                        context) =>
                                                            GroupDetailWidget(
                                                                userPostModal
                                                                    .postedGroupId,
                                                                "",
                                                                "",
                                                                "",
                                                                "")));
                                              },
                                            text: userPostModal
                                                .postedGroupName,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: Constant
                                                    .latoRegular))
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),

                                        ///////////////////////////////////////////////////////////////
                                        TextSpan(
                                            text: ' > ',
                                            style: TextStyle(
                                                color:
                                                ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: Constant
                                                    .latoRegular)),
                                        TextSpan(
                                          recognizer:
                                          TapGestureRecognizer()
                                            ..onTap = () {
                                              Navigator.of(context).push(
                                                  MaterialPageRoute(
                                                      builder: (BuildContext
                                                      context) =>
                                                          SelectedGroup(
                                                              userPostModal, userPostModal
                                                                  .groupList)));
                                            },
                                          text: userPostModal
                                              .groupList[0]
                                              .groupName ==
                                              null ||
                                              userPostModal
                                                  .groupList[0]
                                                  .groupName ==
                                                  "null"
                                              ? ""
                                              : userPostModal
                                              .groupList[0]
                                              .groupName,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily:
                                              Constant.latoRegular),
                                        ),
                                        userPostModal.groupList.length >
                                            1
                                            ? TextSpan(
                                          recognizer:
                                          TapGestureRecognizer()
                                            ..onTap = () {
                                              Navigator.of(
                                                  context)
                                                  .push(new MaterialPageRoute(
                                                  builder:
                                                      (BuildContext context) =>
                                                      SelectedGroup(
                                                          userPostModal, userPostModal
                                                              .groupList)));
                                            },
                                          text: ' and ',
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.groupList.length >
                                            1
                                            ? TextSpan(
                                          recognizer:
                                          TapGestureRecognizer()
                                            ..onTap = () {
                                              Navigator.of(
                                                  context)
                                                  .push(new MaterialPageRoute(
                                                  builder:
                                                      (BuildContext context) =>
                                                      SelectedGroup(
                                                          userPostModal,  userPostModal
                                                              .groupList)));
                                            },
                                          text: (userPostModal
                                              .groupList
                                              .length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.groupList.length >
                                            1
                                            ? TextSpan(
                                          recognizer:
                                          TapGestureRecognizer()
                                            ..onTap = () {
                                              Navigator.of(
                                                  context)
                                                  .push(new MaterialPageRoute(
                                                  builder:
                                                      (BuildContext context) =>
                                                      SelectedGroup(
                                                          userPostModal,userPostModal
                                                              .groupList)));
                                            },
                                          text: " others ",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),

                                        ///////////////////////////////////////////////////////////////

                                        TextSpan(
                                            text: ' with ',
                                            style: TextStyle(
                                                color:
                                                ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: Constant
                                                    .latoRegular)),
                                        TextSpan(
                                          recognizer:
                                          TapGestureRecognizer()
                                            ..onTap = () {
                                              Navigator.of(context).push(
                                                  MaterialPageRoute(
                                                      builder: (BuildContext
                                                      context) =>
                                                          TagDetailWidget(
                                                              userPostModal
                                                                  .tagList)));
                                            },
                                          text: userPostModal.tagList[0]
                                              .name ==
                                              null ||
                                              userPostModal
                                                  .tagList[0]
                                                  .name ==
                                                  "null"
                                              ? ""
                                              : userPostModal
                                              .tagList[0].name,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.bold,
                                              fontFamily:
                                              Constant.latoRegular),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          recognizer:
                                          TapGestureRecognizer()
                                            ..onTap = () {
                                              Navigator.of(
                                                  context)
                                                  .push(new MaterialPageRoute(
                                                  builder:
                                                      (BuildContext context) =>
                                                      TagDetailWidget(
                                                          userPostModal
                                                              .tagList)));
                                            },
                                          text: ' and ',
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          recognizer:
                                          TapGestureRecognizer()
                                            ..onTap = () {
                                              Navigator.of(
                                                  context)
                                                  .push(new MaterialPageRoute(
                                                  builder:
                                                      (BuildContext context) =>
                                                      TagDetailWidget(
                                                          userPostModal
                                                              .tagList)));
                                            },
                                          text: (userPostModal
                                              .tagList
                                              .length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          recognizer:
                                          TapGestureRecognizer()
                                            ..onTap = () {
                                              Navigator.of(
                                                  context)
                                                  .push(new MaterialPageRoute(
                                                  builder:
                                                      (BuildContext context) =>
                                                      TagDetailWidget(
                                                          userPostModal
                                                              .tagList)));
                                            },
                                          text: " others ",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                      ]
                                          : userPostModal.groupList.length !=
                                          0
                                          ? [
                                        WidgetSpan(
                                          child: userPostModal
                                              .roleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),

                                        TextSpan(
                                            text: ' > ',
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: Constant
                                                    .latoRegular)),
                                        TextSpan(
                                          text: userPostModal
                                              .groupList[
                                          0]
                                              .groupName ==
                                              null ||
                                              userPostModal
                                                  .groupList[
                                              0]
                                                  .groupName ==
                                                  "null"
                                              ? ""
                                              : userPostModal
                                              .groupList[0]
                                              .groupName,
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.groupList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: ' and ',
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.groupList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: (userPostModal
                                              .groupList
                                              .length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.groupList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: " others ",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                      ]
                                          : [
                                        WidgetSpan(
                                          child: userPostModal
                                              .roleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                        userPostModal.postedGroupName !=
                                            null &&
                                            userPostModal
                                                .postedGroupName !=
                                                "null" &&
                                            userPostModal
                                                .postedGroupName !=
                                                ""
                                            ? TextSpan(
                                            text: " > ",
                                            style: TextStyle(
                                                color:
                                                ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight
                                                    .w500,
                                                fontFamily: Constant
                                                    .latoRegular))
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.postedGroupName !=
                                            null &&
                                            userPostModal
                                                .postedGroupName !=
                                                "null" &&
                                            userPostModal
                                                .postedGroupName !=
                                                ""
                                            ? TextSpan(
                                            recognizer:
                                            TapGestureRecognizer()
                                              ..onTap = () {
                                                Navigator.of(context).push(
                                                    new MaterialPageRoute(
                                                        builder: (
                                                            BuildContext context) =>
                                                            GroupDetailWidget(
                                                                userPostModal
                                                                    .postedGroupId,
                                                                "",
                                                                "",
                                                                "",
                                                                "")));
                                              },
                                            text: userPostModal
                                                .postedGroupName,
                                            style: TextStyle(
                                                color:
                                                ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight
                                                    .w500,
                                                fontFamily: Constant
                                                    .latoRegular))
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        TextSpan(
                                            text: ' with ',
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: Constant
                                                    .latoRegular)),
                                        TextSpan(
                                          text: userPostModal
                                              .tagList[
                                          0]
                                              .name ==
                                              null ||
                                              userPostModal
                                                  .tagList[
                                              0]
                                                  .name ==
                                                  "null"
                                              ? ""
                                              : userPostModal
                                              .tagList[0].name,
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.bold,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.tagList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: ' and ',
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.tagList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: (userPostModal
                                              .tagList
                                              .length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                        userPostModal.tagList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: " others ",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color:
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                        ),
                                      ],
                                    ),
                                  )),
                              onTap: () {
                                if (userPostModal.tagList.length > 0 &&
                                    userPostModal.groupList.length >
                                        0) {} else if (userPostModal.groupList
                                    .length >
                                    0) {
                                  Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              SelectedGroup(
                                                  userPostModal, userPostModal.groupList)));
                                } else if (userPostModal.tagList.length > 0) {
                                  Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              TagDetailWidget(
                                                  userPostModal.tagList)));
                                } else {
                                  onTapImageTile(userPostModal.postedBy,
                                      userPostModal.roleId);
                                }
                              },
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                      /*    TextViewWrap.textView(
                                        userPostModal.dateTime,
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        12.0,
                                        FontWeight.normal),*/

                      Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                        child: Row(
                          children: [
                            TextViewWrap.textView(
                                userPostModal.dateTime,
                                TextAlign.center,
                                ColorValues.labelColor,
                                12.0,
                                FontWeight.w400),
                            userPostModal.visibility == ""
                                ? Container(
                              height: 0.0,
                            )
                                : userIdPref == userPostModal.postedBy &&
                                roleId ==
                                    userPostModal.roleId.toString()
                                ? PaddingWrap.paddingfromLTRB(
                                10.0,
                                0.0,
                                5.0,
                                0.0,
                                Image.asset(
                                  userPostModal.visibility ==
                                      "Private"
                                      ? "assets/profile/post/private_new.png"
                                      : userPostModal.visibility ==
                                      "SelectedConnections"
                                      ? "assets/profile/post/selected_connection.png"
                                      : userPostModal
                                      .visibility ==
                                      "AllConnections"
                                      ? "assets/profile/post/connection.png"
                                      : userPostModal
                                      .visibility ==
                                      "Group"
                                      ? "assets/profile/post/group_data.png"
                                      : "assets/profile/post/community.png",
                                  width: 13.0,
                                  color: userPostModal.visibility ==
                                      "SelectedConnections"
                                      ? null
                                      : ColorValues.labelColor,
                                  height: 14.0,
                                ))
                                : Container(
                              height: 0.0,
                            ),
                            /*  userPostModal.visibility == ""
                                              ?  Container(
                                                  height: 0.0,
                                                )
                                              : PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap.textView(
                                                      userPostModal.visibility ==
                                                              "Private"
                                                          ? "Private"
                                                          : userPostModal
                                                                      .visibility ==
                                                                  "SelectedConnections"
                                                              ? "Selected Connections"
                                                              : userPostModal
                                                                          .visibility ==
                                                                      "AllConnections"
                                                                  ? "Connections"
                                                                  : userPostModal
                                                                              .visibility ==
                                                                          "Group"
                                                                      ? "Group"
                                                                      : "Community",
                                                      TextAlign.center,
                                                      ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal))*/
                          ],
                        ),
                      )
                    ],
                  )),
              flex: 4,
            ),
            Expanded(
              child: userIdPref == userPostModal.postedBy &&
                  roleId == userPostModal.roleId.toString()
                  ? Container(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,
                      userPostModal.tagList.length > 0 ? 38.0 : 15.0),
                  child: InkWell(
                    child: Image.asset(
                      "assets/feed/three_dot_blue.png",
                      width: 15.0,
                      height: 15.0,
                    ),
                    onTap: () {

                    },
                  ))
                  : Container(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,
                      userPostModal.tagList.length > 0 ? 38.0 : 15.0),
                  child: InkWell(
                    child: Image.asset(
                      "assets/feed/three_dot_blue.png",
                      width: 15.0,
                      height: 15.0,
                    ),
                    onTap: () {

                    },
                  )),
              flex: 0,
            )
          ],
        ));
  }

  Widget imageViewForGetListView(userPostModal, index) {
    return
      Container(
          decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/feed/background_imageview.png"),
              fit: BoxFit.cover,
            ),),
          child: PaddingWrap.paddingfromLTRB(
            15.0,
            15.0,
            13.0,
            10.0,
            Row(
              children: <Widget>[
                Expanded(
                  child: InkWell(
                    child: Center(
                      child: Container(
                          width: 50.0,
                          height: 50.0,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: AppConstants.colorStyle.white,
                                  width: 1),
                              borderRadius:
                              const BorderRadius.all(Radius.circular(10))),
                          child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: FadeInImage.assetNetwork(
                                fit: BoxFit.cover,
                                width: double.infinity,
                                placeholder: userPostModal.roleId == "4"
                                    ? "assets/profile/partner_img.png"
                                    : 'assets/profile/user_on_user.png',
                                image: Constant.IMAGE_PATH_SMALL +
                                    ParseJson.getSmallImage(
                                        userPostModal.profilePicture),
                              ))),
                    ),
                    onTap: () {
                      // ToastWrap.showToast(userPostModal.postedBy);
                      onTapImageTile(
                          userPostModal.postedBy, userPostModal.roleId);
                    },
                  ),
                  flex: 0,
                ),
                Expanded(
                  child: PaddingWrap.paddingfromLTRB(
                      8.0,
                      0.0,
                      15.0,
                      0.0,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                child: InkWell(
                                  child: Container(
                                      child: RichText(
                                        maxLines: 3,
                                        textAlign: TextAlign.start,
                                        text: TextSpan(
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {
                                              if (userPostModal.tagList
                                                  .length > 0 &&
                                                  userPostModal.groupList
                                                      .length >
                                                      0) {
                                                onTapImageTile(
                                                    userPostModal.postedBy,
                                                    userPostModal.roleId);
                                              }
                                            },
                                          text: userPostModal.lastName ==
                                              null ||
                                              userPostModal.lastName == "null"
                                              ? userPostModal.firstName
                                              : userPostModal.firstName +
                                              " " +
                                              userPostModal.lastName,
                                          style: TextStyle(
                                              color: ColorValues.WHITE,
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant
                                                  .latoRegular),
                                          children: userPostModal.tagList
                                              .length ==
                                              0 &&
                                              userPostModal.groupList
                                                  .length == 0
                                              ? userPostModal
                                              .postedGroupName !=
                                              null &&
                                              userPostModal.postedGroupName !=
                                                  "null" &&
                                              userPostModal.postedGroupName !=
                                                  ""
                                              ? [
                                            WidgetSpan(
                                              child: userPostModal.roleId ==
                                                  "1"
                                                  ? Util
                                                  .getStudentBadgeRichTextWithPadding(
                                                  userPostModal
                                                      .badge,
                                                  userPostModal
                                                      .badgeImage)
                                                  : Container(
                                                height: 0.0,
                                                width: 0.0,
                                              ),
                                            ),
                                            TextSpan(
                                                text: " > ",
                                                style: TextStyle(
                                                    color:
                                                    ColorValues.WHITE,
                                                    fontSize: 16.0,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoRegular)),
                                            TextSpan(
                                                recognizer:
                                                TapGestureRecognizer()
                                                  ..onTap = () {
                                                    Navigator.of(context)
                                                        .push(
                                                        new MaterialPageRoute(
                                                            builder: (
                                                                BuildContext
                                                                context) =>
                                                                GroupDetailWidget(
                                                                    userPostModal
                                                                        .postedGroupId,
                                                                    "",
                                                                    "",
                                                                    "",
                                                                    "")));
                                                  },
                                                text: userPostModal
                                                    .postedGroupName,
                                                style: TextStyle(
                                                    color:
                                                    ColorValues.WHITE,
                                                    fontSize: 16.0,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoRegular))
                                          ]
                                              : [
                                            WidgetSpan(
                                              child: userPostModal.roleId ==
                                                  "1"
                                                  ? Util
                                                  .getStudentBadgeRichTextWithPadding(
                                                  userPostModal
                                                      .badge,
                                                  userPostModal
                                                      .badgeImage)
                                                  : Container(
                                                height: 0.0,
                                                width: 0.0,
                                              ),
                                            ),
                                          ]
                                              : userPostModal.tagList
                                              .length != 0 &&
                                              userPostModal
                                                  .groupList.length !=
                                                  0
                                              ? [
                                            WidgetSpan(
                                              child: userPostModal.roleId ==
                                                  "1"
                                                  ? Util
                                                  .getStudentBadgeRichTextWithPadding(
                                                  userPostModal
                                                      .badge,
                                                  userPostModal
                                                      .badgeImage)
                                                  : Container(
                                                height: 0.0,
                                                width: 0.0,
                                              ),
                                            ),
                                            userPostModal.postedGroupName !=
                                                null &&
                                                userPostModal
                                                    .postedGroupName !=
                                                    "null" &&
                                                userPostModal
                                                    .postedGroupName !=
                                                    ""
                                                ? TextSpan(
                                                text: " > ",
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .WHITE,
                                                    fontSize: 16.0,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoRegular))
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.postedGroupName !=
                                                null &&
                                                userPostModal
                                                    .postedGroupName !=
                                                    "null" &&
                                                userPostModal
                                                    .postedGroupName !=
                                                    ""
                                                ? TextSpan(
                                                recognizer:
                                                TapGestureRecognizer()
                                                  ..onTap = () {
                                                    Navigator.of(context)
                                                        .push(
                                                        new MaterialPageRoute(
                                                            builder: (
                                                                BuildContext
                                                                context) =>
                                                                GroupDetailWidget(
                                                                    userPostModal
                                                                        .postedGroupId,
                                                                    "",
                                                                    "",
                                                                    "",
                                                                    "")));
                                                  },
                                                text: userPostModal
                                                    .postedGroupName,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .WHITE,
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoRegular))
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),

                                            ///////////////////////////////////////////////////////////////
                                            TextSpan(
                                                text: ' > ',
                                                style: TextStyle(
                                                    color:
                                                    ColorValues.WHITE,
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoRegular)),
                                            TextSpan(
                                              recognizer:
                                              TapGestureRecognizer()
                                                ..onTap = () {
                                                  Navigator.of(context).push(
                                                      MaterialPageRoute(
                                                          builder: (BuildContext
                                                          context) =>
                                                              SelectedGroup(
                                                                  userPostModal,  userPostModal
                                                                      .groupList)));
                                                },
                                              text: userPostModal
                                                  .groupList[0]
                                                  .groupName ==
                                                  null ||
                                                  userPostModal
                                                      .groupList[0]
                                                      .groupName ==
                                                      "null"
                                                  ? ""
                                                  : userPostModal
                                                  .groupList[0]
                                                  .groupName,
                                              style: TextStyle(
                                                  color: ColorValues.WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily:
                                                  Constant.latoRegular),
                                            ),
                                            userPostModal.groupList.length >
                                                1
                                                ? TextSpan(
                                              recognizer:
                                              TapGestureRecognizer()
                                                ..onTap = () {
                                                  Navigator.of(
                                                      context)
                                                      .push(
                                                      new MaterialPageRoute(
                                                          builder:
                                                              (
                                                              BuildContext context) =>
                                                              SelectedGroup(
                                                                  userPostModal, userPostModal
                                                                      .groupList)));
                                                },
                                              text: ' and ',
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.groupList.length >
                                                1
                                                ? TextSpan(
                                              recognizer:
                                              TapGestureRecognizer()
                                                ..onTap = () {
                                                  Navigator.of(
                                                      context)
                                                      .push(
                                                      new MaterialPageRoute(
                                                          builder:
                                                              (
                                                              BuildContext context) =>
                                                              SelectedGroup(
                                                                  userPostModal,  userPostModal
                                                                      .groupList)));
                                                },
                                              text: (userPostModal
                                                  .groupList
                                                  .length -
                                                  1)
                                                  .toString(),
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .normal,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            ),
                                            userPostModal.groupList.length >
                                                1
                                                ? TextSpan(
                                              recognizer:
                                              TapGestureRecognizer()
                                                ..onTap = () {
                                                  Navigator.of(
                                                      context)
                                                      .push(
                                                      new MaterialPageRoute(
                                                          builder:
                                                              (
                                                              BuildContext context) =>
                                                              SelectedGroup(
                                                                  userPostModal, userPostModal
                                                                      .groupList)));
                                                },
                                              text: " others ",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),

                                            ///////////////////////////////////////////////////////////////

                                            TextSpan(
                                                text: ' with ',
                                                style: TextStyle(
                                                    color:
                                                    ColorValues.WHITE,
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoRegular)),
                                            TextSpan(
                                              recognizer:
                                              TapGestureRecognizer()
                                                ..onTap = () {
                                                  Navigator.of(context).push(
                                                      MaterialPageRoute(
                                                          builder: (BuildContext
                                                          context) =>
                                                              TagDetailWidget(
                                                                  userPostModal
                                                                      .tagList)));
                                                },
                                              text: userPostModal.tagList[0]
                                                  .name ==
                                                  null ||
                                                  userPostModal
                                                      .tagList[0]
                                                      .name ==
                                                      "null"
                                                  ? ""
                                                  : userPostModal
                                                  .tagList[0].name,
                                              style: TextStyle(
                                                  color: ColorValues.WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.bold,
                                                  fontFamily:
                                                  Constant.latoRegular),
                                            ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                              recognizer:
                                              TapGestureRecognizer()
                                                ..onTap = () {
                                                  Navigator.of(
                                                      context)
                                                      .push(
                                                      new MaterialPageRoute(
                                                          builder:
                                                              (
                                                              BuildContext context) =>
                                                              TagDetailWidget(
                                                                  userPostModal
                                                                      .tagList)));
                                                },
                                              text: ' and ',
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                              recognizer:
                                              TapGestureRecognizer()
                                                ..onTap = () {
                                                  Navigator.of(
                                                      context)
                                                      .push(
                                                      new MaterialPageRoute(
                                                          builder:
                                                              (
                                                              BuildContext context) =>
                                                              TagDetailWidget(
                                                                  userPostModal
                                                                      .tagList)));
                                                },
                                              text: (userPostModal
                                                  .tagList
                                                  .length -
                                                  1)
                                                  .toString(),
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                              recognizer:
                                              TapGestureRecognizer()
                                                ..onTap = () {
                                                  Navigator.of(
                                                      context)
                                                      .push(
                                                      new MaterialPageRoute(
                                                          builder:
                                                              (
                                                              BuildContext context) =>
                                                              TagDetailWidget(
                                                                  userPostModal
                                                                      .tagList)));
                                                },
                                              text: " others ",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                          ]
                                              : userPostModal.groupList
                                              .length !=
                                              0
                                              ? [
                                            WidgetSpan(
                                              child: userPostModal
                                                  .roleId ==
                                                  "1"
                                                  ? Util
                                                  .getStudentBadgeRichTextWithPadding(
                                                  userPostModal
                                                      .badge,
                                                  userPostModal
                                                      .badgeImage)
                                                  : Container(
                                                height: 0.0,
                                                width: 0.0,
                                              ),
                                            ),

                                            TextSpan(
                                                text: ' > ',
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .WHITE,
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoRegular)),
                                            TextSpan(
                                              text: userPostModal
                                                  .groupList[
                                              0]
                                                  .groupName ==
                                                  null ||
                                                  userPostModal
                                                      .groupList[
                                                  0]
                                                      .groupName ==
                                                      "null"
                                                  ? ""
                                                  : userPostModal
                                                  .groupList[0]
                                                  .groupName,
                                              style: TextStyle(
                                                  color:
                                                  ColorValues.WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.groupList
                                                .length >
                                                1
                                                ? TextSpan(
                                              text: ' and ',
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.groupList
                                                .length >
                                                1
                                                ? TextSpan(
                                              text: (userPostModal
                                                  .groupList
                                                  .length -
                                                  1)
                                                  .toString(),
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.groupList
                                                .length >
                                                1
                                                ? TextSpan(
                                              text: " others ",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                          ]
                                              : [
                                            WidgetSpan(
                                              child: userPostModal
                                                  .roleId ==
                                                  "1"
                                                  ? Util
                                                  .getStudentBadgeRichTextWithPadding(
                                                  userPostModal
                                                      .badge,
                                                  userPostModal
                                                      .badgeImage)
                                                  : Container(
                                                height: 0.0,
                                                width: 0.0,
                                              ),
                                            ),
                                            userPostModal.postedGroupName !=
                                                null &&
                                                userPostModal
                                                    .postedGroupName !=
                                                    "null" &&
                                                userPostModal
                                                    .postedGroupName !=
                                                    ""
                                                ? TextSpan(
                                                text: " > ",
                                                style: TextStyle(
                                                    color:
                                                    ColorValues
                                                        .WHITE,
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500,
                                                    fontFamily: Constant
                                                        .latoRegular))
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.postedGroupName !=
                                                null &&
                                                userPostModal
                                                    .postedGroupName !=
                                                    "null" &&
                                                userPostModal
                                                    .postedGroupName !=
                                                    ""
                                                ? TextSpan(
                                                recognizer:
                                                TapGestureRecognizer()
                                                  ..onTap = () {
                                                    Navigator.of(context)
                                                        .push(
                                                        new MaterialPageRoute(
                                                            builder: (
                                                                BuildContext context) =>
                                                                GroupDetailWidget(
                                                                    userPostModal
                                                                        .postedGroupId,
                                                                    "",
                                                                    "",
                                                                    "",
                                                                    "")));
                                                  },
                                                text: userPostModal
                                                    .postedGroupName,
                                                style: TextStyle(
                                                    color:
                                                    ColorValues
                                                        .WHITE,
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500,
                                                    fontFamily: Constant
                                                        .latoRegular))
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            TextSpan(
                                                text: ' with ',
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .WHITE,
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                    FontWeight.w500,
                                                    fontFamily: Constant
                                                        .latoRegular)),
                                            TextSpan(
                                              text: userPostModal
                                                  .tagList[
                                              0]
                                                  .name ==
                                                  null ||
                                                  userPostModal
                                                      .tagList[
                                                  0]
                                                      .name ==
                                                      "null"
                                                  ? ""
                                                  : userPostModal
                                                  .tagList[0].name,
                                              style: TextStyle(
                                                  color:
                                                  ColorValues.WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight.w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.tagList
                                                .length >
                                                1
                                                ? TextSpan(
                                              text: ' and ',
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.tagList
                                                .length >
                                                1
                                                ? TextSpan(
                                              text: (userPostModal
                                                  .tagList
                                                  .length -
                                                  1)
                                                  .toString(),
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                            userPostModal.tagList
                                                .length >
                                                1
                                                ? TextSpan(
                                              text: " others ",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            )
                                                : TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color:
                                                  ColorValues
                                                      .WHITE,
                                                  fontSize: 14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500,
                                                  fontFamily: Constant
                                                      .latoRegular),
                                            ),
                                          ],
                                        ),
                                      )),
                                  onTap: () {
                                    if (userPostModal.tagList.length > 0 &&
                                        userPostModal.groupList.length >
                                            0) {} else
                                    if (userPostModal.groupList.length >
                                        0) {
                                      Navigator.of(context).push(
                                          MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  SelectedGroup(
                                                      userPostModal, userPostModal
                                                          .groupList)));
                                    } else
                                    if (userPostModal.tagList.length > 0) {
                                      Navigator.of(context).push(
                                          MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  TagDetailWidget(
                                                      userPostModal
                                                          .tagList)));
                                    } else {
                                      onTapImageTile(userPostModal.postedBy,
                                          userPostModal.roleId);
                                    }
                                  },
                                ),
                                flex: 1,
                              ),
                            ],
                          ),
                          /*    TextViewWrap.textView(
                                          userPostModal.dateTime,
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          12.0,
                                          FontWeight.normal),*/

                          Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                            child: Row(
                              children: [
                                TextViewWrap.textView(
                                    userPostModal.dateTime,
                                    TextAlign.center,
                                    ColorValues.WHITE,
                                    12.0,
                                    FontWeight.w400),
                                userPostModal.visibility == ""
                                    ? Container(
                                  height: 0.0,
                                )
                                    : userIdPref == userPostModal.postedBy &&
                                    roleId ==
                                        userPostModal.roleId.toString()
                                    ? PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    0.0,
                                    5.0,
                                    0.0,
                                    Image.asset(
                                      userPostModal.visibility ==
                                          "Private"
                                          ? "assets/profile/post/private_new.png"
                                          : userPostModal.visibility ==
                                          "SelectedConnections"
                                          ? "assets/profile/post/selected_connection.png"
                                          : userPostModal
                                          .visibility ==
                                          "AllConnections"
                                          ? "assets/profile/post/connection.png"
                                          : userPostModal
                                          .visibility ==
                                          "Group"
                                          ? "assets/profile/post/group_data.png"
                                          : "assets/profile/post/community.png",
                                      width: 13.0,
                                      color: userPostModal.visibility ==
                                          "SelectedConnections"
                                          ? null
                                          : ColorValues.WHITE,
                                      height: 14.0,
                                    ))
                                    : Container(
                                  height: 0.0,
                                ),

                              ],
                            ),
                          )
                        ],
                      )),
                  flex: 4,
                ),
                Expanded(
                  child: userIdPref == userPostModal.postedBy &&
                      roleId == userPostModal.roleId.toString()
                      ? Container(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,
                          userPostModal.tagList.length > 0 ? 38.0 : 15.0),
                      child: InkWell(
                        child: Image.asset(
                          "assets/feed/three_dot_white.png",
                          width: 15.0,
                          height: 15.0,
                        ),
                        onTap: () {

                        },
                      ))
                      : Container(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,
                          userPostModal.tagList.length > 0 ? 38.0 : 15.0),
                      child: InkWell(
                        child: Image.asset(
                          "assets/feed/three_dot_white.png",
                          width: 15.0,
                          height: 15.0,
                        ),
                        onTap: () {

                        },
                      )),
                  flex: 0,
                )
              ],
            ),
          )
      );
  }

  Padding getListView(UserPostModal userPostModal, index) {
    return PaddingWrap.paddingAll(
        0.0,
        Container(
            color: ColorValues.SCREEN_BG_COLOR,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Stack(
                  children: <Widget>[
                    //  getEvent(userPostModal),

                    userPostModal.postdata == null ||
                        userPostModal.postdata.text == null ||
                        userPostModal.postdata.text == "null"
                        ? Container(
                      height: 0.0,
                    )
                        : PaddingWrap.paddingfromLTRB(
                        10.0,
                        0.0,
                        10.0,
                        0.0,
                        Container(
                            color: Colors.transparent,
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  userPostModal.postdata.text == "" ||
                                      userPostModal.postdata.text ==
                                          "null" ||
                                      userPostModal.postdata.text ==
                                          "\n"
                                      ? Container(
                                    height: 1.0,
                                  )
                                      : userPostModal.postdata.assetsList
                                      .length == 0 &&
                                      // (userPostModal.postdata.media ==
                                      //     null ||
                                      //     userPostModal.postdata
                                      //         .media ==
                                      //         "" ||
                                      //     userPostModal.postdata
                                      //         .media ==
                                      //         "null") &&
                                      (userPostModal.postdata
                                          .metaUrl !=
                                          "" &&
                                          userPostModal.postdata
                                              .metaImage !=
                                              "")
                                      ? exp
                                      .allMatches(
                                      userPostModal
                                          .postdata
                                          .text)
                                      .length ==
                                      1 &&
                                      userPostModal
                                          .postdata.text
                                          .toString()
                                          .replaceAll(exp, '')
                                          .length ==
                                          0
                                      ? Container(
                                    height: 0.0,
                                  )
                                      : PaddingWrap.paddingfromLTRB(
                                      4.0,
                                      10.0,
                                      13.0,
                                      0.0,
                                      Container(
                                        child: Linkify(
                                          onOpen:
                                              (link) async {

                                          },
                                          text: "",

                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR,
                                              fontSize: 14.0),
                                          linkStyle: TextStyle(
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR,
                                              fontSize: 14.0),
                                        ),
                                      ))
                                      : Container(
                                    child: Linkify(
                                      onOpen: (link) async {

                                      },
                                      text: "",
                                      // userPostModal
                                      //         .postdata.text +
                                      //     "SSSSSS",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontFamily: Constant
                                              .TYPE_CUSTOMREGULAR,
                                          fontSize: 14.0),
                                      linkStyle: TextStyle(
                                          color: ColorValues
                                              .BLUE_COLOR_BOTTOMBAR,
                                          fontFamily: Constant
                                              .TYPE_CUSTOMREGULAR,
                                          fontSize: 14.0),
                                    ),
                                  ),
                                ),
                              ],
                            ))),

                    userPostModal.postdata.assetsList.length == 0
                        ? Container(
                      height: 0.0,
                    )
                        : PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        Container(
                            height: 250.0,
                            child: SizedBox(
                              // Pager view
                                height: 250.0,
                                child: PageIndicatorContainer(
                                  pageView: PageView.builder(
                                    itemCount: userPostModal.postdata
                                        .assetsList.length,
                                    controller: PageController(),
                                    itemBuilder: (context, index2) {
                                      return
                                        userPostModal.postdata
                                            .assetsList[index2].type ==
                                            'image' ?
                                        InkWell(
                                          child: Stack(children: <Widget>[
                                            Container(
                                                decoration: BoxDecoration(
                                                  color: Colors.black,
                                                ),
                                                height: 250.0,
                                                child: CachedNetworkImage(
                                                  width: double.infinity,
                                                  height: 250.0,
                                                  imageUrl: Constant
                                                      .IMAGE_PATH_SMALL +
                                                      ParseJson
                                                          .getMediumImage(
                                                          userPostModal
                                                              .postdata
                                                              .assetsList[
                                                          index2].file),
                                                  fit: BoxFit.fill,
                                                  placeholder:
                                                      (context, url) =>
                                                      _loader(context),
                                                  errorWidget: (context,
                                                      url, error) =>
                                                      _error(),
                                                )),
                                            userPostModal.postdata.assetsList
                                                .length ==
                                                1
                                                ? InkWell(
                                                onTap: () {
                                                  Navigator.of(context).push(
                                                      new MaterialPageRoute(
                                                          builder: (
                                                              BuildContext context) =>
                                                              CommonFullViewWidget(
                                                                  userPostModal
                                                                      .postdata
                                                                      .assetsList,
                                                                  MessageConstant
                                                                      .HOME_FEED,
                                                                  index2,
                                                                  MessageConstant
                                                                      .COMPANY_PROFILE_HEDING)));
                                                },
                                                child: Container(
                                                  height: 0.0,
                                                ))
                                                : InkWell(
                                                onTap: () {
                                                  Navigator.of(context).push(
                                                      new MaterialPageRoute(
                                                          builder: (
                                                              BuildContext context) =>
                                                              CommonFullViewWidget(
                                                                  userPostModal
                                                                      .postdata
                                                                      .assetsList,
                                                                  MessageConstant
                                                                      .HOME_FEED,
                                                                  index2,
                                                                  MessageConstant
                                                                      .COMPANY_PROFILE_HEDING)));
                                                },
                                                child: Container(
                                                  height: 250.0,
                                                  width:
                                                  double.infinity,
                                                  child: Image.asset(
                                                    "assets/newDesignIcon/navigation/layer_image.png",
                                                    fit: BoxFit.fill,
                                                  ),
                                                ))
                                          ]),
                                          onTap: () {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (BuildContext
                                                    context) =>
                                                        CommonFullViewWidget(
                                                            userPostModal
                                                                .postdata
                                                                .assetsList,
                                                            MessageConstant
                                                                .HOME_FEED,
                                                            index2,
                                                            MessageConstant
                                                                .COMPANY_PROFILE_HEDING)));
                                          },
                                        ) : InkWell(
                                          child: Container(
                                              decoration: BoxDecoration(
                                                color: Colors.black,
                                                borderRadius: BorderRadius
                                                    .circular(0),
                                              ),
                                              height: 250.0,
                                              width: double.infinity,
                                              child: Center(
                                                  child: Center(
                                                    child: Center(
                                                      child: VideoPlayPause(
                                                          userPostModal
                                                              .postdata
                                                              .assetsList[
                                                          index2].file,
                                                          userPostModal
                                                              .feedId,
                                                          true),
                                                    ),
                                                  ))),
                                          onTap: () {
                                            print('ontap video feed::: ');

                                            /*Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (BuildContext
                                      context) =>
                                       VideoFullViewWidget(
                                          '',
                                          MessageConstant
                                              .VIEWER_END_REWCOMMENDATION_HEDING,
                                          Constant.IMAGE_PATH + userPostModal.postdata.media
                                      )));*/
                                          },
                                        );
                                    },
                                    onPageChanged: (index) {},
                                  ),
                                  align: IndicatorAlign.bottom,
                                  length: userPostModal.postdata.assetsList
                                      .length,
                                  indicatorSpace: 10.0,
                                  indicatorColor: userPostModal.postdata
                                      .assetsList.length ==
                                      1
                                      ? Colors.transparent
                                      : Color(0xffc4c4c4),
                                  indicatorSelectorColor: userPostModal
                                      .postdata.assetsList
                                      .length ==
                                      1
                                      ? Colors.transparent
                                      : ColorValues.WHITE,
                                  shape: IndicatorShape.circle(size: 5.0),
                                )))),


                    userPostModal.postdata.assetsList.length == 0 &&

                        (userPostModal.postdata
                            .metaUrl ==
                            "" &&
                            userPostModal.postdata
                                .metaImage ==
                                "") ? imageViewForGetListViewBlue(
                        userPostModal, index) :
                    imageViewForGetListView(userPostModal, index),
                  ],
                ),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Padding(
                        padding:
                        const EdgeInsets.only(left: 20, top: 5),
                        child: Row(
                          children: <Widget>[
                            InkWell(
                              onTap: () {
                                print("onTapLike1+++++++++++++");
                                onTapLike(userPostModal);
                              },
                              child: userPostModal?.isLike ?? false
                                  ? Image.asset(
                                "assets/feed/heart_red.png",
                                height: 22.0,
                                width: 22.0,
                              )
                                  : Image.asset(
                                "assets/feed/heart_blue.png",
                                height: 22.0,
                                width: 22.0,
                              ),
                            ),
                            const SizedBox(width: 7),
                            InkWell(
                              onTap: () {
                                if (userPostModal.isShowCommentIcon)
                                  userPostModal.isShowCommentIcon =
                                  false;
                                else {
                                  userPostModal.isShowCommentIcon =
                                  true;
                                }
                                setState(() {});
                              },
                              child: Image.asset(
                                "assets/feed/comment.png",
                                height: 26.0,
                                width: 26.0,
                              ),
                            ),

                            Spacer(),
                          ],
                        ),
                      ),
                      flex: 1,
                    ),
                  ],
                ),
                Padding(
                  padding:
                  const EdgeInsets.fromLTRB(10.0, 10, 0, 0),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: (userPostModal?.likesCount ?? 0) > 0
                            ? PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            10.0,
                            0.0,
                            InkWell(
                              child: TextViewWrap.textView(
                                  userPostModal.likesCount ==
                                      0
                                      ? "Like"
                                      : userPostModal.likesCount ==
                                      1
                                      ? "1 Like"
                                      : userPostModal.likesCount
                                      .toString() +
                                      " Likes",
                                  TextAlign.end,
                                  ColorValues.labelColor,
                                  12.0,
                                  FontWeight.w500),
                              onTap: () {
                                onTapLikeText(userPostModal);
                              },
                            ))
                            : const SizedBox.shrink(),
                        flex: 0,
                      ),
                      (userPostModal?.commentList?.length ?? 0) == 0
                          ? const SizedBox.shrink()
                          : InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          0.0,
                          0.0,
                          0.0,
                          TextViewWrap.textView(
                              userPostModal.commentList
                                  .length ==
                                  0
                                  ? "Comment"
                                  : "" +
                                  userPostModal
                                      .commentList.length
                                      .toString() +
                                  " Comments",
                              TextAlign.left,
                              ColorValues.labelColor,
                              12.0,
                              FontWeight.w500),
                        ),
                        onTap: () {
                          onTapViewAllComments(
                              userPostModal.commentList,
                              userPostModal.feedId,
                              userPostModal);
                        },
                      )
                    ],
                  ),
                ),
                userPostModal?.postdata?.metaUrl != ""
                    ? Container(
                    padding: EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 0),
                    width: double.infinity,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10),
                      color: Color(0XFFFFFFFF),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          InkWell(
                            child: Text(
                              userPostModal.postdata.metaTitle == null
                                  ? ""
                                  : userPostModal.postdata.metaTitle.trim(),
                              textAlign: TextAlign.start,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color:
                                  ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily: Constant.TYPE_CUSTOMBOLD,
                                  fontSize: 14.0),
                            ),
                            onTap: () {

                            },
                          ),
                          InkWell(
                            child: Text(
                              userPostModal.postdata.metaSource == null
                                  ? ""
                                  : userPostModal.postdata.metaSource.trim(),
                              textAlign: TextAlign.start,
                              maxLines: 1,
                              style: TextStyle(
                                  fontWeight: FontWeight.w400,
                                  color:
                                  ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily: Constant.latoRegular,
                                  fontSize: 14.0),
                            ),
                            onTap: () {
                              //onTapView();
                              Navigator.of(context).push(
                                  new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          WebViewWidget(
                                              userPostModal.postdata.metaUrl,
                                              "spikeview")));
                            },
                          ),
                          Text(
                            userPostModal.postdata.metaDescription == null
                                ? ""
                                : userPostModal.postdata.metaDescription
                                .trim(),
                            textAlign: TextAlign.start,
                            maxLines: isShowMore ? 30 : 3,
                            style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontWeight: FontWeight.w400,
                                fontFamily: Constant.latoRegular,
                                fontSize: 14.0),
                          ),
                          userPostModal.postdata.metaDescription
                              .trim()
                              .length >
                              190
                              ? InkWell(
                              child: Text(
                                isShowMore ? "Less" : "More",
                                textAlign: TextAlign.start,
                                maxLines: 1,
                                style: TextStyle(
                                    color:
                                    ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    fontFamily:
                                    Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 12.0),
                              ),
                              onTap: () {
                                setState(() {
                                  if (isShowMore) {
                                    isShowMore = false;
                                  } else
                                    isShowMore = true;
                                });
                              })
                              : Container(
                            height: 0.0,
                          )
                        ],
                      ),
                    ))
                    : const SizedBox.shrink(),

                userPostModal.postdata == null ||
                    userPostModal.postdata.text == null ||
                    userPostModal.postdata.text == "null"
                    ? const SizedBox.shrink()
                    : PaddingWrap.paddingfromLTRB(
                    20.0,
                    0.0,
                    10.0,
                    0.0,
                    Container(
                        color: Colors.transparent,
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              userPostModal.postdata.text == "" ||
                                  userPostModal.postdata.text ==
                                      "null" ||
                                  userPostModal.postdata.text ==
                                      "\n"
                                  ? Container(
                                height: 1.0,
                              )
                                  : userPostModal.postdata.imageList.length ==
                                  0 &&
                                  (userPostModal.postdata.media ==
                                      null ||
                                      userPostModal.postdata
                                          .media ==
                                          "" ||
                                      userPostModal.postdata
                                          .media ==
                                          "null") &&
                                  (userPostModal.postdata
                                      .metaUrl !=
                                      "" &&
                                      userPostModal.postdata
                                          .metaImage !=
                                          "")
                                  ? exp
                                  .allMatches(
                                  userPostModal
                                      .postdata
                                      .text)
                                  .length ==
                                  1 &&
                                  userPostModal
                                      .postdata.text
                                      .toString()
                                      .replaceAll(exp, '')
                                      .length ==
                                      0
                                  ? Container(
                                height: 0.0,
                              )
                                  : PaddingWrap.paddingfromLTRB(
                                  4.0,
                                  10.0,
                                  13.0,
                                  0.0,
                                  Container(
                                    child: Linkify(
                                      onOpen:
                                          (link) async {
                                        Navigator.of(
                                            context,
                                            rootNavigator:
                                            true)
                                            .push(new MaterialPageRoute(
                                            fullscreenDialog:
                                            true,
                                            builder: (BuildContext
                                            context) =>
                                                WebViewWidget(
                                                    link.url,
                                                    "spikeview")));
                                      },
                                      text: exp
                                          .allMatches(userPostModal
                                          .postdata
                                          .text)
                                          .length >
                                          1
                                          ? userPostModal
                                          .postdata
                                          .text
                                          : userPostModal
                                          .postdata
                                          .text
                                          .toString()
                                          .replaceAll(
                                          exp,
                                          ''),
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontFamily: Constant.latoRegular,
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w400),
                                      linkStyle: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontFamily: Constant.latoRegular,
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w400),
                                    ),
                                  ))
                                  : Container(
                                child: Linkify(
                                  onOpen: (link) async {
                                    Navigator.of(context,
                                        rootNavigator:
                                        true)
                                        .push(new MaterialPageRoute(
                                        fullscreenDialog:
                                        true,
                                        builder: (BuildContext
                                        context) =>
                                            WebViewWidget(
                                                link.url,
                                                "spikeview")));
                                  },
                                  text: userPostModal
                                      .postdata.text,
                                  style: TextStyle(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontFamily: Constant.latoRegular,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w400),
                                  linkStyle: TextStyle(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontFamily: Constant.latoRegular,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w400),
                                ),
                              ),
                            ),
                          ],
                        ))),
                PaddingWrap.paddingAll(
                    0.0,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        // Comment List view
                        Padding(
                            padding: EdgeInsets.fromLTRB(
                                0.0, 5.0, 0.0, 0.0),
                            child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: List.generate(
                                    userPostModal.commentList.length >
                                        3
                                        ? 3
                                        : userPostModal.commentList
                                        .length, (int index) {
                                  return PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      5.0,
                                      10.0,
                                      0.0,
                                      Row(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: <Widget>[
                                          InkWell(
                                              child: Container(
                                                  width: 40.0,
                                                  height: 40.0,
                                                  child: ClipRRect(
                                                      borderRadius: BorderRadius
                                                          .circular(10),
                                                      child: FadeInImage
                                                          .assetNetwork(
                                                        fit: BoxFit.cover,
                                                        width: double
                                                            .infinity,
                                                        placeholder: userPostModal
                                                            .commentList[
                                                        index]
                                                            .roleId ==
                                                            "4"
                                                            ? "assets/profile/partner_img.png"
                                                            : 'assets/profile/user_on_user.png',
                                                        image: Constant
                                                            .IMAGE_PATH_SMALL +
                                                            userPostModal
                                                                .commentList[
                                                            index]
                                                                .profilePicture,
                                                      ))),
                                              onTap: () {
                                                print(
                                                    "OnClick comment++++++++++++");
                                                print(
                                                    "OnClick comment++++++++++++" +
                                                        userPostModal
                                                            .commentList[
                                                        index]
                                                            .toString());
                                                onTapImageTile(
                                                    userPostModal
                                                        .commentList[
                                                    index]
                                                        .commentedBy,
                                                    userPostModal
                                                        .commentList[
                                                    index]
                                                        .roleId);
                                              }), // User Image
                                          SizedBox(
                                            width: 20.0,
                                          ),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Padding(
                                                  padding:
                                                  const EdgeInsets
                                                      .fromLTRB(
                                                      0, 0, 0, 0),
                                                  child: Container(
                                                      child: Row(
                                                        children: <
                                                            Widget>[
                                                          RichText(
                                                            maxLines: 2,
                                                            textAlign:
                                                            TextAlign
                                                                .start,
                                                            text:
                                                            TextSpan(
                                                              text: userPostModal
                                                                  .commentList[
                                                              index]
                                                                  .name,
                                                              style:
                                                              TextStyle(
                                                                color: ColorValues
                                                                    .HEADING_COLOR_EDUCATION,
                                                                fontSize:
                                                                14.0,
                                                                fontWeight:
                                                                FontWeight
                                                                    .bold,
                                                              ),
                                                              /* children: <TextSpan>[
                                                                  TextSpan(
                                                                      text: userPostModal
                                                                          .commentList[
                                                                              index]
                                                                          .comment,
                                                                      style:  TextStyle(
                                                                          color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                              14.0,
                                                                          fontWeight:
                                                                              FontWeight
                                                                                  .normal,
                                                                          fontFamily:
                                                                              Constant.TYPE_CUSTOMREGULAR)),
                                                                ],*/
                                                            ),
                                                          ),
                                                          userPostModal
                                                              .commentList[index] !=
                                                              null &&
                                                              userPostModal
                                                                  .commentList[index]
                                                                  .roleId ==
                                                                  "1"
                                                          //true
                                                              ? Util
                                                              .getStudentBadge12(
                                                              userPostModal
                                                                  .commentList[
                                                              index]
                                                                  .badge,
                                                              userPostModal
                                                                  .commentList[index]
                                                                  .badgeImage)
                                                              : Container(
                                                            height:
                                                            0.0,
                                                            width:
                                                            0.0,
                                                          ),
                                                        ],
                                                      )),
                                                ),
                                                Container(
                                                  child: Linkify(
                                                    onOpen:
                                                        (link) async {
                                                      Navigator.of(
                                                          context,
                                                          rootNavigator:
                                                          true)
                                                          .push(
                                                          new MaterialPageRoute(
                                                              fullscreenDialog:
                                                              true,
                                                              builder: (
                                                                  BuildContext context) =>
                                                                  WebViewWidget(
                                                                      link
                                                                          .url,
                                                                      "spikeview")));
                                                    },
                                                    text: userPostModal
                                                        .commentList[
                                                    index]
                                                        .comment,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        fontSize:
                                                        14.0,
                                                        fontWeight:
                                                        FontWeight
                                                            .normal,
                                                        fontFamily:
                                                        Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                    linkStyle: TextStyle(
                                                        color: ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        fontFamily:
                                                        Constant
                                                            .TYPE_CUSTOMREGULAR,
                                                        fontSize:
                                                        14.0),
                                                  ),
                                                ),
                                                Padding(
                                                    padding:
                                                    EdgeInsets
                                                        .fromLTRB(
                                                        0.0,
                                                        5.0,
                                                        0.0,
                                                        0.0),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .start,
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .center,
                                                      children: <
                                                          Widget>[
                                                        Expanded(
                                                          child: Row(
                                                            mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                            children: <
                                                                Widget>[
                                                              Text(
                                                                userPostModal
                                                                    .commentList[index]
                                                                    .dateTime,
                                                                textAlign:
                                                                TextAlign.end,
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR,
                                                                    fontSize: 12.0,
                                                                    fontFamily: Constant
                                                                        .customRegular),
                                                              )
                                                            ],
                                                          ),
                                                          flex: 0,
                                                        ),
                                                        Container(
                                                          width: 10.0,
                                                        ),
                                                        Expanded(
                                                          child: userIdPref ==
                                                              userPostModal
                                                                  .commentList[index]
                                                                  .commentedBy //&&//
                                                          // userPostModal.commentList[index].isComment
                                                              ? InkWell(
                                                            child:
                                                            Padding(
                                                              padding: const EdgeInsets
                                                                  .fromLTRB(
                                                                  0.0, 0, 0,
                                                                  0),
                                                              child: Image
                                                                  .asset(
                                                                "assets/feed/three_dot_blue.png",
                                                                width: 15.0,
                                                                height: 15.0,
                                                              ),
                                                            ),
                                                            onTap:
                                                                () {
                                                              // optionForDelete(userPostModal.commentList, userPostModal.feedId, userPostModal, userPostModal.commentList[index].commentId, index);
                                                            },
                                                          )
                                                              : Container(
                                                            height:
                                                            1.0,
                                                          ),
                                                          flex: 0,
                                                        )
                                                      ],
                                                    )),
                                              ],
                                            ),
                                            flex: 1,
                                          ) // Comment List Cell
                                        ],
                                      ));
                                }))),

                        // View All Comments
                        userPostModal.commentList.length > 3
                            ? InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            5.0,
                            TextViewWrap.textView(
                                "View All " +
                                    userPostModal
                                        .commentList.length
                                        .toString() +
                                    " Comments",
                                TextAlign.left,
                                ColorValues.labelColor,
                                12.0,
                                FontWeight.w500),
                          ),
                          onTap: () {
                            onTapViewAllComments(
                                userPostModal.commentList,
                                userPostModal.feedId,
                                userPostModal);
                          },
                        )
                            : Container(
                          height: 0.0,
                        ),

                        // Comment Edit Text
                        userPostModal.isShowCommentIcon
                            ? PaddingWrap.paddingAll(
                            10.0,
                            Row(
                              children: <Widget>[
                                //Alok Code Done
                                Container(
                                  width: 40.0,
                                  height: 40.0,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child:
                                    FadeInImage.assetNetwork(
                                      fit: BoxFit.cover,
                                      placeholder: roleId == "4"
                                          ? "assets/profile/partner_img.png"
                                          : 'assets/profile/user_on_user.png',
                                      image: roleId == "4"
                                          ? Constant.IMAGE_PATH +
                                          prefs.getString(
                                              UserPreference
                                                  .COMPANY_IMAGE_PATH)
                                          : Constant.IMAGE_PATH +
                                          prefs.getString(
                                              UserPreference
                                                  .PROFILE_IMAGE_PATH),
                                      height: 45.0,
                                      width: 45.0,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 20.0,
                                ),
                                Expanded(
                                    child: Container(
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                width: 1.0,
                                                color: ColorValues
                                                    .LIGHT_GREY_TEXT_COLOR)),
                                        child: Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .center,
                                          mainAxisAlignment:
                                          MainAxisAlignment
                                              .center,
                                          children: <Widget>[
                                            Expanded(
                                              child: TextField(
                                                controller:
                                                userPostModal
                                                    .txtController,
                                                style: TextStyle(
                                                    fontFamily:
                                                    Constant
                                                        .TYPE_CUSTOMREGULAR),
                                                keyboardType:
                                                TextInputType
                                                    .text,
                                                textCapitalization:
                                                TextCapitalization
                                                    .sentences,
                                                maxLines: null,
                                                maxLength: TextLength
                                                    .COMMENT_MAX_LENGTH,
                                                onChanged: (s) {
                                                  if (s
                                                      .trim()
                                                      .length >
                                                      0) {
                                                    userPostModal
                                                        .isCommentIconVisible =
                                                    true;
                                                  } else {
                                                    userPostModal
                                                        .isCommentIconVisible =
                                                    false;
                                                  }
                                                  setState(() {
                                                    userPostModal
                                                        .isCommentIconVisible;
                                                  });
                                                },
                                                decoration:
                                                InputDecoration(
                                                  border:
                                                  InputBorder
                                                      .none,
                                                  filled: true,
                                                  counterText: "",
                                                  counterStyle: TextStyle(
                                                      fontFamily:
                                                      Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                  hintText: roleId ==
                                                      "4"
                                                      ? "Add Comment as " +
                                                      prefs.getString(
                                                          UserPreference
                                                              .COMPANY_NAME_PATH)
                                                      : "Add Comment as " +
                                                      prefs.getString(
                                                          UserPreference.NAME)
                                                          .replaceAll(
                                                          "null",
                                                          ""),
                                                  hintStyle: TextStyle(
                                                      color: ColorValues
                                                          .GREY_TEXT_COLOR,
                                                      fontSize:
                                                      14.0,
                                                      fontFamily:
                                                      Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                  fillColor: Colors
                                                      .transparent,
                                                ),
                                              ),
                                              flex: 4,
                                            ),
                                            Expanded(
                                              child:
                                              /*userPostModal
                                                        .isCommentIconVisible
                                                    ?*/
                                              InkWell(
                                                child: PaddingWrap
                                                    .paddingfromLTRB(
                                                    0.0,
                                                    0.0,
                                                    5.0,
                                                    0.0,
                                                    Image
                                                        .asset(
                                                      "assets/feed/sent_icon.png",
                                                      width:
                                                      22.0,
                                                      height:
                                                      22.0,
                                                    )),
                                                onTap: () {
                                                  if (userPostModal
                                                      .isCommentIconVisible) {
                                                    FocusScope.of(
                                                        context)
                                                        .requestFocus(
                                                        FocusNode());
                                                    userPostModal
                                                        .isCommentIconVisible =
                                                    false;
                                                    onAddComment(
                                                        userPostModal
                                                            .feedId,
                                                        userPostModal
                                                            .txtController
                                                            .text,
                                                        userPostModal);
                                                    userPostModal
                                                        .txtController
                                                        .text = "";
                                                    setState(() {
                                                      userPostModal
                                                          .txtController;
                                                      userPostModal
                                                          .isCommentIconVisible;
                                                    });
                                                  }
                                                },
                                              )
                                              /*:  Container(
                                                        height: 0.0,
                                                      )*/
                                              ,
                                              flex: 0,
                                            )
                                          ],
                                        )),
                                    flex: 1)
                              ],
                            ))
                            : Container(
                          height: 0.0,
                        ),

                        (userPostList.length - 1) == index
                            ? Container(
                          height: 10.0,
                        )
                            : Container(
                          height: 10.0,
                        )
                        // PaddingWrap.paddingfromLTRB(
                        //     0.0,
                        //     10.0,
                        //     0.0,
                        //     10.0,
                        //     Divider(
                        //       color:
                        //           ColorValues.GREY_TEXT_COLOR,
                        //       height: 1.0,
                        //     ))
                      ],
                    ))

              ],
            )));
  }

  Widget _imageAndNamegetListViewPost(userPostModal, index) {
    return PaddingWrap.paddingfromLTRB(
        11.0,
        10.0,
        11.0,
        10.0,
        Row(
          children: <Widget>[
            Expanded(
              child: InkWell(
                child: Center(
                    child: Container(
                        width: 50.0,
                        height: 50.0,
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: AppConstants.colorStyle
                                    .darkBlue,
                                //AppConstants.colorStyle.white,
                                width: 1),
                            borderRadius:
                            const BorderRadius.all(Radius.circular(10))),
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: FadeInImage.assetNetwork(
                              fit: BoxFit.cover,
                              width: double.infinity,
                              placeholder: userPostModal.roleId == "4"
                                  ? "assets/profile/partner_img.png"
                                  : 'assets/profile/user_on_user.png',
                              image: Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getSmallImage(
                                      userPostModal.profilePicture),
                            )))),
                onTap: () {
                  onTapImageTile(
                      userPostModal.postedBy, userPostModal.roleId);
                },
              ),
              flex: 0,
            ),
            Expanded(
              child: PaddingWrap.paddingfromLTRB(
                  8.0,
                  0.0,
                  15.0,
                  0.0,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      InkWell(
                        child: Container(
                            child: RichText(
                              maxLines: 2,
                              textAlign: TextAlign.start,
                              text: TextSpan(
                                text: userPostModal.lastName == null ||
                                    userPostModal.lastName == "null"
                                    ? userPostModal.firstName
                                    : userPostModal.firstName +
                                    " " +
                                    userPostModal.lastName,
                                style: TextStyle(
                                    color: ColorValues
                                        .HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: Constant.latoRegular
                                ),
                                children: [
                                  WidgetSpan(
                                    child: userPostModal.roleId == "1"
                                        ? Util
                                        .getStudentBadgeRichTextWithPadding(
                                        userPostModal.badge,
                                        userPostModal.badgeImage)
                                        : Container(
                                      height: 0.0,
                                      width: 0.0,
                                    ),
                                  ),
                                  TextSpan(
                                      text: ' shared ',
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w500,
                                          fontFamily: Constant.latoRegular)),
                                  TextSpan(
                                    text: userPostModal.postedGroupName !=
                                        null &&
                                        userPostModal.postedGroupName !=
                                            "null" &&
                                        userPostModal.postedGroupName != ""
                                        ? userPostModal.postedGroupName
                                        : userPostModal.postOwnerLastName ==
                                        ""
                                        ? userPostModal.postOwnerFirstName
                                        .trim() +
                                        "'s"
                                        : userPostModal.postOwnerFirstName +
                                        " " +
                                        userPostModal.postOwnerLastName
                                            .toString()
                                            .trim() +
                                        "'s",
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        if (userPostModal.postedGroupName ==
                                            null ||
                                            userPostModal.postedGroupName !=
                                                "null" ||
                                            userPostModal.postedGroupName !=
                                                "") {
                                          Navigator.of(context).push(
                                              new MaterialPageRoute(
                                                  builder:
                                                      (BuildContext context) =>
                                                      GroupDetailWidget(
                                                          userPostModal
                                                              .postedGroupId,
                                                          "",
                                                          "",
                                                          "",
                                                          "")));
                                        }
                                      },
                                    style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: Constant.latoRegular
                                    ),
                                  ),
                                  TextSpan(
                                    text: " post",
                                    style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: Constant.latoRegular
                                    ),
                                  ),
                                ],
                              ),
                            )),
                        onTap: () {
                          onTapImageTile(
                              userPostModal.postedBy, userPostModal.roleId);
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                        child: Row(
                          children: [
                            TextViewWrap.textView(
                                userPostModal.dateTime,
                                TextAlign.center,
                                ColorValues.labelColor,
                                12.0,
                                FontWeight.normal),
                            userIdPref == userPostModal.postedBy &&
                                roleId == userPostModal.roleId.toString()
                                ? PaddingWrap.paddingfromLTRB(
                                10.0,
                                0.0,
                                5.0,
                                0.0,
                                Image.asset(
                                  userPostModal.visibility == "Private"
                                      ? "assets/profile/post/private_new.png"
                                      : userPostModal.visibility ==
                                      "SelectedConnections"
                                      ? "assets/profile/post/selected_connection.png"
                                      : userPostModal.visibility ==
                                      "AllConnections"
                                      ? "assets/profile/post/connection.png"
                                      : userPostModal
                                      .visibility ==
                                      "Group"
                                      ? "assets/profile/post/group_data.png"
                                      : "assets/profile/post/community.png",
                                  width: 13.0,
                                  color: userPostModal.visibility ==
                                      "SelectedConnections"
                                      ? null
                                      : ColorValues.labelColor,
                                  height: 13.0,
                                ))
                                : Container(height: 0.0),
                          ],
                        ),
                      )
                    ],
                  )),
              flex: 4,
            ),

            InkWell(
                onTap: () {
                  if (userIdPref == userPostModal.postedBy &&
                      roleId == userPostModal.roleId.toString()) {
                    // optionMenuDelete(userPostModal, index);

                  } else {
                    // optionForReport(userPostModal, index);

                  }
                },
                child: Image.asset(
                  "assets/feed/three_dot_blue.png",
                  height: 15.0,
                  width: 15.0,
                )


            ),
          ],
        ));
  }

  Widget _imageAndNamegetListViewPost2(userPostModal, index) {
    return PaddingWrap.paddingfromLTRB(
        17.0,
        10.0,
        10.0,
        10.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: InkWell(
                child: Container(
                    child: Center(
                        child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: userPostModal
                                        .postdata.imageList.length ==
                                        0
                                        ? userPostModal.postdata.metaUrl != ""
                                        ? AppConstants.colorStyle.white
                                        : AppConstants.colorStyle.darkBlue
                                        : AppConstants.colorStyle.white,
                                    width: 1),
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(10))),
                            width: 50.0,
                            height: 50.0,
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                  placeholder:
                                  userPostModal.postOwnerRoleId == "4"
                                      ? "assets/profile/partner_img.png"
                                      : 'assets/profile/user_on_user.png',
                                  image: Constant.IMAGE_PATH_SMALL +
                                      ParseJson.getSmallImage(
                                          userPostModal.profilePicture),
                                  // image: Constant
                                  //         .IMAGE_PATH_SMALL +
                                  //     ParseJson.getSmallImage(
                                  //         userPostModal
                                  //             .postOwnerProfilePicture),
                                ))))),
                onTap: () {
                  onTapImageTile(
                      userPostModal.postOwner, userPostModal.postOwnerRoleId);
                },
              ),
              flex: 0,
            ),
            Expanded(
              child: PaddingWrap.paddingfromLTRB(
                  8.0,
                  0.0,
                  15.0,
                  0.0,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: InkWell(
                              child: Container(
                                  child: RichText(
                                    maxLines: 2,
                                    textAlign: TextAlign.start,
                                    text: TextSpan(
                                      text: userPostModal.lastName == "null"
                                          ? userPostModal.firstName
                                          : userPostModal.firstName +
                                          " " +
                                          userPostModal.lastName,
                                      style: TextStyle(
                                        color: userPostModal
                                            .postdata.imageList.length ==
                                            0
                                            ? userPostModal.postdata
                                            .metaUrl != ""
                                            ? AppConstants.colorStyle.white
                                            : AppConstants.colorStyle.darkBlue
                                            : AppConstants.colorStyle.white,
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: Constant.latoRegular,
                                      ),
                                      children: userPostModal.tagList
                                          .length ==
                                          0 &&
                                          userPostModal.groupList.length == 0
                                          ? [
                                        WidgetSpan(
                                          child: userPostModal.roleId == "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal.badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                      ]
                                          : userPostModal.tagList.length !=
                                          0 &&
                                          userPostModal
                                              .groupList.length !=
                                              0
                                          ? [
                                        WidgetSpan(
                                          child: userPostModal.roleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                        TextSpan(
                                            text: ' > ',
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight.normal,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMREGULAR)),
                                        TextSpan(
                                          text: userPostModal
                                              .groupList[0]
                                              .groupName ==
                                              null ||
                                              userPostModal
                                                  .groupList[0]
                                                  .groupName ==
                                                  "null"
                                              ? ""
                                              : userPostModal
                                              .tagList[0].groupName,
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        userPostModal.groupList.length >
                                            1
                                            ? TextSpan(
                                          text: ' and ',
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.groupList.length >
                                            1
                                            ? TextSpan(
                                          text: (userPostModal
                                              .groupList
                                              .length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight.bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.groupList.length >
                                            1
                                            ? TextSpan(
                                          text: " others ",
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight.bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        TextSpan(
                                            text: ' with ',
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight.normal,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMREGULAR)),
                                        TextSpan(
                                          text: userPostModal.tagList[0]
                                              .name ==
                                              null ||
                                              userPostModal
                                                  .tagList[0]
                                                  .name ==
                                                  "null"
                                              ? ""
                                              : userPostModal
                                              .tagList[0].name,
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: ' and ',
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: (userPostModal
                                              .tagList
                                              .length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight.bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: " others ",
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight.bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                      ]
                                          : userPostModal.groupList.length !=
                                          0
                                          ? [
                                        WidgetSpan(
                                          child: userPostModal
                                              .roleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                        TextSpan(
                                            text: ' > ',
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight
                                                    .normal,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMREGULAR)),
                                        TextSpan(
                                          text: userPostModal
                                              .groupList[
                                          0]
                                              .groupName ==
                                              null ||
                                              userPostModal
                                                  .groupList[
                                              0]
                                                  .groupName ==
                                                  "null"
                                              ? ""
                                              : userPostModal
                                              .groupList[0]
                                              .groupName,
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight.bold,
                                          ),
                                        ),
                                        userPostModal.groupList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: ' and ',
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.groupList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: (userPostModal
                                              .groupList
                                              .length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight
                                                .bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.groupList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: " others ",
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight
                                                .bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                      ]
                                          : // taglist is not empty
                                      [
                                        WidgetSpan(
                                          child: userPostModal
                                              .roleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .badge,
                                              userPostModal
                                                  .badgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                        TextSpan(
                                            text: ' with ',
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight
                                                    .normal,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMREGULAR)),
                                        TextSpan(
                                          text: userPostModal
                                              .tagList[
                                          0]
                                              .name ==
                                              null ||
                                              userPostModal
                                                  .tagList[
                                              0]
                                                  .name ==
                                                  "null"
                                              ? ""
                                              : userPostModal
                                              .tagList[0].name,
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight.bold,
                                          ),
                                        ),
                                        userPostModal.tagList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: ' and ',
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.tagList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: (userPostModal
                                              .tagList
                                              .length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight
                                                .bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.tagList
                                            .length >
                                            1
                                            ? TextSpan(
                                          text: " others ",
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontWeight:
                                            FontWeight
                                                .bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight:
                                              FontWeight
                                                  .normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                      ],
                                    ),
                                  )),
                              onTap: () {
                                if (userPostModal.tagList.length > 0) {
                                  Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              TagDetailWidget(
                                                  userPostModal.tagList)));
                                } else {
                                  print("clicked");
                                  onTapImageTile(userPostModal.postOwner,
                                      userPostModal.postOwnerRoleId);
                                }
                              },
                            ),
                            flex: 0,
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                        child: Row(
                          children: [
                            // color:userPostModal.postdata.imageList.length == 0?userPostModal.postdata.metaUrl !=
                            //                       ""?
                            TextViewWrap.textView(
                                userPostModal.dateTime,
                                TextAlign.center,
                                userPostModal.postdata.imageList.length == 0
                                    ? userPostModal.postdata.metaUrl != ""
                                    ? ColorValues.WHITE
                                    : ColorValues
                                    .HEADING_COLOR_EDUCATION_1
                                    : ColorValues.WHITE,
                                12.0,
                                FontWeight.w500),
                            userIdPref == userPostModal.postedBy &&
                                roleId == userPostModal.roleId.toString()
                                ? PaddingWrap.paddingfromLTRB(
                                10.0,
                                0.0,
                                5.0,
                                0.0,
                                Image.asset(
                                  userPostModal.visibility == "Private"
                                      ? "assets/profile/post/private_new.png"
                                      : userPostModal.visibility ==
                                      "SelectedConnections"
                                      ? "assets/profile/post/selected_connection.png"
                                      : userPostModal.visibility ==
                                      "AllConnections"
                                      ? "assets/profile/post/connection.png"
                                      : userPostModal
                                      .visibility ==
                                      "Group"
                                      ? "assets/profile/post/group_data.png"
                                      : "assets/profile/post/community.png",
                                  width: 13.0,
                                  color: userPostModal.visibility ==
                                      "SelectedConnections"
                                      ? null
                                      : ColorValues.GREY_TEXT_COLOR,
                                  height: 13.0,
                                ))
                                : Container(height: 0.0),
                          ],
                        ),
                      ),

                      // TextViewWrap.textView(
                      //     userPostModal
                      //         .shareTime,
                      //     TextAlign.center,
                      //     ColorValues
                      //         .GREY_TEXT_COLOR,
                      //     12.0,
                      //     FontWeight
                      //         .normal),
                    ],
                  )),
              flex: 4,
            ),
            InkWell(
                onTap: () {

                },
                child: userPostModal.postdata.imageList.length == 0
                    ? userPostModal.postdata.metaUrl != ""
                    ? Image.asset(
                  "assets/feed/three_dot_white.png",
                  height: 15.0,
                  width: 15.0,
                )
                    : Image.asset(
                  "assets/feed/three_dot_blue.png",
                  height: 15.0,
                  width: 15.0,
                )
                    : Image.asset(
                  "assets/feed/three_dot_white.png",
                  height: 15.0,
                  width: 15.0,
                )),
          ],
        ));
  }

  Widget _imageAndNamegetListViewForSharedPostBlue(userPostModal, index) {
    return PaddingWrap.paddingfromLTRB(
        17.0,
        10.0,
        10.0,
        10.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: InkWell(
                child: Container(
                    child: Center(
                        child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: ColorValues
                                        .HEADING_COLOR_EDUCATION_1,
                                    width: 1),
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(10))),
                            width: 50.0,
                            height: 50.0,
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                  placeholder:
                                  userPostModal.postOwnerRoleId == "4"
                                      ? "assets/profile/partner_img.png"
                                      : 'assets/profile/user_on_user.png',
                                  image: Constant.IMAGE_PATH_SMALL +
                                      ParseJson.getSmallImage(
                                          userPostModal
                                              .postOwnerProfilePicture),
                                ))))),
                onTap: () {
                  onTapImageTile(
                      userPostModal.postOwner, userPostModal.postOwnerRoleId);
                },
              ),
              flex: 0,
            ),
            Expanded(
              child: PaddingWrap.paddingfromLTRB(
                  8.0,
                  0.0,
                  15.0,
                  0.0,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      InkWell(
                        child: Container(
                            child: RichText(
                              maxLines: 2,
                              textAlign: TextAlign.start,
                              text: TextSpan(
                                text: userPostModal.postOwnerLastName ==
                                    "null"
                                    ? userPostModal.postOwnerFirstName
                                    : userPostModal.postOwnerFirstName +
                                    " " +
                                    userPostModal.postOwnerLastName,
                                style: TextStyle(
                                  color: ColorValues
                                      .HEADING_COLOR_EDUCATION_1,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: Constant.latoRegular,
                                ),
                                children: userPostModal.tagList.length == 0
                                    ? [
                                  WidgetSpan(
                                    child: userPostModal.postOwnerRoleId ==
                                        "1"
                                        ? Util
                                        .getStudentBadgeRichTextWithPadding(
                                        userPostModal
                                            .postOwnerBadge,
                                        userPostModal
                                            .postOwnerBadgeImage)
                                        : Container(
                                      height: 0.0,
                                      width: 0.0,
                                    ),
                                  )
                                ]
                                    : [
                                  WidgetSpan(
                                    child: userPostModal.postOwnerRoleId ==
                                        "1"
                                        ? Util
                                        .getStudentBadgeRichTextWithPadding(
                                        userPostModal
                                            .postOwnerBadge,
                                        userPostModal
                                            .postOwnerBadgeImage)
                                        : Container(
                                      height: 0.0,
                                      width: 0.0,
                                    ),
                                  ),
                                  TextSpan(
                                      text: ' with ',
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily:
                                          Constant.TYPE_CUSTOMREGULAR)),
                                  TextSpan(
                                    text: userPostModal.tagList[0].name ==
                                        null ||
                                        userPostModal.tagList[0].name ==
                                            "null"
                                        ? ""
                                        : userPostModal.tagList[0].name,
                                    style: TextStyle(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  userPostModal.tagList.length > 1
                                      ? TextSpan(
                                    text: ' and ',
                                    style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant
                                            .TYPE_CUSTOMREGULAR),
                                  )
                                      : TextSpan(
                                    text: "",
                                    style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant
                                            .TYPE_CUSTOMREGULAR),
                                  ),
                                  userPostModal.tagList.length > 1
                                      ? TextSpan(
                                    text: (userPostModal
                                        .tagList.length -
                                        1)
                                        .toString(),
                                    style: TextStyle(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                      : TextSpan(
                                    text: "",
                                    style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant
                                            .TYPE_CUSTOMREGULAR),
                                  ),
                                  userPostModal.tagList.length > 1
                                      ? TextSpan(
                                    text: " others ",
                                    style: TextStyle(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                      : TextSpan(
                                    text: "",
                                    style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant
                                            .TYPE_CUSTOMREGULAR),
                                  ),
                                ],
                              ),
                            )),
                        onTap: () {
                          if (userPostModal.tagList.length > 0) {
                            Navigator.of(context).push(new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    TagDetailWidget(userPostModal.tagList)));
                          } else {
                            print("clicked");
                            onTapImageTile(userPostModal.postOwner,
                                userPostModal.postOwnerRoleId);
                          }
                        },
                      ),

                      //     ? AppConstants.colorStyle.white
                      //     AppConstants.colorStyle.darkBlue
                      // : AppConstants.colorStyle.white,
                      TextViewWrap.textView(
                          userPostModal.shareTime,
                          TextAlign.center,
                          ColorValues.labelColor,
                          12.0,
                          FontWeight.w500),
                    ],
                  )),
              flex: 4,
            )
          ],
        ));
  }

  Widget _imageAndNamegetListViewForSharedPost(userPostModal, index) {
    return
      Container(
          decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/feed/background_imageview.png"),
              fit: BoxFit.cover,
            ),),
          child:
          PaddingWrap.paddingfromLTRB(
              17.0,
              10.0,
              10.0,
              10.0,
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: Container(
                          child: Center(
                              child: Container(
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: AppConstants.colorStyle
                                              .white,
                                          width: 1),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(10))),
                                  width: 50.0,
                                  height: 50.0,
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(10),
                                      child: FadeInImage.assetNetwork(
                                        fit: BoxFit.cover,
                                        width: double.infinity,
                                        placeholder:
                                        userPostModal.postOwnerRoleId == "4"
                                            ? "assets/profile/partner_img.png"
                                            : 'assets/profile/user_on_user.png',
                                        image: Constant.IMAGE_PATH_SMALL +
                                            ParseJson.getSmallImage(
                                                userPostModal
                                                    .postOwnerProfilePicture),
                                      ))))),
                      onTap: () {
                        onTapImageTile(
                            userPostModal.postOwner,
                            userPostModal.postOwnerRoleId);
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        8.0,
                        0.0,
                        15.0,
                        0.0,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            InkWell(
                              child: Container(
                                  child: RichText(
                                    maxLines: 2,
                                    textAlign: TextAlign.start,
                                    text: TextSpan(
                                      text: userPostModal.postOwnerLastName ==
                                          "null"
                                          ? userPostModal.postOwnerFirstName
                                          : userPostModal.postOwnerFirstName +
                                          " " +
                                          userPostModal.postOwnerLastName,
                                      style: TextStyle(
                                        color: ColorValues.WHITE,
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: Constant.latoRegular,
                                      ),
                                      children: userPostModal.tagList
                                          .length == 0
                                          ? [
                                        WidgetSpan(
                                          child: userPostModal
                                              .postOwnerRoleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .postOwnerBadge,
                                              userPostModal
                                                  .postOwnerBadgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        )
                                      ]
                                          : [
                                        WidgetSpan(
                                          child: userPostModal
                                              .postOwnerRoleId ==
                                              "1"
                                              ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                              userPostModal
                                                  .postOwnerBadge,
                                              userPostModal
                                                  .postOwnerBadgeImage)
                                              : Container(
                                            height: 0.0,
                                            width: 0.0,
                                          ),
                                        ),
                                        TextSpan(
                                            text: ' with ',
                                            style: TextStyle(
                                                color: ColorValues.WHITE,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.normal,
                                                fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR)),
                                        TextSpan(
                                          text: userPostModal.tagList[0]
                                              .name ==
                                              null ||
                                              userPostModal.tagList[0].name ==
                                                  "null"
                                              ? ""
                                              : userPostModal.tagList[0].name,
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: ' and ',
                                          style: TextStyle(
                                              color: ColorValues.WHITE,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues.WHITE,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: (userPostModal
                                              .tagList.length -
                                              1)
                                              .toString(),
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues.WHITE,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                        userPostModal.tagList.length > 1
                                            ? TextSpan(
                                          text: " others ",
                                          style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        )
                                            : TextSpan(
                                          text: "",
                                          style: TextStyle(
                                              color: ColorValues.WHITE,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        ),
                                      ],
                                    ),
                                  )),
                              onTap: () {
                                if (userPostModal.tagList.length > 0) {
                                  Navigator.of(context).push(
                                      new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              TagDetailWidget(
                                                  userPostModal.tagList)));
                                } else {
                                  print("clicked");
                                  onTapImageTile(userPostModal.postOwner,
                                      userPostModal.postOwnerRoleId);
                                }
                              },
                            ),

                            //     ? AppConstants.colorStyle.white
                            //     AppConstants.colorStyle.darkBlue
                            // : AppConstants.colorStyle.white,
                            TextViewWrap.textView(
                                userPostModal.shareTime,
                                TextAlign.center,
                                ColorValues.WHITE,
                                12.0,
                                FontWeight.w500),
                          ],
                        )),
                    flex: 4,
                  )
                ],
              )));
  }

  Padding getListViewPost(userPostModal, index) {
    return PaddingWrap.paddingAll(
      0.0,
      Card(
        elevation: 0.0,
        color: ColorValues.WHITE,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            // getEvent(userPostModal),

            userPostModal.shareText != null &&
                userPostModal.postOwnerFirstName != "null" &&
                userPostModal.postOwnerFirstName != null
            // userPostModal.shareText != "" &&
            // userPostModal.shareText != "null"
                ? _imageAndNamegetListViewPost(userPostModal, index)
                : Container(
              height: 0.0,
            ),
            userPostModal.shareText == "null" ||
                userPostModal.shareText == ""
                ? Container(
              height: 0.0,
            )
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                  10.0,
                  10.0,
                  10.0,
                  10.0,
                  userPostModal.shareText == "" ||
                      userPostModal.shareText == "null" ||
                      userPostModal.shareText == "\n"
                      ? Container(
                    height: 0.0,
                  )
                      : PaddingWrap.paddingfromLTRB(
                      10.0,
                      0.0,
                      0.0,
                      0.0,
                      userPostModal.isShareMore
                          ? Container(
                        child: Linkify(
                          onOpen: (link) async {

                          },
                          text: userPostModal.shareText,
                          style: TextStyle(
                              color: ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              fontFamily: Constant.latoRegular,
                              fontWeight: FontWeight.w500,
                              fontSize: 14.0),
                          linkStyle: TextStyle(
                              color: ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              fontFamily: Constant.latoRegular,
                              fontWeight: FontWeight.w500,
                              fontSize: 14.0),
                        ),
                      )
                          : Container(
                        child: Linkify(
                          onOpen: (link) async {

                          },
                          text: userPostModal.shareText,
                          style: TextStyle(
                              color: ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              fontFamily: Constant.latoRegular,
                              fontWeight: FontWeight.w500,
                              fontSize: 14.0),
                          linkStyle: TextStyle(
                              color: ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              fontFamily: Constant.latoRegular,
                              fontWeight: FontWeight.w500,
                              fontSize: 14.0),
                        ),
                      )),
                ),
              ],
            ),

            userPostModal.postOwnerDeleted
                ? PaddingWrap.paddingfromLTRB(
                11.0,
                5.0,
                11.0,
                5.0,
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                      color: ColorValues
                          .OPPORTUNITY_GROUP_SELECTION_GRP,
                      border: Border.all(
                          width: 0.5,
                          color: ColorValues.GREY__COLOR_DIVIDER)),
                  child: PaddingWrap.paddingfromLTRB(
                      11.0,
                      17.0,
                      11.0,
                      16.0,
                      Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          TextViewWrap.textView(
                              "You can’t see this post",
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              14.0,
                              FontWeight.bold),
                          TextViewWrap.textView(
                              MessageConstant.AUTHOR_DELETED_POST,
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              14.0,
                              FontWeight.normal)
                        ],
                      )),
                ))
                : PaddingWrap.paddingfromLTRB(
                0.0,
                5.0,
                0.0,
                5.0,
                Container(
                    decoration: BoxDecoration(),
                    child: Stack(
                      children: <Widget>[
                        userPostModal.postdata.assetsList.length == 0
                            ? Container(
                          height: 0.0,
                        )
                            : PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            10.0,
                            0.0,
                            Container(
                                height: 280.0,
                                child: SizedBox(
                                  // Pager view
                                    height: 280.0,
                                    child:
                                    PageIndicatorContainer(
                                      pageView:
                                      PageView.builder(
                                        itemCount: userPostModal
                                            .postdata.assetsList
                                            .length,
                                        controller:
                                        PageController(),
                                        itemBuilder:
                                            (context, index2) {
                                          return
                                            userPostModal.postdata
                                                .assetsList[index2]
                                                .type == "image" ?
                                            InkWell(
                                              child: Stack(
                                                  children: <
                                                      Widget>[
                                                    Container(
                                                        decoration:
                                                        BoxDecoration(
                                                          color: Colors
                                                              .black,
                                                        ),
                                                        height:
                                                        280.0,
                                                        child:
                                                        CachedNetworkImage(
                                                          width: double
                                                              .infinity,
                                                          height:
                                                          280.0,
                                                          imageUrl:
                                                          Constant
                                                              .IMAGE_PATH_SMALL +
                                                              ParseJson
                                                                  .getMediumImage(
                                                                  userPostModal
                                                                      .postdata
                                                                      .assetsList[index2]
                                                                      .url),
                                                          fit: BoxFit
                                                              .contain,
                                                          placeholder:
                                                              (context,
                                                              url) =>
                                                              _loader(
                                                                  context),
                                                          errorWidget: (context,
                                                              url,
                                                              error) =>
                                                              _error(),
                                                        )),
                                                    userPostModal
                                                        .postdata
                                                        .assetsList
                                                        .length ==
                                                        1
                                                        ? InkWell(
                                                        onTap:
                                                            () {
                                                          Navigator.of(
                                                              context)
                                                              .push(
                                                              new MaterialPageRoute(
                                                                  builder: (
                                                                      BuildContext context) =>
                                                                      CommonFullViewWidget(
                                                                          userPostModal
                                                                              .postdata
                                                                              .assetsList,
                                                                          MessageConstant
                                                                              .HOME_FEED,
                                                                          index2,
                                                                          MessageConstant
                                                                              .COMPANY_PROFILE_HEDING)));
                                                        },
                                                        child:
                                                        Container(
                                                          height:
                                                          0.0,
                                                        ))
                                                        : InkWell(
                                                        onTap:
                                                            () {
                                                          Navigator.of(
                                                              context)
                                                              .push(
                                                              new MaterialPageRoute(
                                                                  builder: (
                                                                      BuildContext context) =>
                                                                      CommonFullViewWidget(
                                                                          userPostModal
                                                                              .postdata
                                                                              .assetsList,
                                                                          MessageConstant
                                                                              .HOME_FEED,
                                                                          index2,
                                                                          MessageConstant
                                                                              .COMPANY_PROFILE_HEDING)));
                                                        },
                                                        child:
                                                        Container(
                                                          height:
                                                          280.0,
                                                          width:
                                                          double
                                                              .infinity,
                                                          child:
                                                          Image.asset(
                                                            "assets/newDesignIcon/navigation/layer_image.png",
                                                            fit: BoxFit
                                                                .fill,
                                                          ),
                                                        ))
                                                  ]),
                                              onTap: () {
                                                Navigator.of(context)
                                                    .push(
                                                    new MaterialPageRoute(
                                                        builder: (
                                                            BuildContext context) =>
                                                            CommonFullViewWidget(
                                                                userPostModal
                                                                    .postdata
                                                                    .assetsList,
                                                                MessageConstant
                                                                    .HOME_FEED,
                                                                index2,
                                                                MessageConstant
                                                                    .COMPANY_PROFILE_HEDING)));
                                              },
                                            ) : InkWell(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Colors.black,
                                                  borderRadius:
                                                  BorderRadius.circular(
                                                      0),
                                                ),
                                                height: 250.0,
                                                width: double.infinity,
                                                child: Center(
                                                  child: Center(
                                                    child: VideoPlayPause(
                                                        userPostModal
                                                            .postdata
                                                            .assetsList[index2]
                                                            .url,
                                                        userPostModal
                                                            .feedId,
                                                        true),
                                                  ),
                                                ),
                                              ),
                                              onTap: () {},
                                            );
                                        },
                                        onPageChanged:
                                            (index) {},
                                      ),
                                      align:
                                      IndicatorAlign.bottom,
                                      length: userPostModal.postdata
                                          .assetsList
                                          .length,
                                      indicatorSpace: 10.0,
                                      indicatorColor:
                                      userPostModal
                                          .postdata
                                          .imageList
                                          .length ==
                                          1
                                          ? Colors
                                          .transparent
                                          : Color(
                                          0xffc4c4c4),
                                      indicatorSelectorColor:
                                      userPostModal.postdata.assetsList
                                          .length ==
                                          1
                                          ? Colors
                                          .transparent
                                          : Color(
                                          0XFFFFFFFF),
                                      shape:
                                      IndicatorShape.circle(
                                          size: 5.0),
                                    )))),
                        // userPostModal.postdata.imageList.length >
                        //     0 ||
                        //     userPostModal.postdata.media ==
                        //         null ||
                        //     userPostModal.postdata.media ==
                        //         "" ||
                        //     userPostModal.postdata.media ==
                        //         "null"
                        //     ? Container(
                        //   height: 1.0,
                        // )
                        //     : PaddingWrap.paddingfromLTRB(
                        //     10.0,
                        //     0.0,
                        //     10.0,
                        //     0.0,
                        //     InkWell(
                        //       child: Container(
                        //         decoration: BoxDecoration(
                        //           color: Colors.black,
                        //           borderRadius:
                        //           BorderRadius.circular(0),
                        //         ),
                        //         height: 250.0,
                        //         width: double.infinity,
                        //         child: Center(
                        //           child: Center(
                        //             child: VideoPlayPause(
                        //                 userPostModal
                        //                     .postdata.media,
                        //                 userPostModal.feedId,
                        //                 true,
                        //                 allVideoController),
                        //           ),
                        //         ),
                        //       ),
                        //       onTap: () {},
                        //     )),


                        userPostModal.postOwnerFirstName ==
                            "null" ||
                            userPostModal.postOwnerFirstName ==
                                null
                            ? _imageAndNamegetListViewPost2(
                            userPostModal, index)
                            :
                        userPostModal.postdata.assetsList.length == 0 &&
                            (userPostModal.postdata.metaUrl == "" &&
                                userPostModal.postdata.metaImage == "")
                            ?
                        _imageAndNamegetListViewForSharedPostBlue(
                            userPostModal, index)

                            : _imageAndNamegetListViewForSharedPost(
                            userPostModal, index),
                      ],
                    ))),
            userPostModal.postOwnerFirstName == "null" ||
                userPostModal.postOwnerFirstName == null
                ? Container(
              height: 0.0,
            )
                : userPostModal.postOwnerDeleted
                ? Container(
              height: 0.0,
            ) : PaddingWrap.paddingfromLTRB(
                20.0,
                10.0,
                13.0,
                0.0,
                Container(
                  child: Linkify(
                    onOpen: (link) async {
                      Navigator.of(context, rootNavigator: true)
                          .push(new MaterialPageRoute(
                          fullscreenDialog: true,
                          builder: (BuildContext context) =>
                              WebViewWidget(
                                  link.url, "spikeview")));
                    },
                    text: exp
                        .allMatches(
                        userPostModal.postdata.text)
                        .length >
                        1
                        ? userPostModal.postdata.text
                        : userPostModal.postdata.text
                        .toString()
                        .replaceAll(exp, ''),
                    style: TextStyle(
                        color:
                        ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: Constant.latoRegular,
                        fontSize: 14.0,
                        fontWeight: FontWeight.w400),
                    linkStyle: TextStyle(
                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                        fontSize: 14.0),
                  ),
                )),

            Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 20, top: 5),
                    child: Row(
                      children: <Widget>[
                        InkWell(
                          onTap: () {
                            onTapLike(userPostModal);
                          },
                          child: userPostModal.isLike
                              ? Image.asset(
                            "assets/feed/heart_red.png",
                            height: 22.0,
                            width: 22.0,
                          )
                              : Image.asset(
                            "assets/feed/heart_blue.png",
                            height: 22.0,
                            width: 22.0,
                          ),
                        ),
                        SizedBox(
                          width: 7,
                        ),
                        InkWell(
                          onTap: () {
                            if (userPostModal
                                .isShowCommentIcon)
                              userPostModal
                                  .isShowCommentIcon = false;
                            else {
                              userPostModal
                                  .isShowCommentIcon = true;
                            }

                            setState(() {
                              userPostModal.isShowCommentIcon;
                            });
                          },
                          child: Image.asset(
                            "assets/feed/comment.png",
                            height: 26.0,
                            width: 26.0,
                          ),
                        ),

                        Spacer(),
                        // Padding(
                        //   padding: const EdgeInsets.only(
                        //     right: 20,
                        //   ),
                        //   child: InkWell(
                        //     onTap: () {
                        //       print("sss like");
                        //     },
                        //     child: Image.asset(
                        //       "assets/feed/save_icon_border.png",
                        //       height: 12.0,
                        //       width: 12.0,
                        //     ),
                        //   ),
                        // ),
                      ],
                    ),
                  )
                  ,
                  flex: 1,
                ),
              ],
            ),
            Padding(
              padding:
              const EdgeInsets.fromLTRB(10.0, 10, 0, 0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: userPostModal.likesCount > 0
                        ? PaddingWrap.paddingfromLTRB(
                        10.0,
                        0.0,
                        10.0,
                        0.0,
                        InkWell(
                          child: TextViewWrap.textView(
                              userPostModal.likesCount ==
                                  0
                                  ? "Like"
                                  : userPostModal.likesCount ==
                                  1
                                  ? "1 Like"
                                  : userPostModal.likesCount
                                  .toString() +
                                  " Likes",
                              TextAlign.end,
                              ColorValues.labelColor,
                              12.0,
                              FontWeight.w500),
                          onTap: () {
                            onTapLikeText(userPostModal);
                          },
                        ))
                        : Container(
                      height: 0.0,
                    ),
                    flex: 0,
                  ),
                  userPostModal.commentList.length == 0
                      ? Container(
                    height: 0.0,
                  )
                      : InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      TextViewWrap.textView(
                          userPostModal.commentList
                              .length ==
                              0
                              ? "Comment"
                              : "" +
                              userPostModal
                                  .commentList
                                  .length
                                  .toString() +
                              " Comments",
                          TextAlign.left,
                          ColorValues.labelColor,
                          12.0,
                          FontWeight.w500),
                    ),
                    onTap: () {
                      onTapViewAllComments(
                          userPostModal.commentList,
                          userPostModal.feedId,
                          userPostModal);
                    },
                  )
                ],
              ),
            )
            ,
            // Padding(
            //   padding: const EdgeInsets.all(10.0),
            //   child: Divider(height: 1.0, color: ColorValues.DARK_GREY),
            // ),

            userPostModal.postdata == null ||
                userPostModal.postdata.text == null ||
                userPostModal.postdata.text == "null"
                ? Container(
              height: 0.0,
            )
                : userPostModal.postdata.metaUrl != ""
                ? userPostModal.shareText != null &&
                userPostModal.postOwnerFirstName !=
                    "null" &&
                userPostModal.postOwnerFirstName != null
                ? Container(
              height: 0.0,
            )
                : Container(
                padding:
                EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 0),
                width: double.infinity,
                child: Container(
                  padding: EdgeInsets.fromLTRB(
                      0.0, 10.0, 0.0, 10),
                  color: Color(0XFFFFFFFF),
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment:
                    MainAxisAlignment.start,
                    children: <Widget>[
                      InkWell(
                        child: Text(
                          userPostModal
                              .postdata.metaTitle ==
                              null
                              ? ""
                              : userPostModal
                              .postdata.metaTitle
                              .trim(),
                          textAlign: TextAlign.start,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                              Constant.TYPE_CUSTOMBOLD,
                              fontSize: 14.0),
                        ),
                        onTap: () {

                        },
                      ),
                      InkWell(
                        child: Text(
                          userPostModal.postdata
                              .metaSource ==
                              null
                              ? ""
                              : userPostModal
                              .postdata.metaSource
                              .trim(),
                          textAlign: TextAlign.start,
                          maxLines: 1,
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              color: ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                              Constant.latoRegular,
                              fontSize: 14.0),
                        ),
                        onTap: () {
                          //onTapView();
                          Navigator.of(context).push(
                              new MaterialPageRoute(
                                  builder: (BuildContext
                                  context) =>
                                      WebViewWidget(
                                          userPostModal
                                              .postdata
                                              .metaUrl,
                                          "spikeview")));
                        },
                      ),
                      Text(
                        userPostModal.postdata
                            .metaDescription ==
                            null
                            ? ""
                            : userPostModal
                            .postdata.metaDescription
                            .trim(),
                        textAlign: TextAlign.start,
                        maxLines: isShowMore ? 30 : 3,
                        style: TextStyle(
                            color: ColorValues
                                .HEADING_COLOR_EDUCATION_1,
                            fontWeight: FontWeight.w400,
                            fontFamily:
                            Constant.latoRegular,
                            fontSize: 14.0),
                      ),
                      userPostModal.postdata.metaDescription
                          .trim()
                          .length >
                          190
                          ? InkWell(
                          child: Text(
                            isShowMore
                                ? "Less"
                                : "More",
                            textAlign: TextAlign.start,
                            maxLines: 1,
                            style: TextStyle(
                                color: ColorValues
                                    .BLUE_COLOR_BOTTOMBAR,
                                fontFamily: Constant
                                    .TYPE_CUSTOMREGULAR,
                                fontSize: 12.0),
                          ),
                          onTap: () {
                            setState(() {
                              if (isShowMore) {
                                isShowMore = false;
                              } else
                                isShowMore = true;
                            });
                          })
                          : Container(
                        height: 0.0,
                      )
                    ],
                  ),
                ))
                : PaddingWrap.paddingfromLTRB(
                20.0,
                0.0,
                20.0,
                0.0,
                Container(
                    color: Colors.transparent,
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      mainAxisAlignment:
                      MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          userPostModal.postdata.text == "" ||
                              userPostModal.postdata.text ==
                                  "null" ||
                              userPostModal.postdata.text ==
                                  "\n"
                              ? Container(
                            height: 1.0,
                          )
                              : userPostModal.postdata.assetsList
                              .length == 0 &&
                              // (userPostModal.postdata.media ==
                              //     null ||
                              //     userPostModal.postdata
                              //         .media ==
                              //         "" ||
                              //     userPostModal.postdata
                              //         .media ==
                              //         "null") &&
                              (userPostModal.postdata.metaUrl != "" &&
                                  userPostModal.postdata
                                      .metaImage !=
                                      "")
                              ? exp
                              .allMatches(userPostModal.postdata.text)
                              .length == 1 &&
                              userPostModal
                                  .postdata.text
                                  .toString()
                                  .replaceAll(
                                  exp, '')
                                  .length ==
                                  0
                              ? Container(
                            height: 0.0,
                          )
                              : PaddingWrap
                              .paddingfromLTRB(
                              4.0,
                              10.0,
                              13.0,
                              0.0,
                              Container(
                                child: Linkify(
                                  onOpen:
                                      (link) async {
                                    Navigator.of(
                                        context, rootNavigator: true)
                                        .push(new MaterialPageRoute(
                                        fullscreenDialog:
                                        true,
                                        builder: (BuildContext context) =>
                                            WebViewWidget(
                                                link.url,
                                                "spikeview")));
                                  },
                                  text: exp
                                      .allMatches(
                                      userPostModal.postdata.text)
                                      .length >
                                      1
                                      ? userPostModal
                                      .postdata
                                      .text
                                      : userPostModal
                                      .postdata
                                      .text
                                      .toString()
                                      .replaceAll(
                                      exp,
                                      ''),
                                  style: TextStyle(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontFamily:
                                      Constant
                                          .latoRegular,
                                      fontSize:
                                      14.0,
                                      fontWeight:
                                      FontWeight
                                          .w400),
                                  linkStyle: TextStyle(
                                      color: ColorValues
                                          .BLUE_COLOR_BOTTOMBAR,
                                      fontFamily:
                                      Constant
                                          .TYPE_CUSTOMREGULAR,
                                      fontSize:
                                      14.0),
                                ),
                              ))
                              : userPostModal.postOwnerFirstName ==
                              "null" ||
                              userPostModal
                                  .postOwnerFirstName ==
                                  null
                              ? Container(
                            child: Linkify(
                              onOpen:
                                  (link) async {
                                Navigator.of(
                                    context,
                                    rootNavigator:
                                    true)
                                    .push(new MaterialPageRoute(
                                    fullscreenDialog:
                                    true,
                                    builder: (BuildContext
                                    context) =>
                                        WebViewWidget(
                                            link.url,
                                            "spikeview")));
                              },
                              text: userPostModal
                                  .postdata.text,
                              style: TextStyle(
                                  color: ColorValues
                                      .HEADING_COLOR_EDUCATION_1,
                                  fontFamily: Constant
                                      .latoRegular,
                                  fontSize: 14.0,
                                  fontWeight:
                                  FontWeight
                                      .w400),
                              linkStyle: TextStyle(
                                  color: ColorValues
                                      .BLUE_COLOR_BOTTOMBAR,
                                  fontFamily: Constant
                                      .TYPE_CUSTOMREGULAR,
                                  fontSize: 14.0),
                            ),
                          )
                              : Container(height: 0),
                        ),
                      ],
                    ))),

            PaddingWrap.paddingAll(
              0.0,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  // Comment List view
                  // Padding(
                  //   padding: const EdgeInsets.all(10.0),
                  //   child: Divider(
                  //       height: 1.0,
                  //       color: ColorValues.DARK_GREY),
                  // ),
                  Padding(
                      padding: EdgeInsets.fromLTRB(
                          0.0, 5.0, 0.0, 0.0),
                      child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: List.generate(
                              userPostModal.commentList
                                  .length >
                                  3
                                  ? 3
                                  : userPostModal.commentList
                                  .length, (int index) {
                            return PaddingWrap
                                .paddingfromLTRB(
                                10.0,
                                5.0,
                                10.0,
                                0.0,
                                Row(
                                  crossAxisAlignment:
                                  CrossAxisAlignment
                                      .start,
                                  children: <Widget>[
                                    InkWell(
                                        child: Container(
                                            width: 40.0,
                                            height: 40.0,
                                            child:
                                            ClipRRect(
                                                borderRadius: BorderRadius
                                                    .circular(10),
                                                child:
                                                FadeInImage
                                                    .assetNetwork(
                                                  fit: BoxFit
                                                      .cover,
                                                  width: double
                                                      .infinity,
                                                  placeholder: userPostModal
                                                      .commentList[index]
                                                      .roleId ==
                                                      "4"
                                                      ? "assets/profile/partner_img.png"
                                                      : 'assets/profile/user_on_user.png',
                                                  image: Constant
                                                      .IMAGE_PATH_SMALL +
                                                      userPostModal
                                                          .commentList[index]
                                                          .profilePicture,
                                                ))),
                                        onTap: () {
                                          onTapImageTile(
                                              userPostModal
                                                  .commentList[
                                              index]
                                                  .commentedBy,
                                              userPostModal
                                                  .commentList[
                                              index]
                                                  .roleId);
                                        }), // User Image
                                    SizedBox(
                                      width: 20.0,
                                    ),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment
                                            .start,
                                        mainAxisAlignment:
                                        MainAxisAlignment
                                            .start,
                                        children: <
                                            Widget>[
                                          Padding(
                                            padding:
                                            const EdgeInsets
                                                .fromLTRB(
                                                0,
                                                0,
                                                0,
                                                0),
                                            child:
                                            Container(
                                                child:
                                                Row(
                                                  children: <
                                                      Widget>[
                                                    RichText(
                                                      maxLines:
                                                      2,
                                                      textAlign:
                                                      TextAlign.start,
                                                      text:
                                                      TextSpan(
                                                        text: userPostModal
                                                            .commentList[index]
                                                            .name,
                                                        style:
                                                        TextStyle(
                                                          color:
                                                          ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          fontSize:
                                                          14.0,
                                                          fontWeight:
                                                          FontWeight
                                                              .bold,
                                                        ),
                                                        /* children: <TextSpan>[
                                                              TextSpan(
                                                                  text: userPostModal
                                                                      .commentList[
                                                                          index]
                                                                      .comment,
                                                                  style:  TextStyle(
                                                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                      fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR)),
                                                        ],*/
                                                      ),
                                                    ),
                                                    userPostModal
                                                        .commentList[index] !=
                                                        null &&
                                                        userPostModal
                                                            .commentList[index]
                                                            .roleId ==
                                                            "1"
                                                    //true
                                                        ? Util
                                                        .getStudentBadge12(
                                                        userPostModal
                                                            .commentList[index]
                                                            .badge,
                                                        userPostModal
                                                            .commentList[index]
                                                            .badgeImage)
                                                        : Container(
                                                      height: 0.0,
                                                      width: 0.0,
                                                    ),
                                                  ],
                                                )),
                                          ),
                                          Container(
                                            child:
                                            Linkify(
                                              onOpen:
                                                  (link) async {
                                                Navigator.of(context,
                                                    rootNavigator: true)
                                                    .push(
                                                    new MaterialPageRoute(
                                                        fullscreenDialog:
                                                        true,
                                                        builder: (
                                                            BuildContext context) =>
                                                            WebViewWidget(
                                                                link
                                                                    .url,
                                                                "spikeview")));
                                              },
                                              text: userPostModal
                                                  .commentList[
                                              index]
                                                  .comment,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION,
                                                  fontSize:
                                                  14.0,
                                                  fontWeight:
                                                  FontWeight
                                                      .normal,
                                                  fontFamily:
                                                  Constant
                                                      .TYPE_CUSTOMREGULAR),
                                              linkStyle: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontFamily:
                                                  Constant
                                                      .TYPE_CUSTOMREGULAR,
                                                  fontSize:
                                                  14.0),
                                            ),
                                          ),
                                          Padding(
                                              padding: EdgeInsets
                                                  .fromLTRB(
                                                  0.0,
                                                  5.0,
                                                  0.0,
                                                  0.0),
                                              child: Row(
                                                mainAxisAlignment:
                                                MainAxisAlignment
                                                    .start,
                                                crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .center,
                                                children: <
                                                    Widget>[
                                                  Expanded(
                                                    child:
                                                    Row(
                                                      mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .start,
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .start,
                                                      children: <
                                                          Widget>[
                                                        Text(
                                                          userPostModal
                                                              .commentList[index]
                                                              .dateTime,
                                                          textAlign: TextAlign
                                                              .end,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .GREY_TEXT_COLOR,
                                                              fontSize: 12.0,
                                                              fontFamily: Constant
                                                                  .customRegular),
                                                        )
                                                      ],
                                                    ),
                                                    flex:
                                                    0,
                                                  ),
                                                  Container(
                                                    width:
                                                    10.0,
                                                  ),
                                                  Expanded(
                                                    child: userIdPref ==
                                                        userPostModal
                                                            .commentList[index]
                                                            .commentedBy //&& userPostModal.commentList[index].isComment
                                                        ? InkWell(
                                                      child: Padding(
                                                        padding: const EdgeInsets
                                                            .fromLTRB(
                                                            0.0, 0, 0,
                                                            5),
                                                        child: Image
                                                            .asset(
                                                          "assets/feed/three_dot_blue.png",
                                                          width: 15.0,
                                                          height: 15.0,
                                                        ),
                                                      ),
                                                      onTap: () {},
                                                    )
                                                        : Container(
                                                      height: 1.0,
                                                    ),
                                                    flex:
                                                    0,
                                                  )
                                                ],
                                              )),
                                        ],
                                      ),
                                      flex: 1,
                                    ) // Comment List Cell
                                  ],
                                ));
                          }))),

                  // View All Comments
                  userPostModal.commentList.length > 3
                      ? InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                      10.0,
                      0.0,
                      0.0,
                      5.0,
                      TextViewWrap.textView(
                          "View All " +
                              userPostModal
                                  .commentList.length
                                  .toString() +
                              " Comments",
                          TextAlign.left,
                          ColorValues.labelColor,
                          12.0,
                          FontWeight.w500),
                    ),
                    onTap: () {
                      onTapViewAllComments(
                          userPostModal.commentList,
                          userPostModal.feedId,
                          userPostModal);
                    },
                  )
                      : Container(
                    height: 0.0,
                  ),

                  // Comment Edit Text
                  userPostModal.isShowCommentIcon
                      ? PaddingWrap.paddingAll(
                    10.0,
                    Row(
                      children: <Widget>[
                        //Alok Code Done
                        Container(
                          width: 40.0,
                          height: 40.0,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: FadeInImage
                                .assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: roleId == "4"
                                  ? "assets/profile/partner_img.png"
                                  : 'assets/profile/user_on_user.png',
                              image: roleId == "4"
                                  ? Constant.IMAGE_PATH +
                                  prefs.getString(
                                      UserPreference
                                          .COMPANY_IMAGE_PATH)
                                  : Constant.IMAGE_PATH +
                                  prefs.getString(
                                      UserPreference
                                          .PROFILE_IMAGE_PATH),
                              height: 45.0,
                              width: 45.0,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 20.0,
                        ),
                        Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      width: 1.0,
                                      color: ColorValues
                                          .LIGHT_GREY_TEXT_COLOR)),
                              child: Row(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .center,
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .center,
                                children: <Widget>[
                                  Expanded(
                                    child: TextField(
                                      controller:
                                      userPostModal
                                          .txtController,
                                      style: TextStyle(
                                          fontFamily:
                                          Constant
                                              .TYPE_CUSTOMREGULAR),
                                      keyboardType:
                                      TextInputType
                                          .text,
                                      textCapitalization:
                                      TextCapitalization
                                          .sentences,
                                      maxLines: null,
                                      maxLength:
                                      TextLength
                                          .COMMENT_MAX_LENGTH,
                                      onChanged: (s) {
                                        if (s
                                            .trim()
                                            .length >
                                            0) {
                                          userPostModal
                                              .isCommentIconVisible =
                                          true;
                                        } else {
                                          userPostModal
                                              .isCommentIconVisible =
                                          false;
                                        }
                                        setState(() {
                                          userPostModal
                                              .isCommentIconVisible;
                                        });
                                      },
                                      decoration:
                                      InputDecoration(
                                        border:
                                        InputBorder
                                            .none,
                                        filled: true,
                                        counterText:
                                        "",
                                        hintText: roleId ==
                                            "4"
                                            ? "Add Comment as " +
                                            prefs.getString(
                                                UserPreference
                                                    .COMPANY_NAME_PATH)
                                            : "Add Comment as " +
                                            prefs.getString(
                                                UserPreference
                                                    .NAME)
                                                .replaceAll(
                                                "null",
                                                ""),
                                        hintStyle: TextStyle(
                                            color: ColorValues
                                                .GREY_TEXT_COLOR,
                                            fontSize:
                                            14.0,
                                            fontFamily:
                                            Constant
                                                .TYPE_CUSTOMREGULAR),
                                        fillColor: Colors
                                            .transparent,
                                      ),
                                    ),
                                    flex: 4,
                                  ),
                                  Expanded(
                                    child:
                                    /*userPostModal
                                                    .isCommentIconVisible
                                                ?*/
                                    InkWell(
                                      child: PaddingWrap
                                          .paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          5.0,
                                          0.0,
                                          Image
                                              .asset(
                                            "assets/feed/sent_icon.png",
                                            width:
                                            22.0,
                                            height:
                                            22.0,
                                          )),
                                      onTap: () {
                                        if (userPostModal
                                            .isCommentIconVisible) {
                                          FocusScope.of(
                                              context)
                                              .requestFocus(
                                              FocusNode());
                                          userPostModal
                                              .isCommentIconVisible =
                                          false;
                                          onAddComment(
                                              userPostModal
                                                  .feedId,
                                              userPostModal
                                                  .txtController
                                                  .text,
                                              userPostModal);
                                          userPostModal
                                              .txtController
                                              .text = "";
                                          setState(
                                                  () {
                                                userPostModal
                                                    .txtController;
                                                userPostModal
                                                    .isCommentIconVisible;
                                              });
                                        }
                                      },
                                    )
                                    /*:  Container(
                                                    height: 0.0,
                                                  )*/
                                    ,
                                    flex: 0,
                                  )
                                ],
                              ),
                            ),
                            flex: 1)
                      ],
                    ),
                  )
                      : Container(
                    height: 0.0,
                  ),

                  (userPostList.length - 1) == index
                      ? Container(
                    height: 10.0,
                  )
                      : Container(
                    height: 0.0,
                  )

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:  customAppbar(
            context,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0, right: 20, top: 24, bottom: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        BaseText(
                          text: 'Feed detail',
                          textColor:
                          ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily:
                          AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w700,
                          fontSize: 28,
                          textAlign: TextAlign.start,
                          maxLines: 3,
                        ),


                      ],
                    ),
                  ),
                  flex: 0,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Column(
                            children:    List.generate(
                                userPostList.length, (int position) {
                              if (userPostList[position].isOpportunity) {
                                if (userPostList[position].postOwner == "null") {
                                  return getListViewForOpportunity(
                                      userPostList[position], position);
                                } else {
                                  return getListViewPostForOpportuntiy(
                                      userPostList[position], position);
                                }
                              } else {
                                if (userPostList[position].postOwner == "null")
                                  return getListView(
                                      userPostList[position], position);
                                else
                                  return getListViewPost(
                                      userPostList[position], position);
                              }
                            }),
                          ),



                        ],
                      ),
                    ),
                  ),
                  flex: 1,
                ),

              ],
            ), () {
          Navigator.pop(context);
        }, isShowIcon: false,isShowExplanation: false));



    return WillPopScope(
      onWillPop: () {
        onBack();
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          brightness: Brightness.light,
          leading: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              InkWell(
                child: SizedBox(
                  height: 40.0,
                  width: 40.0,
                  child: PaddingWrap.paddingfromLTRB(
                      10.0,
                      5.0,
                      0.0,
                      3.0,
                      Center(
                          child: Image.asset(
                              "assets/newDesignIcon/navigation/back.png",
                              height: 20.0,
                              width: 10.0,
                              fit: BoxFit.fitHeight))),
                ),
                onTap: () {
                  onBack();
                },
              )
            ],
          ),
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                "Feed Detail",
                style: TextStyle(
                    fontSize: 18.0,
                    fontFamily: Constant.customRegular,
                    color: ColorValues.HEADING_COLOR_EDUCATION),
              )
            ],
          ),
          actions: <Widget>[
            Container(
              width: 35.0,
            ),
          ],
          backgroundColor: Colors.white,
          elevation: 1.0,
        ),
        body: ListView.builder(
          scrollDirection: Axis.vertical,
          itemCount: userPostList.length,
          padding: EdgeInsets.all(0.0),
          itemBuilder: (BuildContext context, int position) {
            if (userPostList[position].isOpportunity) {
              if (userPostList[position].postOwner == "null") {
                return getListViewForOpportunity(
                    userPostList[position], position);
              } else {
                return getListViewPostForOpportuntiy(
                    userPostList[position], position);
              }
            } else {
              if (userPostList[position].postOwner == "null")
                return getListView(userPostList[position], position);
              else
                return getListViewPost(userPostList[position], position);
            }
          },
        ),
      ),
    );
  }

  Widget getText(String s, Color color) {
    return Padding(
      padding: const EdgeInsets.only(left: 0.0),
      child: Text(s,
          style: TextStyle(
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: color,
              fontSize: 14.0)),
    );
  }
}
