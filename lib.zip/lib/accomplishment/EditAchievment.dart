import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/theme/palette.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyMasterDataModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/LinkUrlModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:path/path.dart' as path;
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

// Create a Form Widget
class EditAchievmentForm extends StatefulWidget {
  Achivment achivmentModel;
  String sasToken;
  String level1;
  String dob;
  String userId;

  // ProfileInfoModal profileInfoModal;

  EditAchievmentForm(
      this.achivmentModel, this.sasToken, this.dob, this.userId, this.level1);

  @override
  EditAchievmentFormState createState() {
    return EditAchievmentFormState(achivmentModel);
  }
}

class EditAchievmentFormState extends State<EditAchievmentForm>
    with BaseCommonWidget {
  List<FileModel> mediaVideosList = List();
  List<String> mediaAndVideoList = List();
  List<LinkUrlModel> linkUrlListData = [];
  UploadMedia uploadMedia;

  EditAchievmentFormState(this.achivmentModel);
  FocusNode weightFocusNode = FocusNode();
  Achivment achivmentModel;
  final _formKey = GlobalKey<FormState>();
  final _formKey2 = GlobalKey<FormState>();

  String strAchievement = "",
      strFromDate = "",
      strToDate = "",
      strName = "",
      strEmail = "",
      strTitle = "",
      strDeascription = "",
      strWeight = "",
      strHeight = "",
      strFootValue = "1\'",
      strInchValue = "0\"";
  TextEditingController fromDateController,
      toDateController,
      coachFirstNameController,
      recommendationTitleController,
      recommendationRequestController,
      recommenderTitleController,
      coachLastNameController,
      coachEmaiController;

  static TextStyle styleForHeight = TextStyle(
      color: ColorValues.HEADING_COLOR_EDUCATION,
      fontSize: 18.0,
      fontFamily: Constant.TYPE_CUSTOMREGULAR);

  final List<String> footList = [
    "1\'",
    "2\'",
    "3\'",
    "4\'",
    "5\'",
    "6\'",
    "7\'",
    "8\'",
    "9\'",
    "10\'",
  ].toList();

  final List<String> inchList = [
    "0\"",
    "1\"",
    "2\"",
    "3\"",
    "4\"",
    "5\"",
    "6\"",
    "7\"",
    "8\"",
    "9\"",
    "10\"",
    "11\"",
    "12\"",
  ].toList();

  TextEditingController heightController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  List<AchievementImportanceModal> levelList = List();
  List<AcvhievmentSkillModel> skillList = List();
  List<Skill> skeelSelectedList = List();
  List<Level3Competencies> level3Competencylist = List();
  SharedPreferences prefs;
  Level3Competencies competencySelected;
  bool isPresent = false;
  FocusNode workinHoursFocusNode = FocusNode();
  String userIdPref,
      userEmail,
      token,
      strCompetencyValue = "",
      strLevelValue = "",
      strWorkingHours = "",
      filterData = "",
      appliedFilter = "",
      strCoachLastName = "",
      strCoachFirstName = "",
      strRecommendationTitle = "",
      strRecommenderTitle = "",
      strRecommendationRequest = "",
      strCoachEmail = "",
      strCompetencyHint = "",
      strLevelHint = "";
  Map<int, bool> filterStatus = Map();
  File imagePath;
  AchievementImportanceModal levelSelected;
  String selectedImageType = "media",
      strPrefixPathforPhoto,
      strAzureImageUploadPath = "";
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<Assest> assestList = List();
  List<String> mediaList = List();
  List<String> certificateList = List();

  //List<String> badgeList = List();
  // List<String> trophyList = List();
  List<Assest> badgeAndTrophyList = List();

  List<bool> assestListSelected = List();
  BuildContext context;
  TextEditingController titleController, descController, workingHourController;
  Map<String, List<Level3Competencies>> competencyList = Map();
  bool isMedaiDialog = false;
  bool isPromptfinal = false;
  bool isPrompt = false;
  ScrollController _controller = ScrollController();
  FocusNode _focus = FocusNode();
  String isPerformChnges = "pop";
  bool isShowMedia = true;
  DateTime startDate;

  int selectedIndexCover = 0;
  bool isPredefinedMediaSelected = false;
  List<String> imageList = List();

  TextEditingController personalReflectionController =
      TextEditingController(text: "");
  String strpersonalReflection = '';

  //--------------------------mediaApi api ------------------

  Future mediaApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_MEDIA_ACCOM, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              imageList = ParseJson.parseMedia(response.data['result']);
              if (imageList != null) {
                setState(() {
                  imageList;
                  if (imageList.length > 0 &&
                      achivmentModel.mediaList.length == 0) {
                    isPredefinedMediaSelected = true;
                    mediaList.removeLast();
                    mediaList.add(imageList[0]);
                    mediaList.add("");
                  }
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCallMaster() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_MASTER_DATA, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              skillList.clear();
              competencyList.clear();
              prefs.setString(
                  "skill", json.encode(response.data['result']['skills']));
              prefs.setString(
                  "level", json.encode(response.data['result']['importance']));

              prefs.setString("competencies",
                  json.encode(response.data['result']['competencies']));

              levelList = ParseJson.parseMapLevelList(
                  response.data['result']['importance']);
              skillList = ParseJson.parseMapSkillList(
                  response.data['result']['skills']);

              competencyList = ParseJson.parseMapMasterCompetency(
                  response.data['result']['competencies']);

              if (competencyList.length > 0) {
                level3Competencylist.clear();
                setState(() {
                  competencyList;

                  level3Competencylist =
                      competencyList[achivmentModel.level2Competency];
                });
              }
              if (level3Competencylist == null) {
                level3Competencylist = List();
              }
              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }

              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      e.toString();
    }
  }

  Future apiCallLevelList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_LEVEL_LIST, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              prefs.setString("level", json.encode(response.data['result']));
              levelList = ParseJson.parseMapLevelList(response.data['result']);
              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (widget.sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": widget.sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      return "";
    }
  }

  //--------------------------Api Call for skills ------------------
  Future apiCallSkill() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_SKILLS, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              skillList.clear();
              prefs.setString("skill", json.encode(response.data['result']));
              skillList = ParseJson.parseMapSkillList(response.data['result']);
              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      e.toString();
    }
  }

  scrollTop() async {
    Timer _timer = Timer(const Duration(milliseconds: 200), () async {
      _controller.jumpTo(_controller.position.minScrollExtent);
    });
  }

  scrollBottom() async {
    Timer _timer = Timer(const Duration(milliseconds: 200), () async {
      _controller.jumpTo(_controller.position.maxScrollExtent);
    });
  }

  //--------------------------Upload Acchievment Data ------------------

  bool validationCheck() {
    if (strCompetencyValue == "") {
      ToastWrap.showToast(MessageConstant.SELECT_COMPETENCY_VAL, context);
      return false;
    } else if (skeelSelectedList.length == 0) {
      ToastWrap.showToast(MessageConstant.SELECT_SKILLS_VAL, context);
      return false;
    } else if (strLevelValue == "") {
      ToastWrap.showToast(
          MessageConstant.SELECT_ACHIEVEMENT_LEVEL_VAL, context);
      return false;
    } else if (strFromDate == "") {
      ToastWrap.showToast(MessageConstant.SELECT_FROM_DATE_VAL, context);
      return false;
    } else if (strToDate == "" && (!isPresent)) {
      ToastWrap.showToast(MessageConstant.SELECT_TO_DATE_VAL, context);
      return false;
    }
    return true;
  }

  showSucessMsg(msg, context) {
    /*Timer _timer;

    _timer = Timer(const Duration(milliseconds: 3000), () async {
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));*/

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            negativeText: 'OK',
            msg: msg,
            isSucessPopup: true,
            onNegativeTap: (){
              Navigator.pop(context, "push");
            },
          );
        });
  }

  Future apiCalling() async {
    try {
      print('inside apiCalling() top');
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //assestList.removeAt(0);
        CustomProgressLoader.showLoader(context);

        mediaList.removeLast();
        //  badgeList.removeLast();
        certificateList.removeLast();
        badgeAndTrophyList.removeLast();
        mediaVideosList.removeLast();
        assestList.clear();
        for (var file in mediaList) {
          assestList.add(new Assest("image", "media", file, "", false));
        }
        print('Assets 000 size:: ${assestList.length}');
        for (FileModel item in mediaVideosList) {
          assestList.add(new Assest("video", "media", item.path, "", false));
        }
        print('Assets 111 size:: ${assestList.length}');

        for (var file in certificateList) {
          assestList.add(new Assest("image", "certificates", file, "", false));
        }

        print('Assets 222 size:: ${assestList.length}');
        for (var file in badgeAndTrophyList) {
          assestList.add(new Assest("image", file.tag, file.file, "", false));
        }
        if (linkUrlListData.length == 1 &&
            linkUrlListData[0].urlController.text.trim() == '') {
          //linkUrlListData[0].urlController.text.trim() == '';
          linkUrlListData.clear();
          print('linkUrlListData len::: ${linkUrlListData.length}');
        }


        Map map;
        if (isPromptfinal) {
          map = {
            "external_links":
                linkUrlListData.map((item) => item.toJson()).toList(),
            "achievementId": achivmentModel.achievementId,
            "competencyTypeId": achivmentModel.competencyTypeId,
            "level2Competency": achivmentModel.level2Competency,
            "level3Competency": strCompetencyValue,
            "focusArea": thirdLevelController.text,
            "userId": userIdPref,
            "badge": [],
            "certificate": [],
            "asset": assestList.map((item) => item.toJson()).toList(),
            "skills": skeelSelectedList.map((item) => item.toJson()).toList(),
            "title": titleController.text,
            "description": descController.text,
            "personalReflection": personalReflectionController.text.trim(),
            "fromDate": strFromDate,
            "toDate": strToDate,
            "importance": strLevelValue,
            "height": heightController.text,
            "weight": weightController.text,
            "hoursWorkedPerWeek": strWorkingHours,
            "guide": {
              "promptRecommendation": isPrompt,
              "firstName": strCoachFirstName,
              "lastName": strCoachLastName,
              "email": strCoachEmail,
              "title": strRecommenderTitle,
              "recommenderTitle": strRecommendationTitle,
             // "title": strRecommendationTitle,
            //  "recommenderTitle": recommenderTitleController.text,
              "request": strRecommendationRequest,
            },
            "stories": "",
            "isActive": "true"
          };
        } else {
          map = {
            "external_links":
                linkUrlListData.map((item) => item.toJson()).toList(),
            "achievementId": achivmentModel.achievementId,
            "competencyTypeId": achivmentModel.competencyTypeId,
            "level2Competency": achivmentModel.level2Competency,
            "level3Competency": strCompetencyValue,
            "focusArea": thirdLevelController.text,
            "userId": userIdPref,
            "badge": [],
            "certificate": [],
            "asset": assestList.map((item) => item.toJson()).toList(),
            "skills": skeelSelectedList.map((item) => item.toJson()).toList(),
            "title": titleController.text,
            "description": descController.text,
            "personalReflection": personalReflectionController.text.trim(),
            "fromDate": strFromDate,
            "toDate": strToDate,
            "height": heightController.text,
            "weight": weightController.text,
            "hoursWorkedPerWeek": strWorkingHours,
            "importance": strLevelValue,
            "guide": {
              "promptRecommendation": isPrompt,
              "firstName": strCoachFirstName,
              "lastName": strCoachLastName,
              "email": strCoachEmail,
              "title": strRecommenderTitle,
              "recommenderTitle": strRecommendationTitle,
            //  "title": strRecommendationTitle,
             // "recommenderTitle": recommenderTitleController.text,
              "request": strRecommendationRequest,
            },
            "stories": "",
            "isActive": "true",
          };
        }

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.userId;
    userEmail = prefs.getString(UserPreference.EMAIL);
    token = prefs.getString(UserPreference.USER_TOKEN);
    mediaApi(true);
    try {
      if (prefs.getString("competencies") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("competencies"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          competencyList.clear();
          competencyList = ParseJson.parseMapMasterCompetency(data);
          if (competencyList.length > 0) {
            level3Competencylist.clear();
            setState(() {
              competencyList;

              level3Competencylist =
                  competencyList[achivmentModel.level2Competency];
            });
          }
        }
      }
      if (level3Competencylist == null) {
        level3Competencylist = List();
      }
      strCompetencyHint = achivmentModel.level3Competency == null
          ? ""
          : achivmentModel.level3Competency;
      /*  for (int i = 0; i < level3Competencylist.length; i++) {
        if (level3Competencylist[i].key == strCompetencyValue) {
          strCompetencyHint = level3Competencylist[i].name;
          break;
        }
      }
*/
      if (prefs.getString("level") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("level"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          levelList.clear();
          levelList = ParseJson.parseMapLevelList(data);
          if (levelList.length > 0) {
            setState(() {
              levelList;
            });
          }
        }
      }

      if (prefs.getString("skill") == null) {
        await apiCallMaster();
      } else {
        final skill = json.decode(prefs.getString("skill"));
        if (skill == null || skill.length == 0) {
          await apiCallMaster();
        } else {
          skillList.clear();
          skillList = ParseJson.parseMapSkillList(skill);
          if (skillList.length > 0) {
            for (int i = 0; i < skillList.length; i++) {
              filterStatus[i] = false;
            }
            setState(() {
              filterStatus;
              skillList;
            });
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      e.toString();
    }
    // await callApiForSaas();

    for (int i = 0; i < levelList.length; i++) {
      if (levelList[i].importanceId == strLevelValue) {
        strLevelHint = levelList[i].title;
        setState(() {
          strLevelHint;
        });
        break;
      }
    }

    for (int i = 0; i < skillList.length; i++) {
      for (int j = 0; j < achivmentModel.skillList.length; j++) {
        if (skillList[i].title == achivmentModel.skillList[j].label) {
          filterStatus[i] = true;
          if (appliedFilter == "") {
            appliedFilter = skillList[i].title;
          } else {
            appliedFilter = appliedFilter + "," + skillList[i].title;
          }
        }
      }
    }
    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
  }

  DateTime fromDate, toDate;

  void _onFocusChange() {
    debugPrint("Focus: " + _focus.hasFocus.toString());
  }

  bool isThirLevelField = true;
  bool isValidHeight = true;
  bool isOtherCategory = false;
  bool isThirdLevelOther = false;
  TextEditingController otherCategory;
  TextEditingController thirdLevelController = TextEditingController(text: "");

  @override
  void initState() {

    print("achivmentModel//////////////"+achivmentModel.recommenderTitle);
    String date = widget.dob;
    if (achivmentModel.level2Competency == "Others") {
      setState(() {
        achivmentModel.level2Competency = "Other";
      });
    }
    if (achivmentModel.level2Competency == "Other" ||
        achivmentModel.level2Competency == "General" ||
        (achivmentModel.focusArea != null &&
            achivmentModel.focusArea != "null" &&
            achivmentModel.focusArea != "")) {
      isOtherCategory = true;
      strCompetencyValue = achivmentModel.level3Competency;
      otherCategory = TextEditingController(text: strCompetencyValue);
      thirdLevelController = TextEditingController(
          text: achivmentModel.focusArea == null ||
                  achivmentModel.focusArea == "null" ||
                  achivmentModel.focusArea == ""
              ? ""
              : achivmentModel.focusArea);
    }

    if (achivmentModel.level3Competency == "Other") {
      thirdLevelController = TextEditingController(
          text: achivmentModel.focusArea == null ||
                  achivmentModel.focusArea == "null" ||
                  achivmentModel.focusArea == ""
              ? ""
              : achivmentModel.focusArea);
      isThirdLevelOther = true;
    }
    initMediaList();
    //check for where old data is present
    if (date != "" || date != null) {
      startDate = DateTime.fromMillisecondsSinceEpoch(int.parse(widget.dob));
    } else {
      startDate = DateTime.now();
    }

    _focus.addListener(_onFocusChange);
    getSharedPreferences();
    uploadMedia = UploadMedia(context);
    titleController = TextEditingController(text: achivmentModel.title);
    workingHourController = TextEditingController(
        text: achivmentModel.hoursWorkedPerWeek == "null" ||
                achivmentModel.hoursWorkedPerWeek == ""
            ? ""
            : achivmentModel.hoursWorkedPerWeek);

    if (achivmentModel.personalReflection != null &&
        achivmentModel.personalReflection != 'null' &&
        achivmentModel.personalReflection != '')
      personalReflectionController =
          TextEditingController(text: achivmentModel.personalReflection);

    print(
        "Inside edit acco personalReflection:: ${personalReflectionController.text}");

    descController = TextEditingController(text: achivmentModel.description);
    descController.addListener(() {
      setState(() {
        descController.text.toString();
      });
    });

    if (widget.level1 == "Sports") {
      if (achivmentModel.sweight != null &&
          achivmentModel.sweight != 'null' &&
          achivmentModel.sweight != '')
        weightController = TextEditingController(text: achivmentModel.sweight);
      if (achivmentModel.sheight != null &&
          achivmentModel.sheight != 'null' &&
          achivmentModel.sheight != '')
        heightController = TextEditingController(text: achivmentModel.sheight);
    }

    if (achivmentModel.guidePromptRecommendation == "true") {
      isPrompt = true;
      isPromptfinal = true;
    } else {
      isPrompt = false;
      isPromptfinal = false;
    }

    setState(() {
      isPrompt;
    });

    if (achivmentModel.coachFirstName == null ||
        achivmentModel.coachFirstName == "null") {
      strCoachFirstName = "";
      coachFirstNameController = TextEditingController(text: "");
    } else {
      strCoachFirstName = achivmentModel.coachFirstName;
      coachFirstNameController =
          TextEditingController(text: achivmentModel.coachFirstName);
    }


    if (achivmentModel.recommenderTitle == null ||
        achivmentModel.recommenderTitle == "null") {
      strRecommendationTitle = "";
      recommendationTitleController =  TextEditingController(text: "");
    } else {
      strRecommendationTitle = achivmentModel.recommenderTitle;
      recommendationTitleController =
          TextEditingController(text: achivmentModel.recommenderTitle);
    }

    if (achivmentModel.recommendationTitle == null ||
        achivmentModel.recommendationTitle == "null") {
      strRecommenderTitle = "";
      recommenderTitleController =  TextEditingController(text: "");
    } else {
      strRecommenderTitle = achivmentModel.recommendationTitle;
      recommenderTitleController =
          TextEditingController(text: achivmentModel.recommendationTitle);
    }
/*
    if (achivmentModel.recommenderTitle == null ||
        achivmentModel.recommenderTitle == "null") {
      strRecommendationTitle = "";
      recommendationTitleController = TextEditingController(text: "");
    } else {
      strRecommendationTitle = achivmentModel.recommenderTitle;
      recommendationTitleController =
          TextEditingController(text: achivmentModel.recommenderTitle);
    }

    if (achivmentModel.recommendationTitle == null ||
        achivmentModel.recommendationTitle== "null") {
      strRecommenderTitle = "";
      recommenderTitleController = TextEditingController(text: "");
    } else {
      strRecommenderTitle = achivmentModel.recommendationTitle;
      recommenderTitleController = TextEditingController(text: achivmentModel.recommendationTitle);
    }*/

    if (achivmentModel.recommenderRequest == null ||
        achivmentModel.recommenderRequest == "null") {
      strRecommendationRequest = "";
      recommendationRequestController = TextEditingController(text: "");
    } else {
      strRecommendationRequest = achivmentModel.recommenderRequest;
      recommendationRequestController =
          TextEditingController(text: achivmentModel.recommenderRequest);
    }

    if (achivmentModel.coachLastName == null ||
        achivmentModel.coachLastName == "null") {
      strCoachLastName = "";
      coachLastNameController = TextEditingController(text: "");
    } else {
      strCoachLastName = achivmentModel.coachLastName;
      coachLastNameController =
          TextEditingController(text: achivmentModel.coachLastName);
    }

    if (achivmentModel.coachEmail == null ||
        achivmentModel.coachEmail == "null") {
      strCoachEmail = "";
      coachEmaiController = TextEditingController(text: "");
    } else {
      strCoachEmail = achivmentModel.coachEmail;
      coachEmaiController =
          TextEditingController(text: achivmentModel.coachEmail);
    }

    strCompetencyValue = achivmentModel.level3Competency == null
        ? ""
        : achivmentModel.level3Competency;
    strLevelValue = achivmentModel.importance;

    if (achivmentModel.fromDate == null ||
        achivmentModel.fromDate == "" ||
        achivmentModel.fromDate == "null") {
      strFromDate = "";
      fromDateController = TextEditingController(text: "");

      strToDate = "";
      toDateController = TextEditingController(text: "");
    } else {
      if (achivmentModel.fromDate != null &&
          achivmentModel.fromDate != "" &&
          achivmentModel.fromDate != "null") {
        DateTime date = DateTime.fromMillisecondsSinceEpoch(
            int.tryParse(achivmentModel.fromDate));
        fromDate = date;
        /* fromDateController =  TextEditingController(
          text:  DateFormat("dd-MM-yyyy").format(date));*/
        /*   fromDateController =  TextEditingController(
            text:  DateFormat("MM-dd-yyyy").format(date));*/

        fromDateController = TextEditingController(text: Util.getDate(date));
        strFromDate = achivmentModel.fromDate;
      } else {
        strFromDate = "";
      }

      if (achivmentModel.toDate != null &&
          achivmentModel.toDate != "" &&
          achivmentModel.toDate != "null") {
        DateTime date = DateTime.fromMillisecondsSinceEpoch(
            int.tryParse(achivmentModel.toDate));
        toDate = date;

        /* toDateController =  TextEditingController(
            text:  DateFormat("MM-dd-yyyy").format(date));*/

        toDateController = TextEditingController(text: Util.getDate(date));
        strToDate = achivmentModel.toDate;
      } else {
        // toDate =  DateTime.now();
        strToDate = "";
        toDateController = TextEditingController(text: "");
        isPresent = true;
      }
    }

    assestList.addAll(achivmentModel.assestList);

    skeelSelectedList.addAll(achivmentModel.skillList);

    if (achivmentModel.mediaList.length == 0 &&
        achivmentModel.certificateList.length == 0 &&
        achivmentModel.badgeList.length == 0 &&
        achivmentModel.trophyList == 0) {
      isShowMedia = false;
    }

    certificateList.addAll(achivmentModel.certificateList);
    certificateList.add("");

    // badgeList.addAll(achivmentModel.badgeList);
    // badgeList.add("");

    for (var file in achivmentModel.badgeList) {
      badgeAndTrophyList.add(new Assest("image", "badges", file, "", false));
    }

    for (var file in achivmentModel.trophyList) {
      badgeAndTrophyList.add(new Assest("image", "badges", file, "", false));
    }

    badgeAndTrophyList.add(new Assest("image", "badges", "", "", false));
    // trophyList.addAll(achivmentModel.trophyList);
    // trophyList.add("");
    // TODO: implement initState

    if (achivmentModel.externalLinksList.length > 0) {
      for (ExternalLinks _mLinkUrlDataModel
          in achivmentModel.externalLinksList) {
        linkUrlListData.add(LinkUrlModel(
            labelController:
                TextEditingController(text: _mLinkUrlDataModel.label),
            urlController: TextEditingController(text: _mLinkUrlDataModel.url),
            descController:
                TextEditingController(text: _mLinkUrlDataModel.description)));
      }
    } else {
      linkUrlListData.add(LinkUrlModel(
          labelController: TextEditingController(),
          urlController: TextEditingController(),
          descController: TextEditingController()));
    }

    super.initState();
  }

  //--------------------------Api Calling for delete achevement ------------------
  Future apiCallingForDeleteAchievment(achievementId) async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "achievementId": achievementId,
      };

      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
      CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            Navigator.pop(context, "push");
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditAchievment", context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    this.context = context;
    final dropdownMenuCompetency = level3Competencylist
        .map((Level3Competencies item) => DropdownMenuItem<Level3Competencies>(
            value: item,
            child: Text(
              item.name,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();

    final dropdownMenuLevel = levelList
        .map((AchievementImportanceModal item) =>
            DropdownMenuItem<AchievementImportanceModal>(
                value: item,
                child: Text(
                  item.title,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                )))
        .toList();

    void conformationDialog(type, path) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      "Are you sure you want to delete?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Remove",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (type == "media") {
                                                  mediaList.remove(path);
                                                  try {
                                                    assestList.removeLast();
                                                  } catch (e) {
                                                    crashlytics_bloc
                                                        .recordCrashlyticsError(
                                                            e,
                                                            "EditAchievment",
                                                            context);
                                                  }
                                                  setState(() {
                                                    mediaList;
                                                    assestList;
                                                  });
                                                  if (mediaList.length == 1 &&
                                                      mediaVideosList.length ==
                                                          1) {
                                                    selectedIndexCover = 0;
                                                    mediaList.removeLast();
                                                    mediaList.add(imageList[0]);
                                                    mediaList.add("");
                                                    isPredefinedMediaSelected =
                                                        true;
                                                  }
                                                } else if (type == "video") {
                                                  mediaVideosList.remove(path);
                                                  //assestList.removeLast();
                                                  setState(() {
                                                    mediaVideosList;
                                                    //assestList;
                                                  });
                                                  if (mediaList.length == 1 &&
                                                      mediaVideosList.length ==
                                                          1) {
                                                    selectedIndexCover = 0;
                                                    mediaList.removeLast();
                                                    mediaList.add(imageList[0]);
                                                    mediaList.add("");
                                                    isPredefinedMediaSelected =
                                                        true;
                                                  }
                                                } else if (type ==
                                                    "certificate") {
                                                  certificateList.remove(path);
                                                  assestList.removeLast();
                                                  setState(() {
                                                    certificateList;
                                                    assestList;
                                                  });
                                                } else {
                                                  badgeAndTrophyList
                                                      .remove(path);
                                                  assestList.removeLast();
                                                  setState(() {
                                                    badgeAndTrophyList;
                                                    assestList;
                                                  });
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void confromationDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      "Are you sure you want to delete this Accomplishment?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Remove",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCallingForDeleteAchievment(
                                                    achivmentModel
                                                        .achievementId);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    //---------------------------------Skill Core Logic nd ui -----------------------
    void iterateFilters(key, value) {
      print('-------------$key:$value'); //string interpolation in action
      if (value) {
        if (key != 0) {
          if (filterData == "") {
            filterData = (key).toString();
            appliedFilter = skillList[key].title;

            skeelSelectedList
                .add(Skill(skillList[key].title, skillList[key].skillId, key));
          } else {
            filterData = filterData + "," + (key).toString();
            appliedFilter = appliedFilter + "," + skillList[key].title;
            skeelSelectedList
                .add(Skill(skillList[key].title, skillList[key].skillId, key));
          }
        }
      }
    }

    _buildChoiceList() {
      List<Widget> choices = List();
      skeelSelectedList.forEach((item) {
        choices.add(Container(
            padding: const EdgeInsets.all(3.0),
            child: Row(
              children: <Widget>[
                Flexible(
                  child: Text(
                    item.label,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),
                  flex: 1,
                ),
                Expanded(
                  child: InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                        Icon(
                          Icons.cancel,
                          color: ColorValues.BG_CIRCLE_COLOR,
                          size: 17.0,
                        )),
                    onTap: () {
                      setState(() {
                        skeelSelectedList.remove(item);
                        filterStatus[item.index] = false;
                        filterStatus[0] = false;
                      });
                      filterData = "";
                      appliedFilter = "";
                      skeelSelectedList.clear();
                      filterStatus.forEach(iterateFilters);
                    },
                  ),
                  flex: 0,
                ),
              ],
            )));
      });
      return choices;
    }

    void onApplyClick() {
      filterData = "";
      appliedFilter = "";
      skeelSelectedList.clear();
      filterStatus.forEach(iterateFilters);
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());
        appliedFilter;
      });
      Navigator.pop(context);
    }

    void onCancelTap() {
      filterData = "";
      appliedFilter = "";
      skeelSelectedList.clear();
      for (int i = 0; i < filterStatus.length; i++) {
        filterStatus[i] = false;
      }
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());
        appliedFilter;
      });
      Navigator.pop(context);
    }

    void selectSkillDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: Scaffold(
                  backgroundColor: Colors.black38,
                  body: Center(
                      child: PaddingWrap.paddingAll(
                          10.0,
                          ListView(children: <Widget>[
                            Container(
                                padding: EdgeInsets.all(0.0),
                                color: Colors.white,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                      color: Color(0XFFEDEDED),
                                      child: PaddingWrap.paddingfromLTRB(
                                          19.0,
                                          10.0,
                                          10.0,
                                          10.0,
                                          Text(
                                            MessageConstant
                                                .ADD_AACHIEVMENT_EACH_EXPERIENCE,
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMREGULAR),
                                          )),
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        19.0,
                                        20.0,
                                        10.0,
                                        10.0,
                                        Text(
                                          MessageConstant
                                              .ADD_AACHIEVMENT_SELECT_ALL_SKILLS,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              fontSize: 14.0,
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                    PaddingWrap.paddingfromLTRB(
                                        19.0,
                                        0.0,
                                        10.0,
                                        10.0,
                                        ListView.builder(
                                            // itemCount: myData.lenght(),
                                            shrinkWrap: true,
                                            itemCount: skillList.length,
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              if ((skillList.length - 1) ==
                                                  index) {
                                                return Column(
                                                  children: <Widget>[
                                                    InkWell(
                                                      child: Padding(
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  8.0,
                                                                  0.0,
                                                                  8.0),
                                                          child: Row(
                                                            children: <Widget>[
                                                              filterStatus[
                                                                      index]
                                                                  ? Expanded(
                                                                      child: Padding(
                                                                          padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child: Image.asset(
                                                                            "assets/newDesignIcon/navigation/check.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                      flex: 0)
                                                                  : Expanded(
                                                                      child: Padding(
                                                                          padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child: Image.asset(
                                                                            "assets/newDesignIcon/navigation/uncheck.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                      flex: 0),
                                                              Expanded(
                                                                  child: Text(
                                                                skillList[index]
                                                                    .title,
                                                                maxLines: 3,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14.0,
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              )),
                                                            ],
                                                          )),
                                                      onTap: () {
                                                        bool value =
                                                            filterStatus[index];

                                                        if (index == 0) {
                                                          for (int i = 0;
                                                              i <
                                                                  filterStatus
                                                                      .length;
                                                              i++) {
                                                            if (value)
                                                              filterStatus[i] =
                                                                  false;
                                                            else
                                                              filterStatus[i] =
                                                                  true;
                                                          }
                                                        } else {
                                                          // filterStatus[0] = false; // Set All false
                                                          if (filterStatus[
                                                              index]) {
                                                            filterStatus[
                                                                index] = false;
                                                          } else {
                                                            filterStatus[
                                                                index] = true;
                                                          }
                                                        }

                                                        // Refresh the All Check
                                                        int count = 0;
                                                        for (int i = 1;
                                                            i <
                                                                filterStatus
                                                                    .length;
                                                            i++) {
                                                          if (!filterStatus[i])
                                                            count++;
                                                        }

                                                        if (count > 0) {
                                                          filterStatus[0] =
                                                              false;
                                                        } else {
                                                          filterStatus[0] =
                                                              true;
                                                        }

                                                        setState(() {
                                                          filterStatus;
                                                        });
                                                        Navigator.pop(context);
                                                        selectSkillDialog();
                                                      },
                                                    ),
                                                    Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            15.0,
                                                            20.0,
                                                            0.0,
                                                            20.0,
                                                            InkWell(
                                                              child: Text(
                                                                MessageConstant
                                                                    .CANCEL,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR),
                                                              ),
                                                              onTap: () {
                                                                onCancelTap();
                                                              },
                                                            ),
                                                          ),
                                                          flex: 0,
                                                        ),
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            0.0,
                                                            20.0,
                                                            20.0,
                                                            20.0,
                                                            InkWell(
                                                              child: Text(
                                                                '',
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR),
                                                              ),
                                                            ),
                                                          ),
                                                          flex: 1,
                                                        ),
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            10.0,
                                                            20.0,
                                                            30.0,
                                                            20.0,
                                                            InkWell(
                                                              child: Text(
                                                                MessageConstant
                                                                    .ADD_AACHIEVMENT_DONE,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color: ColorValues
                                                                        .BLUE_COLOR_BOTTOMBAR),
                                                              ),
                                                              onTap: () {
                                                                onApplyClick();
                                                              },
                                                            ),
                                                          ),
                                                          flex: 0,
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                );
                                              } else {
                                                return InkWell(
                                                  child: Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              0.0,
                                                              8.0,
                                                              0.0,
                                                              8.0),
                                                      child: Row(
                                                        children: <Widget>[
                                                          filterStatus[index]
                                                              ? Expanded(
                                                                  child:
                                                                      Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              5.0,
                                                                              8.0,
                                                                              5.0),
                                                                          child: Image
                                                                              .asset(
                                                                            "assets/newDesignIcon/navigation/check.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                  flex: 0)
                                                              : Expanded(
                                                                  child:
                                                                      Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              5.0,
                                                                              8.0,
                                                                              5.0),
                                                                          child:
                                                                              Image.asset(
                                                                            "assets/newDesignIcon/navigation/uncheck.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                  flex: 0),
                                                          Expanded(
                                                              child: Text(
                                                            skillList[index]
                                                                .title,
                                                            maxLines: 3,
                                                            style: TextStyle(
                                                                fontSize: 14.0,
                                                                color: ColorValues
                                                                    .HEADING_COLOR_EDUCATION,
                                                                fontWeight: skillList[index]
                                                                            .title ==
                                                                        MessageConstant
                                                                            .ADD_AACHIEVMENT_SELECT_ALL
                                                                    ? FontWeight
                                                                        .bold
                                                                    : FontWeight
                                                                        .normal,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR),
                                                          )),
                                                        ],
                                                      )),
                                                  onTap: () {
                                                    bool value =
                                                        filterStatus[index];
                                                    if (index == 0) {
                                                      for (int i = 0;
                                                          i <
                                                              filterStatus
                                                                  .length;
                                                          i++) {
                                                        if (value)
                                                          filterStatus[i] =
                                                              false;
                                                        else
                                                          filterStatus[i] =
                                                              true;
                                                      }
                                                    } else {
                                                      filterStatus[0] = false;
                                                      if (filterStatus[index]) {
                                                        filterStatus[index] =
                                                            false;
                                                      } else {
                                                        filterStatus[index] =
                                                            true;
                                                      }
                                                    }

                                                    // Refresh the All Check
                                                    int count = 0;
                                                    for (int i = 1;
                                                        i < filterStatus.length;
                                                        i++) {
                                                      if (!filterStatus[i])
                                                        count++;
                                                    }

                                                    if (count > 0) {
                                                      filterStatus[0] = false;
                                                    } else {
                                                      filterStatus[0] = true;
                                                    }

                                                    setState(() {
                                                      filterStatus;
                                                    });
                                                    Navigator.pop(context);
                                                    selectSkillDialog();
                                                  },
                                                );
                                              }
                                            }))
                                  ],
                                ))
                          ]))))));
    }

//======================================================================================

    //---------------------Add media View and core logics  ---------------------
    ontapApply(type) async {
      if (imagePath != null) {
        strAzureImageUploadPath = await uploadImgOnAzure(
            imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            strPrefixPathforPhoto);
        setState(() {
          strAzureImageUploadPath;
        });
        CustomProgressLoader.cancelLoader(context);
        print("azureimagepath   :-" + strAzureImageUploadPath);
        if (strAzureImageUploadPath != "" &&
            strAzureImageUploadPath != "false") {
          assestList.add(new Assest("image", type,
              strPrefixPathforPhoto + strAzureImageUploadPath, "", false));

          print("assestList========   " + assestList.length.toString());
          if (type == "media") {
            if (isPredefinedMediaSelected) {
              isPredefinedMediaSelected = false;
              mediaList.removeLast();
            }
            mediaList.removeLast();

            mediaList.add(strPrefixPathforPhoto + strAzureImageUploadPath);
            mediaList.add("");
          } else if (type == "certificates") {
            certificateList.removeLast();

            certificateList
                .add(strPrefixPathforPhoto + strAzureImageUploadPath);
            certificateList.add("");
          } else if (type == "badges") {
            badgeAndTrophyList.removeLast();

            badgeAndTrophyList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath, "", false));
            badgeAndTrophyList.add(new Assest("image", type, "", "", false));
          } else if (type == "trophy") {
            badgeAndTrophyList.removeLast();

            badgeAndTrophyList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath, "", false));
            badgeAndTrophyList.add(new Assest("image", type, "", "", false));
          }

          selectedImageType = "media";
          strAzureImageUploadPath = "";
          imagePath = null;
          setState(() {
            mediaList;
            isMedaiDialog = false;
            assestList;
            selectedImageType;
            strAzureImageUploadPath;
            imagePath;
          });
        }
      }
    }

    //------------------------Image Sewlection ---------------------------
    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }

    Future getImage(type) async {
      imagePath = await UploadMedia(context).pickImageFromGallery();

     // imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null && imagePath != "") {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);

        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          // await _cropImage(imagePath);
          if (imagePath != null) {
            /*setState(() {
            isMedaiDialog = true;
          });
          addMediaDialog();*/
            setState(() {
              imagePath;
            });

            CustomProgressLoader.showLoader(context);
            Timer _timer = Timer(const Duration(milliseconds: 400), () {
              ontapApply(type);
            });
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    String getFileExtension2(File file) {
      return path.extension(file.path);
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      //setState(() {});
      if (type == "video") {
        File file =
            await uploadMedia.compresssData(new File(imagePath), true, type);
        imagePath = file.path;
      } else if (type == "image") {
        File file = await uploadMedia.compressImage(new File(imagePath));
        imagePath = file.path;
      }
      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        //if (type == "video") {
        mediaAndVideoList.add("");
        String path = Constant.IMAGE_PATH +
            strPrefixPathforPhoto +
            strAzureImageUploadPath;

        //final thumbnailFile = await uploadMedia.getVideoThumbnailFromUrl(path);
        final thumbnailFile =
            await uploadMedia.getVideoThumbnailFromUrl(imagePath);
        //final thumbnailFile = await uploadMedia.getVideoThumbnailFromFile(path);

        print('view thumbnailFile:: ${thumbnailFile}');

        if (isPredefinedMediaSelected) {
          isPredefinedMediaSelected = false;
          /*mediaList.removeLast();
            mediaList.add("");*/
          mediaList.removeAt(0);
        }
        mediaVideosList.removeLast();
        mediaVideosList.add(new FileModel(
            thumbnailFile, strPrefixPathforPhoto + strAzureImageUploadPath));
        mediaVideosList.add(null);
        setState(() {
          mediaVideosList;
        });


      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    onTapVideoAddButton() async {
      imagePath = await uploadMedia.pickVideoFromGallery();
      print('Apurva inside onTapVideoAddButton() imagePath:: imagePath');
      if (imagePath != null) {
        if (imagePath != null &&
            getFileExtension2(imagePath) != null &&
            getFileExtension2(imagePath).length > 0) {
          CustomProgressLoader.showLoader(context);
          Timer _timer = Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "video");

            //ontapApply("video");
          });
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    rectangleDecoration() {
      return BoxDecoration(
          border: Border.all(color: Palette.dividerColor), color: Colors.white);
    }

    showMediaFileWidget(double width, File image) {
      return Container(
        height: 54,
        width: width,
        decoration: rectangleDecoration(),
        margin: EdgeInsets.only(left: 0, right: 0),
        child: Image.file(
          image,
          fit: BoxFit.contain,
        ),
      );
    }

    void typeSelection() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child: Container(
                                  height: 160.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    InkWell(
                                                      child: Container(
                                                          height: 50.0,
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child: Text(
                                                            "Badge",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style: TextStyle(
                                                                color: ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () async {
                                                        Navigator.pop(context);
                                                        var status =
                                                            await Permission
                                                                .photos.status;
                                                        if (status.isGranted) {
                                                          getImage("badges");
                                                        } else {
                                                          checkPermissionPhoto(
                                                              context);
                                                        }
                                                      },
                                                    ),
                                                    Container(
                                                      color: ColorValues
                                                          .BORDER_COLOR,
                                                      height: 1.0,
                                                    ),
                                                    InkWell(
                                                      child: Container(
                                                          height: 50.0,
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child: Text(
                                                            "Trophy",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style: TextStyle(
                                                                color: ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () async {
                                                        Navigator.pop(context);
                                                        var status =
                                                            await Permission
                                                                .photos.status;
                                                        if (status.isGranted) {
                                                          getImage("trophy");
                                                        } else {
                                                          checkPermissionPhoto(
                                                              context);
                                                        }
                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final competencyDropDownUi = Container(
        height: 28.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<Level3Competencies>(
                hint: Text(
                  strCompetencyHint,
                  style: TextStyle(
                      fontSize: 16.0,
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: competencySelected,
                items: dropdownMenuCompetency,
                onChanged: (Level3Competencies item) {
                  if (item.name == "Other") {
                    isOtherCategory = true;
                    isThirdLevelOther = true;
                  } else {
                    isThirdLevelOther = false;
                    isOtherCategory = false;
                    thirdLevelController.text = "";
                  }

                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    competencySelected = item;
                    strCompetencyValue = item.name;
                  });
                })));

    final competencyDropLevel = Container(
        height: 28.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<AchievementImportanceModal>(
                hint: Text(
                  strLevelHint,
                  style: TextStyle(
                      fontSize: 16.0,
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: levelSelected,
                items: dropdownMenuLevel,
                onChanged: (AchievementImportanceModal level) {
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    levelSelected = level;
                    strLevelValue = level.importanceId;
                  });
                })));

    final titleUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          maxLength: TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
          focusNode: _focus,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          controller: titleController,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),

          decoration:
              BaseCommonWidget.textFormFieldDecorationAchievment("Title", ""),
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_TITLE_VAL : null,
        ));

    getEditCategoryTextField(isEnabled, label) {
      return Container(
          padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 5.0),
          child: TextFormField(
            keyboardType: TextInputType.text,
            style: TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
            //autofocus: true,
            //enabled: isEnabled,
            maxLength: isEnabled
                ? TextLength.OTHER_MAX_LENGTH
                : TextLength.OTHER_COMPETENCY_MAX_LENGTH,

            textCapitalization: TextCapitalization.sentences,
            cursorColor: Constant.CURSOR_COLOR,
            controller: isEnabled ? otherCategory : thirdLevelController,
            decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
                label, isEnabled ? "" : MessageConstant.FOCUS_AREA_HINT_TEXT),

            validator: (val) =>
                val.trim().isEmpty ? MessageConstant.ENTER_TITLE_VAL : null,
          ));
    }

    final workingHours = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.number,
          maxLength: TextLength.WORKING_HOURS_MAX_LENGTH,
          focusNode: workinHoursFocusNode,
          controller: workingHourController,
          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_HOURS_WORKED, ""),
          onSaved: (val) => strWorkingHours = val.trim(),
        ));

    final recommenderTitle = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: recommenderTitleController,
          enabled: (!isPromptfinal),
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_TITLE, "eg.Science Teacher"),

          validator: (val) => isPromptfinal
              ? null
              : val.trim().isEmpty
                  ? isPrompt
                      ? MessageConstant.ENTER_TITLE_VAL
                      : null
                  : null,
          onSaved: (val) => strRecommenderTitle = val.trim(),
        ));
    final recommendationRequest = Padding(
        padding: const EdgeInsets.fromLTRB(0.0, 15, 0, 0),
        child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(0),
              border: Border.all(
                color: Color(0xFFFDEDEDE),
                style: BorderStyle.solid,
                width: 1.0,
              ),
            ),
            padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
            child: TextFormField(
              keyboardType: TextInputType.multiline,
              cursorColor: Constant.CURSOR_COLOR,
              maxLength: TextLength.RECOMMENDATION_REQUEST_MSG_LENGTH,
              controller: recommendationRequestController,
              enabled: (!isPromptfinal),
              textCapitalization: TextCapitalization.sentences,
              maxLines: 3,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
                  MessageConstant.ADD_ACHIEVMENT_RECOMMENDATION_REQUEST,
                  MessageConstant
                      .ADD_ACHIEVMENT_GREATE_SOCCER_SEASON)
              ,
              validator: (val) => (isPromptfinal)
                  ? null
                  : val.trim().isEmpty
                      ? isPrompt
                          ? MessageConstant.ENTER_REQUEST_VAL
                          : null
                      : null,
              onSaved: (val) => strRecommendationRequest = val.trim(),
            )));

    final recommendationTitle = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          enabled: (!isPromptfinal),
          autofocus: isPromptfinal ? false : true,
          cursorColor: Constant.CURSOR_COLOR,
          controller: recommendationTitleController,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /* TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_RECOMMENDATION_TITLE, ''),

          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? MessageConstant.ENTER_RECOMMENDATION_TITLE_VAL
                  : null
              : null,
          onSaved: (val) => strRecommendationTitle = val.trim(),
        ));

    final coachFirstName = PaddingWrap.paddingfromLTRB(
        0.0,
        10.0,
        0.0,
        0.0,
        Container(
            child: TextFormField(
          keyboardType: TextInputType.text,
          controller: coachFirstNameController,
          cursorColor: Constant.CURSOR_COLOR,
          enabled: (!isPromptfinal),
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),

          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_FIRST_NAME,
              MessageConstant.ADD_ACHIEVMENT_FIRST_NAME),

          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_FIRST_NAME_VAL
                      : !ValidationWidget.isName(val)
                          ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_FIRST_NAME_VAL
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                      : null,
          onSaved: (val) => strCoachFirstName = val.trim(),
        )));
    final coachLastName = PaddingWrap.paddingfromLTRB(
        0.0,
        10.0,
        0.0,
        0.0,
        Container(
            child: TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          enabled: (!isPromptfinal),
          controller: coachLastNameController,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
          /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_LAST_NAME,
              MessageConstant.ADD_ACHIEVMENT_LAST_NAME),

          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_LAST_NAME_VAL
                      : !ValidationWidget.isName(val)
                          ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_LAST_NAME_VAL
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                      : null,
          onSaved: (val) => strCoachLastName = val.trim(),
        )));

    final coachEmail = PaddingWrap.paddingfromLTRB(
        0.0,
        10.0,
        0.0,
        16.0,
        Container(
            child: TextFormField(
          keyboardType: TextInputType.emailAddress,
          controller: coachEmaiController,
          cursorColor: Constant.CURSOR_COLOR,
          enabled: (!isPromptfinal),
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),

          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_AACHIEVMENT_EMAIL, "abc@xyz.com"),

          validator: (val) => isPromptfinal
              ? null
              : val.trim().isEmpty
                  ? isPrompt
                      ? val.trim().length == 0
                          ? MessageConstant.ENTER_EMAIL_VAL
                          : val.toString().toLowerCase() ==
                                  userEmail.toLowerCase()
                              ? MessageConstant
                                  .SELF_RECOMMENDATION_NOT_GOOD_IDEA
                              : !ValidationWidget.isEmail(val)
                                  ? MessageConstant.VALID_EMAIL_VAL
                                  : null
                      : null
                  : val.trim().length == 0
                      ? MessageConstant.ENTER_EMAIL_VAL
                      : val.toString().toLowerCase() == userEmail.toLowerCase()
                          ? MessageConstant.SELF_RECOMMENDATION_NOT_GOOD_IDEA
                          : !ValidationWidget.isEmail(val)
                              ? MessageConstant.VALID_EMAIL_VAL
                              : null,
          onSaved: (val) => strCoachEmail = val.trim(),
        )));

    final descriptrionUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          maxLength: TextLength.ACCOMPLISHMENT_DESCRIPTION_MAX_LENGTH,
          textCapitalization: TextCapitalization.sentences,
          controller: descController,
          maxLines: null,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),

          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_AACHIEVMENT_DESCRIPTION,
              MessageConstant.ADD_AACHIEVMENT_HIGHLIGHT_KAY_LEARNING),

          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_DESCRIPTION_VAL : null,
        ));

    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }
    showHeight() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 38.0,
                              child: Container(
                                  height: 190.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 0, 13, 0),
                                        child: Container(
                                          color: Colors.white,
                                          height: 155.0,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                  color: Colors.white,
                                                  height: 40.0,
                                                  child: Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(
                                                          13.0, 8, 0, 0),
                                                      child: Text(
                                                        MessageConstant
                                                            .ADD_ACCOMPLISHMENT_HEIGHT,
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .GREY_TEXT_COLOR,
                                                            fontSize: 18.0,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR),
                                                      ))),
                                              Container(
                                                color: ColorValues.GREY__COLOR,
                                                height: 0.3,
                                              ),
                                              Container(
                                                  height: 113.0,
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: CupertinoPicker(
                                                            backgroundColor:
                                                            Colors.white,
                                                            onSelectedItemChanged:
                                                                (value) {
                                                              print(
                                                                  "CupertinoPicker Value+++++");
                                                              setState(() {
                                                                //selectedValue = value;
                                                                strFootValue =
                                                                footList[
                                                                value];
                                                              });
                                                            },
                                                            itemExtent: 40.0,
                                                            children:
                                                            List.generate(
                                                                footList
                                                                    .length,
                                                                    (int
                                                                index) {
                                                                  return Padding(
                                                                    padding:
                                                                    const EdgeInsets
                                                                        .fromLTRB(
                                                                        0.0,
                                                                        4,
                                                                        0,
                                                                        0),
                                                                    child: Text(
                                                                      footList[
                                                                      index],
                                                                      style:
                                                                      styleForHeight,
                                                                    ),
                                                                  );
                                                                })),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: CupertinoPicker(
                                                            backgroundColor:
                                                            Colors.white,
                                                            onSelectedItemChanged:
                                                                (value) {
                                                              setState(() {
                                                                //selectedValue = value;
                                                                strInchValue = inchList[
                                                                value];
                                                              });
                                                            },
                                                            itemExtent: 40.0,
                                                            children:
                                                            List.generate(
                                                                inchList.length,
                                                                    (int
                                                                index) {
                                                                  return Padding(
                                                                    padding:
                                                                    const EdgeInsets
                                                                        .fromLTRB(
                                                                        0.0,
                                                                        4,
                                                                        0,
                                                                        0),
                                                                    child: Text(
                                                                      inchList[
                                                                      index],
                                                                      style:
                                                                      styleForHeight,
                                                                    ),
                                                                  );
                                                                })),
                                                        flex: 1,
                                                      ),
                                                    ],
                                                  )),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                    MessageConstant.CANCEL,
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.of(context,
                                                    rootNavigator: true)
                                                    .pop('dialog');
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                    MessageConstant
                                                        .ADD_ACCOMPLISHMENT_SAVE,
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                isValidHeight = true;

                                                heightController.text =
                                                    strFootValue + strInchValue;
                                                Navigator.pop(context);
                                                setState(() {});
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }
    Future<Null> selectFromDate(BuildContext context) async {
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime: DateTime.now(),
        initialDateTime: fromDate == null ? DateTime.now() : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime != null) {
            fromDate = dateTime;
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime);
            String date2 = DateFormat("yyyy-MM-dd").format(dateTime);
            print(date);
            setState(() {
              fromDate;
              strFromDate = (dateTime.millisecondsSinceEpoch).toString();
              fromDateController = TextEditingController(text: date);
              toDateController = TextEditingController(text: "");
              strToDate = "";
            });
          }
        },
      );
    }
    final heightUi = InkWell(
        onTap: () {
          FocusScope.of(context).unfocus();
          showHeight();
        },
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
            margin: EdgeInsets.all(0.0),
            child: TextFormField(
                keyboardType: TextInputType.text,
                controller: heightController,
                maxLength: 10,
                cursorColor: Constant.CURSOR_COLOR,
                style: AppTextStyle.getDynamicStyleAddPortfolia(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    null,
                    FontType.Regular),

                textCapitalization: TextCapitalization.sentences,
                maxLines: null,
                enabled: (!isValidHeight),
                onTap: () {
                  showHeight();
                },
                decoration:
                BaseCommonWidget.textFormFieldDecorationAccomplishment(
                    MessageConstant.ADD_ACCOMPLISHMENT_HEIGHT,
                    MessageConstant.ADD_ACCOMPLISHMENT_HEIGHT))));


    final weightUi = Container(
        padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.number,
          controller: weightController,
          focusNode: weightFocusNode,
          maxLength: 10,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
              "Weight (in pounds)", ""),
          /* validator: (val) =>
          val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,*/
          onSaved: (val) => strWeight = val.trim(),
        ));



    final fromDateUi = InkWell(
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            child: TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              controller: fromDateController,
              decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
                  MessageConstant.ADD_AACHIEVMENT_DATE_FROM,
                  "abc@xyz.com"),
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
            selectFromDate(context);
          });
        });

    Future<Null> selectToDate(BuildContext context) async {
      DateTime dateTime2;
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime: DateTime.now(),
        initialDateTime: toDateController == null || toDateController.text == ""
            ? fromDate
            : toDate != null
                ? toDate
                : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime2 != null) {
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime2);
            String date2 = DateFormat("yyyy-MM-dd").format(dateTime2);
            print(date);

            var differenceStartDate = dateTime2.difference(fromDate);
            if (differenceStartDate.inDays >= 0) {
              setState(() {
                isPresent = false;
                toDate = dateTime2;
                strToDate = (dateTime2.millisecondsSinceEpoch).toString();
                toDateController = TextEditingController(text: date);
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.ENTER_CORRECT_DATE_RANGE_VAL, context);
            }
          }
        },
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());
          dateTime2 = dateTime;
        },
      );
    }

    final toDateUi = InkWell(
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            child: TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              controller: toDateController,
              decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
                  MessageConstant.ADD_AACHIEVMENT_DATE_TO,
                  ''),
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
            if (fromDate != null) {
              selectToDate(context);
            } else {
              ToastWrap.showToast(
                  MessageConstant.SELECT_FROM_DATE_VAL, context);
            }
          });
        });

    final mediaImageListUI = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaList.map((path) {
        if (path == "") {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 80.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () async {
                if (assestList.length <=
                    TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                  var status = await Permission.photos.status;
                  if (status.isGranted) {
                    getImage("media");
                  } else {
                    checkPermissionPhoto(context);
                  }
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return Container(
              child: Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path,
                height: 54.0,
                width: 80.0,
              ),
              Container(
                height: 54.0,
                width: 80.0,
                color: Color(0XFFC0C0C0).withOpacity(.4),
              ),
              isPredefinedMediaSelected
                  ? Container(
                      height: 0.0,
                    )
                  : Container(
                      height: 54.0,
                      width: 80.0,
                      child: Center(
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                            InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    Image.asset(
                                      "assets/newDesignIcon/achievment/remove.png",
                                      width: 35.0,
                                      height: 35.0,
                                    )),
                                onTap: () {
                                  conformationDialog("media", path);
                                })
                          ]))),
            ],
          ));
        }
      }).toList(),
    ));

    final videoListUi = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaVideosList.map((file) {
        if (file == null) {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 80.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                if (mediaAndVideoList.length <= 9) {
                  onTapVideoAddButton();
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAX_10_IMAGE_VIDEO_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return Container(
              child: Stack(
            children: <Widget>[
              file.file == null
                  ? Container(
                      height: 54,
                      width: 80,
                      decoration: rectangleDecoration(),
                      margin: EdgeInsets.only(left: 0, right: 0),
                      child: VideoView(
                          Constant.IMAGE_PATH + file.path, "", false, ""),
                    )
                  : showMediaFileWidget(80, file.file),
              Container(
                height: 54.0,
                width: 80.0,
                color: Color(0XFFC0C0C0).withOpacity(.4),
              ),
              Container(
                  height: 54.0,
                  width: 80.0,
                  child: Center(
                      child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              Image.asset(
                                "assets/newDesignIcon/achievment/remove.png",
                                width: 35.0,
                                height: 35.0,
                              )),
                          onTap: () {
                            conformationDialog("video", file);
                          })
                    ],
                  ))),
            ],
          ));
        }
      }).toList(),
    ));

    final certificateListUI = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: certificateList.map((path) {
        if (path == "") {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 80.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () async {
                if (assestList.length <=
                    TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                  var status = await Permission.photos.status;
                  if (status.isGranted) {
                    getImage("certificates");
                  } else {
                    checkPermissionPhoto(context);
                  }
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path,
                height: 54.0,
                width: 80.0,
              ),
              Container(
                height: 54.0,
                width: 80.0,
                color: Color(0XFFC0C0C0).withOpacity(.4),
              ),
              Container(
                  height: 54.0,
                  width: 80.0,
                  child: Center(
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                        InkWell(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                Image.asset(
                                  "assets/newDesignIcon/achievment/remove.png",
                                  width: 35.0,
                                  height: 35.0,
                                )),
                            onTap: () {
                              conformationDialog("certificate", path);
                            })
                      ]))),
            ],
          );
        }
      }).toList(),
    ));

    final trophyListUi = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: badgeAndTrophyList.map((path) {
        if (path.file == "") {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 54.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                if (assestList.length <=
                    TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                  typeSelection();
                  // getImage("trophy");
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path.file,
                height: 54.0,
                width: 62.0,
              ),
              Container(
                height: 54.0,
                width: 62.0,
                color: Color(0XFFC0C0C0).withOpacity(.4),
              ),
              Container(
                  height: 54.0,
                  width: 80.0,
                  child: Center(
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                        InkWell(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                Image.asset(
                                  "assets/newDesignIcon/achievment/remove.png",
                                  width: 35.0,
                                  height: 35.0,
                                )),
                            onTap: () {
                              conformationDialog("badge", path);
                            })
                      ]))),
            ],
          );
        }
      }).toList(),
    ));
//==========================Grid View horizontal for Selected Images====================================

    // Build a Form widget using the _formKey we created above
    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: GestureDetector(
            onTap: () {
              // FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                backgroundColor: ColorValues.SCREEN_BG_COLOR,
                appBar: AppBar(
                  brightness: Brightness.light,
                  automaticallyImplyLeading: false,
                  titleSpacing: 0.0,
                  elevation: 0.0,
                  title: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Expanded(
                        child: InkWell(
                          child: CustomViews.getBackButton(),
                          onTap: () {
                            Navigator.pop(context, isPerformChnges);
                          },
                        ),
                        flex: 0,
                      ),
                      Expanded(
                        child:

                            Text(
                          achivmentModel.level2Competency == "Other" ||
                                  achivmentModel.level2Competency == "General"
                              ? strCompetencyValue
                              : achivmentModel.level2Competency,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 18.0,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        ),
                        flex: 1,
                      )
                    ],
                  ),
                  actions: <Widget>[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              20.0,
                              0.0,
                              TextViewWrap.textView(
                                  MessageConstant.ADD_AACHIEVMENT_SAVE,
                                  TextAlign.start,
                                  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  16.0,
                                  FontWeight.normal)),
                          onTap: () {
                            final form = _formKey.currentState;
                            form.save();
                            //   FocusScope.of(context).unfocus();
                            if (isThirdLevelOther &&
                                thirdLevelController.text.length > 0) {
                              setState(() {
                                isThirLevelField = true;
                              });
                            } else {
                              setState(() {
                                isThirLevelField = false;
                              });
                            }

                            print('Save Called.....');

                            if (titleController.text == "" ||
                                descController.text == "" ||
                                strCompetencyValue == "" ||
                                appliedFilter == "" ||
                                strLevelValue == "") {
                              scrollTop();
                            } else {
                              if (strCoachFirstName != "" ||
                                  strCoachLastName != "" ||
                                  strCoachEmail != "") {
                                scrollBottom();
                              }
                            }

                            if (form.validate()) {
                              if (validationCheck()) {
                                if (isThirdLevelOther &&
                                    thirdLevelController.text.length == 0) {
                                  return;
                                }
                                apiCalling();
                              }
                            } else {
                              ToastWrap.showToast(
                                  MessageConstant
                                      .ENTER_VALUE_ACCOMPLISHMENT_FIELD_VAL,
                                  context);
                            }
                          },
                        )
                      ],
                    )
                  ],
                  backgroundColor: Colors.white,
                ),
                body: Theme(
                    data: ThemeData(hintColor: Colors.grey[300]),
                    child: Stack(
                      children: <Widget>[
                        Positioned(
                            top: 0.0,
                            left: 0.0,
                            right: 0.0,
                            bottom: 0.0,
                            child: FormKeyboardActions(
                                nextFocus: false,
                                keyboardActionsPlatform:
                                    KeyboardActionsPlatform.IOS,
                                //optional
                                keyboardBarColor: Colors.grey[200],
                                //optional
                                actions: [
                                  KeyboardAction(
                                    focusNode: workinHoursFocusNode,
                                  ),
                                ],
                                child: Column(
                                  children: <Widget>[
                                    CustomViews.getSepratorLine(),
                                    Expanded(
                                        child: ListView(
                                      controller: _controller,
                                      children: <Widget>[
                                        Form(
                                            key: _formKey,
                                            child: Column(
                                              children: <Widget>[
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Container(
                                                        color:
                                                            Color(0XFFFAFAFA),
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                12.0,
                                                                12.0,
                                                                12.0,
                                                                10.0,
                                                                Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: <
                                                                        Widget>[
                                                                      Container(
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(0),
                                                                          color:
                                                                              Colors.white,
                                                                          border:
                                                                              Border.all(
                                                                            color:
                                                                                Color(0xFFFDEDEDE),
                                                                            style:
                                                                                BorderStyle.solid,
                                                                            width:
                                                                                1.0,
                                                                          ),
                                                                        ),
                                                                        child: PaddingWrap.paddingfromLTRB(
                                                                            14.0,
                                                                            0.0,
                                                                            5.0,
                                                                            10.0,
                                                                            Row(
                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: <Widget>[
                                                                                Expanded(
                                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                                      0.0,
                                                                                      17.0,
                                                                                      15.0,
                                                                                      0.0,
                                                                                      Image.asset(
                                                                                        "assets/newDesignIcon/achievment/title.png",
                                                                                        width: 30.0,
                                                                                        height: 30.0,
                                                                                      )),
                                                                                  flex: 0,
                                                                                ),
                                                                                Expanded(
                                                                                  child: Column(
                                                                                    children: <Widget>[
                                                                                      titleUi,
                                                                                      descriptrionUi,

                                                                                      ///personalReflectionUi,
                                                                                    ],
                                                                                  ),
                                                                                  flex: 1,
                                                                                )
                                                                              ],
                                                                            )),
                                                                      ),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(0),
                                                                              color: Colors.white,
                                                                              border: Border.all(
                                                                                color: Color(0xFFFDEDEDE),
                                                                                style: BorderStyle.solid,
                                                                                width: 1.0,
                                                                              ),
                                                                            ),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                14.0,
                                                                                10.0,
                                                                                5.0,
                                                                                10.0,
                                                                                Row(
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                  children: <Widget>[
                                                                                    Expanded(
                                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                                          0.0,
                                                                                          15.0,
                                                                                          15.0,
                                                                                          0.0,
                                                                                          Image.asset(
                                                                                            "assets/newDesignIcon/achievment/competency.png",
                                                                                            width: 30.0,
                                                                                            height: 30.0,
                                                                                          )),
                                                                                      flex: 0,
                                                                                    ),
                                                                                    Expanded(
                                                                                      child: Column(
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: <Widget>[
                                                                                          isThirdLevelOther
                                                                                              ? Column(
                                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                  children: [
                                                                                                    PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 0.0, getTextLabel("Focus Area", 11.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal)),
                                                                                                    competencyDropDownUi,
                                                                                                  ],
                                                                                                )
                                                                                              : Container(height: 0.0),
                                                                                          isThirdLevelOther
                                                                                              ? Padding(
                                                                                                  padding: const EdgeInsets.only(top: 15.0),
                                                                                                  child: Column(
                                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                                    children: [
                                                                                                      PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 5.0, getTextLabel("Other, please specify", 14.0, ColorValues.TEXT_LIGHT_GREY, FontWeight.normal)),
                                                                                                      Container(
                                                                                                          width: double.infinity,
                                                                                                          height: 30.0,
                                                                                                          decoration: BoxDecoration(border: Border.all(color: ColorValues.GREY__COLOR_DIVIDER)),
                                                                                                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                                                                          margin: EdgeInsets.all(0.0),
                                                                                                          child: TextFormField(
                                                                                                            keyboardType: TextInputType.text,
                                                                                                            controller: thirdLevelController,
                                                                                                            maxLength: 25,
                                                                                                            cursorColor: Constant.CURSOR_COLOR,
                                                                                                            style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                            textCapitalization: TextCapitalization.sentences,
                                                                                                            decoration: InputDecoration(
                                                                                                              counterText: "",
                                                                                                              disabledBorder: InputBorder.none,
                                                                                                              focusedBorder: InputBorder.none,
                                                                                                              enabledBorder: InputBorder.none,
                                                                                                              isDense: true,
                                                                                                              // Added this
                                                                                                              contentPadding: EdgeInsets.only(left: 5.0, top: 1.0, bottom: 0.0),
                                                                                                              floatingLabelBehavior: FloatingLabelBehavior.always,
                                                                                                            ),
                                                                                                          )),
                                                                                                      isThirLevelField
                                                                                                          ? Container(
                                                                                                              height: 0.0,
                                                                                                            )
                                                                                                          : PaddingWrap.paddingfromLTRB(
                                                                                                              0.0,
                                                                                                              5.0,
                                                                                                              0.0,
                                                                                                              0.0,
                                                                                                              Text(
                                                                                                                MessageConstant.THIRD_LEVEL_REQUIRED,
                                                                                                                style: TextStyle(color: ColorValues.ERROR_COLOR, fontSize: 12.0),
                                                                                                              ))
                                                                                                    ],
                                                                                                  ),
                                                                                                )
                                                                                              : isOtherCategory
                                                                                                  ? getEditCategoryTextField(false, isThirdLevelOther ? MessageConstant.ADD_AACHIEVMENT_ENTER_DISPLAY_TITLE : MessageConstant.ADD_AACHIEVMENT_FOCUS_AREA)
                                                                                                  : Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: [
                                                                                                        PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 0.0, getTextLabel(MessageConstant.ADD_AACHIEVMENT_FOCUS_AREA, 11.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal)),
                                                                                                        competencyDropDownUi,
                                                                                                      ],
                                                                                                    ),
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              20.0,
                                                                                              0.0,
                                                                                              5.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: InkWell(
                                                                                                        child: TextViewWrap.textView(skeelSelectedList.length == 0 ? "Add Skills" : "Skills", TextAlign.start, skeelSelectedList.length == 0 ? ColorValues.BLUE_COLOR_BOTTOMBAR : ColorValues.GREY_TEXT_COLOR, skeelSelectedList.length == 0 ? 16.0 : 12.0, FontWeight.normal),
                                                                                                        onTap: () {
                                                                                                          if (skeelSelectedList.length == 0) selectSkillDialog();
                                                                                                        }),
                                                                                                    flex: 1,
                                                                                                  )
                                                                                                ],
                                                                                              )),
                                                                                          Row(
                                                                                            crossAxisAlignment: CrossAxisAlignment.end,
                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                            children: <Widget>[
                                                                                              Expanded(
                                                                                                child: Wrap(
                                                                                                  children: _buildChoiceList(),
                                                                                                ),
                                                                                                flex: 1,
                                                                                              ),
                                                                                              Expanded(
                                                                                                child: skeelSelectedList.length == 0
                                                                                                    ? Container(
                                                                                                        height: 0.0,
                                                                                                      )
                                                                                                    : InkWell(
                                                                                                        child: Container(
                                                                                                            height: 20.0,
                                                                                                            width: 40.0,
                                                                                                            child: Icon(
                                                                                                              Icons.add,
                                                                                                              color: Colors.black,
                                                                                                              size: 20.0,
                                                                                                            )),
                                                                                                        onTap: () {
                                                                                                          selectSkillDialog();
                                                                                                        },
                                                                                                      ),
                                                                                                flex: 0,
                                                                                              )
                                                                                            ],
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                      flex: 1,
                                                                                    )
                                                                                  ],
                                                                                )),
                                                                          )),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(0),
                                                                              color: Colors.white,
                                                                              border: Border.all(
                                                                                color: Color(0xFFFDEDEDE),
                                                                                style: BorderStyle.solid,
                                                                                width: 1.0,
                                                                              ),
                                                                            ),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                14.0,
                                                                                10.0,
                                                                                5.0,
                                                                                10.0,
                                                                                Row(
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                  children: <Widget>[
                                                                                    Expanded(
                                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                                          0.0,
                                                                                          15.0,
                                                                                          15.0,
                                                                                          0.0,
                                                                                          Image.asset(
                                                                                            "assets/newDesignIcon/achievment/achiewvement_level.png",
                                                                                            width: 30.0,
                                                                                            height: 30.0,
                                                                                          )),
                                                                                      flex: 0,
                                                                                    ),
                                                                                    Expanded(
                                                                                      child: Column(
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: <Widget>[
                                                                                          /*skillUi,*/
                                                                                          PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 0.0, getTextLabel(MessageConstant.ADD_AACHIEVMENT_ACHIEVEMENT_LEVEL, 12.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal)),
                                                                                          competencyDropLevel,
                                                                                          widget.achivmentModel.level3Competency == MessageConstant.ADD_AACHIEVMENT_VOLUNTEERING ? workingHours : Container(height: 0.0),

                                                                                          widget.level1 ==
                                                                                              "Sports"
                                                                                              ?
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              10.0,
                                                                                              0.0,
                                                                                              0.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[heightUi],
                                                                                                    ),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[weightUi],
                                                                                                    ),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                ],
                                                                                              )):Container(height: 0,),

                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              10.0,
                                                                                              0.0,
                                                                                              0.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[fromDateUi],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Container(),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[toDateUi],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                ],
                                                                                              )),
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              8.0,
                                                                                              0.0,
                                                                                              8.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                                                                mainAxisAlignment: MainAxisAlignment.end,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Container(),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Row(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[
                                                                                                        Expanded(
                                                                                                          child: InkWell(
                                                                                                            child: Image.asset(
                                                                                                              isPresent ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                                                              width: 25.0,
                                                                                                              height: 25.0,
                                                                                                            ),
                                                                                                            onTap: () {
                                                                                                              if (isPresent)
                                                                                                                isPresent = false;
                                                                                                              else
                                                                                                                isPresent = true;
                                                                                                              setState(() {
                                                                                                                isPresent;

                                                                                                                toDate = null;
                                                                                                                strToDate = "";
                                                                                                                toDateController = TextEditingController(text: "");
                                                                                                              });
                                                                                                            },
                                                                                                          ),
                                                                                                          flex: 0,
                                                                                                        ),
                                                                                                        Expanded(
                                                                                                          child: Container(
                                                                                                            padding: EdgeInsets.fromLTRB(5.0, 3.0, 0.0, 0.0),
                                                                                                            child: Container(child: TextViewWrap.textView("Ongoing   ", TextAlign.start, ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontWeight.normal)),
                                                                                                          ),
                                                                                                          flex: 0,
                                                                                                        )
                                                                                                      ],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  )
                                                                                                ],
                                                                                              )),
                                                                                        ],
                                                                                      ),
                                                                                      flex: 1,
                                                                                    )
                                                                                  ],
                                                                                )),
                                                                          )),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(0),
                                                                              color: Colors.white,
                                                                              border: Border.all(
                                                                                color: Color(0xFFFDEDEDE),
                                                                                style: BorderStyle.solid,
                                                                                width: 1.0,
                                                                              ),
                                                                            ),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                14.0,
                                                                                10.0,
                                                                                5.0,
                                                                                10.0,
                                                                                InkWell(
                                                                                  child: Row(
                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    children: <Widget>[
                                                                                      Expanded(
                                                                                        child: PaddingWrap.paddingfromLTRB(
                                                                                            0.0,
                                                                                            15.0,
                                                                                            15.0,
                                                                                            0.0,
                                                                                            Image.asset(
                                                                                              "assets/newDesignIcon/achievment/media.png",
                                                                                              width: 30.0,
                                                                                              height: 30.0,
                                                                                            )),
                                                                                        flex: 0,
                                                                                      ),
                                                                                      Expanded(
                                                                                        child: Column(
                                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                          children: <Widget>[
                                                                                            PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 10.0, TextViewWrap.textView("Add media", TextAlign.start, ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontWeight.normal)),
                                                                                            PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 0.0, TextViewWrap.textViewMultiLine("Upload Photos, Videos or Images of Certificates, Trophies, and Badges to enrich and embellish your Profile", TextAlign.start, ColorValues.GREY_TEXT_COLOR, 14.0, FontWeight.normal, 4)),
                                                                                            isShowMedia
                                                                                                ? Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
                                                                                                    PaddingWrap.paddingfromLTRB(
                                                                                                        0.0,
                                                                                                        20.0,
                                                                                                        0.0,
                                                                                                        10.0,
                                                                                                        Text(
                                                                                                          "Photos",
                                                                                                          style: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                        )),
                                                                                                    mediaImageListUI,
                                                                                                    Padding(
                                                                                                      padding: const EdgeInsets.fromLTRB(0.0, 0, 20, 10),
                                                                                                      child: isPredefinedMediaSelected && imageList.length > 0
                                                                                                          ? Row(
                                                                                                              children: <Widget>[
                                                                                                                Expanded(
                                                                                                                  child: Stack(
                                                                                                                    children: <Widget>[
                                                                                                                      InkWell(
                                                                                                                        child: Container(
                                                                                                                            height: 65,
                                                                                                                            width: 65,
                                                                                                                            padding: EdgeInsets.fromLTRB(0, 8, 10, 8),
                                                                                                                            child: FadeInImage.assetNetwork(
                                                                                                                              fit: BoxFit.fill,
                                                                                                                              width: 65,
                                                                                                                              alignment: Alignment.center,
                                                                                                                              placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                              image: Constant.IMAGE_PATH + imageList[0],
                                                                                                                            )),
                                                                                                                        onTap: () {
                                                                                                                          setState(() {
                                                                                                                            selectedIndexCover = 0;
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.add(imageList[0]);
                                                                                                                            mediaList.add("");
                                                                                                                          });
                                                                                                                        },
                                                                                                                      ),
                                                                                                                      selectedIndexCover == 0
                                                                                                                          ? Align(
                                                                                                                              alignment: Alignment.center,
                                                                                                                              child: Padding(
                                                                                                                                padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                child: Container(
                                                                                                                                    child: Image.asset(
                                                                                                                                  "assets/profile/student/select_circle.png",
                                                                                                                                  height: 25.0,
                                                                                                                                  width: 25.0,
                                                                                                                                )),
                                                                                                                              ),
                                                                                                                            )
                                                                                                                          : Container(
                                                                                                                              height: 0.0,
                                                                                                                            )
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                  flex: 1,
                                                                                                                ),
                                                                                                                Expanded(
                                                                                                                  child: Stack(
                                                                                                                    children: <Widget>[
                                                                                                                      InkWell(
                                                                                                                        child: Container(
                                                                                                                            height: 65,
                                                                                                                            width: 65,
                                                                                                                            padding: EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                                                                            child: FadeInImage.assetNetwork(
                                                                                                                              fit: BoxFit.fill,
                                                                                                                              width: 65,
                                                                                                                              alignment: Alignment.center,
                                                                                                                              placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                              image: Constant.IMAGE_PATH + imageList[1],
                                                                                                                            )),
                                                                                                                        onTap: () {
                                                                                                                          setState(() {
                                                                                                                            selectedIndexCover = 1;
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.add(imageList[1]);
                                                                                                                            mediaList.add("");
                                                                                                                          });
                                                                                                                        },
                                                                                                                      ),
                                                                                                                      selectedIndexCover == 1
                                                                                                                          ? Align(
                                                                                                                              alignment: Alignment.center,
                                                                                                                              child: Padding(
                                                                                                                                padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                child: Container(
                                                                                                                                    child: Image.asset(
                                                                                                                                  "assets/profile/student/select_circle.png",
                                                                                                                                  height: 25.0,
                                                                                                                                  width: 25.0,
                                                                                                                                )),
                                                                                                                              ),
                                                                                                                            )
                                                                                                                          : Container(
                                                                                                                              height: 0.0,
                                                                                                                            )
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                  flex: 1,
                                                                                                                ),
                                                                                                                Expanded(
                                                                                                                  child: Stack(
                                                                                                                    children: <Widget>[
                                                                                                                      InkWell(
                                                                                                                        child: Container(
                                                                                                                            height: 65,
                                                                                                                            width: 65,
                                                                                                                            padding: EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                                                                            child: FadeInImage.assetNetwork(
                                                                                                                              fit: BoxFit.fill,
                                                                                                                              width: 65,
                                                                                                                              alignment: Alignment.center,
                                                                                                                              placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                              image: Constant.IMAGE_PATH + imageList[2],
                                                                                                                            )),
                                                                                                                        onTap: () {
                                                                                                                          setState(() {
                                                                                                                            selectedIndexCover = 2;
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.add(imageList[2]);
                                                                                                                            mediaList.add("");
                                                                                                                          });
                                                                                                                        },
                                                                                                                      ),
                                                                                                                      selectedIndexCover == 2
                                                                                                                          ? Align(
                                                                                                                              alignment: Alignment.center,
                                                                                                                              child: Padding(
                                                                                                                                padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                child: Container(
                                                                                                                                    child: Image.asset(
                                                                                                                                  "assets/profile/student/select_circle.png",
                                                                                                                                  height: 25.0,
                                                                                                                                  width: 25.0,
                                                                                                                                )),
                                                                                                                              ),
                                                                                                                            )
                                                                                                                          : Container(
                                                                                                                              height: 0.0,
                                                                                                                            )
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                  flex: 1,
                                                                                                                ),
                                                                                                                Expanded(
                                                                                                                  child: Stack(
                                                                                                                    children: <Widget>[
                                                                                                                      InkWell(
                                                                                                                        child: Container(
                                                                                                                            height: 65,
                                                                                                                            width: 65,
                                                                                                                            padding: EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                                                                            child: FadeInImage.assetNetwork(
                                                                                                                              fit: BoxFit.fill,
                                                                                                                              width: 65,
                                                                                                                              alignment: Alignment.center,
                                                                                                                              placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                              image: Constant.IMAGE_PATH + imageList[3],
                                                                                                                            )),
                                                                                                                        onTap: () {
                                                                                                                          setState(() {
                                                                                                                            selectedIndexCover = 3;
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.add(imageList[3]);
                                                                                                                            mediaList.add("");
                                                                                                                          });
                                                                                                                        },
                                                                                                                      ),
                                                                                                                      selectedIndexCover == 3
                                                                                                                          ? Align(
                                                                                                                              alignment: Alignment.center,
                                                                                                                              child: Padding(
                                                                                                                                padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                child: Container(
                                                                                                                                    child: Image.asset(
                                                                                                                                  "assets/profile/student/select_circle.png",
                                                                                                                                  height: 25.0,
                                                                                                                                  width: 25.0,
                                                                                                                                )),
                                                                                                                              ),
                                                                                                                            )
                                                                                                                          : Container(
                                                                                                                              height: 0.0,
                                                                                                                            )
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                  flex: 1,
                                                                                                                ),
                                                                                                                Expanded(
                                                                                                                  child: Stack(
                                                                                                                    children: <Widget>[
                                                                                                                      InkWell(
                                                                                                                        child: Container(
                                                                                                                            height: 65,
                                                                                                                            width: 65,
                                                                                                                            padding: EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                                                                            child: FadeInImage.assetNetwork(
                                                                                                                              fit: BoxFit.fill,
                                                                                                                              width: 65,
                                                                                                                              alignment: Alignment.center,
                                                                                                                              placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                              image: Constant.IMAGE_PATH + imageList[4],
                                                                                                                            )),
                                                                                                                        onTap: () {
                                                                                                                          setState(() {
                                                                                                                            selectedIndexCover = 4;
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.removeLast();
                                                                                                                            mediaList.add(imageList[4]);
                                                                                                                            mediaList.add("");
                                                                                                                          });
                                                                                                                        },
                                                                                                                      ),
                                                                                                                      selectedIndexCover == 4
                                                                                                                          ? Align(
                                                                                                                              alignment: Alignment.center,
                                                                                                                              child: Padding(
                                                                                                                                padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                child: Container(
                                                                                                                                    child: Image.asset(
                                                                                                                                  "assets/profile/student/select_circle.png",
                                                                                                                                  height: 25.0,
                                                                                                                                  width: 25.0,
                                                                                                                                )),
                                                                                                                              ),
                                                                                                                            )
                                                                                                                          : Container(
                                                                                                                              height: 0.0,
                                                                                                                            )
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                  flex: 1,
                                                                                                                )
                                                                                                              ],
                                                                                                            )
                                                                                                          : Container(
                                                                                                              height: 0.0,
                                                                                                            ),
                                                                                                    ),
                                                                                                    PaddingWrap.paddingfromLTRB(
                                                                                                        0.0,
                                                                                                        10.0,
                                                                                                        0.0,
                                                                                                        10.0,
                                                                                                        Text(
                                                                                                          "Videos",
                                                                                                          style: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                        )),
                                                                                                    videoListUi,
                                                                                                    PaddingWrap.paddingfromLTRB(
                                                                                                        0.0,
                                                                                                        20.0,
                                                                                                        0.0,
                                                                                                        10.0,
                                                                                                        Text(
                                                                                                          "Certificates",
                                                                                                          style: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                        )),
                                                                                                    certificateListUI,
                                                                                                    PaddingWrap.paddingfromLTRB(
                                                                                                        0.0,
                                                                                                        20.0,
                                                                                                        0.0,
                                                                                                        10.0,
                                                                                                        Text(
                                                                                                          "Trophies & Badges",
                                                                                                          style: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                        )),
                                                                                                    trophyListUi
                                                                                                  ])
                                                                                                : Container(
                                                                                                    height: 0.0,
                                                                                                  )
                                                                                          ],
                                                                                        ),
                                                                                        flex: 1,
                                                                                      )
                                                                                    ],
                                                                                  ),
                                                                                  onTap: () {
                                                                                    setState(() {
                                                                                      isShowMedia = true;
                                                                                    });
                                                                                  },
                                                                                )),
                                                                          )),
                                                                      UIHelper
                                                                          .verticalGapBetweenBox,
                                                                      externalLinkWidget(),
                                                                      UIHelper
                                                                          .verticalGapBetweenBox,
                                                                      personalReflectionWidget(),
                                                                    ]))),
                                                    Container(
                                                        color:
                                                            Color(0XFFFAFAFA),
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                7.0,
                                                                0.0,
                                                                10.0,
                                                                Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: <
                                                                        Widget>[
                                                                      isPromptfinal
                                                                          ? PaddingWrap.paddingfromLTRB(
                                                                              16.0,
                                                                              0.0,
                                                                              16.0,
                                                                              10.0,
                                                                              Row(
                                                                                children: <Widget>[
                                                                                  PaddingWrap.paddingAll(
                                                                                      0.0,
                                                                                      InkWell(
                                                                                        child: Image.asset(
                                                                                          "assets/newDesignIcon/login/check.png",
                                                                                          width: 25.0,
                                                                                          height: 25.0,
                                                                                        ),
                                                                                        onTap: () {},
                                                                                      )),
                                                                                  Text(
                                                                                    "  Ask for recommendation",
                                                                                    style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                  ),
                                                                                ],
                                                                              ))
                                                                          : PaddingWrap.paddingfromLTRB(
                                                                              16.0,
                                                                              0.0,
                                                                              16.0,
                                                                              10.0,
                                                                              Row(
                                                                                children: <Widget>[
                                                                                  PaddingWrap.paddingAll(
                                                                                      0.0,
                                                                                      PaddingWrap.paddingAll(
                                                                                          0.0,
                                                                                          InkWell(
                                                                                            child: Image.asset(
                                                                                              isPrompt ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                                              width: 25.0,
                                                                                              height: 25.0,
                                                                                            ),
                                                                                            onTap: () {
                                                                                              if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                                                                                                if (isPrompt)
                                                                                                  isPrompt = false;
                                                                                                else
                                                                                                  isPrompt = true;
                                                                                                setState(() {
                                                                                                  isPrompt;
                                                                                                });
                                                                                              } else {
                                                                                                ToastWrap.showToast(MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR, context);
                                                                                              }
                                                                                            },
                                                                                          ))),
                                                                                  Text(
                                                                                    "  Ask for recommendation",
                                                                                    style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                  ),
                                                                                ],
                                                                              )),
                                                                      isPrompt
                                                                          ? Card(
                                                                              elevation: 0.0,
                                                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0.0)),
                                                                              child: Container(
                                                                                  decoration: BoxDecoration(border: Border(bottom: BorderSide(color: ColorValues.LIGHT_GREY_TEXT_COLOR, width: 1.0), top: BorderSide(color: ColorValues.LIGHT_GREY_TEXT_COLOR, width: 1.0))),
                                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                                      16.0,
                                                                                      0.0,
                                                                                      16.0,
                                                                                      0.0,
                                                                                      Column(
                                                                                        children: <Widget>[
                                                                                          recommendationTitle,
                                                                                          recommendationRequest,
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              15.0,
                                                                                              0.0,
                                                                                              0.0,
                                                                                              Container(
                                                                                                  padding: EdgeInsets.all(5.0),
                                                                                                  color: Color(0XFFE9E9E9),
                                                                                                  width: double.infinity,
                                                                                                  child: Text(
                                                                                                    "RECOMMENDER DETAILS",
                                                                                                    style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 12.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                  ))),
                                                                                          recommenderTitle,
                                                                                          coachFirstName,
                                                                                          coachLastName,
                                                                                          coachEmail,
                                                                                        ],
                                                                                      ))))
                                                                          : Container(
                                                                              height: 0.0,
                                                                            )
                                                                    ]))),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        Container(
                                                            width:
                                                                double.infinity,
                                                            child: InkWell(
                                                                child: PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        20.0,
                                                                        16.0,
                                                                        16.0,
                                                                        50.0,
                                                                        InkWell(
                                                                          child: TextViewWrap.textView(
                                                                              "Delete Accomplishment",
                                                                              TextAlign.start,
                                                                              ColorValues.RED,
                                                                              16.0,
                                                                              FontWeight.normal),
                                                                          onTap:
                                                                              () {
                                                                            confromationDialog();
                                                                          },
                                                                        )))),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ],
                                            ))
                                      ],
                                    ))
                                  ],
                                ))),
                      ],
                    )))));
  }

  Future<void> initMediaList() async {

    for (Assest item in achivmentModel.assestList) {
      if (item.type == 'image' && item.tag == 'media') {
        //"image", "media",
        mediaList.add(item.file);
      } else if (item.type == 'video' && item.tag == 'media') {

        mediaVideosList.add(FileModel(null, item.file));
      }
    }
    //mediaList.addAll(achivmentModel.mediaList);
    mediaList.add("");
    mediaVideosList.add(null);
  }

  externalLinkWidget() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          14.0,
          10.0,
          5.0,
          10.0,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                    Image.asset(
                      "assets/story_new/link_url.png",
                      width: 30.0,
                      height: 30.0,
                    )),
                flex: 0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        TextViewWrap.textView(
                            "External Links & Mentions",
                            TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            "Upload press coverage, video montages/highlight reels, documents.",
                            TextAlign.start,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    UIHelper.verticalGapBetweenBox,

                    //////////////////////////////////
                    Container(
                      child: ListView.builder(
                        itemCount: linkUrlListData.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
                            child: Container(

                              margin:
                                  EdgeInsets.only(top: 0, bottom: 0, right: 0),
                              child: Stack(
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 10, 5, 0),
                                    child: Container(
                                      color: ColorValues.SELECTION_GRAY,
                                      margin: EdgeInsets.only(top: 0, right: 0),
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 5, 13, 5),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Expanded(
                                              child: Column(
                                                children: <Widget>[
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      bottom: 0,
                                                      top: 0,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .labelController,

                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              'Title'),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      validator: (val) => linkUrlListData[
                                                                          index]
                                                                      .labelController
                                                                      .text ==
                                                                  "" &&
                                                              linkUrlListData[
                                                                          index]
                                                                      .urlController
                                                                      .text ==
                                                                  ""
                                                          ? null
                                                          : val.trim().isEmpty
                                                              ? MessageConstant
                                                                  .FIELD_REQUIRED
                                                              : null,
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      top: 5,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .urlController,

                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              'URL'),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      validator: (value) {
                                                        return linkUrlListData[
                                                                            index]
                                                                        .labelController
                                                                        .text ==
                                                                    "" &&
                                                                linkUrlListData[
                                                                            index]
                                                                        .urlController
                                                                        .text ==
                                                                    ""
                                                            ? null
                                                            : ValidationChecks
                                                                .validateWebUrlPortFolio(
                                                                    value);
                                                      },
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      bottom: UIHelper
                                                          .screenPadding,
                                                      top: 5,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .descController,

                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              'Description'),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},

                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    right: 0.0,
                                    top: 0.0,
                                    child: InkWell(
                                      child: index > 0
                                          ? Container(
                                              padding: EdgeInsets.all(0),
                                              child: Image.asset(
                                                ImagePath.ICON_CLEAR,
                                                height: 24.18,
                                                width: 17,
                                              ),
                                            )
                                          : Container(
                                              height: 24.18,
                                              width: 17,
                                            ),
                                      onTap: () {
                                        if (linkUrlListData.length > 1) {
                                          print(
                                              'link Index is =======>  $index');
                                          linkUrlListData.removeAt(index);
                                        }
                                        setState(() {});
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    ////////////////////////////
                    InkWell(
                      child: Padding(
                        padding:
                            EdgeInsets.only(top: 5, bottom: 5, right: 12.0),
                        child: Text(
                          '+ Add More Link'.toUpperCase(),
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.accentColor, 14, FontType.Regular),
                        ),
                      ),
                      onTap: () {
                        if (linkUrlListData.length > 0) {
                          if (linkUrlListData[linkUrlListData.length - 1]
                                      .urlController
                                      .text !=
                                  "" &&
                              linkUrlListData[linkUrlListData.length - 1]
                                      .labelController
                                      .text !=
                                  "") {
                            setState(() {
                              linkUrlListData.add(LinkUrlModel(
                                  labelController: TextEditingController(),
                                  urlController: TextEditingController(),
                                  descController: TextEditingController()));
                            });
                          }
                        } else {
                          setState(() {
                            linkUrlListData.add(LinkUrlModel(
                                labelController: TextEditingController(),
                                urlController: TextEditingController(),
                                descController: TextEditingController()));
                          });
                        }
                      },
                    ),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  personalReflectionWidget() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          17.0,
          0.0,
          5.0,
          20.0,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                    Image.asset(
                      "assets/newDesignIcon/ad_new/personal_rel.png",
                      width: 25.0,
                      height: 25.0,
                    )),
                flex: 0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        6.0,
                        TextViewWrap.textView(
                            "Personal Reflection",
                            TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            "Add some notes/reminders for yourself that you want to remember.",
                            TextAlign.start,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    //UIHelper.verticalGapBetweenBox,
                    personalReflectionUi(),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLineItalic(
                            "Note: Personal reflection is a note to self and will not be shared with anyone.",
                            TextAlign.start,
                            ColorValues.ORANGE_TEXT_COLOR,
                            10.0,
                            FontWeight.normal,
                            4)),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  personalReflectionUi() {
    return Container(
        padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: personalReflectionController,
          maxLength: TextLength.PERSONAL_DESC_MAX_LENGTH,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:
              BaseCommonWidget.textFormFieldDecorationAchievment("", ''),

          onSaved: (val) => strpersonalReflection = val.trim(),
        ));
  }
}
