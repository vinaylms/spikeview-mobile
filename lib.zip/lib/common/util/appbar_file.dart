import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/new_onboarding/onboarding_education_added_list.dart';
import 'package:spike_view_project/profile/UpdateUserProfile.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class AppBarWidgets {
  getAppBar(
    String title,
    String ScreenName,
    BuildContext mContext,
    ProfileInfoModal mProfileInfoModal,
  {VoidCallback onBackTap,}
  ) {
    return PaddingWrap.paddingfromLTRB(
        20.0,
        50.0,
        20.0,
        0.0,
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              child: SizedBox(
                height: 32.0,
                width: 32.0,
                child: Center(
                    child: Image.asset(
                        "assets/new_onboarding/back_blue_icon.png",
                        height: 32.0,
                        width: 32.0,
                        fit: BoxFit.fitHeight)),
              ),
              onTap: onBackTap ?? () {
                if (title == "add") {
                  Navigator.of(mContext).popUntil((route) => route.isFirst);

                  if (ScreenName == "profile") {
                    Navigator.of(mContext).pushReplacement(
                        new MaterialPageRoute(
                            builder: (BuildContext mContext) =>
                                EducationAddedWeight(
                                  mProfileInfoModal: mProfileInfoModal,
                                  screenName: "profile",
                                )));
                  } else {
                    Navigator.pushReplacement(
                        mContext,
                        MaterialPageRoute(
                            builder: (context) =>
                                UpdateUserProfile(mProfileInfoModal, '')));
                  }
                } else {
                  Navigator.of(mContext).pushReplacement(new MaterialPageRoute(
                      builder: (BuildContext mContext) => EducationAddedWeight(
                            mProfileInfoModal: mProfileInfoModal,
                            screenName: "onBoarding",
                          )));
                }
              },
            ),
            const HelpButtonWidget(),
          ],
        ));
  }
}
