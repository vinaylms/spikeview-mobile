class BusinessCategoryResponse {
  String status;
  List<CategoryResult> result;

  BusinessCategoryResponse({this.status, this.result});

  BusinessCategoryResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<CategoryResult>();
      json['result'].forEach((v) {
        result.add(new CategoryResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
class CategoryResult {
  int businessCategoryId;
  String name;
  String description;

  CategoryResult({this.businessCategoryId, this.name, this.description});

  CategoryResult.fromJson(Map<String, dynamic> json) {
    businessCategoryId = json['businessCategoryId'];
    name = json['name'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['businessCategoryId'] = this.businessCategoryId;
    data['name'] = this.name;
    data['description'] = this.description;
    return data;
  }
}
