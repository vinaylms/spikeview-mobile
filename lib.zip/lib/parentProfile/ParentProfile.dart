import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:spike_view_project/ChatReafctor/view/chat_friend_list_with_header.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/db/chat_model.dart';
import 'package:spike_view_project/group/group_list_share_flow.dart';
import 'package:spike_view_project/home/AddPost.dart';
import 'package:spike_view_project/parentProfile/wizard/newpages/StudentDataUpdate.dart';
import 'package:spike_view_project/parentProfile/wizard/newpages/onboarding_child_interest_widget.dart';
import 'package:spike_view_project/patnerFlow/opportunity/opportunity_selection.dart';
import 'package:dio/dio.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:spike_view_project/profile/ParentProfileImage.dart';
import 'package:spike_view_project/profile/student_profile_view.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:intl/intl.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:keyboard_avoider/keyboard_avoider.dart';
import 'package:package_info/package_info.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/OpportunitySearch.dart';
import 'package:spike_view_project/drawer/SearchFriend_NewDesign.dart';
import 'package:spike_view_project/education/EducationListWidget.dart';
import 'package:spike_view_project/education/model/UniversityModel.dart';
import 'package:spike_view_project/home_page/blocs/home_bloc.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/notification/NotificationWidget.dart';
import 'package:spike_view_project/parentProfile/AddParent.dart';
import 'package:spike_view_project/parentProfile/AddStudent.dart';
import 'package:spike_view_project/parentProfile/AllParent.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parentProfile/SampleProfile.dart';
import 'package:spike_view_project/parentProfile/StudentProfileControls.dart';
import 'package:spike_view_project/parentProfile/activityLog/DetailPageList.dart';
import 'package:spike_view_project/parentProfile/wizard/AddAccomplishment_Widget.dart';
import 'package:spike_view_project/parentProfile/wizard/AddProfileImage.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/parentProfile/wizard/AllAccomplishmentListWidget.dart';
import 'package:spike_view_project/parentProfile/wizard/CompetenciesParentStudent.dart';
import 'package:spike_view_project/parentProfile/wizard/CompletedWizard.dart';
import 'package:spike_view_project/parentProfile/wizard/CongratulationMobileParent.dart';
import 'package:spike_view_project/parentProfile/wizard/ProfilePic_Widget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/InviteNonSpikeViewMember.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/profile/EditProfileImageWidget.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/profile/ProfileSharingLog.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardFromParent.dart';
import 'package:spike_view_project/profile/studentWizard/AddProfileImage.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class ParentProfilePage extends StatefulWidget {
  static String tag = 'login-page';
  GlobalKey<ScaffoldState> _scaffoldKey;
  int notificationCount = 0;
  ProfileInfoModal profileInfoModal;

  ParentProfilePage(this._scaffoldKey, this.notificationCount,
      {this.profileInfoModal});
  @override
  ParentProfilePageState createState() =>
      ParentProfilePageState(notificationCount);
}

class ParentProfilePageState extends State<ParentProfilePage>
    with AutomaticKeepAliveClientMixin, WidgetsBindingObserver {
  int notificationCount = 0;

  List<UniversityResult> _universityList = List();

  ParentProfilePageState(this.notificationCount);

  Color borderColor = Colors.amber;
  bool isRememberMe = false;

  //bool isMore = false;
  bool isDataRember = false;
  File imagePath, imagePathCover;
  String strNetworkImage = "";
  String userIdPref, skip_value, token, emailId;
  TextEditingController passwordCtrl, emailCtrl;
  ProfileInfoModal profileInfoModal;
  List<StudentDataModel> listStudent = List();
  List<ProfileEducationModal> userEducationList = List<ProfileEducationModal>();
  List<NarrativeModel> narrativeList = List<NarrativeModel>();
  List<Recomdation> recommendationtList = List<Recomdation>();
  SharedPreferences prefs;
  PackageInfo packageInfo;
  bool isNarativeShow = false;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String sasToken, containerName;
  String strPrefixPathforCoverPhoto,
      strPrefixPathforProfilePhoto,
      strAzureCoverImageUploadPath = "",
      strAzureProfileImageUploadPath = "";
  String strSummary;
  String strAccCount = "", strRecCount = "";
  bool isActive = false;
  StreamSubscription<dynamic> _streamSubscription;
  StreamSubscription<dynamic> _streamSubscriptionWizard;
  ScrollController _scrollController = ScrollController();
  static StreamController syncDoneController = StreamController.broadcast();
  bool isTitleVisible = false;
  bool _isAppbar = true;
  final _formKey = GlobalKey<FormState>();
  TextEditingController fromDateController;
  String strFirstName = "", strLastName = "", strEmail = "";
  String badge = '';
  String badgeImage = '';
  int gamificationPoints = 0;
  bool isLoading = true;
  static String isAchivmentAdded = "false";
  static String isEducationAdded = "false";

  String isParentGender = "";
  String strParentZip = "";
  TextEditingController parentZipController = TextEditingController(text: "");
  DateTime pickedDate;
  int strDateOfBirth = 0;
  int diffrenceInDob = 14;
  TextEditingController dobController;
  bool isValid = true;
  bool isUserLoginFirstTime = false;
  final FocusNode zipCodeFocus = FocusNode();
  DateTime startDate;

  String strCountryName = "";
  bool isStudentCountrySelected = true;
  CountryList _mCountryItem;
  CountryListModel _mCountryListModel;
  List<CountryList> countryList = List();
  final searchCountryController = TextEditingController();
  List<Item> countries = List();
  Item selectedCityItem;
  bool isShowStudentCitySelectionError = true;
  bool showList = false;
  bool isGenderSelected = true;

  onAddStudent(userId, profilePicture) async {
    prefs.setString(UserPreference.PARENT_WIZARD_USERID, userId);

    await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => CongratulationMobileParent(
            StudentDataModel(
                userId,
                strFirstName,
                strLastName,
                strEmail.toLowerCase(),
                "",
                profilePicture,
                "1",
                "false",
                "",
                "",
                "",
                "",
                "",
                "",
                strDateOfBirth.toString(),
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                null,
                null,
                "false",
                "false",
                "false",
                null,
                "false",
                "0",
                true,
                false,
                badge,
                gamificationPoints,
                badgeImage))));
    studentByParentApi(true);
  }

  //--------------------------Api Calling ------------------
  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;
        Address address2;
        try {
          /*    String formatedAddres = await Util.getDetailUsingZipCode(
              false, context, parentZipController.text);
          address2 =
              ParseJson.addressParse(formatedAddres, parentZipController.text);
          print("addres" + formatedAddres);
          print("data" + address2.zip);
          print("data" + address2.city);
          print("data" + address2.state);
          print("data" + address2.country);*/

          Response response1 = await Util.getDetailUsingZipCodeNew(
              false, context, parentZipController.text);

          final data = response1.data['results'][0]["address_components"];

          String city = "", state = "", country = "";
          if (data.length > 3) {
            city = data[1]['long_name'];
            state = data[3]['long_name'];
            country = data[4]['long_name'];
          } else if (data.length > 0) {
            //city=json[1]['long_name'];
            state = data[1]['long_name'];
            country = data[2]['long_name'];
          }

          address2 = new Address("", "", city, state, country, "", "");
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
        }

        Map map = {
          "userId": int.parse(userIdPref),
          "firstName": profileInfoModal.firstName,
          "lastName": profileInfoModal.lastName,
          "students": [
            {
              "firstName": strFirstName,
              "lastName": strLastName,
              "email": strEmail.toLowerCase(),
              "dob": strDateOfBirth,
              "zipCode": parentZipController.text,
              "gender":
                  isParentGender == "Non-Binary" ? "NonBinary" : isParentGender,
              "state": selectedCityItem != null
                  ? selectedCityItem.state
                  : address2 != null
                      ? address2.state.trim()
                      : "",
              "city": selectedCityItem != null
                  ? selectedCityItem.city
                  : address2 != null
                      ? address2.city.trim()
                      : "",
              "country": _mCountryItem == null ? "" : _mCountryItem.name,
            }
          ],
          "roleId": 2,
          "isActive": true,
          "address": {
            "street1": "",
            "street2": "",
            "city": "",
            "state": "",
            "country": "",
            "zip": ""
          }
        };
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_PARENT_PERSONAL_INFO, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              String userIdNew =
                  response.data["result"]['studentId'].toString();
              String profilePicture =
                  response.data["result"]['profilePicture'].toString();
              print("userId----" + userIdNew);
              //anaylytics.setCurrentSreen(ScreenNameConstant.parent_add_student);
              onAddStudent(userIdNew, profilePicture);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //----------------------------------------- api calling and data parse ----------------------------
//--------------------------Api Calling for delete achevement ------------------
  Future apiCallingForDeleteStudenet(studentId) async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "studentId": int.parse(studentId),
        "parentId": int.parse(userIdPref),
      };

      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_DELETE_STUDENT, map);
      CustomProgressLoader.cancelLoader(context);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            //ToastWrap.showToast(msg);
            studentByParentApi(true);
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    try {
      DateTime dateFormat = DateTime.now();
      if (isShowLaoder) CustomProgressLoader.showLoader(context);

      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_PERSONAL_INFO_NEW + userIdPref + "/false/" + "2/0",
          "get");
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("profileApi() response parent++++++" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          DateTime dateFormat1 = DateTime.now();
          print(dateFormat1);
          final final_time = dateFormat1.difference(dateFormat).inSeconds;

          if (final_time > Constant.PARENT_PROFILE_RESPONSE_MAX_TIME) {
            API.ApiForUpdateReportStatus(
                context,
                "get",
                Constant.ENDPOINT_PERSONAL_INFO_NEW,
                "userId=" + userIdPref + "&roleId=2",
                final_time.toString());
          }

          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            profileInfoModal =
                ParseJson.parseMapUserProfile(response.data['result']);
            if (profileInfoModal.isActive == "true") {
              isActive = true;
            }

            if (profileInfoModal != null) {
              prefs.setString(
                  UserPreference.CREATION_TIME, profileInfoModal.creationTime);
              prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
              print("isHide+++" + prefs.getString(UserPreference.ISHide));

              strNetworkImage = profileInfoModal.profilePicture;
              prefs.setString(UserPreference.ZIPCODE, profileInfoModal.zipCode);
              prefs.setString(UserPreference.NAME,
                  profileInfoModal.firstName + " " + profileInfoModal.lastName);

              print("Apurva UserPreference.NAME::::" +
                  prefs.getString(UserPreference.NAME));

              prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                  profileInfoModal.profilePicture);
              syncDoneController.add("sucess");

              if (profileInfoModal.dob != null &&
                  profileInfoModal.dob != "null") {
                startDate = DateTime.fromMillisecondsSinceEpoch(
                    int.parse(profileInfoModal.dob));
              }
              setState(() {
                strNetworkImage;
                profileInfoModal;
              });
            }
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("data+++" + e.toString());
      e.toString();
    }
  }

  //--------------------------Students BY Parent api ------------------
  void printWrapped(String text) {
    final pattern = RegExp('.{1,800}'); // 800 is the size of each chunk
    pattern.allMatches(text).forEach((match) => print(match.group(0)));
  }

  Future studentByParentApi(isShowLaoder) async {
    try {
      if (mounted) {
        setState(() {
          isLoading = true;
        });
      }
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      listStudent.clear();
      print("parent=====" + "requested");
      Response response = await ApiCalling2().apiCall(context,
          Constant.ENDPOINT_PARENT_STUDENTSBYPARENT + userIdPref, "get");
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
      log("parent=====" + response.toString());

      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            listStudent =
                ParseJson.parseMapStudentByParent(response.data['result']);
            if (listStudent != null) {
              if (mounted) {
                setState(() {
                  listStudent;
                });
              }
            }
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      print("issue shubh" + e.toString());
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future<String> callCollegeListApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_universities_list, "get");
        print("ENDPOINT_universities_list Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              UniversityModel _universityModel =
                  UniversityModel.fromJson(response.data);
              try {
                _universityList = _universityModel.result;
                if (_universityList != null && _universityList.isNotEmpty) {
                  saveDataForUniversity();
                }
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "ParentProfile", context);
                print(
                    'inside ENDPOINT_universities_list catch error:: ${e.toString()}');
              }
              //}
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      e.toString();
    }
  }

  void saveDataForUniversity() {
    // encode data save into sharedpreference
    prefs.remove(UserPreference.UNIVERSITY_LIST);
    final String encodedData = UniversityResult.encode(_universityList);
    prefs.setString(UserPreference.UNIVERSITY_LIST, encodedData);
  }

  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      if (sasToken != "" && containerName != "") {
        final String result = await platform.invokeMethod('getBatteryLevel', {
          "sasToken": sasToken,
          "imagePath": imagePath,
          "uploadPath": Constant.IMAGE_PATH + prefixPath
        });

        print("image_path" + result);
        return result;
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      return "";
    }
  }

  //--------------------------Upload Cover Image Data ------------------
  Future uploadCoverIMage(type) async {
    try {
      Response response;
      if (type == "cover") {
        Map map = {
          "coverImage":
              strPrefixPathforCoverPhoto + strAzureCoverImageUploadPath,
          "userId": userIdPref
        };
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_USER_COVER_PHOTO_UPDATE, map);
      } else {
        Map map = {
          "profilePicture":
              strPrefixPathforProfilePhoto + strAzureProfileImageUploadPath,
          "userId": userIdPref
        };

        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_USER_COVER_PHOTO_UPDATE, map);
        studentByParentApi(true);
      }
      CustomProgressLoader.cancelLoader(context);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            //  ToastWrap.showSucessMsg(msg,context);
            if (type != "cover") {
              prefs.setString(
                  UserPreference.PROFILE_IMAGE_PATH,
                  strPrefixPathforProfilePhoto +
                      strAzureProfileImageUploadPath);
            }
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      e.toString();
    }
  }

  showSucessMsg(msg, context, duration, maxLine) {
    Timer _timer;

    print("timer on");
    _timer = Timer(Duration(milliseconds: duration), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: maxLine == 2 ? 65.0 : 85.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: maxLine,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  //--------------------------Api Calling for update user Status ------------------
  Future apiCallingForUpdateStudentStatus(userId, isActive, flag) async {
    try {
      Response response;

      Map map = {
        "userId": userId,
        "isActive": isActive,
        "parentApprovalFlag": flag,
        "parentId": int.parse(userIdPref)
      };

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_PARENT_PERSONAL_UPDATEUSER_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setString(UserPreference.PATH_PARENT, "");
            if (flag) {
              showSucessMsg(msg, context, 2000, 3);
            } else {
              showSucessMsg(msg, context, 3000, 2);
            }
            prefs.setString(UserPreference.PATH_PARENT, "");
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      e.toString();
    }
  }

  Future apiCallingForUpdateStudentHideStatus(userId, isHide) async {
    try {
      Response response;

      Map map = {
        "userId": userId,
        "isHide": isHide,
        "parentId": int.parse(userIdPref)
      };

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_PARENT_PERSONAL_UPDATEUSER_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            showSucessMsg(msg, context, 3000, 2);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      e.toString();
    }
  }

//***************************************************************************************************************
  void showDialogForRefrerNow() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 18, right: 0, left: 0, bottom: 0),
                            child: Padding(
                                padding: const EdgeInsets.all(13.0),
                                child: Stack(
                                  children: <Widget>[
                                    Padding(
                                        padding: const EdgeInsets.only(
                                          top: 15,
                                          right: 13,
                                          left: 13,
                                        ),
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: ColorValues.DARK_GREY),
                                          ),
                                          child: Column(
                                            children: <Widget>[
                                              Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        30, 13, 30, 18),
                                                child: Text(
                                                  "Invite Friends",
                                                  style: TextStyle(
                                                      color: Color(0xFF000000),
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMBOLD,
                                                      fontSize: 20),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Image.asset(
                                                "assets/newDesignIcon/connections/refernow.png",
                                                height: 160.0,
                                              ),
                                              Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        15, 15, 15, 18),
                                                child: Text(
                                                  "Invite your friends and build your global parent network.",
                                                  style: TextStyle(
                                                      color: Color(0xFF000000),
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontSize: 16),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                              Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 15.0, 0.0, 15.0),
                                                  child: InkWell(
                                                    child: Container(
                                                        color: ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        height: 31,
                                                        width: 100.0,
                                                        child: Padding(
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    5.0,
                                                                    0.0,
                                                                    5.0,
                                                                    0.0),
                                                            child: Center(
                                                              child: Text(
                                                                "INVITE",
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                style: TextStyle(
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR,
                                                                    fontSize:
                                                                        14.0,
                                                                    color: Colors
                                                                        .white),
                                                              ),
                                                            ))),
                                                    onTap: () {
                                                      String referCode =
                                                          prefs.getString(
                                                              UserPreference
                                                                  .referCode);
                                                      Util.shareAppLinkViaOtherApp(
                                                          context,
                                                          referCode,
                                                          prefs.getString(
                                                              UserPreference
                                                                  .NAME));
                                                    },
                                                  ))
                                            ],
                                          ),
                                        )),
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0.0, 25, 18, 0),
                                      child: InkWell(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: <Widget>[
                                            Image.asset(
                                              "assets/cancel_c.png",
                                              width: 30.0,
                                              height: 30.0,
                                            ),
                                          ],
                                        ),
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                    )
                                  ],
                                )),
                          ),
                        ),
                      ],
                    )))));
  }

  Future getVersion() async {
    try {
      print("------------SPIKE BOAT");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (Platform.isAndroid) {
          print("------------getVersion" +
              Constant.ENDPOINT_APP_VERSION +
              "?version=" +
              packageInfo.version.toString() +
              "&appType=android");
        } else {
          print("------------getVersion" +
              Constant.ENDPOINT_APP_VERSION +
              "?version=" +
              packageInfo.version.toString() +
              "&appType=ios");
        }
        Response response = await ApiCalling2().apiCall3(
            context,
            Platform.isAndroid
                ? Constant.ENDPOINT_APP_VERSION +
                    "?version=" +
                    packageInfo.version.toString() +
                    "&appType=android"
                : Constant.ENDPOINT_APP_VERSION +
                    "?version=" +
                    packageInfo.version.toString() +
                    "&appType=ios",
            "get");
        print("------------getVersion" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              double versionForAbndroid;
              double versionForIos;

              String isIosRestrict = "false";
              String isAndroidRestrict = "false";

              try {
                versionForAbndroid = double.parse(
                    response.data['result']['androidVersion'].toString());
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "ParentProfile", context);
              }

              try {
                versionForIos = double.parse(
                    response.data['result']['iosVersion'].toString());
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "ParentProfile", context);
              }

              try {
                isIosRestrict =
                    response.data['result']['isIosRestrict'].toString();
                isAndroidRestrict =
                    response.data['result']['isAndroidRestrict'].toString();
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "ParentProfile", context);
              }

              String upgradeMessage =
                  response.data['result']['upgradeMessage'].toString();

              print("------------getVersionANdroid" +
                  versionForAbndroid.toString());
              print("------------getVersionIOS" + versionForIos.toString());
              print("------------getVersion" + packageInfo.version.toString());
              print("------------getVersionios" + isIosRestrict);
              print("------------getVersionAndroid" + isAndroidRestrict);
              print("------------getVersion" +
                  response.data['result']['isRestrict'].toString());
              if (Platform.isAndroid) {
                if (double.parse(packageInfo.version) < versionForAbndroid) {
                  print("------------getVersion true" + packageInfo.version);

                  if (mounted) {
                    syncDoneController.add("dialogVisible");
                    Util.showUpdateDialog(
                        context,
                        isAndroidRestrict == "true" ? true : false,
                        upgradeMessage);
                  }
                }
              } else {
                if (double.parse(packageInfo.version) < versionForIos) {
                  if (mounted) {
                    syncDoneController.add("dialogVisible");
                    Util.showUpdateDialog(context,
                        isIosRestrict == "true" ? true : false, upgradeMessage);
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      print("error++++++++++++" + e.toString());
      e.toString();
    }
  }

  String linkData;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    emailId = prefs.getString(UserPreference.EMAIL);
    token = prefs.getString(UserPreference.USER_TOKEN);
    try {
      skip_value = prefs.getString(UserPreference.chat_skip_count);
      if (skip_value == null || skip_value == "") {
        skip_value = "0";
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      skip_value = "0";
    }
    packageInfo = await PackageInfo.fromPlatform();
    try {
      linkData = prefs.getString(UserPreference.LINK);
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      linkData = "";
    }
    isUserLoginFirstTime =
        prefs.getBool(UserPreference.IS_USER_LOGIN_FIRST_TIME);
    print("=====linkurl Dataa=====");
    String linkurl = prefs.getString(UserPreference.PATH_PARENT);

    if (linkurl == null) {
      linkurl = "";
    }

    print("=====linkurl=====" + linkurl);
    if (linkurl == "" || linkurl == " ") {
    } else {
      List<String> pathSplitList = linkurl.split("/");
      String studentId = "";
      studentId = pathSplitList[pathSplitList.length - 2];
      print("=====linkurl=====" + studentId);
      if (studentId != null && studentId != "null") {
        await apiCallingForUpdateStudentStatus(studentId, true, true);
      }
    }

    homeBloc.fetcPost(userIdPref, "2", context);
    bloc.fetchConnection(userIdPref, context, prefs, true);
    bloc.fetchGroup(userIdPref, context, prefs, true);

    int skip = int.parse(skip_value);
    DbHelper().deleteChatTable();
    for (var i = 0; i <= skip; i++) {
      bloc.fetchChatList(userIdPref, context, prefs, true, i.toString());
    }

    await getVersion();

    if (!isDialogVisible) {
      // CustomProgressLoader.showLoader(context);
    }
    var isConnect = await ConectionDetecter.isConnected();
    //if (widget.profileInfoModal == null) {
    if (isConnect) {
      print("api++++profile");
      profileApi(true);
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
    //}
    if (isConnect) {
      print("api++++studentByParentApi");
      studentByParentApi(true);
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
    if (!isDialogVisible) {
      //  CustomProgressLoader.cancelLoader(context);
    }
    if (isConnect) {
      print("api++++callApiForSaas");
      callApiForSaas();
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }

    //newly added for university list
    if (isConnect) {
      print("api++++callCollegeListApi");
      callCollegeListApi();
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }

    print(
        "userLoginFirstTime profile+++++++" + isUserLoginFirstTime.toString());
    // if ((!isUserLoginFirstTime) && profileInfoModal.referralPopup) {m

    if (profileInfoModal != null &&
        profileInfoModal.stage != null &&
        profileInfoModal.stage == "0") {
      // if (profileInfoModal.stage == "0") {
      stage1();
      //}
    } else {
      if (profileInfoModal != null && profileInfoModal.referralPopup) {
        showDialogForRefrerNow();
      }
    }

    prefs.setBool(UserPreference.IS_USER_LOGIN_FIRST_TIME, false);

    strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_COVER +
        "/";

    strPrefixPathforProfilePhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_PROFILE +
        "/";
    try {
      print("linkData++++" + linkData.toString());
      if (linkData != null && linkData != "") {
        prefs.setString(UserPreference.LINK, "");
        shareUrlOption(linkData);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
    }
  }

  void shareUrlOption(link) {
    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 24.0,
                            child: Container(
                                height:
                                    prefs.getString(UserPreference.ROLE_ID) ==
                                            "4"
                                        ? 248.0
                                        : 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          "Chat",
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                        )),
                                                    onTap: () {
                                                      if (prefs.getString(
                                                              UserPreference
                                                                  .ISACTIVE) ==
                                                          "true") {
                                                        Navigator.pop(Constant
                                                            .applicationContext);
                                                        Navigator.of(Constant
                                                                .applicationContext)
                                                            .push(
                                                                MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        ChatFriendListWithHeader(
                                                                          link,
                                                                          "",
                                                                          userIdPref,
                                                                          pageName:
                                                                              "notification",
                                                                          roleId:
                                                                              "2",
                                                                        )));
                                                      } else {
                                                        Navigator.pop(Constant
                                                            .applicationContext);
                                                        ToastWrap.showToast(
                                                            MessageConstant
                                                                .PENDING_PROFILE_ACTIVATION,
                                                            Constant
                                                                .applicationContext);
                                                      }
                                                    },
                                                  ),
                                                  Column(
                                                    children: <Widget>[
                                                      Container(
                                                        color: ColorValues
                                                            .BORDER_COLOR,
                                                        height: 1.0,
                                                      ),
                                                      InkWell(
                                                        child: Container(
                                                            height: 50.0,
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    0.0,
                                                                    13.0,
                                                                    0.0,
                                                                    13.0),
                                                            child: Text(
                                                              "Feed",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 1,
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            )),
                                                        onTap: () async {
                                                          if (prefs.getString(
                                                                  UserPreference
                                                                      .ISACTIVE) ==
                                                              "true") {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            Navigator.of(Constant
                                                                    .applicationContext)
                                                                .push(
                                                                    MaterialPageRoute(
                                                                        builder: (BuildContext
                                                                                context) =>
                                                                            AddPost(
                                                                              profileInfoModal,
                                                                              "",
                                                                              groupDetailModel: null,
                                                                              link: link,
                                                                            )));
                                                          } else {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            ToastWrap.showToast(
                                                                MessageConstant
                                                                    .PENDING_PROFILE_ACTIVATION,
                                                                Constant
                                                                    .applicationContext);
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  Column(
                                                    children: <Widget>[
                                                      Container(
                                                        color: ColorValues
                                                            .BORDER_COLOR,
                                                        height: 1.0,
                                                      ),
                                                      InkWell(
                                                        child: Container(
                                                            height: 50.0,
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    0.0,
                                                                    13.0,
                                                                    0.0,
                                                                    13.0),
                                                            child: Text(
                                                              "Group",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 1,
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            )),
                                                        onTap: () async {
                                                          if (prefs.getString(
                                                                  UserPreference
                                                                      .ISACTIVE) ==
                                                              "true") {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            Navigator.of(Constant
                                                                    .applicationContext)
                                                                .push(new MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        GroupListShareFlow(
                                                                            profileInfoModal,
                                                                            link)));
                                                          } else {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            ToastWrap.showToast(
                                                                MessageConstant
                                                                    .PENDING_PROFILE_ACTIVATION,
                                                                Constant
                                                                    .applicationContext);
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  prefs.getString(UserPreference
                                                              .ROLE_ID) ==
                                                          "4"
                                                      ? Column(
                                                          children: <Widget>[
                                                            Container(
                                                              color: ColorValues
                                                                  .BORDER_COLOR,
                                                              height: 1.0,
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                  height: 50.0,
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          13.0,
                                                                          0.0,
                                                                          13.0),
                                                                  child: Text(
                                                                    "Opportunity",
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 1,
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR,
                                                                        height:
                                                                            1.2,
                                                                        fontSize:
                                                                            16.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                              onTap: () async {
                                                                Navigator.pop(
                                                                    Constant
                                                                        .applicationContext);
                                                                /* Navigator.of(
                                                              Constant
                                                                  .applicationContext)
                                                              .push(new MaterialPageRoute(
                                                              builder: (BuildContext context) =>  OpportunitySelection(
                                                                  companyModel,
                                                                  link:
                                                                  link)));*/
                                                                //}
                                                              },
                                                            ),
                                                          ],
                                                        )
                                                      : Container(height: 0.0),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(
                                                  Constant.applicationContext);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

//*********************************************************************************************
  onTapAddStudent(page) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            AddStudent("Student profile", profileInfoModal, page)));

    if (result == "push") {
      //  anaylytics.setCurrentSreen(ScreenNameConstant.parent_add_student);

      studentByParentApi(true);
    }
  }

  onBoardingStart(StudentDataModel studModel) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            StudentDataUpdate("Student profile", studModel)));

    if (result == "push") {
      //  anaylytics.setCurrentSreen(ScreenNameConstant.parent_add_student);

      studentByParentApi(true);
    }
  }

  void appBarStatus(bool status) {
    setState(() {
      _isAppbar = status;
    });
  }

  stage1() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            ParentProfileImage(sasToken, "parentPage")));
    await profileApi(true);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print('state partner profile+++++++++ = $state');

    if (mounted) {
      Constant.applicationContext = context1;
    }
  }

  BuildContext context1;
  bool isDialogVisible = false;

  Future getCountry() async {
    print('inside getPreLoginData() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2()
            .apiCallWithouAuth(context, Constant.ENDPOINT_GET_COUNTRY, "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mCountryListModel = CountryListModel.fromJson(response.data);
              setState(() {
                _mCountryListModel;
                countryList.addAll(_mCountryListModel.countryList);
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentProfile", context);
      e.toString();
    }
  }

  initCountryList(text, sortname) async {
    countries.clear();
    countries = await API.fetchCountryListForSignup(text, 'cities', sortname);
    if (countries.length > 0) {
      setState(() {});
    }
  }

  @override
  void initState() {
    print("changes");
    WidgetsBinding.instance.addObserver(this);
    this.context1 = context;
    dobController = TextEditingController(text: '');
    if (widget.profileInfoModal != null) {
      profileInfoModal = widget.profileInfoModal;
      print("profileInfoModal++++not null+");

      setState(() {});
    }

    searchCountryController.addListener(() {
      if (searchCountryController.text.isEmpty) {
        setState(() {
          countries.clear();
        });
      } else {
        if (searchCountryController.text.trim().length >= 1) {
          initCountryList(
              searchCountryController.text.trim(), _mCountryItem.sortname);
        }
      }
    });

    _scrollController.addListener(() {
      if (_scrollController.offset < 150.0) {
        if (isTitleVisible) {
          setState(() {
            isTitleVisible = false;
          });
        }
      } else {
        if (!isTitleVisible) {
          setState(() {
            isTitleVisible = true;
          });
        }
      }

      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (_isAppbar) {
          setState(() {
            _isAppbar = false;
          });
        }
      }
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (!_isAppbar) {
          setState(() {
            _isAppbar = true;
          });
        }
      }
    });
    getCountry();
    getSharedPreferences();

    //-------------listener for refresh profile info -------------------------
    _streamSubscription =
        DashBoardStateParent.syncDoneController.stream.listen((value) {
      print("api called profile");
      if (value == "success") {
        apiUpdated(value);
      } else if (value == "dialogVisible") {
        isDialogVisible = true;
      } else {
        notificationCount = int.parse(value);
        setState(() {
          notificationCount;
        });
      }
    });

    _streamSubscriptionWizard =
        CompetenciesStudentState.syncDoneController.stream.listen((value) {
      print("api called student" + value);
      if (value == "add") {
        onTapAddStudent("wizard");
      } else {
        studentByParentApi(true);
      }
    });
    _streamSubscriptionWizard = SelectingChildIterestWidgetState
        .syncDoneController.stream
        .listen((value) {
      print("api called student" + value);
      if (value == "profile") {
        /*    onTapAddStudent("wizard");
          } else {*/
        studentByParentApi(true);
      }
    });
    _streamSubscriptionWizard =
        AddAchievmentFormStateNEW.syncDoneController.stream.listen((value) {
      studentByParentApi(true);
    });
    _streamSubscriptionWizard =
        AllAccomplishmentListState.syncDoneController.stream.listen((value) {
      studentByParentApi(true);
    });

    _streamSubscription =
        ProfilePicState.syncDoneController.stream.listen((value) {
      print("api called profile");
      if (value == "refresh") {
        studentByParentApi(true);
      } else {}
    });
    super.initState();
  }

  void apiUpdated(String result) async {
    profileApi(true);
  }

  Future<Null> _cropImage(File imageFile, name) async {
    if (name == "imagepath") {
      print("imagepath printed");
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    } else {
      print("imagepathcover printed");
      imagePathCover = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    Constant.pageNameFr = "parentRole";
    super.build(context);

    onTapChildEditProfile(index) async {
      print("set user Id pref" + listStudent[index].userId);
      prefs.setString(UserPreference.USER_ID, listStudent[index].userId);

      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => EditUserProfile(
                "",
                userName: listStudent[index].firstName,
                userId: listStudent[index].userId,
                roleId: '1',
                pageName: 'parentPage',
              )));
      print("set parent Id pref" + userIdPref);
      prefs.setString(UserPreference.USER_ID, userIdPref);

      if (result == "push") {
        studentByParentApi(true);
      }
    }

    onTapSetting(index) async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              StudentProfilControl(listStudent[index])));

      if (result == "push") {
        studentByParentApi(true);
      }
    }

    InkWell isImageSelectedView() {
      return InkWell(
        child: Container(
          width: 65.0,
          height: 65.0,
          child: Stack(
            children: <Widget>[
              Center(
                  child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: ColorValues.DARK_YELLOW,
                          width: 5.0,
                        ),
            boxShadow: [
              BoxShadow(
                spreadRadius: 3,
                blurRadius: 3,
                offset: Offset(0, 2),
                color: Color.fromRGBO(98, 175, 226,0.09),
              )
            ],
                        borderRadius: BorderRadius.circular(20),
                      ),
                      width: 65.0,
                      height: 65.0,
                      child: profileInfoModal != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: FadeInImage.assetNetwork(
                                fit: BoxFit.cover,
                                placeholder: 'assets/profile/user_on_user.png',
                                image: profileInfoModal != null
                                    ? Constant.IMAGE_PATH_SMALL +
                                        ParseJson.getMediumImage(
                                            profileInfoModal.profilePicture)
                                    : "",
                              ),
                            )
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Image.asset(
                                  "assets/profile/user_on_user.png")))),
              /* Align(
                  alignment: Alignment.bottomRight,
                  child:  Container(
                    padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                    child:  Image.asset("assets/newDesignIcon/edit_img.png"),
                    height: 30.0,
                    width: 30.0,
                  ))*/
            ],
          ),
        ),
        onTap: () {
          //  onTapEditProfile();
        },
      );
    }

    Widget headerUiDesign() {
      return Container(
          margin: EdgeInsets.only(top: 20, left: 20, right: 20, bottom: 15),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0, 10.0, 13.0, 10.0, isImageSelectedView()),
                flex: 0,
              ),
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    5.0,
                    0.0,
                    0.0,
                    8.0,
                    Container(
                        child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingAll(
                            2.0,
                            BaseText(
                              text: profileInfoModal == null
                                  ? ""
                                  : profileInfoModal.lastName == "" ||
                                          profileInfoModal.lastName == "null"
                                      ? profileInfoModal.firstName != null
                                          ? profileInfoModal.firstName
                                          : ""
                                      : profileInfoModal.firstName +
                                          " " +
                                          profileInfoModal.lastName,
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w500,
                              fontSize: 22,
                              textAlign: TextAlign.start,
                              maxLines: 2,
                            )),
                      ],
                    ))),
                flex: 1,
              )
            ],
          ));
    }

    onTapAddParent(index) async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => AddParent(
              "Add  Parent",
              listStudent[index].userId,
              profileInfoModal.firstName != null ||
                      profileInfoModal.firstName != "null"
                  ? profileInfoModal.lastName != null ||
                          profileInfoModal.lastName != "null"
                      ? profileInfoModal.firstName +
                          " " +
                          profileInfoModal.lastName
                      : profileInfoModal.firstName
                  : "")));
      if (result == "push") {
        studentByParentApi(true);
      }
    }

    onTapStudentItem(index) async {
      print("set user Id pref" + listStudent[index].userId);
      // prefs.setString(UserPreference.USER_ID, listStudent[index].userId);
      /* await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
               UserProfileDashBoardFromParent(listStudent[index].userId)));*/

      await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => StudentProfileView(
          isActive: listStudent[index].isActive == "true",
          roleId: listStudent[index].roleId,
          userId: listStudent[index].userId,
        ),
      ));
      print("set parent Id pref" + userIdPref);
      prefs.setString(UserPreference.USER_ID, userIdPref);
      prefs.setString(
          UserPreference.PROFILE_IMAGE_PATH, profileInfoModal.profilePicture);
      studentByParentApi(true);
    }

    void childRemoveConfromation(studentId, studentName) {

      showModalBottomSheet(
          context: context,
          backgroundColor: Colors.transparent,
          isDismissible: false,
          builder: (_)
          {
            return ConfirmationDialog(
              msg: 'Are you sure you want to remove this student?',
              negativeText: 'Cancel',
              positiveText: 'Remove',
              isSucessPopup: false,
              positiveTextColor:AppConstants.colorStyle.lightBlue,
              onNegativeTap: () {
              },
              onPositiveTap: (){
                apiCallingForDeleteStudenet(
                    studentId);
              },
            );
          });



    }

    onTapAuthorizedParent(index) async {
      String result = await Navigator.of(context).push(
        new MaterialPageRoute(
          builder: (BuildContext context) => AllParentList(
              listStudent[index].parentList,
              profileInfoModal,
              listStudent[index].userId),
        ),
      );

      if (result == "push") {
        studentByParentApi(true);
      }
    }

    void optionMenu(index) {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
          onWillPop: () {
            Navigator.pop(context);
          },
          child: SafeArea(
            child: Scaffold(
              backgroundColor: Colors.black38,
              body: Stack(
                children: <Widget>[
                  Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Container(
                          height: 362.0,
                          color: Colors.transparent,
                          child: Stack(
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  ListView(children: <Widget>[
                                    Container(
                                      width: double.infinity,
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(10.0),
                                            topRight:
                                                const Radius.circular(10.0),
                                            bottomRight:
                                                const Radius.circular(10.0),
                                            bottomLeft:
                                                const Radius.circular(10.0),
                                          )),
                                      child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: <Widget>[
                                            InkWell(
                                              child: Container(
                                                  height: 50.0,
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 0.0, 0.0, 0.0),
                                                  child: Center(
                                                    child: Text(
                                                      "Edit details",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoMedium),
                                                    ),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onTapChildEditProfile(index);
                                              },
                                            ),
                                            Container(
                                              color: ColorValues.BORDER_COLOR,
                                              height: 1.0,
                                            ),
                                            InkWell(
                                              child: Container(
                                                  height: 50.0,
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 0.0, 0.0, 0.0),
                                                  child: Center(
                                                    child: Text(
                                                      "Settings",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoMedium),
                                                    ),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onTapSetting(index);
                                              },
                                            ),
                                            Container(
                                              color: ColorValues.BORDER_COLOR,
                                              height: 1.0,
                                            ),
                                            InkWell(
                                              child: Container(
                                                  height: 50.0,
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 0.0, 0.0, 0.0),
                                                  child: Center(
                                                    child: Text(
                                                      "Add Parent",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoMedium),
                                                    ),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onTapAddParent(index);
                                              },
                                            ),
                                            Container(
                                              color: ColorValues.BORDER_COLOR,
                                              height: 1.0,
                                            ),
                                            InkWell(
                                              child: Container(
                                                  height: 50.0,
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 0.0, 0.0, 0.0),
                                                  child: Center(
                                                    child: Text(
                                                      "Authorized parent(s)",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoMedium),
                                                    ),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onTapAuthorizedParent(index);
                                              },
                                            ),
                                            Container(
                                              color: ColorValues.BORDER_COLOR,
                                              height: 1.0,
                                            ),
                                            InkWell(
                                              child: Container(
                                                  height: 50.0,
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 0.0, 0.0, 0.0),
                                                  child: Center(
                                                    child: Text(
                                                      "Profile Sharing",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoMedium),
                                                    ),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                Navigator.of(context).push(
                                                    new MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                            ProfileSharingLog(
                                                                listStudent[
                                                                        index]
                                                                    .userId)));
                                              },
                                            ),
                                            Container(
                                              color: ColorValues.BORDER_COLOR,
                                              height: 1.0,
                                            ),
                                            InkWell(
                                              child: Container(
                                                  height: 50.0,
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 0.0, 0.0, 0.0),
                                                  child: Center(
                                                    child: Text(
                                                      "Delete",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoMedium),
                                                    ),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                childRemoveConfromation(
                                                    listStudent[index].userId,
                                                    listStudent[index]
                                                                .lastName !=
                                                            "null"
                                                        ? listStudent[index]
                                                                .firstName +
                                                            " " +
                                                            listStudent[index]
                                                                .lastName
                                                        : listStudent[index]
                                                            .firstName);
                                              },
                                            ),
                                          ]),
                                    )
                                  ])),
                            ],
                          ))),
                  Positioned(
                    right: 0.0,
                    left: 0.0,
                    bottom: 10.0,
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: PaddingWrap.paddingfromLTRB(
                          13.0,
                          0.0,
                          13.0,
                          0.0,
                          InkWell(
                            child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.only(
                                      topLeft: const Radius.circular(10.0),
                                      topRight: const Radius.circular(10.0),
                                      bottomRight: const Radius.circular(10.0),
                                      bottomLeft: const Radius.circular(10.0),
                                    )),
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Container(
                                          child: Text(
                                        "Cancel",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w500,
                                            fontFamily: Constant.latoMedium),
                                      )),
                                      flex: 1,
                                    ),
                                  ],
                                )),
                            onTap: () {
                              Navigator.pop(context);
                            },
                          )),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    Padding getStudentsUi() {
      return Padding(
        padding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        child: Column(
          children: List.generate(
            listStudent.length,
            (int index) {
              return PaddingWrap.paddingfromLTRB(
                  0.0,
                  10.0,
                  0.0,
                  0.0,
                  Container(
                      decoration: BoxDecoration(
                        color: ColorValues.LIST_BOTTOM_BG,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        children: <Widget>[
                          Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Expanded(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      11.0,
                                      0.0,
                                      0.0,
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              12.0,
                                              0.0,
                                              10.0,
                                              5.0,
                                              Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: InkWell(
                                                      child: ClipRRect(
                                                          borderRadius:
                                                          BorderRadius
                                                              .circular(
                                                              15),
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                            fit: BoxFit.cover,
                                                            width: 48.0,
                                                            height: 48.0,
                                                            placeholder:
                                                            'assets/profile/user_on_user.png',
                                                            image: Constant
                                                                .IMAGE_PATH_SMALL +
                                                                ParseJson.getMediumImage(
                                                                    listStudent[
                                                                    index]
                                                                        .profilePicture),
                                                          )),
                                                      onTap: () {},
                                                    ),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                      child: Column(
                                                        crossAxisAlignment:
                                                        listStudent[index].tagline ==
                                                            "null"
                                                            ? CrossAxisAlignment
                                                            .center:CrossAxisAlignment
                                                            .start,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .start,
                                                        children: <Widget>[
                                                          Row(
                                                            children: <
                                                                Widget>[
                                                              PaddingWrap
                                                                  .paddingfromLTRB(
                                                                10.0,
                                                                0.0,
                                                                0.0,
                                                                5.0,
                                                                BaseText(
                                                                  text: listStudent[index].lastName ==
                                                                      "null"
                                                                      ? listStudent[index]
                                                                      .firstName
                                                                      : listStudent[index].firstName +
                                                                      " " +
                                                                      listStudent[index].lastName,
                                                                  textColor:
                                                                  ColorValues
                                                                      .HEADING_COLOR_EDUCATION_1
                                                                  /* : ColorValues
                                                                            .HEADING_COLOR_EDUCATION_1
                                                                            .withOpacity(0.4)*/
                                                                  ,
                                                                  fontFamily: AppConstants
                                                                      .stringConstant
                                                                      .latoMedium,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                                  fontSize:
                                                                  16,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .start,
                                                                  maxLines: 1,
                                                                ),
                                                              ),
                                                              Util.getStudentBadge12(
                                                                  listStudent[
                                                                  index]
                                                                      .badge,
                                                                  listStudent[
                                                                  index]
                                                                      .badgeImage)
                                                            ],
                                                          ),
                                                          listStudent[index].tagline ==
                                                              "null"
                                                              ?SizedBox():    PaddingWrap
                                                              .paddingfromLTRB(
                                                              10.0,
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              PaddingWrap
                                                                  .paddingAll(
                                                                2.0,
                                                                BaseText(
                                                                  text: listStudent[index].tagline ==
                                                                      "null"
                                                                      ? ""
                                                                      : listStudent[index].tagline,
                                                                  textColor:
                                                                  ColorValues.labelColor,
                                                                  fontFamily: AppConstants
                                                                      .stringConstant
                                                                      .latoRegular,
                                                                  fontWeight:
                                                                  FontWeight.w400,
                                                                  fontSize:
                                                                  14,
                                                                  textAlign:
                                                                  TextAlign.center,
                                                                  maxLines:
                                                                  1,
                                                                ),
                                                              )),
                                                        ],
                                                      ),
                                                      flex: 1),
                                                  Expanded(
                                                    child:   InkWell(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          10.0,
                                                          listStudent[index]
                                                              .isMore
                                                              ? Image
                                                              .asset(
                                                            "assets/newDesignIcon/icon/view_less.png",
                                                            width:
                                                            20.0,
                                                            height:
                                                            20.0,
                                                          )
                                                              : Image
                                                              .asset(
                                                            "assets/newDesignIcon/icon/view_more.png",
                                                            width:
                                                            20.0,
                                                            height:
                                                            20.0,
                                                          )),
                                                      onTap: () {
                                                        setState(() {
                                                          if (listStudent[
                                                          index]
                                                              .isMore) {
                                                            listStudent[
                                                            index]
                                                                .isMore = false;
                                                            //isMore = false;
                                                          } else {
                                                            listStudent[
                                                            index]
                                                                .isMore = true;
                                                            //isMore = true;
                                                          }
                                                        });
                                                      },
                                                    ),
                                                    flex: 0,
                                                  )
                                                ],
                                              )),
                                          int.parse(listStudent[index]
                                              .stage) <
                                              5
                                              ? PaddingWrap.paddingfromLTRB(
                                              14.0,
                                              5.0,
                                              0.0,
                                              11.0,
                                              Row(
                                                crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .center,
                                                mainAxisAlignment:
                                                MainAxisAlignment
                                                    .start,
                                                children: <Widget>[
                                                  Expanded(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          Row(
                                                            children: <
                                                                Widget>[
                                                              Image
                                                                  .asset(
                                                                "assets/newDesignIcon/icon/wrning_icon.png",
                                                                width:
                                                                24.0,
                                                                height:
                                                                24.0,
                                                              ),
                                                              SizedBox(width: 5,),
                                                              TextViewWrap.textView(
                                                                  "Profile is incomplete",
                                                                  TextAlign.start,
                                                                  Color(0xff27275A),
                                                                  14.0,
                                                                  FontWeight.w600)
                                                            ],
                                                          )),
                                                      flex: 1),
                                                  Expanded(
                                                    child: InkWell(
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(right:12.0),
                                                        child: Container(
                                                            width: 114.0,
                                                            height: 34.0,
                                                            decoration:
                                                            BoxDecoration(
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR,
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  10),
                                                            ),
                                                            child: PaddingWrap
                                                                .paddingAll(
                                                              0.0,
                                                              Row(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                                mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                                children: <
                                                                    Widget>[
                                                                  BaseText(
                                                                    text:
                                                                    'Complete now',
                                                                    textColor:
                                                                    ColorValues.WHITE,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                    fontWeight:
                                                                    FontWeight.w600,
                                                                    fontSize:
                                                                    14,
                                                                    textAlign:
                                                                    TextAlign.center,
                                                                    maxLines:
                                                                    1,
                                                                  ),
                                                                ],
                                                              ),
                                                            )),
                                                      ),
                                                      onTap: () {
                                                        isAchivmentAdded =
                                                            listStudent[
                                                            index]
                                                                .isAchievement;

                                                        isEducationAdded =
                                                            listStudent[
                                                            index]
                                                                .isEducation;
                                                        prefs.setString(
                                                            UserPreference
                                                                .PARENT_WIZARD_USERID,
                                                            listStudent[
                                                            index]
                                                                .userId);
                                                        /*   Navigator.of(
                                                                    context)
                                                                .push(new MaterialPageRoute(
                                                                    builder:
                                                                        (BuildContext context) =>
                                                                             CongratulationMobileParent(listStudent[index])));*/

                                                        onBoardingStart(
                                                            listStudent[
                                                            index]);
                                                      },
                                                    ),
                                                    flex: 0,
                                                  ),
                                                ],
                                              ))
                                              : Container(
                                            height: 0.0,
                                          )
                                        ],
                                      )),
                                ),
                              ]),
                          listStudent[index].isMore
                              ? int.parse(listStudent[index].stage) < 5
                              ? Container(
                            height: 0.0,
                          )
                              : Container(
                            padding: EdgeInsets.only(top: 6),
                            decoration: BoxDecoration(
                                color: ColorValues.SELECTION_BG,
                                borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(8),
                                    bottomRight:
                                    Radius.circular(8))),
                            child: Column(
                              children: [
                                Column(
                                  children: List.generate(
                                    listStudent[index]
                                        .activityLogList
                                        .length,
                                        (position) {
                                      return InkWell(
                                        child: Container(
                                            margin: EdgeInsets.only(
                                                left: 12,
                                                right: 12,
                                                top: 6,
                                                bottom: 6),
                                            height: 38,
                                            decoration: BoxDecoration(
                                                color: ColorValues
                                                    .WHITE,
                                                borderRadius:
                                                BorderRadius
                                                    .circular(
                                                    10)),
                                            child: Row(
                                                mainAxisAlignment:
                                                MainAxisAlignment
                                                    .spaceBetween,
                                                children: <Widget>[
                                                  Container(
                                                    margin: EdgeInsets
                                                        .only(
                                                        left:
                                                        12),
                                                    child: Text(
                                                      listStudent[
                                                      index]
                                                          .activityLogList[
                                                      position]
                                                          .title,
                                                      style: TextStyle(
                                                          fontSize:
                                                          14.0,
                                                          fontWeight:
                                                          FontWeight
                                                              .w400,
                                                          fontFamily:
                                                          Constant
                                                              .latoMedium,
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets
                                                        .only(
                                                        right:
                                                        12),
                                                    child: Text(
                                                      listStudent[index]
                                                          .activityLogList[
                                                      position]
                                                          .count ==
                                                          "null"
                                                          ? "0"
                                                          : listStudent[index].activityLogList[position].count ==
                                                          "0"
                                                          ? "0"
                                                          : listStudent[index].activityLogList[position].count.length == 1
                                                          ? "0" + listStudent[index].activityLogList[position].count
                                                          : listStudent[index].activityLogList[position].count,
                                                      style: TextStyle(
                                                          fontSize:
                                                          16.0,
                                                          fontWeight:
                                                          FontWeight
                                                              .w700,
                                                          fontFamily:
                                                          Constant
                                                              .latoMedium,
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1),
                                                    ),
                                                  ),
                                                ])),
                                        onTap: () {
                                          if (listStudent[index]
                                              .activityLogList[
                                          position]
                                              .count !=
                                              "null") {
                                            if (int.parse(listStudent[
                                            index]
                                                .activityLogList[
                                            position]
                                                .count) >
                                                0)
                                              Navigator.of(context).push(new MaterialPageRoute(
                                                  builder: (BuildContext
                                                  context) =>
                                                      DetailPageListWidget(
                                                          listStudent[
                                                          index]
                                                              .activityLogList[
                                                          position]
                                                              .title,
                                                          listStudent[
                                                          index]
                                                              .userId)));
                                          }
                                        },
                                      );
                                    },
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Container(
                                          height: 42,
                                          alignment:
                                          Alignment.center,
                                          decoration: BoxDecoration(
                                            color: ColorValues
                                                .SELECTION_BG,
                                            border: Border.all(
                                              color: ColorValues
                                                  .BORDER_COLOR_NEW,
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                            BorderRadius.only(
                                                bottomLeft: Radius
                                                    .circular(
                                                    10),
                                                bottomRight:
                                                Radius
                                                    .circular(
                                                    0)),
                                          ),
                                          child: InkWell(
                                            onTap: () {
                                              onTapStudentItem(
                                                  index);
                                            },
                                            child: BaseText(
                                              text: 'View profile',
                                              textColor: ColorValues
                                                  .HEADING_COLOR_EDUCATION_2,
                                              fontFamily:
                                              AppConstants
                                                  .stringConstant
                                                  .latoMedium,
                                              fontWeight:
                                              FontWeight.w600,
                                              fontSize: 16,
                                              textAlign:
                                              TextAlign.center,
                                              maxLines: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Container(
                                          alignment:
                                          Alignment.center,
                                          height: 42,
                                          decoration: BoxDecoration(
                                            color: ColorValues
                                                .SELECTION_BG,
                                            border: Border.all(
                                              color: ColorValues
                                                  .BORDER_COLOR_NEW,
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                            BorderRadius.only(
                                                bottomLeft: Radius
                                                    .circular(
                                                    0),
                                                bottomRight:
                                                Radius
                                                    .circular(
                                                    10)),
                                          ),
                                          child: InkWell(
                                            onTap: () {
                                              optionMenu(index);
                                            },
                                            child: BaseText(
                                              text:
                                              'View more options',
                                              textColor: ColorValues
                                                  .HEADING_COLOR_EDUCATION_2,
                                              fontFamily:
                                              AppConstants
                                                  .stringConstant
                                                  .latoMedium,
                                              fontWeight:
                                              FontWeight.w600,
                                              fontSize: 16,
                                              textAlign:
                                              TextAlign.center,
                                              maxLines: 1,
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          )
                              : SizedBox(),
                        ],
                      )));
            },
          ),
        ),
      );
    }

    Future<Null> _refreshPageHere() async {
      //CustomProgressLoader.showLoader(context);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        await profileApi(false);
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }

      if (isConnect) {
        await studentByParentApi(false);
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    }

    return SafeArea(
      child: Stack(
        children: <Widget>[
          Positioned(
              left: 0.0,
              right: 0.0,
              top: 0.0,
              bottom: 0.0,
              child: Scaffold(
                appBar: CustomViews.getAppBar(
                    '', widget._scaffoldKey, context, prefs, notificationCount),
                backgroundColor: ColorValues.WHITE,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        left: 0.0,
                        right: 0.0,
                        top: 0.0,
                        bottom: 0.0,
                        child: FormKeyboardActions(
                            nextFocus: false,
                            keyboardActionsPlatform:
                                KeyboardActionsPlatform.IOS,
                            //optional
                            keyboardBarColor: Colors.grey[200],
                            //optional
                            actions: [
                              KeyboardAction(
                                focusNode: zipCodeFocus,
                              ),
                            ],
                            child: RefreshIndicator(
                                onRefresh: _refreshPageHere,
                                displacement: 0.0,
                                child: SingleChildScrollView(
                                  controller: _scrollController,
                                  child: Column(
                                    children: <Widget>[

                                      headerUiDesign(),
                                      Form(
                                          key: _formKey,
                                          child: Column(
                                            children: <Widget>[
                                              isLoading
                                                  ? Container(
                                                      height: 0.0,
                                                    )
                                                  : listStudent.length > 0
                                                      ? Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            PaddingWrap
                                                                .paddingfromLTRB(
                                                                    20.0,
                                                                    10.0,
                                                                    20.0,
                                                                    3.0,
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      children: [
                                                                        Container(
                                                                          child:
                                                                              BaseText(
                                                                            text:
                                                                                'My student dashboard',
                                                                            textColor:
                                                                                ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                            fontFamily:
                                                                                AppConstants.stringConstant.latoMedium,
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                            fontSize:
                                                                                18,
                                                                            textAlign:
                                                                                TextAlign.start,
                                                                            maxLines:
                                                                                1,
                                                                          ),
                                                                        ),
                                                                        InkWell(
                                                                          onTap:
                                                                              () {
                                                                            onTapAddStudent("parent");
                                                                          },
                                                                          child:
                                                                              Container(
                                                                            margin:
                                                                                EdgeInsets.only(right: 5),
                                                                            child:
                                                                                Image.asset(
                                                                              'assets/newDesignIcon/icon/plus_icon.png',
                                                                              height: 19,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    )),







                                                            getStudentsUi()
                                                          ],
                                                        )
                                                      : Padding(
                                                        padding: const EdgeInsets.only(top:100.0),
                                                        child: Center(
                                                            child: Align(
                                                              alignment: Alignment
                                                                  .center,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: <
                                                                    Widget>[
                                                                  Image.asset(
                                                                    "assets/newDesignIcon/icon/no_student_found.png",
                                                                    height: 114,
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets
                                                                        .only(
                                                                            top:
                                                                                24),
                                                                    child: Column(
                                                                      children: [
                                                                        BaseText(
                                                                          text:
                                                                              'No student available',
                                                                          textColor:
                                                                              ColorValues.HEADING_COLOR_CHAT_1,
                                                                          fontFamily: AppConstants
                                                                              .stringConstant
                                                                              .latoRegular,
                                                                          fontWeight:
                                                                              FontWeight.w600,
                                                                          fontSize:
                                                                              18,
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                          maxLines:
                                                                              1,
                                                                        ),
                                                                        SizedBox(
                                                                            height:
                                                                                6),
                                                                        BaseText(
                                                                          text:
                                                                              'Please add student to view student dashboard',
                                                                          textColor: AppConstants
                                                                              .colorStyle
                                                                              .lightGrey,
                                                                          fontFamily: AppConstants
                                                                              .stringConstant
                                                                              .latoRegular,
                                                                          fontWeight:
                                                                              FontWeight.w400,
                                                                          fontSize:
                                                                              14,
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                          maxLines:
                                                                              2,
                                                                        ),
                                                                        SizedBox(
                                                                            height:
                                                                                12),
                                                                        InkWell(
                                                                          child: Container(
                                                                              width: 132.0,
                                                                              height: 44.0,
                                                                              decoration: BoxDecoration(
                                                                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                                borderRadius: BorderRadius.circular(12),
                                                                              ),
                                                                              child: PaddingWrap.paddingAll(
                                                                                0.0,
                                                                                Row(
                                                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                                  children: <Widget>[
                                                                                    BaseText(
                                                                                      text: 'Add Student',
                                                                                      textColor: ColorValues.WHITE,
                                                                                      fontFamily: AppConstants.stringConstant.latoMedium,
                                                                                      fontWeight: FontWeight.w600,
                                                                                      fontSize: 18,
                                                                                      textAlign: TextAlign.center,
                                                                                      maxLines: 1,
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              )),
                                                                          onTap:
                                                                              () {
                                                                            onTapAddStudent(
                                                                                "parent");
                                                                          },
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                      ),
                                            ],
                                          ))
                                    ],
                                  ),
                                )))),
                    /* Positioned(
                        left: 0.0,
                        right: 0.0,
                        top: 0.0,
                        child: AnimatedContainer(
                          height: _isAppbar ? 55.0 : 0.0,
                          duration: Duration(milliseconds: 200),
                          child: getView(),
                        )),*/
                    Positioned(
                      top: 0.0,
                      left: 0.0,
                      right: 0.0,
                      bottom: 0.0,
                      child: profileInfoModal != null &&
                              profileInfoModal.stage == "0"
                          ? Container(
                              height: double.infinity,
                              width: double.infinity,
                              color: Colors.transparent,
                            )
                          : Container(
                              height: 0.0,
                            ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
