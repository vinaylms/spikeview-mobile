import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/FullImageViewForPortFolio.dart';
import 'package:spike_view_project/common/Util.dart';

import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';

import 'package:spike_view_project/modal/NarrativeModel.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

class VideoPlayPauseNew extends StatefulWidget {
  final String path;
  bool isShowControll = true;
  String feedId;
  ScrollController _scrollController;

  VideoPlayPauseNew(
      this.path, this.feedId, this.isShowControll, this._scrollController);

  @override
  State createState() {
    return _VideoPlayPauseState();
  }
}

class _VideoPlayPauseState extends State<VideoPlayPauseNew> {
  FadeAnimation imageFadeAnim =
      FadeAnimation(child: Icon(Icons.play_arrow, size: 100.0));
  VoidCallback listener;
  bool isApiNeedToCall = true;

  VideoPlayerController controller;
  ChewieController _chewieController;

  _VideoPlayPauseState() {
    listener = () {
      final bool isPlaying = controller.value.isPlaying;


      if (controller.value.isPlaying) {
        isApiNeedToCall = false;
      } else {
        isApiNeedToCall = true;
//apiCallingForIncreaseCount(widget.feedId);
      }
    };
  }

  // ChewieController _chewieController;

  @override
  void initState() {
    super.initState();
    if (widget.isShowControll == null) {
      widget.isShowControll = true;
    }
    controller = VideoPlayerController.network(
        Constant.PATH_FOR_VIDEO + widget.path.replaceAll(" ", "%20"));
    controller.addListener(listener);
    controller.setVolume(1.0);
    controller.pause();
    controller.initialize();
    //controller.seekTo(Duration(seconds: 5));

    widget._scrollController.addListener(() {
      if (controller != null) {
        controller.pause();
      }
    });
  }

  @override
  void deactivate() {
    controller.setVolume(0.0);

    controller.removeListener(listener);
    controller.dispose();
    // _chewieController.dispose();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    final List<Widget> children = <Widget>[
      GestureDetector(
        child: Container(
            child: Stack(
          children: <Widget>[
            Center(
              child: controller.value.initialized
                  ? Chewie(
                      controller: ChewieController(
                        videoPlayerController: controller,
                        autoPlay: false,
                        allowFullScreen: false,
                        aspectRatio: controller.value.aspectRatio,
                        looping: false,
                        showControls: widget.isShowControll,
                        placeholder: Container(
                          color: Colors.black,
                        ),
                      ),
                    )
                  : Center(
                      child: Container(
                      child: widget.feedId == "FromMediaDetailPage"
                          ? CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation(Colors.white),
                            )
                          : CircularProgressIndicator(),
                    )),
            ),
          ],
        )),
        onTap: () {
          if (!controller.value.initialized) {
            return;
          }
          if (controller.value.isPlaying) {
            imageFadeAnim =
                FadeAnimation(child: Icon(Icons.pause, size: 100.0));
            controller.pause();
          } else {
            imageFadeAnim =
                FadeAnimation(child: Icon(Icons.play_arrow, size: 100.0));
            controller.play();
          }
        },
      ),
      Center(child: imageFadeAnim),
    ];

    return Stack(
      alignment: Alignment.bottomCenter,
      fit: StackFit.passthrough,
      children: children,
    );
  }
}

class FadeAnimation extends StatefulWidget {
  final Widget child;
  final Duration duration;

  FadeAnimation({this.child, this.duration: const Duration(milliseconds: 500)});

  @override
  _FadeAnimationState createState() => _FadeAnimationState();
}

class _FadeAnimationState extends State<FadeAnimation>
    with SingleTickerProviderStateMixin {
  AnimationController animationController;

  @override
  void initState() {
    super.initState();
    animationController =
        AnimationController(duration: widget.duration, vsync: this);
    animationController.addListener(() {
      if (mounted) {
        setState(() {});
      }
    });
    animationController.forward(from: 0.0);
  }

  @override
  void deactivate() {
    animationController.stop();
    super.deactivate();
  }

  @override
  void didUpdateWidget(FadeAnimation oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.child != widget.child) {
      animationController.forward(from: 0.0);
    }
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return animationController.isAnimating
        ? Opacity(
            opacity: 1.0 - animationController.value,
            child: widget.child,
          )
        : Container();
  }
}

typedef Widget VideoWidgetBuilder(
    BuildContext context, VideoPlayerController controller);

/// A widget connecting its life cycle to a [VideoPlayerController].
class PlayerLifeCycle extends StatefulWidget {
  final VideoWidgetBuilder childBuilder;
  final String uri;

  PlayerLifeCycle(this.uri, this.childBuilder);

  @override
  _PlayerLifeCycleState createState() => _PlayerLifeCycleState();
}

class _PlayerLifeCycleState extends State<PlayerLifeCycle> {
  VideoPlayerController controller;

  _PlayerLifeCycleState();

  @override
  void initState() {
    super.initState();
    controller =
        VideoPlayerController.network(widget.uri.replaceAll(" ", "%20"));
    controller.addListener(() {
      if (controller.value.isBuffering) {
        print(controller.value.errorDescription);
      }
    });

    controller.initialize();
    controller.setLooping(false);
    controller.pause();
  }

  @override
  void deactivate() {
    super.deactivate();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.childBuilder(context, controller);
  }
}

// Create a Form Widget
class PortfolioViewWidget extends StatefulWidget {
  Achivment _mAchivment;
  String levelName;
  String pageName;

  PortfolioViewWidget(this._mAchivment, this.levelName, {this.pageName});

  @override
  PortfolioViewWidgetState createState() {
    return PortfolioViewWidgetState(_mAchivment);
  }
}

class PortfolioViewWidgetState extends State<PortfolioViewWidget> {
  Achivment _mAchivment;

  PortfolioViewWidgetState(this._mAchivment);

  bool isShowTeam = false;
  ScrollController _scrollController = ScrollController();
  List<TeamData> mteamDataList = List();

  @override
  void initState() {
    for (Team _mTeam in _mAchivment.teamList) {
      
      if (_mTeam.teamDataList.length > 0) {
        mteamDataList.addAll(_mTeam.teamDataList);
        isShowTeam = true;
      }
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    String getStringHeightWeight(var height, var weight) {
      print("stringheight++++");
      String localString = '';
      if (height != null && height.trim() != '' && height != 'null') {
        localString = "Height: " + height;
        if (weight != null && weight != '' && weight != 'null') {
          return localString =
              localString + " | Weight: " + weight + ' Pounds ';
        }
      } else if (weight != null && weight != '' && weight != 'null') {
        return localString = "Weight: " + weight + ' Pounds ';
      }
      return localString;
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: GestureDetector(
            onTap: () {
              // FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                appBar: AppBar(
                  brightness: Brightness.light,
                  automaticallyImplyLeading: false,
                  titleSpacing: 0.0,
                  elevation: 0.0,
                  title: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        width: 50.0,
                      ),
                      Expanded(
                        child: Image.asset(
                          "assets/newDesignIcon/navigation/spike_logo_login.png",
                          height: 35.0,
                        ),
                        flex: 1,
                      )
                    ],
                  ),
                  actions: <Widget>[
                    InkWell(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset(
                          "assets/cancel_circle.png",
                          color: ColorValues.HEADING_COLOR_EDUCATION,
                          height: 25.0,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    )
                  ],
                  backgroundColor: Colors.white,
                ),
                body: Stack(
                  children: [
                    Positioned(
                        left: 0,
                        top: 0,
                        bottom: 0,
                        right: 0,
                        child: Image.asset(
                          widget.levelName == "Arts"
                              ? "assets/portfolio/arts_bg.png"
                              : "assets/portfolio/sport_bg.png",
                          fit: BoxFit.fill,
                        )),
                    Positioned(
                        top: 25.0,
                        left: 0.0,
                        child: Container(
                          child: CachedNetworkImage(
                            imageUrl:
                                Constant.IMAGE_PATH + _mAchivment.level2Icon,
                            fit: BoxFit.cover,
                            color: widget.levelName == "Arts"
                                ? Color(0xff291739).withOpacity(0.4)
                                : Color(0xff0C1329).withOpacity(0.5),
                            placeholder: (context, url) =>
                                _loader(context, "assets/portfolio/"),
                            errorWidget: (context, url, error) =>
                                _error("assets/portfolio/"),
                          ),
                          width: 260.0,
                          height: 260.0,
                        )),
                    Positioned(
                        left: 0,
                        top: 0,
                        bottom: 0,
                        right: 0,
                        child: Container(
                          color: Colors.transparent,
                          child: ListView(
                            shrinkWrap: true,
                            controller: _scrollController,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(0.0, 15, 0, 0),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Text(_mAchivment.title,
                                            style: TextStyle(
                                                fontSize: 20.0,
                                                color: ColorValues.ORANGE_COLOR,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMBOLD)),
                                        Text(
                                            _mAchivment.city +
                                                ", " +
                                                _mAchivment.state,
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                color: Colors.white,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMBOLD))
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          10.0, 0, 10, 0),
                                      child: Container(
                                        child: ClipOval(
                                            child: CachedNetworkImage(
                                          imageUrl: Constant.IMAGE_PATH +
                                              _mAchivment.userImage,
                                          fit: BoxFit.cover,
                                          placeholder: (context, url) =>
                                              _loader(context,
                                                  "assets/portfolio/dammy.png"),
                                          errorWidget: (context, url, error) =>
                                              _error(
                                                  "assets/portfolio/dammy.png"),
                                        )),
                                        width: 85.0,
                                        height: 85.0,
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      10.0, 30, 15, 5),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      widget.levelName == "Arts"
                                          ? Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Text("BIO",
                                                    style: TextStyle(
                                                        fontSize: 15.0,
                                                        color: ColorValues
                                                            .ORANGE_COLOR,
                                                        letterSpacing: 5.0,
                                                        wordSpacing: 0.0,
                                                        fontFamily:
                                                            "customAcme")),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          3.0, 5, 0, 30),
                                                  child: Text(
                                                      _mAchivment.description,
                                                      style: TextStyle(
                                                          fontSize: 14.0,
                                                          color: Colors.white,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR)),
                                                ),
                                              ],
                                            )
                                          : Container(
                                              height: 0.0,
                                            ),
                                      _mAchivment.personalStatement == null ||
                                              _mAchivment.personalStatement ==
                                                  ""
                                          ? Container(
                                              height: 0.0,
                                            )
                                          : Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Text(
                                                    widget.levelName == "Arts"
                                                        ? "ARTIST STATEMENT"
                                                        : "PERSONAL STATEMENT",
                                                    style: TextStyle(
                                                        fontSize: 15.0,
                                                        color: ColorValues
                                                            .ORANGE_COLOR,
                                                        letterSpacing: 5.0,
                                                        wordSpacing: 0.0,
                                                        fontFamily:
                                                            "customAcme")),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          3.0, 5, 0, 0),
                                                  child: Text(
                                                      _mAchivment
                                                          .personalStatement,
                                                      style: TextStyle(
                                                          fontSize: 14.0,
                                                          color: Colors.white,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR)),
                                                ),
                                              ],
                                            ),
                                      widget.levelName == "Arts"
                                          ? Container(
                                              height: 0.0,
                                            )
                                          :(_mAchivment.age == null ||
                                          _mAchivment.age ==
                                              'null' ||
                                          _mAchivment.age.trim()  == '')&&(_mAchivment.sheight == null ||
                                          _mAchivment.sheight ==
                                              'null' ||
                                          _mAchivment.sheight.trim()  == '')&&(_mAchivment.sweight == null ||
                                          _mAchivment.sweight ==
                                              'null' ||
                                          _mAchivment.sweight.trim()  == '')
                                          ? SizedBox()
                                          : Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Padding(
                                                    padding: const EdgeInsets
                                                            .fromLTRB(
                                                        0.0, 30, 0, 0),
                                                    child: Text("My Detail",
                                                        style: TextStyle(
                                                            fontSize: 15.0,
                                                            color: ColorValues
                                                                .ORANGE_COLOR,
                                                            letterSpacing: 5.0,
                                                            wordSpacing: 0.0,
                                                            fontFamily:
                                                                "customAcme"))),
                                                (_mAchivment.sheight == null ||
                                                    _mAchivment.sheight ==
                                                        'null' ||
                                                    _mAchivment.sheight.trim()  == '')&&(_mAchivment.sweight == null ||
                                                    _mAchivment.sweight ==
                                                        'null' ||
                                                    _mAchivment.sweight.trim() == '')

                                                    ? SizedBox(height: 0,)
                                                    : Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                3.0, 5, 0, 0),
                                                        child: Text(
                                                            getStringHeightWeight(
                                                                _mAchivment
                                                                    .sheight,
                                                                _mAchivment
                                                                    .sweight)

                                                            ,
                                                            style: TextStyle(
                                                                fontSize: 14.0,
                                                                color: Colors
                                                                    .white,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR)),
                                                      ),
                                                _mAchivment.age == null ||
                                                        _mAchivment.age ==
                                                            'null' ||
                                                        _mAchivment.age.trim()  == ''
                                                    ? SizedBox()
                                                    : Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                3.0, 10, 0, 0),
                                                        child: Text(
                                                            "Age: " +
                                                                _mAchivment
                                                                    .age +
                                                                " years",
                                                            style: TextStyle(
                                                                fontSize: 14.0,
                                                                color: Colors
                                                                    .white,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR)),
                                                      ),
                                                Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(3.0, 0, 0, 0),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: List.generate(
                                                          _mAchivment.statsList
                                                              .length, (index) {
                                                        return _mAchivment
                                                                    .statsList[
                                                                        index]
                                                                    .playingPosition ==
                                                                ""
                                                            ? Container(
                                                                height: 0.0,
                                                              )
                                                            : Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Padding(
                                                                    padding:
                                                                        const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            10,
                                                                            0,
                                                                            0),
                                                                    child: Text(
                                                                        _mAchivment
                                                                            .statsList[
                                                                        index]
                                                                            .playingPosition =="null"||_mAchivment
                                                                            .statsList[
                                                                        index]
                                                                            .playingPosition ==""?  "Playing Position: ":
                                                                        "Playing Position: " +
                                                                            _mAchivment
                                                                                .statsList[
                                                                                    index]
                                                                                .playingPosition,
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                14.0,
                                                                            color:
                                                                                Colors.white,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                  ),

                                                                      Padding(
                                                                          padding: const EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              1,
                                                                              0,
                                                                              0),
                                                                          child: Text(  _mAchivment.statsList[index].label == null ||
                                                                              _mAchivment.statsList[index].label ==
                                                                                  "" ||
                                                                              _mAchivment.statsList[index].label ==
                                                                                  "null" ? "Statistics - " :
                                                                              "Statistics - " + _mAchivment.statsList[index].label + " : " + _mAchivment.statsList[index].value,
                                                                              style: TextStyle(fontSize: 14.0, color: Color(0XFF5A7496), fontFamily: "customItalic")),
                                                                        ),
                                                                ],
                                                              );
                                                      }),
                                                    )),
                                              ],
                                            ),
                                      Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              0.0, 30, 0, 10),
                                          child: Text("GALLERY",
                                              style: TextStyle(
                                                  fontSize: 15.0,
                                                  color:
                                                      ColorValues.ORANGE_COLOR,
                                                  letterSpacing: 5.0,
                                                  wordSpacing: 0.0,
                                                  fontFamily: "customAcme"))),
                                      Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              3.0, 0, 0, 0),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: List.generate(
                                                _mAchivment.portFolioAssestList
                                                    .length, (index) {
                                              return Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  _mAchivment
                                                              .portFolioAssestList[
                                                                  index]
                                                              .type ==
                                                          "image"
                                                      ? Stack(
                                                          children: [
                                                            InkWell(
                                                              onTap: () {
                                                                Navigator.of(context).push(new MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        FullImageViewForPortFolio(_mAchivment
                                                                            .portFolioAssestList[index]
                                                                            .file)));
                                                              },
                                                              child: Container(
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Colors
                                                                      .black,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              5),
                                                                ),
                                                                child:
                                                                    CachedNetworkImage(
                                                                  height: 220.0,
                                                                  width: double
                                                                      .infinity,
                                                                  imageUrl: Constant
                                                                          .IMAGE_PATH +
                                                                      _mAchivment
                                                                          .portFolioAssestList[
                                                                              index]
                                                                          .file[
                                                                              0]
                                                                          .filePath,
                                                                  fit: BoxFit
                                                                      .contain,
                                                                  placeholder: (context, url) => _loader(
                                                                      context,
                                                                      widget.levelName ==
                                                                              "Sports"
                                                                          ? "assets/portfolio/sport_default.png"
                                                                          : "assets/portfolio/arts_default.png"),
                                                                  errorWidget: (context,
                                                                          url,
                                                                          error) =>
                                                                      _error(widget.levelName ==
                                                                              "Sports"
                                                                          ? "assets/portfolio/sport_default.png"
                                                                          : "assets/portfolio/arts_default.png"),
                                                                ),
                                                              ),
                                                            ),
                                                            Positioned(
                                                                top: 13.0,
                                                                right: 13.0,
                                                                child: _mAchivment
                                                                            .portFolioAssestList[index]
                                                                            .file
                                                                            .length ==
                                                                        1
                                                                    ? Container(
                                                                        height:
                                                                            0.0,
                                                                      )
                                                                    : Container(
                                                                        height:
                                                                            26.0,
                                                                        width:
                                                                            46,
                                                                        child: Container(
                                                                            decoration: BoxDecoration(color: Colors.black.withOpacity(.70), borderRadius: BorderRadius.all(Radius.circular(25.0))),
                                                                            child: Center(
                                                                              child: Text(
                                                                                "1/" + _mAchivment.portFolioAssestList[index].file.length.toString(),
                                                                                style: TextStyle(color: Colors.white),
                                                                              ),
                                                                            )),
                                                                      )),
                                                          ],
                                                        )
                                                      : _mAchivment
                                                                  .portFolioAssestList[
                                                                      index]
                                                                  .type ==
                                                              "video"
                                                          ? InkWell(
                                                              child: Container(
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Colors
                                                                      .black,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              5),
                                                                ),
                                                                height: 220.0,
                                                                child: Center(
                                                                  child: VideoPlayPauseNew(
                                                                      _mAchivment
                                                                          .portFolioAssestList[
                                                                              index]
                                                                          .file[
                                                                              0]
                                                                          .filePath,
                                                                      "",
                                                                      true,
                                                                      _scrollController),
                                                                ),
                                                              ),
                                                            )
                                                          : _mAchivment
                                                                      .portFolioAssestList[
                                                                          index]
                                                                      .type ==
                                                                  "link"
                                                              ? InkWell(
                                                                  onTap: () {
                                                                    if (_mAchivment
                                                                            .portFolioAssestList[index]
                                                                            .type ==
                                                                        "link") {
                                                                      if (_mAchivment
                                                                          .portFolioAssestList[
                                                                              index]
                                                                          .file[
                                                                              0]
                                                                          .filePath
                                                                          .toLowerCase()
                                                                          .contains(
                                                                              "http")) {
                                                                        launch(_mAchivment
                                                                            .portFolioAssestList[index]
                                                                            .file[0]
                                                                            .filePath);
                                                                      } else {
                                                                        String
                                                                            url =
                                                                            "http://" +
                                                                                _mAchivment.portFolioAssestList[index].file[0].filePath;
                                                                        launch(
                                                                            url);
                                                                      }
                                                                    }
                                                                  },
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            0,
                                                                            0,
                                                                            2),
                                                                    child:
                                                                        Stack(
                                                                      children: [
                                                                        ClipRRect(
                                                                            borderRadius:
                                                                                BorderRadius.circular(5.0),
                                                                            child: Image.asset(
                                                                              widget.levelName == "Sports" ? "assets/portfolio/sport_default.png" : "assets/portfolio/arts_default.png",
                                                                              fit: BoxFit.fill,
                                                                              height: 220.0,
                                                                              width: double.infinity,
                                                                            )),
                                                                        Positioned(
                                                                            bottom:
                                                                                0.0,
                                                                            left:
                                                                                0,
                                                                            right:
                                                                                0,
                                                                            child:
                                                                                Container(
                                                                              decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.only(
                                                                                      //  topRight: Radius.circular(40.0),
                                                                                      bottomRight: Radius.circular(5.0),
                                                                                      // topLeft: Radius.circular(40.0),
                                                                                      bottomLeft: Radius.circular(5.0)),
                                                                                  color: widget.levelName == "Sports" ? Color(0xff152543).withOpacity(.80) : Color(0xff152543).withOpacity(.80)),
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.fromLTRB(13.0, 10, 13, 10),
                                                                                child: Text(_mAchivment.portFolioAssestList[index].label, overflow: TextOverflow.ellipsis, maxLines: 2, style: TextStyle(fontSize: 14.0, color: Colors.white, fontFamily: Constant.TYPE_CUSTOMBOLD)),
                                                                              ),
                                                                            ))
                                                                      ],
                                                                    ),
                                                                  ))
                                                              : Container(
                                                                  height: 0.0,
                                                                ),
                                                  _mAchivment
                                                              .portFolioAssestList[
                                                                  index]
                                                              .type ==
                                                          "link"
                                                      ? Container(height: 0.0)
                                                      : Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  10,
                                                                  0,
                                                                  0),
                                                          child: InkWell(
                                                            child: Text(
                                                                _mAchivment
                                                                    .portFolioAssestList[
                                                                        index]
                                                                    .label,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color: widget.levelName ==
                                                                            "Sports"
                                                                        ? Color(
                                                                            0xff7799BC)
                                                                        : Color(
                                                                            0xff6F5B86),
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMBOLD)),
                                                          ),
                                                        ),
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(0.0, 3, 0, 0),
                                                    child: Text(
                                                        _mAchivment
                                                            .portFolioAssestList[
                                                                index]
                                                            .description,
                                                        style: TextStyle(
                                                            fontSize: 14.0,
                                                            color: Colors.white,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR)),
                                                  ),
                                                  widget.levelName == "Arts"
                                                      ? Container(
                                                          height: 20.0,
                                                        )
                                                      : Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  1,
                                                                  0,
                                                                  20),
                                                          child: Text(
                                                              _mAchivment
                                                                          .portFolioAssestList[
                                                                              index]
                                                                          .statistics ==
                                                                      ""
                                                                  ? ""
                                                                  : "Statistics: " +
                                                                      _mAchivment
                                                                          .portFolioAssestList[
                                                                              index]
                                                                          .statistics,
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      14.0,
                                                                  color: Color(
                                                                      0XFF5A7496),
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR)),
                                                        ),
                                                ],
                                              );
                                            }),
                                          )),
                                      isShowTeam && widget.levelName != "Arts"
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0.0, 10, 0, 0),
                                              child: Text("TEAMS",
                                                  style: TextStyle(
                                                      fontSize: 15.0,
                                                      color: ColorValues
                                                          .ORANGE_COLOR,
                                                      letterSpacing: 5.0,
                                                      wordSpacing: 0.0,
                                                      fontFamily:
                                                          "customAcme")))
                                          : Container(
                                              height: 0.0,
                                            ),
                                      isShowTeam && widget.levelName != "Arts"
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      3.0, 0, 0, 0),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: List.generate(
                                                    mteamDataList.length,
                                                    (index) {
                                                  return Padding(
                                                    padding: const EdgeInsets
                                                            .fromLTRB(
                                                        0.0, 10, 0, 0),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        border: Border.all(
                                                            color: const Color
                                                                    .fromRGBO(
                                                                255,
                                                                255,
                                                                255,
                                                                0.1),
                                                            width: 1.0),
                                                        gradient: index % 2 == 0
                                                            ? LinearGradient(
                                                                colors: [
                                                                  Color(
                                                                      0xff113A61),
                                                                  Color(
                                                                      0xff180256)
                                                                ],
                                                                begin:
                                                                    const FractionalOffset(
                                                                        0.0, 0.0),
                                                                end: const FractionalOffset(
                                                                    0.5, 0.0),
                                                                stops: [
                                                                  0.0,
                                                                  1.0
                                                                ],
                                                                tileMode:
                                                                    TileMode
                                                                        .clamp)
                                                            : LinearGradient(
                                                                colors: [
                                                                  Color(
                                                                      0xff400455),
                                                                  Color(
                                                                      0xff00224A)
                                                                ],
                                                                begin:
                                                                    const FractionalOffset(
                                                                        0.0,
                                                                        0.0),
                                                                end: const FractionalOffset(
                                                                    0.5, 0.0),
                                                                stops: [
                                                                  0.0,
                                                                  1.0
                                                                ],
                                                                tileMode:
                                                                    TileMode
                                                                        .clamp),
                                                      ),
                                                      child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  15.0,
                                                                  0,
                                                                  15,
                                                                  0),
                                                          child: Column(
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          const EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              0,
                                                                              0,
                                                                              0),
                                                                      child:
                                                                          Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          Padding(
                                                                              padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                                                                              child: Text(mteamDataList[index].orgName, style: TextStyle(fontSize: 25.0, color: ColorValues.ORANGE_COLOR, letterSpacing: 0.0, wordSpacing: 0.0, fontFamily: Constant.TYPE_CUSTOMREGULAR))),
                                                                          Padding(
                                                                            padding: const EdgeInsets.fromLTRB(
                                                                                0.0,
                                                                                2,
                                                                                0,
                                                                                0),
                                                                            child:
                                                                                Text(mteamDataList[index].teamName + "(" + mteamDataList[index].teamType + ")", style: TextStyle(fontSize: 16.0, color: Colors.white, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                          ),
                                                                          Padding(
                                                                            padding: const EdgeInsets.fromLTRB(
                                                                                0.0,
                                                                                2,
                                                                                0,
                                                                                0),
                                                                            child:
                                                                                Text(mteamDataList[index].city + ", " + mteamDataList[index].state, style: TextStyle(fontSize: 16.0, color: Colors.white, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    flex: 1,
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          const EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              0,
                                                                              0,
                                                                              0),
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          Padding(
                                                                              padding: const EdgeInsets.fromLTRB(0.0, 20, 0, 0),
                                                                              child: Text(mteamDataList[index].jersey, style: TextStyle(fontSize: 30.0, color: ColorValues.BLUE_COLOR_BOTTOMBAR, letterSpacing: 0.0, wordSpacing: 0.0, fontFamily: Constant.TYPE_CUSTOMREGULAR))),
                                                                          Padding(
                                                                            padding: const EdgeInsets.fromLTRB(
                                                                                0.0,
                                                                                2,
                                                                                0,
                                                                                0),
                                                                            child:
                                                                                Text("Jersey #", style: TextStyle(fontSize: 16.0, color: Color(0xff7799BC), fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    flex: 0,
                                                                  ),
                                                                ],
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .fromLTRB(
                                                                        0.0,
                                                                        10,
                                                                        0,
                                                                        0),
                                                                child:
                                                                    Container(
                                                                  height: 1.0,
                                                                  color: Colors
                                                                      .white
                                                                      .withOpacity(
                                                                          .1),
                                                                ),
                                                              ),
                                                              Row(
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsets
                                                                              .fromLTRB(
                                                                          0.0,
                                                                          10,
                                                                          0,
                                                                          20),
                                                                      child:
                                                                          Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          Padding(
                                                                              padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                                                                              child: Text(mteamDataList[index].coachName + "(Coach)", style: TextStyle(fontSize: 14.0, color: ColorValues.COACH_TEXT_COLOR_SPORTS, letterSpacing: 0.0, wordSpacing: 0.0, fontFamily: Constant.TYPE_CUSTOMREGULAR))),
                                                                          Padding(
                                                                            padding: const EdgeInsets.fromLTRB(
                                                                                0.0,
                                                                                2,
                                                                                0,
                                                                                0),
                                                                            child:
                                                                                Text(mteamDataList[index].coachEmail.trim(), style: TextStyle(fontSize: 14.0, color: ColorValues.COACH_TEXT_COLOR_SPORTS, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                          ),
                                                                          Padding(
                                                                            padding: const EdgeInsets.fromLTRB(
                                                                                0.0,
                                                                                2,
                                                                                0,
                                                                                0),
                                                                            child:
                                                                                Text("+" + mteamDataList[index].coachCountryCode + getFormattedPhoneNo(mteamDataList[index].coachPhoneNo), style: TextStyle(fontSize: 14.0, color: ColorValues.COACH_TEXT_COLOR_SPORTS, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    flex: 1,
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsets
                                                                              .fromLTRB(
                                                                          0.0,
                                                                          10,
                                                                          0,
                                                                          0),
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          Container(
                                                                            child:
                                                                                CachedNetworkImage(
                                                                              imageUrl: Constant.IMAGE_PATH + _mAchivment.level2Icon,
                                                                              fit: BoxFit.cover,
                                                                              color: ColorValues.COACH_TEXT_COLOR_SPORTS,
                                                                              placeholder: (context, url) => _loader(context, "assets/portfolio/baseball.png"),
                                                                              errorWidget: (context, url, error) => _error("assets/portfolio/baseball.png"),
                                                                            ),
                                                                            width:
                                                                                68.0,
                                                                            height:
                                                                                68.0,
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    flex: 0,
                                                                  ),
                                                                ],
                                                              ),
                                                            ],
                                                          )),
                                                    ),
                                                  );
                                                }),
                                              ))
                                          : Container(
                                              height: 0.0,
                                            ),
                                      _mAchivment.recommendations != null &&
                                              _mAchivment
                                                      .recommendations.stage ==
                                                  "Added"
                                          ? Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Padding(
                                                    padding: const EdgeInsets
                                                            .fromLTRB(
                                                        0.0, 20, 0, 10),
                                                    child: Text(
                                                        "RECOMMENDATION(S)",
                                                        style: TextStyle(
                                                            fontSize: 15.0,
                                                            color: ColorValues
                                                                .ORANGE_COLOR,
                                                            letterSpacing: 5.0,
                                                            wordSpacing: 0.0,
                                                            fontFamily:
                                                                "customAcme"))),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          3.0, 0, 0, 0),
                                                  child: Text(
                                                      _mAchivment
                                                          .recommendations
                                                          .recommendation,
                                                      style: TextStyle(
                                                          fontSize: 14.0,
                                                          color: Colors.white,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR)),
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          3.0, 10, 0, 0),
                                                  child: Text(
                                                      _mAchivment
                                                                  .recommendations
                                                                  .recommender
                                                                  .firstName ==
                                                              "null"
                                                          ? ""
                                                          : _mAchivment
                                                                      .recommendations
                                                                      .recommender
                                                                      .lastName ==
                                                                  "null"
                                                              ? _mAchivment
                                                                  .recommendations
                                                                  .recommender
                                                                  .firstName
                                                              : _mAchivment
                                                                      .recommendations
                                                                      .recommender
                                                                      .firstName +
                                                                  " " +
                                                                  _mAchivment
                                                                      .recommendations
                                                                      .recommender
                                                                      .lastName,
                                                      style: TextStyle(
                                                          fontSize: 14.0,
                                                          color:
                                                              Color(0XFF7799BC),
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR)),
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          3.0, 3, 0, 0),
                                                  child: Text(
                                                      _mAchivment
                                                          .recommendationTitle,
                                                      style: TextStyle(
                                                          fontSize: 12.0,
                                                          color: Colors.white,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR)),
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          3.0, 2, 0, 0),
                                                  child: Text(
                                                      "For: " +
                                                          _mAchivment
                                                              .level3Competency +
                                                          "  |  " +
                                                          Util.getConvertedDateStampNew(
                                                              _mAchivment
                                                                  .recommendations
                                                                  .repliedDate
                                                                  .toString()),
                                                      style: TextStyle(
                                                          fontSize: 12.0,
                                                          color: Colors.white,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR)),
                                                ),
                                              ],
                                            )
                                          : Container(
                                              height: 0.0,
                                            ),
                                      _mAchivment.externalLinksList.length == 0
                                          ? Container(
                                              height: 0.0,
                                            )
                                          : _mAchivment.externalLinksList
                                                          .length >
                                                      1 ||
                                                  (_mAchivment.externalLinksList
                                                              .length ==
                                                          1 &&
                                                      _mAchivment.externalLinksList[0].url
                                                              .toString() !=
                                                          "null" &&
                                                      _mAchivment.externalLinksList[0].url
                                                              .toString() !=
                                                          "")
                                              ? Padding(
                                                  padding: const EdgeInsets.fromLTRB(
                                                      0.0, 30, 0, 10),
                                                  child: Text(
                                                      "External Links & Mentions",
                                                      style: TextStyle(
                                                          fontSize: 15.0,
                                                          color: ColorValues
                                                              .ORANGE_COLOR,
                                                          letterSpacing: 5.0,
                                                          wordSpacing: 0.0,
                                                          fontFamily: "customAcme")))
                                              : Container(
                                                  height: 0.0,
                                                ),
                                      Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              3.0, 0, 0, 30),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: List.generate(
                                                _mAchivment.externalLinksList
                                                    .length, (index) {
                                              return Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(0.0, 0, 0, 0),
                                                    child: InkWell(
                                                      onTap: () {
                                                        if (_mAchivment
                                                            .externalLinksList[
                                                                index]
                                                            .url
                                                            .toLowerCase()
                                                            .contains("http")) {
                                                          launch(_mAchivment
                                                              .externalLinksList[
                                                                  index]
                                                              .url);
                                                        } else {
                                                          String url = "http://" +
                                                              _mAchivment
                                                                  .externalLinksList[
                                                                      index]
                                                                  .url;
                                                          launch(url);
                                                        }
                                                      },
                                                      child: Text(
                                                          _mAchivment
                                                              .externalLinksList[
                                                                  index]
                                                              .label,
                                                          style: TextStyle(
                                                              fontSize: 14.0,
                                                              color: Color(
                                                                  0xff4684EB),
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMBOLD)),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(0.0, 3, 0, 0),
                                                    child: Text(
                                                        _mAchivment
                                                            .externalLinksList[
                                                                index]
                                                            .description,
                                                        style: TextStyle(
                                                            fontSize: 14.0,
                                                            color: Colors.white,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR)),
                                                  ),
                                                ],
                                              );
                                            }),
                                          )),
                                      widget.pageName == "dashboard"
                                          ? getPersonalReflection()
                                          : Container(
                                              width: 0,
                                              height: 0,
                                            ),
                                    ],
                                  ))
                            ],
                          ),
                        ))
                  ],
                ))));
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  String getFormattedPhoneNo(String phoneNumber) {
    String formattedPhoneNumber = '';
    if (phoneNumber != null && phoneNumber != '' && phoneNumber != 'null') {
      formattedPhoneNumber = "-" +
          phoneNumber.substring(0, 3) +
          "-" +
          phoneNumber.substring(3, 6) +
          "-" +
          phoneNumber.substring(6, phoneNumber.length);
    }
    print('Apurva getFormattedPhoneNo phoneNumber:: $phoneNumber');
    return formattedPhoneNumber;
  }

  Container getPersonalReflection() {
    return _mAchivment.personalReflection != null &&
            _mAchivment.personalReflection != 'null' &&
            _mAchivment.personalReflection != ''
        ? Container(
            //color: Colors.red,
            //height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 20.0),
            child: Stack(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 16.0, 0.0, 0.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(0),
                      //color: Color(0xFFF333333),
                      color: Color(0xFFFFFFFFF).withOpacity(0.1),
                      border: Border.all(
                        color: Color(0xFFFFFFFFF).withOpacity(0.1),
                        style: BorderStyle.solid,
                        width: 1.0,
                      ),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(0),
                      child: Container(
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              10.0,
                              Row(
                                children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      6.0,
                                      0.0,
                                      InkWell(
                                        onTap: () {},
                                        child: Image.asset(
                                          "assets/newDesignIcon/ad_new/pr_notes_seleted.png",
                                          height: 32.0,
                                          width: 32.0,
                                        ),
                                      )),
                                  Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        TextViewWrap.textViewMultiLine(
                                            "Personal Reflection".toUpperCase(),
                                            TextAlign.start,
                                            ColorValues.WHITE,
                                            12.0,
                                            FontWeight.w400,
                                            2)),
                                    flex: 0,
                                  ),
                                ],
                              ),
                            ),

                            //=========Show more / less ===========
                            Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      5.0,
                                      Text(
                                        _mAchivment.personalReflection.trim(),
                                        maxLines:
                                            _mAchivment.isShowMorePersonalRef
                                                ? 25
                                                : 3,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            color: Color(0xFFFFFFFFF),
                                            fontSize: 12.0,
                                            //fontStyle: FontStyle.italic,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR),
                                      )),
                                  Expanded(
                                    child: _mAchivment.personalReflection
                                                .trim()
                                                .length >
                                            130
                                        ? InkWell(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                Text(
                                                  _mAchivment
                                                          .isShowMorePersonalRef
                                                      ? "Less"
                                                      : "More",
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.start,
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 12.0,
                                                      //fontStyle: FontStyle.italic,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              if (_mAchivment
                                                  .isShowMorePersonalRef)
                                                _mAchivment
                                                        .isShowMorePersonalRef =
                                                    false;
                                              else
                                                _mAchivment
                                                        .isShowMorePersonalRef =
                                                    true;
                                              setState(() {
                                                _mAchivment
                                                    .isShowMorePersonalRef;
                                              });
                                            },
                                          )
                                        : Container(
                                            height: 0.0,
                                          ),
                                    flex: 0,
                                  ),
                                ],
                              ),
                            ),
                            //=====================
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                0.0,
                                TextViewWrap.textViewMultiLineItalic(
                                    "Note: Personal reflection is a note to self and will not be shared with anyone.",
                                    TextAlign.start,
                                    ColorValues.ORANGE_TEXT_COLOR_VIEW,
                                    11.0,
                                    FontWeight.normal,
                                    4)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          )
        : Container(
            height: 1.0,
          );
  }
}
