import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/group_list_for_post.dart';
import 'package:spike_view_project/linkPreview/whatsapp/view.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/video_player/video_play_view.dart';

class NewSharePostWidget extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  UserPostModal userPostModal;
  String page, groupId;

  NewSharePostWidget(
    this.profileInfoModal,
    this.userPostModal,
    this.page,
    this.groupId,
  );

  @override
  State<NewSharePostWidget> createState() => _NewSharePostWidgetState();
}

class _NewSharePostWidgetState extends State<NewSharePostWidget> {
  SharedPreferences prefs;
  var isButtonEnable = false;
  String userIdPref,
      roleId,
      token,
      userProfilePath,
      companyImagePath,
      companyName;
  String isType = "Community";
  TextEditingController edtController;
  String sasToken, containerName, strPrefixPathforFeed;
  List<TagsPost> selectedtScopeList = List();
  List<TagModel> selectedUerTagLIst1 = List();
  RegExp exp = RegExp(
      r"(http|ftp|https|Https|Http)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");
  List<TagsPost> selectedUerTagLIst = List();
  List<String> groupidList = List();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    companyImagePath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    companyName = prefs.getString(UserPreference.COMPANY_NAME_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);
    setState(() {});
    strPrefixPathforFeed = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
  }

  bool showMore = false;

  @override
  void initState() {
    getSharedPreferences();
    isType = widget?.userPostModal?.visibility ?? '';
    edtController = TextEditingController(text: '');
    edtController.addListener(() {
      if (edtController.text.length > 20) {
        setState(() {
          showMore = true;
        });
      } else {
        setState(() {
          showMore = false;
        });
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      bottomSheet: bottomSection(),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/generateScript/script_background.png"),
              fit: BoxFit.fill,
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    top: 40, left: 20, right: 20, bottom: 22),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context, 'pop');
                      },
                      child: Image.asset(
                        "assets/generateScript/back.png",
                        height: 32.0,
                        width: 32.0,
                      ),
                    ),
                    const HelpButtonWidget(),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Share post",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            fontSize: 28.0,
                            fontWeight: FontWeight.w700,
                            color: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: Constant.latoRegular),
                      ),
                      const SizedBox(height: 10),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              const SizedBox(height: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  ProfileImageView(
                                    imagePath: Constant.IMAGE_PATH_SMALL +
                                        ParseJson.getSmallImage(roleId == "4"
                                            ? companyImagePath
                                            : userProfilePath),
                                    placeHolderImage: roleId == "4"
                                        ? "assets/profile/partner_img.png"
                                        : 'assets/profile/user_on_user.png',
                                    width: 46.0,
                                    height: 46.0,
                                    onTap: () {},
                                  ),
                                  const SizedBox(width: 11),
                                  Expanded(
                                    child: Text(
                                        roleId == "4"
                                            ? companyName
                                            : widget.profileInfoModal != null
                                                ? widget.profileInfoModal
                                                                .lastName ==
                                                            null ||
                                                        widget.profileInfoModal
                                                                .lastName ==
                                                            "null" ||
                                                        widget.profileInfoModal
                                                                .lastName ==
                                                            ""
                                                    ? widget.profileInfoModal
                                                        .firstName
                                                    : widget.profileInfoModal
                                                            .firstName +
                                                        " " +
                                                        widget.profileInfoModal
                                                            .lastName
                                                : "",
                                        overflow: TextOverflow.ellipsis,
                                        style: AppConstants.txtStyle
                                            .heading16500LatoRegularDarkBlue
                                        // assestList.length > 0
                                        //     ? AppConstants.txtStyle
                                        //         .heading16500LatoRegularWhite
                                        //     :,
                                        ),
                                  )
                                ],
                              ),
                              const SizedBox(height: 24),
                              CustomFormField(
                                maxLines: 3,
                                minLines: 3,
                                maxLength: TextLength.SUMMARY_MSG_LENGTH,
                                controller: edtController,
                                label: "Share your thoughts",
                                alignLabelWithHint: true,
                              ),
                              const SizedBox(height: 24),
                              widget.userPostModal.isOpportunity
                                  ? getListViewForOpportunity(
                                      widget.userPostModal)
                                  : getListView(widget.userPostModal),
                              const SizedBox(height: 24),
                              Text(
                                AppConstants.stringConstant.sharePostWith,
                                style: AppConstants.txtStyle
                                    .heading14500LatoRegularLightPurple,
                              ),
                              const SizedBox(height: 3),
                              isType == "Public"
                                  ? InkWell(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Expanded(
                                            child: Text(
                                              "Public",
                                              textAlign: TextAlign.start,
                                              style: AppConstants.txtStyle
                                                  .heading18500LatoRegularDarkBlue,
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: Image.asset(
                                              "assets/feed/down_arrow.png",
                                              height: 24.0,
                                              width: 24.0,
                                            ),
                                            flex: 0,
                                          ),
                                        ],
                                      ),
                                      onTap: () {
                                        //_settingModalBottomSheet(context);
                                        //onTapWhoCanSeePost();
                                        showWhoCanSeeYourPostPopup();
                                      })
                                  : isType == "Private"
                                      ? InkWell(
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: <Widget>[
                                              Expanded(
                                                child: Text(
                                                  "Private",
                                                  textAlign: TextAlign.start,
                                                  style: AppConstants.txtStyle
                                                      .heading18500LatoRegularDarkBlue,
                                                ),
                                                flex: 1,
                                              ),
                                              Expanded(
                                                child: Image.asset(
                                                  "assets/feed/down_arrow.png",
                                                  height: 24.0,
                                                  width: 24.0,
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            //_settingModalBottomSheet(context);
                                            //onTapWhoCanSeePost();
                                            showWhoCanSeeYourPostPopup();
                                          })
                                      : isType == "AllConnections"
                                          ? InkWell(
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Text(
                                                      "Connections",
                                                      textAlign:
                                                          TextAlign.start,
                                                      style: AppConstants
                                                          .txtStyle
                                                          .heading18500LatoRegularDarkBlue,
                                                    ),
                                                    flex: 1,
                                                  ),
                                                  Expanded(
                                                    child: Image.asset(
                                                      "assets/feed/down_arrow.png",
                                                      height: 24.0,
                                                      width: 24.0,
                                                    ),
                                                    flex: 0,
                                                  ),
                                                ],
                                              ),
                                              onTap: () {
                                                // _settingModalBottomSheet(context);
                                                //onTapWhoCanSeePost();
                                                showWhoCanSeeYourPostPopup();
                                              })
                                          : isType == "Community"
                                              ? InkWell(
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: <Widget>[
                                                      Expanded(
                                                        child: Text(
                                                          "Community",
                                                          textAlign:
                                                              TextAlign.start,
                                                          style: AppConstants
                                                              .txtStyle
                                                              .heading18500LatoRegularDarkBlue,
                                                        ),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: Image.asset(
                                                          "assets/feed/down_arrow.png",
                                                          height: 24.0,
                                                          width: 24.0,
                                                        ),
                                                        flex: 0,
                                                      ),
                                                    ],
                                                  ),
                                                  onTap: () {
                                                    // _settingModalBottomSheet(context);
                                                    //onTapWhoCanSeePost();
                                                    showWhoCanSeeYourPostPopup();
                                                  })
                                              : isType == "Group"
                                                  ? InkWell(
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          Expanded(
                                                            child: Text(
                                                              "Group",
                                                              textAlign:
                                                                  TextAlign
                                                                      .start,
                                                              style: AppConstants
                                                                  .txtStyle
                                                                  .heading18500LatoRegularDarkBlue,
                                                            ),
                                                            flex: 1,
                                                          ),
                                                          Expanded(
                                                            child: Image.asset(
                                                              "assets/feed/down_arrow.png",
                                                              height: 24.0,
                                                              width: 24.0,
                                                            ),
                                                            flex: 0,
                                                          ),
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        // _settingModalBottomSheet(context);
                                                        // onTapWhoCanSeePost();
                                                        showWhoCanSeeYourPostPopup();
                                                      })
                                                  : InkWell(
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          Expanded(
                                                            child: Text(
                                                              "Selected Connections",
                                                              textAlign:
                                                                  TextAlign
                                                                      .start,
                                                              style: AppConstants
                                                                  .txtStyle
                                                                  .heading18500LatoRegularDarkBlue,
                                                            ),
                                                            flex: 1,
                                                          ),
                                                          Expanded(
                                                            child: Image.asset(
                                                              "assets/feed/down_arrow.png",
                                                              height: 24.0,
                                                              width: 24.0,
                                                            ),
                                                            flex: 0,
                                                          ),
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        //_settingModalBottomSheet(context);
                                                        // onTapWhoCanSeePost();
                                                        showWhoCanSeeYourPostPopup();
                                                      }),
                              Divider(
                                thickness: 1,
                                color: Color(0xffE5EBF0),
                                height: 10,
                              ),
                              const SizedBox(height: 100),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  bottomSection() {
    return Container(
      color: Colors.white,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          //cancelButton(),
          proceedButton(),
        ],
      ),
    );
  }

  cancelButton() {
    return Expanded(
      flex: 0,
      child: Container(
          margin: EdgeInsets.only(left: 20, right: 12, top: 20, bottom: 30),
          height: 44.0,
          width: 120,
          child: FlatButton(
            onPressed: () async {
              Navigator.pop(context, 'pop');
            },
            shape: RoundedRectangleBorder(
                side: BorderSide(color: AppConstants.colorStyle.btnBg),
                borderRadius: BorderRadius.circular(10)),
            color: AppConstants.colorStyle.white,
            child: Row(
              // Replace with a Row for horizontal icon + text
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Cancel",
                    style: AppConstants
                        .txtStyle.heading18600LatoRegularLightPurple),
              ],
            ),
          )),
    );
  }

  proceedButton() {
    return Expanded(
      flex: 1,
      child: Container(
        margin: EdgeInsets.only(right: 20, top: 20, bottom: 30, left: 20),
        //width: 212,
        height: 44.0,
        child: FlatButton(
          onPressed: () {
            onTapPostButton();
          },
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          color: AppConstants.colorStyle.lightBlue,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                AppConstants.stringConstant.post,
                style: TextStyle(
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontSize: 16,
                    color: AppConstants.colorStyle.white,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void postPopUp() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => SafeArea(
        child: Scaffold(
          backgroundColor: Colors.black38,
          body: Stack(
            children: <Widget>[
              Positioned(
                  right: 0.0,
                  left: 0.0,
                  bottom: 50.0,
                  child: Container(
                      height: 205.0,
                      color: Colors.transparent,
                      child: Stack(
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              20.0,
                              0.0,
                              20.0,
                              0.0,
                              ListView(children: <Widget>[
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(10)),
                                  ),
                                  width: double.infinity,
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        SizedBox(
                                          height: 15,
                                        ),
                                        Text(
                                          AppConstants
                                              .stringConstant.communityPost,
                                          textAlign: TextAlign.center,
                                          maxLines: 5,
                                          style: AppConstants.txtStyle
                                              .heading14700LatoRegularDarkBlue,
                                        ),
                                        SizedBox(
                                          height: 7,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 14, right: 14),
                                          child: Text(
                                            AppConstants.stringConstant
                                                .spikeCommunityReviewed,
                                            textAlign: TextAlign.center,
                                            maxLines: 5,
                                            style: AppConstants.txtStyle
                                                .heading14400LatoRegularLightPurple,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 15,
                                        ),
                                        Container(
                                          color: AppConstants
                                              .colorStyle.dividerPopUp,
                                          height: 1.0,
                                        ),
                                        InkWell(
                                          child: Container(
                                              height: 50.0,
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 12.0, 0.0, 13.0),
                                              child: Text(
                                                AppConstants
                                                    .stringConstant.post,
                                                textAlign: TextAlign.center,
                                                style: AppConstants.txtStyle
                                                    .heading16500LatoRegularLightBlue,
                                              )),
                                          onTap: () async {
                                            Navigator.pop(context, 'pop');
                                            // onTapReviewedPost();
                                            // CustomProgressLoader
                                            //     .showLoader(context);
                                            apiCalling();
                                          },
                                        ),
                                      ]),
                                )
                              ])),
                        ],
                      ))),
              Positioned(
                right: 0.0,
                left: 0.0,
                bottom: 32.0,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: PaddingWrap.paddingfromLTRB(
                      20.0,
                      0.0,
                      20.0,
                      0.0,
                      Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius:
                                const BorderRadius.all(Radius.circular(10)),
                          ),
                          padding: EdgeInsets.all(10.0),
                          height: 51.0,
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: InkWell(
                                  child: Container(
                                      child: Text(
                                    AppConstants.stringConstant.cancel,
                                    textAlign: TextAlign.center,
                                    style: AppConstants.txtStyle
                                        .heading16500LatoRegularDarkBlue,
                                  )),
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                ),
                                flex: 1,
                              ),
                            ],
                          ))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  onTapPostButton() async {
    if (isType == "Community") {
      // conformationDialogForCommunityPost();
      postPopUp();
    } else {
      apiCalling();
    }
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        bool isCommunityPost = false;
        if (isType == "Community") {
          isCommunityPost = true;
        }
        Map map = {
          "feedId": widget.userPostModal.feedId,
          "postedBy": int.parse(userIdPref),
          "postOwner": int.parse(widget.userPostModal.postedBy),
          "postOwnerRoleId": widget.userPostModal.postOwnerRoleId != "null" ||
                  widget.userPostModal.postOwnerRoleId != ""
              ? ""
              : int.parse(widget.userPostModal.postOwnerRoleId),
          "visibility": isType,
          "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
          "shareTime": DateTime.now().millisecondsSinceEpoch,
          "shareText": edtController.text,
          "isActive": widget.profileInfoModal.isActive,
          "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
          "lastActivityType": "ShareFeed",
          "roleId": int.parse(roleId),
          "groupId": widget.groupId == "0" ? "" : int.parse(widget.groupId),
          "groupIds": groupidList.map((item) => int.parse(item)).toList(),
          "isCommunityPost": isCommunityPost,
        };

        print("Map:-" + map.toString());
        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_SHARE_FEED, map);

        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              Navigator.pop(context, "push");
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("error" + e.toString());
      CustomProgressLoader.cancelLoader(context);
    }
  }

  Widget getListViewForOpportunity(UserPostModal userPostModal) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        userPostModal.opportunityModelForFeed.assestVideoAndImage.length == 0
            ? _imageAndName(true)
            : const SizedBox.shrink(),
        Stack(
          children: <Widget>[
            InkWell(
              child: Container(
                width: double.infinity,
                child: Column(
                  children: <Widget>[
                    userPostModal.opportunityModelForFeed.assestVideoAndImage
                                .length >
                            0
                        ? Container(
                            color: Colors.black,
                            child: SizedBox(
                              // Pager view
                              height: 215.50,
                              child: PageIndicatorContainer(
                                pageView: PageView.builder(
                                  itemCount: userPostModal
                                      .opportunityModelForFeed
                                      .assestVideoAndImage
                                      .length,
                                  controller: PageController(),
                                  itemBuilder: (context, index2) {
                                    return Stack(
                                      children: <Widget>[
                                        userPostModal
                                                    .opportunityModelForFeed
                                                    .assestVideoAndImage[index2]
                                                    .type ==
                                                "image"
                                            ? CachedNetworkImage(
                                                width: double.infinity,
                                                height: 300.00,
                                                imageUrl: Constant.IMAGE_PATH +
                                                    userPostModal
                                                        .opportunityModelForFeed
                                                        .assestVideoAndImage[
                                                            index2]
                                                        .file,
                                                fit: BoxFit.contain,
                                                //before issue .fill
                                                placeholder: (context, url) =>
                                                    _loader(context),
                                                errorWidget:
                                                    (context, url, error) =>
                                                        _error(),
                                              )
                                            : Container(
                                                height: 300.00,
                                                color: Colors.black,
                                                child: Center(
                                                  child: VideoPlayerView(
                                                    videoPath: Constant
                                                                .PATH_FOR_VIDEO +
                                                            userPostModal
                                                                ?.opportunityModelForFeed
                                                                ?.assestVideoAndImage[
                                                                    index2]
                                                                ?.file
                                                                ?.replaceAll(
                                                                    Constant
                                                                        .PATH_FOR_VIDEO,
                                                                    '') ??
                                                        '',
                                                    videoType:
                                                        VideoType.network,
                                                  ),
                                                ),
                                              ),
                                        userPostModal
                                                    .opportunityModelForFeed
                                                    .assestVideoAndImage
                                                    .length ==
                                                1
                                            ? const SizedBox.shrink()
                                            : Container(
                                                height: 300.00,
                                                width: double.infinity,
                                                child: Image.asset(
                                                  "assets/newDesignIcon/navigation/layer_image.png",
                                                  fit: BoxFit.fill,
                                                ),
                                              )
                                      ],
                                    );
                                  },
                                  onPageChanged: (index) {},
                                ),
                                align: IndicatorAlign.bottom,
                                length: userPostModal.opportunityModelForFeed
                                    .assestVideoAndImage.length,
                                indicatorSpace: 10.0,
                                indicatorColor: userPostModal
                                            .opportunityModelForFeed
                                            .assestVideoAndImage
                                            .length ==
                                        1
                                    ? Colors.transparent
                                    : Color(0xffc4c4c4),
                                indicatorSelectorColor: userPostModal
                                            .opportunityModelForFeed
                                            .assestVideoAndImage
                                            .length ==
                                        1
                                    ? Colors.transparent
                                    : ColorValues.WHITE,
                                shape: IndicatorShape.circle(size: 5.0),
                              ),
                            ),
                          )
                        : SizedBox(
                            height: 215.50,
                            child: Stack(
                              children: <Widget>[
                                Image.asset(
                                  "assets/profile/default_achievement.png",
                                  fit: BoxFit.cover,
                                  height: 215.50,
                                  width: double.infinity,
                                ),
                                Container(
                                  height: 215.50,
                                  color: Colors.black54.withOpacity(.4),
                                )
                              ],
                            ),
                          ),
                    Container(
                      color: ColorValues.WHITE,
                      child: Column(
                        children: <Widget>[
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(top: 16.0),
                                child: Image.asset(
                                  "assets/newDesignIcon/patner/spike_grey.png",
                                  height: 12.0,
                                  width: 12.0,
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 3.0, top: 16.0),
                                child: Text(
                                  "OPPORTUNITY",
                                  style: TextStyle(
                                      color: ColorValues.GREY_TEXT_COLOR,
                                      fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: Container(
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0, 2.0, 10.0, 10.0),
                                    child: Text(
                                      userPostModal
                                          .opportunityModelForFeed.jobTitle,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 14.0,
                                          fontFamily: Constant.TYPE_CUSTOMBOLD,
                                          fontWeight: FontWeight.bold),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ),
                                flex: 1,
                              ),
                            ],
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              onTap: () {},
            ),
            userPostModal.opportunityModelForFeed.assestVideoAndImage.length > 0
                ? _imageAndName(false)
                : const SizedBox.shrink(),
          ],
        ),
      ],
    );
  }

  Widget getListView(UserPostModal userPostModal) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        userPostModal.postdata.assetsList.length == 0
            ? const SizedBox.shrink()
            : userPostModal.postdata.assetsList.length == 0
                ? _imageAndName(true)
                : const SizedBox.shrink(),
        Stack(
          children: <Widget>[
            userPostModal.postdata == null ||
                    userPostModal.postdata.text == null ||
                    userPostModal.postdata.text == "null"
                ? const SizedBox.shrink()
                : Container(
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          userPostModal.postdata.text == "" ||
                                  userPostModal.postdata.text == "null" ||
                                  userPostModal.postdata.text == "\n"
                              ? const SizedBox.shrink()
                              : userPostModal.postdata.assetsList.length == 0 &&
                                      (userPostModal.postdata.metaUrl != "" &&
                                          userPostModal.postdata.metaImage !=
                                              "")
                                  ? exp
                                                  .allMatches(userPostModal
                                                      .postdata.text)
                                                  .length ==
                                              1 &&
                                          userPostModal.postdata.text
                                                  .toString()
                                                  .replaceAll(exp, '')
                                                  .length ==
                                              0
                                      ? const SizedBox.shrink()
                                      : PaddingWrap.paddingfromLTRB(
                                          4.0,
                                          10.0,
                                          13.0,
                                          0.0,
                                          Container(
                                            child: Linkify(
                                              onOpen: (link) async {
                                                print("onclick +++" +
                                                    link.url.toLowerCase());

                                                Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        //   builder: (context) =>  DashBoardWidget()));
                                                        builder: (context) =>
                                                            WebViewWidget(
                                                                link.url,
                                                                "spikeview")));
                                              },
                                              text: exp
                                                          .allMatches(
                                                              userPostModal
                                                                  .postdata
                                                                  .text)
                                                          .length >
                                                      1
                                                  ? userPostModal.postdata.text
                                                  : userPostModal.postdata.text
                                                      .toString()
                                                      .replaceAll(exp, ''),
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR,
                                                  fontSize: 14.0),
                                              linkStyle: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR,
                                                  fontSize: 14.0),
                                            ),
                                          ))
                                  : Linkify(
                                      onOpen: (link) async {
                                        print("onclick +++" +
                                            link.url.toLowerCase());

                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                //   builder: (context) =>  DashBoardWidget()));
                                                builder: (context) =>
                                                    WebViewWidget(link.url,
                                                        "spikeview")));
                                      },
                                      text: userPostModal
                                                  .postdata.assetsList.length ==
                                              0
                                          ? userPostModal.postdata.text
                                          : "",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14.0),
                                      linkStyle: TextStyle(
                                          color:
                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR,
                                          fontSize: 14.0),
                                    ),
                        ),
                      ],
                    ),
                  ),
            userPostModal.postdata.assetsList.length == 0
                ? const SizedBox.shrink()
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                          color: Colors.black,
                          height: 250.00,
                          child: SizedBox(
                              // Pager view sss
                              height: 250.00,
                              child: PageIndicatorContainer(
                                pageView: PageView.builder(
                                  itemCount:
                                      userPostModal.postdata.assetsList.length,
                                  controller: PageController(),
                                  itemBuilder: (context, index2) {
                                    return userPostModal.postdata
                                                .assetsList[index2].type ==
                                            'image'
                                        ? InkWell(
                                            child: Stack(children: <Widget>[
                                              Container(
                                                  height: 250.00,
                                                  decoration: BoxDecoration(
                                                    color: Colors.black,
                                                  ),
                                                  child:
                                                      FadeInImage.assetNetwork(
                                                    fit: BoxFit.contain,
                                                    width: double.infinity,
                                                    height: 250.00,
                                                    placeholder:
                                                        'assets/aerial/default_img.png',
                                                    image: Constant
                                                            .IMAGE_PATH_SMALL +
                                                        ParseJson
                                                            .getMediumImage(
                                                                userPostModal
                                                                    .postdata
                                                                    .assetsList[
                                                                        index2]
                                                                    .file),
                                                  )),
                                              userPostModal.postdata.assetsList
                                                          .length ==
                                                      1
                                                  ? Container(
                                                      height: 0.0,
                                                    )
                                                  : Container(
                                                      height: 250.00,
                                                      width: double.infinity,
                                                      child: Image.asset(
                                                        "assets/newDesignIcon/navigation/layer_image.png",
                                                        fit: BoxFit.fill,
                                                      ),
                                                    )
                                            ]),
                                            onTap: () {},
                                          )
                                        : Container(
                                            height: 250.00,
                                            color: Colors.black,
                                            child: Center(
                                              child: VideoPlayerView(
                                                  videoPath: Constant
                                                              .PATH_FOR_VIDEO +
                                                          userPostModal
                                                              ?.postdata
                                                              ?.assetsList[
                                                                  index2]
                                                              ?.file
                                                              ?.replaceAll(
                                                                  Constant
                                                                      .PATH_FOR_VIDEO,
                                                                  '') ??
                                                      '',
                                                  videoType: VideoType.network),
                                            ),
                                          );
                                  },
                                  onPageChanged: (index) {},
                                ),
                                align: IndicatorAlign.bottom,
                                length:
                                    userPostModal.postdata.assetsList.length,
                                indicatorSpace: 10.0,
                                indicatorColor:
                                    userPostModal.postdata.assetsList.length ==
                                            1
                                        ? Colors.transparent
                                        : Color(0xffc4c4c4),
                                indicatorSelectorColor:
                                    userPostModal.postdata.assetsList.length ==
                                            1
                                        ? Colors.transparent
                                        : ColorValues.WHITE,
                                shape: IndicatorShape.circle(size: 5.0),
                              ))),
                      const SizedBox(height: 20),
                      Text(
                        userPostModal.postdata.text,
                        textAlign: TextAlign.start,
                        style: TextStyle(
                            color: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: Constant.latoRegular,
                            fontWeight: FontWeight.w400,
                            fontSize: 14.0),
                      ),
                    ],
                  ),
            userPostModal.postdata.assetsList.length == 0
                ? userPostModal.postdata == null ||
                        userPostModal.postdata.text == null ||
                        userPostModal.postdata.text == "null"
                    ? Container(
                        height: 0.0,
                      )
                    : userPostModal.postdata.metaUrl != ""
                        ? Container(
                            margin: EdgeInsets.symmetric(vertical: 4.0),
                            child: WhatsAppView(
                              imageUrl: userPostModal.postdata.metaImage,
                              feedId: userPostModal.feedId,
                              title: userPostModal.postdata.metaTitle,
                              url: userPostModal.postdata.metaUrl,
                              metaHeight: userPostModal.postdata.metaHeight,
                              metaWidth: userPostModal.postdata.metaWidth,
                              description:
                                  userPostModal.postdata.metaDescription,
                              metaSource: '',
                            ))
                        : const SizedBox.shrink()
                : const SizedBox.shrink(),
            userPostModal.postdata.assetsList.length == 0 &&
                    (userPostModal.postdata.metaUrl != "" &&
                        userPostModal.postdata.metaImage != "")
                ? _imageAndName(false)
                : userPostModal.postdata.assetsList.length == 0
                    ? const SizedBox.shrink()
                    : _imageAndName(false),
          ],
        ),
      ],
    );
  }

  Widget _imageAndName(bool isTop) {
    return Container(
      decoration: new BoxDecoration(
        image: new DecorationImage(
          image: new AssetImage("assets/feed/background_imageview.png"),
          fit: BoxFit.cover,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
        17.0,
        18.0,
        17.0,
        17.0,
        Row(
          children: <Widget>[
            ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  ParseJson.getSmallImage(widget.userPostModal.profilePicture),
              placeHolderImage: roleId == "4"
                  ? "assets/profile/partner_img.png"
                  : 'assets/profile/user_on_user.png',
              width: 46.0,
              height: 46.0,
              onTap: () {},
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                      child: RichText(
                    maxLines: 2,
                    textAlign: TextAlign.start,
                    text: TextSpan(
                      text: widget.userPostModal.lastName == "null"
                          ? widget.userPostModal.firstName
                          : widget.userPostModal.firstName +
                              " " +
                              widget.userPostModal.lastName,
                      style: isTop
                          ? AppConstants
                              .txtStyle.heading16500LatoRegularDarkBlue
                          : AppConstants.txtStyle.heading16500LatoRegularWhite,
                      children: widget.userPostModal.tagList.length == 0
                          ? null
                          : <TextSpan>[
                              TextSpan(
                                  text: ' with ',
                                  style: TextStyle(
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                      fontSize: 14.0,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                              TextSpan(
                                text: widget.userPostModal.tagList[0].name,
                                style: TextStyle(
                                    color: ColorValues.HEADING_COLOR_EDUCATION,
                                    fontSize: 14.0,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              ),
                              widget.userPostModal.tagList.length > 1
                                  ? TextSpan(
                                      text: ' and ',
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontSize: 14.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    )
                                  : TextSpan(
                                      text: "",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontSize: 14.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    ),
                              widget.userPostModal.tagList.length > 1
                                  ? TextSpan(
                                      text:
                                          (widget.userPostModal.tagList.length -
                                                  1)
                                              .toString(),
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontSize: 14.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    )
                                  : TextSpan(
                                      text: "",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontSize: 14.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    ),
                              widget.userPostModal.tagList.length > 1
                                  ? TextSpan(
                                      text: " others ",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontSize: 14.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    )
                                  : TextSpan(
                                      text: "",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontSize: 14.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    ),
                            ],
                    ),
                  )),
                  const SizedBox(height: 3),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      TextViewWrap.textView(
                          widget.userPostModal.dateTime,
                          TextAlign.start,
                          isTop
                              ? AppConstants.colorStyle.darkBlue
                              : AppConstants.colorStyle.white,
                          12.0,
                          FontWeight.normal),
                      const SizedBox(width: 2),
                      isTop
                          ? Image.asset(
                              "assets/newDesignIcon/connections/time_icon_grey.png",
                              width: 10.0,
                              height: 10.0,
                            )
                          : Image.asset(
                              "assets/time_ago_icon.png",
                              width: 10.0,
                              height: 10.0,
                            )
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _loader(BuildContext context) => Center(
          child: Container(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.cover,
        ),
      ));

  Widget _error() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill,
      ),
    );
  }

  showWhoCanSeeYourPostPopup() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        builder: (BuildContext bc) {
          return StatefulBuilder(builder: (context, state) {
            return Scaffold(
                backgroundColor: ColorValues.WHITE,
                body: SafeArea(
                  child: Stack(
                    children: [
                      Container(
                        height: double.infinity,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(
                                    "assets/generateScript/script_background.png"),
                                fit: BoxFit.fill)),
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 40, left: 20, right: 20),
                        child: SizedBox(
                          height: 100,
                          width: double.infinity,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pop(context, 'pop');
                                },
                                child: Image.asset(
                                  "assets/generateScript/back.png",
                                  height: 32.0,
                                  width: 32.0,
                                ),
                              ),
                              const HelpButtonWidget(),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          margin: const EdgeInsets.only(top: 125),
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(30),
                                topRight: Radius.circular(30),
                              ),
                            ),
                            child: Column(
                              children: [
                                const SizedBox(height: 25),
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 20, right: 20),
                                  alignment: Alignment.centerLeft,
                                  width: MediaQuery.of(context).size.width,
                                  child: Text(
                                      AppConstants
                                          .stringConstant.whoCanSeeYourPost,
                                      style: AppConstants.txtStyle
                                          .heading28_700LatoRegularDarkBlue),
                                ),
                                const SizedBox(height: 40),
                                Expanded(
                                  child: SingleChildScrollView(
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10),
                                      child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            27.0,
                                                            10.0,
                                                            11.0,
                                                            10.0,
                                                            Image.asset(
                                                              "assets/feed/community.png",
                                                              width: 26.0,
                                                              height: 26.0,
                                                              color: isType == "Community"
                                                                  ? ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR
                                                                  : ColorValues
                                                                      .HEADING_COLOR_EDUCATION,
                                                            )),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            8.0,
                                                            0.0,
                                                            3.0,
                                                            Text("Community",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType ==
                                                                        "Community"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            13.0,
                                                            Text(
                                                                "Visible to all spikeview community members.",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                selectedtScopeList.clear();
                                                groupidList.clear();
                                                isType = "Community";
                                                setState(() {});
                                              },
                                            ),
                                            CustomViews.getSeparatorLineNewUI(
                                                leftPadding: 20.0,
                                                rightPadding: 20.0,
                                                topPadding: 10.0,
                                                bottomPadding: 10.0),
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        27.0,
                                                        10.0,
                                                        11.0,
                                                        10.0,
                                                        Image.asset(
                                                            "assets/feed/group.png",
                                                            width: 26.0,
                                                            height: 26.0,
                                                            color: isType ==
                                                                    "Group"
                                                                ? ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue)),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            8.0,
                                                            0.0,
                                                            3.0,
                                                            Text("Group",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType == "Group"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            4.0,
                                                            13.0,
                                                            Text(
                                                                "Visible to all members in selected groups.",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onClickGroup();
                                              },
                                            ),
                                            CustomViews.getSeparatorLineNewUI(
                                                leftPadding: 20.0,
                                                rightPadding: 20.0,
                                                topPadding: 10.0,
                                                bottomPadding: 10.0),
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            27.0,
                                                            10.0,
                                                            11.0,
                                                            10.0,
                                                            Image.asset(
                                                              "assets/feed/connections.png",
                                                              width: 26.0,
                                                              height: 26.0,
                                                              color: isType == "AllConnections"
                                                                  ? ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR
                                                                  : AppConstants
                                                                      .colorStyle
                                                                      .darkBlue,
                                                            )),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            3.0,
                                                            Text("Connections",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType ==
                                                                        "AllConnections"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            13.0,
                                                            Text(
                                                                "Your connections on spikeview",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 0,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                selectedtScopeList.clear();
                                                groupidList.clear();
                                                isType = "AllConnections";
                                                setState(() {});
                                              },
                                            ),
                                            CustomViews.getSeparatorLineNewUI(
                                                leftPadding: 20.0,
                                                rightPadding: 20.0,
                                                topPadding: 10.0,
                                                bottomPadding: 10.0),
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            27.0,
                                                            10.0,
                                                            11.0,
                                                            10.0,
                                                            Image.asset(
                                                              "assets/feed/selected_connections.png",
                                                              width: 26.0,
                                                              height: 26.0,
                                                              // color: isType == "SelectedConnections"
                                                              //     ? ColorValues
                                                              //         .BLUE_COLOR_BOTTOMBAR
                                                              //     : AppConstants
                                                              //         .colorStyle
                                                              //         .darkBlue,
                                                            )),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            3.0,
                                                            Text(
                                                                "Selected Connections",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType ==
                                                                        "SelectedConnections"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            13.0,
                                                            Text(
                                                                "Only visible to some connections",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 0,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onTapTagSelectedConnection();
                                              },
                                            ),
                                            CustomViews.getSeparatorLineNewUI(
                                                leftPadding: 20.0,
                                                rightPadding: 20.0,
                                                topPadding: 10.0,
                                                bottomPadding: 10.0),
                                            InkWell(
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        27.0,
                                                        15.0,
                                                        11.0,
                                                        10.0,
                                                        Image.asset(
                                                            "assets/feed/private_lock.png",
                                                            width: 26.0,
                                                            height: 26.0,
                                                            color: isType ==
                                                                    "Private"
                                                                ? ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue)),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            3.0,
                                                            Text(
                                                                "Make it Private",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                style: isType ==
                                                                        "Private"
                                                                    ? AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularLightBlue
                                                                    : AppConstants
                                                                        .txtStyle
                                                                        .heading18600LatoRegularDarkBlue)),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            13.0,
                                                            Text(
                                                                "Only visible to me",
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                maxLines: 2,
                                                                style: AppConstants
                                                                    .txtStyle
                                                                    .heading16600LatoRegularLightPurple)),
                                                      ],
                                                    ),
                                                    flex: 0,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                Navigator.pop(context);
                                                selectedtScopeList.clear();
                                                groupidList.clear();
                                                selectedUerTagLIst1.clear();
                                                selectedUerTagLIst.clear();
                                                isType = "Private";
                                                setState(() {});
                                              },
                                            ),
                                          ]),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ));
          });
        }).then((value) => _closeModal(value));
  }

  void _closeModal(void value) {
    setState(() {
      //showSignupButton = true;
      //isOpenSignup = !isOpenSignup;
      // isOpenLogin = !isOpenLogin;
    });
  }

  onClickGroup() async {
    List<String> groupData = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => GroupListForPost(groupidList, widget.groupId)),
    );
    if (groupData != null && groupData.length > 0) {
      selectedtScopeList.clear();
      groupidList.clear();
      groupidList.addAll(groupData);
      isType = "Group";
      setState(() {});
    }
  }

  void onTapTagSelectedConnection() async {
    List<TagsPost> result = await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (BuildContext context) => AddMyConnectionSharePost(
          "Select Connections",
          selectedtScopeList,
        ),
      ),
    );
    if (result != null) {
      if (result != null && result.length > 0) {
        isType = "SelectedConnections";
        selectedtScopeList.clear();
        groupidList.clear();
        selectedtScopeList = result;
        setState(() {});
      }
    }
  }
}
