import 'dart:io';

class ProfileInfoModal {



  String _id,recommendationId,userId,recommenderId,
      competencyTypeId,level3Competency,level2Competency,title,request,recommendation,stage,interactionStartDate,interactionEndDate,__v;






}

class Assest{

  String type,tag,file;
}
class Skill{

  String label,skillId;
}

class Recommender{

  String recommender,_id,userId,firstName,lastName,email,password,salt,
      mobileNo,roleId,isActive,isPasswordChanged,organizationId,dob,title,tempPassword,isArchived,__v;
}