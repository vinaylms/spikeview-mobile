import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            leading: Container(
                child: Image.asset('assets/Vector 2.3.png', height: 15, width: 15)
            )

        ),
        body: Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(color: Color.fromRGBO(193, 227, 252, 1) ),
                margin: const EdgeInsets.only(left: 25, top: 26),
                child: Padding(
                  padding: const EdgeInsets.only(left: 17, top: 19),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 295,
                        child: Row(
                          children: [
                            Text('Participate in Leaderboard',
                                style: TextStyle(fontSize: 18, fontFamily: 'Nunito', fontWeight: FontWeight.w600)),
                            SizedBox(width: 20),
                            Image.asset('assets/Group 435.png', height: 19, width:34.22)

                          ],
                        ),
                      ),
                      SizedBox(height: 6),
                      Container(
                          height: 150,
                          width: 293,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                  text: TextSpan(
                                    text: 'Diam commodo, risus volutpat ante. ',
                                    style: TextStyle(fontSize: 14, fontFamily: 'Nunito', color: Colors.black),
                                  )
                              ),
                              SizedBox(height: 15),
                              Container(
                                  width: 293,
                                  child: Row(
                                    children: [
                                      Image.asset('assets/Ellipse 342.png', height: 6, width: 6),
                                      SizedBox(height: 19, width: 10),
                                      Container(
                                        width: 274,
                                        child: RichText(
                                            text: TextSpan(
                                              text: 'Ac amet non adipiscing, vitae, habitasse.',
                                              style: TextStyle(fontSize: 14, fontFamily: 'Nunito', color: Colors.black),
                                            )
                                        ),
                                      ),

                                    ],
                                  )
                              ),
                              SizedBox(height: 15),
                              Container(
                                  width: 293,
                                  child: Row(
                                    children: [
                                      Image.asset('assets/Ellipse 342.png', height: 6, width: 6),
                                      SizedBox(height: 19, width: 10),
                                      Container(
                                        width: 274,
                                        child: RichText(
                                            text: TextSpan(
                                              text: 'Ac amet non adipiscing, vitae, habitasse.',
                                              style: TextStyle(fontSize: 14, fontFamily: 'Nunito', color: Colors.black),
                                            )
                                        ),
                                      ),

                                    ],
                                  )
                              ),
                              SizedBox(height: 15),
                              Container(
                                  width: 293,
                                  child: Row(
                                    children: [
                                      Image.asset('assets/Ellipse 342.png', height: 6, width: 6),
                                      SizedBox(height: 19, width: 10),
                                      Container(
                                        width: 274,
                                        child: RichText(
                                            text: TextSpan(
                                              text: 'Ac amet non adipiscing, vitae, habitasse.',
                                              style: TextStyle(fontSize: 14, fontFamily: 'Nunito', color: Colors.black),
                                            )
                                        ),
                                      ),

                                    ],
                                  )
                              ),
                            ],
                          )

                      )
                    ],
                  ),
                ),
              ),

            ],
          ),
        )
    );
  }
}
