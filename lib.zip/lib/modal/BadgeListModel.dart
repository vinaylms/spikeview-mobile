import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class BadgeListModel {

  List<BadgeModel> requestedBadgeList;
  List<BadgeModel> collectionBadgeList;
  List<BadgeModel> presentBadgeList;
  List<BadgeModel> allBadgeList;
  BadgeListModel(this.requestedBadgeList, this.collectionBadgeList,
      this.presentBadgeList,this.allBadgeList);


}


class BadgeModel{
  int badgeReqId,badgeId;
  String message,badgeName,status,createdAt,badgeImage,userName,userImage,userTagline,companyName;
  bool isMore=false;
  int userId,userRoleId;
  String badge,type;
  String badgeImageGamification;
  int gamificationPoints;
  BadgeModel(this.badgeReqId, this.badgeId, this.message,
      this.badgeName, this.status, this.createdAt, this.badgeImage,this.userName,this.userImage,this.userTagline,this.companyName,this.userId, this.userRoleId,this.badge,this.gamificationPoints,this.badgeImageGamification,this.type);


}



