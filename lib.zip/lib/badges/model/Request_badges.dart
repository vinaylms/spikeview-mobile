import 'RequestResult.dart';

class RequestBadges {
  RequestBadges({
      this.status, 
      this.requestResult,
      this.totalCount,});

  RequestBadges.fromJson(dynamic json) {
    status = json['status'];
    if (json['result'] != null) {
      requestResult = [];
      json['result'].forEach((v) {
        requestResult.add(RequestResult.fromJson(v));
      });
    }
    totalCount = json['totalCount'];
  }
  String status;
  List<RequestResult> requestResult;
  int totalCount;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    if (requestResult != null) {
      map['result'] = requestResult.map((v) => v.toJson()).toList();
    }
    map['totalCount'] = totalCount;
    return map;
  }

}