import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class TimeZoneModal {

  String status;
  List<TimeZone> timeZoneList;

  TimeZoneModal({this.status, this.timeZoneList});

  TimeZoneModal.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      timeZoneList =  List<TimeZone>();
      json['result'].forEach((v) {
        timeZoneList.add(new TimeZone.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.timeZoneList != null) {
      data['result'] = this.timeZoneList.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class TimeZone {
  int zoneId;
  String countryCode;
  String zoneName;
  String offset;
  String dst;

  TimeZone({this.zoneId, this.countryCode, this.zoneName, this.offset, this.dst});

  TimeZone.fromJson(Map<String, dynamic> json) {
    zoneId = json['zoneId'];
    countryCode = json['countryCode'];
    zoneName = json['zone_name'];
    offset = json['offset'];
    dst = json['dst'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['zoneId'] = this.zoneId;
    data['countryCode'] = this.countryCode;
    data['zone_name'] = this.zoneName;
    data['offset'] = this.offset;
    data['dst'] = this.dst;
    return data;
  }
}
