import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_multiline_text_form.dart';
import 'package:spike_view_project/constant/style.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/recommendation/EditRecommendationPerformance.dart';

import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/recommendation/recommendationReply/ThankYouPage.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/remove_button.dart';
import 'package:url_launcher/url_launcher.dart';

class HeroDialogRoute<T> extends PageRoute<T> {
  HeroDialogRoute({this.builder}) : super();

  final WidgetBuilder builder;

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => true;

  @override
  Duration get transitionDuration => const Duration(milliseconds: 300);

  @override
  bool get maintainState => true;

  @override
  Color get barrierColor => Colors.black54;

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    return FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
        child: child);
  }

  @override
  Widget buildPage(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation) {
    return builder(context);
  }

  // TODO: implement barrierLabel
  @override
  String get barrierLabel => null;
}

// Create a Form Widget
class RecommendationReuest extends StatefulWidget {
  Recomdation recomdation;
  final ProfileData studentProfile;

  RecommendationReuest(
    this.recomdation, {
    this.studentProfile,
  });

  @override
  RecommendationReuestState createState() {
    return RecommendationReuestState(recomdation);
  }
}

class RecommendationReuestState extends State<RecommendationReuest> {
  Recomdation recomdation;

  RecommendationReuestState(this.recomdation);

//  ProfileInfoModal profileInfoModal;
  bool isParent = false;
  bool isSubmitRecommendation = true;
  SharedPreferences prefs;
  String userIdPref, token, roleId;
  List<Skill> skeelSelectedList = List();
  String strTitle = "", fileName = "", strRequest = "", strCompetency = "";
  String strSkills = "",
      strYear = "",
      strEndYear = "",
      appliedFilter = "",
      filterData = "";
  DateTime date;
  String url = "", strRecommendation = "", strPrefixPathforPhoto;
  final _formKey = GlobalKey<FormState>();
  File imagePath;
  String selectedImageType = "media";
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String sasToken, containerName;
  List<AcvhievmentSkillModel> skillList = List();
  bool isMedaiDialog = false;
  List<Assest> assestList = List();

  bool _showInvalidFileError = false;
  List<String> mediaDocumentList = [];


  Future apiCallMaster() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_MASTER_DATA, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              skillList.clear();
              prefs.setString(
                  "skill", json.encode(response.data['result']['skills']));

              skillList = ParseJson.parseMapSkillList(
                  response.data['result']['skills']);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Map<int, bool> filterStatus = Map();
  TextEditingController addSummary;

  getSharedPreferences() async {
    print("recomdation.user.tagline ${recomdation.user.tagline}");
    prefs = await SharedPreferences.getInstance();
    if (widget.studentProfile != null) {
      userIdPref = widget.studentProfile.userId;
      roleId = widget.studentProfile.roleId;
    } else {
      userIdPref = prefs.getString(UserPreference.USER_ID);
      roleId = prefs.getString(UserPreference.ROLE_ID);
    }
    token = prefs.getString(UserPreference.USER_TOKEN);
    isParent = prefs.getBool("isParent");
    if (isParent == null) {
      isParent = false;
    }
    addSummary = TextEditingController(
        text: strRecommendation != "null" ? strRecommendation : "");
    setState(() {});

    addSummary.addListener(() {
      setState(() {});
    });

    await callApiForSaas();

    try {
      if (prefs.getString("skill") == null) {
        await apiCallMaster();
      } else {
        final skill = json.decode(prefs.getString("skill"));
        if (skill == null || skill.length == 0) {
          await apiCallMaster();
        } else {
          skillList.clear();
          skillList = ParseJson.parseMapSkillList(skill);
          if (skillList.length > 0) {
            for (int i = 0; i < skillList.length; i++) {
              filterStatus[i] = false;
            }
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }

    skeelSelectedList.addAll(recomdation.skillList);

    if (recomdation != null) {
      strTitle = recomdation.title == "null" ? "" : recomdation.title;
      strCompetency = recomdation.focusArea == null ||
              recomdation.focusArea == "null" ||
              recomdation.focusArea == ""
          ? recomdation.level3Competency
          : recomdation.focusArea;

      strRequest = recomdation.request;
      setState(() {});
      for (int i = 0; i < skillList.length; i++) {
        for (int j = 0; j < recomdation.skillList.length; j++) {
          if (skillList[i].title == recomdation.skillList[j].label) {
            filterStatus[i] = true;
            if (appliedFilter == "") {
              appliedFilter = skillList[i].title;
            } else {
              appliedFilter = appliedFilter + "," + skillList[i].title;
            }
          }
        }
      }
    }

    if (recomdation != null) {
      if (recomdation.interactionStartDate != "null") {
        int d = int.tryParse(recomdation.interactionStartDate);
        date = DateTime.fromMillisecondsSinceEpoch(d);
        var formatter = DateFormat('MMM dd, yyyy');
        strYear = formatter.format(date);
      }
      if (recomdation.interactionEndDate != "null") {
        int d = int.tryParse(recomdation.interactionEndDate);
        date = DateTime.fromMillisecondsSinceEpoch(d);
        var formatter = DateFormat('MMM dd, yyyy');
        strEndYear = formatter.format(date);
      } else {
        // var formatter =  DateFormat('MMM, yyyy');
        // strEndYear = formatter.format(new DateTime.now());
        strEndYear = "Ongoing";
      }
      setState(() {});
    }

    assestList.addAll(recomdation.mediaVideoList);

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
  }

  onBack() async {
    Navigator.pop(context);
  }

  void _showInfoDialog(String msg) {
    showModalBottomSheet(
        isDismissible: false,
        backgroundColor: Colors.transparent,
        context: context,
        builder: (_) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.all(10.0),
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                  ),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [

                      const SizedBox(height: 10),
                      BaseText(
                        text: msg,
                        textAlign: TextAlign.center,
                        textColor: Color(0xff666B9A),
                        fontSize: 14,
                        fontFamily: Constant.latoRegular,
                        fontWeight: FontWeight.w400,
                      ),
                      const SizedBox(height: 10),

                    ],
                  ),
                ),
                const SizedBox(height: 12),
                InkWell(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    alignment: Alignment.center,
                    child: BaseText(
                      text: "OK",
                      textAlign: TextAlign.center,
                      textColor: Color(0xff27275A),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      fontFamily: Constant.latoRegular,
                    ),
                  ),
                  onTap: () {
                    Timer _timer;
                    _timer = Timer(const Duration(milliseconds: 1000), () async {
                      print("timer off");
                      Navigator.pop(context);
                      Navigator.pop(context, "push");
                    });
                  },
                ),
              ],
            ),
          );
        });
  }


  showSucessMsg(msg, context) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 15.0),
                child: Image.asset(
                  "assets/recommendation/green_tick_circle.png",
                  height: 70.0,
                  width: 69.0,
                ),
              ),
              SizedBox(height: 16.0),
              Text(
                MessageConstant.RECOMMENDATION_SUBMIT,
                textAlign: TextAlign.center,
                maxLines: 3,
                style:
                    TextStyle(fontSize: 16.0, color: ColorValues.RADIO_BLACK),
              ),
              Padding(
                  padding: EdgeInsets.only(
                      left: 20.0, top: 20.0, right: 20.0, bottom: 15.0),
                  child: InkWell(
                    child: Container(
                        height: 44.0,
                        width: 100.0,
                        color: ColorValues.BLUE_COLOR,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              MessageConstant.OK,
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 20.0,
                              ),
                            )
                          ],
                        )),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pop(context, "push");
                    },
                  ))
            ],
          ),
        );
      },
    );
  }

  Future apiCall() async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "recommenderId": recomdation.recommenderId,
        "recommendationId": recomdation.recommendationId,
        "stage": "Replied",
        "recommendation": strRecommendation,
        "recommenderFile": url,
        "recommenderFileName": fileName,
        "repliedDate": DateTime.now().millisecondsSinceEpoch.toString(),
        "skills": skeelSelectedList.map((item) => item.toJson()).toList(),
        "asset": recomdation.assestList.map((item) => item.toJson()).toList()
      };

      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_RECOMENDATION, map);
      CustomProgressLoader.cancelLoader(context);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            //  ToastWrap.showToast(msg);

            _showInfoDialog(msg);
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  @override
  void initState() {
    try {
      getSharedPreferences();
      // TODO: implement initState

    } catch (e) {
      e.toString();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey we created above
    Constant.applicationContext = context;


    void conformationDialog() {
      showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: "Are you sure you want to delete?",
            onPositiveTap: (){
              url = "";
              setState(() {});
            },
          );
        },
      );
    }



    void conformationDialogold() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => SafeArea(
              child: Scaffold(
                  backgroundColor: Colors.black38,
                  body: Stack(
                    children: <Widget>[
                      Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 40.0,
                          child: Container(
                              height: 200.0,
                              color: Colors.transparent,
                              child: Stack(
                                children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                      13.0,
                                      20.0,
                                      13.0,
                                      0.0,
                                      ListView(children: <Widget>[
                                        Container(
                                          height: 145.0,
                                          padding: EdgeInsets.all(10.0),
                                          width: double.infinity,
                                          color: Colors.white,
                                          child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: <Widget>[
                                                Text(
                                                  "Are you sure you want to delete?",
                                                  textAlign: TextAlign.center,
                                                  maxLines: 5,
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      height: 1.2,
                                                      fontSize: 16.0,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                ),
                                              ]),
                                        )
                                      ])),
                                ],
                              ))),
                      Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 10.0,
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: PaddingWrap.paddingfromLTRB(
                              13.0,
                              0.0,
                              13.0,
                              0.0,
                              Container(
                                  color: Colors.white,
                                  padding: EdgeInsets.all(10.0),
                                  height: 51.0,
                                  child: Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: InkWell(
                                          child: Container(
                                              child: Text(
                                            "Cancel",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color:
                                                    ColorValues.GREY_TEXT_COLOR,
                                                fontSize: 16.0,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMREGULAR),
                                          )),
                                          onTap: () {
                                            Navigator.pop(context);
                                          },
                                        ),
                                        flex: 1,
                                      ),
                                      Expanded(
                                        child: InkWell(
                                          child: Container(
                                              child: Text(
                                            "Remove",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .BLUE_COLOR_BOTTOMBAR,
                                                fontSize: 16.0,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMREGULAR),
                                          )),
                                          onTap: () {
                                            Navigator.pop(context);
                                            url = "";
                                            setState(() {});
                                          },
                                        ),
                                        flex: 1,
                                      )
                                    ],
                                  ))),
                        ),
                      ),
                    ],
                  ))));
    }

    Widget _uploadedItem() {
      // final item = addUploadedFileList[index];
      return Padding(
        padding: const EdgeInsets.only(left: 20, right: 20,top: 15),
        child: SizedBox(
          height: 121,
          child: Stack(
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(18, 25, 18, 26),
                margin: EdgeInsets.only(top: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Color(0xffD4E4FF), width: 1),
                ),
                child: Row(
                  children: [
                    Image.asset(
                      "assets/resume/ic_doc_pdf.png",
                      height: 58,
                      width: 58,
                      fit: BoxFit.fill,
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  fileName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Color(0xff27275A),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 24),
                              Text(
                                '100%',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Color(0xff666B9A),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 13),
                          Text(
                            'Uploaded successful',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.green,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(width: 14),
                    Image.asset(
                      "assets/resume/ic_green_checked.png",
                      height: 25,
                      width: 25,
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: InkWell(
                  onTap: () {
                    conformationDialog();
                  },
                  child: Image.asset(
                    'assets/profile/skills/red_close.png',
                    height: 25,
                    width: 25,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    Container writeRecommendation() {
      return Container(
          child: Padding(
              padding: EdgeInsets.only(
                  left: 10.0, top: 40.0, right: 10.0, bottom: 20.0),
              child: Container(
                  height: 50.0,
                  child: FlatButton(
                    onPressed: () {
                      setState(() {
                        isSubmitRecommendation = true;
                      });
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0)),
                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                    child: Row(
                      // Replace with a Row for horizontal icon + text
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text('Write recommendation',
                            style: TextStyle(
                                fontSize: 14.0,
                                fontWeight: FontWeight.w600,
                                fontFamily: Constant.latoMedium,
                                color: Colors.white)),
                      ],
                    ),
                  ))));
    }

    Container submitRecommendation() {
      return Container(
          child: Padding(
              padding: EdgeInsets.only(
                  left: 0.0, top: 40.0, right: 0.0, bottom: 20.0),
              child: Container(
                  height: 50.0,
                  child: FlatButton(
                    onPressed: () {
                      final form = _formKey.currentState;
                      form.save();
                      if (form.validate()) {
                        if (appliedFilter == "") {
                          ToastWrap.showToast(
                              MessageConstant.SELECT_SKILLS_VAL, context);
                          return false;
                        } else {


                          apiCall();
                        }
                      }
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                    child: Row(
                      // Replace with a Row for horizontal icon + text
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text('Submit recommendation',
                            style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.w600,
                                fontFamily: Constant.latoMedium,
                                color: Colors.white)),
                      ],
                    ),
                  ))));
    }

    final recommendation = PaddingWrap.paddingfromLTRB(
        20.0,
        10.0,
        20.0,
        0.0,
        Container(
            color: Colors.transparent,
            child:

            CustomMultilineTextForm(
              textInputType: TextInputType.text,
             // label: 'Bio',
              hint: 'Start typing the recommendation.....',
              maxLength:2000,
              maxLines:4,
              // onType: (val) => _checkStepOneValidaiton(),

              alignLabelWithHint: true,
             // focusNode: _bioFocus,
              controller: addSummary,


              validation: (val) => val.trim().isEmpty
                  ? url != ""
                  ? null
                  : 'Please enter the details of recommendation.'
                  : null,

              // onClick: (){
              //   generateChipsForOther();
              //   //add  _checkAccomplishmentsValidation();
              // },

              onSaved: (val) => strRecommendation = val,

            ),


        ));

    final mediaImageListUI = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 0.0,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: assestList.map((path) {
        if (path.type == "video") {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 54.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: VideoApp(Constant.IMAGE_PATH + path.file)),
              onTap: () {},
            )
          ]);
        } else {
          return Stack(
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  FadeInImage.assetNetwork(
                    fit: BoxFit.cover,
                    placeholder: 'assets/aerial/default_img.png',
                    image: Constant.IMAGE_PATH + path.file,
                    height: 54.0,
                    width: 54.0,
                  )
                ],
              ),

            ],
          );
        }
      }).toList(),
    ));

    _buildChoiceList() {
      List<Widget> choices = List();
      skeelSelectedList.forEach((item) {
        choices.add(Container(
            padding: const EdgeInsets.only(bottom: 2.0),
            child: Row(
              children: <Widget>[
                Flexible(
                  child: Text(
                    item.label,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontSize: 14.0,
                        fontWeight: FontWeight.w400,
                        fontFamily: Constant.latoRegular),
                  ),
                  flex: 1,
                )

                ,
              ],
            ) /*ChoiceChip(
            selectedColor: Colors.transparent,

            label: Wrap(
              children: <Widget>[
                 Row(children: <Widget>[
                   Flexible(child:     Text(
                   item.label,overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),flex: 1,)
                  ,
           Expanded(child:   PaddingWrap.paddingfromLTRB(
                      5.0,
                      3.0,
                      0.0,
                      0.0,
                       Icon(
                        Icons.cancel,
                        color:  ColorValues.BG_CIRCLE_COLOR,
                        size: 17.0,
                      )),flex: 0,),
                ],)

              ],
            ),
            selected: true,
            onSelected: (selected) {
              setState(() {
                skeelSelectedList.remove(item);
                filterStatus[item.index] = false;
              });
              filterData = "";
              appliedFilter = "";
              skeelSelectedList.clear();
              filterStatus.forEach(iterateFilters);
            },
          ),*/
            ));
      });
      return choices;
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      setState(() {});
      fileName = imagePath.split('/').last;
      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        url = strPrefixPathforPhoto + strAzureImageUploadPath;
        print("url+++++" + url);
        setState(() {
          url;
        });
        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    getDocuments() async {
      try {
        // Platform messages may fail, so we use a try/catch PlatformException.
        try {
          FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
            allowedFileExtensions: ['pdf'],
            allowedMimeTypes: [
              'application/pdf',
              'application/msword',
              'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            ],
            invalidFileNameSymbols: ['/'],
          );

          String path =
              await FlutterDocumentPicker.openDocument(params: params);

          if (path != null && path != "") {
            if ((Util.getFileExtension(path) == ".pdf") && path != null) {
              CustomProgressLoader.showLoader(context);
              _showInvalidFileError = false ;
              Timer _timer = Timer(const Duration(milliseconds: 400), () {


                checkMediaAndUpload(
                    imagePath: path
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    type: "doc");
              });
            } else {

              _showInvalidFileError = true ;

              setState(() {

              });

              // ToastWrap.showToast(
              //     MessageConstant.INVALID_FILE_FORMAT_VAL, context);
            }
          }
        } catch (e) {
          _showInvalidFileError = true ;

          setState(() {

          });

          // ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
        }
      } catch (e) {
        _showInvalidFileError = true ;

        setState(() {

        });

        //ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
      }
    }


    mediaRecomendationSection() {
      return Padding(
        padding:
            const EdgeInsets.only(top: 10, bottom: 10, left: 20, right: 20),
        child: Column(
          children: [
            InkWell(
              onTap: () {
                if (url == "") getDocuments();
              },
              child: Stack(
                alignment: Alignment.center,
                overflow: Overflow.visible,
                children: [
                  Column(
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: 96,
                        child: Column(
                          children: [
                            const SizedBox(height: 18),
                            Image.asset(
                              "assets/recommendation/recommendation.png",
                              height: 26.0,
                              width: 25.0,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              'Upload your recommendation letter',
                              maxLines: 1,
                              textAlign: TextAlign.center,
                              style: AppConstants
                                  .txtStyle.heading14400LatoItalicLightPurple,
                            ),
                          ],
                        ),
                        decoration: BoxDecoration(
                          color: AppConstants.colorStyle.box_bg_color,
                          border: Border.all(color: Color(0XFFC9CDE2)),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(10)),
                        ),
                      ),
                      SizedBox(
                        height: 12,
                      )
                    ],
                  ),
                  // gridSelectedImagesVideos(),
                  Positioned(
                    bottom: 0,
                    child: InkWell(
                      radius: 50,
                      onTap: () {
                        if (url == "") getDocuments();
                      },
                      child: Image.asset(
                        "assets/generateScript/plus_icon.png",
                        height: 26.0,
                        width: 25.0,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return WillPopScope(
        onWillPop: () {
          print('recomdation.user.tagline- ${recomdation.user.tagline}');
          onBack();
          return Future.value(false);
        },
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerFloat,
            backgroundColor: ColorValues.SCREEN_BG_COLOR,
            /* appBar:  AppBar(
              elevation: 0.0,
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child:  InkWell(
                      child: CustomViews.getBackButton(),
                      onTap: () {
                        onBack();
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child:  Text(
                      "Recommendations",
                      textAlign: TextAlign.center,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  )
                ],
              ),
              /* actions: <Widget>[
                 Container(
                  width: 30.0,
                )
              ],*/
              backgroundColor: Colors.white,
            ),


            */

            body: Stack(
              children: <Widget>[
                Container(
                  height: double.infinity,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                              "assets/generateScript/script_background.png"),
                          fit: BoxFit.fill)),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 40, left: 20, right: 20),
                  child: SizedBox(
                    height: 103,
                    width: double.infinity,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {
                            onBack();
                            // Navigator.pop(context, isPerformChnges);
                          },
                          child: Image.asset(
                            "assets/generateScript/back.png",
                            height: 32.0,
                            width: 32.0,
                          ),
                        ),
                        Image.asset(
                          "assets/generateScript/help.png",
                          height: 32.0,
                          width: 32.0,
                        ),
                      ],
                    ),
                  ),
                ),

                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                      ),
                    ),
                    margin: const EdgeInsets.only(top: 115),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 4),
                          Expanded(
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(30),
                                  topRight: Radius.circular(30),
                                ),
                              ),
                              child: Form(
                                  key: _formKey,
                                  child: recomdation == null
                                      ? Container()
                                      : ListView(
                                          children: <Widget>[
                                            Container(
                                              margin: const EdgeInsets.only(
                                                  left: 0, right: 10, top: 0),
                                              alignment: Alignment.centerLeft,
                                              width: MediaQuery.of(context)
                                                  .size
                                                  .width,
                                              color: Colors.white,
                                              child: RichText(
                                                text: TextSpan(children: [
                                                  TextSpan(
                                                      text:
                                                          'Add recommendation',
                                                      style: AppConstants
                                                          .txtStyle
                                                          .heading28_700LatoRegularDarkBlue),
                                                  TextSpan(
                                                      recognizer:
                                                          TapGestureRecognizer()
                                                            ..onTap = () {},
                                                      text: '',
                                                      style: AppConstants
                                                          .txtStyle
                                                          .heading26_700LatoRegularDarkBlue)
                                                ]),
                                              ),
                                            ),
                                            recomdation.stage == "Replied" ||
                                                    recomdation.stage == "Added"
                                                ? Column(
                                                    children: <Widget>[
                                                      Container(
                                                          child: Center(
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                30.0,
                                                                0.0,
                                                                0.0,
                                                                Text(
                                                                  "Recommendation already submitted successfully ",
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: TextStyle(
                                                                      color: Colors
                                                                          .green,
                                                                      fontFamily:
                                                                          "customRegualr",
                                                                      fontSize:
                                                                          18.0),
                                                                )),
                                                      ))
                                                    ],
                                                  )
                                                : Container(
                                                    color: Colors.white,
                                                    child: Column(
                                                      children: <Widget>[

                                                        Padding(
                                                          padding: const EdgeInsets.only(left: 0,right: 0,top: 30,bottom: 10),
                                                          child: Row(
                                                            children: <Widget>[




                                                              Expanded(
                                                                child: Stack(
                                                                  children: <Widget>[

                                                                    InkWell(
                                                                      child: ProfileImageView(
                                                                        imagePath: recomdation.user.profilePicture == "null" ? "" : Constant.IMAGE_PATH + recomdation.user.profilePicture,
                                                                        placeHolderImage: 'assets/profile/user_on_user.png',
                                                                        height: 60.0,
                                                                        width: 60.0,
                                                                        onTap: () async{

                                                                        },
                                                                      ),


                                                                      // ClipOval(
                                                                      //     child: FadeInImage
                                                                      //         .assetNetwork(
                                                                      //       fit: BoxFit.cover,
                                                                      //       width: 60.0,
                                                                      //       height: 60.0,
                                                                      //       placeholder:
                                                                      //       'assets/profile/user_on_user.png',
                                                                      //       image:recomdation.user.profilePicture == "null" ? "" : Constant.IMAGE_PATH + recomdation.user.profilePicture,
                                                                      //     )),

                                                                      onTap: () {

                                                                      },
                                                                    ),
                                                                  ],
                                                                ),
                                                                flex: 0,
                                                              ),

                                                              Expanded(
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                    CrossAxisAlignment.start,
                                                                    mainAxisAlignment:
                                                                    MainAxisAlignment.center,
                                                                    children: <Widget>[

                                                                      PaddingWrap.paddingfromLTRB(
                                                                        12.0,
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        RichText(
                                                                          textAlign:
                                                                          TextAlign.center,
                                                                          text: TextSpan(
                                                                            text: "",
                                                                            //MessageConstant  .ADD_RECOMMENDATION_FROM,
                                                                            style: TextStyle(
                                                                                color: ColorValues
                                                                                    .HEADING_COLOR_EDUCATION,
                                                                                height: 1.2,
                                                                                fontSize: 18.0,
                                                                                fontWeight:
                                                                                FontWeight
                                                                                    .w600,
                                                                                fontFamily: Constant
                                                                                    .latoMedium),
                                                                            children: <TextSpan>[
                                                                              TextSpan(
                                                                                text: recomdation.user.firstName == "null"
                                                                                    ? ""
                                                                                    : recomdation.user.firstName != "null"
                                                                                    ? recomdation.user.lastName != "null"
                                                                                    ? recomdation.user.firstName + " " + recomdation.user.lastName
                                                                                    : recomdation.user.firstName
                                                                                    : "" + recomdation.user.lastName,
                                                                                style: TextStyle(
                                                                                    color: ColorValues
                                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                                    fontSize:
                                                                                    18.0,
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w600,
                                                                                    fontFamily:
                                                                                    Constant
                                                                                        .latoMedium),
                                                                              )
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      recomdation.user.tagline != null &&  recomdation.user.tagline != "" && recomdation.user.tagline != "null"?
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          12.0,
                                                                          2.0,
                                                                          0.0,
                                                                          0.0,
                                                                          PaddingWrap.paddingAll(2.0,
                                                                            TextViewWrap.textViewMultiLinelato(
                                                                                recomdation.user.tagline == "null" ? "" : recomdation.user.tagline,
                                                                                //recomdation.user.tagline
                                                                                TextAlign.start,
                                                                                ColorValues
                                                                                    .labelColor,
                                                                                12.0,
                                                                                FontWeight
                                                                                    .w400,
                                                                              3

                                                                            ),
                                                                          )) : Container(),

                                                                    ],
                                                                  ),
                                                                  flex: 1),


                                                            ],
                                                          ),
                                                        ),
                                                        /*

                                                        PaddingWrap.paddingAll(
                                                            0.0,
                                                            Container(
                                                             // color: Colors.red,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: <
                                                                    Widget>[
                                                                  /*  TextViewWrap.textView(
                                                                                "REQUEST FOR RECOMMENDATION",
                                                                                TextAlign.start,
                                                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                                                12.0,
                                                                                FontWeight.normal),*/

                                                                  PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          0.0,
                                                                          30.0,
                                                                          0.0,
                                                                          10.0,
                                                                          Row(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: <Widget>[
                                                                              Expanded(
                                                                                child: ClipOval(
                                                                                    child: FadeInImage.assetNetwork(
                                                                                  fit: BoxFit.cover,
                                                                                  placeholder: 'assets/profile/user_on_user.png',
                                                                                  image: recomdation.user.profilePicture == "null" ? "" : Constant.IMAGE_PATH + recomdation.user.profilePicture,
                                                                                  height: 60.0,
                                                                                  width: 60.0,
                                                                                )),
                                                                                flex: 0,
                                                                              ),
                                                                              Expanded(
                                                                                child: PaddingWrap.paddingfromLTRB(
                                                                                    5.0,
                                                                                    0.0,
                                                                                    0.0,
                                                                                    0.0,
                                                                                    Column(
                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                      children: <Widget>[
                                                                                        Padding(
                                                                                          padding: const EdgeInsets.only(bottom: 10),
                                                                                          child: Row(
                                                                                            children: <Widget>[

                                                                                              PaddingWrap.paddingfromLTRB(
                                                                                                5.0,
                                                                                                0.0,
                                                                                                2.0,
                                                                                                0.0,
                                                                                                TextViewWrap.textView(
                                                                                                    recomdation.user.firstName == "null"
                                                                                                        ? ""
                                                                                                        : recomdation.user.firstName != "null"
                                                                                                            ? recomdation.user.lastName != "null"
                                                                                                                ? recomdation.user.firstName + " " + recomdation.user.lastName
                                                                                                                : recomdation.user.firstName
                                                                                                            : "" + recomdation.user.lastName,
                                                                                                    TextAlign.start,
                                                                                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                                                    18.0,
                                                                                                    FontWeight.bold),
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                        ),
                                                                                        PaddingWrap.paddingfromLTRB(
                                                                                          6.0,
                                                                                          0.0,
                                                                                          0.0,
                                                                                          10.0,
                                                                                          TextViewWrap.textViewMultiLine(recomdation.user.tagline == "null" ? "" : recomdation.user.tagline, TextAlign.start, ColorValues.labelColor, 12.0, FontWeight.normal, 3),
                                                                                        ),
                                                                                      ],
                                                                                    )),
                                                                                flex: 1,
                                                                              )
                                                                            ],
                                                                          )),
                                                                  // Divider(
                                                                  //   height: 2.0,
                                                                  //   color: ColorValues.GRAY_HEADER_PRESSO_VIEW,
                                                                  // )
                                                                ],
                                                              ),
                                                            )),

                                                        */
                                                        recomdation != null
                                                            ? PaddingWrap
                                                                .paddingfromLTRB(
                                                                    0.0,
                                                                    10.0,
                                                                    5.0,
                                                                    10.0,
                                                                    Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: <
                                                                          Widget>[
                                                                        PaddingWrap
                                                                            .paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          5.0,
                                                                          Text(
                                                                              "“$strRequest”",
                                                                              maxLines:
                                                                              recomdation.isMore
                                                                                  ? 30
                                                                                  : 3,
                                                                              overflow:
                                                                              TextOverflow
                                                                                  .ellipsis,
                                                                              style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION_1, fontSize: 16.0, fontFamily: Constant.latoRegular)),
                                                                        ),

                                                                        recomdation.request.length >
                                                                            100
                                                                            ? InkWell(
                                                                          child: Padding(
                                                                              padding: const EdgeInsets.only(top: 0.0, left: 0.0, right: 0,bottom: 10),
                                                                              child: Text(
                                                                                recomdation.isMore ? "Less" : "More",
                                                                                maxLines: 1,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                style: TextStyle(
                                                                                  fontWeight: FontWeight.w400,
                                                                                  fontSize: 14,
                                                                                  color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                                ),
                                                                              )),
                                                                          onTap:
                                                                              () {
                                                                            if (recomdation.isMore)
                                                                              recomdation.isMore = false;
                                                                            else
                                                                              recomdation.isMore = true;
                                                                            setState(() {
                                                                              recomdation.isMore;
                                                                            });
                                                                          },
                                                                        )
                                                                            : Container(
                                                                          height:
                                                                          10.0,
                                                                        ),

                                                                        recomdation.title.isNotEmpty && recomdation.title == null ?

                                                                        PaddingWrap.paddingfromLTRB(
                                                                            0.0,
                                                                            5.0,
                                                                            0.0,
                                                                            3.0,
                                                                            TextViewWrap.textView(
                                                                                "Title",
                                                                                TextAlign.start,
                                                                                ColorValues.labelColor,
                                                                                12.0,
                                                                                FontWeight.w400)) : const SizedBox(),

                                                                        recomdation.title.isNotEmpty && recomdation.title == null ?

                                                                        TextViewWrap.textView(
                                                                            recomdation.title,
                                                                            TextAlign.start,
                                                                            ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                            14.0,
                                                                            FontWeight.w400) : const SizedBox(),


                                                                        PaddingWrap.paddingfromLTRB(
                                                                            0.0,
                                                                            20.0,
                                                                            0.0,
                                                                            3.0,
                                                                            TextViewWrap.textView(
                                                                                "Focus area",
                                                                                TextAlign.start,
                                                                                ColorValues.labelColor,
                                                                                12.0,
                                                                                FontWeight.w400)),
                                                                        TextViewWrap.textView(
                                                                            strCompetency,
                                                                            TextAlign.start,
                                                                            ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                            14.0,
                                                                            FontWeight.w400),
                                                                        // competencyUi,

                                                                        PaddingWrap.paddingfromLTRB(
                                                                            0.0,
                                                                            20.0,
                                                                            0.0,
                                                                            0.0,
                                                                            Row(
                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: <Widget>[
                                                                                Expanded(
                                                                                  child: TextViewWrap.textView("Skills", TextAlign.start, ColorValues.labelColor, 12.0, FontWeight.w400),
                                                                                  flex: 1,
                                                                                ),
                                                                              ],
                                                                            )),
                                                                        PaddingWrap.paddingfromLTRB(
                                                                            0.0,
                                                                            5.0,
                                                                            0.0,
                                                                            20.0,
                                                                            Row(
                                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: <Widget>[
                                                                                Expanded(
                                                                                  child: Wrap(
                                                                                    children: _buildChoiceList(),
                                                                                  ),
                                                                                  flex: 1,
                                                                                ),
                                                                              ],
                                                                            )),

                                                                        PaddingWrap.paddingfromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            5.0,
                                                                            TextViewWrap.textView(
                                                                              "Interaction date",
                                                                              TextAlign.start,
                                                                              ColorValues.labelColor,
                                                                              12.0,
                                                                              FontWeight.w400,
                                                                            )),

                                                                        TextViewWrap.textView(
                                                                            strYear +
                                                                                " - " +
                                                                                strEndYear,
                                                                            TextAlign.start,
                                                                            ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                            14.0,
                                                                            FontWeight.w400),

                                                                        assestList.length >
                                                                                0
                                                                            ? PaddingWrap.paddingfromLTRB(
                                                                                0.0,
                                                                                10.0,
                                                                                0.0,
                                                                                10.0,
                                                                                Text(
                                                                                  "Media",
                                                                                  style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION_1, fontSize: 12.0, fontFamily: Constant.latoRegular, fontWeight: FontWeight.w400),
                                                                                ))
                                                                            : Container(
                                                                                height: 0.0,
                                                                              ),
                                                                        assestList.length >
                                                                                0
                                                                            ? mediaImageListUI
                                                                            : Container(
                                                                                height: 15.0,
                                                                              ),
                                                                      ],
                                                                    ))
                                                            : Container(
                                                                height: 0.0,
                                                              ),

                                                        isSubmitRecommendation
                                                            ? PaddingWrap
                                                                .paddingfromLTRB(
                                                                0.0,
                                                                0.0,
                                                                20.0,
                                                                15.0,
                                                                Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                        "Add / Upload recommendation",
                                                                        maxLines:
                                                                            30,
                                                                        style: TextStyle(
                                                                            color: ColorValues
                                                                                .HEADING_COLOR_EDUCATION_1,
                                                                            fontSize:
                                                                                18.0,
                                                                            fontFamily:
                                                                                Constant.latoMedium,
                                                                            fontWeight: FontWeight.w600)),
                                                                  ],
                                                                ),
                                                              )
                                                            : Container(
                                                                height: 0.0,
                                                              ),

                                                        //gray view
                                                        Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color: Color(
                                                                  0xffF5F6FA),
                                                              border: Border.all(
                                                                  width: 1.0,
                                                                  color: Color(
                                                                      0xffE5EBF0)),
                                                              borderRadius: BorderRadius
                                                                  .all(Radius
                                                                      .circular(
                                                                          7.0)),
                                                            ),
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                isSubmitRecommendation
                                                                    ? PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        20.0,
                                                                        25.0,
                                                                        20.0,
                                                                        4.0,
                                                                        Text(
                                                                            "Recommendation",
                                                                            maxLines:
                                                                                30,
                                                                            style: TextStyle(
                                                                                color: ColorValues.labelColor,
                                                                                fontSize: 16.0,
                                                                                fontFamily: Constant.latoMedium,
                                                                                fontWeight: FontWeight.w500)),
                                                                      )
                                                                    : Container(
                                                                        height:
                                                                            0.0,
                                                                      ),

                                                                isSubmitRecommendation
                                                                    ? recommendation
                                                                    : Container(
                                                                        height:
                                                                            0.0,
                                                                      ),




                                                                url == ""
                                                                    ? Container(
                                                                        height:
                                                                            0.0,
                                                                      )
                                                                    : _uploadedItem(),


                                                                SizedBox(
                                                                  height: 10,
                                                                ),

                                                                //Add recomendation pdf view
                                                                isSubmitRecommendation
                                                                    ? mediaRecomendationSection()
                                                                    : Container(
                                                                        height:
                                                                            0.0,
                                                                      ),

                                                                SizedBox(
                                                                  height: 10,
                                                                ),
                                                              ],
                                                            )),

                                                        _showInvalidFileError
                                                            ? Padding(
                                                          padding: const EdgeInsets.only(top: 10,bottom: 10),
                                                          child: Row(
                                                            children: [
                                                              Text(
                                                                MessageConstant.INVALID_FILE_FORMAT_VAL,
                                                                maxLines: 1,
                                                                style: TextStyle(
                                                                  fontSize: 12.0,
                                                                  color: ColorValues.ERROR_COLOR,
                                                                ),
                                                              ),
                                                              Spacer()
                                                            ],
                                                          ),
                                                        )
                                                            : const SizedBox.shrink(),



                                                        isSubmitRecommendation
                                                            ? submitRecommendation()
                                                            : writeRecommendation(),
                                                      ],
                                                    ))
                                          ],
                                        )),

                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            )));
  }
}
