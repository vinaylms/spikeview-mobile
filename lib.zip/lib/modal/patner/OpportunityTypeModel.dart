class OpportunityTypeObj {
  bool isSelected;
  String OpportunityType;
  int index;
  int offerId;
  OpportunityTypeObj(this.isSelected,this.OpportunityType, this.index,this.offerId);

}