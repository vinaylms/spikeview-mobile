import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/home/LikeDetailWidget.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';

// Create a Form Widget
class CommentListWidget extends StatefulWidget {
  List<CommentData> commentList;
  String profile_image_path, feedId, name;
  UserPostModal userPostModel;
  String userIdPref, roleId;
  String badge;
  String badgeImage;
  int gamificationPoints;

  CommentListWidget(
      this.commentList,
      this.profile_image_path,
      this.feedId,
      this.name,
      this.userPostModel,
      this.userIdPref,
      this.roleId,
      this.badge,
      this.gamificationPoints,
      this.badgeImage);

  @override
  CommentListWidgetState createState() {
    return  CommentListWidgetState(commentList, userIdPref);
  }
}

class CommentListWidgetState extends State<CommentListWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId, token, summary = "";
  final _formKey = GlobalKey<FormState>();
  TextEditingController addComment;
  bool isCommentIconVisible = false;
  String companyName = "", companyImage = "", userNAme = "", userImage = "";

  CommentListWidgetState(this.commentList, this.userIdPref);

  int commentLength = 0;
  List<CommentData> commentList;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    roleId = prefs.getString(UserPreference.ROLE_ID);
    companyName = prefs.getString(UserPreference.COMPANY_NAME_PATH);
    companyImage = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    userImage = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    userNAme = prefs.getString(UserPreference.NAME);
    setState(() {
      companyName;
      userNAme;
    });
  }

  @override
  void initState() {
    getSharedPreferences();
    addComment =  TextEditingController(text: '');

    super.initState();
  }

  Future apiCallingForAddLike(index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        bool isLike = false;
        if (commentList[index].isLike) {
          isLike = false;
        } else {
          isLike = true;
        }
        Map map = {
          "feedId": int.parse(widget.feedId),
          "userId": int.parse(userIdPref),
          "isLike": isLike,
          "roleId": int.parse(roleId),
          "commentId": commentList[index].commentId
        };

        Response response = await  ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_ADD_LIKE, map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              if (commentList[index].isLike) {
                commentList[index].isLike = false;
                commentList[index].likesList.removeLast();
                for (int i = 0; i < commentList[index].likesList.length; i++) {
                  if (commentList[index].likesList[i].userId == userIdPref) {
                    commentList[index].likesList.removeAt(i);
                    break;
                  }
                }
              } else {
                commentList[index].isLike = true;
                commentList[index].likesList.add(new Likes(
                    userIdPref,
                    widget.name,
                    widget.profile_image_path,
                    "student",
                    "",
                    "",
                    prefs.getBool(UserPreference.IS_PARENT) ? "2" : "1",
                    widget.badge,
                    widget.gamificationPoints,
                    widget.badgeImage));
              }
              DbHelper(). updateFeedDataComments(widget.feedId,commentList);
              setState(() {
                commentList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForAddComment(localCommentId,commentText) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": widget.feedId,
          "userId": int.parse(userIdPref),
          "comment": commentText,
          "dateTime":  DateTime.now().millisecondsSinceEpoch,
          "name": "",
          "title": "",
          "roleId": int.parse(roleId),
          "profilePicture": "",
          "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
          "lastActivityType": "CommentOnFeed"
        };

        Response response = await  ApiCalling2().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_FEED_COMMENT, map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              widget.userPostModel.isCommented = true;
              List<Likes> likesList =  List();
              for(CommentData _comment in  commentList){
                if(_comment.commentId==localCommentId){

                  _comment.commentId= response.data["result"]["commentId"].toString();
                  _comment.isComment = true;
                  break;
                }
              }
              if(mounted) {
                setState(() {
                  //  addComment.text = "";
                  widget.userPostModel;
                  commentList;
                });
              }
              DbHelper(). updateFeedDataComments(widget.feedId,commentList);

            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForRemoveComment(index,commentId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": int.parse(widget.feedId),
          "commentId": commentId,
          "roleId": int.parse(roleId),
          "dateTime":  DateTime.now().millisecondsSinceEpoch
        };

        Response response = await  ApiCalling2().apiCallPostWithMapData(
            context, Constant.ENDPOINT_REMOVE_COMMENT, map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {

            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey we created above
    Constant.applicationContext = context;
    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {
      } else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }

    Widget getListItem(index) {
      return index == commentList.length - 1
          ? PaddingWrap.paddingfromLTRB(
              13.0,
              15.0,
              13.0,
              10.0,
               Row(crossAxisAlignment: CrossAxisAlignment.start, children: <
                  Widget>[
                 InkWell(
                    child:  Container(
                        width: 40.0,
                        height: 40.0,
                        child: ClipOval(
                            child: FadeInImage.assetNetwork(
                          fit: BoxFit.cover,
                          width: double.infinity,
                          placeholder: commentList[index].roleId == "4"
                              ? "assets/profile/partner_img.png"
                              : 'assets/profile/user_on_user.png',
                          image: Constant.IMAGE_PATH_SMALL +
                              commentList[index].profilePicture,
                        ))),
                    onTap: () {
                      onTapImageTile(commentList[index].commentedBy,
                          commentList[index].roleId);
                    }), // User Image
                 SizedBox(
                  width: 20.0,
                ),
                 Expanded(
                  child:  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                       Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                          child: Row(
                            children: <Widget>[
                               RichText(
                                maxLines: null,
                                text:  TextSpan(
                                  children: <TextSpan>[
                                     TextSpan(
                                        text: commentList[index].name,
                                        style:  TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: ColorValues.HEADING_COLOR_EDUCATION,
                                          fontFamily: Constant.customBold,
                                          fontSize: 14.0,
                                        )),
                                  ],
                                ),
                              ),
                              commentList[index] != null &&
                                      commentList[index].roleId == "1"
                                  //true
                                  ? Util.getStudentBadge12(
                                      commentList[index].badge,
                                      commentList[index].badgeImage)
                                  : Container(),
                            ],
                          )),
                       Container(
                        child: Linkify(
                          onOpen: (link) async {

                            Navigator.push(
                                context,
                                 MaterialPageRoute(
                                    //   builder: (context) =>  DashBoardWidget()));
                                    builder: (context) =>  WebViewWidget(
                                        link.url, "spikeview")));
                          },
                          text: commentList[index].comment,
                          style:  TextStyle(
                              color:   ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          linkStyle:  TextStyle(
                              color:
                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 14.0),
                        ),
                      ),
                       Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                          child:  Row(
                            children: <Widget>[
                               Expanded(
                                child:  Row(
                                  children: <Widget>[
                                     Text(
                                      commentList[index].dateTime,
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          color: ColorValues.GREY_TEXT_COLOR,
                                          fontSize: 12.0,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                                flex: 0,
                              ),
                               Container(
                                width: 10.0,
                              ),
                               Expanded(
                                child:
                                    userIdPref == commentList[index].commentedBy&&
                                    commentList[index].isComment  ?  InkWell(
                                            child:  Image.asset(
                                              "assets/profile/post/user_more1.png",
                                              width: 25.0,
                                              height: 25.0,
                                            ),
                                            onTap: () {
                                              optionForDelete(index);
                                            },
                                          )
                                        :  Container(
                                            height: 1.0,
                                          ),
                                flex: 0,
                              )
                            ],
                          )),
//                   Divider(color: Colors.grey[300]),

                      /*  PaddingWrap.paddingAll(
                      20.0,
                       Container(

                          padding:  EdgeInsets.all(0.0),
                          decoration:  BoxDecoration(
                            shape: BoxShape.rectangle,
                            color: Colors.white,

                            border:  Border.all(
                              color: ColorValues.GREY_TEXT_COLOR,
                              width: 1.0,
                            ),
                          ),
                          child:  Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                               Expanded(
                                child:  Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        5.0, 0.0, 0.0, 10.0),
                                    child:  TextField(
                                      maxLines: null,
                                      maxLength: 200,
                                      controller: addComment,
                                      keyboardType: TextInputType.text,
                                      textCapitalization:
                                          TextCapitalization.sentences,
                                      onChanged: (s) {
                                        if (s.trim().length > 0) {
                                          isCommentIconVisible = true;
                                        } else {
                                          isCommentIconVisible = false;
                                        }
                                        setState(() {
                                          isCommentIconVisible;
                                        });
                                      },
                                      decoration:
                                          */ /*isCommentIconVisible
                                  ?  InputDecoration(
                                      border: InputBorder.none,
                                      filled: true,

                                      hintText: "Add Comment..",
                                      fillColor: Colors.transparent,
                                      suffixIcon:  InkWell(
                                        child:  Image.asset(
                                          "assets/home/send.png",
                                          width: 20.0,
                                          height: 20.0,
                                        ),
                                        onTap: () {
                                          isCommentIconVisible = false;
                                          apiCallingForAddComment();
                                          setState(() {
                                            isCommentIconVisible;
                                          });
                                        },
                                      ))
                                  :*/ /*
                                           InputDecoration(
                                        border: InputBorder.none,
                                        filled: true,
                                        counterText: "",
                                        hintText: "Add Comment as " +widget.name.toString(),
                                        hintStyle: TextStyle(
                                            fontFamily: Constant.customRegular,
                                            fontSize: 14.0,
                                            color:  ColorValues.GREY_TEXT_COLOR),
                                        fillColor: Colors.transparent,
                                        */ /*        suffixIcon: isCommentIconVisible
                                            ?  InkWell(
                                          child:  PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              5.0,
                                              5.0,
                                              5.0,
                                               Image.asset(
                                                "assets/newDesignIcon/feed/send.png",
                                                width: 15.0,
                                                height: 15.0,
                                              )),
                                          onTap: () {
                                            isCommentIconVisible = false;
                                            apiCallingForAddComment();
                                            setState(() {
                                              isCommentIconVisible;
                                            });
                                          },
                                        )
                                            :  Container(
                                          height: 0.0,
                                        )*/ /*
                                      ),
                                    )),
                                flex: 1,
                              ),
                               Expanded(
                                child:  InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      5.0,
                                      0.0,
                                       Image.asset(
                                        "assets/newDesignIcon/send_new.png",
                                        width: 30.0,
                                        height: 30.0,
                                      )),
                                  onTap: () {
                                    if (isCommentIconVisible) {
                                      isCommentIconVisible = false;
                                      apiCallingForAddComment();
                                      setState(() {
                                        isCommentIconVisible;
                                      });
                                    }
                                  },
                                ),
                                flex: 0,
                              )
                            ],
                          ))) */ // FOR INPUT
                    ],
                  ),
                  flex: 1,
                )
              ]))
          : PaddingWrap.paddingfromLTRB(
              13.0,
              15.0,
              13.0,
              10.0,
               Row(crossAxisAlignment: CrossAxisAlignment.start, children: <
                  Widget>[
                 Container(
                    width: 40.0,
                    height: 40.0,
                    child:  InkWell(
                        child: ClipOval(
                            child: FadeInImage.assetNetwork(
                          fit: BoxFit.cover,
                          width: double.infinity,
                          placeholder: commentList[index].roleId == "4"
                              ? "assets/profile/partner_img.png"
                              : 'assets/profile/user_on_user.png',
                          image: Constant.IMAGE_PATH_SMALL +
                              commentList[index].profilePicture,
                        )),
                        onTap: () {
                          onTapImageTile(commentList[index].commentedBy,
                              commentList[index].roleId);
                        })), // User Image
                 SizedBox(
                  width: 20.0,
                ),

                 Expanded(
                  child:  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                       Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                          child: Row(
                            children: <Widget>[
                               RichText(
                                maxLines: null,
                                text:  TextSpan(
                                  children: <TextSpan>[
                                     TextSpan(
                                        text: commentList[index].name,
                                        style:  TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: ColorValues.HEADING_COLOR_EDUCATION,
                                          fontFamily: Constant.customBold,
                                          fontSize: 14.0,
                                        )),
                                  ],
                                ),
                              ),
                              commentList[index] != null &&
                                      commentList[index].roleId == "1"
                                  //true
                                  ? Util.getStudentBadge12(
                                      commentList[index].badge,
                                      commentList[index].badgeImage)
                                  : Container(),
                            ],
                          )),
                       Container(
                        child: Linkify(
                          onOpen: (link) async {

                            Navigator.push(
                                context,
                                 MaterialPageRoute(
                                    //   builder: (context) =>  DashBoardWidget()));
                                    builder: (context) =>  WebViewWidget(
                                        link.url, "spikeview")));
                          },
                          text: commentList[index].comment,
                          style:  TextStyle(
                              color:   ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          linkStyle:  TextStyle(
                              color:
                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 14.0),
                        ),
                      ),
                       Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                          child:  Row(
                            children: <Widget>[
                               Expanded(
                                child:  Row(
                                  children: <Widget>[
                                     Text(
                                      commentList[index].dateTime,
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          color: ColorValues.GREY_TEXT_COLOR,
                                          fontSize: 12.0,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                                flex: 0,
                              ),
                               Container(
                                width: 10.0,
                              ),
                               Expanded(
                                child:
                                    userIdPref == commentList[index].commentedBy&&
                                        commentList[index].isComment
                                        ?  InkWell(
                                            child:

//                                    TextViewWrap.textView(
//                                        "Remove Comment",
//                                        TextAlign.center,
//                                         ColorValues.RED,
//                                        12.0,
//                                        FontWeight.normal),

                                                 Image.asset(
                                              "assets/profile/post/user_more1.png",
                                              width: 25.0,
                                              height: 25.0,
                                            ),
                                            onTap: () {
                                              optionForDelete(index);
                                            },
                                          )
                                        :  Container(
                                            height: 1.0,
                                          ),
                                flex: 0,
                              )
                            ],
                          )),
                    ],
                  ),
                  flex: 1,
                )
              ]));
    }

    return  Scaffold(
        backgroundColor:  ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
        appBar:  AppBar(
          titleSpacing: 2.0,
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          leading:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               InkWell(
                child:  SizedBox(
                  height: 40.0,
                  width: 40.0,
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      0.0,
                      3.0,
                       Center(
                          child:  Image.asset(
                              "assets/newDesignIcon/navigation/back.png",
                              height: 20.0,
                              width: 10.0,
                              fit: BoxFit.fitHeight))),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
              )
            ],
          ),
          elevation: 0.0,
          backgroundColor: Colors.white,
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               Text(
                "Comments",
                style:  TextStyle(
                    fontSize: 18.0,
                    fontFamily: Constant.customRegular,
                    color:  ColorValues.HEADING_COLOR_EDUCATION),
              )
            ],
          ),
          actions: <Widget>[
             Container(
              width: 45.0,
            ),
          ],
        ),
        body:  Container(
            color:  ColorValues.GRAY_BG,
            child:  Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                 Expanded(
                  child: Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child:  ListView(
                        children: <Widget>[
                           Padding(
                              padding:
                                   EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                              child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:  List.generate(
                                      commentList.length, (int index) {
                                    return getListItem(index);
                                  }))),
                        ],
                      )),
                  flex: 1,
                ),
                 Expanded(
                  child: PaddingWrap.paddingfromLTRB(
                      13.0,
                      10.0,
                      13.0,
                      5.0,
                       Container(
                          decoration:  BoxDecoration(
                              border:  Border.all(
                                  width: 1.0,
                                  color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                          child:  Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                               Expanded(
                                child:  TextField(
                                  style:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR), controller: addComment,
                                  keyboardType: TextInputType.text,
                                  textCapitalization:
                                      TextCapitalization.sentences,
                                  maxLines: null,
                                  maxLength: TextLength.COMMENT_MAX_LENGTH,
                                  onChanged: (s) {
                                    if (s.trim().length > 0) {
                                      isCommentIconVisible = true;
                                    } else {
                                      isCommentIconVisible = false;
                                    }
                                    setState(() {
                                      commentLength = s.length;
                                      isCommentIconVisible;
                                    });
                                  },
                                  decoration:  InputDecoration(
                                    border: InputBorder.none,
                                    filled: true,
                                    counterText: "",
                                    counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),       hintText: roleId == "4"
                                        ? "Add Comment as " + companyName
                                        : "Add Comment as " + userNAme,
                                    hintStyle:  TextStyle(
                                        color:  ColorValues.hintColor,
                                        fontSize: 14.0,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                    fillColor: Colors.transparent,
                                  ),
                                ),
                                flex: 4,
                              ),
                               Expanded(
                                child:
                                    /*userPostModal
                                                    .isCommentIconVisible
                                                ?*/
                                     InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      5.0,
                                      0.0,
                                       Image.asset(
                                        "assets/newDesignIcon/feed/send.png",
                                        width: 22.0,
                                        height: 22.0,
                                      )),
                                  onTap: () {
                                    if (addComment.text.trim().length > 0) {
                                      String commentId=  DateTime.now().millisecondsSinceEpoch.toString().toString();
                                      String commentText=  addComment.text;
                                      widget.userPostModel.isCommented = true;
                                      List<Likes> likesList =  List();
                                      commentList.insert(
                                          0,
                                           CommentData(
                                              commentId,
                                              commentText,
                                              userIdPref,
                                              "a few seconds ago",
                                              roleId == "4"
                                                  ? prefs.getString(UserPreference.COMPANY_IMAGE_PATH)
                                                  : widget.profile_image_path,
                                              roleId == "4"
                                                  ? prefs.getString(UserPreference.COMPANY_NAME_PATH)
                                                  : widget.name,
                                              "",
                                              userIdPref,
                                              likesList,
                                              false,
                                              prefs.getBool(UserPreference.IS_PARENT) ? "2" : "1",
                                              widget.badge,
                                              widget.gamificationPoints,
                                              widget.badgeImage,false));
                                      DbHelper(). updateFeedDataComments(widget.feedId,commentList);
                                      setState(() {
                                        addComment.text = "";
                                        widget.userPostModel;
                                        commentList;
                                      });


                                      apiCallingForAddComment(commentId,commentText);
                                    }
                                  },
                                )
                                /*:  Container(
                                                    height: 0.0,
                                                  )*/
                                ,
                                flex: 0,
                              )
                            ],
                          ))),
                  flex: 0,
                ),
                 Expanded(
                  child: Align(
                      alignment: Alignment.bottomRight,
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          13.0,
                          5.0,
                           Text(
                            commentLength.toString() + "/200",
                            textAlign: TextAlign.end,
                            style:  TextStyle(
                                color:  ColorValues.GREY__COLOR, fontSize: 10.0),
                          ))),
                  flex: 0,
                )
              ],
            )));
  }

  void optionForDelete(int index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Container(
                                height: 110.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   InkWell(
                                                    child:  Container(
                                                        height: 50.0,
                                                        padding:  EdgeInsets
                                                                .fromLTRB(0.0,
                                                            13.0, 0.0, 13.0),
                                                        child:  Text(
                                                          "Delete",
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style:  TextStyle(
                                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                        )),
                                                    onTap: () {
                                                      String commentId=commentList[index].commentId;
                                                      commentList.removeAt(index);
                                                      if (commentList.length == 0)
                                                        widget.userPostModel.isCommented = false;

                                                      DbHelper(). updateFeedDataComments(widget.feedId,commentList);
                                                      setState(() {
                                                        commentList;
                                                        widget.userPostModel;
                                                      });

                                                      Navigator.pop(context);
                                                      apiCallForRemoveComment(
                                                          index,commentId);
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }
}
