import 'dart:io';

class LocationData {

  String street1,street2,city,state,country,zip;

  LocationData(this.street1, this.street2, this.city, this.state, this.country,
      this.zip);

}