import 'dart:async';

import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';

import 'package:spike_view_project/constant/TextView_Wrap.dart';


import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:spike_view_project/constant/Constant.dart';


import 'package:spike_view_project/CoachMark/CoachMarkImageModel.dart';


import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class NewCoachMarkSlider extends StatefulWidget {

  NewCoachMarkSlider();
  @override
  NewCoachMarkSliderState createState() =>  NewCoachMarkSliderState();
}



class NewCoachMarkSliderState extends State<NewCoachMarkSlider> with WidgetsBindingObserver {

  List<CoachMarkImagePagerModel> pagerList =  List();

  PageController _controller =  PageController();

  SharedPreferences prefs;
  String userIdPref, roleId;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

  }
  @override
  void dispose() {
    // TODO: implement dispose

    _controller.dispose();
    super.dispose();
  }

  @override
  void initState() {
    // _controller =new  PageController();
    super.initState();
    getSharedPreferences();

    WidgetsBinding.instance.addObserver(this);

    pagerList.clear();

    pagerList.add(new CoachMarkImagePagerModel(
        "assets/coach_mark/sc_one.png",
        "assets/coach_mark/sc_one_.png"
    ));
    pagerList.add(new CoachMarkImagePagerModel(
        "assets/coach_mark/sc_two.png",
        "assets/coach_mark/sc_two_.png"
    ));

    pagerList.add(new CoachMarkImagePagerModel(
        "assets/coach_mark/sc_three.png",
        "assets/coach_mark/sc_three_.png"
    ));

    pagerList.add(new CoachMarkImagePagerModel(
        "assets/coach_mark/sc_four.png",
        "assets/coach_mark/sc_four_.png"
    ));

    pagerList.add(new CoachMarkImagePagerModel(
        "assets/coach_mark/sc_five.png",
        "assets/coach_mark/sc_five_.png"
    ));

    pagerList.add(new CoachMarkImagePagerModel(
        "assets/coach_mark/sc_six.png",
        "assets/coach_mark/sc_six_.png"
    ));





  }


  void _animateSlider() {
    Future.delayed(Duration(seconds: 2)).then((_) {
      if(mounted) {
        if (pagerList.length > 0) {
          int nextPage = _controller.page.round() + 1;

          if (nextPage != pagerList.length) {
            _controller
                .animateToPage(nextPage,
                duration: Duration(seconds: 1), curve: Curves.linear)
                .then((_) => _animateSlider());
          }
          //}
        }
      }
    });
  }
  static const _kDuration = const Duration(milliseconds: 300);
  static const _kCurve = Curves.ease;
  @override
  Widget build(BuildContext context) {
    Constant.pageNameFr = "login";
    Constant.applicationContext = context;

    final double statusBarHeight = MediaQuery.of(context).padding.top;
    final double screenHeight = MediaQuery.of(context).size.height;
    final double screenWidth = MediaQuery.of(context).size.width;

    //https://stackoverflow.com/questions/49553402/how-to-determine-the-screen-height-and-width-in-flutter
    final double ratioHW =screenHeight/screenWidth;
    print('device Ration H/W:::: $ratioHW');
    if(ratioHW > 2.05){
      print('Apurva Screen with height::::::::::::');
    }else
      print('Apurva Screen with width::::::::::::');
    return WillPopScope(
      onWillPop: (){
        print('WillPopScope Back clicked');
      },
      child: Stack(
        children: <Widget>[
           Theme(
              data: ThemeData(
                  backgroundColor: Colors.white,
                  brightness: Brightness.light,
                  indicatorColor: Colors.black,
                  textSelectionColor: Colors.black54,
                  cursorColor: Colors.black,
                  accentColor: Colors.black),
              child:  GestureDetector(
                  onTap: () {
                    FocusScope.of(context).requestFocus(new FocusNode());
                  },
                  child: Scaffold(

                      backgroundColor: Colors.white,
                      body:  SafeArea(
                        child: Container(
                          //margin: EdgeInsets.only(top: statusBarHeight),
                          constraints: BoxConstraints.expand(),

                          child: Container(
                            color: ColorValues.coach_bg_color.withOpacity(0.7),
                            height: MediaQuery.of(context).size.height,
                            child: PageIndicatorContainer(
                              pageView:  PageView.builder(
                                itemCount: pagerList.length,
                                controller: _controller,
                                itemBuilder: (context, index2) {
                                  return InkWell(
                                    child:   Container(

                                        child: Stack(
                                          children: <Widget>[
                                            Positioned(
                                              top: 0,
                                              right: 0,
                                              left: 0.0,
                                              bottom: 0.0,
                                              child:  Container(
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      ratioHW > 2.05 ?
                                                      pagerList[index2].height
                                                          : pagerList[index2].width,

                                                    ),
                                                    fit: BoxFit.contain,
                                                  ),
                                                  //color: Colors.blue.withOpacity(0.5),
                                                ),
                                                child: Container(
                                                  //color: ColorValues.coach_bg_color.withOpacity(0.7),
                                                  child: Stack(
                                                    children: <Widget>[


                                                      Positioned(
                                                        //top: 296-statusBarHeight,
                                                        right: 0,
                                                        left: 0.0,
                                                        bottom: 20.0,
                                                        child: Column(children: [

                                                          Row(

                                                            mainAxisAlignment: MainAxisAlignment.center,

                                                            children:

                                                          [
                                                            index2.toString()=="0"?Container(height: 0,):
                                                            Padding(
                                                                padding: EdgeInsets.only(
                                                                    left: 10.0, top: 20.0, right: 10.0, bottom: 15.0),
                                                                child: InkWell(
                                                                  child: Container(
                                                                      height: 31.0,
                                                                      width: 77.0,
                                                                      decoration: BoxDecoration(
                                                                        color: ColorValues.WHITE,
                                                                        borderRadius: BorderRadius.circular(6),
                                                                      ),

                                                                      child: Row(
                                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                                        children: <Widget>[
                                                                          Text(
                                                                            "Back",
                                                                            style: TextStyle(
                                                                              fontWeight: FontWeight.w400,
                                                                              color: ColorValues.BLUE_COLOR,
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                              fontSize: 14.0,
                                                                            ),
                                                                          )
                                                                        ],
                                                                      )),
                                                                  onTap: () {
                                                                    _controller.previousPage(
                                                                        duration: _kDuration, curve: _kCurve);
                                                                  },
                                                                )),

                                                            index2.toString()=="5"?Container(height: 0,):
                                                            Padding(
                                                                padding: EdgeInsets.only(
                                                                    left: 10.0, top: 20.0, right: 10.0, bottom: 15.0),
                                                                child: InkWell(
                                                                  child: Container(
                                                                      height: 31.0,
                                                                      width: 77.0,
                                                                      decoration: BoxDecoration(
                                                                        color: ColorValues.BLUE_COLOR,
                                                                        borderRadius: BorderRadius.circular(6),
                                                                      ),

                                                                      child: Row(
                                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                                        children: <Widget>[
                                                                          Text(
                                                                            "Next",
                                                                            style: TextStyle(
                                                                              fontWeight: FontWeight.w400,
                                                                              color: ColorValues.WHITE,
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                              fontSize: 14.0,
                                                                            ),
                                                                          )
                                                                        ],
                                                                      )),
                                                                  onTap: () {
                                                                    _controller.nextPage(duration: _kDuration, curve: _kCurve);
                                                                  },
                                                                )),index2.toString()=="5"?
                                                          Padding(
                                                              padding: EdgeInsets.only(
                                                                  left: 10.0, top: 20.0, right: 10.0, bottom: 15.0),
                                                              child: InkWell(
                                                                child: Container(
                                                                    height: 31.0,
                                                                    width: 77.0,
                                                                    decoration: BoxDecoration(
                                                                      color: ColorValues.BLUE_COLOR,



                                                                      borderRadius: BorderRadius.circular(6),
                                                                    ),

                                                                    child: Row(
                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                      children: <Widget>[
                                                                        Text(
                                                                          "Done",
                                                                          style: TextStyle(
                                                                            fontWeight: FontWeight.w400,
                                                                            color: ColorValues.WHITE,
                                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                            fontSize: 14.0,
                                                                          ),
                                                                        )
                                                                      ],
                                                                    )),
                                                                onTap: () {
                                                                  print('back from coach at index::: $index2');
                                                                  Navigator.of(context).pop('coachMark');
                                                                },
                                                              )):Container(height: 0,),],),


                                                          index2.toString()=="5"?Container(height: 0,): Padding(
                                                            padding: EdgeInsets.only(
                                                                left: 0.0, top: 0.0, right: 0.0, bottom:0.0),
                                                            child: InkWell(
                                                            onTap: () async {
                                                              print('back from coach at index::: $index2');
                                                              Navigator.of(context).pop('coachMark');
                                                            },
                                                            child: PaddingWrap.paddingfromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                TextViewWrap
                                                                    .textViewMultiLineShadow(
                                                                    "Skip",
                                                                    TextAlign
                                                                        .center,
                                                                    ColorValues.BLUE_COLOR_BOTTOMBAR,//9A9C9C, 100%
                                                                    14.0,
                                                                    FontWeight
                                                                        .normal,
                                                                    3)),
                                                          )),
                                                        ],)/**/
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),

                                          ],
                                        )),
                                    onTap: () {},
                                  );
                                  //getCoachView(statusBarHeight, ratioHW,index2);
                                  //getProfilThree(statusBarHeight, ratioHW);

                                },
                                onPageChanged: (index) {},
                              ),
                              align: IndicatorAlign.bottom,
                              length: pagerList.length,
                              indicatorSpace: 10.0,
                              indicatorColor:
                             Colors.transparent,
                              indicatorSelectorColor:
                              Colors.transparent,
                              shape: IndicatorShape.circle(
                                  size: 0.0),
                            ),
                          ),
                        ),
                      ))))
        ],
      ),
    );
  }

  getCoachView(statusBarHeight,ratioHW, int index){

    return InkWell(
      child:   Container(

          child: Stack(
            children: <Widget>[
              Positioned(
                top: 0,
                right: 0,
                left: 0.0,
                bottom: 0.0,
                child:  Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        ratioHW > 2.05 ?
                        pagerList[index].height
                            : pagerList[index].width,

                      ),
                      fit: BoxFit.contain,
                    ),
                    //color: Colors.blue.withOpacity(0.5),
                  ),
                  child: Container(
                    //color: ColorValues.coach_bg_color.withOpacity(0.7),
                    child: Stack(
                      children: <Widget>[
                        Positioned(
                          //top: 296-statusBarHeight,
                          right: 0,
                          left: 0.0,
                          bottom: 20.0,
                          child: InkWell(
                            onTap: () async {
                              print('back from coach at index::: $index');
                              Navigator.of(context).pop('coachMark');
                            },
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                TextViewWrap
                                    .textViewMultiLineShadow(
                                    "SKIP",
                                    TextAlign
                                        .center,
                                     ColorValues.WHITE,//9A9C9C, 100%
                                    16.0,
                                    FontWeight
                                        .bold,
                                    3)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            ],
          )),
      onTap: () {},
    );
  }

  getProfilThree(statusBarHeight,ratioHW){

    return InkWell(
      child:   Container(

          child: Stack(
            children: <Widget>[
              Positioned(
                top: 0,
                right: 0,
                left: 0.0,
                bottom: 0.0,
                child:  Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        ratioHW > 2.05 ?
                        "assets/coach_mark/profile_three_text_h.png"
                            : "assets/coach_mark/profile_three_text_w.png",
                      ),
                      fit: BoxFit.contain,
                    ),
                    //color: Colors.blue.withOpacity(0.5),
                  ),
                  child: Container(
                    //color: ColorValues.coach_bg_color.withOpacity(0.7),
                    child: Stack(
                      children: <Widget>[


                        Positioned(
                          //top: 296-statusBarHeight,
                          right: 0,
                          left: 0.0,
                          bottom: 20.0,
                          child: InkWell(
                            onTap: () async {
                              print('aaaaaaaaaaaaaa');
                              Navigator.of(context).pop('coachMarkAddStory');
                              //await apiCallingUpdateCoachMarkDialogStatus();
                            },
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                TextViewWrap
                                    .textViewMultiLineShadow(
                                    "SKIP",
                                    TextAlign
                                        .center,
                                     ColorValues.WHITE,//9A9C9C, 100%
                                    16.0,
                                    FontWeight
                                        .bold,
                                    3)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            ],
          )),
      onTap: () {},
    );
  }

  Future apiCallingUpdateCoachMarkDialogStatus() async {
    try {
      Response response;
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "featureKey": ['coachMark'],
        "display": false

      };
      print("apiCallingUpdateCoachMarkDialogStatus map   ENDPOINT_UPDATE_DIALOG_STATUS:-" + map.toString());
      response = await  ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_DIALOG_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            print("Coack mark dispaly updated" + response.toString());
          }
        }
      }
    } catch (e) {
      print("Errorr:-" + e.toString());
      e.toString();
    }
  }
}
