import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';

//import 'package:simple_permissions/simple_permissions.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/home/SharePostWidget.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/VideoModel.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';
import 'package:spike_view_project/modal/patner/user_signup_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:dio/dio.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

class CompanyPreviewProfileWidget extends StatefulWidget {
  List<String> mediaImagesList;
  List<FileModel> mediaVideosList;

  List<String> mediaDocumentList;

  List<String> googleDoclinkList;

  UserModel personalInfoObject;

  CompanyPreviewProfileWidget(
    this.personalInfoObject,
    this.mediaImagesList,
    this.mediaVideosList,
    this.mediaDocumentList,
    this.googleDoclinkList,
  );

  @override
  CompanyPreviewProfileWidgetState createState() =>
       CompanyPreviewProfileWidgetState();
}

class CompanyPreviewProfileWidgetState
    extends State<CompanyPreviewProfileWidget> {
  var style = TextStyle(
      color: ColorValues.GREY_TEXT_COLOR, fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var styleblack =
      TextStyle(color: Colors.black, fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var stylextreLarge =
      TextStyle(color: Colors.black, fontSize: 24, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var styleblackText =
      TextStyle(color: Colors.black, fontSize: 14, fontFamily: Constant.TYPE_CUSTOMBOLD);
  SharedPreferences prefs;
  String userid;

  String cname = '',
      cemail = '',
      cphone = '',
      cbusiness = '',
      curl = '',
      cdetail = '';

  List<String> mediaDocumentList =  List();
  List<String> googleDoclinkList =  List();
  List<Assest> assestVideoAndImage =  List();

  @override
  void initState() {
    for (String model in widget.mediaImagesList) {
      if (model != null && model != "")
        assestVideoAndImage.add(Assest("image", "image", model,"", false));
    }

    for (FileModel model in widget.mediaVideosList) {
      if (model != null) {
        if (model.path != null && model.path != "")
          assestVideoAndImage.add(Assest("video", "video", model.path,"", false));
      }
    }

    for (String model in widget.mediaDocumentList) {
      if (model != null && model != "") mediaDocumentList.add(model);
    }

    googleDoclinkList.addAll(widget.googleDoclinkList);

    setState(() {
      assestVideoAndImage;

      mediaDocumentList;
      googleDoclinkList;
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    rectangleDecoration() {
      return BoxDecoration(
          border: Border.all(color: Palette.dividerColor), color: Colors.white);
    }

    mediaLabelText(String label) {
      return Text(
        label,
        style: AppTextStyle.getDynamicFontStyle(
            Palette.primaryTextColor, 16, FontType.Regular),
      );
    }

    final docListUiData =  Container(
        padding: const EdgeInsets.fromLTRB(0.0, 18.0, 0.0, 0.0),
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.3,
          scrollDirection: Axis.vertical,
          crossAxisCount: 4,
          children: mediaDocumentList.map((file) {
            /*    return  Container(
                child:  Stack(
              children: <Widget>[
                 InkWell(
                  onTap: () {
                    print("DOC++++" + Constant.IMAGE_PATH + file);
                    launch(Constant.IMAGE_PATH + file);
                  },
                  child:  Container(
                      height: 54.0,
                      width: 62.0,
                      child:  Image.asset(
                        "assets/newDesignIcon/patner/pdf.png",
                        height: 54.0,
                        width: 62.0,
                      )),
                ),
              ],
            ));*/
            return  Container(
                child:  Stack(
              children: <Widget>[
                 InkWell(
                  onTap: () {
                    print("DOC++++" + Constant.IMAGE_PATH + file);
                    launch(Constant.IMAGE_PATH + file);
                  },
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      0.0,
                      5.0,
                       Container(
                          height: 80.0,
                          width: 62.0,
                          child:  Column(
                            children: <Widget>[
                               Expanded(
                                child:  Image.asset(
                                  "assets/newDesignIcon/patner/pdf.png",
                                  height: 54.0,
                                  width: 62.0,
                                ),
                                flex: 1,
                              ),
                               Expanded(
                                child:  Text(
                                  file.substring(
                                      (file.lastIndexOf("/") + 1), file.length),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                flex: 0,
                              )
                            ],
                          ))),
                ),
              ],
            ));
          }).toList(),
        ));

    uploadGoogleDocLink() {
      return Column(
        children: <Widget>[
           Column(
            children: List.generate(googleDoclinkList.length, (index) {
              return Row(
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                      child:  InkWell(
                        child: Text(
                          googleDoclinkList[index],
                          style: TextStyle(
                              color: Palette.accentColor, fontSize: 16,fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        ),
                        onTap: () {
                          Navigator.push(
                              context,
                               MaterialPageRoute(
                                  //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) =>  WebViewWidget(
                                      googleDoclinkList[index], "spikeview")));
                        },
                      ),
                    ),
                  ),
                ],
              );
            }),
          )
        ],
      );
    }

    Widget _loader(BuildContext context) => Center(
            child: Container(
          child:  Image.asset(
            "assets/aerial/feed_default_img.png",
            fit: BoxFit.cover,
          ),
        ));

    Widget _error() {
      return Center(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.fill,
        ),
      );
    }

    // TODO: implement build
    return  Scaffold(
      appBar:  AppBar(
        automaticallyImplyLeading: false,
        titleSpacing: 0.0,
        brightness: Brightness.light,
        leading:  Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
             InkWell(
              child:  SizedBox(
                height: 40.0,
                width: 40.0,
                child: PaddingWrap.paddingfromLTRB(
                    10.0,
                    5.0,
                    0.0,
                    3.0,
                     Center(
                        child:  Image.asset(
                            "assets/newDesignIcon/navigation/back.png",
                            height: 20.0,
                            width: 10.0,
                            fit: BoxFit.fitHeight))),
              ),
              onTap: () {
                Navigator.pop(context);
              },
            )
          ],
        ),
        backgroundColor: ColorValues.singin_bg_color,
        elevation: 0.0,
      ),
      backgroundColor: ColorValues.singin_bg_color,
      body: Column(
        children: <Widget>[
           Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(
                      top: 10.0,
                      left: 13.0,
                      right: 13.0,
                    ),
                    child: Text(
                      widget.personalInfoObject.companyName,
                      style: stylextreLarge,
                    ),
                  ),
                  Container(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 13.0, right: 13.0, top: 20.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              //
                              assestVideoAndImage.length > 0
                                  ?  SizedBox(
                                      // Pager view
                                      height: 215.50,
                                      child: PageIndicatorContainer(
                                        pageView:  PageView.builder(
                                          itemCount: assestVideoAndImage.length,
                                          controller:  PageController(),
                                          itemBuilder: (context, index2) {
                                            return  InkWell(
                                              child:
                                                   Stack(children: <Widget>[
                                                assestVideoAndImage[index2]
                                                            .type ==
                                                        "image"
                                                    ?  CachedNetworkImage(
                                                        width: double.infinity,
                                                        height: 215.50,
                                                        imageUrl: Constant
                                                                .IMAGE_PATH +
                                                            assestVideoAndImage[
                                                                    index2]
                                                                .file,
                                                        fit: BoxFit.fill,
                                                        placeholder:(context, url) =>
                                                            _loader(context),
                                                        errorWidget:(context, url, error) => _error(),
                                                      )
                                                    :  Container(
                                                        height: 215.50,
                                                        child:  Center(
                                                          child:   VideoPlayPauseNew(
                                                              assestVideoAndImage[
                                                              index2]
                                                                  .file,
                                                              ""),
                                                        ),
                                                      ),
                                                assestVideoAndImage.length ==
                                                            1 ||
                                                        assestVideoAndImage[
                                                                    index2]
                                                                .type ==
                                                            "video"
                                                    ?  Container(
                                                        height: 0.0,
                                                      )
                                                    :  Container(
                                                        height: 215.50,
                                                        width: double.infinity,
                                                        child:  Image.asset(
                                                          "assets/newDesignIcon/navigation/layer_image.png",
                                                          fit: BoxFit.fill,
                                                        ),
                                                      )
                                              ]),
                                              onTap: () {},
                                            );
                                          },
                                          onPageChanged: (index) {},
                                        ),
                                        align: IndicatorAlign.bottom,
                                        length: assestVideoAndImage.length,
                                        indicatorSpace: 10.0,
                                        indicatorColor:
                                            assestVideoAndImage.length == 1
                                                ? Colors.transparent
                                                :  Color(0xffc4c4c4),
                                        indicatorSelectorColor:
                                            assestVideoAndImage.length == 1
                                                ? Colors.transparent
                                                :  ColorValues.WHITE,
                                        shape: IndicatorShape.circle(size: 5.0),
                                      ))
                                  :  Stack(children: <Widget>[
                                       Image.asset(
                                        "assets/profile/default_achievement.png",
                                        fit: BoxFit.cover,
                                        height: 215.50,
                                        width: double.infinity,
                                      ),
                                       Container(
                                        height: 215.50,
                                        color: Colors.black54.withOpacity(.4),
                                      )
                                    ])),
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 20.0, bottom: 0, right: 25),
                            child: Column(
                              children: <Widget>[
                                Text(
                                  widget.personalInfoObject.aboutCompany,
                                  style: style,
                                ),
                              ],
                            ),
                          ),
                          mediaDocumentList.length == 0
                              ?  Container(
                                  height: 0.0,
                                )
                              : Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 35.0, 0.0, 0.0),
                                  child:  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      mediaLabelText('Attached Documents (PDF only)'),
                                      docListUiData,
                                    ],
                                  )),
                          googleDoclinkList.length == 0
                              ?  Container(
                                  height: 0.0,
                                )
                              : Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 35.0, 0.0, 0.0),
                                  child:  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      mediaLabelText('Document Link'),
                                      uploadGoogleDocLink(),
                                    ],
                                  )),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(
                                0.0,
                                45.0,
                                0.0,
                                0.0,
                              ),
                              child:  Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                   Expanded(
                                    flex: 0,
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                        0.0,
                                        0.0,
                                        12.0,
                                        0.0,
                                      ),
                                      child:  Container(
                                          height: 35.0,
                                          width: 35.0,
                                          child:  Image.asset(
                                            "assets/newDesignIcon/patner/address.png",
                                            height: 35.0,
                                            width: 35.0,
                                          )),
                                    ),
                                  ),
                                   Expanded(
                                    flex: 1,
                                    child: Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        widget
                                            .personalInfoObject.companyAddress,
                                        style: styleblackText,
                                        maxLines: null,
                                      ),
                                    ),
                                  )
                                ],
                              )),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(
                                0.0,
                                13.0,
                                0.0,
                                0.0,
                              ),
                              child:  Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                   Expanded(
                                    flex: 0,
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                        0.0,
                                        0.0,
                                        12.0,
                                        0.0,
                                      ),
                                      child:  Container(
                                          height: 35.0,
                                          width: 35.0,
                                          child:  Image.asset(
                                            "assets/newDesignIcon/patner/website.png",
                                            height: 35.0,
                                            width: 35.0,
                                          )),
                                    ),
                                  ),
                                   Expanded(
                                    flex: 1,
                                    child: GestureDetector(
                                        onTap: () {
                                          if (widget.personalInfoObject
                                                      .webUrl !=
                                                  "null" &&
                                              widget.personalInfoObject
                                                      .webUrl !=
                                                  null) {
                                            Navigator.push(
                                                Constant.applicationContext,
                                                 MaterialPageRoute(
                                                    //   builder: (context) =>  DashBoardWidget()));
                                                    builder: (context) =>
                                                         WebViewWidget(
                                                            widget
                                                                .personalInfoObject
                                                                .webUrl,
                                                            "Spikeview")));
                                          }
                                        },
                                        child: Text(
                                          widget.personalInfoObject.webUrl,
                                          style: TextStyle(
                                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                              fontSize: 16,
                                              fontFamily: Constant.TYPE_CUSTOMBOLD),
                                        )),
                                  )
                                ],
                              )),
                          widget.personalInfoObject.email == null
                              ?  Container(
                                  height: 0.0,
                                )
                              : Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    0.0,
                                    13.0,
                                    0.0,
                                    0.0,
                                  ),
                                  child:  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                       Expanded(
                                        flex: 0,
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                            0.0,
                                            0.0,
                                            12.0,
                                            0.0,
                                          ),
                                          child:  Container(
                                              height: 35.0,
                                              width: 35.0,
                                              child:  Image.asset(
                                                "assets/newDesignIcon/patner/email.png",
                                                height: 35.0,
                                                width: 35.0,
                                              )),
                                        ),
                                      ),
                                       Expanded(
                                        flex: 1,
                                        child: Text(
                                          widget.personalInfoObject.email,
                                          style: styleblack,
                                        ),
                                      )
                                    ],
                                  )),
                          Padding(
                              padding: const EdgeInsets.fromLTRB(
                                0.0,
                                13.0,
                                0.0,
                                0.0,
                              ),
                              child:  Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                   Expanded(
                                    flex: 0,
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                        0.0,
                                        0.0,
                                        12.0,
                                        0.0,
                                      ),
                                      child:  Container(
                                          height: 35.0,
                                          width: 35.0,
                                          child:  Image.asset(
                                            "assets/newDesignIcon/patner/phone.png",
                                            height: 35.0,
                                            width: 35.0,
                                          )),
                                    ),
                                  ),
                                   Expanded(
                                    flex: 1,
                                    child: Text(
                                      widget.personalInfoObject
                                          .companyPhoneNumber,
                                      style: styleblack,
                                    ),
                                  )
                                ],
                              )),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            flex: 1,
          ),
        ],
      ),
    );
  }
}
