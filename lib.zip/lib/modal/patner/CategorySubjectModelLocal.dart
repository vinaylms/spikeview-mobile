class CategorySubjectLocal {
  int categoryId;
  String name;
  String description;
  List<SubjectLocal> subjects;
  bool isSelected;
  
  CategorySubjectLocal(this.categoryId, this.name, this.description, this.subjects,this.isSelected);
  
}



class SubjectLocal {
  int subjectId;
  String name;
  String description;
  int categoryId;
  bool isSelected;

  SubjectLocal(
      this.subjectId, this.name, this.description, this.categoryId,this.isSelected);

}


