import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/badges/model/SelfBadgeModel.dart';

import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/badges/custom_appbar.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/style.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestFromParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/recommendation/AddRecommendationPerformance.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:url_launcher/url_launcher.dart';

class BadgeRequest extends StatefulWidget {
  //const BadgeRequest({Key key}) : super(key: key);

  String badgeId, screenName;

  BadgeRequest(this.badgeId, this.screenName);

  @override
  State<BadgeRequest> createState() => _BadgeRequestState();
}

class _BadgeRequestState extends State<BadgeRequest> {
  SelfBadgeModel badgeModel;

  onBack() async {
    print('onback() roleId:: $roleId');

    if (prefs.getBool("loginStatus")) {
      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        StudentOnBoarding()
            .getStudentOnBoardingInit(context, null, null, userIdPref);
      }
    } else {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => LoginPage(null)));
    }
  }

  Future recommendationApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2()
            .apiCall6(context, 'ui/badge?badgeReqId=${widget.badgeId}', "get");
        print('id +++ui/badge?badgeReqId=${widget.badgeId} ');

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);
        String status = response.data[LoginResponseConstant.STATUS];

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              badgeModel = SelfBadgeModel.fromJson(response.data);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  SharedPreferences prefs;
  String userIdPref, token, roleId;
  String path;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    path = prefs.getString(UserPreference.PATHURL);
    print('path+++$path ');

    await recommendationApi(true);
  }

  @override
  void initState() {
    try {
      getSharedPreferences();
      // TODO: implement initState

    } catch (e) {
      e.toString();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () {
          if (widget.screenName == "notification") {
            Navigator.pop(context);
          } else {
            onBack();
          }
        },
        child: Scaffold(

            body: badgeModel == null
                ? Container()
                : Stack(
                    children: <Widget>[
                      Container(
                        height: double.infinity,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(
                                    "assets/generateScript/script_background.png"),
                                fit: BoxFit.fill)),
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 40, left: 20, right: 20),
                        child: SizedBox(
                          height: 103,
                          width: double.infinity,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              InkWell(
                                onTap: () {
                                  if (widget.screenName == "notification") {
                                    Navigator.pop(context);
                                  } else {
                                    onBack();
                                  } // Navigator.pop(context, isPerformChnges);
                                },
                                child: Image.asset(
                                  "assets/generateScript/back.png",
                                  height: 32.0,
                                  width: 32.0,
                                ),
                              ),
                              path == "" || path == null || path == "null"
                                  ? SizedBox()
                                  : (path.contains("/3/"))
                                      ? Container(
                                          width: 80,
                                          height: 32,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                                width: 2.0,
                                                color: Color(0xffB2BDDB)),
                                            borderRadius:
                                                BorderRadius.circular(8),
                                          ),
                                          child: InkWell(
                                            child: Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 4.0,
                                                    left: 9.0,
                                                    right: 0,
                                                    bottom: 4),
                                                child: Text(
                                                  "Join now",
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                    fontSize: 14,
                                                    color:
                                                        ColorValues.labelColor,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                )),
                                            onTap: () {
                                              Navigator.pushReplacement(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) =>
                                                          LoginPage(
                                                            null,
                                                            isRedirectToRecommendation:
                                                                true,
                                                            pageName:
                                                                "recomendation",
                                                            showSignup: true,
                                                          )));
                                            },
                                          ),
                                        )
                                      : SizedBox(),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(30),
                              topRight: Radius.circular(30),
                            ),
                          ),
                          margin: const EdgeInsets.only(top: 115),
                          child: Padding(
                            padding: const EdgeInsets.only(left: 20, right: 20),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 4),
                                  Expanded(
                                    child: Container(
                                      width: MediaQuery.of(context).size.width,
                                      decoration: const BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(30),
                                          topRight: Radius.circular(30),
                                        ),
                                      ),
                                      child: Column(children: <Widget>[
                                        Container(
                                          margin: const EdgeInsets.only(
                                              left: 0, right: 10, top: 20,bottom: 5),
                                          alignment: Alignment.centerLeft,
                                          width:
                                              MediaQuery.of(context).size.width,
                                          color: Colors.white,
                                          child: RichText(
                                            text: TextSpan(children: [
                                              TextSpan(
                                                  text: 'Badge review',
                                                  style: AppConstants.txtStyle
                                                      .heading28_700LatoRegularDarkBlue),
                                              TextSpan(
                                                  recognizer:
                                                      TapGestureRecognizer()
                                                        ..onTap = () {},
                                                  text: '',
                                                  style: AppConstants.txtStyle
                                                      .heading26_700LatoRegularDarkBlue)
                                            ]),
                                          ),
                                        ),
                                        Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  badgeModel.result[0].user
                                                      .firstName +
                                                      " " +
                                                      badgeModel.result[0]
                                                          .user.lastName +
                                                      " has added the following badge to their profile on your behalf. Please review.",
                                                  textAlign:
                                                  TextAlign.start,
                                                  style: TextStyle(
                                                      fontFamily: Constant.latoRegular,
                                                      fontSize: 14,
                                                      color: const Color(0xff666B9A),
                                                      fontWeight: FontWeight.w400
                                                  ),
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.only(top:10.0),
                                                  child: Text(
                                                    'From',
                                                    textAlign:
                                                    TextAlign.start,
                                                    style: TxtStyle
                                                        .nunito_12_400lightpurple,
                                                  ),
                                                ),
                                                Container(
                                                  margin:
                                                  const EdgeInsets.only(
                                                      top: 5),
                                                  child: Row(
                                                    children: [
                                                      InkWell(
                                                        child: ClipOval(
                                                            child: FadeInImage
                                                                .assetNetwork(
                                                              fit: BoxFit.cover,
                                                              width: 50.0,
                                                              height: 50.0,
                                                              placeholder:
                                                              'assets/profile/user_on_user.png',
                                                              image: Constant
                                                                  .IMAGE_PATH_SMALL +
                                                                  ParseJson.getMediumImage(
                                                                      badgeModel
                                                                          .result[
                                                                      0]
                                                                          .user
                                                                          .profilePicture),
                                                            )),
                                                        onTap: () {},
                                                      ),
                                                      const SizedBox(
                                                          width: 10),
                                                      Column(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                        children: [
                                                          Row(
                                                            children: [

                                                              Text(
                                                                badgeModel
                                                                    .result[
                                                                0]
                                                                    .user
                                                                    .firstName +
                                                                    " " +
                                                                    badgeModel
                                                                        .result[0]
                                                                        .user
                                                                        .lastName,
                                                                textAlign:
                                                                TextAlign
                                                                    .start,
                                                                style: TextStyle(
                                                                    fontFamily: Constant.latoRegular,
                                                                    fontSize:14,
                                                                    color: const Color(0xff27275A),
                                                                    fontWeight: FontWeight.w700
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          Text(
                                                              badgeModel
                                                                  .result[0]
                                                                  .user
                                                                  .tagline,
                                                              textAlign:
                                                              TextAlign
                                                                  .start,
                                                              style: TextStyle(
                                                                  fontFamily:
                                                                  Constant
                                                                      .TYPE_CUSTOMREGULAR,
                                                                  fontSize:
                                                                  12,
                                                                  color: ColorValues
                                                                      .riminderColor,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w400)),
                                                          /*  Text(
                                      'Soccer Lover',
                                      textAlign: TextAlign.start,
                                      style: TxtStyle.nunito_14_400Grey,
                                    ),*/
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                ),

                                                Container(
                                                  margin:
                                                  const EdgeInsets.only(
                                                      top: 20),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                      Text(
                                                        'Issuer name',
                                                        textAlign:
                                                        TextAlign.start,
                                                        style: TxtStyle
                                                            .nunito_12_400lightpurple,
                                                      ),
                                                      Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                              top: 4.0),
                                                          child: Text(
                                                            badgeModel
                                                                .result[
                                                            0]
                                                                .partner
                                                                .lastName ==
                                                                null
                                                                ? badgeModel
                                                                .result[
                                                            0]
                                                                .partner
                                                                .firstName
                                                                : '${badgeModel.result[0].partner.firstName} ${badgeModel.result[0].partner.lastName}',
                                                            textAlign:
                                                            TextAlign
                                                                .start,
                                                            style: TxtStyle
                                                                .nunito_14_400Blue,
                                                          )),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin:
                                                  const EdgeInsets.only(
                                                      top: 20),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                      Text(
                                                        'Issuer email',
                                                        textAlign:
                                                        TextAlign.start,
                                                        style: TxtStyle
                                                            .nunito_12_400lightpurple,
                                                      ),
                                                      Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                              top: 4.0),
                                                          child: Text(
                                                            badgeModel
                                                                .result[0]
                                                                .partner
                                                                .email,
                                                            textAlign:
                                                            TextAlign
                                                                .start,
                                                            style: TxtStyle
                                                                .nunito_14_400Blue,
                                                          )),
                                                    ],
                                                  ),
                                                ),
                                                badgeModel.result[0]
                                                    .issuerLogo ==
                                                    null ||
                                                    badgeModel.result[0]
                                                        .issuerLogo ==
                                                        ''
                                                    ? Container()
                                                    : Container(
                                                  margin:
                                                  const EdgeInsets
                                                      .only(
                                                      top: 20),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                      Text(
                                                        'Issuer logo image',
                                                        textAlign:
                                                        TextAlign
                                                            .start,
                                                        style: TxtStyle
                                                            .nunito_12_400lightpurple,
                                                      ),
                                                      InkWell(
                                                          onTap: () {
                                                            if (badgeModel.result != null &&
                                                                badgeModel.result.length >
                                                                    0 &&
                                                                badgeModel.result[0].issuerLogo !=
                                                                    null) {
                                                              Navigator
                                                                  .push(
                                                                context,
                                                                HeroDialogRoute(
                                                                  builder:
                                                                      (BuildContext context) {
                                                                    return Center(
                                                                      child: AlertDialog(
                                                                        content: Container(
                                                                          child: Hero(
                                                                            tag: 'developer-hero',
                                                                            child: Container(
                                                                              height: 200.0,
                                                                              width: 200.0,
                                                                              child: Image.network(
                                                                                Constant.IMAGE_PATH_SMALL + ParseJson.getMediumImage(badgeModel.result[0].issuerLogo),
                                                                                fit: BoxFit.fitHeight,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        actions: <Widget>[
                                                                          FlatButton(
                                                                            child: Text('Close'),
                                                                            onPressed: Navigator.of(context).pop,
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  },
                                                                ),
                                                              );
                                                            }
                                                          },
                                                          child: Container(
                                                              margin: const EdgeInsets.only(top: 5),
                                                              padding: const EdgeInsets.all(5.0),
                                                              width: 50,
                                                              height: 48,
                                                              decoration: BoxDecoration(color: const Color(0xFFFFFFFF), border: Border.all(color: const Color(0xffE9E9EC))),
                                                              child: FadeInImage.assetNetwork(
                                                                fit: BoxFit
                                                                    .cover,
                                                                width:
                                                                50,
                                                                height:
                                                                48,
                                                                placeholder:
                                                                'assets/badges/national_pic.png',
                                                                image:
                                                                Constant.IMAGE_PATH_SMALL + ParseJson.getMediumImage(badgeModel.result[0].issuerLogo),
                                                              )))
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin:
                                                  const EdgeInsets.only(
                                                      top: 20),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                      Text(
                                                        'Issue date',
                                                        textAlign:
                                                        TextAlign.start,
                                                        style: TxtStyle
                                                            .nunito_12_400lightpurple,
                                                      ),
                                                      Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                              top: 4.0),
                                                          child: Text(
                                                            Util.getConvertedDateStamp(
                                                                badgeModel
                                                                    .result[
                                                                0]
                                                                    .issueDate
                                                                    .toString()),
                                                            textAlign:
                                                            TextAlign
                                                                .start,
                                                            style: TxtStyle
                                                                .nunito_14_400Blue,
                                                          )),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin:
                                                  const EdgeInsets.only(
                                                      top: 20),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                      Text(
                                                        'Badge title',
                                                        textAlign:
                                                        TextAlign.start,
                                                        style: TxtStyle
                                                            .nunito_12_400lightpurple,
                                                      ),
                                                      Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                              top: 4.0),
                                                          child: Text(
                                                            badgeModel
                                                                .result[0]
                                                                .badgeName
                                                                .toString(),
                                                            textAlign:
                                                            TextAlign
                                                                .start,
                                                            style: TxtStyle
                                                                .nunito_14_400Blue,
                                                          )),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin:
                                                  const EdgeInsets.only(
                                                      top: 20),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                      Text(
                                                        'Badge Image',
                                                        textAlign:
                                                        TextAlign.start,
                                                        style: TxtStyle
                                                            .nunito_12_400lightpurple,
                                                      ),
                                                      InkWell(
                                                        onTap: () {
                                                          if (badgeModel
                                                              .result !=
                                                              null &&
                                                              badgeModel
                                                                  .result
                                                                  .length >
                                                                  0 &&
                                                              badgeModel
                                                                  .result[
                                                              0]
                                                                  .badgeImage !=
                                                                  null) {
                                                            Navigator.push(
                                                              context,
                                                              HeroDialogRoute(
                                                                builder:
                                                                    (BuildContext
                                                                context) {
                                                                  return Center(
                                                                    child:
                                                                    AlertDialog(
                                                                      content:
                                                                      Container(
                                                                        child:
                                                                        Hero(
                                                                          tag: 'developer-hero',
                                                                          child: Container(
                                                                            height: 200.0,
                                                                            width: 200.0,
                                                                            child: Image.network(
                                                                              Constant.IMAGE_PATH_SMALL + ParseJson.getMediumImage(badgeModel.result[0].badgeImage),
                                                                              fit: BoxFit.fitHeight,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      actions: <
                                                                          Widget>[
                                                                        FlatButton(
                                                                          child: Text('Close'),
                                                                          onPressed: Navigator.of(context).pop,
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  );
                                                                },
                                                              ),
                                                            );
                                                          }
                                                        },
                                                        child: Container(
                                                            margin: const EdgeInsets
                                                                .only(
                                                                top: 5),
                                                            padding:
                                                            const EdgeInsets.all(
                                                                5.0),
                                                            width: 50,
                                                            height: 48,
                                                            decoration: BoxDecoration(
                                                                color: const Color(
                                                                    0xFFFFFFFF),
                                                                border: Border.all(
                                                                    color: const Color(
                                                                        0xffE9E9EC))),
                                                            child: FadeInImage
                                                                .assetNetwork(
                                                              fit: BoxFit
                                                                  .cover,
                                                              width: 50,
                                                              height: 48,
                                                              placeholder:
                                                              'assets/badges/national_pic.png',
                                                              image: Constant
                                                                  .IMAGE_PATH_SMALL +
                                                                  ParseJson.getMediumImage(badgeModel
                                                                      .result[
                                                                  0]
                                                                      .badgeImage),
                                                            )),
                                                      )
                                                    ],
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 50,
                                                )
                                              ],
                                            ),
                                            flex: 1),
                                        Expanded(
                                          child: GestureDetector(
                                            onTap: () {
                                              final String subject = "";
                                              final String stringText = "";
                                              String uri =
                                                  'mailto:team@spikeview.com?subject=${Uri.encodeComponent(subject)}&body=${Uri.encodeComponent(stringText)}';
                                              launch(uri);
                                            },
                                            child: Container(
                                                margin:
                                                const EdgeInsets.all(
                                                    0),
                                                padding:
                                                const EdgeInsets.all(
                                                    5.0),
                                                width:
                                                MediaQuery.of(context)
                                                    .size
                                                    .width,
                                                height: 60,


                                                child: Column(
                                                  children: [
                                                    RichText(
                                                      textAlign:
                                                      TextAlign.start,
                                                      text: TextSpan(
                                                        text: 'Note: ',
                                                        style: TxtStyle
                                                            .nunito_italic_12_400grey,
                                                        /*defining default style is optional */
                                                        children: <
                                                            TextSpan>[
                                                          TextSpan(
                                                              text:
                                                              'If this badge detail are not correct, you can contact to ',
                                                              style: TxtStyle
                                                                  .nunito_italic_12_400grey),
                                                          TextSpan(
                                                              text:
                                                              'team@spikeview.com.',
                                                              style: TxtStyle
                                                                  .nunito_italic_14_400Blue),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                )),
                                          ),
                                          flex: 0,
                                        )
                                      ]),
                                    ),
                                  ),
                                ]),
                          ),
                        ),
                      )
                    ],
                  )));
  }
}
