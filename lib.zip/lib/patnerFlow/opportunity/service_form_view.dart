import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/age_between.dart';
import 'package:spike_view_project/patnerFlow/opportunity/Service.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ServiceFormView extends StatefulWidget {
  final Service service;

  ServiceFormView({this.service});

  @override
  State<StatefulWidget> createState() => ServiceFormViewState();
}

class ServiceFormViewState extends State<ServiceFormView>
    with BaseCommonWidget {
  List<IntrestModel> selectedInterestList = [];

  final titleController = TextEditingController();
  final genderController = TextEditingController();
  final locationController = TextEditingController();

  List<AgeBetween> toFromAge = [];

  @override
  void initState() {
    titleController.text = widget.service.title;
    genderController.text = widget.service.gender;

    String text = "";
    for (Address adress in widget.service.location) {
      if (text == "") {
        text = text + " " + adress.street1;
      } else {
        text = text + "   /  " + adress.street1;
      }
    }
    locationController.text = text;
    selectedInterestList = widget.service.interests;
    toFromAge = widget.service.ageBetween;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // TODO: implement build

    return   WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:customAppbar(
          context,
          GestureDetector(
              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child: Padding(
                padding: const EdgeInsets.only(left: 20,right: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [

                    Padding(
                      padding:
                      const EdgeInsets.only(
                          top: 24.0, bottom: 20,),
                      child: Text(
                        'For services',
                        style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w700,
                            fontFamily: Constant
                                .latoSemibold,
                            color: ColorValues
                                .HEADING_COLOR_EDUCATION_1),
                      ),
                    ),
                    // Expanded(
                    //   child: CustomViews.getSepratorLine(),
                    //   flex: 0,
                    // ),
                    Expanded(
                      child: targetAudienceWidget(),
                      flex: 1,
                    ),

                    UIHelper.verticalGap(5),

                  ],
                ),
              )),
              () {
            Navigator.pop(context);
          },

          isShowIcon: false,
        )
    );
   /*
    return SafeArea(
      child:



      Scaffold(
          appBar:  AppBar(
            elevation: 0.0,
            backgroundColor: Colors.white,
            centerTitle: true,
            title: Text('For Services',
                style: AppTextStyle.getDynamicFontStyle(
                    Palette.primaryTextColor, 18, FontType.Regular)),
            leading: backIcon(context),
          ),
          body: Column(
            children: <Widget>[
               Expanded(
                child: CustomViews.getSepratorLine(),
                flex: 0,
              ),
               Expanded(
                child: targetAudienceWidget(),
                flex: 1,
              ),
            ],
          )),

    );
    */
  }

  otherInformationValue(String value) {
    return Text(
      value,
      textAlign: TextAlign.start,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 14,
          color: ColorValues.labelColor,
          fontWeight: FontWeight.w600
      ),
    );
  }
  otherInformationHeader(String title) {
    return Text(
      title,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 12,
          color: ColorValues.HEADING_COLOR_EDUCATION_1,
          fontWeight: FontWeight.w600
      ),
    );
  }

  targetAudienceWidget() {
    return  Container(
      color: Colors.white,
      child: Form(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[

            titleController.text != "" && titleController.text.isNotEmpty ? Title() : const SizedBox(),
            locationController.text != "" && locationController.text.isNotEmpty ? locationView() : const SizedBox(),
            genderController.text != "" && genderController.text.isNotEmpty ? gender() : const SizedBox(),
            toFromAge.length > 0  ? ageGroup() : const SizedBox(),
            selectedInterestList.length > 0 ?
            intrests() : const SizedBox() ,
            UIHelper.verticalGap(20),

          ],
        ),
      ),
    );
  }


  Widget locationView(){
  return Column(
  crossAxisAlignment:
  CrossAxisAlignment.start,
  mainAxisAlignment:
  MainAxisAlignment.start,
  children: [
    UIHelper.verticalGap(20),
    otherInformationHeader('Location you like to cover '),
    SizedBox(height: 10,),
    otherInformationValue(locationController.text.trim()),
  ],
  );
  }



  Widget intrests(){
  return Column(
  crossAxisAlignment:
  CrossAxisAlignment.start,
  mainAxisAlignment:
  MainAxisAlignment.start,
  children: [
    UIHelper.verticalGap(20),
    otherInformationHeader(
        'Interest(s)'),
    SizedBox(height: 10,),

    showSelectedInterest(),
  ],
  );
  }



  Widget Title(){
  return Column(
  crossAxisAlignment:
  CrossAxisAlignment.start,
  mainAxisAlignment:
  MainAxisAlignment.start,
  children: [
    otherInformationHeader('Title'),
    SizedBox(height: 10,),
    otherInformationValue(titleController.text.trim()),
  ],
  );
  }




  Widget gender(){
    return Column(
      crossAxisAlignment:
      CrossAxisAlignment.start,
      mainAxisAlignment:
      MainAxisAlignment.start,
      children: [
        UIHelper.verticalGap(20),
        otherInformationHeader('Gender '),
        SizedBox(height: 9,),
        otherInformationValue(genderController.text),
      ],
    );
  }

  Widget ageGroup(){
    return Column(
      crossAxisAlignment:
      CrossAxisAlignment.start,
      mainAxisAlignment:
      MainAxisAlignment.start,
      children: [
        UIHelper.verticalGap(20),
        otherInformationHeader('Age group'),
        SizedBox(height: 0,),
        getAgeList(),

      ],
    );
  }


  Widget getAgeList() {
    return

      Container(
          decoration: BoxDecoration(
            //color: Colors.white,
            // border:  Border.all(
            //     color:   ColorValues.DEVIDER_COLOR,
            //     width: 1.0)
          ),
          child: Wrap(
            spacing: 0.0,
            runSpacing: 0.0,
            children: toFromAge.map((level) {
              return Padding(
                  padding: const EdgeInsets.only(left: 0,right: 8,top: 5,bottom: 0),
                  child: Container(

                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          InkWell(
                            onTap: () {

                            },
                            child:

                            otherInformationValue(level.fromAge.toString() +
                                    "-" + level.toAge.toString() +
                                    " Years;"
                            ),
                            //   Text(
                            //     level.from +
                            //         "-" +
                            //         level.to +
                            //         " years;",
                            //     style: TextStyle(
                            //         fontFamily: Constant.latoRegular,
                            //         fontSize: 12,
                            //         color: ColorValues.labelColor,
                            //         fontWeight: FontWeight.w600
                            //     ),
                            //
                            //
                            // ),
                          )
                        ],
                      ),
                    ),
                  )


              );
            }).toList(),
          )


      );

    /*
      Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(selectedDataOpportunityPreview.ageList.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 2.0, 0.0, 0.0),
          child: Text(
            selectedDataOpportunityPreview.ageList[index].from +
                "-" +
                selectedDataOpportunityPreview.ageList[index].to +
                " years ",
            style: TextStyle(
                fontFamily: Constant.latoRegular,
                fontSize: 14,
                color: ColorValues.labelColor,
                fontWeight: FontWeight.w600
            ),
          ),
        );
      }),
    );
      */
  }



  showSelectedInterest() {
    return   Container(
        decoration: BoxDecoration(

        ),
        child: Wrap(
          spacing: 0.0,
          runSpacing: 0.0,
          children: selectedInterestList.map((level) {
            return Padding(
                padding: const EdgeInsets.only(left: 0,right: 10,top: 5,bottom: 5),
                child: Container(
                  decoration: BoxDecoration(
                    color: ColorValues.DARK_YELLOW,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8,right: 8,top: 7,bottom: 7),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        InkWell(
                          onTap: () {

                          },
                          child: Text(
                            '${level.name}',
                            style: TextStyle(
                              fontSize: 14.0,
                              fontFamily: Constant.latoRegular,
                              fontWeight: FontWeight.w500,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )


            );
          }).toList(),
        )

    );


  }
}
