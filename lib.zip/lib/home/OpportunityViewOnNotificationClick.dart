import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/UserProfileDashBoard.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';

class OpportunityViewWidgetOnNotificationClick extends StatefulWidget {
  OpportunityModelForFeed opportunity;
  String roleId, pageName;

  String opportunityId;

  OpportunityViewWidgetOnNotificationClick(
      this.opportunityId, this.roleId, this.pageName);

  @override
  State<StatefulWidget> createState() =>
      OpportunityViewWidgetOnNotificationClickState(opportunityId);
}

class OpportunityViewWidgetOnNotificationClickState
    extends State<OpportunityViewWidgetOnNotificationClick>
    with BaseCommonWidget {
  bool isActivate = true;
  OpportunityModelForFeed opportunity = null;
  SharedPreferences prefs;
  List<Assest> mediaDocumentList =  List();
  List<Assest> googleLinkList =  List();
  String userIdPref;
  String location = "";

  String opportunityId;

  OpportunityViewWidgetOnNotificationClickState(this.opportunityId);

  int diffrenceInDob = 14;

  String firstHalf = '';
  String secondHalf = '';
  bool flag = true;

  String firstHalfDesc = '';
  String secondHalfDesc = '';
  bool flagDesc = true;

  String descVal = '';

  String categoryString = '';

  String subjectString = '';
  bool isGroup_AccessControl = true;
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    String dob = prefs.getString(UserPreference.DOB);
    diffrenceInDob = int.tryParse(dob);
    try {
      isGroup_AccessControl =
          prefs.getString(UserPreference.ACCESS_CONTROL_GROUP)
              .toLowerCase() ==
              "true";

    }catch(e){
      isGroup_AccessControl = true;
    }
    setState(() {

    });
  }

  onBack() async {
    print("inside onBack()");
    print("inside onBack() widget.page++" + widget.pageName);
    if (widget.pageName != null && widget.pageName == "login") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>  DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>  DashBoardWidget(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context);
    }
  }

  Future callGetOpportunityDetailsAPI() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'callGetOpportunityDetailsAPI URL:: ${Constant.ENDPOINT_Opportunity_detail_api}${widget.opportunityId}');
        CustomProgressLoader.showLoader(context);
        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_Opportunity_detail_api + widget.opportunityId,
            "get");
        CustomProgressLoader.cancelLoader(context);
        print("callGetOpportunityDetailsAPI data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            print('Status:: $status');

            opportunity = ParseJson.parseOpportunityDetailData(
                response.data['result'], userIdPref, widget.roleId);
            print('opportunity after parsing:::::: $opportunity');
            if (opportunity != null) {
              print('inside if::::: ');
              mediaDocumentList.addAll(opportunity.docList);

              googleLinkList.addAll(opportunity.googleLinkList);
              for (Address adress in opportunity.locationList) {
                if (location == "") {
                  location = location + " " + adress.street1;
                } else {
                  location = location + "   /  " + adress.street1;
                }
              }
              getData();
            }
            setState(() {
              opportunity = opportunity;
            });
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }

  Future<void> getInitData() async {
    await getSharedPreferences();
    await callGetOpportunityDetailsAPI();
  }

  @override
  void initState() {
    // TODO: implement initState
    print('Apurva inside Opportunity details new');
    getInitData();
    super.initState();
  }

  void groupInvitationAccepted() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Center(
                                              child:  Container(
                                                  child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text: opportunity
                                                          .groupIsPublic
                                                      ? ' Awesome! You have successfully joined this group '
                                                      : ' Awesome! You have successfully sent request for this group ',
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                              )),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Close",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallJoin(groupId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(widget.roleId)
        };
        print("map++++" + map.toString());
        response = await  ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_JOIN_GROUP, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForForwardParent(groupId, opportunityModelForFeed) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "parentId": int.parse(userIdPref),
          "userId": int.parse(opportunityModelForFeed.studentJoinId)
        };

        print("joinMap++++" + map.toString());

        response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_JOIN_GROUP_FORWARD, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    void feedForwardConformation() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Center(
                                                child:  Container(
                                                    child: RichText(
                                                  maxLines: 5,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text:
                                                        ' Your post has been forwarded to your parent. Please follow up with them ',
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                )),
                                              ),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "OK",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    Future apiCallForForwardFeed(id) async {
      try {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          Map map = {
            "opportunityId": int.parse(id),
            "userId": int.parse(userIdPref)
          };
          print("map+++" + map.toString());
          Response response = await  ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_FEED_FORWARD, map);

          print("response:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                if (msg.contains("Opportunity already forwarded to parent")) {
                  ToastWrap.showToast(msg, context);
                } else {
                  feedForwardConformation();
                }
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      } catch (e) {
        e.toString();
      }
    }

    Widget _loader(BuildContext context) => Center(
            child: Container(
          child:  Image.asset(
            "assets/aerial/feed_default_img.png",
            fit: BoxFit.cover,
          ),
        ));

    Widget _error() {
      return Center(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.fill,
        ),
      );
    }

    void forwardToParentConformAtionDialog(id) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(20.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to forward this feed to your parent?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "No",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Yes",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCallForForwardFeed(id);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void infoDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        Container(
                                          height: 145.0,
                                          padding: const EdgeInsets.all(8.0),
                                          width: double.infinity,
                                          color: Colors.white,
                                          child: ListView(children: <Widget>[
                                            Image.asset(
                                              'assets/profile/parent/info.png',
                                              height: 25.0,
                                              width: 25.0,
                                            ),
                                             Container(
                                                padding:
                                                    const EdgeInsets.all(3.0),
                                                child: RichText(
                                                  maxLines: 1,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text: 'Forward to Parent',
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMBOLD),
                                                  ),
                                                )),
                                             Container(
                                                child: RichText(
                                              maxLines: 5,
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                text:
                                                    'Great that you are interested on this opportunity. Because you are under 13, please follow up your parent/guardian to help with next steps. They will see the details in their feed.',
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontSize: 16.0,
                                                    fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                              ),
                                            ))
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Close",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final docListUiData =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.5,
      mainAxisSpacing: 10.0,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: mediaDocumentList.map((file) {
        return  InkWell(
          child:  Container(
              height: 45.0,
              width: 45.0,
              child:  Image.asset(
                "assets/newDesignIcon/patner/pdf.png",
                height: 45.0,
                width: 45.0,
              )),
          onTap: () {
            launch(Constant.IMAGE_PATH + (file.file.replaceAll(" ", "%20")));
          },
        );
      }).toList(),
    ));

    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {
      } else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }

    otherInformationHeader(String title) {
      return Text(
        title,
        style: AppTextStyle.getDynamicFontStyle(
            Palette.secondaryTextColor, 14, FontType.Regular),
      );
    }

    otherInformationHeaderBold(String title) {
      return Text(
        title,
        style: AppTextStyle.getDynamicFontStyle(
            Palette.secondaryTextColor, 14, FontType.Bold),
      );
    }

    otherInformationValue(String value) {
      return Text(
        value,
        style: AppTextStyle.getDynamicFontStyle(
            Palette.primaryTextColor, 16, FontType.Regular),
      );
    }

    return WillPopScope(
      onWillPop: () {
        print("----------ON BACK PROCESS");

        onBack();
      },
      child: SafeArea(
          child: Scaffold(
        appBar:  AppBar(
          backgroundColor: Palette.webColor,
          centerTitle: true,
          elevation: 0.0,
          actions: <Widget>[
            InkWell(
              child: Container(
                width: 40,
                height: 40,
                padding: EdgeInsets.all(10),
              ),
              onTap: () {},
            )
          ],
          title: Text(
            'Opportunity Details ',
            style: AppTextStyle.getDynamicFontStyle(
                Palette.primaryTextColor, 18, FontType.Regular),
          ),
          //leading: backIcon(context),
          leading: Padding(
            padding: const EdgeInsets.fromLTRB(0.0, 0.0, 25.0, 0.0),
            child: IconButton(
                icon: Image.asset(
                  ImagePath.ICON_BACK,
                  color: Palette.primaryTextColor,
                  height: 20,
                  width: 10,
                ),
                onPressed: () {
                  onBack();
                }),
          ),
        ),
        body: opportunity != null
            ? Column(
                children: <Widget>[
                  CustomViews.getSepratorLine(),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 15.0),
                        child: opportunity != null
                            ? Container(
                                child:  Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        15.0,
                                        15.0,
                                        13.0,
                                        10.0,
                                         Row(
                                          children: <Widget>[
                                             Expanded(
                                              child:  InkWell(
                                                child:  Center(
                                                  child:  Container(
                                                      width: 50.0,
                                                      height: 50.0,
                                                      child: ClipOval(
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                        fit: BoxFit.cover,
                                                        width: double.infinity,
                                                        placeholder:
                                                            'assets/profile/partner_img.png',
                                                        image: Constant
                                                                .IMAGE_PATH_SMALL +
                                                            ParseJson.getSmallImage(
                                                                opportunity
                                                                    .profilePicture),
                                                      ))),
                                                ),
                                                onTap: () {
                                                  onTapImageTile(
                                                      opportunity.userId,
                                                      opportunity.roleId);
                                                },
                                              ),
                                              flex: 0,
                                            ),
                                             Expanded(
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      8.0,
                                                      0.0,
                                                      15.0,
                                                      0.0,
                                                       Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                           InkWell(
                                                            child:  Container(
                                                                child: RichText(
                                                              maxLines: 2,
                                                              textAlign:
                                                                  TextAlign
                                                                      .start,
                                                              text: TextSpan(
                                                                text: opportunity
                                                                    .companyName,
                                                                style:
                                                                     TextStyle(
                                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontSize:
                                                                      15.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                ),
                                                              ),
                                                            )),
                                                          ),
                                                        ],
                                                      )),
                                              flex: 4,
                                            ),
                                          ],
                                        )),
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        //
                                        opportunity.assestVideoAndImage.length >
                                                0
                                            ?  SizedBox(
                                                // Pager view
                                                height: 215.50,
                                                child: PageIndicatorContainer(
                                                  pageView:
                                                       PageView.builder(
                                                    itemCount: opportunity
                                                        .assestVideoAndImage
                                                        .length,
                                                    controller:
                                                         PageController(),
                                                    itemBuilder:
                                                        (context, index2) {
                                                      print("image+++");
                                                      print("image+++" +
                                                          opportunity
                                                              .assestVideoAndImage[
                                                                  index2]
                                                              .file);
                                                      return  InkWell(
                                                        child:  Stack(
                                                            children: <Widget>[
                                                              opportunity
                                                                          .assestVideoAndImage[
                                                                              index2]
                                                                          .type ==
                                                                      "image"
                                                                  ? Container(
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                      child:
                                                                           CachedNetworkImage(
                                                                        width: double
                                                                            .infinity,
                                                                        height:
                                                                            215.50,
                                                                        imageUrl:
                                                                            Constant.IMAGE_PATH +
                                                                                opportunity.assestVideoAndImage[index2].file,
                                                                        fit: BoxFit
                                                                            .contain,
                                                                        placeholder:
                                                                            (context, url) =>
                                                                                _loader(context),
                                                                        errorWidget: (context,
                                                                                url,
                                                                                error) =>
                                                                            _error(),
                                                                      ))
                                                                  :  Container(
                                                                      decoration:
                                                                          BoxDecoration(
                                                                            color: Colors.black,
                                                                        borderRadius:
                                                                            BorderRadius.circular(0),
                                                                      ),
                                                                      height:
                                                                          215.50,
                                                                      child:
                                                                           Center(
                                                                        child:  VideoPlayPause(
                                                                            opportunity.assestVideoAndImage[index2].file,
                                                                            "",
                                                                            true),
                                                                      ),
                                                                    ),
                                                              opportunity.assestVideoAndImage
                                                                              .length ==
                                                                          1 ||
                                                                      opportunity
                                                                              .assestVideoAndImage[
                                                                                  index2]
                                                                              .type ==
                                                                          "video"
                                                                  ?  Container(
                                                                      height:
                                                                          0.0,
                                                                    )
                                                                  :  InkWell(
                                                                      onTap:
                                                                          () {
                                                                        Navigator.of(context).push(new MaterialPageRoute(
                                                                            builder: (BuildContext context) =>  CommonFullViewWidget(
                                                                                opportunity.assestVideoAndImage,
                                                                                MessageConstant.ACCOMPLISHMENT_HEDING,
                                                                                index2,
                                                                                MessageConstant.VIEWER_END_REWCOMMENDATION_HEDING)));
                                                                      },
                                                                      child:
                                                                           Container(
                                                                        height:
                                                                            215.50,
                                                                        width: double
                                                                            .infinity,
                                                                        child:  Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/navigation/layer_image.png",
                                                                          fit: BoxFit
                                                                              .fill,
                                                                        ),
                                                                      ))
                                                            ]),
                                                        onTap: () {},
                                                      );
                                                    },
                                                    onPageChanged: (index) {},
                                                  ),
                                                  align: IndicatorAlign.bottom,
                                                  length: opportunity
                                                      .assestVideoAndImage
                                                      .length,
                                                  indicatorSpace: 10.0,
                                                  indicatorColor: opportunity
                                                              .assestVideoAndImage
                                                              .length ==
                                                          1
                                                      ? Colors.transparent
                                                      :  Color(0xffc4c4c4),
                                                  indicatorSelectorColor:
                                                      opportunity.assestVideoAndImage
                                                                  .length ==
                                                              1
                                                          ? Colors.transparent
                                                          :  Color(
                                                              0XFFFFFFFF),
                                                  shape: IndicatorShape.circle(
                                                      size: 5.0),
                                                ))
                                            :  Stack(children: <Widget>[
                                                 Image.asset(
                                                  "assets/profile/default_achievement.png",
                                                  fit: BoxFit.cover,
                                                  height: 215.50,
                                                  width: double.infinity,
                                                ),
                                                 Container(
                                                  height: 215.50,
                                                  color: Colors.black54
                                                      .withOpacity(.4),
                                                )
                                              ])),
                                    // UIHelper.verticalSpaceSmall,
                                    Container(
                                      width: double.infinity,
                                      margin: EdgeInsets.all(10),
                                      padding: EdgeInsets.all(13),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            /*opportunity.offerId == "1" || opportunity.offerId == "2" || opportunity.offerId == "3"
                                        ? opportunity.jobTitle
                                        : */
                                            opportunity.offerId == "4" ||
                                                    opportunity.offerId == "5"
                                                ? opportunity.serviceTitle
                                                : opportunity.jobTitle,
                                            //: "College Counselling",
                                            style: AppTextStyle
                                                .getDynamicFontStyle(
                                                    Palette.primaryTextColor,
                                                    20,
                                                    FontType.Regular),
                                          ),
                                          UIHelper.verticalSpaceSmall,
                                          /*Text(
                                    opportunity.offerId == "1" || opportunity.offerId == "2" || opportunity.offerId == "3"
                                        ? opportunity.project
                                        : opportunity.offerId == "4" || opportunity.offerId == "5"
                                            ? opportunity.serviceDesc
                                            : "${opportunity.description}",//"College Counselling",
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.primaryTextColor,
                                        16,
                                        FontType.Regular),
                                  ),*/

                                           RichText(
                                            text:  TextSpan(
                                                text: secondHalfDesc.isEmpty
                                                    ? firstHalfDesc
                                                    : flagDesc
                                                        ? (firstHalfDesc + "")
                                                        : (firstHalfDesc +
                                                            secondHalfDesc),
                                                //style: underlineStyle.copyWith(decoration: TextDecoration.none),
                                                style: AppTextStyle.getDynamicFont(
                                                     ColorValues.HEADING_COLOR_EDUCATION,
                                                    14,
                                                    FontType.Regular),
                                                children: [
                                                   TextSpan(
                                                    text: secondHalfDesc.isEmpty
                                                        ? ''
                                                        : flagDesc
                                                            ? " More"
                                                            : " Less",
                                                    style: AppTextStyle
                                                        .getDynamicFont(
                                                             ColorValues.BLUE_COLOR,
                                                            14,
                                                            FontType.Regular),
                                                    recognizer:
                                                         TapGestureRecognizer()
                                                          ..onTap = () {
                                                            print(
                                                                'Tap Here onTap');
                                                            setState(() {
                                                              flagDesc =
                                                                  !flagDesc;
                                                            });
                                                          },
                                                  )
                                                ]),
                                          ),
                                          UIHelper.verticalSpaceSmall,
                                          opportunity.offerId == "6" ||
                                                  opportunity.offerId == "7" ||
                                                  opportunity.offerId == "8"
                                              ? getMentorAdvisorTutor()
                                              : opportunity.offerId == "1" ||
                                                      opportunity.offerId ==
                                                          "2" ||
                                                      opportunity.offerId == "3"
                                                  ? getJobInternship()
                                                  : Container(),

                                          /*   UIHelper.verticalSpaceSmall,
                                  opportunity.url == "null"
                                      ?  Container(
                                    height: 0,
                                  )
                                      : Text(
                                    opportunity.url,
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.accentColor,
                                        16,
                                        FontType.Regular),
                                  ),*/
                                          /*opportunity.jobLocation==null  || opportunity.jobLocation=="null"  || opportunity.jobLocation==""?new Container(height: 0.0,):
                                  UIHelper.verticalSpaceSmall,
                                  opportunity.jobLocation==null  || opportunity.jobLocation=="null"  || opportunity.jobLocation==""?new Container(height: 0.0,):  Text(
                                    'Job Location: ' +

                                            opportunity.jobLocation,
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.primaryTextColor,
                                        12,
                                        FontType.Regular),
                                  ),*/
                                          opportunity.offerId == "6" ||
                                                  opportunity.offerId == "7" ||
                                                  opportunity.offerId == "8"
                                              ? UIHelper.verticalSpaceSmall
                                              : Container(),
                                          opportunity.offerId == "6" ||
                                                  opportunity.offerId == "7" ||
                                                  opportunity.offerId == "8"
                                              ? getScheduleWidget(opportunity)
                                              : Row(
                                                  children: <Widget>[
                                                    /*Text(
                                        'Schedule For: ' +
                                            getConvertedDateStamp2(
                                                opportunity.fromDate) +
                                            " - " +
                                            getConvertedDateStamp2(
                                                opportunity.toDate),
                                        style: AppTextStyle.getDynamicFontStyle(
                                            Palette.primaryTextColor,
                                            14,
                                            FontType.Regular),
                                      ),*/
                                                    AppTextStyle.getLableTextForDetail(
                                                        'Scheduled For: ',
                                                        getConvertedDateStamp2(
                                                                opportunity
                                                                    .fromDate) +
                                                            " - " +
                                                            getConvertedDateStamp2(
                                                                opportunity
                                                                    .toDate)),
                                                    /*Text(
                                        'Schedule For: ' +
                                            getConvertedDateStamp2(
                                                opportunity.fromDate) +
                                            " - " +
                                            getConvertedDateStamp2(
                                                opportunity.toDate),
                                        style: AppTextStyle.getDynamicFontStyle(
                                            Palette.primaryTextColor,
                                            14,
                                            FontType.Regular),
                                      ),*/
                                                  ],
                                                ),
                                          widget.pageName == 'preview'
                                              ? Column(
                                                  children: <Widget>[
                                                    UIHelper.verticalSpaceSmall,
                                                    /*Text(
                                    'Expiration Date: ' +
                                        getConvertedDateStamp2(
                                            opportunity.expiresOn),
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.primaryTextColor,
                                        14,
                                        FontType.Regular),
                                  ),*/

                                                    AppTextStyle
                                                        .getLableTextForDetail(
                                                            'Expiration Date: ',
                                                            getConvertedDateStamp2(
                                                                opportunity
                                                                    .expiresOn)),
                                                  ],
                                                )
                                              : Container(),
                                        ],
                                      ),
                                    ),
                                    mediaDocumentList.length == 0 ||
                                            opportunity.offerId == "6"
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        : UIHelper.verticalSpaceSmall,
                                    mediaDocumentList.length == 0 ||
                                            opportunity.offerId == "6"
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        : Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                              23.0,
                                              0.0,
                                              23.0,
                                              7.0,
                                            ),
                                            child: Text(
                                              //"Attach Documents (PDF only)",
                                              "Documents",
                                              style: AppTextStyle
                                                  .getDynamicFontStyle(
                                                      Palette.primaryTextColor,
                                                      14,
                                                      FontType.Regular),
                                            ),
                                          ),
                                    mediaDocumentList.length == 0 ||
                                            opportunity.offerId == "6"
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        : docListUiData,

                                    opportunity.offerId == "7" ||
                                            opportunity.offerId == "8"
                                        ? Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                              23.0,
                                              0.0,
                                              23.0,
                                              0.0,
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                opportunity != null &&
                                                        opportunity
                                                                .userImageModelParam
                                                                .length >
                                                            0
                                                    ? Text(
                                                        "${opportunity.offerId == "8" ? "Advisors Photo" : "Mentor Photo"}",
                                                        style: AppTextStyle
                                                            .getDynamicFont(
                                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                                14,
                                                                FontType.Regular),
                                                      )
                                                    :  Container(
                                                        height: 0.0,
                                                      ),
                                                userImageListUI(),
                                              ],
                                            ),
                                          )
                                        : Container(),

                                    opportunity.offerId == "6" ||
                                            opportunity.offerId == "7" ||
                                            opportunity.offerId == "8"
                                        ? Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                              23.0,
                                              0.0,
                                              23.0,
                                              5.0,
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                /*UIHelper.verticalSpaceSmall,
                                  Padding(
                                    padding: const EdgeInsets.only( bottom: 20.0),
                                    child: Container(
                                      height: 1.0,
                                      color: ColorValues.BORDER_COLOR,
                                    ),
                                  ),*/
                                                Text(
                                                  "Bio",
                                                  style: AppTextStyle
                                                      .getDynamicFont(
                                                           ColorValues.HEADING_COLOR_EDUCATION,
                                                          14,
                                                          FontType.Regular),
                                                ),
                                                UIHelper
                                                    .verticalSpaceExtraSmall,
                                                 RichText(
                                                  text:  TextSpan(
                                                      text: secondHalf.isEmpty
                                                          ? firstHalf
                                                          : flag
                                                              ? (firstHalf + "")
                                                              : (firstHalf +
                                                                  secondHalf),
                                                      //style: underlineStyle.copyWith(decoration: TextDecoration.none),
                                                      style: AppTextStyle
                                                          .getDynamicFont(
                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                              14,
                                                              FontType.Regular),
                                                      children: [
                                                         TextSpan(
                                                          text:
                                                              secondHalf.isEmpty
                                                                  ? ''
                                                                  : flag
                                                                      ? " More"
                                                                      : " Less",
                                                          style: AppTextStyle
                                                              .getDynamicFont(
                                                                    ColorValues.BLUE_COLOR,
                                                                  14,
                                                                  FontType
                                                                      .Regular),
                                                          recognizer:
                                                               TapGestureRecognizer()
                                                                ..onTap = () {
                                                                  print(
                                                                      'Tap Here onTap');
                                                                  setState(() {
                                                                    flag =
                                                                        !flag;
                                                                  });
                                                                },
                                                        )
                                                      ]),
                                                ),
                                              ],
                                            ),
                                          )
                                        : Container(),


                                    mediaDocumentList.length != 0 &&
                                            opportunity.offerId == "6"
                                        ? Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                              23.0,
                                              10.0,
                                              23.0,
                                              0.0,
                                            ),
                                            child: Text(
                                              "Teaching Certifications",
                                              style: AppTextStyle
                                                  .getDynamicFontStyle(
                                                      Palette.primaryTextColor,
                                                      14,
                                                      FontType.Regular),
                                            ),
                                          )
                                        :  Container(
                                            height: 0.0,
                                          ),
                                    mediaDocumentList.length != 0 &&
                                            opportunity.offerId == "6"
                                        ? docListUiData
                                        :  Container(
                                            height: 0.0,
                                          ),


                                    googleLinkList.length == 0
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        : Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                              23.0,
                                              15.0,
                                              23.0,
                                              0.0,
                                            ),
                                            child: Text(
                                              "Additional Link(s):",
                                              style: AppTextStyle
                                                  .getDynamicFontStyle(
                                                      Palette.primaryTextColor,
                                                      14,
                                                      FontType.Regular),
                                            ),
                                          ),
                                     Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children:  List.generate(
                                            googleLinkList.length, (index) {
                                          return Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                23.0, 10.0, 23.0, 0.0),
                                            child:  InkWell(
                                              child: Text(
                                               googleLinkList[
                                                index]
                                                    .label
                                                    .trim()=="null"? googleLinkList[
                                                index]
                                                    .file
                                                    .trim():  googleLinkList[
                                                index]
                                                    .label
                                                    .trim(),
                                                style: AppTextStyle
                                                    .getDynamicFontStyle(
                                                        Palette.accentColor,
                                                        14,
                                                        FontType.Regular),
                                              ),
                                              onTap: () {
                                                String url="";
                                                if (googleLinkList[index].file
                                                    .contains("http")) {
                                                  url =googleLinkList[index].file;
                                                } else {
                                                  url = "http://" + googleLinkList[index].file;

                                                }

                                                Navigator.push(
                                                    Constant.applicationContext,
                                                     MaterialPageRoute(
                                                        //   builder: (context) =>  DashBoardWidget()));
                                                        builder: (context) =>
                                                             WebViewWidget(
                                                                url,
                                                                "Document Link")));
                                              },
                                            ),
                                          );
                                        })),

                                    widget.pageName == "preview"
                                        ? Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              UIHelper.verticalSpaceSmall,
                                              opportunity.targetAudience ==
                                                      "true"
                                                  ? Container(
                                                      width: double.infinity,
                                                      color: Palette.titleBg,
                                                      padding: EdgeInsets.only(
                                                          left: 23,
                                                          top: 5,
                                                          bottom: 5),
                                                      child: Text(
                                                        'OTHER INFORMATION',
                                                        style: AppTextStyle
                                                            .getDynamicFontStyle(
                                                                Palette
                                                                    .primaryTextColor,
                                                                14,
                                                                FontType
                                                                    .Regular),
                                                      ),
                                                    )
                                                  :  Container(
                                                      height: 0.0,
                                                    ),
                                              opportunity.targetAudience ==
                                                      "true"
                                                  ? Container(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              23, 13, 13, 13),
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          UIHelper
                                                              .verticalSpaceSmall,

                                                          location != ""
                                                              ?  Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    otherInformationHeader(
                                                                        'Location You Like To Cover'),
                                                                    otherInformationValue(
                                                                        location
                                                                            .trim()),
                                                                  ],
                                                                )
                                                              :  Container(
                                                                  height: 0.0,
                                                                ),

                                                          opportunity.gender ==
                                                                  ""
                                                              ?  Container(
                                                                  height: 0.0,
                                                                )
                                                              :  Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    UIHelper
                                                                        .verticalSpaceMedium,
                                                                    otherInformationHeader(
                                                                        'Gender'),
                                                                    otherInformationValue(
                                                                        opportunity
                                                                            .gender),
                                                                  ],
                                                                ),

                                                          // UIHelper.verticalSpaceMedium,
                                                          opportunity.ageList
                                                                      .length ==
                                                                  0
                                                              ?  Container(
                                                                  height: 0.0,
                                                                )
                                                              :  Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    UIHelper
                                                                        .verticalSpaceMedium,
                                                                    otherInformationHeader(
                                                                        'Age Group'),
                                                                    getAgeList(),
                                                                  ],
                                                                ),

                                                          opportunity.interestTypeList
                                                                      .length ==
                                                                  0
                                                              ?  Container(
                                                                  height: 0.0,
                                                                )
                                                              :  Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    UIHelper
                                                                        .verticalSpaceMedium,
                                                                    otherInformationHeader(
                                                                        'Interest(s)'),
                                                                     Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children:  List
                                                                              .generate(
                                                                          opportunity
                                                                              .interestTypeList
                                                                              .length,
                                                                          (index) {
                                                                        return otherInformationValue(opportunity
                                                                            .interestTypeList[index]
                                                                            .name);
                                                                      }),
                                                                    ),
                                                                    UIHelper
                                                                        .verticalSpaceMedium,
                                                                  ],
                                                                )
                                                        ],
                                                      ),
                                                    )
                                                  :  Container(
                                                      height: 0.0,
                                                    ),
                                            ],
                                          )
                                        : Container(),
                                  ],
                                ),
                              )
                            :  Container(height: 0.0),
                      ),
                    ),
                    flex: 1,
                  ),
                  widget.pageName == "preview"
                      ?  Container(
                          height: 0.0,
                        )
                      :  Expanded(
                          child: diffrenceInDob < 13
                              ?  Container(
                                  width: double.infinity,
                                  decoration:  BoxDecoration(
                                    color: Palette.webColor,
                                    border: Border.all(
                                        color: ColorValues.DARK_GREY),
                                  ),
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 10.0, 0.0, 10.0),
                                  child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 10.0, 20.0, 10.0),
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    0.0, 0.0, 0.0, 0.0),
                                                child:  Text(
                                                  "FORWARD TO PARENT",
                                                  style: TextStyle(
                                                      fontFamily: Constant
                                                          .customRegular,
                                                      fontSize: 12.0,
                                                      color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                                                ),
                                              ),
                                              onTap: () {
                                                forwardToParentConformAtionDialog(
                                                    opportunity.opportunityId);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                              child:  InkWell(
                                                child: Image.asset(
                                                  'assets/profile/parent/info.png',
                                                  height: 25.0,
                                                  width: 25.0,
                                                ),
                                                onTap: () {
                                                  infoDialog();
                                                },
                                              ),
                                              flex: 0),
                                        ],
                                      )),
                                )
                              :
                          Container(
                                  width: double.infinity,
                                  decoration:  BoxDecoration(
                                    // color: Palette.webColor,
                                    border: Border.all(
                                        color: ColorValues.DARK_GREY),
                                  ),
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 10.0, 0.0, 10.0),
                                  height: 45.0,
                                  child:  Row(
                                    children: <Widget>[
                                       Expanded(
                                        flex: 1,
                                        child:  Container(),
                                      ),
                                       InkWell(
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              15.0, 0.0, 15.0, 0.0),
                                          child:  Container(
                                              height: 25.0,
                                              alignment:
                                                  FractionalOffset.center,
                                              decoration:  BoxDecoration(
                                                //  color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                                border: Border.all(
                                                    color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                                              ),
                                              child: Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    6.0, 0.0, 6.0, 0.0),
                                                child:  Text(
                                                  opportunity.actionType ==
                                                          Constant.LINK_URL
                                                      ? opportunity
                                                                  .linkUrlPosition ==
                                                              Constant
                                                                  .LEARN_MORE
                                                          ? "LEARN MORE"
                                                          : opportunity
                                                                      .linkUrlPosition ==
                                                                  Constant
                                                                      .GET_OFFER
                                                              ? "GET OFFER"
                                                              : "APPLY NOW"
                                                      : opportunity
                                                                  .actionType ==
                                                              Constant
                                                                  .JOIN_GROUP
                                                          ? "JOIN GROUP"
                                                          : opportunity
                                                                      .actionType ==
                                                                  Constant
                                                                      .CALL_NOW
                                                              ? "CALL NOW"
                                                              : "Inquire Now"
                                                                  .toUpperCase(),
                                                  style:  TextStyle(
                                                      color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 12.0,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                              )),
                                        ),
                                        onTap: () {
                                          // apiCallingForIncreaseCount();
                                          if (opportunity.actionType ==
                                              Constant.LINK_URL) {
                                            Navigator.push(
                                                context,
                                                 MaterialPageRoute(
                                                    //   builder: (context) =>  DashBoardWidget()));
                                                    builder: (context) =>  WebViewWidget(
                                                        opportunity.url
                                                                .contains(
                                                                    "http")
                                                            ? opportunity.url
                                                            : "https://" +
                                                                opportunity.url,
                                                        opportunity.linkUrlPosition ==
                                                                Constant
                                                                    .LEARN_MORE
                                                            ? "LEARN MORE"
                                                            : opportunity
                                                                        .linkUrlPosition ==
                                                                    Constant
                                                                        .GET_OFFER
                                                                ? "GET OFFER"
                                                                : "APPLY NOW")));
                                          } else if (opportunity.actionType ==
                                              Constant.JOIN_GROUP) {
                                            if(prefs!=null&&opportunity!=null&& Util.showJoinGroupButton(
                                                prefs,opportunity.schoolCode,
                                                opportunity.actionType)=="true") {
                                              if (opportunity.studentJoinId ==
                                                  "" ||
                                                  opportunity.studentJoinId ==
                                                      "null") {
                                                if (isGroup_AccessControl) {
                                                  apiCallJoin(
                                                      opportunity.groupIdAction);
                                                  ;
                                                } else {
                                                  ToastWrap.showToastForAccessDenied(
                                                      MessageConstant.JOIN_GROUP_DISABLE, context);
                                                }
                                              } else {
                                                apiCallForForwardParent(
                                                    opportunity.groupIdAction,
                                                    opportunity);
                                              }
                                            }else{
                                              ToastWrap.showToast(MessageConstant.OPPORTUNITY_NOT_IN_COMMUNITY, context);

                                            }
                                          } else if (opportunity.actionType ==
                                              Constant.CALL_NOW) {
                                            String callingNumber =
                                                opportunity.callingNumber;
                                            launch("tel:" + callingNumber);
                                          } else {
                                            Navigator.of(context).push(
                                                 MaterialPageRoute(
                                                    builder: (BuildContext
                                                            context) =>
                                                         InquireNowScreen(
                                                            opportunity
                                                                .opportunityId,
                                                            userIdPref,
                                                            opportunity.formId,
                                                            opportunity.offerId
                                                                .toString(),
                                                            "")));
                                          }
                                        },
                                      ),
                                       Expanded(
                                          flex: 1, child:  Container()),
                                    ],
                                  )),
                          flex: 0,
                        )
                ],
              )
            :  Container(
                height: 0.0,
              ),
      )),
    );
  }

  Widget getScheduleWidget(OpportunityModelForFeed opportunity) {
    print(
        'opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Container(
        child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          'Scheduled For: ',
          style: AppTextStyle.getDynamicFontStyle(
              Palette.primaryTextColor, 14, FontType.Regular),
        ),
         Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children:
               List.generate(opportunity.scheduleModelParam.length, (index) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child:
                  /*Text(
                          opportunity
                              .scheduleModelParam[
                          index]
                              .day +
                              " : " +
                              getHours(
                                  index),
                          maxLines: null,
                          style: AppTextStyle.getDynamicFont(
                               ColorValues.HEADING_COLOR_EDUCATION,
                              12,
                              FontType
                                  .Regular))*/
                  getHoursData(index),
            );
          }),
        )
      ],
    ));
  }

  String getConvertedTime(int time) {
    String timeReturn = "";
    if (time != null) {
      int startTimeHour = DateTime.fromMillisecondsSinceEpoch(time).hour;
      int startTimeMinute = DateTime.fromMillisecondsSinceEpoch(time).minute;

      if (startTimeHour > 12) {
        String startTimeH = (startTimeHour - 12).toString();

        startTimeH = startTimeH.toString().length == 2
            ? startTimeH.toString()
            : "0" + startTimeH.toString();
        String startTimeM = startTimeMinute.toString().length == 2
            ? startTimeMinute.toString()
            : "0" + startTimeMinute.toString();

        return timeReturn = startTimeH.toString() + ":" + startTimeM + " pm";
      } else {
        String startTimeH = startTimeHour.toString().length == 2
            ? startTimeHour.toString()
            : "0" + startTimeHour.toString();
        String startTimeM = startTimeMinute.toString().length == 2
            ? startTimeMinute.toString()
            : "0" + startTimeMinute.toString();

        return timeReturn =
            startTimeH.toString() + ":" + startTimeM.toString() + " am";
      }
    } else {
      return "";
    }
  }

  Widget getAgeList() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(opportunity.ageList.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 2.0, 0.0, 0.0),
          child: Text(
            opportunity.ageList[index].from +
                "-" +
                opportunity.ageList[index].to +
                " years ",
            style: AppTextStyle.getDynamicFontStyle(
                Palette.primaryTextColor, 16, FontType.Regular),
          ),
        );
      }),
    );
  }

  otherInformationHeader(String title) {
    return Text(
      title,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
    );
  }

  otherInformationValue(String value) {
    return Text(
      value,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.primaryTextColor, 16, FontType.Regular),
    );
  }

  bottomWidgetDataTitleWidget(String text, Color color) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(color, 12, FontType.Regular),
    );
  }

  bottomWidgetDataValueWidget(String text) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.accentColor, 24, FontType.Regular),
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now =  DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter =  DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter =  DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  Widget getMentorAdvisorTutor() {
    print('opportunity.fees:: ${opportunity.fees}');
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall,
        AppTextStyle.getLableTextForDetail('Category: ', categoryString),
        //opportunity.toMapStringForDesignation()),
        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7"
            ? Container()
            : AppTextStyle.getLableTextForDetail('Subject: ', subjectString),
        //opportunity.toMapStringSubject()),
        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7"
            ? Container()
            : AppTextStyle.getLableTextForDetail(
                'Qualification: ', opportunity.toMapStringQualification()),

        /*opportunity.offerId == "6" ? Container(): UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7" ? Text(
          "Mentee Support Offered: " +
              opportunity
                  .menteeSupport,
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        )
            :
        opportunity.offerId == "8" ? Text(
            "Advisor Support Offered: " +
                opportunity.advisorSupportOffered,
            style: AppTextStyle
                .getDynamicFont(
                 Color(
                    ColorValues
                        .HEADING_COLOR_EDUCATION),
                14,
                FontType
                    .Regular)) : Container(),
                    opportunity.offerId == "8" ? UIHelper
            .verticalSpaceSmall1: Container(),
        opportunity.offerId == "8" ? Text(
          "Project Areas: ${opportunity.projectAreas}",
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        ): Container(),

                    */

        UIHelper.verticalSpaceSmall1,
        AppTextStyle.getLableTextForDetail(
            'Fees: ',
            opportunity.fees == "0"
                ? MessageConstant.FEE_EMPTY_VAL
                : opportunity.fees),
      ],
    );
  }

  getHoursData(index) {
    return RichText(
      textAlign: TextAlign.start,
      maxLines: null,
      text: TextSpan(
        text:
            opportunity.scheduleModelParam[index].day + ": " + getHours(index),
        style: AppTextStyle.getDynamicFont(
             ColorValues.HEADING_COLOR_EDUCATION,
            14,
            FontType.Regular),
        children: <TextSpan>[
          TextSpan(
            text: opportunity.timeZone == null ||
                    opportunity.timeZone == "" ||
                    opportunity.timeZone == "null"
                ? ""
                : "(" + opportunity.timeZone + ")",
            style:  TextStyle(
                color:  ColorValues.GREY__COLOR,
                fontSize: 14.0,
                fontWeight: FontWeight.normal,
                fontFamily: Constant.customRegular),
          )
        ],
      ),
    );
  }

  String getHours(index) {
    String timeReturn = "";
    try {
      for (HoursData hours in opportunity.scheduleModelParam[index].hours) {
        timeReturn = Util.getConvertedTimeForScheduleDate(hours.timeFrom) +
            " - " +
            Util.getConvertedTimeForScheduleDate(
                hours.timeTo == null ? hours.timeFrom : hours.timeTo) +
            " | " +
            timeReturn;
      }

      return timeReturn.substring(0, timeReturn.lastIndexOf("|"));
    } catch (e) {
      return timeReturn;
    }
  }

  userImageListUI() {
    return Container(
      child: opportunity != null && opportunity.userImageModelParam.length > 0
          ? PaddingWrap.paddingfromLTRB(
              0.0,
              10.0,
              15.0,
              10.0,
               Container(
                  child:  GridView.count(
                      primary: false,
                      shrinkWrap: true,
                      padding: const EdgeInsets.all(0.0),
                      crossAxisSpacing: 10.0,
                      childAspectRatio: 1.5,
                      scrollDirection: Axis.vertical,
                      crossAxisCount: 3,
                      children:  List.generate(
                          opportunity.userImageModelParam.length, (index2) {
                        return  Container(
                            child:  Stack(
                          children: <Widget>[
                             InkWell(
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  placeholder: 'assets/aerial/default_img.png',
                                  image: Constant.IMAGE_PATH +
                                      opportunity
                                          .userImageModelParam[index2].file,
                                  height: 80.0,
                                  width: 120.0,
                                ),
                                onTap: () {
                                  Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                           CommonFullViewWidget(
                                              opportunity.userImageModelParam,
                                              MessageConstant.HOME_HEDING,
                                              index2,
                                              MessageConstant
                                                  .VIEWER_END_REWCOMMENDATION_HEDING)));

                                  /*  Navigator.push(
                                  context,
                                   HeroDialogRoute(
                                    builder: (BuildContext context) {
                                      return  Center(
                                        child:  AlertDialog(
                                          content:  Container(
                                            child:  Hero(
                                              tag: 'developer-hero',
                                              child:  Container(
                                                height: 200.0,
                                                width: 200.0,
                                                child: Image.network(
                                                  Constant.IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          path.file),
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              ),
                                            ),
                                          ),
                                          actions: <Widget>[
                                             FlatButton(
                                              child:  Text('Close'),
                                              onPressed: Navigator.of(context).pop,
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                );*/
                                }),
                          ],
                        ));
                      })

                      /* opportunity.userImageModelParam.map((path) {
                  return  Container(
                      child:  Stack(
                    children: <Widget>[
                       InkWell(
                          child: FadeInImage.assetNetwork(
                            fit: BoxFit.cover,
                            placeholder: 'assets/aerial/default_img.png',
                            image: Constant.IMAGE_PATH + path.file,
                            height: 80.0,
                            width: 120.0,
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                               HeroDialogRoute(
                                builder: (BuildContext context) {
                                  return  Center(
                                    child:  AlertDialog(
                                      content:  Container(
                                        child:  Hero(
                                          tag: 'developer-hero',
                                          child:  Container(
                                            height: 200.0,
                                            width: 200.0,
                                            child: Image.network(
                                              Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getMediumImage(
                                                      path.file),
                                              fit: BoxFit.fitHeight,
                                            ),
                                          ),
                                        ),
                                      ),
                                      actions: <Widget>[
                                         FlatButton(
                                          child:  Text('Close'),
                                          onPressed: Navigator.of(context).pop,
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          }),
                    ],
                  ));
                }).toList(),*/
                      )))
          :  Container(
              height: 0.0,
            ),
    );
  }

  getJobInternship() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall,
        AppTextStyle.getLableTextForDetail('Job Type: ', opportunity.jobType),
        UIHelper.verticalSpaceSmall,
        AppTextStyle.getLableTextForDetail(
            'Job Location: ', opportunity.jobLocation),
        UIHelper.verticalSpaceSmall,
      ],
    );
  }

  void getData() {
    //category
    if (opportunity.bio != null) {
      if (opportunity.bio.length > 150) {
        firstHalf = opportunity.bio.substring(0, 150);
        secondHalf = opportunity.bio.substring(150, opportunity.bio.length);
      } else {
        firstHalf = opportunity.bio;
        secondHalf = "";
      }
    }

    categoryString = opportunity.toMapStringForDesignation();
    if (opportunity.selectedDesignationCareerOption != null &&
        opportunity.selectedDesignationCareerOption.length > 0) {
      if (categoryString != "")
        categoryString = categoryString +
            " | " +
            opportunity.toMapStringForDesignationCareer();
      else
        categoryString = opportunity.toMapStringForDesignationCareer();
    }
    if (opportunity.selectedDesignationOtherOption != null &&
        opportunity.selectedDesignationOtherOption.length > 0) {
      if (categoryString != "")
        categoryString = categoryString +
            " | " +
            opportunity.toMapStringForDesignationOther();
      else
        categoryString = opportunity.toMapStringForDesignationOther();
    }

    //Subject
    subjectString = opportunity.toMapStringSubject();
    if (opportunity.selectedSubjectOtherOption != null &&
        opportunity.selectedSubjectOtherOption.length > 0) {
      if (subjectString != "")
        subjectString =
            subjectString + " | " + opportunity.toMapStringSubjectOther();
      else
        subjectString = opportunity.toMapStringSubjectOther();
    }

    descVal = '';
    if (opportunity.offerId == "1" ||
        opportunity.offerId == "2" ||
        opportunity.offerId == "3") {
      descVal = opportunity.project;
    } else if (opportunity.offerId == "4" || opportunity.offerId == "5") {
      descVal = opportunity.serviceDesc;
    } else {
      descVal = opportunity.description;
    }

    if (descVal != null) {
      if (descVal.length > 150) {
        firstHalfDesc = descVal.substring(0, 150);
        secondHalfDesc = descVal.substring(150, descVal.length);
      } else {
        firstHalfDesc = descVal;
        secondHalfDesc = "";
      }
    }

    setState(() {
      categoryString;
      subjectString;
      secondHalfDesc;
      firstHalfDesc;
    });
  }
}
