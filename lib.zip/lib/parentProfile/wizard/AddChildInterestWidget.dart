import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/wizard/AllAccomplishmentListWidget.dart';
import 'package:spike_view_project/parentProfile/wizard/CompetenciesParentStudent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/studentWizard/SkillSelectionWiget.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';
import 'package:spike_view_project/skill/model/SkillModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/parentProfile/wizard/AddChildOtherInterestWidget.dart';

// Create a Form Widget
class AddChildStudentInterestWidget extends StatefulWidget {

  //SkillIntrestDataModel _mSkillModel;
  //ProfileInfoModal profileInfoModal;
  StudentDataModel studModel;
  String pageName;
  String sasToken;
  int stage;
  AddChildStudentInterestWidget(this.studModel,this.pageName, this.sasToken,this.stage);
  //AddChildStudentInterestWidget(this.profileInfoModal);


  @override
  AddChildStudentInterestWidgetState createState() {
    return  AddChildStudentInterestWidgetState();
  }
}

class AddChildStudentInterestWidgetState extends State<AddChildStudentInterestWidget> {
  final _formKey = GlobalKey<FormState>();
  SharedPreferences prefs;
  String userIdPref, token;

  SkillModel _skillModel=new SkillModel();

  List<SkillData> selectedLoveInterestsList =  List<SkillData>();

  SkillModel _mSkillModelForAlready=new SkillModel();
  String strOtherInterest='';

  TextEditingController otherInterestController =  TextEditingController(text: "");


  final FocusNode _otherInterestFocus = FocusNode();

  SkillIntrestDataModel widgetSkillModel = null;
  String popString='';

  bool isOptionClicked = false;
//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_WIZARD_USERID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    print('inside getSharedPreferences() EditInterest');
    await apiCallForSkill(context);
    await callLoveInterestApi();

  }

  //=========================================================Api Calling =======================================

  Future<String> callLoveInterestApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_GET_HOBBY_TYPE_API+"love_interests", "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _skillModel =  SkillModel.fromJson(response.data);
              _mSkillModelForAlready =  SkillModel.fromJson(response.data);
              //====================================
              //_skillModel =  SkillModel.fromJson(response.data);
              if(widgetSkillModel != null) {
              try{
                print('Apurva widgetSkillModel.result.length:: ${widgetSkillModel.result.length}');
                if(widgetSkillModel.result.length > 0){
                  for (Skills _mSkills in widgetSkillModel.result[0].loveInterests) {
                    if(_mSkills.hobbyId.toString() =='null' || _mSkills.hobbyId.toString() ==""){
                      selectedLoveInterestsList.add(new SkillData(
                        name: _mSkills.name,
                      ));

                      _mSkillModelForAlready.skillList.add(new SkillData(
                          name: _mSkills.name));

                    }else {
                      for (int i = 0; i < _skillModel.skillList.length; i++) {
                        try{
                          if (_mSkills.hobbyId.toString() == _skillModel.skillList[i].hobbyId.toString()) {
                            print('Apurva 555 if');
                          _skillModel.skillList[i].isSelected = true;
                          selectedLoveInterestsList.add(new SkillData(
                              hobbyId: _skillModel.skillList[i].hobbyId,
                              name: _skillModel.skillList[i].name,
                              type: i.toString()));

                            _mSkillModelForAlready.skillList.add(new SkillData(
                                hobbyId: _skillModel.skillList[i].hobbyId,
                                name: _skillModel.skillList[i].name,
                                type: i.toString()));
                        }
                      }catch(e){
                print('Apurva 555 if catch error:: ${e.toString()}');
              }
                      }
                    }
                  }
                }

              }catch(e){
                print('inside love interest parent catch error:: ${e.toString()}');
              }
              }
              setState(() {
                _skillModel;
                widgetSkillModel;
                selectedLoveInterestsList;
              });


              //====================================
              //await getUnSelectedList();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      e.toString();
    }
  }
  //--------------------------Edit Data ------------------

  Future editInterest(String navigateTo) async {
    print('inside editInterest() navigateTo:: $navigateTo');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //  CustomProgressLoader.showLoader(context);

        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": 1,//int.parse(widget.studModel.roleId),
          //"userHobbyId":widgetSkillModel.result.length > 0  ? widgetSkillModel.result[0].userHobbyId : 0,
          "love_interests": selectedLoveInterestsList.map((item) => item.toJson()).toList()
        };

        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_SKILL_API, map);
        try {
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];

              if (status == "Success") {
                popString = "push";
                //Navigator.pop(context, popString);
                print('Data updated successfully');
                if(navigateTo == 'next') {
                  onTapNextPage();
                }
                else
                  onTapPrePage();
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } catch (e) {
          print('inside catch inner::::::: ${e.toString()}');
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      print('inside catch outer::::::: ${e.toString()}');
      e.toString();
    }
  }


  @override
  void initState() {
    // TODO: implement initState
    try {
      //widgetSkillModel = widget._mSkillModel;
      getSharedPreferences();
    } catch (e) {
      print(e.toString());
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    void conformationForSkip() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to skip this step?",
                                                      textAlign:
                                                      TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Skip",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onTapNextPage();
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }
    final double statusBarHeight = MediaQuery.of(context).padding.top;


    //-------------------------------------Main Ui ------------------------------------------
    return  WillPopScope(
      onWillPop: () {
        Navigator.pop(context, popString);
      },
      child:  GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child:  Scaffold(
              backgroundColor:  ColorValues.SCREEN_BG_COLOR,
              //backgroundColor:  Color(0XFFF4F2F2),
              body: Stack(
                children: <Widget>[
               Positioned(
              bottom: 65.0,
                right: 13.0,
                left: 13.0,
                top: 0.0,

                child:  SingleChildScrollView(
                      child: Column(
                        children: <Widget>[
                          //CustomViews.getSepratorLine(),
                          Padding(
                            padding:  EdgeInsets.only(top: statusBarHeight + 20,left: 13.0,right: 13.0,bottom: 7),
                            child: Center(
                              child:  Image.asset(
                                  "assets/progress_indecator/indicator_step5.png",
                                  height: 26.0,
                                  width: 300.0,
                                  fit: BoxFit.fitWidth
                              ),
                            ),
                          ),
                          Padding(
                            padding:  EdgeInsets.only(top:20),
                            child:  Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                 Text(
                                  //"Step 5 of 7",
                                  "",
                                  style:  TextStyle(
                                      fontSize: 15.0,
                                      fontFamily: Constant.customRegular,
                                      color:  ColorValues.HEADING_COLOR_EDUCATION),
                                ),
                                InkWell(
                                  child:  Text(
                                    "SKIP ",
                                    style:  TextStyle(
                                        fontSize: 14.0,
                                        fontFamily: Constant.customRegular,
                                        color:
                                         ColorValues.GREY_TEXT_COLOR),
                                  ),
                                  onTap: () {
                                    //onTapNextPage();
                                    if(isOptionClicked)
                                      conformationForSkip();
                                    else
                                      onTapNextPage();
                                  },
                                ),

                              ],
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(top:10.0,left: 13.0),
                            child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Padding(
                                      padding:
                                      const EdgeInsets.fromLTRB(0.0, 12, 0, 5),
                                      child:  Image.asset(
                                          "assets/story_new/add_knowledge.png",
                                          height: 50.0,
                                          width: 50.0,
                                          fit: BoxFit.fitHeight),
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        5.0,
                                        TextViewWrap.textViewMultiLine(
                                            "What does your child love to do?",
                                            TextAlign.start,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            18.0,
                                            FontWeight.bold,3)),
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        10.0,
                                        TextViewWrap.textViewMultiLine(
                                            "Share some hobbies and activities they love to pursue.",
                                            TextAlign.center,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.normal,4)),
                                  ],
                                ),
                                getInterestTextField(),
                                //Container(height: 5.0,),
                                Container(height: 13.0,),
                                getUserInterestSelectedChips(selectedLoveInterestsList,true),
                                _skillModel !=null ?
                                getUserInterestChips(_skillModel.skillList,false): Container(height: 0.0,),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                   Positioned(
                      bottom: 0.0, left: 0, right: 0, child: getBottomBar())
                ],
              ))),
    );
  }

  getUserInterestSelectedChips(_items, bool isSelected) {
    return _items != null ? MediaQuery.removePadding(
      context: context,
      removeTop: true,
      removeBottom: true,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        primary: true,
        shrinkWrap: true,
        children: <Widget>[
          Wrap(
            spacing: 5.0,
            runSpacing: 0.0,
            children: List<Widget>.generate(

                _items.length, // place the length of the array here
                    (int index) {
                  return InputChip(
                    label: Text('${_items[index].name}',maxLines: 4,softWrap: true,),
                    backgroundColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
                    shape: StadiumBorder(side: BorderSide(color: ColorValues.BLUE_COLOR_BOTTOMBAR),),
                    onSelected: (bool value) {},
                    deleteIcon: Icon(
                      Icons.clear,
                      color:  ColorValues.WHITE,
                      size: 16.0,
                    ),
                    onDeleted: () {
                      toggalSelection(isSelected,index);
                    },
                    labelStyle: TextStyle(
                      color: ColorValues.WHITE,
                      fontSize: 16,
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12.0,vertical: 3.0),
                  );
                }
            ).toList(),
          ),
        ],
      ),
    ): Container(height: 0,width: 0,);
  }

  getUserInterestChips(_items, bool isSelected) {
    return _items != null ? MediaQuery.removePadding(
      context: context,
      removeTop: true,
      removeBottom: true,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        primary: true,
        shrinkWrap: true,
        children: <Widget>[
          Wrap(
            spacing: 0.0,
            runSpacing: 0.0,
            children: List<Widget>.generate(

                _items.length, // place the length of the array here
                    (int index) {
                  return _items[index].isSelected && !isSelected
                      ?  Container(
                    height: 0.0,width: 0.0,
                  )
                      : Padding(
                    padding: const EdgeInsets.only(right:5.0),
                        child: InputChip(
                    label: Text('${_items[index].name}',softWrap: true,),
                    backgroundColor: ColorValues.WHITE,
                    shape: StadiumBorder(side: BorderSide(color: ColorValues.BORDER_COLOR),),
                    onSelected: (bool value) {
                        if(!isSelected){
                          //print("selected index:: $index");
                          toggalSelection(isSelected,index);
                        }
                    },
                    labelStyle: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16,
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12.0,vertical: 3.0),
                  ),
                      );
                }
            ).toList(),
          ),
        ],
      ),
    ): Container(height: 0,width: 0,);
  }


  void toggalSelection(bool isSelected, int index) {
    if(!isOptionClicked){
      isOptionClicked = true;
    }
    if(isSelected){
      //add item to unselected list and remove from selected list
      SkillData item = selectedLoveInterestsList[index];
      if (item.type != null && item.type != "") {
        _skillModel.skillList[int.parse(item.type)].isSelected = false;
      }
      selectedLoveInterestsList.removeAt(index);

      _mSkillModelForAlready.skillList.clear();
      _mSkillModelForAlready.skillList.addAll(_skillModel.skillList);
      _mSkillModelForAlready.skillList.addAll(selectedLoveInterestsList);

      setState(() {
        _skillModel;
        selectedLoveInterestsList;
        _mSkillModelForAlready;
      });
    }else{
      //add item to selected list and remove from unselected list
      _skillModel.skillList[index].isSelected = true;
      selectedLoveInterestsList.add(new SkillData(
          hobbyId: _skillModel.skillList[index].hobbyId,
          name: _skillModel.skillList[index].name,
          type: index.toString()));

      setState(() {
        _skillModel;
        selectedLoveInterestsList;
      });
    }
  }

  getInterestTextField() {
    return  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          controller: otherInterestController,
          maxLength: TextLength.TESTSCORE_DESC_MAX_LENGTH,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",errorStyle:Util.errorTextStyle,
            labelText: "Add Other Interest(s)",
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            //hintText: "Add Additional Interests",
            hintStyle:  TextStyle(
                color:  ColorValues.hintColor,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),
          /*validator: (val) =>
          val.trim().isEmpty ? MessageConstant.ENTER_DESCRIPTION_VAL : null,*/
          onSaved: (val) => strOtherInterest = val.trim(),
          onFieldSubmitted: (term) {
            print('onFieldSubmitted clicked');
            _otherInterestFocus.unfocus();
            if (otherInterestController.text != null && otherInterestController.text.trim() != "") {
              if (!selectedLoveInterestsList.contains(otherInterestController.text)) {

                List <SkillData>
                results = _mSkillModelForAlready.skillList.where((user) =>
                    user.name.trim().toString().toLowerCase().contains(term.toString().toLowerCase().trim())
                ).toList();


                if (results.length==0){
                  _mSkillModelForAlready.skillList.add(new SkillData(name: term));
                  selectedLoveInterestsList.add(SkillData(name: otherInterestController.text));
                  otherInterestController.clear();
                  setState(() {
                  });
                }else {
                  otherInterestController.clear();
               //   ToastWrap.showToast(MessageConstant.ALREADY_INTREST_ADDEDD, context);
                }

              }
            }

            setState(() {
              selectedLoveInterestsList;
            });
          },
        ));
  }

  Future<void> onTapNextPage() async {
    //String result = await
    print('inside onTapNextPage()');
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
         AddChildStudentOtherInterestWidget(widget.studModel, '', widget.sasToken,widget.stage)));
    /*Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
         SkillSelectionWiget(widgetSkillModel.result[0].skills)));*/
    /*if (result == "push") {
      popString = "push";
      apiCallForSkill(context);
    }*/
  }
  Future<void> onTapPrePage() async {
    //String result = await
    //Move to Accomplishment Page
    /*if (widget.studModel.isAchievement == "true") {
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
           AllAccomplishmentListWidget(widget.studModel)));
    } else {
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>  CompetenciesParentStudent(
              widget.sasToken,
              widget.studModel.email,
              widget.studModel.lastName == "" || widget.studModel.lastName == "null"
                  ? widget.studModel.firstName
                  : widget.studModel.firstName + " " + widget.studModel.lastName,
              widget.studModel,
              "")));
    }*/
    print('apurva widget.pageName;;; ${widget.pageName}');
    if (widget.pageName == 'all')
    Navigator.pop(context);

    Navigator.pop(context);
  }

  Future<String> apiCallForSkill(context) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_GET_SKILL_API+userIdPref+"&roleId=1", "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              widgetSkillModel =  SkillIntrestDataModel.fromJson(response.data);
              setState(() {
                _skillModel;
                widgetSkillModel;
                selectedLoveInterestsList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      e.toString();
    }
  }

  Container getBottomBar() {
    return  Container(
        child:  Row(
          children: <Widget>[
             InkWell(
              child:  Padding(
                  padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                  child: Image.asset(
                    'assets/newDesignIcon/parentProfile/backword.png',
                    height: 45.0,
                    width: 45.0,
                  )),
              onTap: () {
                print('on click previous');
                editInterest('previous');
              },
            ),
             Expanded(
              child:  InkWell(
                child:  Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                    child:  Text(
                      "",
                      style: TextStyle(
                          fontSize: 16.0,
                          fontFamily: Constant.customRegular,
                          color: ColorValues.GREY_TEXT_COLOR),
                      textAlign: TextAlign.center,
                    )),
                onTap: () {
                  // skipOnClick();
                },
              ),
              flex: 1,
            ),
            selectedLoveInterestsList.length>0
                ?  InkWell(
              child:  Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                  child: Image.asset(
                    'assets/newDesignIcon/parentProfile/next.png',
                    height: 45.0,
                    width: 45.0,
                  )),
              onTap: () {
                editInterest('next');
              },
            )
                :  Padding(
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                child: Image.asset(
                  'assets/newDesignIcon/parentProfile/next_gray.png',
                  height: 45.0,
                  width: 45.0,
                ))
          ],
        ));
  }

}
