import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class SelectedGroup extends StatefulWidget {
  List<Groups> tagList;
  UserPostModal userPostModal;
  SelectedGroup(this.userPostModal,this.tagList);

  @override
  SelectedGroupState createState() {
    return  SelectedGroupState(tagList);
  }
}

class SelectedGroupState extends State<SelectedGroup> {
  List<Groups> tagList;
  SharedPreferences prefs;
  BuildContext context;
  String userIdPref, userProfilePath;
bool isGroup_AccessControl=true;
  SelectedGroupState(this.tagList);

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    try {
      isGroup_AccessControl = prefs
          .getString(UserPreference.ACCESS_CONTROL_GROUP)
          .toLowerCase() ==
          "true";
    } catch (e) {
      isGroup_AccessControl = true;
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above
    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            appBar:  AppBar(
              elevation: 0.0,
              automaticallyImplyLeading: false,
              titleSpacing: 2.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  )
                ],
              ),
              actions: <Widget>[
                 InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      5.0,
                      0.0,
                      8.0,
                      5.0,
                       Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                           Text(
                            " ",
                            style:  TextStyle(
                                fontSize: 16.0,
                                fontFamily: Constant.customRegular,
                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                          )
                        ],
                      )),
                  onTap: () {},
                )
              ],
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Groups",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              backgroundColor: Colors.white,
            ),
            body:  ListView.builder(
                itemCount: tagList.length,
                itemBuilder: (BuildContext context, int position) {
                  return  Padding(
                      padding:  EdgeInsets.all(0.0),
                      child:  InkWell(
                        child:  Row(
                          children: <Widget>[
                             Expanded(
                              child: PaddingWrap.paddingAll(
                                10.0,
                                 Container(
                                    width: 50.0,
                                    height: 50.0,
                                    child:  ClipOval(
                                        child: FadeInImage.assetNetwork(
                                          fit: BoxFit.cover,
                                          placeholder:
                                          'assets/newDesignIcon/group/default_circle_bg.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getSmallImage(
                                                  tagList[position].groupImage),
                                        ))),
                              ),
                              flex: 0,
                            ),
                             Expanded(
                                child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        PaddingWrap.paddingfromLTRB(
                                            5.0,
                                            0.0,
                                            0.0,
                                            2.0,
                                            TextViewWrap.textView(
                                                tagList[position].groupName,
                                                TextAlign.start,
                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                15.0,
                                                FontWeight.normal)),


                                      ],
                                    ),

                                  ],
                                ),
                                flex: 2),
                          ],
                        ),
                        onTap: () {

                          if (isGroup_AccessControl) {
                            if (Util.showJoinGroupButton(
                                prefs,
                                widget.userPostModal.schoolCode,
                                Constant.JOIN_GROUP) ==
                                "true") {
                              Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>  GroupDetailWidget(tagList[position].groupId, "", "", "", "")));


                            } else {
                              ToastWrap.showToast(
                                  MessageConstant
                                      .OPPORTUNITY_NOT_IN_COMMUNITY,
                                  context);
                            }
                          } else {
                            ToastWrap.showToastForAccessDenied(
                                MessageConstant.JOIN_GROUP_DISABLE, context);
                          }



                          }



                      ));
                })));
  }
}
