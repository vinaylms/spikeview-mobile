import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges_notification.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/gateway/more_data.dart';
import 'package:spike_view_project/parentProfile/ParentOnBoarding.dart';
import 'package:spike_view_project/patnerFlow/PartnerOnBoarding.dart';
import 'package:spike_view_project/patnerFlow/opportunity/opportunity_selection.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';

//==========  IOS file ==========
import 'package:adhara_socket_io/manager.dart';
import 'package:dio/dio.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/ChatReafctor/app/locator.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/PublicProfileFilter/PublicViewModel/PublicViewModel.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicViewForUser.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomPresoViewForUser.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomViewForUser.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/drawer/ProfileVisibilitySetting.dart';

//import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:spike_view_project/gateway/ChangePasswordNew.dart';
import 'package:spike_view_project/home/OpportunityViewOnNotificationClick.dart';
import 'package:spike_view_project/notification/FeedDetailWidget.dart';
import 'package:spike_view_project/notification/FeedDetailWidgetForBoat.dart';
import 'package:spike_view_project/notification/OpportunityForBoat.dart';
import 'package:spike_view_project/notification/opportunityRejected.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parentProfile/RecommendationListForParent.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PartnerRejectionReason.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForBoatReview.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/recommendation/manageRecommendation/Manage_Recommendation_dashbaord.dart';
import 'package:spike_view_project/recommendation/manageRecommendation/manage_recommendation.dart';
import 'package:spike_view_project/unsubscribe/UnsubscribeWidget.dart';
import 'package:spike_view_project/updateEmail/email_update_success.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gallery/FullImageViewPager.dart';

import 'package:spike_view_project/gateway/ChangePassword.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/notification/NotificationWidget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';

import 'package:spike_view_project/recommendation/SharedRecoomendAtion.dart';

import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:stacked_services/stacked_services.dart';
import 'package:url_launcher/url_launcher.dart';

import 'ChatReafctor/view/chat_friend_list_with_header.dart';
import 'badges/new_badges/badges_manage_student.dart';
import 'badges/new_badges/request_badges_view.dart';
import 'component/app_constants.dart';
import 'constant/MessageConstant.dart';
import 'db/db_helper_new.dart';
import 'gateway/EmailVerification.dart';
import 'gateway/Signup_As_Student_Widget_New.dart';
import 'group/group_list_share_flow.dart';
import 'home/AddPost.dart';
import 'modal/CompanyProfileModel.dart';
import 'modal/ProfileInfoModel.dart';
import 'notification/boat_report/FeedReportWidgetBoat.dart';
import 'notification/boat_report/GroupReportWidgetBoat.dart';

import 'notification/boat_report/StudentProfileReportWidgetBoat.dart';

const _kTestingCrashlytics = true;

void main() async {
  await runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    setupLocator();
    await Firebase.initializeApp(
        options: Platform.isIOS ? Constant.ios : Constant.android);

    DbHelper helper = DbHelper();
    helper.initializeDb();

    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;
    runApp(new MaterialApp(
      theme: ThemeData(fontFamily: Constant.TYPE_CUSTOMREGULAR),
      home: SplashScreen(),
      routes: <String, WidgetBuilder>{
        //5
        '/dashboard': (BuildContext context) =>
            DashBoardWidget("false", "false", "false"),
        '/spike_view_project': (BuildContext context) => LoginPage(
              null,
            ),
        //7
      },
      navigatorKey: locator<NavigationService>().navigatorKey,
    ));
  }, (error, stackTrace) {
    FirebaseCrashlytics.instance.recordError(error, stackTrace);
  });
}

bool isAlreadyLoggedIn = false;
bool isPasswordChanged = false;
bool isProfileCreatedByParent = false;
bool userLoginFirstTime = false;
PublicViewModel _PublicViewModel;

bool isParent = false;
String roleId = "";
String userIdPref = "";
String userEmail = "";
String userName = "";
final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();

class SplashScreen extends StatefulWidget {
  @override
  SplashScreenState createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> {
  bool _visible = true;
  SharedPreferences prefs;
  bool isLoading = false;
  static CompanyProfileModel companyModelNew;

  //FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;
  bool isPathAvailable = false;
  static StreamController syncDoneController = StreamController.broadcast();
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String sharedProfileId = "";
  static const channel = BasicMessageChannel<String>('foo', StringCodec());
  BuildContext context;
  ShareProfileModal shareProfileModal;
  List<SharedMediaFile> imageList = List();
  StreamSubscription _intentDataStreamSubscription;
  List<SharedMediaFile> _sharedFiles;
  String _sharedText;
  CompanyProfileModel companyModel;
  ProfileInfoModal profileInfoModal;
  RegExp exp = RegExp(
      r"(http|ftp|https|Https|Http)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");
  bool isContainPass = false;
  var isConnect;
  String sasToken = '';

  void afterAnimation() {
    if (mounted) {
      setState(() {
        _visible = false;
        startTime();
      });
    }
  }

  // Define an async function to initialize FlutterFire
  Future<void> _initializeFlutterFire() async {
    if (_kTestingCrashlytics) {
      // Force enable crashlytics collection enabled if we're testing it.
      await FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(true);
    } else {
      // Else only enable it in non-debug builds.
      // You could additionally extend this to allow users to opt-in.
      await FirebaseCrashlytics.instance
          .setCrashlyticsCollectionEnabled(!kDebugMode);
    }
  }

  void addUser() {
    Map map = {
      "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
      //"deviceId": deviceId,
      //"roleId": roleId,
    };
    print("data for addUser" + map.toString());
    GlobalSocketConnection.socket.emitWithAck("chat-login", [map]).then((data) {
      // this callback runs when this specific message is acknowledged by the server
      print("chat-login++++" + data.toString());
    });
  }

  Future companyInfoApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=" + roleId,
          "get");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response comapny" + response.toString());
      print("response comapny userIdPref" + userIdPref + " &roleId " + roleId);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            var map = response.data['result'];
            if (map != null) {
              companyModel = ParseJson.parseCompanyInfoData(map);
              if (companyModel != null) {
                companyModelNew = companyModel;
                prefs.setString(UserPreference.COMPANY_IMAGE_PATH,
                    companyModel.profilePicture);

                //for remove college counselling
                for (int i = 0; i < companyModel.offers.length; i++) {
                  if (companyModel.offers[i].offerId == 3) {
                    companyModel.offers.removeAt(i);
                  }
                }

                prefs.setString(
                    UserPreference.COMPANY_NAME_PATH, companyModel.name);
              }
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      e.toString();
    }
  }

  Future profileApiParent(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      print("++++ENDPOINT_PERSONAL_INFO+PARENT+++" +
          Constant.ENDPOINT_PERSONAL_INFO_NEW +
          userIdPref +
          "/false/1/0");
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_PERSONAL_INFO_NEW + userIdPref + "/false/" + "2/0",
          "get");
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response parent" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            profileInfoModal =
                ParseJson.parseMapUserProfile(response.data['result']);

            if (profileInfoModal != null) {
              prefs.setString(
                  UserPreference.CREATION_TIME, profileInfoModal.creationTime);
              prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
              print("isHide+++" + prefs.getString(UserPreference.ISHide));
              prefs.setString(UserPreference.ZIPCODE, profileInfoModal.zipCode);
              prefs.setString(UserPreference.NAME,
                  profileInfoModal.firstName + " " + profileInfoModal.lastName);
              prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                  profileInfoModal.profilePicture);
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      print("data+++" + e.toString());
      e.toString();
    }
  }

  Future profileApiChild(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("++++ENDPOINT_PERSONAL_INFO+Child+++" +
            Constant.ENDPOINT_PERSONAL_INFO_NEW +
            userIdPref +
            "/false/1/0");
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_PERSONAL_INFO_NEW + userIdPref + "/false/1/0",
            "get");

        print("ENDPOINT_PERSONAL_INFO++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (mounted) {
                setState(() {});
                if (profileInfoModal != null) {
                  if (mounted) {
                    setState(() {
                      prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                          profileInfoModal.profilePicture);
                      prefs.setString(
                          UserPreference.ISHide, profileInfoModal.isHide);
                      prefs.setString(UserPreference.CREATION_TIME,
                          profileInfoModal.creationTime);
                      prefs.setString(
                          UserPreference.TAGLINE, profileInfoModal.tagline);
                      prefs.setString(
                          UserPreference.ISACTIVE, profileInfoModal.isActive);
                      prefs.setString(
                          UserPreference.ZIPCODE, profileInfoModal.zipCode);
                      prefs.setString(
                          UserPreference.NAME,
                          profileInfoModal.firstName +
                              " " +
                              profileInfoModal.lastName);

                      profileInfoModal;
                    });
                    // navigationPage();
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++" + e.toString());
    }
  }

  startTime() async {
    var _duration = Duration(milliseconds: 1000);
    return Timer(_duration, () {
      if (!isLoading) {
        navigationPage(false);
      }
    });
  }

  startTimeForAnimation() async {
    var _duration = Duration(milliseconds: 2000);
    return Timer(_duration, afterAnimation);
  }

  //Future shareIDData2(shareId,type) async {

  Future shareIDData2(shareId, type, isPublicProfile) async {
    try {
      print("profile shareId" + shareId);
      Response response;
      if (!isPublicProfile) {
        print('shareIDData if URL:: ${Constant.ENDPOINT_SHARE_ID + shareId}');
        response = await ApiCalling2()
            .apiCall4(context, Constant.ENDPOINT_SHARE_ID + shareId, "get");
      } else {
        print(
            'shareIDData else URL:: ${Constant.ENDPOINT_SHARE_ID + shareId + "&publickey=1"}');
        response = await ApiCalling2().apiCall4(
            context,
            Constant.ENDPOINT_SHARE_ID + shareId + "&publickey=1",
            "get"); //http://103.21.53.11:3001/ui/share/profile?sharedId=549&publickey=1
      }
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data['message'];
          print("---share---" + response.toString());
          if (status == "Success") {
            shareProfileModal =
                ParseJson.parseShareProfile(response.data['result']);

            if (shareProfileModal.isActive == "true") {
              if (shareProfileModal.profileOwner != "") {
                print("profile status" + shareProfileModal.isActive);
                print("profile status" + shareProfileModal.isViewed);

                if (shareProfileModal.sharedView == "linear") {
                  Navigator.pushReplacement(
                      Constant.applicationContext,
                      MaterialPageRoute(
                          //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) => ShareProfilePage(
                              shareProfileModal.profileOwner,
                              false,
                              "shareProfile",
                              shareProfileModal,
                              type)));
                } else {
                  onTapPresoView(type);
                }
              }
            } else {
              ToastWrap.showToast("Your access on this profile has revoked.",
                  Constant.applicationContext);
            }

            return;
          } else {
            ToastWrap.showToast(message, Constant.applicationContext);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      e.toString();
      return;
    }
  }

  Future apiCallSkill() async {
    try {
      Response response = await ApiCalling2()
          .apiCall4(context, Constant.ENDPOINT_MASTER_DATA, "get");
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            prefs.setString(
                "skill", json.encode(response.data['result']['skills']));
            prefs.setString(
                "level", json.encode(response.data['result']['importance']));

            prefs.setString("competencies",
                json.encode(response.data['result']['competencies']));
            return;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      e.toString();
      return;
    }
  }

  void navigationPage(bool isLink) async {
    print("navigationPage++++++++++++");
    // Navigator.pop(context);
    /*  _firebaseMessaging.requestNotificationPermissions();
    _firebaseMessaging.configure() ;
    _firebaseMessaging.getToken();*/
    if (isConnect == null) isConnect = await ConectionDetecter.isConnected();

    isAlreadyLoggedIn = prefs.getBool("loginStatus");
    isPasswordChanged = prefs.getBool("isPasswordChanged");
    isParent = prefs.getBool("isParent");
    roleId = prefs.getString(UserPreference.ROLE_ID);
    if (isAlreadyLoggedIn == null) {
      isAlreadyLoggedIn = false;
    }
    if (isPasswordChanged == null) {
      isPasswordChanged = false;
    }
    if (isParent == null) {
      isParent = false;
    }

    if (!isAlreadyLoggedIn) {
      Navigator.of(Constant.applicationContext)
          .popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
          Constant.applicationContext,
          MaterialPageRoute(
              builder: (context) => LoginPage(
                imageList,
                showLogin: isLink,
              )));
    } else {
      if (roleId == "2") {
        ParentOnBoarding()
            .onBoardingInit(context, profileInfoModal, userIdPref);

        /* if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
            Navigator.of(context).pushReplacement(new MaterialPageRoute(
                builder: (BuildContext context) => MoreData()));
          } else {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidgetParent(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      profileInfoModal: profileInfoModal,
                    )));
          }*/
      } else if (roleId == "4") {
        PartnerOnBoarding()
            .onBoardingInit(context, profileInfoModal, userIdPref);
        /*  Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        companyModel: companyModel,
                      )));*/
      } else {
        if (isConnect) {
          userName = prefs.getString(UserPreference.NAME);
          if (profileInfoModal != null &&
              profileInfoModal.stage != null &&
              int.parse(profileInfoModal.stage) >= 5) {
            if(profileInfoModal.isEmailVerified==null || !profileInfoModal.isEmailVerified){
              Navigator.of(context).popUntil((route) => route.isFirst);
              Navigator.of(context).pushReplacement(new MaterialPageRoute(
                  builder: (BuildContext context) =>
                      EmailVerification(profileInfoModal, sasToken, loginRole: LoginRole.student,)));
            }else
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        profileInfoModal: profileInfoModal,
                      )));
          } else {
            if (profileInfoModal != null &&
                profileInfoModal.isExistingUser.toString() == "true") {
              if(profileInfoModal.isEmailVerified==null || !profileInfoModal.isEmailVerified){
                Navigator.of(context).popUntil((route) => route.isFirst);
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                        EmailVerification(profileInfoModal, sasToken)));
              }else
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DashBoardWidget(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          profileInfoModal: profileInfoModal,
                        )));
            } else {
              /*   if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => MoreData()));
                } else {*/
              StudentOnBoarding().getStudentOnBoardingInit(
                  context, profileInfoModal, sasToken, userIdPref);
              //}
            }
          }
        } else {
          if (int.parse(profileInfoModal.stage) >= 5) {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                    )));
          } else {
            print("stage++++++" + prefs.getString(UserPreference.STAGE));
            ToastWrap.showToast(
                MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
          }
        }
      }
    }
  }

  void iOS_Permission() {
    _firebaseMessaging.requestNotificationPermissions(
        IosNotificationSettings(sound: true, badge: true, alert: true));
    _firebaseMessaging.onIosSettingsRegistered
        .listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
    });
  }

  void firebaseCloudMessaging_Listeners() {
    if (Platform.isIOS) iOS_Permission();

    _firebaseMessaging.getToken().then((token) {
      print("tokenm" + token);
      prefs.setString("deviceId", token);
    });

    movetoWindow(userRole, pageName) {
      if (userRole == "1") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        // For Studenet
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidget(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: pageName)));
      } else if (userRole == "2") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidgetParent(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: pageName)));

        // For Parent
      } else if (userRole == "4") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    currentPage: pageName)));

        // For Partner
      }
    }

    void _onNotificationClick(Map<String, dynamic> message) async {
      print('inside _onNotificationClick()');
      print("_onNotificationClick++++++++++" + message.toString());

      if (mounted) {
        setState(() {
          isPathAvailable = true;
        });
      }

      String type = message['type'].toString();
      print("Apurva inside _onNotificationClick() type:: " + type.toString());
      String roleId =
          message['roleId'].toString(); // Its for Current User Role.
      String id = message['values'].toString();
      String requestId =
          message['requestId'].toString(); // Its for Current User Role.

      prefs = await SharedPreferences.getInstance();

      String userRole = prefs.getString(UserPreference.ROLE_ID);
      bool isPartnerApprovedByAdmin =
          prefs.getBool(UserPreference.IS_PARTNER_ACTIVE);

      if (type == 'BadgeRequest') {
        try {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) =>  PartnerNotificationManageBadges("login", badgeId: id)));

        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
      } else if (type == 'BadgePresented') {
        try {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) =>  BadgeRequest(id, 'main')));


        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
      } else if (type == 'BadgeCollection') {
        try {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) =>  TabsBadges(
                      prefs.getString(UserPreference.DOB),
                      prefs.getString(UserPreference.USER_ID),
                      "main")));

        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
      } else if (type.toString().trim()  == "RecommendationRequest" ||
          type.toString().trim()  == "RecommendationPending" ||
          type.toString().trim()  == "RecommendationReplied" ||
          type.toString().trim()  == "RecommendationReminder" ||
          type.toString().trim()  == "Recommendation") {
        if (roleId == "1") {
          if (type.toString().trim()  == 'RecommendationReplied') {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) =>  SharedRecommendationDetail(id, false, "", "existing")));


          } else if (type.toString().trim()  == 'RecommendationRequest') {
            if (profileInfoModal == null) {
              await profileApiChild(false);
            }

            var dataModel = ProfileData(
              userId: profileInfoModal.userId,
              firstName: profileInfoModal.firstName,
              lastName: profileInfoModal.lastName,
              email: profileInfoModal.email,
              stage: profileInfoModal.stage,
              dob: profileInfoModal.dob,
              summary: profileInfoModal.summary,
              isExistingUser: profileInfoModal.isExistingUser,
              publicUrl: profileInfoModal.publicUrl,
            );
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => ManageRecommendation(
                      dataModel,
                      true,
                      false,
                      userIdPref,
                      sasToken,
                      "mainRequest",
                      "",
                      profileModel: profileInfoModal,
                    )));
          } else {
            if (profileInfoModal == null) {
              await profileApiChild(false);
            }

            var dataModel = ProfileData(
              userId: profileInfoModal.userId,
              firstName: profileInfoModal.firstName,
              lastName: profileInfoModal.lastName,
              email: profileInfoModal.email,
              stage: profileInfoModal.stage,
              dob: profileInfoModal.dob,
              summary: profileInfoModal.summary,
              isExistingUser: profileInfoModal.isExistingUser,
              publicUrl: profileInfoModal.publicUrl,
            );
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => ManageRecommendation(
                      dataModel,
                      true,
                      false,
                      userIdPref,
                      sasToken,
                      "main",
                      "",
                      profileModel: profileInfoModal,
                    )));

          }
        } else {
          if (type.toString().trim()  == 'RecommendationReplied') {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => SharedRecommendationDetail(id, false, "", "existing")));

          } else {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => ManageRequestDashBoard("main")));

          }
        }
      }  else if (type == Constant.ADMIN_TYPE) {
        // For Connection Request

        isPathAvailable = true;
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }

        if (message['linkType'] == "external") {
          if (message['buttonUrl'] != null &&
              message['buttonUrl'] != "") {
            String url = message['buttonUrl'];
            if (message['buttonUrl'].toLowerCase().contains("http")) {
            } else {
              url = "http://" + message['buttonUrl'];
            }

            await launch(url);

            if (userRole == "1") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              // For Studenet
              Navigator.pushReplacement(
                  Constant.applicationContext,
                  MaterialPageRoute(
                      builder: (context) => DashBoardWidget(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          currentPage: Constant.PROFILE_TYPE)));
            } else if (userRole == "2") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              Navigator.pushReplacement(
                  Constant.applicationContext,
                  MaterialPageRoute(
                      builder: (context) => DashBoardWidgetParent(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          currentPage: Constant.PROFILE_TYPE)));

              // For Parent
            } else if (userRole == "4") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              Navigator.pushReplacement(
                  Constant.applicationContext,
                  MaterialPageRoute(
                      builder: (context) => DashBoardWidgetPartner(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          currentPage: Constant.PROFILE_TYPE)));

              // For Partner
            }
          }
        }
        //else {
        else if (message['linkType'] == "internal") {
          String pageName = Constant.PROFILE_TYPE;
          if (message['appModule'] == "Profile") {
            pageName = Constant.PROFILE_TYPE;
            movetoWindow(userRole, pageName);
          } else if (message['appModule'] == "Feed") {
            print("id++++++++++++++" + id.toString());

            if (id != null && id != "null" && id != "") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              // For Studenet
              Navigator.pushReplacement(
                  Constant.applicationContext,
                  MaterialPageRoute(
                      builder: (context) => FeedDetailWidget(id, "")));
            } else {
              pageName = Constant.FEED_TYPE;
              movetoWindow(userRole, pageName);
            }

            //pageName = Constant.FEED_TYPE;
          } else if (message['appModule'] == "Connection") {
            pageName = Constant.CONNECTIONS_TYPE;
            movetoWindow(userRole, pageName);
          } else if (message['appModule'] == "Chat") {
            pageName = Constant.CHAT_TYPE;
            movetoWindow(userRole, pageName);
          } else if (message['appModule'] == "Group") {
            if (id != null && id != "null" && id != "") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              // For Studenet
              Navigator.pushReplacement(
                  Constant.applicationContext,
                  MaterialPageRoute(
                      builder: (context) =>
                          GroupDetailWidget(id, "Notification", "", "", "")));
            } else {
              pageName = Constant.GROUP_TYPE;
              movetoWindow(userRole, pageName);
            }
          }
        } else if (message['linkType'] == "text") {
          if (userRole == "1") {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            // For Studenet
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));
          } else if (userRole == "2") {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidgetParent(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));

            // For Parent
          } else if (userRole == "4") {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));

            // For Partner
          }
        }
      } else if (type.toString().trim() ==
          Constant.UNDER_13_FILTER_PAGE_Enabled) {
        if (roleId == "1") {
          bloc.fetcprofileData(userIdPref, context, prefs, true);
          if (id == "true") {
            prefs.setString(UserPreference.ISACTIVE, "true");
          } else {
            prefs.setString(UserPreference.ISACTIVE, "false");
          }
        }
      } else if (type == "partner_approval") {
        String actedBy = message['actedBy'].toString();
        Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                PatnerProfileWidgetForBoatReview(actedBy, "main")));
      } else if (type == "partner_decline") {
        Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
            builder: (BuildContext context) => PartnerRejectionReason('main')));
      } else if (type == Constant.OPPORTUNITY_APPROVAL ||
          type == Constant.OPPORTUNITY_APPROVED) {
        Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                OpportunityForBoat(id, roleId, "main")));
      } else if (type == Constant.OPPORTUNITY_DECLINE) {
        Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                opportunityRejected('main', id)));
      } else if (type == Constant.UNDER_13_PROFILE_VISIBILITY) {
        if (prefs.getString(UserPreference.ROLE_ID) == "2") {
          //  String actedBy = message['actedBy'].toString();

          String values = message['values'].toString();
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(
            Constant.applicationContext,
          ).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => ProfileVisibilitySetting(
                    values,
                    true,
                    pageName: "main",
                  )));
        } else {
          // String userId = message['userId'].toString();
          String values = message['values'].toString();
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(
            Constant.applicationContext,
          ).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => ProfileVisibilitySetting(
                    values,
                    false,
                    pageName: "main",
                  )));
        }
      } else if (type.toString().trim() == Constant.UNDER_13_FILTER_PAGE) {
        if (prefs.getString(UserPreference.ROLE_ID) == "2") {
          String actedBy = message['actedBy'].toString();
          print("acted Role 2+++" + actedBy);
          Navigator.of(
            Constant.applicationContext,
          ).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => PublicViewForUser(
                    "",
                    "main",
                    "Connected",
                    true,
                    actedUserId: actedBy,
                    acteRoleId: "2",
                    profileValue: id,
                  )));
        } else {
          String userId = message['userId'].toString();
          print("acted Role 1+++" + userId);
          Navigator.of(
            Constant.applicationContext,
          ).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => PublicViewForUser(
                  "", "main", "Connected", true,
                  actedUserId: userId, acteRoleId: "1")));
        }
      } else if (type == Constant.UNDER_13_TYPE) {
        if (prefs.getString(UserPreference.ROLE_ID) == "2") {
          String actedBy = message['actedBy'].toString();
          print("acted Role 2+++" + actedBy);
          Navigator.of(
            Constant.applicationContext,
          ).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => PublicViewForUser(
                    "",
                    "main",
                    "Connected",
                    true,
                    actedUserId: actedBy,
                    acteRoleId: "2",
                    profileValue: id,
                  )));
        } else {
          String userId = message['userId'].toString();
          print("acted Role 1+++" + userId);
          Navigator.of(
            Constant.applicationContext,
          ).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => PublicViewForUser(
                  "", "main", "Connected", true,
                  actedUserId: userId, acteRoleId: "1")));
        }
      } else if (type == Constant.CONNECTIONS_TYPE) {
        // For Connection Request
        isPathAvailable = true;
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }

        if (userRole == "1") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          // For Studenet
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.CONNECTIONS_TYPE)));
        } else if (userRole == "2") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => DashBoardWidgetParent(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.CONNECTIONS_TYPE)));

          // For Parent
        } else if (userRole == "4") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.CONNECTIONS_TYPE)));

          // For Partner
        }
        /*
         * For Now Id is not Using Just navigating to the Specific class
         *
         */

      } else if (type == Constant.partner_approval_TYPE) {
        print('Apurva partner_approval_TYPE');
        // For Connection Request
        isPathAvailable = true;
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        if (userRole == "1") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);

          Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  PatnerProfileWidgetForBoatReview(id, "main")));

          // For Partner
        }
        /*
         * For Now Id is not Using Just navigating to the Specific class
         *
         */

      } else if (type == Constant.partner_approved_TYPE) {
        print('Apurva partner_approved_TYPE');
        // For Connection Request
        isPathAvailable = true;
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        if (userRole == "4") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));

          // For Partner
        }
        /*
         * For Now Id is not Using Just navigating to the Specific class
         *
         */

      } else if (type == Constant.partner_decline_TYPE) {
        print('Apurva partner_decline_TYPE');
        // For Connection Request
        isPathAvailable = true;
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        if (userRole == "4") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  PartnerRejectionReason('main')));

          // For Partner
        }
        /*
         * For Now Id is not Using Just navigating to the Specific class
         *
         */

      } else if (type == Constant.GROUP_TYPE) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        print("groupId++++" + id.toString());
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    GroupDetailWidget(id, "Notification", "", "", "")));
      } else if (type == Constant.GROUP_SCREEN) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        print("groupId++++" + id.toString());
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    GroupDetailWidget(id, "Notification", "", "", "")));
      } else if (type == Constant.UNDER_13_GROUP_SCREEN) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        print("groupId++++" + id.toString());
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    GroupDetailWidget(id, "Notification", "", "", "")));
      } //type == opportunity
      else if (type == Constant.Opportunity_TYPE) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        print("Apurva OpportunityID::: " + id.toString());
        print('noti type Opportunity>>>>'); //FEED_TYPE
        print('Apurva clicked Opportunity details');
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    OpportunityViewWidgetOnNotificationClick(
                      id, //model.values,//OpportunityId
                      roleId,
                      'login',
                    )));
      } else if (type == Constant.GROUP_TYPE_INVITE) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        print("groupId++++" + id.toString());
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    GroupDetailWidget(id, "login", "", "", "")));
      } else if (type == Constant.CHAT_TYPE) {
        try {
          print("111111111111" + message.toString());
          addUser();

          String receiverId = message['senderId'].toString();
          String senderId = message['userId'].toString();
          String senderRoleId = message['roleId'].toString();
          String receiverRoleId = message['senderRoleId'].toString();
          String creationTime = message['creationTime'].toString();
          String connectionId = message['values'].toString();
          String partnerFirstName =
              message['partnerFirstName'].toString();
          String partnerLastName =
              message['partnerLastName'].toString();
          String dateTime = message['dateTime'].toString();

          String partnerProfilePicture = "";
          if (message.containsKey("partnerProfilePicture")) {
            partnerProfilePicture =
                message['partnerProfilePicture'].toString();
          }
          if (creationTime == "null" || creationTime == "") {
            creationTime = "0";
          }
          if (dateTime == "null" || dateTime == "") {
            dateTime = "0";
          }

          Friends model = Friends(
              connectId: int.parse(connectionId),
              userId: int.parse(senderId),
              firstName: "",
              lastName: "",
              profilePicture: "",
              partnerId: int.parse(receiverId),
              partnerFirstName: partnerFirstName,
              partnerLastName: partnerLastName,
              partnerRoleId: int.parse(receiverRoleId),
              partnerProfilePicture: partnerProfilePicture,
              dateTime: int.parse(dateTime),
              creationTime: int.parse(creationTime),
              isActive: true,
              online: 1,
              lastMessage: "",
              unreadMessages: 0,
              lastTime: 0,
              lastSeen: 0,
              textSentBy: int.parse(senderId));

          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext)
              .pushReplacement(new MaterialPageRoute(
                  builder: (BuildContext context) => ChatRoomWidget(
                        model,
                        "",
                        "",
                        pageName: "notification",
                      )));
        } catch (e) {
          print("Error chat page++++" + e.toString());
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
        //}

      } else if (type == Constant.BADGE_TYPE) {
        if (roleId == "4") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);

          Navigator.of(Constant.applicationContext).pushReplacement(
              MaterialPageRoute(
                  builder: (BuildContext context) =>
                      PartnerNotificationManageBadges("login", badgeId: id)));
        } else {
          if (userRole == "1") {
            // For Studenet
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));
          } else if (userRole == "2") {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidgetParent(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));
          }
        }
      } else if (type == Constant.USER_TYPE) {
      } else if (type == Constant.CONNECTIONS_PROFILE) {
        // For Profile Changes

        String actedRoleId = message['actedRoleId'].toString();
        String actedBy = message['actedBy']
            .toString(); // Which User Role viewed your profile
        String connectionId = message['values'].toString();

        if (actedRoleId == "1") {
          // For Student
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).pushReplacement(
              MaterialPageRoute(
                  builder: (BuildContext context) =>
                      UserProfileDashBoardForOther(
                        actedBy,
                        true,
                        "pushNotification",
                        "1",
                        connectionId: connectionId,
                      )));
        } else if (actedRoleId == "2") {
          // For Parent
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) => ParentProfilePageWithHeader(
                    actedBy,
                    "pushNotification",
                    connectionId: connectionId,
                  )));
        } else if (actedRoleId == "4") {
          // For Partner
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  PatnerProfileWidgetForOtherUser(
                    actedBy,
                    "pushNotification",
                    connectionId: connectionId,
                  )));
        }
      } else if (type == Constant.PROFILE_TYPE) {
        // For Profile Changes

        String actedRoleId = message['actedRoleId']
            .toString(); // Which User Role viewed your profile
        String actedBy = message['actedBy'].toString();
        if (actedRoleId == "1") {
          // For Student
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) => UserProfileDashBoardForOther(
                  actedBy, true, "pushNotification", "1")));
        } else if (actedRoleId == "2") {
          // For Parent  Navigator.of( Constant.applicationContext).popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  ParentProfilePageWithHeader(actedBy, "pushNotification")));
        } else if (actedRoleId == "4") {
          // For Partner
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  PatnerProfileWidgetForOtherUser(
                      actedBy, "pushNotification")));
        }
      } else if (type == Constant.SHARED_TYPE) {
        if (id != null && id != "") {
          //  Navigator.pop(context);

          await shareIDData(id, "main", false);

          // CustomProgressLoader.cancelLoader(context);

        }
      } else if (type == "ProfileScreen") {
        // For Profile Changes

        String actedRoleId = message['actedRoleId']
            .toString(); // Which User Role viewed your profile
        String actedBy = message['actedBy'].toString();
        if (actedRoleId == "1") {
          // For Student
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) => UserProfileDashBoardForOther(
                  actedBy, true, "pushNotification", "1",
                  groupId: id)));
        } else if (actedRoleId == "2") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) => ParentProfilePageWithHeader(
                  actedBy, "pushNotification",
                  groupId: id)));
        } else if (actedRoleId == "4") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  PatnerProfileWidgetForOtherUser(actedBy, "pushNotification",
                      groupId: id)));
        }
      } else if (type == Constant.GROUP_PROFILE_TYPE) {
        // For Profile Changes

        String actedRoleId = message['actedRoleId']
            .toString(); // Which User Role viewed your profile
        String actedBy = message['actedBy'].toString();
        if (actedRoleId == "1") {
          // For Student
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) => UserProfileDashBoardForOther(
                  actedBy, true, "pushNotification", "1" /*,groupId: id*/)));
        } else if (actedRoleId == "2") {
          // For Parent
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) => ParentProfilePageWithHeader(
                  actedBy, "pushNotification" /*,groupId: id*/)));
        } else if (actedRoleId == "4") {
          // For Partner

          print('Apurva actedBy:: $actedBy');
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  PatnerProfileWidgetForOtherUser(
                      actedBy, "pushNotification" /*,groupId: id*/)));
        }
      } else if (type == MessageConstant.Recommendation_TYPE) {
        print(
            'Inside Recommendation_TYPE, roleID:: $type $roleId, userRole:: $userRole');
        if (roleId == "1") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));
        } else {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          /*if (!isPartnerApprovedByAdmin && roleId == "4") {
          ToastWrap.showToast(
              MessageConstant
                  .PENDING_PARTNER_ACTIVATION_BY_ADMIN_ERROR,
              context);
        } else {*/
          Navigator.of(Constant.applicationContext).pushReplacement(
              MaterialPageRoute(
                  builder: (BuildContext context) =>
                      ManageRequestDashBoard("login")));
          //}
        }
      } else if (type == Constant.FEED_REPORTED) {
        print("data+++++++++++++++++++boat account");
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    FeedReportWidgetBoat(id, "")));
      } else if (type == Constant.GROUP_REPORTED) {
        print("data+++++++++++++++++++boat account");
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    GroupReportWidgetBoat(id, "", requestId)));
      } else if (type == Constant.STUDENT_PROFILE_REPORTED) {
        print("data+++++++++++++++++++boat account");
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    StudentProfileReportWidgetBoat(id, "", requestId, "1")));
      } else if (type == Constant.PARENT_PROFILE_REPORTED) {
        print("data+++++++++++++++++++boat account");
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    StudentProfileReportWidgetBoat(id, "", requestId, "2")));
      } else if (type == Constant.PARTNER_PROFILE_REPORTED) {
        print("data+++++++++++++++++++boat account");
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    StudentProfileReportWidgetBoat(id, "", requestId, "3")));
      } else if (type == Constant.FEED_TYPE_APPROVE) {
        print("data+++++++++++++++++++boat account");
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) =>
                    FeedDetailWidgetForBoat(id, "")));
      } else if (type == Constant.FEED_TYPE) {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) => FeedDetailWidget(id, "")));
      } else if (type == Constant.REWARD_TYPE) {
        // For Connection Request

        isPathAvailable = true;
        if (mounted) {
          setState(() {});
        }
        if (userRole == "1") {
          Navigator.of(Constant.applicationContext)
              .popUntil((route) => route.isFirst);
          // For Studenet
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE,
                        profileInfoModal: profileInfoModal,
                      )));
        }
      }
    }

    roleSwitchConfirmationDialog(Map<String, dynamic> message, roleId) {
      String roleName;
      String roleId = message['roleId'].toString();

      switch (roleId) {
        case "1":
          roleName = "Student";
          break;
        case "2":
          roleName = "Parent";
          break;
        case "4":
          roleName = "Partner";
          break;
      }

      showDialog(
          barrierDismissible: false,
          context: Constant.applicationContext,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(Constant.applicationContext);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 193.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      "Are you sure you want to switch your role as " +
                                                          roleName +
                                                          "?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "No",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                if (mounted) {
                                                  navigationPage(false);
                                                } else {
                                                  Navigator.of(
                                                          Constant
                                                              .applicationContext,
                                                          rootNavigator: true)
                                                      .pop('dialog');
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Yes",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.of(
                                                        Constant
                                                            .applicationContext,
                                                        rootNavigator: true)
                                                    .pop('dialog');

                                                prefs.setString(
                                                    UserPreference.ROLE_ID,
                                                    roleId);
                                                _onNotificationClick(message);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    _firebaseMessaging.configure(
        onMessage: (Map<String, dynamic> message) async {
      print("onMessage:++++ " + json.encode(message) + "+++++++end+++");

      String userRole = prefs.getString(UserPreference.ROLE_ID);
      String roleId = message['roleId'].toString();
      if (userRole == roleId) {
        syncDoneController.add(message['type'].toString());
      }
    },
        //onBackgroundMessage: myBackgroundMessageHandler,
        onLaunch: (Map<String, dynamic> message) async {
      // Call when app is Terminated

      print("Alok Tiwari Test---------- LAUNCH>");

      print("onLaunch: $message");

      syncDoneController.add("success");

      String roleId = message['roleId'].toString();
      String type = message['type'].toString();
      prefs = await SharedPreferences.getInstance();
      userIdPref = prefs.getString(UserPreference.USER_ID);
      String userRole = prefs.getString(UserPreference.ROLE_ID);
      isAlreadyLoggedIn = prefs.getBool("loginStatus");
      if (isAlreadyLoggedIn == null) {
        isAlreadyLoggedIn = false;
      }
      if (isAlreadyLoggedIn) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        if (prefs != null && userRole != roleId) {
          // Popup Need to show here
          if (type == Constant.SHARED_TYPE) {
            _onNotificationClick(message);
          } else {
            roleSwitchConfirmationDialog(message, roleId);
          }
        } else {
          _onNotificationClick(message);
        }
      }
    }, onResume: (Map<String, dynamic> message) async {
      print("onResume: $message");
      print("Alok Tiwari Test---------- RESUME >");
      syncDoneController.add("success");

      String roleId = message['roleId'].toString();
      String type = message['type'].toString();
      prefs = await SharedPreferences.getInstance();
      userIdPref = prefs.getString(UserPreference.USER_ID);
      String userRole = prefs.getString(UserPreference.ROLE_ID);
      isAlreadyLoggedIn = prefs.getBool("loginStatus");
      if (isAlreadyLoggedIn == null) {
        isAlreadyLoggedIn = false;
      }
      if (isAlreadyLoggedIn) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        if (prefs != null && userRole != roleId) {
          // Popup Need to show here
          if (type == Constant.SHARED_TYPE) {
            _onNotificationClick(message);
          } else {
            roleSwitchConfirmationDialog(message, roleId);
          }
        } else {
          _onNotificationClick(message);
        }
      }
    }, onClick: (Map<String, dynamic> message) async {
      print("onClick---------->: " + json.encode(message));

      print("@@@@@@@" + prefs.getString(UserPreference.USER_ID));

      String roleId = message['roleId'].toString();
      String type = message['type'].toString();
      prefs = await SharedPreferences.getInstance();
      userIdPref = prefs.getString(UserPreference.USER_ID);
      String userRole = prefs.getString(UserPreference.ROLE_ID);
      isAlreadyLoggedIn = prefs.getBool("loginStatus");
      if (isAlreadyLoggedIn == null) {
        isAlreadyLoggedIn = false;
      }
      if (isAlreadyLoggedIn) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        if (prefs != null && userRole != roleId) {
          // Popup Need to show here
          if (type == Constant.SHARED_TYPE) {
            _onNotificationClick(message);
          } else {
            roleSwitchConfirmationDialog(message, roleId);
          }
        } else {
          _onNotificationClick(message);
        }
      }
    });
  }

  Future onSelectNotification(String payload) async {
    Navigator.push(Constant.applicationContext,
        MaterialPageRoute(builder: (context) => NotificationWidget()));
  }

  int count = 0;

  processForUri(path, roleId, name, String userId) async {
    print("processForUri path" + path);
    if (path.contains(Constant.PREVIEW_PROFILE_TYPE)) {
      List<String> mesagelist = path.split("/");

      String sharedId = mesagelist[mesagelist.length - 3];

      try {
        Codec<String, String> stringToBase64 = utf8.fuse(base64);
        String decodedSharedId = stringToBase64
            .decode(sharedId.replaceAll("&SPK", "=")); // username:password

        print('decodedSharedId public preview 222:: ${decodedSharedId}');
        print('SharedID public preview 222:: ${sharedId}');
        if (decodedSharedId != null && decodedSharedId != "") {
          await shareIDData(
              decodedSharedId, Constant.PREVIEW_PROFILE_TYPE, false);
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      }
    } else if (path.contains(Constant.PUBLIC_PROFILE_TYPE)) {
      List<String> mesagelist = path.split("/");
      String sharedId = mesagelist[mesagelist.length - 1];

      try {
        Codec<String, String> stringToBase64 = utf8.fuse(base64);
        String decodedSharedId = stringToBase64
            .decode(sharedId.replaceAll("&SPK", "=")); // username:password
        print('SharedID public preview 111:: ${sharedId}');
        print('decodedSharedId public preview 111:: ${decodedSharedId}');
        if (decodedSharedId != null && decodedSharedId != "") {
          //  Navigator.pop(context);
          await shareIDData(
              decodedSharedId, Constant.PUBLIC_PROFILE_TYPE, true);
          // CustomProgressLoader.cancelLoader(context);
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        print('Exception 111 e: $e');
      }
    } else if (path.contains("/badges/") && path.contains("/self/")) {
      try {
        if (path.contains("/self/")) {
          List<String> mesagelist = path.split("/");

          String badgeId = mesagelist[mesagelist.length - 4];
          print("badgeid++$badgeId");
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => BadgeRequest(badgeId, 'main')));
        } else {
          navigationPage(false);
        }
      } catch (e) {
        navigationPage(false);
        crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      }
    } else if (path.contains("recommendation")) {
      List<String> mesagelist = path.split("/");

      //   ToastWrap.showToast(mesagelist[mesagelist.length-3]);
      String recommendationId = mesagelist[mesagelist.length - 3];
      String userIdRecomm = mesagelist[mesagelist.length - 5];
      String password = mesagelist[mesagelist.length - 1];

      if (password != null && password != "null") {
        isContainPass = true;
      }

      Navigator.pushReplacement(
          Constant.applicationContext,
          MaterialPageRoute(
              builder: (context) => SharedRecommendationDetail(
                  recommendationId, isContainPass, "", "Notexisting")));

      print("sharedidshubh" +
          recommendationId +
          "isContainPass" +
          isContainPass.toString());
    } else if (path.contains("autoLogin")) {
      if (isProfileCreatedByParent && userLoginFirstTime) {
        Navigator.pushReplacement(
          Constant.applicationContext,
          MaterialPageRoute(
              builder: (context) =>
                  ChangePasswordNew("reset", roleId, userId: userId)),
        );
      } else {
        Navigator.pushReplacement(
          Constant.applicationContext,
          MaterialPageRoute(
              builder: (context) =>
                  ChangePassword("login", roleId, userId: userId)),
        );
      }
    } else if (path.contains("joingroup")) {
      List<String> mesagelist = path.split("=");

      Navigator.of(Constant.applicationContext)
          .popUntil((route) => route.isFirst);

      Navigator.of(Constant.applicationContext)
          .pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => LoginPage(
                    null,
                    isRedirectToRecommendation: true,
                    pageName: "main",
                    showSignup: true,
                  )));
    } else if (path.contains("forwardToParentInquire")) {
      List<String> mesagelist = path.split("=");

      String opportunityId = mesagelist[1].replaceAll("&email", "");
      String email = mesagelist[2].replaceAll("&pass", "");

      print("opportunityId++++" + opportunityId + "  " + email);

      Navigator.of(Constant.applicationContext).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) => InquireNowScreen(
                  opportunityId, userIdPref, "", "1", "login")));
    }
  }

  showToastLong(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");
      Navigator.pop(context);
      Navigator.of(Constant.applicationContext)
          .popUntil((route) => route.isFirst);
      Navigator.of(Constant.applicationContext).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  LoginPage(imageList, showLogin: true)));
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR : ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  loginServiceCall(email, password, path) async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        if (!mounted)
          CustomProgressLoader.showLoader(Constant.applicationContext);

        print("logincall:-" + email + " " + "call" + password);
// prefs = await SharedPreferences.getInstance();
        final String decrptedPassword =
            await platform.invokeMethod('decryption', {
          "password": password,
        });

        print("decryptedpass:-" + decrptedPassword);

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
// Prepare Data
        print("token genrated:-" + prefs.getString("deviceId"));
        Map map = {
          "email": email.toLowerCase(),
          "password": password,
          "deviceId": prefs.getString("deviceId"),
          "signinType": "spikeview",
          "socialId": "",
          "platformType": "mobile"
        };
// Make API call
        Response response =
            await dio.post(Constant.ENDPOINT_LOGIN, data: json.encode(map));

        if (!mounted)
          CustomProgressLoader.cancelLoader(Constant.applicationContext);

        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setString(UserPreference.chat_skip_count, "0");
            prefs.setString(UserPreference.IS_USER_ROLE, "false");
            prefs.setString(UserPreference.IS_PARENT_ROLE, "false");
            prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");
            if (response.data['result']['inviteDetails'] != null) {
              var emailChangeSkipCount = response.data['result']
                  ['inviteDetails']['emailChangeSkipCount'];
              if (emailChangeSkipCount == null) {
                emailChangeSkipCount = 0;
              }
              prefs.setInt(
                  UserPreference.EMAIL_SKIP_COUNT, emailChangeSkipCount);
            }

            String userId = response.data['result']['userId'].toString();
            // Api call for get setting data
            bloc.fetchSetting(userId, context, prefs);
            String firstName = response.data['result']['firstName'].toString();
            String lastName = response.data['result']['lastName'].toString();
            String email = response.data['result']['email'].toString();
            String salt = response.data['result']['salt'].toString();
            String mobileNo = response.data['result']['mobileNo'].toString();
            String profilePicture =
                response.data['result']['profilePicture'].toString();
            String roleId = response.data['result']['roleId'].toString();
            var role = response.data['result']['role'];
            String dob = response.data['result']['dob'].toString();
            if (dob == null || dob == "null" || dob == "") {
              dob = "0";
            }
            bool isAddedDob = response.data['result']['isAddedDob'];
            if (isAddedDob == null) {
              isAddedDob = false;
            }
            prefs.setBool(UserPreference.IS_ADDED_DOB, isAddedDob);

            bool isUnderAge = response.data['result']['isUnderAge'];
            if (isUnderAge == null) {
              isUnderAge = false;
            }
            prefs.setBool(UserPreference.IS_UNDER_AGE, isUnderAge);
            String schoolCode =
                response.data['result']['schoolCode'].toString();
            if (schoolCode == null ||
                schoolCode == "" ||
                schoolCode == "null") {
              schoolCode = "";
              prefs.setBool(UserPreference.IS_SCHOOL, false);
            } else {
              prefs.setBool(UserPreference.IS_SCHOOL, true);
            }
            prefs.setString(UserPreference.SCHOOL_CODE, schoolCode);
            prefs.setString(UserPreference.SCHOOL_CODE, schoolCode);
            if (prefs.getString(UserPreference.SCHOOL_CODE) != null &&
                prefs.getString(UserPreference.SCHOOL_CODE) != "null" &&
                prefs.getString(UserPreference.SCHOOL_CODE) != "") {
              bloc.apiCallForAcessControl(prefs, userId, context);
            } else {
              bloc.accessControlParam(prefs);
            }

            isProfileCreatedByParent =
                response.data['result']['profileCreatedByParent'];
            if (isProfileCreatedByParent == null) {
              isProfileCreatedByParent = false;
            }

            String achievement =
                response.data['result']['isAchievement'].toString();
            String isEducation =
                response.data['result']['isEducation'].toString();
            userLoginFirstTime = response.data['result']['userLoginFirstTime'];
            if (userLoginFirstTime == null) {
              userLoginFirstTime = false;
            }
            prefs.setBool(
                UserPreference.SHOW_BOT_DEFAULT_COUNT, userLoginFirstTime);

            print("userLoginFirstTime+++++++" + userLoginFirstTime.toString());
            prefs.setBool(
                UserPreference.IS_USER_LOGIN_FIRST_TIME, userLoginFirstTime);

            prefs.setString(UserPreference.DOB, dob);
            for (int i = 0; i < role.length; i++) {
              if (role[i]['id'] == 1) {
                prefs.setString(UserPreference.IS_USER_ROLE, "true");
              } else if (role[i]['id'] == 2) {
                prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
              } else if (role[i]['id'] == 4) {
                prefs.setString(UserPreference.IS_PARTNER_ROLE, "true");
              }
            }

            if (prefs.getString(UserPreference.IS_PARTNER_ROLE) == "true") {
              roleId = "4";
            } else if (prefs.getString(UserPreference.IS_PARENT_ROLE) ==
                "true") {
              roleId = "2";
            } else if (prefs.getString(UserPreference.IS_USER_ROLE) == "true") {
              roleId = "1";
            }

            if (achievement == "true") {
              prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, true);
            } else {
              prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, false);
            }

            if (isEducation == "true") {
              prefs.setBool(UserPreference.isEducationAdded, true);
            } else {
              prefs.setBool(UserPreference.isEducationAdded, false);
            }

            String token = response.data['result']['token'].toString();
            isPasswordChanged = response.data['result']['isPasswordChanged'];

            String companyName =
                response.data['result']['companyName'].toString();
            String companyProfilePicture =
                response.data['result']['companyProfilePicture'].toString();

            userList.add(new UserData(userId, firstName, lastName, email, salt,
                mobileNo, profilePicture, roleId));
            print("user Login token" + token);

            String isActive = response.data['result']['isActive'].toString();
            String isHide = response.data['result']['isHide'].toString();
            prefs.setString(UserPreference.ISHide, isHide);
            prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
            prefs.setString(UserPreference.ISACTIVE, isActive);

            prefs.setBool(
                UserPreference.IS_PASSWORD_CHANGED, isPasswordChanged);
            prefs.setBool(UserPreference.IS_PROFILECRETED_BY_PARENT,
                isProfileCreatedByParent);

            String badgeImage =
                response.data['result']['badgeImage'].toString();
            if (badgeImage == null ||
                badgeImage == "null" ||
                badgeImage == "") {
              badgeImage = "";
            }

            String badge = response.data['result']['badge'].toString();
            if (badge == null || badge == "null" || badge == "") {
              badge = "0";
            }
            String gamification =
                response.data['result']['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == null ||
                gamification == "null" ||
                gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }

            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            String referCode =
                response.data['result']['referCode'].toString() == "null"
                    ? ""
                    : response.data['result']['referCode'].toString();
            prefs.setString(UserPreference.referCode, referCode);
            prefs.setString(UserPreference.badgeImage, badgeImage);
            prefs.setString(UserPreference.badgeType, badge);
            prefs.setInt(UserPreference.gamificationPoints, gamificationPoints);

            String creationTime =
                response.data['result']['creationTime'].toString();
            if (creationTime == "null") {
              creationTime = "0";
            }
            prefs.setString(UserPreference.CREATION_TIME, creationTime);

            bool isPreLoginSetting =
                response.data["result"]["isLeaderboardDisplay"];
            if (isPreLoginSetting == null) {
              isPreLoginSetting = false;
            }

            prefs.setBool(UserPreference.IS_PRE_LOGIN, isPreLoginSetting);

            prefs.setString(UserPreference.USER_ID, userId);
            prefs.setBool(
                UserPreference.IS_PARENT, roleId == "2" ? true : false);
            prefs.setString(UserPreference.ROLE_ID, roleId);
            Constant.ROLE_ID = roleId;
            prefs.setString(UserPreference.PARENT_ID, userId);
            prefs.setString(UserPreference.NAME,
                firstName == "null" ? " " : firstName + " " + lastName);
            prefs.setString(UserPreference.EMAIL, email);
            prefs.setString(UserPreference.MOBILE, mobileNo);
            prefs.setString(UserPreference.PASSWORD, decrptedPassword);

            prefs.setString(UserPreference.PROFILE_IMAGE_PATH, profilePicture);
            prefs.setString(
                UserPreference.COMPANY_IMAGE_PATH, companyProfilePicture);
            prefs.setString(UserPreference.COMPANY_NAME_PATH, companyName);
            prefs.setString(UserPreference.USER_TOKEN, "Spike " + token);
            processForUri(path, roleId, firstName, userId);

            print("main Data role" + roleId);

            if (roleId == "3") {
              prefs.setBool(UserPreference.LOGIN_STATUS, false);
            } else {
              Constant.isAlreadyLoggedIn = true;
              prefs.setBool(UserPreference.LOGIN_STATUS, true);
            }

            if (path.toString().contains("studentActivation")) {
              prefs.setString(UserPreference.PATH_PARENT, path);
            }
// ToastWrap.showToast("Loggedin");
          } else {
            prefs.setString(UserPreference.PATHURL, path);
// afterAnimation();
            showToastLong(message, Constant.applicationContext);
          }
        } else {
          afterAnimation();
// If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        if (!mounted)
          CustomProgressLoader.cancelLoader(Constant.applicationContext);

        print(e);
// afterAnimation();
        showToastLong(e.toString(), context);
      }
    } else {
// afterAnimation();
      showToastLong("Please check your internet connection.", context);
    }
  }

  Future apiCallForLogout(path) async {
    try {
      print("response:-" + "api call");

      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        // CustomProgressLoader.showLoader(Constant.applicationContext);
        //assestList.removeAt(0);
        Map map = {};

        Response response = await ApiCalling().apiCallPostWithMapData(
            Constant.applicationContext, Constant.ENDPOINT_LOGOUT, map);
        // CustomProgressLoader.cancelLoader(Constant.applicationContext);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              Constant.isAlreadyLoggedIn = false;
              prefs.setBool(UserPreference.LOGIN_STATUS, false);
              if (path.contains("parentNotification")) {
                prefs.setString(UserPreference.PATHURL, path);
                Navigator.of(Constant.applicationContext)
                    .popUntil((route) => route.isFirst);

                Navigator.of(Constant.applicationContext).pushReplacement(
                    MaterialPageRoute(
                        builder: (BuildContext context) =>
                            LoginPage(imageList, showLogin: true)));
              } else if (path.contains("signupInvite")) {
                List<String> pathSplitList = path.split("/");
                String QRCODE = "";

                QRCODE = pathSplitList[pathSplitList.length - 1];
                try {
                  Codec<String, String> stringToBase64 = utf8.fuse(base64);
                  QRCODE =
                      stringToBase64.decode(QRCODE.replaceAll("&SPK", "="));
                } catch (e) {}
                print("qr code++++" + QRCODE.toString());
                Navigator.of(Constant.applicationContext)
                    .popUntil((route) => route.isFirst);
                Navigator.of(Constant.applicationContext)
                    .pushReplacement(MaterialPageRoute(
                        builder: (BuildContext context) => SignupStudentPageNew(
                              false,
                              "main",
                              "spikeview",
                              firstName: '',
                              lastName: '',
                              email: '',
                              image: "",
                              isValid: true,
                              isEditable: false,
                              qrCode: QRCODE,
                              qrType: 'QR',
                            )));
              } else if (path.contains("studentSignup")) {
                List<String> pathSplitList = path.split("/");
                String email = "", firstName = "", lastName = "";
                email = pathSplitList[pathSplitList.length - 3];
                firstName = pathSplitList[pathSplitList.length - 2];
                lastName = pathSplitList[pathSplitList.length - 1];
                Navigator.of(Constant.applicationContext)
                    .popUntil((route) => route.isFirst);
                Navigator.of(Constant.applicationContext).pushReplacement(
                    MaterialPageRoute(
                        builder: (BuildContext context) => SignupStudentPageNew(
                            false, "main", "spikeview",
                            firstName: firstName,
                            lastName: lastName,
                            email: email,
                            image: "",
                            isValid: true,
                            isEditable: true)));
              } else {
                handleAutoLoginWhenUserNotLogedIn(path);
              }
            } else {
              ToastWrap.showToast(msg, Constant.applicationContext);
            }
          }
        }
      } else {
        ToastWrap.showToast("Please check your internet connection.",
            Constant.applicationContext);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      print("response:-" + "Exception" + e.toString());
      //CustomProgressLoader.cancelLoader(Constant.applicationContext);
      e.toString();
    }
  }

  onTapPresoView(type) async {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    Navigator.pushReplacement(
        Constant.applicationContext,
        MaterialPageRoute(
            //   builder: (context) =>  DashBoardWidget()));
            builder: (context) => SharePresoView23(
                shareProfileModal.profileOwner, shareProfileModal, type)));
  }

  showConformatioDialog(path) {

    showModalBottomSheet(
        context: Constant.applicationContext,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            msg: 'Would you like to logout the current user?',
            negativeText: 'Cancel',
            positiveText: 'OK',
            isSucessPopup: false,
            positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
              afterAnimation();
            },
            onPositiveTap: (){
              apiCallForLogout(path);
            },
          );
        });


  }

  handleAutoLoginWhenUserNotLogedIn(path) {
    prefs.setString(UserPreference.PATHURL, path);
    if (path.contains("/badges/") &&
        path.contains("/self/") &&
        (path.contains("/5/") ||
            path.contains("/0/") ||
            path.contains("/3/") ||
            path.contains("/6/") ||
            path.contains("/7/") ||
            path.contains("/8/") ||
            path.contains("/9/"))) {
      try {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }

        if (path.contains("/self/")) {
          List<String> mesagelist = path.split("/");

          String badgeId = mesagelist[mesagelist.length - 4];
          print("badgeid++$badgeId");
          Navigator.pushReplacement(
              Constant.applicationContext,
              MaterialPageRoute(
                  builder: (context) => BadgeRequest(badgeId, 'main')));
        } else {
          navigationPage(false);
        }
      } catch (e) {
        navigationPage(false);
        crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      }
    } else if (path.contains("recommendation") &&
        (path.contains("/3/")
        )) {
      List<String> mesagelist = path.split("/");
      print("shubham8888++");
      //   ToastWrap.showToast(mesagelist[mesagelist.length-3]);
      String recommendationId = mesagelist[mesagelist.length - 3];
      String userIdRecomm = mesagelist[mesagelist.length - 5];
      String password = mesagelist[mesagelist.length - 1];
      print("88888888888---" + recommendationId + userIdRecomm);
      isContainPass = false;

      Navigator.pushReplacement(
          Constant.applicationContext,
          MaterialPageRoute(
              builder: (context) => SharedRecommendationDetail(
                  recommendationId, isContainPass, "", "Notexisting")));
    }else if (path.toString().contains("null")) {
      // prefs.setString(UserPreference.PATHURL, path);

      if (path.contains("recommendation") &&
          (path.contains("/5/") ||
              path.contains("/0/") ||
              path.contains("/6/") ||
              path.contains("/7/") ||
              path.contains("/8/") ||
              path.contains("/9/"))) {
        List<String> mesagelist = path.split("/");

        //   ToastWrap.showToast(mesagelist[mesagelist.length-3]);
        String recommendationId = mesagelist[mesagelist.length - 3];
        String userIdRecomm = mesagelist[mesagelist.length - 5];
        String password = mesagelist[mesagelist.length - 1];
        print("88888888888---" + recommendationId + userIdRecomm);
        isContainPass = false;

        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                builder: (context) => SharedRecommendationDetail(
                    recommendationId, isContainPass, "", "existing")));
      } else if (path.contains("referNow") || path.contains("refer")) {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                builder: (context) => LoginPage(
                      null,
                      isRedirectToRecommendation: false,
                      pageName: "main",
                      showSignup: true,
                    )));
      } else {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                builder: (context) => LoginPage(
                      imageList,
                      showLogin: true,
                    )));
      }
    } else {
      if (path.contains("login")) {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                builder: (context) => LoginPage(
                      null,
                      isRedirectToRecommendation: false,
                      pageName: "main",
                      showLogin: true,
                    )));
      } else if (path.contains("signupInvite")) {
        List<String> pathSplitList = path.split("/");
        String QRCODE = "";

        QRCODE = pathSplitList[pathSplitList.length - 1];
        try {
          Codec<String, String> stringToBase64 = utf8.fuse(base64);
          QRCODE = stringToBase64.decode(QRCODE.replaceAll("&SPK", "="));
        } catch (e) {}
        print("qr code++++" + QRCODE.toString());
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext)
            .pushReplacement(MaterialPageRoute(
                builder: (BuildContext context) => SignupStudentPageNew(
                      false,
                      "main",
                      "spikeview",
                      firstName: '',
                      lastName: '',
                      email: '',
                      image: "",
                      isValid: true,
                      isEditable: false,
                      qrCode: QRCODE,
                      qrType: 'QR',
                    )));
      } else if (path.contains("studentSignup")) {
        List<String> pathSplitList = path.split("/");
        String email = "", firstName = "", lastName = "";
        email = pathSplitList[pathSplitList.length - 3];
        firstName = pathSplitList[pathSplitList.length - 2];
        lastName = pathSplitList[pathSplitList.length - 1];
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) => SignupStudentPageNew(
                    false, "main", "spikeview",
                    firstName: firstName,
                    lastName: lastName,
                    email: email,
                    image: "",
                    isValid: true,
                    isEditable: true)));
      } else if (path.contains("signup")) {
        List<String> pathSplitList = path.split("/");
        String email = "", firstName = "", lastName = "";
        email = pathSplitList[pathSplitList.length - 1];

        print('email++++'+email);
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(Constant.applicationContext).pushReplacement(
            MaterialPageRoute(
                builder: (BuildContext context) => SignupStudentPageNew(
                  false, "main", "spikeview",
                  firstName: firstName,
                  lastName: lastName,
                  email: email,
                  image: "",
                  isValid: true,
                  isEditable: true,
                  loginRole: LoginRole.student,
                )));
      }else if (path.contains("subscription")) {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);

        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                builder: (context) => LoginPage(
                      imageList,
                      showLogin: true,
                    )));
      } else if (path.contains("joingroup")) {

        List<String> mesagelist = path.split("/");
        String roleId = mesagelist[mesagelist.length - 3];
        String groupId = mesagelist[mesagelist.length - 2];
        String email = mesagelist[mesagelist.length - 1];

        print("name shubh" +
            roleId +
            "   " +
            groupId +
            " " +
            "  " +
            email +
            "  "
        );

        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);

        Navigator.of(Constant.applicationContext)
            .pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => LoginPage(
              null,
              pageName: "main",
              showSignup: true,
            )));
      } else if (path.contains("publicprofile")) {
        //PUBLICUSER: 'kapil001@yopmail.com',
        //PUBLICPWD: 'Zs8uiJ8yla60CGPazIhqaA==',
        loginServiceCall(
            'notdelete@gmail.com', 'eJ8GA0plChBPc33WVTrc4A==', path);
      } else {
        if (path.contains("parentNotification")) {
        } else if (path.contains(Constant.OPPORTUNITY_DECLINE) ||
            path.contains(Constant.OPPORTUNITY_APPROVED) ||
            path.contains("OpportunityApproval") ||
            path.contains("partner_decline") ||
            path.contains("partner_approved") ||
            path.contains("partner_approval")) {
          Navigator.of(Constant.applicationContext).pushReplacement(
              MaterialPageRoute(
                  builder: (BuildContext context) =>
                      LoginPage(imageList, showLogin: true)));
        } else if (path.contains("studentActivation")) {
          List<String> pathSplitList = path.split("/");
          String email = "", password = "";
          email = pathSplitList[pathSplitList.length - 4];
          password = pathSplitList[pathSplitList.length - 3];
          password = password.replaceAll("_spike_", "/");
          print("email:-" + email + "  " + "pass" + password);
          loginServiceCall(email, password, path);
        } else {
          List<String> pathSplitList = path.split("/");
          String email = "", password = "";
          email = pathSplitList[pathSplitList.length - 2];
          password = pathSplitList[pathSplitList.length - 1];
          password = password.replaceAll("_spike_", "/");
          print("email:-" + email + "  " + "pass" + password);

          if (email == null || email == 'app.spikeview.com') {
            Navigator.of(Constant.applicationContext)
                .popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => LoginPage(
                          null,
                          isRedirectToRecommendation: false,
                          pageName: "main",
                          showLogin: true,
                        )));
          } else {
            loginServiceCall(email, password, path);
          }
        }
      }
    }
  }

  showErrorDialog(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");
      Navigator.pop(context);
      afterAnimation();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR : ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  roleSwitchConfirmationDialogForjoinGroup(roleId, groupId) {
    String roleName;

    switch (roleId) {
      case "1":
        roleName = "Student";
        break;
      case "2":
        roleName = "Parent";
        break;
      case "4":
        roleName = "Partner";
        break;
    }

    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 193.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Are you sure you want to switch your role as " +
                                                        roleName +
                                                        "?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              if (mounted) {
                                                navigationPage(false);
                                              } else {
                                                Navigator.of(
                                                        Constant
                                                            .applicationContext,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.of(
                                                      Constant
                                                          .applicationContext,
                                                      rootNavigator: true)
                                                  .pop('dialog');

                                              prefs.setString(
                                                  UserPreference.ROLE_ID,
                                                  roleId);

                                              /* if (userName == null ||
                                                  userName.contains("null") ||
                                                  userName == "") {
                                                Navigator.of(Constant.applicationContext).pushReplacement(
                                                     MaterialPageRoute(
                                                        builder: (BuildContext context) =>
                                                         EditUserProfile(groupId)));
                                              } else {*/
                                              Navigator.of(Constant
                                                      .applicationContext)
                                                  .pushReplacement(
                                                      MaterialPageRoute(
                                                          builder: (BuildContext
                                                                  context) =>
                                                              GroupDetailWidget(
                                                                  groupId,
                                                                  "login",
                                                                  "",
                                                                  "",
                                                                  "")));
                                              //  }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  addAchivmentOutsideTheApp(value) {
    if (prefs.getBool("loginStatus") != null && prefs.getBool("loginStatus")) {
      isParent = prefs.getBool("isParent");
      if (isParent == null) {
        isParent = false;
      }

      /* if (isParent) {
        ToastWrap.showToast(
            "Please login as student to add achivement into your story.");
      } else {*/
      if (mounted) {
        setState(() {
          isPathAvailable = true;
        });
      }

      Navigator.pushReplacement(
          Constant.applicationContext,
          MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
              builder: (context) => FullIMageViewGallery(value)));

      //   }
    } else {
      if (mounted) {
        setState(() {
          isPathAvailable = true;
        });
      }

      imageList.addAll(value);
      showErrorDialog("Please login to add achivement into your story",
          Constant.applicationContext);
    }
  }

  roleChangeNvigationHandling(String message) {
    if (message.contains("OpportunityApproval")) {
      List<String> mesagelist = message.split("/");
      String opportunityId = mesagelist[mesagelist.length - 3];

      Navigator.of(Constant.applicationContext).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  OpportunityForBoat(opportunityId, "1", 'main')));
    } else if (message.contains(Constant.OPPORTUNITY_APPROVED)) {
      List<String> mesagelist = message.split("/");
      String opportunityId = mesagelist[mesagelist.length - 1];

      Navigator.of(Constant.applicationContext).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  OpportunityForBoat(opportunityId, "4", 'main')));
    } else if (message.contains(Constant.OPPORTUNITY_DECLINE)) {
      List<String> mesagelist = message.split("/");
      String opportunityId = mesagelist[mesagelist.length - 1];

      Navigator.of(Constant.applicationContext).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  opportunityRejected('main', opportunityId)));
    } else if (message.contains("partner_approval")) {
      List<String> mesagelist = message.split("/");
      String userId = mesagelist[mesagelist.length - 1];

      Navigator.of(Constant.applicationContext).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  PatnerProfileWidgetForBoatReview(userId, "main")));
    } else if (message.contains("partner_decline")) {
      Navigator.of(Constant.applicationContext).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  PartnerRejectionReason('main')));
    } else if (message.contains("partner_approved")) {
      navigationPage(false);
    }
  }

  roleSwitchConfirmationDialogForBadge(badgeId) {
    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 193.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Are you sure you want to switch your role as " +
                                                        'Partner' +
                                                        "?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              if (mounted) {
                                                navigationPage(false);
                                              } else {
                                                Navigator.of(
                                                        Constant
                                                            .applicationContext,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.of(
                                                      Constant
                                                          .applicationContext,
                                                      rootNavigator: true)
                                                  .pop('dialog');

                                              prefs.setString(
                                                  UserPreference.ROLE_ID, '4');

                                              Navigator.of(Constant
                                                      .applicationContext)
                                                  .pushReplacement(MaterialPageRoute(
                                                      builder: (BuildContext
                                                              context) =>
                                                          PartnerNotificationManageBadges(
                                                              "login",
                                                              badgeId:
                                                                  badgeId)));
                                              // }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  roleSwitchConfirmationDialogForBoatAndPrtner(String message, roleId) {
    String roleName;

    switch (roleId) {
      case "1":
        roleName = "Student";
        break;
      case "2":
        roleName = "Parent";
        break;
      case "4":
        roleName = "Partner";
        break;
    }

    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 193.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Are you sure you want to switch your role as " +
                                                        roleName +
                                                        "?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              if (mounted) {
                                                navigationPage(false);
                                              } else {
                                                Navigator.of(
                                                        Constant
                                                            .applicationContext,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.of(
                                                      Constant
                                                          .applicationContext,
                                                      rootNavigator: true)
                                                  .pop('dialog');

                                              prefs.setString(
                                                  UserPreference.ROLE_ID,
                                                  roleId);
                                              roleChangeNvigationHandling(
                                                  message);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  roleSwitchConfirmationDialogForParentApprovel(message, type, loginRole) {
    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 193.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    loginRole == "2"
                                                        ? "Are you sure you want to switch your role as parent?"
                                                        : "Are you sure you want to switch your role as student?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              if (mounted) {
                                                navigationPage(false);
                                              } else {
                                                Navigator.of(
                                                        Constant
                                                            .applicationContext,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                                afterAnimation();
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.of(
                                                      Constant
                                                          .applicationContext,
                                                      rootNavigator: true)
                                                  .pop('dialog');

                                              prefs.setString(
                                                  UserPreference.ROLE_ID,
                                                  loginRole);
                                              approveConnectionFlow(
                                                  message, type);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  approveConnectionFlow(message, type) {
    String connectId, status, email, pass, userId, roleId, loginRole;
    if (type == "redirect") {
      message = message.replaceAll(
          "https://app.spikeview.com/student/connectionrequest/?connectId=",
          "");
      message = message.replaceAll(
          "https://spikeview.com/student/connectionrequest/?connectId=", "");
      List<String> mesagelist = message.split("&");
//https://app.spikeview.com/student/connectionrequest/?connectId=10116&status=Requested&loginRole=2&email=p55@yopmail.com&pass=null&userId=4186&roleId=1
      connectId = mesagelist[0];
      status = mesagelist[1].replaceAll("status=", "");
      loginRole = mesagelist[2].replaceAll("loginRole=", "");
      email = mesagelist[3].replaceAll("email=", "");
      pass = mesagelist[4].replaceAll("pass=", "");
      userId = mesagelist[5].replaceAll("userId=", "");
      roleId = mesagelist[6].replaceAll("roleId=", "");
    } else {
      //https://app.spikeview.com/viewprofile/?connectId=10116&loginRole=2&email=p55@yopmail.com&pass=null&userId=4186&roleId=1
      message = message.replaceAll(
          "https://app.spikeview.com/viewprofile/?connectId=", "");
      message = message.replaceAll(
          "https://spikeview.com/student/connectionrequest/?connectId=", "");
      List<String> mesagelist = message.split("&");

      connectId = mesagelist[0];
      loginRole = mesagelist[1].replaceAll("loginRole=", "");
      status = "";
      email = mesagelist[2].replaceAll("email=", "");
      pass = mesagelist[3].replaceAll("pass=", "");
      userId = mesagelist[4].replaceAll("userId=", "");
      roleId = mesagelist[5].replaceAll("roleId=", "");
    }

    print("=======" +
        connectId +
        "  " +
        status +
        "  " +
        email +
        "  " +
        pass +
        "  " +
        userId +
        "  " +
        roleId);

    if (roleId == "1") {
      // For Student
      Navigator.of(Constant.applicationContext)
          .pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => UserProfileDashBoardForOther(
                    userId,
                    true,
                    type,
                    "1",
                    connectionId: connectId,
                    requestStatus: status,
                  )));
    } else if (roleId == "2") {
      // For Parent
      Navigator.of(Constant.applicationContext)
          .pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => ParentProfilePageWithHeader(
                    userId,
                    type,
                    connectionId: connectId,
                    requestStatus: status,
                  )));
    } else if (roleId == "4") {
      // For Partner

      Navigator.of(Constant.applicationContext).pushReplacement(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  PatnerProfileWidgetForOtherUser(
                    userId,
                    type,
                    connectionId: connectId,
                    requestStatus: status,
                  )));
    }
  }

  showToastAndMove(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(Constant.applicationContext);
      Navigator.of(Constant.applicationContext)
          .popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
          Constant.applicationContext,
          MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
              builder: (context) => DashBoardWidget(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                  )));
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  roleSwitchConfirmationDialogForParent(roleId, actedBy, profileId) {
    String roleName;

    switch (roleId) {
      case "1":
        roleName = "Student";
        break;
      case "2":
        roleName = "Parent";
        break;
      case "4":
        roleName = "Partner";
        break;
    }

    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 193.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Are you sure you want to switch your role as " +
                                                        roleName +
                                                        "?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              if (mounted) {
                                                navigationPage(false);
                                              } else {
                                                Navigator.of(
                                                        Constant
                                                            .applicationContext,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                              }
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.of(
                                                      Constant
                                                          .applicationContext,
                                                      rootNavigator: true)
                                                  .pop('dialog');

                                              prefs.setString(
                                                  UserPreference.ROLE_ID,
                                                  roleId);

                                              Navigator.of(
                                                Constant.applicationContext,
                                              ).pushReplacement(
                                                  new MaterialPageRoute(
                                                      builder: (BuildContext
                                                              context) =>
                                                          PublicViewForUser(
                                                            "",
                                                            "main",
                                                            "Connected",
                                                            true,
                                                            actedUserId:
                                                                actedBy,
                                                            acteRoleId: "2",
                                                            profileValue:
                                                                profileId,
                                                          )));
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  ErrorToast(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");

      Navigator.pop(Constant.applicationContext);
      navigationPage(false);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  String getLinkUrl(str) {
    try {
      Iterable<Match> matches = exp.allMatches(str);
      print("uri+++++++matches++++++" + matches.length.toString());
      for (Match m in matches) {
        String match = m.group(0);

        return match;
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      return "";
    }
    return "";
  }

  Future apiCallForPublicData(isShowLaoder, context, publicURL) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++" +
            Constant.ENDPOINT_GET_PREVIEW_DETAIL_IN_PUBLIC +
            publicURL +
            "&profileType=Public&userId=" +
            "");
        Response response = await ApiCalling2().apiCallingWithoutAuth(
            Constant.ENDPOINT_GET_PREVIEW_DETAIL_IN_PUBLIC +
                publicURL +
                "&profileType=Public&userId=" +
                "",
            "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _PublicViewModel = PublicViewModel.fromJson(response.data);
              if (_PublicViewModel != null &&
                  _PublicViewModel.result.profileView == "Linear") {
                try {
                  Navigator.of(Constant.applicationContext)
                      .popUntil((route) => route.isFirst);
                  Navigator.of(Constant.applicationContext).pushReplacement(
                      MaterialPageRoute(
                          builder: (BuildContext context) => PublicViewForUser(
                              publicURL, "main", "Public", false)));
                } catch (e) {
                  crashlytics_bloc.recordCrashlyticsError(e, "main", context);
                  print('Exception 111 e: $e');
                }
              } else {
                Navigator.of(Constant.applicationContext)
                    .popUntil((route) => route.isFirst);
                Navigator.of(Constant.applicationContext).pushReplacement(
                    MaterialPageRoute(
                        builder: (BuildContext context) =>
                            CustomPresoViewForUser(publicURL, "main", 'Public',
                                false.toString(), "")));
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      // if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++" + e.toString());
    }
  }

  Future changeEmailApiCall(userToken) async {
    print('inside getPreLoginData() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCallWithouAuth(
            Constant.applicationContext,
            Constant.CHANGE_EMAIL + userToken,
            "get");
        print("response++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String userId = response.data['result'][LoginResponseConstant.ID];
            print("response++++" + userId.toString());
            if (status == "Success") {
              Navigator.pushReplacement(
                  Constant.applicationContext,
                  MaterialPageRoute(
                      builder: (context) => EmailUpdateSuccess(
                          prefs.getBool("loginStatus") != null &&
                                  prefs.getBool("loginStatus")
                              ? true
                              : false,
                          prefs.getString(UserPreference.USER_ID) == userId
                              ? true
                              : false)));
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      e.toString();
    }
  }

  preformLogin(message) {
    Timer _timer = Timer(const Duration(milliseconds: 400), () async {
      if (message.contains("/sv/")) {
        try {
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
          String publicURL = message.split("/sv/")[1];
          print("publicURL+++++++" + publicURL);
          apiCallForPublicData(false, Constant.applicationContext, publicURL);
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
      } else if (message.contains("changeEmail")) {
        try {
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
          List<String> mesagelist = message.split("/");
          String userToken = mesagelist[mesagelist.length - 1];
          changeEmailApiCall(userToken);
        } catch (e) {
          navigationPage(false);
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
      } else if (message.contains("userprofile_dwd")) {
        try {
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
          String shareId = message.split("/userprofile_dwd/")[1];
          print('Clicked on link' + message);

          try {
            String profileId = await platform.invokeMethod('decryption', {
              "password": shareId.replaceAll("_spike_", "/"),
            });

            if (profileId != null && profileId != "") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              Navigator.of(
                Constant.applicationContext,
              ).pushReplacement(new MaterialPageRoute(
                  builder: (BuildContext context) => PublicViewForUser(
                      "", "main", "Connected", true,
                      actedUserId: profileId)));
              // CustomProgressLoader.cancelLoader(context);
            }
          } catch (e) {
            crashlytics_bloc.recordCrashlyticsError(e, "main", context);
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
          navigationPage(false);
        }
      } else if (message.contains("cus") && message.contains("Linear")) {
        try {
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
          String shareId = message.split("/Linear/")[1];
          print('Clicked on link' + message);

          try {
            Codec<String, String> stringToBase64 = utf8.fuse(base64);
            String decodedSharedId = stringToBase64
                .decode(shareId.replaceAll("&SPK", "=")); // username:password
            print('SharedID public preview 111:: ${shareId}');
            print('decodedSharedId public preview 111:: ${decodedSharedId}');
            if (decodedSharedId != null && decodedSharedId != "") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              Navigator.of(Constant.applicationContext).pushReplacement(
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          CustomViewForUser(decodedSharedId, "main")));
              // CustomProgressLoader.cancelLoader(context);
            }
          } catch (e) {
            print('Exception 111 e: $e');
            crashlytics_bloc.recordCrashlyticsError(e, "main", context);
          }
        } catch (e) {
          navigationPage(false);
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
      } else if (message.contains("cus") && message.contains("Preso")) {
        try {
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
          String shareId = message.split("/Preso/")[1];
          print('Clicked on link' + message);

          try {
            Codec<String, String> stringToBase64 = utf8.fuse(base64);
            String decodedSharedId = stringToBase64
                .decode(shareId.replaceAll("&SPK", "=")); // username:password
            print('SharedID public preview 111:: ${shareId}');
            print('decodedSharedId public preview 111:: ${decodedSharedId}');
            if (decodedSharedId != null && decodedSharedId != "") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              Navigator.of(Constant.applicationContext).push(MaterialPageRoute(
                  builder: (BuildContext context) => CustomPresoViewForUser(
                      decodedSharedId,
                      "main",
                      'Custom',
                      false.toString(),
                      "")));
              // CustomProgressLoader.cancelLoader(context);
            }
          } catch (e) {
            print('Exception 111 e: $e');
            crashlytics_bloc.recordCrashlyticsError(e, "main", context);
          }
        } catch (e) {
          navigationPage(false);
          crashlytics_bloc.recordCrashlyticsError(e, "main", context);
        }
      } else if (prefs.getBool("loginStatus") != null &&
          prefs.getBool("loginStatus")) {
        if (message.contains("parentNotification")) {
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
// isLoading = true;
          List<String> mesagelist = message.split("/");

          String userId = mesagelist[mesagelist.length - 1];
          String profileId = mesagelist[mesagelist.length - 2];
          String actedBy = mesagelist[mesagelist.length - 3];
          if (userId == prefs.getString(UserPreference.USER_ID)) {
            if (prefs.getString(UserPreference.ROLE_ID) == "2") {
              Navigator.of(Constant.applicationContext)
                  .popUntil((route) => route.isFirst);
              Navigator.of(
                Constant.applicationContext,
              ).pushReplacement(new MaterialPageRoute(
                  builder: (BuildContext context) => PublicViewForUser(
                        "",
                        "main",
                        "Connected",
                        true,
                        actedUserId: actedBy,
                        acteRoleId: "2",
                        profileValue: profileId,
                      )));
            } else {
              roleSwitchConfirmationDialogForParent("2", actedBy, profileId);
            }
          } else {
            showConformatioDialog(message);

            // ErrorToast("Sorry, you are not authorized to access this link.", Constant.applicationContext);
            // navigationPage(false);
          }
        } else if (message.contains("publicprofile")) {
          print("userName publicprofile" + userName);
          // https://app.spikeview.com/student/publicprofile/MTUxNw==
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
          List<String> mesagelist = message.split("/");

          String sharedId = mesagelist[mesagelist.length - 1];
          print('decodedSharedId public preview 222:: ${message}');
          print('decodedSharedId public preview 222:: ${sharedId}');
          try {
            Codec<String, String> stringToBase64 = utf8.fuse(base64);
            String decodedSharedId = stringToBase64
                .decode(sharedId.replaceAll("&SPK", "=")); // username:password

            print('decodedSharedId public preview 222:: ${decodedSharedId}');
            print('SharedID public preview 222:: ${sharedId}');
            if (decodedSharedId != null && decodedSharedId != "") {
// Navigator.pop(context);
              await shareIDData(decodedSharedId, "main", true);

// CustomProgressLoader.cancelLoader(context);

            }
          } catch (e) {
            print("Error publicprofile+++++++++" + e.toString());
            crashlytics_bloc.recordCrashlyticsError(e, "main", context);
          }
        } else if (message.toLowerCase().contains(
            prefs.getString(UserPreference.EMAIL).toString().toLowerCase())) {
          if (message.contains("/badges/")) {
            try {
              if (mounted) {
                setState(() {
                  isPathAvailable = true;
                });
              }

              List<String> mesagelist = message.split("/");

              String badgeId = mesagelist[mesagelist.length - 4];
              print("badgeid++$badgeId");

              if (message.contains("/request/")) {
                if (prefs.getString(UserPreference.ROLE_ID) == '4') {
                  Navigator.of(Constant.applicationContext)
                      .popUntil((route) => route.isFirst);

                  Navigator.of(Constant.applicationContext).pushReplacement(
                      MaterialPageRoute(
                          builder: (BuildContext context) =>
                              PartnerNotificationManageBadges("login",
                                  badgeId: badgeId)));
                } else {
                  roleSwitchConfirmationDialogForBadge(badgeId);
                }
              } else {
                Navigator.of(Constant.applicationContext)
                    .popUntil((route) => route.isFirst);
                Navigator.pushReplacement(
                    Constant.applicationContext,
                    MaterialPageRoute(
                        builder: (context) => BadgeRequest(badgeId, 'main')));
              }
            } catch (e) {
              navigationPage(false);
              crashlytics_bloc.recordCrashlyticsError(e, "main", context);
            }
          } else if (message.toString().contains("studentActivation") &&
              roleId == "2") {
            prefs.setString(UserPreference.PATH_PARENT, message);
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => DashBoardWidgetParent(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                        )));
          } else if (message.contains("subscription")) {
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            List<String> mesagelist = message.split("/");

            //   isLoading = true;
            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) =>
                        UnSubScribeWidget(mesagelist[mesagelist.length - 2])));
          } else if (message.contains("partner_approval")) {
            ///[4:03 PM] Rajesh Patel partner_approval
            //     https://app.spikeview.com/partner_approval/operations@spikeview.com/3297
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            List<String> mesagelist = message.split("/");
            String userId = mesagelist[mesagelist.length - 3];

            if (prefs.getString(UserPreference.ROLE_ID) == "1") {
              Navigator.of(Constant.applicationContext).pushReplacement(
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          PatnerProfileWidgetForBoatReview(userId, "main")));
            } else {
              roleSwitchConfirmationDialogForBoatAndPrtner(message, "1");
            }
          } else if (message.contains("partner_approved")) {
            ///[4:03 PM] Rajesh Patel partner_approval
            //     https://app.spikeview.com/partner_approval/operations@spikeview.com/3297

            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }

            if (prefs.getString(UserPreference.ROLE_ID) == "4") {
              navigationPage(false);
            } else {
              roleSwitchConfirmationDialogForBoatAndPrtner(message, "4");
            }
          } else if (message.contains("partner_decline")) {
            ///[4:03 PM] Rajesh Patel partner_approval
            //     https://app.spikeview.com/partner_approval/operations@spikeview.com/3297

            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }

            if (prefs.getString(UserPreference.ROLE_ID) == "4") {
              Navigator.of(Constant.applicationContext).pushReplacement(
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          PartnerRejectionReason('main')));
            } else {
              roleSwitchConfirmationDialogForBoatAndPrtner(message, "4");
            }
          } else if (message.contains("OpportunityApproval")) {
            //https://app.spikeview.com/OpportunityApproval/1744/operations@spikeview.com/1
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            List<String> mesagelist = message.split("/");
            String userId = mesagelist[mesagelist.length - 3];

            if (prefs.getString(UserPreference.ROLE_ID) == "1") {
              Navigator.of(Constant.applicationContext).pushReplacement(
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          OpportunityForBoat(userId, "1", 'main')));
            } else {
              roleSwitchConfirmationDialogForBoatAndPrtner(message, "1");
            }
          } else if (message.contains(Constant.OPPORTUNITY_APPROVED)) {
            //https://app.spikeview.com/OpportunityApproval/1744/operations@spikeview.com/1
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            List<String> mesagelist = message.split("/");
            String userId = mesagelist[mesagelist.length - 1];

            if (prefs.getString(UserPreference.ROLE_ID) == "4") {
              Navigator.of(Constant.applicationContext).pushReplacement(
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          OpportunityForBoat(userId, "4", 'main')));
            } else {
              roleSwitchConfirmationDialogForBoatAndPrtner(message, "4");
            }
          } else if (message.contains(Constant.OPPORTUNITY_DECLINE)) {
            //https://app.spikeview.com/OpportunityApproval/1744/operations@spikeview.com/1
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            List<String> mesagelist = message.split("/");
            String opportunityId = mesagelist[mesagelist.length - 1];

            if (prefs.getString(UserPreference.ROLE_ID) == "4") {
              Navigator.of(Constant.applicationContext).pushReplacement(
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          opportunityRejected('main', opportunityId)));
            } else {
              roleSwitchConfirmationDialogForBoatAndPrtner(message, "4");
            }
          } else if (message.contains("connectionrequest")) {
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }

            message = message.replaceAll(
                "https://app.spikeview.com/student/connectionrequest/?connectId=",
                "");
            List<String> mesagelist = message.split("&");
            String loginRole = mesagelist[2].replaceAll("loginRole=", "");

            if (prefs.getString(UserPreference.ROLE_ID) == loginRole) {
              approveConnectionFlow(message, "redirect");
            } else {
              roleSwitchConfirmationDialogForParentApprovel(
                  message, "redirect", loginRole);
            }
          } else if (message.contains("previewprofile")) {
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            //   isLoading = true;
            List<String> mesagelist = message.split("/");

            //   ToastWrap.showToast(mesagelist[mesagelist.length-3]);
            String sharedId = mesagelist[mesagelist.length - 3];

            try {
              Codec<String, String> stringToBase64 = utf8.fuse(base64);
              String decodedSharedId = stringToBase64.decode(
                  sharedId.replaceAll("&SPK", "=")); // username:password

              print('decodedSharedId public preview 222:: ${decodedSharedId}');
              print('SharedID public preview 222:: ${sharedId}');
              if (decodedSharedId != null && decodedSharedId != "") {
                await shareIDData(decodedSharedId, "main", false);
              }
            } catch (e) {
              crashlytics_bloc.recordCrashlyticsError(e, "main", context);
            }

            /* if (sharedId != null && sharedId != "") {
              //  Navigator.pop(context);
              await shareIDData(sharedId, "main",false);

              // CustomProgressLoader.cancelLoader(context);

            }*/
          } else if (message.contains("viewprofile")) {
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }

            message = message.replaceAll(
                "https://app.spikeview.com/viewprofile/?connectId=", "");
            List<String> mesagelist = message.split("&");

            String loginRole = mesagelist[1].replaceAll("loginRole=", "");

            if (prefs.getString(UserPreference.ROLE_ID) == loginRole) {
              approveConnectionFlow(message, "view");
            } else {
              roleSwitchConfirmationDialogForParentApprovel(
                  message, "view", loginRole);
            }
          } else if (message.contains("recommendation")) {
            // isLoading = true;
            List<String> mesagelist = message.split("/");

            //   ToastWrap.showToast(mesagelist[mesagelist.length-3]);
            String recommendationId = mesagelist[mesagelist.length - 3];
            String userIdRecomm = mesagelist[mesagelist.length - 5];

            if (prefs.getString(UserPreference.USER_ID) == userIdRecomm) {
              Navigator.pushReplacement(
                  Constant.applicationContext,
                  MaterialPageRoute(
                      builder: (context) => SharedRecommendationDetail(
                          recommendationId, false, "", "existing")));
            } else {
              ToastWrap.showToast(
                  "Sorry, you are not authorized to access this recommendation.",
                  Constant.applicationContext);
            }
            print("sharedid" + recommendationId + "userId" + userIdRecomm);
          } else if (message.contains("joingroup")) {
            print("userName latest" + userName);
            userName = prefs.getString(UserPreference.NAME);

            print("userName latest" + userName);
            List<String> mesagelist = message.split("=");


            String roleId = mesagelist[mesagelist.length - 3];
            String groupId = mesagelist[mesagelist.length - 2];
            String email = mesagelist[mesagelist.length - 1];


            prefs = await SharedPreferences.getInstance();

            String userRole = prefs.getString(UserPreference.ROLE_ID);

            if (prefs != null && userRole != roleId) {
              // Popup Need to show here

              print("datat+++++userRole=={$userRole}++RoleIs=={$roleId}++++" +
                  message.toString());

              roleSwitchConfirmationDialogForjoinGroup(roleId, groupId);
            } else {
              /* if (userName == null ||
                  userName.contains("null") ||
                  userName == "") {
                Navigator.of(Constant.applicationContext).pushReplacement(
                     MaterialPageRoute(
                        builder: (BuildContext context) =>
                             EditUserProfile(groupId)));
              } else {*/
              Navigator.of(Constant.applicationContext).pushReplacement(
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          GroupDetailWidget(groupId, "login", "", "", "")));
              //}
            }
          } else if (message.contains("forwardToParentGroup")) {
            //https://spikeview.com/forwardToParentGroup?
            // groupId=702
            // &studentId=4069
            // &roleId=1&email=father@mailinator.com&pass=null
            List<String> mesagelist = message.split("=");

            String groupId = mesagelist[1].replaceAll("&studentId", "");
            String studentId = mesagelist[2].replaceAll("&roleId", "");
            String roleId = mesagelist[3].replaceAll("&email", "");
            String email = mesagelist[4].replaceAll("&pass", "");

            print("dtata++++" + groupId + " " + studentId);

            //117&studentId  368&email  papa20@yopmail.com&pass

            Navigator.of(Constant.applicationContext).pushReplacement(
                MaterialPageRoute(
                    builder: (BuildContext context) => GroupDetailWidget(
                        groupId, "login", "", "", studentId)));
          } else if (message.contains("forwardToParentInquire")) {
            List<String> mesagelist = message.split("=");

            String opportunityId = mesagelist[1].replaceAll("&email", "");
            String email = mesagelist[2].replaceAll("&pass", "");

            print("opportunityId++++" + opportunityId + "  " + email);

            Navigator.of(Constant.applicationContext).pushReplacement(
                MaterialPageRoute(
                    builder: (BuildContext context) => InquireNowScreen(
                        opportunityId, userIdPref, "", "1", "login")));
          } //////////////////-------------else if(auto)
          else if (message.contains("autoLogin")) {
            print('inside autoLogin user already logged in');
            prefs = await SharedPreferences.getInstance();
            String userRole = prefs.getString(UserPreference.ROLE_ID);
            //navigate to that page on click from email
            // value :- https://app.spikeview.com/autoLogin/ad30@yopmail.com/_spike_I6SMCBCYc9NHifBmClcQg==
            if (userRole == "1") {
              print('before going to any page widget.userId:: ${userIdPref}');
            /*  if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
                Navigator.of(Constant.applicationContext).pushReplacement(
                    MaterialPageRoute(
                        builder: (BuildContext context) => MoreData()));
              } else {*/
                StudentOnBoarding().getStudentOnBoardingInit(
                    Constant.applicationContext,
                    profileInfoModal,
                    sasToken,
                    userIdPref);
            //  }
            }
          }
        } else {
          if (message.contains("publicprofile")) {
            ToastWrap.showToast(
                "Sharing is not available.", Constant.applicationContext);
          } else {
            print(("userEmail" + "logout first"));
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            // print("Role++++"+  Constant.pageNameFr.toString());

            showConformatioDialog(message);
          }
        }
      } else {
        print(("is notlogged in"));
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        prefs.setString(UserPreference.PATHURL, message);
        if (message.contains("null")) {
          print(("is notlogged in"));

          if (message.contains("referNow") || message.contains("refer")) {
            // https://spikeview.com/referNow?userId=1830&roleId=1&email=sk1213@yopmail.com&pass=null
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }

            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => LoginPage(
                          null,
                          isRedirectToRecommendation: false,
                          pageName: "main",
                          showSignup: true,
                        )));
          } else {
            handleAutoLoginWhenUserNotLogedIn(message);
          }
        } else {
          //ToastWrap.showToast("Auto login");

          if (message.contains("referNow") || message.contains("refer")) {
            // https://spikeview.com/referNow?userId=1830&roleId=1&email=sk1213@yopmail.com&pass=null
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }

            Navigator.pushReplacement(
                Constant.applicationContext,
                MaterialPageRoute(
                    builder: (context) => LoginPage(
                          null,
                          isRedirectToRecommendation: false,
                          pageName: "main",
                          showSignup: true,
                        )));
          } else {
            handleAutoLoginWhenUserNotLogedIn(message);
          }
        }
        //prefs.setString(UserPreference.PATHURL,message);
      }
    });
  }

  showToastForShare(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");
      navigationPage(false);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              //  Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                navigationPage(false);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: ' ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                navigationPage(false);
              },
            )));
  }

  void shareUrlOption(link) {
    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 24.0,
                            child: Container(
                                height: prefs.getString(
                                            UserPreference.ROLE_ID) ==
                                        "4"
                                    ? 248.0
                                    : prefs != null &&
                                            prefs.getString(UserPreference
                                                    .ACCESS_CONTROL_ALLOWFEEDPOST) !=
                                                null &&
                                            prefs.getString(UserPreference
                                                    .ACCESS_CONTROL_ALLOWFEEDPOST) ==
                                                "true"
                                        ? 200.0
                                        : 145.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          "Chat",
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                        )),
                                                    onTap: () {
                                                      if (prefs.getString(
                                                              UserPreference
                                                                  .ISACTIVE) ==
                                                          "true") {
                                                        Navigator.pop(Constant
                                                            .applicationContext);
                                                        Navigator.of(Constant
                                                                .applicationContext)
                                                            .push(
                                                                MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        ChatFriendListWithHeader(
                                                                          link,
                                                                          "",
                                                                          userIdPref,
                                                                          pageName:
                                                                              "notification",
                                                                          roleId:
                                                                              prefs.getString(UserPreference.ROLE_ID),
                                                                        )));
                                                      } else {
                                                        Navigator.pop(Constant
                                                            .applicationContext);
                                                        showToastForShare(
                                                            MessageConstant
                                                                .PENDING_PROFILE_ACTIVATION,
                                                            Constant
                                                                .applicationContext);
                                                      }
                                                    },
                                                  ),
                                                  prefs != null &&
                                                          prefs.getString(
                                                                  UserPreference
                                                                      .ACCESS_CONTROL_ALLOWFEEDPOST) !=
                                                              null &&
                                                          prefs.getString(
                                                                  UserPreference
                                                                      .ACCESS_CONTROL_ALLOWFEEDPOST) ==
                                                              "true"
                                                      ? Column(
                                                          children: <Widget>[
                                                            Container(
                                                              color: ColorValues
                                                                  .BORDER_COLOR,
                                                              height: 1.0,
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                  height: 50.0,
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          13.0,
                                                                          0.0,
                                                                          13.0),
                                                                  child: Text(
                                                                    "Feed",
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 1,
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR,
                                                                        height:
                                                                            1.2,
                                                                        fontSize:
                                                                            16.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                              onTap: () async {
                                                                if (prefs.getString(
                                                                        UserPreference
                                                                            .ISACTIVE) ==
                                                                    "true") {
                                                                  if (  prefs.getString(UserPreference.ACCESS_CONTROL_FEED_STATUS)
                                                                      .toLowerCase() ==
                                                                      "true") {
                                                                    Navigator.pop(
                                                                        Constant
                                                                            .applicationContext);
                                                                    Navigator.of(
                                                                        Constant.applicationContext)
                                                                        .push(MaterialPageRoute(
                                                                        builder: (BuildContext context) => AddPost(
                                                                          profileInfoModal,
                                                                          "",
                                                                          groupDetailModel: null,
                                                                          link: link,
                                                                        )));
                                                                  } else {
                                                                    ToastWrap.showToastForAccessDenied(
                                                                        MessageConstant
                                                                            .FEATURE_DIABLED,
                                                                        context);
                                                                  }
                                                                } else {
                                                                  Navigator.pop(
                                                                      Constant
                                                                          .applicationContext);
                                                                  showToastForShare(
                                                                      MessageConstant
                                                                          .PENDING_PROFILE_ACTIVATION,
                                                                      Constant
                                                                          .applicationContext);
                                                                }
                                                              },
                                                            ),
                                                          ],
                                                        )
                                                      : SizedBox(),
                                                  Column(
                                                    children: <Widget>[
                                                      Container(
                                                        color: ColorValues
                                                            .BORDER_COLOR,
                                                        height: 1.0,
                                                      ),
                                                      InkWell(
                                                        child: Container(
                                                            height: 50.0,
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    0.0,
                                                                    13.0,
                                                                    0.0,
                                                                    13.0),
                                                            child: Text(
                                                              "Group",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 1,
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            )),
                                                        onTap: () async {
                                                          if (prefs.getString(
                                                                  UserPreference
                                                                      .ISACTIVE) ==
                                                              "true") {
                                                            if (prefs.getString(UserPreference.ACCESS_CONTROL_GROUP)
                                                                .toLowerCase() ==
                                                                "true") {
                                                              Navigator.pop(Constant
                                                                  .applicationContext);
                                                              Navigator.of(Constant
                                                                  .applicationContext)
                                                                  .push(MaterialPageRoute(
                                                                  builder: (BuildContext
                                                                  context) =>
                                                                      GroupListShareFlow(
                                                                          profileInfoModal,
                                                                          link)));
                                                            } else {
                                                              ToastWrap.showToastForAccessDenied(
                                                                  MessageConstant
                                                                      .FEATURE_DIABLED,
                                                                  context);
                                                            }
                                                          } else {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            showToastForShare(
                                                                MessageConstant
                                                                    .PENDING_PROFILE_ACTIVATION,
                                                                Constant
                                                                    .applicationContext);
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  prefs.getString(UserPreference
                                                              .ROLE_ID) ==
                                                          "4"
                                                      ? Column(
                                                          children: <Widget>[
                                                            Container(
                                                              color: ColorValues
                                                                  .BORDER_COLOR,
                                                              height: 1.0,
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                  height: 50.0,
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          13.0,
                                                                          0.0,
                                                                          13.0),
                                                                  child: Text(
                                                                    "Opportunity",
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 1,
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR,
                                                                        height:
                                                                            1.2,
                                                                        fontSize:
                                                                            16.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                              onTap: () async {
                                                                if (prefs.getString(
                                                                        UserPreference
                                                                            .ISACTIVE) ==
                                                                    "true") {
                                                                  Navigator.pop(
                                                                      Constant
                                                                          .applicationContext);
                                                                  Navigator.of(
                                                                          Constant
                                                                              .applicationContext)
                                                                      .push(MaterialPageRoute(
                                                                          builder: (BuildContext context) => OpportunitySelection(
                                                                              companyModelNew,
                                                                              link: link)));
                                                                } else {
                                                                  Navigator.pop(
                                                                      Constant
                                                                          .applicationContext);
                                                                  showToastForShare(
                                                                      MessageConstant
                                                                          .PENDING_PROFILE_ACTIVATION,
                                                                      Constant
                                                                          .applicationContext);
                                                                }
                                                                //}
                                                              },
                                                            ),
                                                          ],
                                                        )
                                                      : Container(height: 0.0),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(
                                                  Constant.applicationContext);
                                              navigationPage(false);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  @override
  void initState() {
    _initializeFlutterFire();
    _intentDataStreamSubscription =
        ReceiveSharingIntent.getTextStream().listen((String value) async {
      print("value text1:- " + value);
      if (value != null &&
          value.contains("app.spikeview") &&
          !value.contains("I am sharing my")) {
        if (value.contains("/sv/") || value.contains("cus")) {
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
        }
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        isPathAvailable = true;
        preformLogin(value);
      } else {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        prefs = await SharedPreferences.getInstance();
        if (prefs.getBool("loginStatus") != null &&
            prefs.getBool("loginStatus")) {
          //  if (Platform.isAndroid) {
          if (mounted) {
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            prefs.setString(UserPreference.LINK, value);
            navigationPage(true);
          } else {
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
            if (prefs.getString(UserPreference.ROLE_ID) == "1" &&
                isAlreadyLoggedIn) {
              if (profileInfoModal == null) profileApiChild(false);
            } else if (prefs.getString(UserPreference.ROLE_ID) == "2") {
              if (profileInfoModal == null) profileApiParent(false);
            } else if (prefs.getString(UserPreference.ROLE_ID) == "4") {
              if (companyModel == null) companyInfoApi(false);
            }
            shareUrlOption(value);
          }
          /*    }else{
                if (mounted) {
                  setState(() {
                    isPathAvailable = true;
                  });
                }
                if (prefs.getString(UserPreference.ROLE_ID) == "1" &&
                    isAlreadyLoggedIn) {
                  if (profileInfoModal == null) profileApiChild(false);
                } else if (prefs.getString(UserPreference.ROLE_ID) == "2") {
                  if (profileInfoModal == null) profileApiParent(false);
                } else if (prefs.getString(UserPreference.ROLE_ID) == "4") {
                  if (companyModel == null) companyInfoApi(false);
                }
                shareUrlOption(value);
              }*/

        } else {
          print("Link1++++++++" + value);
          prefs.setString(UserPreference.LINK, value);
          navigationPage(true);
        }
      }
    }, onError: (err) {
      print("getLinkStream error: $err");
    });

    ReceiveSharingIntent.getInitialText().then((String value) async {
      if (value != null) {
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        print("value text2:- " + value);
        if (value != null &&
            value.contains("app.spikeview") &&
            !value.contains("I am sharing my")) {
          print("value text2:- " + value);
          if (value.contains("/sv/") || value.contains("cus")) {
            if (mounted) {
              setState(() {
                isPathAvailable = true;
              });
            }
          }
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
          isPathAvailable = true;
          preformLogin(value);
        } else {
          if (mounted) {
            setState(() {
              isPathAvailable = true;
            });
          }
          prefs = await SharedPreferences.getInstance();
          if (prefs.getBool("loginStatus") != null &&
              prefs.getBool("loginStatus")) {
            //if (Platform.isAndroid) {
            if (mounted) {
              if (mounted) {
                setState(() {
                  isPathAvailable = true;
                });
              }
              prefs.setString(UserPreference.LINK, value);
              navigationPage(true);
            } else {
              if (mounted) {
                setState(() {
                  isPathAvailable = true;
                });
              }
              if (prefs.getString(UserPreference.ROLE_ID) == "1" &&
                  isAlreadyLoggedIn) {
                if (profileInfoModal == null) profileApiChild(false);
              } else if (prefs.getString(UserPreference.ROLE_ID) == "2") {
                if (profileInfoModal == null) profileApiParent(false);
              } else if (prefs.getString(UserPreference.ROLE_ID) == "4") {
                if (companyModel == null) companyInfoApi(false);
              }
              shareUrlOption(value);
            }
            /* }else{
              if (mounted) {
                setState(() {
                  isPathAvailable = true;
                });
              }
              if (prefs.getString(UserPreference.ROLE_ID) == "1" &&
                  isAlreadyLoggedIn) {
                if (profileInfoModal == null) profileApiChild(false);
              } else if (prefs.getString(UserPreference.ROLE_ID) == "2") {
                if (profileInfoModal == null) profileApiParent(false);
              } else if (prefs.getString(UserPreference.ROLE_ID) == "4") {
                if (companyModel == null) companyInfoApi(false);
              }
              shareUrlOption(value);
            }*/
          } else {
            print("Link++++++++" + value);
            prefs.setString(UserPreference.LINK, value);
            navigationPage(true);
          }
        }
      }
    });

    GlobalSocketConnection.initSocket();
    getSharedPreferences();
    _intentDataStreamSubscription = ReceiveSharingIntent.getMediaStream()
        .listen((List<SharedMediaFile> value) {
      print("data call from media2");

      if (value.length > 0) {
        isPathAvailable = true;
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }

        imageList.addAll(value);

        /*       Navigator.pushReplacement(
            Constant.applicationContext,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>
                 FullIMageViewGallery(value)));*/

        addAchivmentOutsideTheApp(value);
      }
    }, onError: (err) {
      print("getIntentDataStream error: $err");
    });

    // For sharing images coming from outside the app while the app is closed
    ReceiveSharingIntent.getInitialMedia().then((List<SharedMediaFile> value) {
      print("data call from media");
      if (value != null && value.length > 0) {
        isPathAvailable = true;
        if (mounted) {
          setState(() {
            isPathAvailable = true;
          });
        }
        imageList.addAll(value);
        /*    Navigator.pushReplacement(
            Constant.applicationContext,
             MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>
                 FullIMageViewGallery(value)));*/

        addAchivmentOutsideTheApp(value);
      }
    });

    _firebaseMessaging.getToken().then((token) {
      print("tokenm" + token);
      prefs.setString("deviceId", token);
    });
    //startTime();
    //startTimeForAnimation();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    this.context = context;
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);
    return Scaffold(
      backgroundColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/login/splash.png"),
            fit: BoxFit.fill,
          ),
        ),
        child: Center(
          child: AnimatedOpacity(
            // If the Widget should be visible, animate to 1.0 (fully visible). If
            // the Widget should be hidden, animate to 0.0 (invisible).
            opacity: _visible ? 1.0 : 0.0,
            duration: Duration(milliseconds: 2000),
            // The green box needs to be the child of the AnimatedOpacity
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Container(
                        margin: const EdgeInsets.all(30.0),
                        child: Image(
                          image: AssetImage("assets/png/logo.png"),
                          color: null,
                          width: 200.0,
                          height: 50.0,
                          fit: BoxFit.contain,
                        )),
                    flex: 1,
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 30.0),
                      child: Container(
                          width: 200.0,
                          decoration: BoxDecoration(
                              border: Border.all(
                                color: ColorValues.BLUE_COLOR,
                              ),
                              color: Colors.white,
                              borderRadius:
                              BorderRadius.all(Radius.circular(20))),
                          child: LinearProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(
                                ColorValues.BLUE_COLOR),
                          )),
                    ),
                    flex: 0,
                  ),
                ]),
          ),
        ),
      ),
    );
  }

  Future onDidReceiveLocalNotification(
      int id, String title, String body, String payload) async {
    // display a dialog with the notification details, tap ok to go to another page
    print(
        "New Method Call here onDidReceiveLocalNotification---------------->> ");
  }

  getSharedPreferences() async {
    UserPreference.initSharedPreference();
    prefs = await SharedPreferences.getInstance();
    isConnect = await ConectionDetecter.isConnected();
    firebaseCloudMessaging_Listeners();
    isAlreadyLoggedIn = prefs.getBool("loginStatus");
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userEmail = prefs.getString(UserPreference.EMAIL);
    userName = prefs.getString(UserPreference.NAME);
    UserPreference.setIsUserReported(true);
    isPasswordChanged = prefs.getBool("isPasswordChanged");
    isProfileCreatedByParent = prefs.getBool("isProfileCreatedByParent");
    isParent = prefs.getBool("isParent");
    Constant.CURRENT_PAGE_NAME = "Main";

    try {
      String access_feedLike =
          prefs.getString(UserPreference.ACCESS_CONTROL_FEED);
      if (access_feedLike == null) {
        bloc.accessControlParam(prefs);
      }
    } catch (e) {
      bloc.accessControlParam(prefs);
    }
    if (isAlreadyLoggedIn == null) {
      isAlreadyLoggedIn = false;
    }

    if (userName == null) {
      userName = "";
    }

    GlobalSocketConnection.socket.onConnect((data) {
      print("=====connected...");
      addUser();
    });

    if (mounted) {
      setState(() {
        Constant.isAlreadyLoggedIn = isAlreadyLoggedIn;
        isAlreadyLoggedIn;
      });
    }
    //ToastWrap.showToast("response prefrence");
    isPasswordChanged = prefs.getBool("isPasswordChanged");
    isParent = prefs.getBool("isParent");
    prefs.setString("deviceId", "");
    if (isPasswordChanged == null) {
      isPasswordChanged = false;
    }
    if (isProfileCreatedByParent == null) {
      isProfileCreatedByParent = false;
    }
    if (isParent == null) {
      isParent = false;
    }

    print("Data call getshreprefrence++++++++++++++++++++++");
    try {
      if (prefs.getBool("loginStatus")) {
        if (isConnect) {
          print("Data call login++++++++++++++++++++++");
          // await apiCallLevelList();
          if (roleId == "1") {
            print("Data call 1++++++++++++++++++++++");
            await profileApiChild(false);
            if (prefs.getString(UserPreference.SCHOOL_CODE) != null &&
                prefs.getString(UserPreference.SCHOOL_CODE) != "null" &&
                prefs.getString(UserPreference.SCHOOL_CODE) != "") {
              bloc.apiCallForAcessControl(prefs, userIdPref, context);
            }

            bloc.chekUpdateStatus(userIdPref, context, prefs);
          } else if (roleId == "2") {
            print("Data call 2++++++++++++++++++++++");
            await profileApiParent(false);
          } else if (roleId == "4") {
            await companyInfoApi(false);
          }
          print("data is null++++++++++++++++++++++++++");
        }
      } else {}
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
    }

    if (!isPathAvailable) startTimeForAnimation();
  }

  Future shareIDData(shareId, type, isPublicProfile) async {
    try {
      print("profile shareId" + shareId);
      Response response;
      if (!isPublicProfile) {
        print('shareIDData if URL:: ${Constant.ENDPOINT_SHARE_ID + shareId}');
        response = await ApiCalling2()
            .apiCall4(context, Constant.ENDPOINT_SHARE_ID + shareId, "get");
      } else {
        print(
            'shareIDData else URL:: ${Constant.ENDPOINT_SHARE_ID + shareId + "&publickey=1"}');
        response = await ApiCalling2().apiCall4(
            context,
            Constant.ENDPOINT_SHARE_ID + shareId + "&publickey=1",
            "get"); //http://103.21.53.11:3001/ui/share/profile?sharedId=549&publickey=1
      }
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data['message'];
          print(response.toString());
          if (status == "Success") {
            shareProfileModal =
                ParseJson.parseShareProfile(response.data['result']);
            if (shareProfileModal.isActive == "true") {
              if (shareProfileModal.profileOwner != "") {
                print("profile status" + shareProfileModal.isActive);
                print("profile status" + shareProfileModal.isViewed);

                if (shareProfileModal.sharedView == "linear") {
                  Navigator.pushReplacement(
                      Constant.applicationContext,
                      MaterialPageRoute(
                          //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) => ShareProfilePage(
                              shareProfileModal.profileOwner,
                              false,
                              "shareProfile",
                              shareProfileModal,
                              type)));
                } else {
                  onTapPresoView(type);
                }
              }
            } else {
              ToastWrap.showToast("Your access on this profile has revoked.",
                  Constant.applicationContext);
            }
            return;
          } else {
            ToastWrap.showToast(message, Constant.applicationContext);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "main", context);
      e.toString();
      return;
    }
  }
}

Future<dynamic> myBackgroundMessageHandler(Map<String, dynamic> message) async {
  try {
    print("onMessage:+++background");
    ToastWrap.showToast("onClick working", Constant.applicationContext);
  } catch (e) {}

  // Or do other work.
}
/* <key>FIREBASE_ANALYTICS_COLLECTION_ENABLED</key>
    <string>NO</string>
    <key>FIREBASE_ANALYTICS_COLLECTION_DEACTIVATED</key>
    <string>YES</string>
    <key>FirebaseScreenReportingEnabled</key>
    <false/>*/
