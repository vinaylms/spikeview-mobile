import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/svg.dart';

import 'package:keyboard_actions/keyboard_actions.dart';

import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/PublicProfileFilter/CustomizeProfilePreViewWidget.dart';
import 'package:spike_view_project/PublicProfileFilter/custom_portfolio_details_view.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/PublicProfileDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomPresoViewForUser.dart';
import 'package:spike_view_project/TestScore/DocumentPerformance.dart';
import 'package:spike_view_project/accomplishment/portfolio/PortfolioViewWidget.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/component/CustomDropdownButtonNew.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/ScoreDataModel.dart';

import 'package:spike_view_project/modal/SkillBarModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart'
    as profile;
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/checked_container.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/disable_view.dart';
import 'package:spike_view_project/widgets/full_image_widget.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/read_more_text.dart';
import 'package:url_launcher/url_launcher.dart';

// Create a Form Widget
class CustomizeProfileFilterViewWidget extends StatefulWidget {
  List<double> spiderChartList = List<double>();
  List<String> spiderChartName = List<String>();
  List<SkillBarModel> barListModel = List();
  String dob, userId;
  final profile.ProfileData studentProfile;

  CustomizeProfileFilterViewWidget(
    this.spiderChartList,
    this.spiderChartName,
    this.barListModel,
    this.dob,
    this.userId, {
    this.studentProfile,
  });

  @override
  CustomizeProfileFilterViewWidgetState createState() {
    return CustomizeProfileFilterViewWidgetState(
        spiderChartList, spiderChartName, barListModel);
  }
}

class CustomizeProfileFilterViewWidgetState
    extends State<CustomizeProfileFilterViewWidget> {
  CustomizeProfileFilterViewWidgetState(
    this.spiderChartList,
    this.spiderChartName,
    this.barListModel,
  );

  TextEditingController dayController = TextEditingController(text: "");
  TextEditingController otherDayController = TextEditingController(text: "");
  SharedPreferences prefs;
  String userIdPref, roleId;
  PublicProfileDataModel _mPublicProfileDataModel;
  ScrollController _scrollController = ScrollController();
  UploadMedia uploadMedia;
  bool isShowAllTestScore = false;
  bool isViewAllBadges = false;
  AcoomplismentDataModel _mAcoomplismentDataModel;
  final PageController pageController = PageController();
  final dataKey0 = GlobalKey();
  List<double> spiderChartList = List<double>();
  List<String> spiderChartName = List<String>();
  List<SkillBarModel> barListModel = List();
  bool isSpiderChartApiCalled = true;
  bool isShowSummary = false;
  bool isShowAllRecommendation = false;
  bool isGPA = false;
  int counter = 120;
  bool isVideoPlay = false;
  bool isLinkExpire = true;
  bool isLinearView = true;
  bool isTabOne = true;
  bool isPresoView = false;
  bool isCollage = false;
  bool isSchool = false;

  StreamSubscription<dynamic> _streamSubscription;
  List<String> dayList = [
    "10",
    "20",
    "30",
    "60",
    "90",
    "Other",
  ].toList();

  Future getProfileDetail(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_PROFILE_DETAIL + userIdPref + "&roleId=" + roleId,
            "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS] == "Success") {
              Result.type = "custom";

              log("Pritam ++++ " + response.data.toString());
              _mPublicProfileDataModel =
                  PublicProfileDataModel.fromJson(response.data);
              try {
                _mPublicProfileDataModel.result.loveOtherInterests = List();

                if (_mPublicProfileDataModel.result.loveInterests != null &&
                    _mPublicProfileDataModel.result.loveInterests.length > 0)
                  _mPublicProfileDataModel.result.loveOtherInterests
                      .addAll(_mPublicProfileDataModel.result.loveInterests);
                if (_mPublicProfileDataModel.result.otherInterests != null &&
                    _mPublicProfileDataModel.result.otherInterests.length > 0)
                  _mPublicProfileDataModel.result.loveOtherInterests
                      .addAll(_mPublicProfileDataModel.result.otherInterests);
              } catch (e) {}
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("getProfileDetail_INFO++++" + e.toString());
    }
  }

  String strDay;
  FocusNode daySelectionFocusNode = FocusNode();

  Future getAccomplishment(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_ACCOMPLISHMENT_DETAIL + userIdPref, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("getAccomplishment++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS].toString() ==
                "Success") {
              Achievement.callingType = "custom";
              _mAcoomplismentDataModel =
                  AcoomplismentDataModel.fromJson(response.data, "");
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      print("getAccomplishment++++" + e.toString());
    }
  }

  String strDayList;
  bool isPresentationView = false;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    if (widget.studentProfile != null) {
      userIdPref = widget.studentProfile.userId;
      roleId = widget.studentProfile.roleId;
    } else {
      userIdPref = widget.userId;
      roleId = "1";
    }
    getProfileDetail(true);
    getAccomplishment(true);
  }

  @override
  void initState() {
    uploadMedia = UploadMedia(context);
    getSharedPreferences();
    _streamSubscription =
        VideoPlayPauseState.syncDoneController.stream.listen((value) {
      setState(() {
        isVideoPlay = false;
      });
    });

    super.initState();
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  Widget introductionViewUI() {
    String videoThumbnailUrl =
        _mPublicProfileDataModel?.result?.introVideo?.thumbnailUrl ?? '';
    String videoUrl =
        _mPublicProfileDataModel?.result?.introVideo?.videoUrl ?? '';

    return _mPublicProfileDataModel.result == null ||
            _mPublicProfileDataModel.result.introVideo == null ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == null ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == "null" ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == ""
        ? const SizedBox.shrink()
        : PaddingWrap.paddingfromLTRB(
            20.0,
            8.0,
            20.0,
            13.0,
            Container(
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: BaseText(
                          text: 'Introduction',
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w600,
                          fontSize: 18,
                          maxLines: 1,
                        ),
                      ),
                      const SizedBox(width: 12),
                      _hideShowButton(
                        value: _mPublicProfileDataModel.result.isIntroVideo,
                        onChange: (value) {
                          setState(() {
                            _mPublicProfileDataModel.result.isIntroVideo =
                                value;
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  DisableView(
                    isEnable: _mPublicProfileDataModel.result.isIntroVideo,
                    child: Container(
                      height: 200,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10)),
                      clipBehavior: Clip.antiAlias,
                      child: isVideoPlay ?? false
                          ? VideoPlayPause(
                              _mPublicProfileDataModel
                                  .result.introVideo.videoUrl,
                              "",
                              true,
                              pageName: "profile",
                            )
                          : Container(
                              color: Colors.black,
                              child: Stack(
                                children: [
                                  videoThumbnailUrl?.isNotEmpty ?? false
                                      ? CachedNetworkImage(
                                          height: 200,
                                          width: double.infinity,
                                          imageUrl: videoThumbnailUrl
                                                      .toLowerCase()
                                                      .contains("http") ||
                                                  videoThumbnailUrl
                                                      .toLowerCase()
                                                      .contains("www.")
                                              ? videoThumbnailUrl
                                              : "${Constant.IMAGE_PATH}$videoThumbnailUrl",
                                          fit: BoxFit.contain,
                                          placeholder: (context, url) =>
                                              Util.loader(context, ""),
                                          errorWidget: (context, url, error) =>
                                              Util.error(""),
                                        )
                                      : const SizedBox.shrink(),
                                  Center(
                                    child: InkWell(
                                      onTap: () {
                                        if (videoUrl
                                                .toLowerCase()
                                                .contains("http") ||
                                            videoUrl
                                                .toLowerCase()
                                                .contains("www.")) {
                                          if (videoUrl
                                              .toLowerCase()
                                              .contains("http")) {
                                            launch(videoUrl);
                                          } else {
                                            String url = "http://" + videoUrl;
                                            launch(url);
                                          }
                                        } else {
                                          setState(() {
                                            isVideoPlay = true;
                                          });
                                        }
                                      },
                                      child: Image.asset(
                                        'assets/ic_intro_play.png',
                                        height: 40,
                                        width: 40,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                    ),
                  )
                ],
              ),
            ),
          );
  }

  Padding summaryView() {
    return PaddingWrap.paddingfromLTRB(
      20.0,
      0.0,
      20.0,
      0.0,
      Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                color: ColorValues.LIST_BOTTOM_BG,
                borderRadius: new BorderRadius.only(
                    topLeft: const Radius.circular(10.0),
                    topRight: const Radius.circular(10.0)),
              ),
              child: Row(
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                      6.0,
                      10.0,
                      10.0,
                      10.0,
                      Image.asset(
                        "assets/newDesignIcon/icon/my_summary.png",
                        width: 35,
                        height: 35,
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      0.0,
                      10.0,
                      BaseText(
                        text: 'Summary',
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w600,
                        fontSize: 18,
                        maxLines: 1,
                      )),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: ColorValues.SELECTION_BG,
                borderRadius: new BorderRadius.only(
                    bottomLeft: const Radius.circular(10.0),
                    bottomRight: const Radius.circular(10.0)),
              ),
              child: PaddingWrap.paddingfromLTRB(
                  17.0,
                  12.0,
                  17.0,
                  12.0,
                  Text(
                      _mPublicProfileDataModel.result == null ||
                              _mPublicProfileDataModel.result.summary == null ||
                              _mPublicProfileDataModel.result.summary == "null"
                          ? "No Information Available"
                          : _mPublicProfileDataModel.result.summary,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 100,
                      style: TextStyle(
                          fontFamily: Constant.latoMedium,
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontWeight: FontWeight.w500,
                          fontSize: 16.0))),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hideShowButton({
    @required bool value,
    @required Function(bool value) onChange,
  }) {
    return value
        ? GestureDetector(
            onHorizontalDragEnd: (details) => onChange(false),
            onTap: () => onChange(false),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Transform.translate(
                  offset: const Offset(0, -2),
                  child: BaseText(
                    text: 'Show',
                    textColor: AppConstants.colorStyle.darkBlue,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                  ),
                ),
                const SizedBox(width: 6),
                Image.asset(
                  "assets/newDesignIcon/icon/active.png",
                  width: 32,
                  height: 16,
                ),
              ],
            ),
          )
        : GestureDetector(
            onHorizontalDragEnd: (details) => onChange(true),
            onTap: () => onChange(true),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Transform.translate(
                  offset: const Offset(0, -2),
                  child: BaseText(
                    text: 'Show',
                    textColor: AppConstants.colorStyle.darkBlue,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                  ),
                ),
                const SizedBox(width: 6),
                Image.asset(
                  "assets/newDesignIcon/icon/inactive.png",
                  width: 32,
                  height: 16,
                ),
              ],
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    final expiringDay = Container(
        padding: const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: CustomFormField(
          autovalidateMode: AutovalidateMode.disabled,
          textInputType: TextInputType.number,
          controller: otherDayController,
          focusNode: daySelectionFocusNode,
          maxLength: 3,
          onType: (val) {
            setState(() {});
          },
          label: 'Enter days',
        ));

    selectType() {
      return PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        0.0,
        0.0,
        Container(
            child: Container(
                child: Column(
          children: [
            PaddingWrap.paddingfromLTRB(
                20.0,
                24.0,
                20.0,
                4.0,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        BaseText(
                          text: 'Link expiration (days):',
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                          maxLines: 1,
                        )),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        15.0,
                        BaseText(
                          text:
                              'Set how long you want your link to be accessible once you share it. After that it will expire.',
                          textColor: ColorValues.labelColor,
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w400,
                          fontSize: 14,
                          maxLines: 3,
                        )),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        isLinkExpire
                            ? Expanded(
                                child: InkWell(
                                  child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 0.0),
                                      child: Image.asset(
                                        "assets/newDesignIcon/icon/checked_box.png",
                                        height: 22.0,
                                        width: 22.0,
                                      )),
                                  onTap: () {
                                    setState(() {
                                      isLinkExpire = false;
                                    });
                                  },
                                ),
                                flex: 0)
                            : Expanded(
                                child: Padding(
                                    padding:
                                        EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                    child: InkWell(
                                      child: Image.asset(
                                        "assets/newDesignIcon/icon/uncheked_box.png",
                                        height: 22.0,
                                        width: 22.0,
                                      ),
                                      onTap: () {
                                        setState(() {
                                          strDay = null;
                                          strDayList = null;
                                          isLinkExpire = true;
                                        });
                                      },
                                    )),
                                flex: 0),
                        Expanded(
                            child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(12.0, 0.0, 0.0, 0.0),
                                child: BaseText(
                                  text: 'Don\'t expire link',
                                  textColor:
                                      ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  maxLines: 1,
                                )),
                            flex: 1)
                      ],
                    ),
                  ],
                )),
            PaddingWrap.paddingfromLTRB(
                20.0,
                20.0,
                20.0,
                0.0,
                Stack(
                  children: [
                    CustomDropdownButtonFormFieldNew(
                      icon: Image.asset(
                        'assets/recommendation/ic_arrow_down.png',
                        height: 24,
                        width: 24,
                      ),
                      items: dayList
                          .map((item) => CustomDropdownMenuItem<String>(
                              value: item,
                              child: Text(
                                item,
                                style: AppConstants.txtStyle.txtStyleTextForm,
                              )))
                          .toList(),
                      onChanged: (s) {
                        setState(() {
                          FocusScope.of(context).requestFocus(new FocusNode());
                          strDayList = s;
                          strDay = s;
                        });
                      },
                      value: strDay,
                      labelText: 'Select expire link (Days)',
                      //decoration: _dropdownDeco('Select expire link (Days)'),
                    ),
                    isLinkExpire
                        ? Container(
                            color: Colors.white.withOpacity(.4),
                            height: 50.0,
                          )
                        : const SizedBox.shrink()
                  ],
                )),
            strDay == "Other"
                ? PaddingWrap.paddingfromLTRB(
                    20.0, 20.0, 20.0, 0.0, expiringDay)
                : Container(height: 0.0),
          ],
        ))),
      );
    }

    final bottomBar = BottomAppBar(
      elevation: 15.0,
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border(
              top: BorderSide(color: ColorValues.BORDER_COLOR, width: 0.5),
            )),
        height: 90,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          child: Row(
            children: [
              Expanded(
                flex: 2,
                child: InkWell(
                  child: Container(
                    height: 45,
                    padding: EdgeInsets.symmetric(vertical: 11),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: ColorValues.WHITE,
                      border: Border.all(color: Color(0xffB2BDDB)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "Cancel",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: AppConstants.colorStyle.lightPurple,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  onTap: () async {
                    Navigator.pop(context, "push");
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 3,
                child: Stack(
                  children: [
                    InkWell(
                      child: Container(
                        height: 45,
                        padding: EdgeInsets.symmetric(vertical: 11),
                        decoration: BoxDecoration(
                          color: AppConstants.colorStyle.lightBlue,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          isTabOne ? 'Proceed' : "Preview & Share",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: ColorValues.WHITE,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontSize: 18,
                          ),
                        ),
                      ),
                      onTap: () {
                        if (isTabOne) {
                          setState(() {
                            isTabOne = false;
                          });
                        } else {
                          if (!isLinkExpire) {
                            if (strDay == null || strDay == "") {
                              ToastWrap.showToast(
                                  "Please select expire link(Days).", context);
                            } else if (strDay == "Other" &&
                                (otherDayController.text.trim().length == 0)) {
                              ToastWrap.showToast(
                                  "Please enter expire day.", context);
                            } else if (strDay == "Other" &&
                                (otherDayController.text.trim().contains(".") ||
                                    otherDayController.text
                                        .trim()
                                        .contains("-") ||
                                    otherDayController.text == "0")) {
                              ToastWrap.showToast("Invalid entry", context);
                            } else {
                              apiCalling();
                            }
                          } else {
                            apiCalling();
                          }
                        }
                      },
                    ),
                    (!isLinkExpire && strDay == null) ||
                            isTabOne &&
                                strDay == "Other" &&
                                otherDayController.text.trim().length == 0
                        ? Container(
                            color: Colors.white.withOpacity(.4),
                            height: 50.0,
                          )
                        : SizedBox(
                            height: 0.0,
                          )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );

    return Scaffold(
      bottomNavigationBar: bottomBar,
      backgroundColor: ColorValues.WHITE,
      body: SafeArea(
        child: FormKeyboardActions(
          nextFocus: false,
          keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
          //optional
          keyboardBarColor: Colors.grey[200],
          //optional
          actions: [
            KeyboardAction(
              focusNode: daySelectionFocusNode,
            ),
          ],
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 20.0, right: 20, top: 24, bottom: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        BaseText(
                          text: 'Customized share',
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w700,
                          fontSize: 28,
                          maxLines: 1,
                        ),
                        const HelpButtonWidget(),
                      ],
                    ),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        4.0,
                        0.0,
                        0.0,
                        BaseText(
                          text: 'Customize profile for share:',
                          textColor: ColorValues.labelColor,
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w400,
                          fontSize: 16,
                          maxLines: 1,
                        )),
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  color: AppConstants.colorStyle.white,
                  child: ListView(
                    controller: _scrollController,
                    children: [
                      PaddingWrap.paddingfromLTRB(
                        20.0,
                        0.0,
                        20.0,
                        24.0,
                        Row(
                          children: [
                            Expanded(
                              child: InkWell(
                                child: Container(
                                  margin: EdgeInsets.only(right: 1),
                                  padding: EdgeInsets.only(
                                      top: 2, bottom: 2, left: 0, right: 0),
                                  decoration: BoxDecoration(
                                    color: isTabOne
                                        ? ColorValues.DARK_YELLOW
                                        : AppConstants.colorStyle.tabBg,
                                    border: Border.all(
                                        color: isTabOne
                                            ? ColorValues.DARK_YELLOW
                                            : AppConstants.colorStyle
                                                .borderGenerateScript),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(10)),
                                  ),
                                ),
                                onTap: () {
                                  setState(() {
                                    //   isTabOne = true;
                                  });
                                },
                              ),
                            ),
                            Expanded(
                              child: InkWell(
                                child: Container(
                                  margin: EdgeInsets.only(left: 1),
                                  padding: EdgeInsets.only(
                                      top: 2, bottom: 2, left: 0, right: 0),
                                  decoration: BoxDecoration(
                                    color: !isTabOne
                                        ? ColorValues.DARK_YELLOW
                                        : AppConstants.colorStyle.tabBg,
                                    border: Border.all(
                                        color: AppConstants
                                            .colorStyle.borderGenerateScript),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(10)),
                                  ),
                                ),
                                onTap: () {
                                  setState(() {
                                    // isTabOne = false;
                                  });
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      isTabOne
                          ? Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                PaddingWrap.paddingfromLTRB(
                                    20.0,
                                    0.0,
                                    20.0,
                                    0.0,
                                    BaseText(
                                      text:
                                          'Select the view of your profile you want to share',
                                      textColor:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 16,
                                      maxLines: 2,
                                    )),
                                PaddingWrap.paddingfromLTRB(
                                    20.0,
                                    4.0,
                                    20.0,
                                    0.0,
                                    BaseText(
                                      text:
                                          'Following two views are supported.',
                                      textColor: ColorValues.labelColor,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      maxLines: 1,
                                    )),
                                PaddingWrap.paddingfromLTRB(
                                  20.0,
                                  24.0,
                                  20.0,
                                  0.0,
                                  Row(
                                    children: [
                                      Expanded(
                                        child: InkWell(
                                          child: Container(
                                            //width: MediaQuery.of(context).size.width*0.45,
                                            child: Text(
                                              'Linear view',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: !isPresentationView
                                                    ? ColorValues.WHITE
                                                    : AppConstants
                                                        .colorStyle.darkBlue,
                                                fontSize: 15,
                                                fontWeight: FontWeight.w400,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoRegular,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: !isPresentationView
                                                  ? ColorValues.DARK_YELLOW
                                                  : AppConstants
                                                      .colorStyle.tabBg,
                                              border: Border.all(
                                                  color: !isPresentationView
                                                      ? ColorValues.DARK_YELLOW
                                                      : AppConstants.colorStyle
                                                          .borderGenerateScript),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                      topLeft:
                                                          Radius.circular(10),
                                                      bottomLeft:
                                                          Radius.circular(10)),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              isLinearView = true;
                                              isPresoView = false;
                                              isPresentationView = false;
                                            });
                                          },
                                        ),
                                      ),
                                      Expanded(
                                        child: InkWell(
                                          child: Container(
                                            //width: MediaQuery.of(context).size.width*0.45,
                                            child: Text(
                                              'Presentation view',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: isPresentationView
                                                    ? ColorValues.WHITE
                                                    : AppConstants
                                                        .colorStyle.darkBlue,
                                                fontSize: 15,
                                                fontWeight: FontWeight.w400,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoRegular,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: isPresentationView
                                                  ? ColorValues.DARK_YELLOW
                                                  : AppConstants
                                                      .colorStyle.tabBg,
                                              border: Border.all(
                                                  color: isPresentationView
                                                      ? ColorValues.DARK_YELLOW
                                                      : AppConstants
                                                          .colorStyle.tabBg),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(10),
                                                      bottomRight:
                                                          Radius.circular(10)),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              isLinearView = false;
                                              isPresoView = true;
                                              isPresentationView = true;
                                            });
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                PaddingWrap.paddingfromLTRB(
                                    20.0,
                                    8.0,
                                    20.0,
                                    0.0,
                                    BaseText(
                                      text: isPresentationView
                                          ? 'Your profile will be seen as a presentation by the viewers.'
                                          : 'Your profile will be vertically scrollable by viewers.',
                                      textColor: ColorValues.labelColor,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      maxLines: 2,
                                    )),
                                selectType(),
                              ],
                            )
                          : SizedBox(),
                      isTabOne
                          ? SizedBox()
                          : _mPublicProfileDataModel == null ||
                                  _mPublicProfileDataModel.result == null
                              ? Container(
                                  height: 0.0,
                                )
                              : Column(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        20.0,
                                        0.0,
                                        20.0,
                                        15.0,
                                        BaseText(
                                          text:
                                              'Use the toggles below and customize the view of the profile you want to share. Create unlimited customer views to share.',
                                          textColor: ColorValues.labelColor,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14,
                                        )),
                                    introductionViewUI(),
                                    _mPublicProfileDataModel.result == null ||
                                            _mPublicProfileDataModel.result.summary ==
                                                null ||
                                            _mPublicProfileDataModel
                                                    .result.summary
                                                    .trim() ==
                                                "" ||
                                            _mPublicProfileDataModel
                                                    .result.summary ==
                                                "null"
                                        ? const SizedBox.shrink()
                                        : summaryView(),
                                    _mPublicProfileDataModel
                                                    .result.educations ==
                                                null ||
                                            _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .colleges
                                                        .length +
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .schools
                                                        .length ==
                                                0
                                        ? const SizedBox.shrink()
                                        : Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                20, 24, 20, 0),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: ColorValues
                                                        .LIST_BOTTOM_BG,
                                                    borderRadius: new BorderRadius
                                                            .only(
                                                        topLeft: const Radius
                                                            .circular(10.0),
                                                        topRight: const Radius
                                                            .circular(10.0)),
                                                  ),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              6.0,
                                                              10.0,
                                                              10.0,
                                                              10.0,
                                                              Image.asset(
                                                                "assets/png/education.png",
                                                                width: 35,
                                                                height: 35,
                                                              )),
                                                      Expanded(
                                                        child: BaseText(
                                                          text: 'Education',
                                                          textColor: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize: 18,
                                                          maxLines: 1,
                                                        ),
                                                      ),
                                                      _hideShowButton(
                                                        value:
                                                            _mPublicProfileDataModel
                                                                .result
                                                                .isEducations,
                                                        onChange: (value) {
                                                          setToggel(
                                                              _mPublicProfileDataModel
                                                                  .result
                                                                  .educations
                                                                  .colleges,
                                                              value);
                                                          setState(() {
                                                            _mPublicProfileDataModel
                                                                    .result
                                                                    .isEducations =
                                                                value;
                                                          });
                                                        },
                                                      ),
                                                      const SizedBox(width: 12),
                                                    ],
                                                  ),
                                                ),
                                                DisableView(
                                                  isEnable:
                                                      _mPublicProfileDataModel
                                                          .result.isEducations,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .SELECTION_BG,
                                                      borderRadius: new BorderRadius
                                                              .only(
                                                          bottomLeft:
                                                              const Radius
                                                                      .circular(
                                                                  10.0),
                                                          bottomRight:
                                                              const Radius
                                                                      .circular(
                                                                  10.0)),
                                                    ),
                                                    child: Column(
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  10,
                                                                  0,
                                                                  0),
                                                          child: Row(
                                                            children: [
                                                              isGPA
                                                                  ? Expanded(
                                                                      child: InkWell(
                                                                          onTap: () {
                                                                            setState(() {
                                                                              isGPA = false;
                                                                            });
                                                                          },
                                                                          child: Padding(
                                                                              padding: EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 0.0),
                                                                              child: Image.asset(
                                                                                "assets/newDesignIcon/icon/checked_box.png",
                                                                                height: 22.0,
                                                                                width: 22.0,
                                                                              ))),
                                                                      flex: 0)
                                                                  : Expanded(
                                                                      child: InkWell(
                                                                        child: Padding(
                                                                            padding: EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 0.0),
                                                                            child: Image.asset(
                                                                              "assets/newDesignIcon/icon/uncheked_box.png",
                                                                              height: 22.0,
                                                                              width: 22.0,
                                                                            )),
                                                                        onTap:
                                                                            () {
                                                                          setState(
                                                                              () {
                                                                            isGPA =
                                                                                true;
                                                                          });
                                                                        },
                                                                      ),
                                                                      flex: 0),
                                                              Expanded(
                                                                  flex: 1,
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          BaseText(
                                                                            text:
                                                                                'Show GPA with my education',
                                                                            textColor:
                                                                                ColorValues.call_now_color,
                                                                            fontFamily:
                                                                                AppConstants.stringConstant.latoMedium,
                                                                            fontWeight:
                                                                                FontWeight.w400,
                                                                            textAlign:
                                                                                TextAlign.start,
                                                                            fontSize:
                                                                                14,
                                                                            maxLines:
                                                                                2,
                                                                          )))
                                                            ],
                                                          ),
                                                        ),
                                                        _mPublicProfileDataModel
                                                                        .result
                                                                        .educations
                                                                        .schools !=
                                                                    null &&
                                                                _mPublicProfileDataModel
                                                                        .result
                                                                        .educations
                                                                        .schools
                                                                        .length >
                                                                    0
                                                            ? Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: List.generate(
                                                                    _mPublicProfileDataModel
                                                                        .result
                                                                        .educations
                                                                        .schools
                                                                        .length,
                                                                    (int
                                                                        index) {
                                                                  return getSchoolEducationListItem22(
                                                                      index);
                                                                }))
                                                            : const SizedBox
                                                                .shrink(),
                                                        _mPublicProfileDataModel
                                                                        .result
                                                                        .educations
                                                                        .colleges !=
                                                                    null &&
                                                                _mPublicProfileDataModel
                                                                        .result
                                                                        .educations
                                                                        .colleges
                                                                        .length >
                                                                    0
                                                            ? Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: List.generate(
                                                                    _mPublicProfileDataModel
                                                                        .result
                                                                        .educations
                                                                        .colleges
                                                                        .length,
                                                                    (int
                                                                        index) {
                                                                  return getCollegeEducationListItem22(
                                                                      index);
                                                                }),
                                                              )
                                                            : const SizedBox
                                                                .shrink(),
                                                        _mPublicProfileDataModel
                                                                    .result
                                                                    .educations ==
                                                                null
                                                            ? SizedBox()
                                                            : Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .all(
                                                                        12.0),
                                                                child: InkWell(
                                                                  onTap: () {
                                                                    Util.onTapViewTimeLine(
                                                                        context,'custom');
                                                                  },
                                                                  child: Center(
                                                                    child:
                                                                        BaseText(
                                                                      text:
                                                                          'View timeline',
                                                                      textColor:
                                                                          Color(
                                                                              0xff4684EB),
                                                                      fontFamily: AppConstants
                                                                          .stringConstant
                                                                          .latoRegular,
                                                                      fontSize:
                                                                          16,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      maxLines:
                                                                          1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                      ],
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                    _mPublicProfileDataModel
                                                    .result.testScores ==
                                                null ||
                                            _mPublicProfileDataModel
                                                    .result.testScores.length ==
                                                0
                                        ? const SizedBox.shrink()
                                        : PaddingWrap.paddingfromLTRB(
                                            20.0,
                                            24.0,
                                            20.0,
                                            0.0,
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: ColorValues
                                                        .LIST_BOTTOM_BG,
                                                    borderRadius: new BorderRadius
                                                            .only(
                                                        topLeft: const Radius
                                                            .circular(10.0),
                                                        topRight: const Radius
                                                            .circular(10.0)),
                                                  ),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              6.0,
                                                              10.0,
                                                              10.0,
                                                              10.0,
                                                              Image.asset(
                                                                "assets/newDesignIcon/icon/test_score.png",
                                                                width: 35,
                                                                height: 35,
                                                              )),
                                                      Expanded(
                                                        child: BaseText(
                                                          text: 'Test score',
                                                          textColor: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize: 18,
                                                          maxLines: 1,
                                                        ),
                                                      ),
                                                      const SizedBox(width: 12),
                                                      _hideShowButton(
                                                        value:
                                                            _mPublicProfileDataModel
                                                                .result
                                                                .isTestScore,
                                                        onChange: (value) {
                                                          _mPublicProfileDataModel
                                                                  .result
                                                                  .isTestScore =
                                                              value;
                                                          setToggeltestScore(
                                                              value);
                                                          setState(() {});
                                                        },
                                                      ),
                                                      const SizedBox(width: 12),
                                                    ],
                                                  ),
                                                ),
                                                DisableView(
                                                  isEnable:
                                                      _mPublicProfileDataModel
                                                          .result.isTestScore,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .SELECTION_BG,
                                                      borderRadius: new BorderRadius
                                                              .only(
                                                          bottomLeft:
                                                              const Radius
                                                                      .circular(
                                                                  10.0),
                                                          bottomRight:
                                                              const Radius
                                                                      .circular(
                                                                  10.0)),
                                                    ),
                                                    child: Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          0.0, 12, 0, 12),
                                                      child: Column(
                                                        children: <Widget>[
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  12.0,
                                                                  0.0,
                                                                  12.0,
                                                                  0.0,
                                                                  BaseText(
                                                                    text:
                                                                        "Your test scores remain private and are not visible to any of you connections. If you want to share them, please select them during the ‘Filter’ step.",
                                                                    textColor:
                                                                        ColorValues
                                                                            .HEADING_COLOR_EDUCATION_1,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoRegular,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                    fontSize:
                                                                        12,
                                                                  )),
                                                          Column(
                                                            children:
                                                                List.generate(
                                                                    _mPublicProfileDataModel.result.testScores.length >
                                                                            2
                                                                        ? isShowAllTestScore
                                                                            ? _mPublicProfileDataModel
                                                                                .result.testScores.length
                                                                            : 2
                                                                        : _mPublicProfileDataModel
                                                                            .result
                                                                            .testScores
                                                                            .length,
                                                                    (int
                                                                        index) {
                                                              return getTestScoreListItem(
                                                                  index);
                                                            }),
                                                          ),
                                                          _mPublicProfileDataModel
                                                                      .result
                                                                      .testScores
                                                                      .length >
                                                                  2
                                                              ? PaddingWrap
                                                                  .paddingfromLTRB(
                                                                  5.0,
                                                                  12.0,
                                                                  5.0,
                                                                  6.0,
                                                                  Center(
                                                                    child:
                                                                        Container(
                                                                      decoration: BoxDecoration(
                                                                          borderRadius: BorderRadius.circular(
                                                                              10),
                                                                          border:
                                                                              Border.all(color: ColorValues.BLUE_COLOR_BOTTOMBAR)),
                                                                      height:
                                                                          30.0,
                                                                      width: isShowAllTestScore
                                                                          ? 120.0
                                                                          : 90,
                                                                      child: FlatButton(
                                                                          onPressed: () {
                                                                            if (isShowAllTestScore) {
                                                                              isShowAllTestScore = false;
                                                                            } else {
                                                                              isShowAllTestScore = true;
                                                                            }
                                                                            setState(() {});
                                                                          },
                                                                          child: Text(isShowAllTestScore ? "View less" : "View all", textAlign: TextAlign.center, style: TextStyle(color: ColorValues.BLUE_COLOR_BOTTOMBAR, fontFamily: Constant.TYPE_CUSTOMREGULAR, fontSize: 14.0))),
                                                                    ),
                                                                  ),
                                                                )
                                                              : const SizedBox
                                                                  .shrink(),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                    _mAcoomplismentDataModel == null ||
                                            _mAcoomplismentDataModel
                                                    .accomplimentData.length ==
                                                0
                                        ? const SizedBox.shrink()
                                        : PaddingWrap.paddingfromLTRB(
                                            20.0,
                                            24.0,
                                            20.0,
                                            0.0,
                                            Column(
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: ColorValues
                                                        .LIST_BOTTOM_BG,
                                                    borderRadius:
                                                        new BorderRadius.all(
                                                            const Radius
                                                                    .circular(
                                                                10.0)),
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              6.0,
                                                              10.0,
                                                              10.0,
                                                              10.0,
                                                              Image.asset(
                                                                "assets/experience/ic_experience.png",
                                                                width: 35,
                                                                height: 35,
                                                              )),
                                                      Expanded(
                                                          child: BaseText(
                                                        text: 'Experiences',
                                                        textColor: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontFamily: AppConstants
                                                            .stringConstant
                                                            .latoMedium,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 18,
                                                        maxLines: 1,
                                                      )),
                                                      _hideShowButton(
                                                        value:
                                                            _mPublicProfileDataModel
                                                                .result
                                                                .isAccomplishment,
                                                        onChange: (value) {
                                                          setState(() {
                                                            _mPublicProfileDataModel
                                                                    .result
                                                                    .isAccomplishment =
                                                                value;
                                                            setToggelAccomplishment(
                                                                value);
                                                          });
                                                        },
                                                      ),
                                                      const SizedBox(width: 12),
                                                    ],
                                                  ),
                                                ),
                                                DisableView(
                                                  isEnable:
                                                      _mPublicProfileDataModel
                                                          .result
                                                          .isAccomplishment,
                                                  child: ListView.separated(
                                                    itemBuilder: (_, index) =>
                                                        _storyItem(
                                                            _mAcoomplismentDataModel
                                                                    .accomplimentData[
                                                                index],
                                                            index),
                                                    separatorBuilder:
                                                        (_, index) =>
                                                            const SizedBox(
                                                                height: 24),
                                                    itemCount:
                                                        _mAcoomplismentDataModel
                                                                .accomplimentData
                                                                ?.length ??
                                                            0,
                                                    shrinkWrap: true,
                                                    padding: const EdgeInsets
                                                            .symmetric(
                                                        vertical: 24),
                                                    physics:
                                                        const NeverScrollableScrollPhysics(),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                    _mPublicProfileDataModel.result
                                                    .loveInterests.length >
                                                0 ||
                                            _mPublicProfileDataModel.result
                                                    .goalInterests.length >
                                                0
                                        ? getUserInterestAndGoals()
                                        : const SizedBox.shrink(),
                                    _mPublicProfileDataModel
                                                    .result.skills.length ==
                                                0 &&
                                            _mPublicProfileDataModel.result
                                                    .certificates.length ==
                                                0
                                        ? const SizedBox.shrink()
                                        : skillView(),
                                    _mPublicProfileDataModel
                                                    .result.badges ==
                                                null ||
                                            _mPublicProfileDataModel
                                                    .result
                                                    .badges
                                                    .collections
                                                    .length ==
                                                0 ||
                                            (_mPublicProfileDataModel
                                                    .result
                                                    .badges
                                                    .collections
                                                    .length ==
                                                0)
                                        ? const SizedBox.shrink()
                                        : Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                20, 24, 20, 0),
                                            child: Container(
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Container(
                                                    decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .LIST_BOTTOM_BG,
                                                      borderRadius: new BorderRadius
                                                              .only(
                                                          topLeft: const Radius
                                                              .circular(10.0),
                                                          topRight: const Radius
                                                              .circular(10.0)),
                                                    ),
                                                    child: Row(
                                                      children: [
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                                6.0,
                                                                10.0,
                                                                10.0,
                                                                10.0,
                                                                Image.asset(
                                                                  "assets/newDesignIcon/icon/badges_icon.png",
                                                                  width: 35,
                                                                  height: 35,
                                                                )),
                                                        Expanded(
                                                          child: BaseText(
                                                            text: 'Badges',
                                                            textColor: ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontFamily:
                                                                AppConstants
                                                                    .stringConstant
                                                                    .latoMedium,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            fontSize: 18,
                                                            maxLines: 1,
                                                          ),
                                                        ),
                                                        _hideShowButton(
                                                            value:
                                                                _mPublicProfileDataModel
                                                                    .result
                                                                    .isBadges,
                                                            onChange: (value) {
                                                              setState(() {
                                                                setToggel(
                                                                    _mPublicProfileDataModel
                                                                        .result
                                                                        .badges
                                                                        .collections,
                                                                    value);

                                                                _mPublicProfileDataModel
                                                                        .result
                                                                        .isBadges =
                                                                    value;
                                                              });
                                                            }),
                                                        const SizedBox(
                                                            width: 12),
                                                      ],
                                                    ),
                                                  ),
                                                  DisableView(
                                                    isEnable:
                                                        _mPublicProfileDataModel
                                                            .result.isBadges,
                                                    child: badgeList2(),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                    _mPublicProfileDataModel.result == null ||
                                            _mPublicProfileDataModel
                                                    .result.recommendations ==
                                                null ||
                                            _mPublicProfileDataModel.result
                                                    .recommendations.length ==
                                                0
                                        ? const SizedBox.shrink()
                                        : getRecommendation(),
                                    (!dobCheck(widget.dob))
                                        ? const SizedBox.shrink()
                                        : PaddingWrap.paddingfromLTRB(
                                            20.0,
                                            24.0,
                                            20.0,
                                            0.0,
                                            Container(
                                                child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: ColorValues
                                                        .LIST_BOTTOM_BG,
                                                    borderRadius: new BorderRadius
                                                            .only(
                                                        topLeft: const Radius
                                                            .circular(10.0),
                                                        topRight: const Radius
                                                            .circular(10.0)),
                                                  ),
                                                  child: Row(
                                                    children: <Widget>[
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              6.0,
                                                              10.0,
                                                              10.0,
                                                              10.0,
                                                              Image.asset(
                                                                "assets/newDesignIcon/icon/my_contact_info.png",
                                                                width: 35,
                                                                height: 35,
                                                              )),
                                                      Expanded(
                                                        child: BaseText(
                                                          text:
                                                              'Contact information',
                                                          textColor: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize: 18,
                                                          maxLines: 1,
                                                        ),
                                                      ),
                                                      _hideShowButton(
                                                          value: _mPublicProfileDataModel
                                                              .result
                                                              .isDisplaySocialEmail,
                                                          onChange: (value) {
                                                            if (value) {
                                                              /* conformationDialog(
                                                         "Your connections will be able to see your Contact Info. Uncheck to hide from profile.",
                                                         context);*/
                                                            }
                                                            setState(() {
                                                              _mPublicProfileDataModel
                                                                      .result
                                                                      .isDisplaySocialEmail =
                                                                  value;
                                                            });
                                                          }),
                                                      const SizedBox(width: 12),
                                                    ],
                                                  ),
                                                ),
                                                DisableView(
                                                  isEnable:
                                                      _mPublicProfileDataModel
                                                          .result
                                                          .isDisplaySocialEmail,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .SELECTION_BG,
                                                      borderRadius: new BorderRadius
                                                              .only(
                                                          bottomLeft:
                                                              const Radius
                                                                      .circular(
                                                                  10.0),
                                                          bottomRight:
                                                              const Radius
                                                                      .circular(
                                                                  10.0)),
                                                    ),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  12.0,
                                                                  0,
                                                                  13,
                                                                  13),
                                                          child: Container(
                                                            child: Row(
                                                              children: [
                                                                Expanded(
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Image
                                                                              .asset(
                                                                            "assets/newDesignIcon/userprofile/Mail.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                  flex: 0,
                                                                ),
                                                                Expanded(
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          10.0,
                                                                          10.0,
                                                                          0.0,
                                                                          10.0,
                                                                          BaseText(
                                                                            text:
                                                                                _mPublicProfileDataModel.result.email,
                                                                            textColor:
                                                                                ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                            fontFamily:
                                                                                AppConstants.stringConstant.latoMedium,
                                                                            fontWeight:
                                                                                FontWeight.w400,
                                                                            fontSize:
                                                                                16,
                                                                            maxLines:
                                                                                1,
                                                                          )),
                                                                  flex: 1,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ))),
                                    _mPublicProfileDataModel.result == null ||
                                            _mPublicProfileDataModel
                                                    .result.socialLinks ==
                                                null ||
                                            _mPublicProfileDataModel.result
                                                    .socialLinks.length ==
                                                0
                                        ? const SizedBox.shrink()
                                        : PaddingWrap.paddingfromLTRB(
                                            20.0,
                                            24.0,
                                            20.0,
                                            0.0,
                                            Container(
                                                child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: ColorValues
                                                        .LIST_BOTTOM_BG,
                                                    borderRadius: new BorderRadius
                                                            .only(
                                                        topLeft: const Radius
                                                            .circular(10.0),
                                                        topRight: const Radius
                                                            .circular(10.0)),
                                                  ),
                                                  child: Row(
                                                    children: <Widget>[
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              6.0,
                                                              10.0,
                                                              10.0,
                                                              10.0,
                                                              Image.asset(
                                                                "assets/newDesignIcon/icon/social_links.png",
                                                                width: 35,
                                                                height: 35,
                                                              )),
                                                      Expanded(
                                                        child: BaseText(
                                                          text:
                                                              'Social links',
                                                          textColor: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize: 18,
                                                          maxLines: 1,
                                                        ),
                                                      ),
                                                      _hideShowButton(
                                                          value:
                                                              _mPublicProfileDataModel
                                                                  .result
                                                                  .isSocialLinks,
                                                          onChange: (value) {
                                                            setState(() {
                                                              _mPublicProfileDataModel
                                                                      .result
                                                                      .isSocialLinks =
                                                                  value;
                                                              setToggel(
                                                                  _mPublicProfileDataModel
                                                                      .result
                                                                      .socialLinks,
                                                                  value);
                                                            });
                                                          }),
                                                      const SizedBox(width: 12),
                                                    ],
                                                  ),
                                                ),
                                                DisableView(
                                                  isEnable:
                                                      _mPublicProfileDataModel
                                                          .result.isSocialLinks,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .SELECTION_BG,
                                                      borderRadius: new BorderRadius
                                                              .only(
                                                          bottomLeft:
                                                              const Radius
                                                                      .circular(
                                                                  10.0),
                                                          bottomRight:
                                                              const Radius
                                                                      .circular(
                                                                  10.0)),
                                                    ),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: List.generate(
                                                          _mPublicProfileDataModel
                                                              .result
                                                              .socialLinks
                                                              .length,
                                                          (int index) {
                                                        return Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0, 7, 0, 7),
                                                          child: Row(
                                                            children: [
                                                              _mPublicProfileDataModel
                                                                      .result
                                                                      .socialLinks[
                                                                          index]
                                                                      .isProfileDisplay
                                                                  ? Expanded(
                                                                      child: InkWell(
                                                                          onTap: () {
                                                                            setState(() {
                                                                              _mPublicProfileDataModel.result.socialLinks[index].isProfileDisplay = false;
                                                                              updateSocialToggel();
                                                                            });
                                                                          },
                                                                          child: Padding(
                                                                              padding: EdgeInsets.fromLTRB(13.0, 5.0, 13.0, 5.0),
                                                                              child: Image.asset(
                                                                                "assets/newDesignIcon/icon/checked_box.png",
                                                                                height: 22.0,
                                                                                width: 22.0,
                                                                              ))),
                                                                      flex: 0)
                                                                  : Expanded(
                                                                      child: InkWell(
                                                                        child: Padding(
                                                                            padding: EdgeInsets.fromLTRB(13.0, 5.0, 13.0, 5.0),
                                                                            child: Image.asset(
                                                                              "assets/newDesignIcon/icon/uncheked_box.png",
                                                                              height: 22.0,
                                                                              width: 22.0,
                                                                            )),
                                                                        onTap:
                                                                            () {
                                                                          setState(
                                                                              () {
                                                                            _mPublicProfileDataModel.result.socialLinks[index].isProfileDisplay =
                                                                                true;

                                                                            _mPublicProfileDataModel.result.isSocialLinks =
                                                                                true;
                                                                          });
                                                                        },
                                                                      ),
                                                                      flex: 0),
                                                              Expanded(
                                                                  flex: 0,
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            4,
                                                                            4,
                                                                            4),
                                                                    child:
                                                                        ClipOval(
                                                                      child:
                                                                          Container(
                                                                        child: FadeInImage
                                                                            .assetNetwork(
                                                                          fit: BoxFit
                                                                              .fill,
                                                                          placeholder:
                                                                              'assets/profile/img_default.png',
                                                                          image:
                                                                              Constant.IMAGE_PATH + _mPublicProfileDataModel.result.socialLinks[index].image,
                                                                          height:
                                                                              40.0,
                                                                          width:
                                                                              40.0,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  )),
                                                              Expanded(
                                                                  flex: 1,
                                                                  child: PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          11.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          BaseText(
                                                                            text:
                                                                                _mPublicProfileDataModel.result.socialLinks[index].socialName,
                                                                            textColor:
                                                                                ColorValues.TEXT_COLOR,
                                                                            fontFamily:
                                                                                AppConstants.stringConstant.latoMedium,
                                                                            fontWeight:
                                                                                FontWeight.w400,
                                                                            fontSize:
                                                                                16,
                                                                            textAlign:
                                                                                TextAlign.start,
                                                                            maxLines:
                                                                                2,
                                                                          )))
                                                            ],
                                                          ),
                                                        );
                                                      }),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ))),
                                    _mPublicProfileDataModel.result.resume !=
                                                null &&
                                            _mPublicProfileDataModel.result
                                                    .resume.displayName !=
                                                "null" &&
                                            _mPublicProfileDataModel.result
                                                    .resume.displayName !=
                                                ""
                                        ? PaddingWrap.paddingfromLTRB(
                                            20.0,
                                            24.0,
                                            20.0,
                                            0.0,
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: ColorValues
                                                        .LIST_BOTTOM_BG,
                                                    borderRadius: new BorderRadius
                                                            .only(
                                                        topLeft: const Radius
                                                            .circular(10.0),
                                                        topRight: const Radius
                                                            .circular(10.0)),
                                                  ),
                                                  child: Row(
                                                    children: <Widget>[
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              6.0,
                                                              10.0,
                                                              10.0,
                                                              10.0,
                                                              Image.asset(
                                                                "assets/profile/skills/ic_resume.png",
                                                                width: 35,
                                                                height: 35,
                                                              )),
                                                      Expanded(
                                                        child: BaseText(
                                                          text: 'Resume',
                                                          textColor: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize: 18,
                                                          maxLines: 1,
                                                        ),
                                                      ),
                                                      _hideShowButton(
                                                          value:
                                                              _mPublicProfileDataModel
                                                                  .result
                                                                  .isResume,
                                                          onChange: (value) {
                                                            setState(() {
                                                              _mPublicProfileDataModel
                                                                      .result
                                                                      .isResume =
                                                                  value;
                                                            });
                                                          }),
                                                      const SizedBox(width: 12),
                                                    ],
                                                  ),
                                                ),
                                                DisableView(
                                                  isEnable:
                                                      _mPublicProfileDataModel
                                                          .result.isResume,
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0, 0, 0, 0),
                                                        child: Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            color: ColorValues
                                                                .SELECTION_BG,
                                                            borderRadius: new BorderRadius
                                                                    .only(
                                                                bottomLeft:
                                                                    const Radius
                                                                            .circular(
                                                                        10.0),
                                                                bottomRight:
                                                                    const Radius
                                                                            .circular(
                                                                        10.0)),
                                                          ),
                                                          child: Row(
                                                            children: [
                                                              Expanded(
                                                                child: PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        10.0,
                                                                        10.0,
                                                                        0.0,
                                                                        10.0,
                                                                        Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/icon/pdf_icon.png",
                                                                          height:
                                                                              33.0,
                                                                          width:
                                                                              33.0,
                                                                        )),
                                                                flex: 0,
                                                              ),
                                                              Expanded(
                                                                child: Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    PaddingWrap.paddingfromLTRB(
                                                                        10.0,
                                                                        5.0,
                                                                        5.0,
                                                                        10.0,
                                                                        InkWell(
                                                                            onTap: () {
                                                                              Util.launchUrl(_mPublicProfileDataModel.result.resume.uploadType, _mPublicProfileDataModel.result.resume.resumeUrl);
                                                                            },
                                                                            child: Text(
                                                                              _mPublicProfileDataModel.result.resume.displayName,
                                                                              maxLines: 1,
                                                                              style: TextStyle(fontWeight: FontWeight.normal, color: ColorValues.BLUE_COLOR_BOTTOMBAR, fontFamily: Constant.TYPE_CUSTOMREGULAR, fontSize: 16.0),
                                                                            ))),
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                )
                                              ],
                                            ))
                                        : const SizedBox.shrink(),
                                    const SizedBox(height: 24),
                                  ],
                                ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void conformationDialog(msg, context) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: msg,
            negativeText: 'OK',
            isSucessPopup: true,
            onNegativeTap: () {},
          );
        });
  }

  setToggel(var model, bool setFlag) {
    for (var dateModel in model) {
      dateModel.isProfileDisplay = setFlag;
    }
  }

  setToggelAccomplishment(bool setFlag) {
    for (AccomplimentData accomplimentDataList
        in _mAcoomplismentDataModel.accomplimentData) {
      for (Achievement achievementModel in accomplimentDataList.achievement) {
        achievementModel.isProfileDisplay = setFlag;
      }
    }
  }

  setToggeltestScore(bool setFlag) {
    for (TestScores testScoresList
        in _mPublicProfileDataModel.result.testScores) {
      for (Scores ScoresModel in testScoresList.scores) {
        ScoresModel.isProfileDisplay = setFlag;
      }
    }
  }

  updaetAccomplismentToggel() {
    bool isAccomplishmentValue = false;
    for (AccomplimentData accomplimentDataList
        in _mAcoomplismentDataModel.accomplimentData) {
      for (Achievement achievementModel in accomplimentDataList.achievement) {
        if (achievementModel.isProfileDisplay) {
          isAccomplishmentValue = true;
          break;
        }
      }
      if (isAccomplishmentValue) {
        break;
      }
    }
    if (isAccomplishmentValue) {
      _mPublicProfileDataModel.result.isAccomplishment = true;
    } else {
      _mPublicProfileDataModel.result.isAccomplishment = false;
    }
  }

  updateSocialToggel() {
    bool isSocialLinks = false;

    for (var socialLinksModel in _mPublicProfileDataModel.result.socialLinks) {
      if (socialLinksModel.isProfileDisplay) {
        isSocialLinks = true;
        break;
      }
    }
    if (isSocialLinks) {
      _mPublicProfileDataModel.result.isSocialLinks = true;
    } else {
      _mPublicProfileDataModel.result.isSocialLinks = false;
    }
  }

  updateBadgeToggel() {
    bool isBadgeValue = false;

    for (Collections collectionsModel
        in _mPublicProfileDataModel.result.badges.collections) {
      if (collectionsModel.isProfileDisplay) {
        isBadgeValue = true;
        break;
      }
    }
    if (isBadgeValue) {
      _mPublicProfileDataModel.result.isBadges = true;
    } else {
      _mPublicProfileDataModel.result.isBadges = false;
    }
  }

  updateEducationToggel() {
    bool isEducationVallue = false;

    for (Colleges collegesModel
        in _mPublicProfileDataModel.result.educations.colleges) {
      if (collegesModel.isProfileDisplay) {
        isEducationVallue = true;
        break;
      }
    }

    if (!isEducationVallue) {
      for (Schools schoolsModel
          in _mPublicProfileDataModel.result.educations.schools) {
        if (schoolsModel.isProfileDisplay) {
          isEducationVallue = true;
          break;
        }
      }
    }
    if (isEducationVallue) {
      _mPublicProfileDataModel.result.isEducations = true;
    } else {
      isGPA = false;
      _mPublicProfileDataModel.result.isEducations = false;
    }
  }

  updateTerstScoreToggel() {
    bool isTestScoreValue = false;
    for (TestScores testScoresList
        in _mPublicProfileDataModel.result.testScores) {
      for (Scores ScoresModel in testScoresList.scores) {
        {
          if (ScoresModel.isProfileDisplay) {
            isTestScoreValue = true;
            break;
          }
        }
        if (isTestScoreValue) {
          break;
        }
      }
      if (isTestScoreValue) {
        _mPublicProfileDataModel.result.isTestScore = true;
      } else {
        _mPublicProfileDataModel.result.isTestScore = false;
      }
    }
  }

  updateRecommendationToggel() {
    bool isRecommendation = false;

    for (Recommendations recommendationsModel
        in _mPublicProfileDataModel.result.recommendations) {
      if (recommendationsModel.isProfileDisplay) {
        isRecommendation = true;
        break;
      }
    }
    if (isRecommendation) {
      _mPublicProfileDataModel.result.isRecommendation = true;
    } else {
      _mPublicProfileDataModel.result.isRecommendation = false;
    }
  }

  Container getSchoolEducationListItem(index, schoolsInfoList) {
    return Container(
        child: InkWell(
      child: PaddingWrap.paddingfromLTRB(
          13.0,
          12.0,
          13.0,
          0.0,
          Container(
            height: 84,
            width: double.infinity,
            decoration: BoxDecoration(
              color: int.parse(schoolsInfoList[index].fromYear) ==
                          DateTime.now().year ||
                      int.parse(schoolsInfoList[index].toYear) ==
                          DateTime.now().year ||
                      setRange(schoolsInfoList[index].fromYear,
                          schoolsInfoList[index].toYear)
                  ? AppConstants.colorStyle.education_bg_green
                  : Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(12)),
            ),
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12.0, top: 12, bottom: 12, right: 4),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      //color: Colors.transparent,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          BaseText(
                            text: schoolsInfoList[index].institute,
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                            maxLines: 2,
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          RichText(
                            maxLines: 15,
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              text: schoolsInfoList[index].toYear == null ||
                                      schoolsInfoList[index].toYear == "null" ||
                                      schoolsInfoList[index].toYear == ""
                                  ? schoolsInfoList[index].fromYear +
                                      " - " +
                                      "Ongoing" +
                                      " | "
                                  : schoolsInfoList[index].fromYear +
                                      " - " +
                                      schoolsInfoList[index].toYear +
                                      " | ",
                              style: TextStyle(
                                  color: AppConstants.colorStyle.lightPurple,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: Constant.latoRegular,
                                  fontSize: 13.0),
                              children: [
                                TextSpan(
                                    text: schoolsInfoList[index].fromGrade +
                                        " - " +
                                        schoolsInfoList[index].toGrade,
                                    style: TextStyle(
                                        color:
                                            AppConstants.colorStyle.lightPurple,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: Constant.latoRegular,
                                        fontSize: 13.0)),
                                TextSpan(
                                    text: schoolsInfoList[index].gpa != null &&
                                            schoolsInfoList[index].gpa != ''
                                        ? " | GPA: " +
                                            schoolsInfoList[index]
                                                .gpa
                                                .toString()
                                        : '',
                                    style: TextStyle(
                                        color:
                                            AppConstants.colorStyle.lightPurple,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: Constant.latoRegular,
                                        fontSize: 13.0)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    flex: 1,
                  ),
                  Expanded(
                    child: Image.asset(
                      'assets/new_onboarding/l1.png',
                      height: 68,
                      width: 72,
                    ),
                    flex: 0,
                  ),
                ],
              ),
            ),
          )),
      onTap: () {},
    ));
  }

  Container getCollegeEducationListItem(index, collegesInfoList) {
    return Container(
        child: InkWell(
      child: PaddingWrap.paddingfromLTRB(
          13.0,
          12.0,
          13.0,
          0.0,
          Container(
            height: 84,
            width: double.infinity,
            decoration: BoxDecoration(
              color: int.parse(collegesInfoList[index].fromYear) ==
                          DateTime.now().year ||
                      int.parse(collegesInfoList[index].toYear) ==
                          DateTime.now().year ||
                      setRange(collegesInfoList[index].fromYear,
                          collegesInfoList[index].toYear)
                  ? AppConstants.colorStyle.education_bg_green
                  : Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(12)),
            ),
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 12.0, top: 12, bottom: 12, right: 4),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      //color: Colors.transparent,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          BaseText(
                            text: collegesInfoList[index].institute,
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                            maxLines: 2,
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          Row(
                            children: [
                              collegesInfoList[index].degree != 'null'
                                  ? BaseText(
                                      text: collegesInfoList[index].degree +
                                          " | ",
                                      textColor:
                                          AppConstants.colorStyle.lightPurple,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 13,
                                      maxLines: 2,
                                    )
                                  : SizedBox(),
                              BaseText(
                                text: collegesInfoList[index].toYear == null ||
                                        collegesInfoList[index].toYear ==
                                            "null" ||
                                        collegesInfoList[index].toYear == ""
                                    ? collegesInfoList[index].fromYear +
                                        " - " +
                                        "Ongoing"
                                    : collegesInfoList[index].fromYear +
                                        " - " +
                                        collegesInfoList[index].toYear,
                                textColor: AppConstants.colorStyle.lightPurple,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w500,
                                fontSize: 13,
                                maxLines: 2,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    flex: 1,
                  ),
                  Expanded(
                    child: Image.asset(
                      'assets/new_onboarding/l1.png',
                      height: 68,
                      width: 72,
                    ),
                    flex: 0,
                  ),
                ],
              ),
            ),
          )),
      onTap: () {},
    ));
  }

  setRange(String fromYear, String toYear) {
    DateTime dateD = DateTime.now();
    //DateTime now = DateTime.now();

    String convertedDateTime =
        "${fromYear}-${dateD.month.toString().padLeft(2, '0')}-${dateD.day.toString().padLeft(2, '0')} ${dateD.hour.toString().padLeft(2, '0')}-${dateD.minute.toString().padLeft(2, '0')}";
    String convertedDateTime1 =
        "${toYear}-${dateD.month.toString().padLeft(2, '0')}-${dateD.day.toString().padLeft(2, '0')} ${dateD.hour.toString().padLeft(2, '0')}-${dateD.minute.toString().padLeft(2, '0')}";

    if (DateTime.parse(convertedDateTime).isBefore(dateD) &&
        DateTime.parse(convertedDateTime1).isAfter(dateD)) {
      return true;
    } else {
      return false;
    }
  }

  Container getSchoolEducationListItem22(index) {
    return Container(
        child: InkWell(
      child: PaddingWrap.paddingfromLTRB(
          13.0,
          10.0,
          13.0,
          0.0,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              _mPublicProfileDataModel
                      .result.educations.schools[index].isProfileDisplay
                  ? Expanded(
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              _mPublicProfileDataModel.result.educations
                                  .schools[index].isProfileDisplay = false;

                              updateEducationToggel();
                            });
                          },
                          child: Padding(
                              padding:
                                  EdgeInsets.fromLTRB(0.0, 15.0, 13.0, 5.0),
                              child: Image.asset(
                                "assets/newDesignIcon/icon/checked_box.png",
                                height: 20.0,
                                width: 20.0,
                              ))),
                      flex: 0)
                  : Expanded(
                      child: InkWell(
                        child: Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 15.0, 13.0, 5.0),
                            child: Image.asset(
                              "assets/newDesignIcon/icon/uncheked_box.png",
                              height: 20.0,
                              width: 20.0,
                            )),
                        onTap: () {
                          setState(() {
                            _mPublicProfileDataModel.result.isEducations = true;
                            _mPublicProfileDataModel.result.educations
                                .schools[index].isProfileDisplay = true;
                          });
                        },
                      ),
                      flex: 0),
              Expanded(
                  flex: 1,
                  child: PaddingWrap.paddingfromLTRB(
                      8.0,
                      12.0,
                      4.0,
                      0.0,
                      Container(
                        height: 84,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: int.parse(_mPublicProfileDataModel
                                          .result
                                          .educations
                                          .schools[index]
                                          .fromYear) ==
                                      DateTime.now().year ||
                                  int.parse(_mPublicProfileDataModel.result
                                          .educations.schools[index].toYear) ==
                                      DateTime.now().year ||
                                  setRange(
                                      _mPublicProfileDataModel.result.educations
                                          .schools[index].fromYear,
                                      _mPublicProfileDataModel.result.educations
                                          .schools[index].toYear)
                              ? AppConstants.colorStyle.education_bg_green
                              : Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 12.0, top: 12, bottom: 12, right: 4),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  //color: Colors.transparent,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      BaseText(
                                        text: _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .schools[index]
                                            .institute,
                                        textColor: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontFamily: AppConstants
                                            .stringConstant.latoRegular,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                        maxLines: 2,
                                      ),
                                      SizedBox(
                                        height: 4,
                                      ),
                                      RichText(
                                        maxLines: 15,
                                        textAlign: TextAlign.start,
                                        text: TextSpan(
                                          text: _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .schools[index]
                                                          .toYear ==
                                                      null ||
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .schools[index]
                                                          .toYear ==
                                                      "null" ||
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .schools[index]
                                                          .toYear ==
                                                      ""
                                              ? _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .schools[index]
                                                      .fromYear +
                                                  " - " +
                                                  "Ongoing" +
                                                  " | "
                                              : _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .schools[index]
                                                      .fromYear +
                                                  " - " +
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .schools[index]
                                                      .toYear +
                                                  " | ",
                                          style: TextStyle(
                                              color: AppConstants
                                                  .colorStyle.lightPurple,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant.latoRegular,
                                              fontSize: 13.0),
                                          children: [
                                            TextSpan(
                                                text: _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .schools[index]
                                                        .fromGrade +
                                                    " - " +
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .schools[index]
                                                        .toGrade,
                                                style: TextStyle(
                                                    color: AppConstants
                                                        .colorStyle.lightPurple,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    fontSize: 13.0)),
                                            TextSpan(
                                                text: _mPublicProfileDataModel
                                                                .result
                                                                .educations
                                                                .schools[index]
                                                                .gpa !=
                                                            null &&
                                                        _mPublicProfileDataModel
                                                                .result
                                                                .educations
                                                                .schools[index]
                                                                .gpa !=
                                                            ''
                                                    ? " | GPA: " +
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .schools[index]
                                                            .gpa
                                                            .toString()
                                                    : '',
                                                style: TextStyle(
                                                    color: AppConstants
                                                        .colorStyle.lightPurple,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    fontSize: 13.0)),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                flex: 1,
                              ),
                              Expanded(
                                child: Image.asset(
                                  'assets/new_onboarding/l1.png',
                                  height: 68,
                                  width: 72,
                                ),
                                flex: 0,
                              ),
                            ],
                          ),
                        ),
                      )))
            ],
          )),
      onTap: () {},
    ));
  }

  Container getCollegeEducationListItem22(index) {
    return Container(
        child: InkWell(
      child: PaddingWrap.paddingfromLTRB(
          13.0,
          0.0,
          13.0,
          0.0,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              _mPublicProfileDataModel
                      .result.educations.colleges[index].isProfileDisplay
                  ? Expanded(
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              _mPublicProfileDataModel.result.educations
                                  .colleges[index].isProfileDisplay = false;
                              updateEducationToggel();
                            });
                          },
                          child: Padding(
                              padding: EdgeInsets.fromLTRB(0.0, 15.0, 8.0, 5.0),
                              child: Image.asset(
                                "assets/newDesignIcon/icon/checked_box.png",
                                height: 22.0,
                                width: 22.0,
                              ))),
                      flex: 0)
                  : Expanded(
                      child: InkWell(
                        child: Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 15.0, 8.0, 5.0),
                            child: Image.asset(
                              "assets/newDesignIcon/icon/uncheked_box.png",
                              height: 22.0,
                              width: 22.0,
                            )),
                        onTap: () {
                          setState(() {
                            _mPublicProfileDataModel.result.isEducations = true;
                            _mPublicProfileDataModel.result.educations
                                .colleges[index].isProfileDisplay = true;
                          });
                        },
                      ),
                      flex: 0),
              Expanded(
                  flex: 1,
                  child: PaddingWrap.paddingfromLTRB(
                      8.0,
                      12.0,
                      4.0,
                      0.0,
                      Container(
                        height: 84,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: int.parse(_mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .fromYear) ==
                                      DateTime.now().year ||
                                  int.parse(_mPublicProfileDataModel.result
                                          .educations.colleges[index].toYear) ==
                                      DateTime.now().year ||
                                  setRange(
                                      _mPublicProfileDataModel.result.educations
                                          .colleges[index].fromYear,
                                      _mPublicProfileDataModel.result.educations
                                          .colleges[index].toYear)
                              ? AppConstants.colorStyle.education_bg_green
                              : Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 12.0, top: 12, bottom: 12, right: 4),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  //color: Colors.transparent,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      BaseText(
                                        text: _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .institute,
                                        textColor: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontFamily: AppConstants
                                            .stringConstant.latoRegular,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                        maxLines: 2,
                                      ),
                                      SizedBox(
                                        height: 4,
                                      ),
                                      Row(
                                        children: [
                                          BaseText(
                                            text: _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges[index]
                                                            .toYear ==
                                                        null ||
                                                    _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges[index]
                                                            .toYear ==
                                                        "null" ||
                                                    _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges[index]
                                                            .toYear ==
                                                        ""
                                                ? _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .colleges[index]
                                                        .fromYear +
                                                    " - " +
                                                    "Ongoing"
                                                : _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .colleges[index]
                                                        .fromYear +
                                                    " - " +
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .colleges[index]
                                                        .toYear,
                                            textColor: AppConstants
                                                .colorStyle.lightPurple,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 13,
                                            maxLines: 2,
                                          ),
                                          BaseText(
                                            text: " | " +
                                                _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .degree,
                                            textColor: AppConstants
                                                .colorStyle.lightPurple,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 13,
                                            maxLines: 2,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                flex: 1,
                              ),
                              Expanded(
                                child: Image.asset(
                                  'assets/new_onboarding/l1.png',
                                  height: 68,
                                  width: 72,
                                ),
                                flex: 0,
                              ),
                            ],
                          ),
                        ),
                      ))),
            ],
          )),
      onTap: () {},
    ));
  }

  Widget getTestScoreListItem(index) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        _mPublicProfileDataModel.result.testScores[index].scores.length,
        (index3) {
          return PaddingWrap.paddingfromLTRB(
            0.0,
            5.0,
            0.0,
            0.0,
            Container(
              decoration: BoxDecoration(
                color: ColorValues.WHITE,
                borderRadius: BorderRadius.circular(10),
              ),
              margin: EdgeInsets.only(left: 12, right: 12, top: 5, bottom: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 12.0, right: 12.0, top: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _mPublicProfileDataModel.result.testScores[index]
                                .scores[index3].isProfileDisplay
                            ? Expanded(
                                child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        _mPublicProfileDataModel
                                            .result
                                            .testScores[index]
                                            .scores[index3]
                                            .isProfileDisplay = false;
                                      });

                                      updateTerstScoreToggel();
                                    },
                                    child: Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 5.0, 0.0, 5.0),
                                        child: Image.asset(
                                          "assets/newDesignIcon/icon/checked_box.png",
                                          height: 22.0,
                                          width: 22.0,
                                        ))),
                                flex: 0)
                            : Expanded(
                                child: InkWell(
                                  child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          0.0, 5.0, 0.0, 5.0),
                                      child: Image.asset(
                                        "assets/newDesignIcon/icon/uncheked_box.png",
                                        height: 22.0,
                                        width: 22.0,
                                      )),
                                  onTap: () {
                                    setState(() {
                                      _mPublicProfileDataModel
                                          .result.isTestScore = true;
                                      _mPublicProfileDataModel
                                          .result
                                          .testScores[index]
                                          .scores[index3]
                                          .isProfileDisplay = true;
                                    });
                                  },
                                ),
                                flex: 0),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 1,
                          child: BaseText(
                            text: _mPublicProfileDataModel
                                .result.testScores[index].name,
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                            maxLines: 3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                      padding: const EdgeInsets.only(
                          left: 12.0, right: 12.0, bottom: 12),
                      child: Container(
                          child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Column(
                              children: List.generate(
                                  _mPublicProfileDataModel
                                      .result
                                      .testScores[index]
                                      .scores[index3]
                                      .subjects
                                      .length, (index2) {
                            return Padding(
                                padding: const EdgeInsets.only(top: 9.0),
                                child: Container(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        0.0,
                                        0.0,
                                        Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: BaseText(
                                                text: _mPublicProfileDataModel
                                                    .result
                                                    .testScores[index]
                                                    .scores[index3]
                                                    .subjects[index2]
                                                    .subject,
                                                textColor: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoRegular,
                                                fontWeight: FontWeight.w400,
                                                fontSize: 14,
                                                maxLines: 3,
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: BaseText(
                                                text: _mPublicProfileDataModel
                                                    .result
                                                    .testScores[index]
                                                    .scores[index3]
                                                    .subjects[index2]
                                                    .score
                                                    .toString(),
                                                textColor: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoRegular,
                                                fontWeight: FontWeight.w700,
                                                fontSize: 16,
                                                maxLines: 3,
                                              ),
                                              flex: 0,
                                            )
                                          ],
                                        ))));
                          })),
                        ],
                      ))),
                  PaddingWrap.paddingfromLTRB(
                      12.0,
                      0.0,
                      12.0,
                      16.0,
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                9.0,
                                0.0,
                                0.0,
                                BaseText(
                                  text: getConvertedDateStamp2(
                                      _mPublicProfileDataModel
                                          .result
                                          .testScores[index]
                                          .scores[index3]
                                          .dateTaken
                                          .toString()),
                                  textColor: ColorValues.labelColor,
                                  fontFamily:
                                      AppConstants.stringConstant.latoItalic,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  maxLines: 3,
                                )),
                            flex: 1,
                          ),
                          Expanded(
                            child: _mPublicProfileDataModel
                                            .result
                                            .testScores[index]
                                            .scores[index3]
                                            .docUrl
                                            .length >
                                        0 ||
                                    _mPublicProfileDataModel
                                            .result
                                            .testScores[index]
                                            .scores[index3]
                                            .imageUrl
                                            .length >
                                        0
                                ? InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        9.0,
                                        0.0,
                                        0.0,
                                        BaseText(
                                          text: 'View attachment',
                                          textColor: ColorValues
                                              .HEADING_COLOR_EDUCATION_2,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 12,
                                          maxLines: 3,
                                        )),
                                    onTap: () {
                                      var score = _mPublicProfileDataModel
                                          .result
                                          .testScores[index]
                                          .scores[index3];

                                      ScoreDataModel model = ScoreDataModel(
                                          sId: score.sId,
                                          userTestId: score.userTestId,
                                          testId: score.testId,
                                          userId: score.userId,
                                          dateTaken: score.dateTaken,
                                          imageUrl: score.imageUrl,
                                          docUrl: score.docUrl,
                                          name: score.name,
                                          subjects: score.subjects,
                                          isProfileDisplay:
                                              score.isProfileDisplay);
                                      Navigator.of(context).push(
                                          new MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  DocumentPerformance(
                                                    null,
                                                    model: model,
                                                    subjectName:
                                                        score.subjects.length ==
                                                                1
                                                            ? score.subjects[0]
                                                                .subject
                                                            : '',
                                                  )));
                                    },
                                  )
                                : SizedBox(),
                            flex: 0,
                          ),
                        ],
                      )),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  badgeList2() {
    return Container(
      decoration: BoxDecoration(
        color: ColorValues.SELECTION_BG,
        borderRadius: new BorderRadius.only(
            bottomLeft: const Radius.circular(10.0),
            bottomRight: const Radius.circular(10.0)),
      ),
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: List.generate(
                _mPublicProfileDataModel.result.badges.collections.length > 2
                    ? isViewAllBadges
                        ? _mPublicProfileDataModel
                            .result.badges.collections.length
                        : 2
                    : _mPublicProfileDataModel.result.badges.collections.length,
                (int index) {
                  return Container(
                    decoration: BoxDecoration(
                      color: ColorValues.WHITE,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin:
                        EdgeInsets.only(top: 6, bottom: 6, left: 12, right: 12),
                    padding: EdgeInsets.only(
                        top: 11, bottom: 11, left: 12, right: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        _mPublicProfileDataModel.result.badges
                                .collections[index].isProfileDisplay
                            ? Expanded(
                                child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        _mPublicProfileDataModel
                                            .result
                                            .badges
                                            .collections[index]
                                            .isProfileDisplay = false;

                                        updateBadgeToggel();
                                      });
                                    },
                                    child: Image.asset(
                                      "assets/newDesignIcon/icon/checked_box.png",
                                      height: 22.0,
                                      width: 22.0,
                                    )),
                                flex: 0)
                            : Expanded(
                                child: InkWell(
                                  child: Image.asset(
                                    "assets/newDesignIcon/icon/uncheked_box.png",
                                    height: 22.0,
                                    width: 22.0,
                                  ),
                                  onTap: () {
                                    setState(() {
                                      _mPublicProfileDataModel
                                          .result
                                          .badges
                                          .collections[index]
                                          .isProfileDisplay = true;
                                      _mPublicProfileDataModel.result.isBadges =
                                          true;
                                    });
                                  },
                                ),
                                flex: 0),
                        Expanded(
                          flex: 0,
                          child: Padding(
                            padding: const EdgeInsets.only(
                                left: 12.0, top: 0, right: 12.0, bottom: 0),
                            child: Container(
                              height: 78.0,
                              width: 76.0,
                              decoration: BoxDecoration(
                                border: Border.all(
                                    color: ColorValues.BORDER_GENERATE_SCRIPT),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(12)),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(3.0),
                                    child: FadeInImage.assetNetwork(
                                      fit: BoxFit.contain,
                                      placeholder:
                                          'assets/profile/user_on_user.png',
                                      image: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getMediumImage(
                                              _mPublicProfileDataModel
                                                  .result
                                                  .badges
                                                  .collections[index]
                                                  .image),
                                      height: 94.0,
                                      width: 86.0,
                                    )),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                _mPublicProfileDataModel
                                    .result.badges.collections[index].name
                                    .toString(),
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: Constant.latoRegular,
                                  color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                ),
                              ),
                              const SizedBox(height: 4),
                              _mPublicProfileDataModel.result.badges
                                          .collections[index].companyName
                                          .toString() ==
                                      ""
                                  ? new Container(height: 0.0)
                                  : Text(
                                      _mPublicProfileDataModel.result.badges
                                          .collections[index].companyName
                                          .toString(),
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: Constant.latoRegular,
                                        color: ColorValues.labelColor,
                                      ),
                                    ),
                              InkWell(
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 4),
                                  child: Text(
                                    _mPublicProfileDataModel.result.badges
                                                    .collections[index].type ==
                                                "request" &&
                                            _mPublicProfileDataModel
                                                    .result
                                                    .badges
                                                    .collections[index]
                                                    .status ==
                                                "accepted"
                                        ? 'Issued on: ' +
                                            getConvertedDateStamp2(
                                                _mPublicProfileDataModel
                                                    .result
                                                    .badges
                                                    .collections[index]
                                                    .date
                                                    .toString())
                                        : 'Issued on: ' +
                                            getConvertedDateStamp2(
                                                _mPublicProfileDataModel
                                                    .result
                                                    .badges
                                                    .collections[index]
                                                    .date
                                                    .toString()),
                                    style: TextStyle(
                                      color: ColorValues.labelColor,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: Constant.latoRegular,
                                    ),
                                  ),
                                ),
                                onTap: () {},
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
          _mPublicProfileDataModel.result.badges.collections == null
              ? Container(
                  height: 0,
                )
              : _mPublicProfileDataModel.result.badges.collections.length > 2
                  ? InkWell(
                      onTap: () {
                        if (isViewAllBadges) {
                          isViewAllBadges = false;
                        } else {
                          isViewAllBadges = true;
                        }
                        setState(() {});
                      },
                      child: Container(
                        margin: const EdgeInsets.only(top: 8, bottom: 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(7),
                          border: Border.all(
                            color: Color(0xff4684EB),
                            width: 1,
                          ),
                        ),
                        padding: const EdgeInsets.fromLTRB(20, 6, 19, 7),
                        child: Text(
                          isViewAllBadges ? 'View less' : 'View all',
                          style: TextStyle(
                            color: Color(0xff4684EB),
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                          ),
                        ),
                      ),
                    )
                  : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Widget getRecommendation() {
    return PaddingWrap.paddingfromLTRB(
        20.0,
        24.0,
        20.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                color: ColorValues.LIST_BOTTOM_BG,
                borderRadius: new BorderRadius.only(
                    topLeft: const Radius.circular(10.0),
                    topRight: const Radius.circular(10.0)),
              ),
              child: Row(
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                      6.0,
                      10.0,
                      10.0,
                      10.0,
                      Image.asset(
                        "assets/profile/skills/ic_recommendation.png",
                        width: 35,
                        height: 35,
                      )),
                  Expanded(
                    child: BaseText(
                      text: 'Recommendations',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                      maxLines: 1,
                    ),
                  ),
                  _hideShowButton(
                      value: _mPublicProfileDataModel.result.isRecommendation,
                      onChange: (value) {
                        setState(() {
                          _mPublicProfileDataModel.result.isRecommendation =
                              value;
                          setToggel(
                              _mPublicProfileDataModel.result.recommendations,
                              value);
                        });
                      }),
                  const SizedBox(width: 12),
                ],
              ),
            ),
            DisableView(
              isEnable: _mPublicProfileDataModel.result.isRecommendation,
              child: Container(
                  decoration: BoxDecoration(
                    color: ColorValues.SELECTION_BG,
                    borderRadius: new BorderRadius.only(
                        bottomLeft: const Radius.circular(10.0),
                        bottomRight: const Radius.circular(10.0)),
                  ),
                  child: Column(
                    children: [
                      _mPublicProfileDataModel
                                  ?.result?.recommendations?.isNotEmpty ??
                              false
                          ? ListView.separated(
                              itemBuilder: (_, index) {
                                final item = _mPublicProfileDataModel
                                    .result.recommendations[index];
                                return _recommendationItem(item, index);
                              },
                              separatorBuilder: (_, index) =>
                                  const SizedBox(height: 16),
                              itemCount: (_mPublicProfileDataModel?.result
                                              ?.recommendations?.length ??
                                          0) >
                                      3
                                  ? isShowAllRecommendation
                                      ? (_mPublicProfileDataModel?.result
                                              ?.recommendations?.length ??
                                          0)
                                      : 3
                                  : _mPublicProfileDataModel
                                          ?.result?.recommendations?.length ??
                                      0,
                              shrinkWrap: true,
                              padding: EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 12),
                              physics: const NeverScrollableScrollPhysics(),
                            )
                          : const SizedBox.shrink(),
                      (_mPublicProfileDataModel
                                      ?.result?.recommendations?.length ??
                                  0) >=
                              3
                          ? InkWell(
                              onTap: () {
                                isShowAllRecommendation =
                                    !isShowAllRecommendation;
                                setState(() {});
                              },
                              child: Container(
                                margin:
                                    const EdgeInsets.only(top: 8, bottom: 12),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(7),
                                  border: Border.all(
                                    color: Color(0xff4684EB),
                                    width: 1,
                                  ),
                                ),
                                padding:
                                    const EdgeInsets.fromLTRB(20, 6, 19, 7),
                                child: Text(
                                  isShowAllRecommendation
                                      ? 'View less'
                                      : 'View all',
                                  style: TextStyle(
                                    color: Color(0xff4684EB),
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                  ),
                                ),
                              ),
                            )
                          : const SizedBox.shrink(),
                    ],
                  )),
            )
          ],
        ));
  }

  Widget _recommendationItem(Recommendations item, int index) {
    return Container(
      padding: EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _mPublicProfileDataModel
                      .result.recommendations[index].isProfileDisplay
                  ? Expanded(
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              _mPublicProfileDataModel
                                  .result
                                  .recommendations[index]
                                  .isProfileDisplay = false;

                              updateRecommendationToggel();
                            });
                          },
                          child: Image.asset(
                            "assets/newDesignIcon/icon/checked_box.png",
                            height: 22.0,
                            width: 22.0,
                          )),
                      flex: 0)
                  : Expanded(
                      child: InkWell(
                        child: Image.asset(
                          "assets/newDesignIcon/icon/uncheked_box.png",
                          height: 22.0,
                          width: 22.0,
                        ),
                        onTap: () {
                          setState(() {
                            _mPublicProfileDataModel.result
                                .recommendations[index].isProfileDisplay = true;

                            _mPublicProfileDataModel.result.isRecommendation =
                                true;
                          });
                        },
                      ),
                      flex: 0),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    item.recommenderFile != "null" && item.recommenderFile != ""
                        ? InkWell(
                            onTap: () {
                              launch(
                                  Constant.IMAGE_PATH + item.recommenderFile);
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Image.asset(
                                      'assets/recommendation/ic_list_recommendation.png',
                                      width: 16,
                                      height: 20,
                                    ),
                                    flex: 0,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: BaseText(
                                      text: 'Recommendation letter',
                                      textColor: Color(0xff4684EB),
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      maxLines: 1,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : const SizedBox.shrink(),
                    ReadMoreTextWidget(
                      text: item.stage == "Added" || item.stage == "Replied"
                          ? item.recommendation ?? ''
                          : item.request,
                    ),
                    const SizedBox(height: 7),
                    BaseText(
                      text:
                          "${item?.recommender[0]?.firstName ?? ''} ${item?.recommender[0]?.lastName ?? ''}",
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 7),
                    BaseText(
                      text: '${item.title ?? ''} ',
                      textColor: ColorValues.labelColor,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 11),
                  ],
                ),
                flex: 1,
              ),
            ],
          ),
          Divider(
            height: 0,
            thickness: 1,
            color: Color(0xffE8ECFF),
          ),

          const SizedBox(height: 11),

          item?.level3Competency?.toString() != 'null' &&
              (item?.level3Competency?.isNotEmpty ?? false)
              ? Row(
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    BaseText(
                      text: 'For',
                      textColor: ColorValues.labelColor,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 5),
                    BaseText(
                      text: item?.level3Competency?.toString() !=
                          'null' &&
                          item?.level3Competency?.isNotEmpty ??
                          false
                          ? "${item.level3Competency}"
                          : '',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      maxLines: 1,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    BaseText(
                      text: 'Sent On:',
                      textColor: ColorValues.labelColor,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 5),
                    BaseText(
                      text: Util.getConvertedDateStampNew(
                          item.requestedDate),
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      maxLines: 1,
                    ),
                  ],
                ),
              ),
            ],
          )
              : Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Expanded(
              //   child: Column(
              //     mainAxisSize: MainAxisSize.min,
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: [
              //       BaseText(
              //         text: item.title,
              //         textColor: ColorValues.labelColor,
              //         fontFamily: AppConstants.stringConstant.latoRegular,
              //         fontSize: 12,
              //         fontWeight: FontWeight.w500,
              //         maxLines: 1,
              //       ),
              //       const SizedBox(height: 5),
              //
              //     ],
              //   ),
              // ),

              BaseText(
                text: 'Sent On:',
                textColor: ColorValues.labelColor,
                fontFamily: AppConstants.stringConstant.latoRegular,
                fontSize: 10,
                fontWeight: FontWeight.w500,
                maxLines: 1,
              ),
              const SizedBox(height: 5),
              BaseText(
                text: Util.getConvertedDateStampNew(item.requestedDate),
                textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                fontFamily: AppConstants.stringConstant.latoRegular,
                fontSize: 14,
                fontWeight: FontWeight.w500,
                maxLines: 1,
              ),
            ],
          ),


        ],
      ),
    );
  }

  Padding skillView() {
    return PaddingWrap.paddingfromLTRB(
        20.0,
        24.0,
        20.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                color: ColorValues.LIST_BOTTOM_BG,
                borderRadius: new BorderRadius.only(
                    topLeft: const Radius.circular(10.0),
                    topRight: const Radius.circular(10.0)),
              ),
              child: Row(
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                      6.0,
                      10.0,
                      10.0,
                      10.0,
                      Image.asset(
                        "assets/newDesignIcon/icon/skills_certi.png",
                        width: 35,
                        height: 35,
                      )),
                  Expanded(
                    child: BaseText(
                      text: 'Skills & certifications',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                      maxLines: 2,
                    ),
                  ),
                  const SizedBox(width: 10),
                  _hideShowButton(
                      value: _mPublicProfileDataModel
                          .result.isSkillAndCertification,
                      onChange: (value) {
                        setState(() {
                          _mPublicProfileDataModel
                              .result.isSkillAndCertification = value;
                          setToggel(
                              _mPublicProfileDataModel.result.certificates,
                              value);
                        });
                      }),
                  const SizedBox(width: 12),
                ],
              ),
            ),
            DisableView(
              isEnable: _mPublicProfileDataModel.result.isSkillAndCertification,
              child: Container(
                width: double.maxFinite,
                decoration: BoxDecoration(
                  color: ColorValues.SELECTION_BG,
                  borderRadius: new BorderRadius.only(
                      bottomLeft: const Radius.circular(10.0),
                      bottomRight: const Radius.circular(10.0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    _mPublicProfileDataModel.result != null &&
                            _mPublicProfileDataModel.result.skills != null &&
                            _mPublicProfileDataModel.result.skills.length > 0
                        ? Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              PaddingWrap.paddingfromLTRB(
                                  17.0,
                                  10.0,
                                  0.0,
                                  0.0,
                                  TextViewWrap.textViewSingleLine(
                                      "Skills",
                                      TextAlign.start,
                                      ColorValues.HEADING_COLOR_EDUCATION,
                                      16.0,
                                      FontWeight.w500)),
                              Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(13.0, 0, 13, 0),
                                child: _skillsItem(
                                    _mPublicProfileDataModel.result.skills),
                              ),
                            ],
                          )
                        : const SizedBox.shrink(),
                    _mPublicProfileDataModel.result != null &&
                            _mPublicProfileDataModel.result.certificates !=
                                null &&
                            _mPublicProfileDataModel
                                    .result.certificates.length >
                                0
                        ? Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              PaddingWrap.paddingfromLTRB(
                                  17.0,
                                  10.0,
                                  0.0,
                                  0.0,
                                  TextViewWrap.textViewSingleLine(
                                      "Certifications",
                                      TextAlign.start,
                                      ColorValues.HEADING_COLOR_EDUCATION,
                                      16.0,
                                      FontWeight.w500)),
                              Column(
                                  children: List.generate(
                                      _mPublicProfileDataModel.result
                                          .certificates.length, (int index) {
                                return getCertificateItem(index);
                              })),
                            ],
                          )
                        : const SizedBox.shrink(),
                  ],
                ),
              ),
            )
          ],
        ));
  }

  Container getCertificateItem(index) {
    return Container(
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          borderRadius: BorderRadius.circular(10),
        ),
        margin: EdgeInsets.only(top: 10, bottom: 10, left: 12, right: 12),
        child: InkWell(
          child: PaddingWrap.paddingfromLTRB(
              5.0,
              8.0,
              5.0,
              8.0,
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  _mPublicProfileDataModel
                          .result.certificates[index].isProfileDisplay
                      ? Expanded(
                          child: InkWell(
                              onTap: () {
                                setState(() {
                                  _mPublicProfileDataModel
                                      .result
                                      .certificates[index]
                                      .isProfileDisplay = false;
                                });
                              },
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 5.0, 13.0, 5.0),
                                  child: Image.asset(
                                    "assets/newDesignIcon/icon/checked_box.png",
                                    height: 22.0,
                                    width: 22.0,
                                  ))),
                          flex: 0)
                      : Expanded(
                          child: InkWell(
                            child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(13.0, 5.0, 13.0, 5.0),
                                child: Image.asset(
                                  "assets/newDesignIcon/icon/uncheked_box.png",
                                  height: 22.0,
                                  width: 22.0,
                                )),
                            onTap: () {
                              setState(() {
                                _mPublicProfileDataModel
                                    .result
                                    .certificates[index]
                                    .isProfileDisplay = true;
                              });
                            },
                          ),
                          flex: 0),
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      3.0,
                      10.0,
                      5.0,
                      _mPublicProfileDataModel
                                      .result.certificates[index].image ==
                                  "" ||
                              _mPublicProfileDataModel
                                      .result.certificates[index].image ==
                                  "null"
                          ? Image.asset(
                              "assets/portfolio/certificate.png",
                              height: 28.0,
                              width: 23.0,
                            )
                          : InkWell(
                              child: Container(
                                  height: 28.0,
                                  width: 23.0,
                                  child: FadeInImage.assetNetwork(
                                    fit: BoxFit.cover,
                                    placeholder:
                                        'assets/portfolio/certificate.png',
                                    image: Constant.IMAGE_PATH +
                                        _mPublicProfileDataModel
                                            .result.certificates[index].image,
                                  )),
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => FullImageWidget(
                                      imagePath: _mPublicProfileDataModel
                                          .result.certificates[index].image,
                                      type: FullImageType.network,
                                      toolbarTitle: "Certificate",
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            5.0,
                            0.0,
                            5.0,
                            0.0,
                            Text(
                              _mPublicProfileDataModel
                                  .result.certificates[index].title,
                              maxLines: 5,
                              style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.CERTIFICATE_TEXT_COLOR,
                                  fontFamily: Constant.latoMedium,
                                  fontSize: 12.0),
                            )),
                        PaddingWrap.paddingfromLTRB(
                            5.0,
                            0.0,
                            0.0,
                            0.0,
                            Text(
                              'Received on: ' +
                                  Util.getConvertedDateStamp(
                                      _mPublicProfileDataModel
                                          .result.certificates[index].date
                                          .toString()),
                              style: TextStyle(
                                  color:
                                      ColorValues.CERTIFICATE_DATE_TEXT_COLOR,
                                  fontFamily: Constant.latoRegular,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 10.0),
                            )),
                      ],
                    ),
                    flex: 1,
                  ),
                ],
              )),
          onTap: () {},
        ));
  }

  Widget _skillsItem(skills) {
    return Wrap(
      spacing: 11,
      runSpacing: 0,
      children: List<Widget>.generate(skills.length, (index) {
        return Chip(
          label: Text(
            '${skills[index].name}',
            overflow: TextOverflow.clip,
            style: TextStyle(
              color: Color(0xff4684EB),
              fontSize: 12,
              fontWeight: FontWeight.w400,
              fontFamily: AppConstants.stringConstant.latoRegular,
            ),
          ),
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          padding: EdgeInsets.zero,
        );
      }).toList(),
    );
  }

  Container getSelectedWidgets() {
    return Container(
      child: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: ListView(
          physics: const NeverScrollableScrollPhysics(),
          primary: true,
          shrinkWrap: true,
          children: <Widget>[
            Wrap(
              spacing: 5.0,
              runSpacing: 0.0,
              children: List<Widget>.generate(
                  _mPublicProfileDataModel.result.skills.length,
                  // place the length of the array here
                  (int index) {
                //int h = _items[index].name.toString().length % 36;
                //print('Height h:::: $h');
                return InputChip(
                  label: Text(
                    '${_mPublicProfileDataModel.result.skills[index].name}',
                    overflow: TextOverflow.clip,
                    style: TextStyle(
                      fontSize: 14.0,
                      fontFamily: Constant.customRegular,
                    ),
                  ),
                  // softWrap: true,maxLines: 100,
                  //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  backgroundColor: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                  shape: StadiumBorder(
                    side: BorderSide(
                      color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                    ),
                  ),
                  onSelected: (bool value) {},

                  labelStyle: TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16,
                    fontFamily: Constant.customRegular,
                  ),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 5.0, vertical: 3.0),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget getUserInterestAndGoals() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: ColorValues.LIST_BOTTOM_BG,
              borderRadius: new BorderRadius.only(
                  topLeft: const Radius.circular(10.0),
                  topRight: const Radius.circular(10.0)),
            ),
            child: Row(
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                    6.0,
                    10.0,
                    10.0,
                    10.0,
                    Image.asset(
                      "assets/newDesignIcon/icon/intrest_icon.png",
                      width: 35,
                      height: 35,
                    )),
                Expanded(
                  child: BaseText(
                    text: 'Interests',
                    textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                    maxLines: 2,
                  ),
                ),
                _hideShowButton(
                    value: _mPublicProfileDataModel.result.isInterests,
                    onChange: (value) {
                      setState(() {
                        _mPublicProfileDataModel.result.isInterests = value;
                      });
                    }),
                const SizedBox(width: 12),
              ],
            ),
          ),
          DisableView(
            isEnable: _mPublicProfileDataModel.result.isInterests,
            child: Container(
                decoration: BoxDecoration(
                  color: ColorValues.SELECTION_BG,
                  borderRadius: new BorderRadius.only(
                      bottomLeft: const Radius.circular(10.0),
                      bottomRight: const Radius.circular(10.0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    _mPublicProfileDataModel.result.goalInterests.length > 0
                        ? PaddingWrap.paddingfromLTRB(
                            17.0,
                            10.0,
                            17.0,
                            5.0,
                            TextViewWrap.textViewSingleLine(
                                "Interests",
                                TextAlign.start,
                                const Color(0xff27275A),
                                16.0,
                                FontWeight.w500))
                        : const SizedBox.shrink(),
                    PaddingWrap.paddingfromLTRB(
                      17.0,
                      8.0,
                      17.0,
                      12.0,
                      getUserInterestChips(
                          _mPublicProfileDataModel.result.loveOtherInterests),
                    ),
                    _mPublicProfileDataModel.result.goalInterests.length > 0
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[

                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 5, bottom: 8, left: 17, right: 17),
                                child: Divider(
                                  height: 0,
                                  thickness: 1,
                                  color: Color(0xffE8ECFF),
                                ),
                              ),

                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 5, bottom: 0, left: 17, right: 17),
                                child: Text(
                                  'Future goals',
                                  style: TextStyle(
                                    color: const Color(0xff27275A),
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: AppConstants.stringConstant.latoMedium,
                                  ),
                                ),
                              ),


                              PaddingWrap.paddingfromLTRB(
                                  17.0,
                                  10.0,
                                  17.0,
                                  7.0,
                                  Text(
                                    "What’s next after high school?",overflow: TextOverflow.ellipsis,maxLines:1 ,
                                    textAlign: TextAlign.start,
                                    style:  TextStyle(
                                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: Constant.latoMedium),
                                  )
                              ),



                              //getUserInterestChips(goalInterestsList,false),
                              PaddingWrap.paddingfromLTRB(
                                17.0,
                                5.0,
                                17.0,
                                10.0,
                                getUserInterestChips(_mPublicProfileDataModel
                                    .result.goalInterests),
                              ),

                              _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          null &&
                                      _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          'null' &&
                                      _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          ''
                                  ? PaddingWrap.paddingfromLTRB(
                                      17.0,
                                      10.0,
                                      17.0,
                                      5.0,
                                      TextViewWrap.textViewSingleLine(
                                          "Institute(s)",
                                          TextAlign.start,
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                          16.0,
                                          FontWeight.w500))
                                  : const SizedBox.shrink(),
                              _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          null &&
                                      _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          'null' &&
                                      _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          ''
                                  ? PaddingWrap.paddingfromLTRB(
                                      17.0,
                                      0.0,
                                      17.0,
                                      13.0,
                                      TextViewWrap.textViewSingleLine(
                                          "${_mPublicProfileDataModel.result.goalInterestInstitute}",
                                          TextAlign.start,
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.normal))
                                  : const SizedBox.shrink(),
                            ],
                          )
                        : Container(
                            height: 0,
                            width: 0,
                          )
                  ],
                )),
          ),
        ],
      ),
    );
  }

  getUserInterestChips(List<SkillID> _items) {
    return _items != null
        ? MediaQuery.removePadding(
            context: context,
            removeTop: true,
            removeBottom: true,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              primary: true,
              shrinkWrap: true,
              children: <Widget>[
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: List<Widget>.generate(
                      _items.length, // place the length of the array here
                      (int index) {
                    return Container(
                      padding: const EdgeInsets.fromLTRB(10, 7, 10, 7),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Visibility(
                            visible:
                                (_items[index]?.image?.isNotEmpty ?? false) &&
                                    _items[index]?.image != 'null',
                            child: Padding(
                              padding: const EdgeInsets.only(right: 5),
                              child: SvgPicture.network(
                                Constant.IMAGE_PATH +
                                    ParseJson.getMediumImage(
                                        _items[index].image),
                                width: 16,
                                height: 16,
                                color: AppConstants.colorStyle.lightBlue,
                                placeholderBuilder: (context) => Container(
                                    width: 16,
                                    height: 16,
                                    alignment: Alignment.center,
                                    child: const CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                    )), //placeholder while downloading file.
                              ),
                            ),
                          ),
                          Text(
                            '${_items[index].name}',
                            style: const TextStyle(
                              fontSize: 12.0,
                              fontFamily: Constant.latoRegular,
                              fontWeight: FontWeight.w500,
                              color: Color(0xff4684EB),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          )
        : const SizedBox.shrink();
  }

  Widget isImageOrVideo(FileDataModel _mPortFolioAssest, heigt, type) {
    return _mPortFolioAssest.type == "image"
        ? Container(
            height: heigt,
            child: CachedNetworkImage(
              width: double.infinity,
              height: heigt,
              imageUrl: Constant.IMAGE_PATH + _mPortFolioAssest.filePath,
              fit: BoxFit.cover,
              placeholder: (context, url) => _loader(
                  context,
                  type == "Sports"
                      ? "assets/portfolio/sport_default.png"
                      : "assets/portfolio/arts_default.png"),
              errorWidget: (context, url, error) => _error(type == "Sports"
                  ? "assets/portfolio/sport_default.png"
                  : "assets/portfolio/arts_default.png"),
            ))
        : Container(
            height: heigt,
            width: double.infinity,
            child: VideoView(Constant.IMAGE_PATH + _mPortFolioAssest.filePath,
                "", false, type));
  }

  getVideoThumb(path, int index) async {
    final thumbnailFile =
        await uploadMedia.getVideoThumbnailFromUrl(Constant.IMAGE_PATH + path);
    return Image.file(
      thumbnailFile,
      fit: BoxFit.contain,
    );
  }

  Widget _storyItem(AccomplimentData narrative, int mainIndex) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xffF5F6FA),
        borderRadius: BorderRadius.circular(10),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xffE8ECFF),
            ),
            child: Row(
              children: [
                Expanded(
                  child: BaseText(
                    text: narrative.name,
                    textColor: const Color(0xff27275A),
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                  ),
                ),
                const SizedBox(width: 10),
                _mAcoomplismentDataModel.accomplimentData.length > 1 &&
                        mainIndex <
                            _mAcoomplismentDataModel.accomplimentData.length - 1
                    ? InkWell(
                        onTap: () {
                          AccomplimentData model = _mAcoomplismentDataModel
                              .accomplimentData[mainIndex];
                          _mAcoomplismentDataModel.accomplimentData
                              .removeAt(mainIndex);
                          _mAcoomplismentDataModel.accomplimentData
                              .insert(mainIndex + 1, model);
                          setState(() {});
                        },
                        child: Image.asset(
                          'assets/experience/ic_item_down.png',
                          height: 24,
                          width: 24,
                        ),
                      )
                    : const SizedBox.shrink(),
                const SizedBox(width: 10),
                mainIndex > 0
                    ? InkWell(
                        onTap: () {
                          AccomplimentData model = _mAcoomplismentDataModel
                              .accomplimentData[mainIndex];
                          _mAcoomplismentDataModel.accomplimentData
                              .removeAt(mainIndex);
                          _mAcoomplismentDataModel.accomplimentData
                              .insert(mainIndex - 1, model);

                          setState(() {});
                        },
                        child: Image.asset(
                          'assets/experience/ic_item_up.png',
                          height: 24,
                          width: 24,
                        ),
                      )
                    : const SizedBox.shrink(),
              ],
            ),
          ),
          ListView.separated(
            itemBuilder: (_, index) {
              final achieveItem = narrative.achievement[index];
              int size = achieveItem.fileList.length;
              return achieveItem.type == "portfolio"
                  ? Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Container(
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SizedBox(
                                  height: 190,
                                  child: Stack(
                                    children: [
                                      achieveItem.fileList.length < 4
                                          ? achieveItem.fileList.length == 0
                                              ? ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  child: Image.asset(
                                                    narrative.level1 == "Sports"
                                                        ? "assets/portfolio/sport_default.png"
                                                        : "assets/portfolio/arts_default.png",
                                                    fit: BoxFit.fill,
                                                    height: 190,
                                                  ),
                                                )
                                              : isImageOrVideo(
                                                  achieveItem
                                                      .fileList[size - 1],
                                                  190.0,
                                                  narrative.level1)
                                          : Container(
                                              color: Colors.black,
                                              child: Column(
                                                children: [
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: isImageOrVideo(
                                                            achieveItem
                                                                    .fileList[
                                                                size - 1],
                                                            95.0,
                                                            narrative.level1),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: isImageOrVideo(
                                                            achieveItem
                                                                    .fileList[
                                                                size - 2],
                                                            95.0,
                                                            narrative.level1),
                                                        flex: 1,
                                                      )
                                                    ],
                                                  ),
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: isImageOrVideo(
                                                            achieveItem
                                                                    .fileList[
                                                                size - 3],
                                                            95.0,
                                                            narrative.level1),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: isImageOrVideo(
                                                            achieveItem
                                                                    .fileList[
                                                                size - 4],
                                                            95.0,
                                                            narrative.level1),
                                                        flex: 1,
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        bottom: 0,
                                        top: 0,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              gradient: const LinearGradient(
                                            colors: [
                                              Color(0xff000000),
                                              Color(0x7A000000),
                                              Color(0xB5000000),
                                            ],
                                            begin: Alignment.topCenter,
                                            end: Alignment.bottomCenter,
                                          )),
                                        ),
                                      ),
                                      Positioned(
                                        left: 14,
                                        top: 53,
                                        right: 10,
                                        child: Row(
                                          children: [
                                            Center(
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                clipBehavior: Clip.antiAlias,
                                                child: CachedNetworkImage(
                                                  imageUrl:
                                                      Constant.IMAGE_PATH +
                                                          achieveItem.userImage,
                                                  fit: BoxFit.cover,
                                                  height: 54,
                                                  width: 54,
                                                  placeholder: (context, url) =>
                                                      Image.asset(
                                                    "assets/profile/user_on_user.png",
                                                    height: 54,
                                                    width: 54,
                                                  ),
                                                  errorWidget:
                                                      (context, url, error) =>
                                                          Image.asset(
                                                    "assets/profile/user_on_user.png",
                                                    height: 54,
                                                    width: 54,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  BaseText(
                                                    text: achieveItem.title,
                                                    fontSize: 16,
                                                    textColor: Colors.white,
                                                    fontWeight: FontWeight.w700,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    maxLines: 1,
                                                  ),
                                                  const SizedBox(height: 4),
                                                  BaseText(
                                                    text:
                                                        "${achieveItem?.city ?? ''}, ${achieveItem?.state ?? ''}",
                                                    fontSize: 14,
                                                    textColor: Colors.white,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    maxLines: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      /*    achieveItem?.personalReflection
                                    ?.isNotEmpty ??
                                    false
                                    ? Positioned(
                                  right: 11,
                                  bottom: 16,
                                  child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        achieveItem
                                            .isShowMorePersonalRef =
                                        !(achieveItem
                                            .isShowMorePersonalRef);
                                      });
                                    },
                                    child: Image.asset(
                                      'assets/experience/ic_inner_portfolio_list.png',
                                      height: 28,
                                      width: 28,
                                    ),
                                  ),
                                )
                                    : const SizedBox.shrink(),*/
                                    ],
                                  ),
                                ),
                                /*    Visibility(
                            visible: achieveItem.isShowMorePersonalRef,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 14),
                                BaseText(
                                  text: "Personal reflection",
                                  textColor: const Color(0xff27275A),
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  fontFamily: Constant.latoRegular,
                                ),
                                const SizedBox(height: 6),
                                _personalReflectionView(achieveItem),
                                const SizedBox(height: 14),
                              ],
                            ),
                          ),*/
                                InkWell(
                                  onTap: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            CustomPortFolioDetailsView(
                                          achieveItem: achieveItem,
                                          levelOneName: narrative.level1,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    color: const Color(0xff27275A),
                                    padding: const EdgeInsets.fromLTRB(
                                        12, 7, 12, 12),
                                    alignment: Alignment.center,
                                    child: BaseText(
                                      text: narrative.level1 == "Sports"
                                          ? "View sports portfolio"
                                          : "View arts portfolio",
                                      fontSize: 16,
                                      textColor: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: Constant.latoRegular,
                                      maxLines: 1,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        Visibility(
                          visible:
                              narrative.achievement[index].isProfileDisplay ??
                                  false,
                          child: Positioned(
                            left: 0,
                            right: 0,
                            top: 0,
                            bottom: 0,
                            child: CheckContainer(),
                          ),
                        ),
                        Positioned(
                          left: 24,
                          top: 24,
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                narrative.achievement[index].isProfileDisplay =
                                    !(narrative.achievement[index]
                                            .isProfileDisplay ??
                                        false);
                                updaetAccomplismentToggel();
                              });
                            },
                            child: Image.asset(
                              narrative.achievement[index].isProfileDisplay ??
                                      false
                                  ? "assets/newDesignIcon/icon/checked_box.png"
                                  : "assets/newDesignIcon/icon/uncheked_box.png",
                              height: 22.0,
                              width: 22.0,
                            ),
                          ),
                        ),
                      ],
                    )
                  : Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                clipBehavior: Clip.antiAlias,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                height: 184,
                                child: achieveItem.mediaAndVideoList.isNotEmpty
                                    ? PageIndicatorContainer(
                                        pageView: PageView.builder(
                                          itemCount: achieveItem
                                              .mediaAndVideoList.length,
                                          controller: PageController(),
                                          itemBuilder: (_, innerIndex) {
                                            return InkWell(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Colors.black,
                                                ),
                                                child: achieveItem
                                                            .mediaAndVideoList[
                                                                innerIndex]
                                                            .type ==
                                                        "image"
                                                    ? CachedNetworkImage(
                                                        width: double.infinity,
                                                        height: 184,
                                                        imageUrl: Constant
                                                                .IMAGE_PATH +
                                                            achieveItem
                                                                .mediaAndVideoList[
                                                                    innerIndex]
                                                                .file,
                                                        fit: BoxFit.cover,
                                                        placeholder: (context,
                                                                url) =>
                                                            Util.loader(context,
                                                                "assets/aerial/default_img.png"),
                                                        errorWidget: (context,
                                                                url, error) =>
                                                            Util.error(
                                                                "assets/aerial/default_img.png"),
                                                      )
                                                    : Center(
                                                        child: VideoPlayPauseNew(
                                                            achieveItem
                                                                .mediaAndVideoList[
                                                                    innerIndex]
                                                                .file,
                                                            "",
                                                            false,
                                                            _scrollController),
                                                      ),
                                              ),
                                              onTap: () {
                                                print('dffgdfgg--------');
                                                Navigator.of(context).push(
                                                  MaterialPageRoute(
                                                    builder: (BuildContext
                                                            context) =>
                                                        CommonFullViewWidget(
                                                      achieveItem
                                                          .mediaAndVideoList,
                                                      MessageConstant
                                                          .ACCOMPLISHMENT_HEDING,
                                                      innerIndex,
                                                      achieveItem.title,
                                                    ),
                                                  ),
                                                );
                                              },
                                            );
                                          },
                                          onPageChanged: (index) {},
                                        ),
                                        align: IndicatorAlign.bottom,
                                        length: achieveItem
                                            .mediaAndVideoList.length,
                                        indicatorSpace: 10.0,
                                        indicatorColor: achieveItem
                                                    .mediaAndVideoList.length ==
                                                1
                                            ? Colors.transparent
                                            : const Color(0xffc4c4c4),
                                        indicatorSelectorColor: achieveItem
                                                    .mediaAndVideoList.length ==
                                                1
                                            ? Colors.transparent
                                            : const Color(0XFFFFFFFF),
                                        shape: IndicatorShape.circle(size: 5.0),
                                      )
                                    : Image.asset(
                                        "assets/profile/default_achievement.png",
                                        fit: BoxFit.cover,
                                        height: 184,
                                        width: double.infinity,
                                      ),
                              ),
                              const SizedBox(height: 8),
                              RichText(
                                textAlign: TextAlign.start,
                                maxLines: 15,
                                text: TextSpan(
                                  text: achieveItem.focusArea == null ||
                                          achieveItem.focusArea == "null" ||
                                          achieveItem.focusArea == ""
                                      ? achieveItem.level3Competency + " | "
                                      : achieveItem.focusArea + " | ",
                                  style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  children: [
                                    TextSpan(
                                      text: achieveItem.title,
                                      style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 16,
                                        fontFamily: Constant.latoRegular,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 6),
                              BaseText(
                                text:
                                    "${Util.getConvertedDateStamp2(achieveItem.fromDate.toString())} - ${Util.getConvertedDateStamp2(achieveItem.toDate.toString())}",
                                textColor: const Color(0xff666B9A),
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                fontFamily: Constant.latoRegular,
                                maxLines: 1,
                              ),
                              achieveItem.hoursWorkedPerWeek != null &&
                                      achieveItem.hoursWorkedPerWeek !=
                                          "null" &&
                                      achieveItem.hoursWorkedPerWeek.trim() !=
                                          ""
                                  ? Padding(
                                      padding: const EdgeInsets.only(top: 6),
                                      child: BaseText(
                                        text:
                                            "${achieveItem?.hoursWorkedPerWeek ?? ''}",
                                        textColor: const Color(0xff666B9A),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        fontFamily: Constant.latoRegular,
                                        maxLines: 1,
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                              const SizedBox(height: 5),
                              ReadMoreTextWidget(
                                text: achieveItem.description,
                              ),
                              achieveItem
                                      .all_badge_trophy_certificate.isNotEmpty
                                  ? Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(height: 11),
                                        BaseText(
                                          text:
                                              "Certificates, trophies & badges",
                                          textColor: const Color(0xff27275A),
                                          fontWeight: FontWeight.w600,
                                          fontSize: 14,
                                          fontFamily: Constant.latoRegular,
                                          maxLines: 1,
                                        ),
                                        const SizedBox(height: 7),
                                        SingleChildScrollView(
                                          scrollDirection: Axis.horizontal,
                                          child: Row(
                                            children: achieveItem
                                                .all_badge_trophy_certificate
                                                .map((e) {
                                              return Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                clipBehavior: Clip.antiAlias,
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                                //padding: const EdgeInsets.fromLTRB(9, 2, 8, 2),
                                                child: InkWell(
                                                  child: CachedNetworkImage(
                                                    height: 51,
                                                    width: 64,
                                                    imageUrl:
                                                        Constant.IMAGE_PATH +
                                                            e.file,
                                                    fit: BoxFit.cover,
                                                    placeholder: (context,
                                                            url) =>
                                                        Util.loader(context,
                                                            "assets/profile/default_achievement.png"),
                                                    errorWidget: (context, url,
                                                            error) =>
                                                        Util.error(
                                                            "assets/profile/default_achievement.png"),
                                                  ),
                                                  onTap: () {
                                                    Navigator.of(context).push(
                                                      new MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                            CommonFullViewWidget(
                                                          achieveItem
                                                              .all_badge_trophy_certificate,
                                                          MessageConstant
                                                              .CERTIFICATES_TROPHIES_HEDING,
                                                          achieveItem
                                                              .all_badge_trophy_certificate
                                                              .indexOf(e),
                                                          MessageConstant
                                                              .CERTIFICATES_TROPHIES_HEDING,
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                ),
                                              );
                                            }).toList(),
                                          ),
                                        ),
                                      ],
                                    )
                                  : const SizedBox.shrink(),
                              Visibility(
                                  visible: achieveItem.externalLinks.isNotEmpty,
                                  child: _showExternalLinks(achieveItem)),
                              /*   achieveItem.personalReflection.isNotEmpty
                            ? Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: [
                            Divider(
                              thickness: 1,
                              color: const Color(0xffC0C8DD),
                              height: 24,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  achieveItem
                                      .isShowPersonalReflection =
                                  !(achieveItem
                                      .isShowPersonalReflection);
                                });
                              },
                              child: Row(
                                children: [
                                  Flexible(
                                    child: BaseText(
                                      text: "Personal reflection",
                                      textColor:
                                      const Color(0xff27275A),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14,
                                      fontFamily:
                                      Constant.latoRegular,
                                      maxLines: 1,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Icon(
                                    achieveItem?.isShowPersonalReflection ??
                                        false
                                        ? Icons.keyboard_arrow_up
                                        : Icons.keyboard_arrow_down,
                                    color: const Color(0xff7C89AD),
                                  ),
                                ],
                              ),
                            ),
                            Visibility(
                              visible: achieveItem
                                  .isShowPersonalReflection,
                              child: _personalReflectionView(
                                  achieveItem),
                            ),
                          ],
                        )
                            : const SizedBox.shrink(),*/
                            ],
                          ),
                        ),
                        Visibility(
                          visible:
                              narrative.achievement[index].isProfileDisplay ??
                                  false,
                          child: const Positioned(
                            left: 0,
                            right: 0,
                            top: 0,
                            bottom: 0,
                            child: CheckContainer(),
                          ),
                        ),
                        Positioned(
                          left: 24,
                          top: 24,
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                narrative.achievement[index].isProfileDisplay =
                                    !(narrative.achievement[index]
                                            .isProfileDisplay ??
                                        false);
                                updaetAccomplismentToggel();
                              });
                            },
                            child: Image.asset(
                              narrative.achievement[index].isProfileDisplay ??
                                      false
                                  ? "assets/newDesignIcon/icon/checked_box.png"
                                  : "assets/newDesignIcon/icon/uncheked_box.png",
                              height: 22.0,
                              width: 22.0,
                            ),
                          ),
                        ),
                      ],
                    );
            },
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: narrative.achievement?.length ?? 0,
            separatorBuilder: (_, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        color: const Color(0xffC0C8DD),
                        height: 1,
                      ),
                    ),
                    const SizedBox(width: 18),
                    InkWell(
                      onTap: () {
                        final model = _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement[index + 1];
                        _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement
                            .removeAt(index + 1);
                        _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement
                            .insert(index, model);
                        setState(() {});
                      },
                      child: Image.asset(
                        'assets/experience/ic_up_arrow_circle.png',
                        height: 40,
                        width: 40,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      color: const Color(0xffC0C8DD),
                      width: 8,
                      height: 1,
                    ),
                    const SizedBox(width: 6),
                    InkWell(
                      onTap: () {
                        final model = _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement[index];
                        _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement
                            .removeAt(index);
                        _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement
                            .insert(index + 1, model);
                        setState(() {});
                      },
                      child: Image.asset(
                        'assets/experience/ic_down_arrow_circle.png',
                        height: 40,
                        width: 40,
                      ),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Container(
                        color: const Color(0xffC0C8DD),
                        height: 1,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _showExternalLinks(Achievement achieveItem) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListView.separated(
          itemCount: achieveItem.externalLinks.length,
          itemBuilder: (_, exIndex) {
            final exItem = achieveItem.externalLinks[exIndex];
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BaseText(
                  text: "External links:",
                  textColor: const Color(0xff27275A),
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  fontFamily: Constant.latoRegular,
                  maxLines: 1,
                ),
                const SizedBox(height: 7),
                InkWell(
                  onTap: () {
                    if (exItem.url.toLowerCase().contains("https") ||
                        exItem.url.toLowerCase().contains("http")) {
                      launch(exItem.url.trim());
                    } else {
                      launch("https://" + exItem.url.trim());
                    }
                  },
                  child: BaseText(
                    text: exItem.label,
                    textColor: const Color(0xff4684EB),
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                    fontFamily: Constant.latoRegular,
                    maxLines: 3,
                    textDecoration: TextDecoration.underline,
                  ),
                ),
                const SizedBox(height: 11),
                BaseText(
                  text: "External description:",
                  textColor: const Color(0xff27275A),
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  fontFamily: Constant.latoRegular,
                  maxLines: 1,
                ),
                const SizedBox(height: 5),
                ReadMoreTextWidget(
                  text: exItem.description,
                  textStyle: TextStyle(
                    color: Color(0xff666B9A),
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            );
          },
          separatorBuilder: (_, ind) => const SizedBox(height: 10),
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(0, 11, 0, 0),
          physics: const NeverScrollableScrollPhysics(),
        ),
      ],
    );
  }

  Widget _personalReflectionView(Achievement achieveItem) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ReadMoreTextWidget(
            text: achieveItem.personalReflection,
          ),
          const SizedBox(height: 10),
          BaseText(
            text:
                "Note : Personal Reflection is only for yourself, this is not sharable to anyone",
            textColor: const Color(0xff828282),
            fontWeight: FontWeight.w400,
            fontSize: 12,
            fontFamily: Constant.latoRegular,
            fontStyle: FontStyle.italic,
          ),
        ],
      ),
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      //  var formatter =   DateFormat('MMM dd, yyyy');
      //return formatter.format(new DateTime.now());
      return "Ongoing";
    }
  }

  int getLenthOfName() {
    int lenght = 0;
    if (_mPublicProfileDataModel.result == null) {
      return 0;
    } else {
      if (_mPublicProfileDataModel.result.lastName == null ||
          _mPublicProfileDataModel.result.lastName == "" ||
          _mPublicProfileDataModel.result.lastName == "null") {
        lenght = 0;
      } else {
        lenght = _mPublicProfileDataModel.result.firstName.length +
            _mPublicProfileDataModel.result.lastName.length;
      }
    }

    return lenght;
  }

  bool dobCheck(String time) {
    if (time != "null" || time != "") {
      int millis = int.tryParse(time);
      DateTime bod = DateTime.fromMillisecondsSinceEpoch(millis);
      int diffrenceInDob = DateTime.now().year - bod.year;

      DateTime currentDate = DateTime.now();
      int age = currentDate.year - bod.year;

      if (age > 13) {
        return true;
      }
      if (age == 13) {
        print("apurva equal" + '$age');
        int month1 = currentDate.month;
        int month2 = bod.month;
        if (month2 > month1) {
          print("apurva below" + '$age');
          _mPublicProfileDataModel.result.isDisplaySocialEmail = false;
          return false;
        } else if (month1 == month2) {
          int day1 = currentDate.day;
          int day2 = bod.day;
          if (day2 > day1) {
            print("apurva below" + '$age');
            _mPublicProfileDataModel.result.isDisplaySocialEmail = false;
            return false;
          } else {
            print("apurva equal or above" + '$age');
            return true;
          }
        } else {
          print("apurva equal or above" + '$age');
          return true;
        }
      } else {
        _mPublicProfileDataModel.result.isDisplaySocialEmail = false;
        return false;
      }
    } else {
      _mPublicProfileDataModel.result.isDisplaySocialEmail = false;
      return false;
    }
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        if (isGPA) {
          _mPublicProfileDataModel.result.isGpa = true;
        } else {
          _mPublicProfileDataModel.result.isGpa = false;
        }
        //assestList.removeAt(0);

        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "profileType": "Custom",
          "isProfileLinkExpire": !isLinkExpire,
          "profileView": isLinearView ? "Linear" : "Preso",
          "isSummary": true /*_mPublicProfileDataModel.result.isSummary*/,
          "isInterests": _mPublicProfileDataModel.result.isInterests,
          "isResume": _mPublicProfileDataModel.result.isResume,
          "isIntroVideo": _mPublicProfileDataModel.result.isIntroVideo,
          "education": {
            "isEducations": _mPublicProfileDataModel.result.isEducations,
            "isGpa": isGPA,
            "educationIds": _mPublicProfileDataModel.result.isEducations
                ? _mPublicProfileDataModel.result.educations.toJson()
                : []
          },
          "accomplishment": {
            "isAccomplishment":
                _mPublicProfileDataModel.result.isAccomplishment,
            "accomplishmentIds":
                _mPublicProfileDataModel.result.isAccomplishment
                    ? _mAcoomplismentDataModel.toJson()
                    : [],
            "sortOrder": _mPublicProfileDataModel.result.isAccomplishment
                ? _mAcoomplismentDataModel.toJsonSortOrder()
                : [],
            "categorySortOrder":
                _mPublicProfileDataModel.result.isAccomplishment
                    ? _mAcoomplismentDataModel.toJsonCategoryOrder()
                    : [],
          },
          "recommendation": {
            "isRecommendation":
                _mPublicProfileDataModel.result.isRecommendation,
            "recommendationIds":
                _mPublicProfileDataModel.result.isRecommendation
                    ? _mPublicProfileDataModel.result.toJsonRec()
                    : []
          },
          "badges": {
            "isBadges": _mPublicProfileDataModel.result.isBadges,
            "badgeReqIds": _mPublicProfileDataModel.result.badges == null ||
                    _mPublicProfileDataModel.result.badges.collections.length ==
                        0
                ? []
                : _mPublicProfileDataModel.result.isBadges
                    ? _mPublicProfileDataModel.result.badges.toJsonBadge()
                    : []
          },
          "testScore": {
            "isTestScore": _mPublicProfileDataModel.result.isTestScore,
            "userTestIds": _mPublicProfileDataModel.result.isTestScore
                ? _mPublicProfileDataModel.result.toJsonTestScore()
                : []
          },
          "skillAndCertification": {
            "isSkillAndCertification":
                _mPublicProfileDataModel.result.isSkillAndCertification,
            "certificateIds":
                _mPublicProfileDataModel.result.isSkillAndCertification
                    ? _mPublicProfileDataModel.result.toJsonCertificate()
                    : []
          },
          "socialLinks": {
            "isSocialLinks": _mPublicProfileDataModel.result.isSocialLinks,
            "isDisplaySocialEmail":
                _mPublicProfileDataModel.result.isDisplaySocialEmail,
            "socialLinkIds": _mPublicProfileDataModel.result.isSocialLinks
                ? _mPublicProfileDataModel.result.toJsonLink()
                : []
          },
          "linkExpirationDate": strDay == null || strDay == ""
              ? "0"
              : strDay == "Other"
                  ? otherDayController.text
                  : strDay
        };
        print("map++++:-" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_PROFILEL, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            String link = response.data["result"]["customProfileLink"];
            print("Link+++++++++++" + link);
            if (status == "Success") {
              if (isLinearView) {
                List<double> spiderChartList1 = List<double>();
                List<String> spiderChartName1 = List<String>();
                spiderChartList1.addAll(spiderChartList);
                spiderChartName1.addAll(spiderChartName);
                String result = await Navigator.of(context).push(
                    MaterialPageRoute(
                        builder: (BuildContext context) =>
                            CustomizeProfilePreViewWidget(
                              _mPublicProfileDataModel
                                  .result.isDisplaySocialEmail,
                              isGPA,
                              _mPublicProfileDataModel,
                              _mAcoomplismentDataModel,
                              link,
                              widget.userId,
                              studentProfile: widget.studentProfile,
                            )));

                if (result == "push") {
                  Navigator.pop(context);
                }
              } else {
                String shareId = link.split("/Preso/")[1];
                try {
                  Codec<String, String> stringToBase64 = utf8.fuse(base64);
                  String decodedSharedId =
                      stringToBase64.decode(shareId.replaceAll("&SPK", "="));
                  if (decodedSharedId != null && decodedSharedId != "") {
                    String result = await Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => CustomPresoViewForUser(
                          decodedSharedId,
                          "preview",
                          'Custom',
                          "false",
                          link,
                          studentProfile: widget.studentProfile,
                        ),
                      ),
                    );
                    if (result == "push") {
                      Navigator.pop(context);
                    }
                  }
                } catch (e) {
                  print('Exception 111 e: $e');
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("data errorr++++++++++++++" + e.toString());
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  linkExpireUI() {
    //UI for LinkExpire
    return PaddingWrap.paddingfromLTRB(
      13.0,
      13.0,
      13.0,
      13.0,
      Container(
          child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  border:
                      Border.all(color: ColorValues.BORDER_COLOR, width: 0.5)),
              child: PaddingWrap.paddingfromLTRB(
                  13.0,
                  13.0,
                  13.0,
                  4.0,
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            2.0,
                            10.0,
                            0.0,
                            Image.asset(
                              "assets/story_new/link.png",
                              width: 30,
                              height: 30,
                            )),
                        flex: 0,
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                TextViewWrap.textViewSingleLine(
                                    "Link expiration (days):",
                                    TextAlign.start,
                                    ColorValues.HEADING_COLOR_EDUCATION,
                                    16.0,
                                    FontWeight.bold)),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                5.0,
                                0.0,
                                7.0,
                                TextViewWrap.textViewMultiLine(
                                    "Set how long you want your link to be accessible once you share it. After that it will expire. ",
                                    TextAlign.start,
                                    ColorValues.GREY_TEXT_COLOR,
                                    14.0,
                                    FontWeight.bold,
                                    3)),
                            Row(
                              children: <Widget>[
                                InkWell(
                                  onTap: () {
                                    setState(() {
                                      if (counter > 1) counter--;
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color: ColorValues.BORDER_COLOR,
                                        border: Border.all(
                                            color: ColorValues.BORDER_COLOR,
                                            width: 0.5)),
                                    width: 25,
                                    height: 25,
                                    child: Center(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                          Image.asset(
                                            "assets/story_new/minus.png",
                                            width: 13.0,
                                            height: 2.0,
                                          )),
                                    ),
                                  ),
                                ),
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    13.0,
                                    13.0,
                                    13.0,
                                    TextViewWrap.textViewSingleLine(
                                        "$counter",
                                        TextAlign.start,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                        16.0,
                                        FontWeight.bold)),
                                InkWell(
                                  onTap: () {
                                    setState(() {
                                      counter++;
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color: ColorValues.BORDER_COLOR,
                                        border: Border.all(
                                            color: ColorValues.BORDER_COLOR,
                                            width: 0.5)),
                                    width: 25,
                                    height: 25,
                                    child: Center(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                          Image.asset(
                                            "assets/story_new/plus.png",
                                            width: 13.0,
                                            height: 13.0,
                                          )),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        flex: 1,
                      ),
                    ],
                  )))),
    );
  }
}
