import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/TestDataModel.dart';
import 'package:spike_view_project/modal/TestScoreModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:url_launcher/url_launcher.dart';

// Create a Form Widget
class UpdateTestScore extends StatefulWidget {
  List<TestDataModel> mainTestList;
  String sasToken, containerName, userId;

  UpdateTestScore(
      this.mainTestList, this.sasToken, this.containerName, this.userId);

  @override
  UpdateTestScoreState createState() {
    return     UpdateTestScoreState(mainTestList, sasToken, containerName);
  }
}

class UpdateTestScoreState extends State<UpdateTestScore> {
  UpdateTestScoreState(this.localListMain, this.sasToken, this.containerName);

  static const platform = const MethodChannel('samples.flutter.io/battery');

  final formKey = GlobalKey<FormState>();
  SharedPreferences prefs;
  String userIdPref, sasToken, containerName;
  List<TestDataModel> mainTestList =     List();
  List<TestDataModel> localListMain =     List();
  String strPrefixPathOrganization;
  File mediaImage, imagePath;
  DateTime startDate;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    String  dob = prefs.getString(UserPreference.DOB);

    if (dob != null&&dob != 'null'&&dob != '') {
      int d = int.tryParse(dob);
      startDate =     DateTime.fromMillisecondsSinceEpoch(d);
      setState(() {
        startDate;
      });
    } else {
      startDate =     DateTime.now();
    }
    userIdPref = widget.userId;
    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
    setState(() {});
  }

  //=========================================================Api Calling =======================================

  @override
  void initState() {
    // TODO: implement initState
    try {
      mainTestList = localListMain;
      for (TestDataModel model in mainTestList) {
        model.imgList.insert(0,null);
        model.docList.insert(0,null);
      }

      getSharedPreferences();
    } catch (e) {
      print(e.toString());
    }
    super.initState();
  }
  void showConfirmationAlert(userTestId) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>   WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:   SafeArea(
                child:   Scaffold(
                    backgroundColor: Colors.black38,
                    body:   Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:   Container(
                                height: 125.0,
                                color: Colors.transparent,
                                child:   Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 80.0,
                                            padding:   EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:   Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Are you sure you want to delete?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:   TextStyle(
                                                        color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR,
                                                        fontWeight:
                                                        FontWeight.normal),
                                                  ),

                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:   Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding:   EdgeInsets.all(10.0),
                                    height: 45.0,
                                    child:   Row(
                                      children: <Widget>[
                                        Expanded(
                                          child:   InkWell(
                                            child:   Container(
                                                child:   Text(
                                                  "No",
                                                  textAlign: TextAlign.center,
                                                  style:   TextStyle(
                                                      color:   ColorValues.GREY_TEXT_COLOR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child:   InkWell(
                                            child:   Container(
                                                child:   Text(
                                                  "Yes",
                                                  textAlign: TextAlign.center,
                                                  style:   TextStyle(
                                                      color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              deleteTest(userTestId);
                                              //share profile
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future deleteTest(userTestId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": userIdPref,
          "userTestId": userTestId,
        };
        print("map++++" + map.toString());
        Response response = await     ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_DELETE_TEST_SCORE_DATA, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              Navigator.pop(context, "push");
              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "userId": userIdPref,
          "testScores": mainTestList.map((item) => item.toJson()).toList(),
        };

        print("map+++" + map.toString());
        response = await     ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_TEST_SCORE_DATA, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              print("suceess");
              Navigator.pop(context, "push");
            } else {
              for (TestDataModel model in mainTestList) {
                model.imgList.insert(0,null);
                model.docList.insert(0,null);
              }
              setState(() {});
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      for (TestDataModel model in mainTestList) {
        model.imgList.insert(0,null);
        model.docList.insert(0,null);
      }
      setState(() {});
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    onBack() {
      for (TestDataModel model in mainTestList) {
        model.imgList.removeAt(0);
        model.docList.removeAt(0);
      }

      Navigator.pop(context);
    }

    validateMethod(SubjectListModel model, value) {
      if (value >= model.minScore && value <= model.maxScore) {
        return null;
      }

      return "Please enter value between " +
          model.minScore.toString() +
          "-" +
          model.maxScore.toString();
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
      @required TestDataModel dataModel,
    }) async {
      setState(() {});

      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathOrganization);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        String path = strPrefixPathOrganization + strAzureImageUploadPath;
        if (type == "image") {
         // dataModel.imgList.removeLast();
          dataModel.imgList.add(path);
         // dataModel.imgList.add(null);
          setState(() {
            dataModel;
          });
        } else {
         // dataModel.docList.removeLast();
          dataModel.docList.add(path);
         // dataModel.docList.add(null);
          setState(() {
            dataModel;
          });
        }
        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }


    onTapImageAddButton(TestDataModel dataModel) async {
      mediaImage = await UploadMedia(context).pickImageFromGallery();

    //  mediaImage = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (mediaImage != null) {
        imagePath = mediaImage;
        //   await _cropImage(mediaImage);
        if (imagePath != null) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =     Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                dataModel: dataModel,
                type: "image");
          });
        }
      } else {
        //ToastWrap.showToast("'No file was selected'", context);
      }
    }

    getDocuments(TestDataModel dataModel) async {
      try {
        // Platform messages may fail, so we use a try/catch PlatformException.
        try {
          FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
            allowedFileExtensions: ['pdf'],
            allowedMimeTypes: ['application/pdf'],
            invalidFileNameSymbols: ['/'],
          );

          String path =
              await FlutterDocumentPicker.openDocument(params: params);
          if (path != null && path != "") {
            if ((Util.getFileExtension(path) == ".pdf" ) &&
                path != null) {
              print("path+++++" + path.toString());

              CustomProgressLoader.showLoader(context);
              Timer _timer =     Timer(const Duration(milliseconds: 400), () {
                checkMediaAndUpload(
                    imagePath: path
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    dataModel: dataModel,
                    type: "doc");
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.INVALID_FILE_FORMAT_VAL, context);
            }
          }
        } catch (e) {
          ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
        }
      } catch (e) {
        ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
      }
    }

    void conformationDialog(type, file, index) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>     WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:     SafeArea(
                  child:     Scaffold(
                      backgroundColor: Colors.black38,
                      body:     Stack(
                        children: <Widget>[
                              Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:     Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:     Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                                Container(
                                              height: 145.0,
                                              padding:     EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:     Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                        Text(
                                                      MessageConstant.REMOVE_NAME,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:    AppTextStyle.getDynamicStyleGroupHEIGHT(ColorValues.HEADING_COLOR_EDUCATION,16.0,FontType.Regular, 1.2),/* TextStyle(
                                                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),*/
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                              Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:     Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                      Container(
                                      color: Colors.white,
                                      padding:     EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:     Row(
                                        children: <Widget>[
                                              Expanded(
                                            child:     InkWell(
                                              child:     Container(
                                                  child:     Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style:    AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,16.0,FontType.Regular), /*TextStyle(
                                                    color:     ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                              Expanded(
                                            child:     InkWell(
                                              child:     Container(
                                                  child:     Text(
                                                    MessageConstant.REMOVE,
                                                textAlign: TextAlign.center,
                                                style:    AppTextStyle.getDynamicStyleGroup(ColorValues.BLUE_COLOR_BOTTOMBAR,16.0,FontType.Regular),   /*TextStyle(
                                                    color:     ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (type == "image")
                                                  mainTestList[index]
                                                      .imgList
                                                      .remove(file);
                                                else
                                                  mainTestList[index]
                                                      .docList
                                                      .remove(file);

                                                setState(() {});
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void _checkValidation() async {
      print("checking");
      final form = formKey.currentState;
      form.save();

      if (form.validate()) {
        for (TestDataModel model in mainTestList) {
          model.imgList.removeAt(0);
          model.docList.removeAt(0);
        }
        apiCalling();
      } else {
        print("not validate..");
      }
    }

    Future<Null> selectDob(BuildContext context,int index2) async {
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text(MessageConstant.CANCEL, style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime:     DateTime.now(),
        initialDateTime:     DateTime.now() ,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());

          if (dateTime != null) {

            mainTestList[index2].longDate = dateTime.millisecondsSinceEpoch.toString();
            String date = Util.getDate(dateTime);
            mainTestList[index2].dateTaken=date;
            setState(() {
              mainTestList;
            });
          } else {
            FocusScope.of(context).requestFocus(new FocusNode());
          }
        },
      );
    }

    //-------------------------------------Main Ui ------------------------------------------
    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:     Scaffold(
            backgroundColor:     ColorValues.SCREEN_BG_COLOR,
            appBar:     AppBar(
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              elevation: 0.0,
              titleSpacing: 0.0,
              title:     Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                      Expanded(
                    child:     InkWell(
                      child:     SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                                Center(
                                child:     Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        onBack();
                      },
                    ),
                    flex: 0,
                  ),
                      Expanded(
                    child:     Text(
                      MessageConstant.TEXT_SCORE_TEST_SCORE,
                      textAlign: TextAlign.center,
                      style:      AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,16.0,FontType.Regular), /* TextStyle(
                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                    Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                        InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          13.0,
                          0.0,
                          TextViewWrap.textView(
                              "Update",
                              TextAlign.start,
                                  ColorValues.BLUE_COLOR_BOTTOMBAR,
                              16.0,
                              FontWeight.normal)),
                      onTap: () {
                        _checkValidation();
                      },
                    )
                  ],
                )
              ],
              backgroundColor: Colors.white,
            ),
            body: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  FocusScopeNode currentFocus = FocusScope.of(context);

                  if (!currentFocus.hasPrimaryFocus &&
                      currentFocus.focusedChild != null) {
                    FocusManager.instance.primaryFocus.unfocus();
                  }
                },
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    5.0,
                        Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        CustomViews.getSepratorLine(),
                            Expanded(
                          child: ListView(
                            children: <Widget>[
                                  Container(
                                  width: double.infinity,
                                  child: PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    10.0,
                                    0.0,
                                    20.0,
                                    Form(
                                        key: formKey,
                                        child:     Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                                  Container(
                                                  child:
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              0.0,
                                                              12.0,
                                                              0.0,
                                                              0.0,
                                                                  Column(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: <
                                                                    Widget>[
                                                                  PaddingWrap.paddingfromLTRB(
                                                                      0.0,
                                                                      10.0,
                                                                      0.0,
                                                                      0.0,
                                                                          Column(
                                                                          children:     List.generate(mainTestList.length, (index3) {
                                                                        return Padding(
                                                                          padding: const EdgeInsets.fromLTRB(
                                                                              0,
                                                                              0,
                                                                              0,
                                                                              20),
                                                                          child:
                                                                                  Stack(
                                                                            children: <Widget>[
                                                                              PaddingWrap.paddingfromLTRB(
                                                                                  0.0,
                                                                                  10.0,
                                                                                  13.0,
                                                                                  0.0,
                                                                                      Container(
                                                                                      decoration:     BoxDecoration(color: Colors.white, border:     Border.all(color:     ColorValues.BORDER_COLOR, width: 0.5)),
                                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                                          0.0,
                                                                                          0.0,
                                                                                          0.0,
                                                                                          0.0,
                                                                                              Column(
                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                            children: <Widget>[
                                                                                              PaddingWrap.paddingfromLTRB(
                                                                                                  10.0,
                                                                                                  20.0,
                                                                                                  0.0,
                                                                                                  8.0,
                                                                                                      Container(
                                                                                                    padding:     EdgeInsets.only(left: 0.0, top: 5.0, right: 0.0, bottom: 0.0),
                                                                                                    child:     TextField(
                                                                                                      keyboardType: TextInputType.text,
                                                                                                      controller:     TextEditingController(text: mainTestList[index3].dateTaken),
                                                                                                      readOnly: true,
                                                                                                      onTap: () {
                                                                                                        selectDob(context,index3);
                                                                                                      },
                                                                                                      style:     TextStyle(color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                      decoration:     InputDecoration(
                                                                                                        labelText: MessageConstant.TEXT_SCORE_DATE_TAKEN,
                                                                                                        errorStyle: Util.errorTextStyle,
                                                                                                        contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                                                                                                        focusedBorder:     UnderlineInputBorder(borderSide:     BorderSide(color:     ColorValues.DARK_GREY, width: 1.0)),
                                                                                                        disabledBorder:     UnderlineInputBorder(borderSide:     BorderSide(color:     ColorValues.DARK_GREY, width: 1.0)),
                                                                                                        labelStyle:     TextStyle(color:     ColorValues.GREY_TEXT_COLOR, fontFamily: Constant.TYPE_CUSTOMREGULAR, fontSize: 14.0),
                                                                                                      ),
                                                                                                    ),
                                                                                                  )),
                                                                                                  Column(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                      Column(
                                                                                                      children:     List.generate(mainTestList[index3].subjectListModel.length, (index2) {
                                                                                                    return Container(
                                                                                                        child: PaddingWrap.paddingfromLTRB(
                                                                                                            10.0,
                                                                                                            10.0,
                                                                                                            10.0,
                                                                                                            10.0,
                                                                                                            Container(
                                                                                                              child:     TextFormField(
                                                                                                                textAlign: TextAlign.start,
                                                                                                                keyboardType: TextInputType.number,
                                                                                                                controller: mainTestList[index3].subjectListModel[index2].textEditingController,
                                                                                                                maxLength: 10,
                                                                                                                inputFormatters: <TextInputFormatter>[
                                                                                                                  WhitelistingTextInputFormatter.digitsOnly

                                                                                                                ],
                                                                                                                cursorColor: Constant.CURSOR_COLOR,
                                                                                                                validator: (val) => mainTestList[index3].subjectListModel[index2].isOptional && (val == null || val == "") ? null : validateMethod(mainTestList[index3].subjectListModel[index2], val != null && val != "" ? int.parse(val) : 0),
                                                                                                                style:     TextStyle(color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                                decoration:     InputDecoration(
                                                                                                                  contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                                                                                                                  counterText: "",
                                                                                                                  counterStyle:     TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                                  labelText: mainTestList[index3].subjectListModel[index2].subjectName + " (" + mainTestList[index3].subjectListModel[index2].minScore.toString() + "-" + mainTestList[index3].subjectListModel[index2].maxScore.toString() + ")",
                                                                                                                  errorStyle: Util.errorTextStyle,
                                                                                                                  labelStyle:     TextStyle(color:     ColorValues.GREY_TEXT_COLOR, fontFamily: Constant.TYPE_CUSTOMREGULAR, fontSize: 14.0),
                                                                                                                  focusedBorder:     UnderlineInputBorder(borderSide:     BorderSide(color:     ColorValues.DARK_GREY, width: 1.0)),
                                                                                                                  enabledBorder:     UnderlineInputBorder(borderSide:     BorderSide(color:     ColorValues.DARK_GREY, width: 1.0)),
                                                                                                                ),
                                                                                                              ),
                                                                                                            )));
                                                                                                  })),
                                                                                                ],
                                                                                              ),
                                                                                              PaddingWrap.paddingfromLTRB(
                                                                                                  10.0,
                                                                                                  20.0,
                                                                                                  0.0,
                                                                                                  10.0,
                                                                                                  Text(
                                                                                                    MessageConstant.TEXT_SCORE_DOCUMENTS,
                                                                                                    style: AppTextStyle.getDynamicFontStyle(Palette.primaryTextColor, 14, FontType.Regular),
                                                                                                  )),
                                                                                                  Container(
                                                                                                  padding:     EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                                                                                                  child:     GridView.count(
                                                                                                    primary: false,
                                                                                                    shrinkWrap: true,
                                                                                                    padding: const EdgeInsets.all(0.0),
                                                                                                    crossAxisSpacing: 10.0,
                                                                                                    childAspectRatio: 1.50,
                                                                                                    scrollDirection: Axis.vertical,
                                                                                                    crossAxisCount: 4,
                                                                                                    children: mainTestList[index3].docList.map((file) {
                                                                                                      if (file == null) {
                                                                                                        return     Stack(children: <Widget>[
                                                                                                              InkWell(
                                                                                                            child: Padding(
                                                                                                                padding: const EdgeInsets.fromLTRB(7.0, 5, 20, 0),
                                                                                                                child:     Container(
                                                                                                                    height: 54.0,
                                                                                                                    width: 58.0,
                                                                                                                    decoration:     BoxDecoration(border:     Border.all(color:     ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                                                                                                    child:     Image.asset(
                                                                                                                      "assets/newDesignIcon/userprofile/add.png",
                                                                                                                      height: 25.0,
                                                                                                                      width: 25.0,
                                                                                                                    ))),
                                                                                                            onTap: () async{
                                                                                                              if (mainTestList[index3].docList.length <= 5) {
                                                                                                                getDocuments(mainTestList[index3]);
                                                                                                             /*   var status = await Permission.storage.status;
                                                                                                                if (status.isGranted) {
                                                                                                                  getDocuments(mainTestList[index3]);
                                                                                                                }  else {
                                                                                                                  checkStoragePermissionStorage(context);
                                                                                                                }*/
                                                                                                              } else {
                                                                                                                ToastWrap.showToast(MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
                                                                                                              }
                                                                                                            },
                                                                                                          )
                                                                                                        ]);
                                                                                                      } else {
                                                                                                        return     Stack(
                                                                                                          children: <Widget>[
                                                                                                            Padding(
                                                                                                                padding: const EdgeInsets.fromLTRB(7.0, 5, 20, 0),
                                                                                                                child:     Container(
                                                                                                                    decoration:     BoxDecoration(border:     Border.all(color:     ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                                                                                                    child:     InkWell(
                                                                                                                      child: Padding(
                                                                                                                        padding: const EdgeInsets.all(5.0),
                                                                                                                        child:     Container(
                                                                                                                            height: 58.0,
                                                                                                                            width: 58.0,
                                                                                                                            child:     Image.asset(
                                                                                                                              "assets/newDesignIcon/patner/pdf.png",
                                                                                                                              height: 58.0,
                                                                                                                              width: 58.0,
                                                                                                                            )),
                                                                                                                      ),
                                                                                                                      onTap: () {
                                                                                                                        launch(Constant.IMAGE_PATH + file);
                                                                                                                      },
                                                                                                                    ))),
                                                                                                                Positioned(
                                                                                                                right: 10.0,
                                                                                                                top: 0.0,
                                                                                                                child:     Container(
                                                                                                                    height: 20.0,
                                                                                                                    width: 20.0,
                                                                                                                    child:     Center(
                                                                                                                        child:     Row(
                                                                                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                      children: <Widget>[
                                                                                                                            InkWell(
                                                                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                                                                0.0,
                                                                                                                                0.0,
                                                                                                                                0.0,
                                                                                                                                0.0,
                                                                                                                                    Image.asset(
                                                                                                                                  "assets/remove_grey.png",
                                                                                                                                  width: 20.0,
                                                                                                                                  height: 20.0,
                                                                                                                                )),
                                                                                                                            onTap: () {
                                                                                                                              conformationDialog("doc", file, index3);
                                                                                                                            })
                                                                                                                      ],
                                                                                                                    )))),
                                                                                                          ],
                                                                                                        );
                                                                                                      }
                                                                                                    }).toList(),
                                                                                                  )),
                                                                                              PaddingWrap.paddingfromLTRB(
                                                                                                  10.0,
                                                                                                  20.0,
                                                                                                  0.0,
                                                                                                  10.0,
                                                                                                  Text(
                                                                                                    MessageConstant.TEXT_SCORE_PHOTOS,
                                                                                                    style: AppTextStyle.getDynamicFontStyle(Palette.primaryTextColor, 14, FontType.Regular),
                                                                                                  )),
                                                                                                  Container(
                                                                                                  padding:     EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                                                                                                  child:     GridView.count(
                                                                                                    primary: false,
                                                                                                    shrinkWrap: true,
                                                                                                    padding: const EdgeInsets.all(0.0),
                                                                                                    crossAxisSpacing: 10.0,
                                                                                                    childAspectRatio: 1.50,
                                                                                                    scrollDirection: Axis.vertical,
                                                                                                    crossAxisCount: 3,
                                                                                                    children: mainTestList[index3].imgList.map((file) {
                                                                                                      if (file == null) {
                                                                                                        return     Stack(children: <Widget>[
                                                                                                              InkWell(
                                                                                                            child: Padding(
                                                                                                              padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                                                                                                              child:     Container(
                                                                                                                  height: 54.0,
                                                                                                                  width: 80.0,
                                                                                                                  decoration:     BoxDecoration(border:     Border.all(color:     ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                                                                                                  child:     Image.asset(
                                                                                                                    "assets/newDesignIcon/userprofile/add.png",
                                                                                                                    height: 25.0,
                                                                                                                    width: 25.0,
                                                                                                                  )),
                                                                                                            ),
                                                                                                            onTap: () async{
                                                                                                              var status = await Permission.photos.status;
                                                                                                              if (status.isGranted) {
                                                                                                                onTapImageAddButton(mainTestList[index3]);
                                                                                                              }  else {
                                                                                                                checkPermissionPhoto(context);
                                                                                                              }

                                                                                                            },
                                                                                                          )
                                                                                                        ]);
                                                                                                      } else {
                                                                                                        return     Container(
                                                                                                            height: 60.0,
                                                                                                            child:     Stack(
                                                                                                              children: <Widget>[
                                                                                                                    Positioned(
                                                                                                                  top: 5.0,
                                                                                                                  child:     Column(
                                                                                                                    children: <Widget>[
                                                                                                                      FadeInImage.assetNetwork(
                                                                                                                        fit: BoxFit.cover,
                                                                                                                        placeholder: 'assets/aerial/default_img.png',
                                                                                                                        image: Constant.IMAGE_PATH + file,
                                                                                                                        height: 50.0,
                                                                                                                        width: 75.0,
                                                                                                                      ),
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                ),
                                                                                                                Padding(
                                                                                                                  padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                                                                                                                  child:     Container(
                                                                                                                    height: 50.0,
                                                                                                                    width: 75.0,
                                                                                                                    color:     Color(0XFFC0C0C0).withOpacity(.4),
                                                                                                                  ),
                                                                                                                ),
                                                                                                                    Positioned(
                                                                                                                    right: 20.0,
                                                                                                                    top: 0.0,
                                                                                                                    bottom: 0.0,
                                                                                                                    left: 0.0,
                                                                                                                    child:     Container(
                                                                                                                        height: 20.0,
                                                                                                                        width: 20.0,
                                                                                                                        child:     Center(
                                                                                                                            child:     Row(
                                                                                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                          mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                          children: <Widget>[
                                                                                                                                InkWell(
                                                                                                                                child: PaddingWrap.paddingfromLTRB(
                                                                                                                                    0.0,
                                                                                                                                    0.0,
                                                                                                                                    0.0,
                                                                                                                                    0.0,
                                                                                                                                        Image.asset(
                                                                                                                                      "assets/remove_grey.png",
                                                                                                                                      width: 20.0,
                                                                                                                                      height: 20.0,
                                                                                                                                    )),
                                                                                                                                onTap: () {
                                                                                                                                  conformationDialog("image", file, index3);
                                                                                                                                })
                                                                                                                          ],
                                                                                                                        )))),
                                                                                                              ],
                                                                                                            ));
                                                                                                      }
                                                                                                    }).toList(),
                                                                                                  )),
                                                                                            ],
                                                                                          )))),
                                                                                  Positioned(
                                                                                  top: 0.0,
                                                                                  right: 0.0,
                                                                                  child:     InkWell(
                                                                                    child:     Container(
                                                                                        height: 30.0,
                                                                                        width: 30.0,
                                                                                        child: Icon(
                                                                                          Icons.cancel,
                                                                                          color: Colors.grey,
                                                                                          size: 30.0,
                                                                                        )),
                                                                                    onTap: () {
                                                                                      showConfirmationAlert(mainTestList[index3].userTestId);

                                                                                    },
                                                                                  ))
                                                                            ],
                                                                          ),
                                                                        );
                                                                      }))),

                                                                  // CustomViews.getSepratorLine()
                                                                ],
                                                              )))
                                            ])),
                                  )),
                            ],
                          ),
                          flex: 1,
                        )
                      ],
                    )))));
  }
}
