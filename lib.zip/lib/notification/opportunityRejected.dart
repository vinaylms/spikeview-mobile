import 'dart:async';
import 'package:dio/dio.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_advisor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_mentor_opportunity_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_opportunity_view.dart';

import 'package:flutter/material.dart';

import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';

import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

import 'package:spike_view_project/notification/model/NotificationModel.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';

import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/patnerFlow/opportunity/update_tutor_opportunity_view.dart';

import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/widgets/positive_button.dart';


class opportunityRejected extends StatefulWidget {
  String opportunityId, pageName;


  opportunityRejected(this.pageName, this.opportunityId);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  opportunityRejectedState();
  }
}

class opportunityRejectedState extends State<opportunityRejected> {
  List<NotificationModel> dataList =  List();
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  String userIdPref, roleId;
  OpportunityModelForFeed _mOpportunityModelForFeed;
  String rejectionReason='';


  Future callGetOpportunityDetailsAPI() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'callGetOpportunityDetailsAPI URL:: ${Constant.ENDPOINT_Opportunity_detail_api}${widget.opportunityId}');
        CustomProgressLoader.showLoader(context);
        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_Opportunity_detail_api + widget.opportunityId,
            "get");
        CustomProgressLoader.cancelLoader(context);
        print("callGetOpportunityDetailsAPI data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            print('Status:: $status');

            _mOpportunityModelForFeed = ParseJson.parseOpportunityDetailData(
                response.data['result'], userIdPref, "1");
            if (_mOpportunityModelForFeed != null) {
              rejectionReason=_mOpportunityModelForFeed.declineReason.toString();
              print("callGetOpportunityDetailsAPI data" + rejectionReason.toString());
            }
            setState(() {
              rejectionReason;
              _mOpportunityModelForFeed;
            });
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }

  getSharedPreferences() async {


    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
   await callGetOpportunityDetailsAPI();

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getSharedPreferences();
    print("==================== INIT STATE");
  }



  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    callUpdateOldForms() async {
      String result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
           UpdateOpportunity( null,_mOpportunityModelForFeed.category,"edit",opportunityId:widget.opportunityId,)));

    }

    updateMentorOpportunity() async {
      String result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
           UpdateMentorOpportunity(null,"edit",opportunityId:widget.opportunityId,)));


    }

    updateTutorOpportunity() async {
      String result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
           UpdateTutorOpportunity(null,"edit",opportunityId:widget.opportunityId,)));

    }

    updateAdvisorOpportunity() async {
      String result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
           UpdateAdvisorOpportunity(null,"edit",opportunityId:widget.opportunityId,)));


    }


    activateAgain() async {
print("_mOpportunityModelForFeed.name----------"+_mOpportunityModelForFeed.name);
      int switchIndex = int.parse(_mOpportunityModelForFeed.offerId);
      switch (switchIndex) {
        case 1:
          callUpdateOldForms();
          break;
        case 2:
          callUpdateOldForms();
          break;
        case 3:
          callUpdateOldForms();
          break;
        case 4:
          callUpdateOldForms();
          break;
        case 5:
          callUpdateOldForms();
          break;
        case 6:
          updateTutorOpportunity();
          break;
        case 7:
          updateMentorOpportunity();
          break;
        case 8:
          updateAdvisorOpportunity();
          break;
      }
    }


    return   WillPopScope(
        onWillPop: () {
          if(widget.pageName == 'main'){
            Navigator.pushReplacement(
              //Constant.applicationContext,
                context,
                MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) =>  DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));
          }else
            Navigator.pop(context);        },

        child:customAppbar(
          context,
          GestureDetector(
              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20, top: 24, bottom: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox()
                          // BaseText(
                          //   text:"${opportunity.status} opportunity",
                          //   textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          //   fontFamily: AppConstants.stringConstant.latoMedium,
                          //   fontWeight: FontWeight.w700,
                          //   fontSize: 28,
                          //   textAlign: TextAlign.start,
                          //   maxLines: 3,
                          // ),
                        ],
                      ),
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Padding(
                        padding: const EdgeInsets.only(left: 20.0, right: 20),
                        child:SingleChildScrollView(
                          child: Container(
                            child:  Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    Text("Opportunity not approved",
                                      //: "College Counselling",
                                      style: TextStyle(
                                          fontSize: 28,
                                          fontFamily: Constant
                                              .customBold,
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1),
                                    ),


                                    SizedBox(height: 10,),



                                    Text(
                                      "Please see comments below, make the updates and resubmit for approval.",
                                      textAlign: TextAlign.start,
                                      style:  TextStyle(
                                          color:  ColorValues.labelColor,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.w400,
                                          fontFamily:Constant.latoRegular),
                                    ),

                                    SizedBox(height: 30,),

                                    Text(
                                      "Reason :",
                                      textAlign: TextAlign.left,
                                      style:  TextStyle(
                                          color:  ColorValues.labelColor,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.w600,
                                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                    ),


                                    SizedBox(height: 10,),

                                    RichText(
                                      text:  TextSpan(
                                          text:rejectionReason.toString() != 'null' ? "$rejectionReason" :"" ,
                                          style:  TextStyle(
                                              fontSize: 14,
                                              fontFamily: Constant
                                                  .latoRegular,
                                              fontWeight: FontWeight.w500,
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1),
                                          children: [
                                            TextSpan(
                                              text: "",
                                            )
                                          ]),
                                    ),

                                    /*
                                      Padding(
                                        padding: const EdgeInsets.only(top: 20.0, bottom: 0.0),
                                        child: Container(
                                          width: MediaQuery.of(context).size.width,
                                          decoration:  BoxDecoration(
                                            color: Colors.white, ),
                                          padding: const EdgeInsets.symmetric(horizontal: 13.0, vertical: 20.0),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: <Widget>[
                                              Padding(
                                                padding: const EdgeInsets.only(top: 0.0, bottom: 15.0),
                                                child: Text(
                                                  "Reason :",
                                                  textAlign: TextAlign.left,
                                                  style:  TextStyle(
                                                      color:  ColorValues.RADIO_BLACK,
                                                      fontSize: 16.0,
                                                      fontWeight: FontWeight.w600,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                              ),




                                              Text(
                                                rejectionReason.toString() != 'null' ? "$rejectionReason" :"",
                                                textAlign: TextAlign.left,
                                                style:  TextStyle(
                                                    color:  ColorValues.RADIO_BLACK,
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              ),
                                            ],
                                          ),
                                        ),

                                      ),

                                       */


                                    SizedBox(height: 30,),



                                    RichText(
                                      text:  TextSpan(
                                        text:"For additional questions email ",
                                        style:  TextStyle(
                                            fontSize: 14,
                                            fontFamily: Constant
                                                .latoRegular,
                                            fontWeight: FontWeight.w500,
                                            color: ColorValues
                                                .labelColor),
                                        children: <TextSpan>[
                                          TextSpan(
                                            text: "team@spikeview.com",
                                            style:  TextStyle(
                                                color:  ColorValues.light_grey,
                                                fontSize: 14.0,
                                                fontFamily: Constant.latoSemibold),
                                          ),

                                        ],
                                      ),
                                    ),

                                    /*

                                      Padding(
                                          padding: const EdgeInsets.only(top: 10.0, bottom: 40.0),
                                          child: RichText(
                                            maxLines: 8,
                                            textAlign: TextAlign.center,
                                            text: TextSpan(
                                              text:  "For additional questions email ",
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY__COLOR,
                                                  fontSize: 12.0,
                                                  fontWeight: FontWeight.w400,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: "team@spikeview.com",
                                                  style:  TextStyle(
                                                      color:  ColorValues.GREY__COLOR,
                                                      fontSize: 12.0,
                                                      fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                ),

                                              ],
                                            ),
                                          )


                                      ),

                                       */

                                    SizedBox(height: 100,),



                                    SizedBox(
                                      height: 44,
                                      child: PositiveButton(
                                        onTap: (){
                                          if(_mOpportunityModelForFeed!=null)
                                            activateAgain();
                                        },
                                        // isEnable: true,
                                        isEnable: true,
                                        title: 'Edit Opportunity' ,
                                      ),
                                    ),

                                    /*
                                      InkWell(
                                        onTap: (){
                                          if(_mOpportunityModelForFeed!=null)
                                            activateAgain();
                                        },
                                        child:  Container(
                                            height: 35.0,
                                            //width: 226.0,
                                            color:  ColorValues.BLUE_COLOR,
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .center,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .center,
                                              children: <Widget>[
                                                Text(
                                                  "Edit Opportunity",
                                                  style:  TextStyle(
                                                    color: Colors.white,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 16.0,
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                )
                                              ],
                                            )),
                                      ),

                                       */

                                  ],
                                )

                              ],
                            ),
                          ),
                        )
                    ),
                    flex: 1,
                  ),
                ],
              )),
              () {
            Navigator.pop(context);
          },
          isShowIcon: false,
        )
    );

    /*
    return  WillPopScope(
        onWillPop: () {

            if(widget.pageName == 'main'){
              Navigator.pushReplacement(
                //Constant.applicationContext,
                  context,
                   MaterialPageRoute(
                    //   builder: (context) =>  DashBoardWidget()));
                      builder: (context) =>  DashBoardWidgetPartner(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          currentPage: Constant.PROFILE_TYPE)));
            }else
            Navigator.pop(context);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,

              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    flex: 0,
                    child:  InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        if(widget.pageName == 'main'){
                          Navigator.pushReplacement(
                            //Constant.applicationContext,
                              context,
                               MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) =>  DashBoardWidgetPartner(
                                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                      prefs.getString(UserPreference.IS_USER_ROLE),
                                      currentPage: Constant.PROFILE_TYPE)));
                        }else
                          Navigator.pop(context);
                      },
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Center(
                      child:  Image.asset(
                        "assets/newDesignIcon/blue_spike_logo.png",
                        width: 114.0,
                        height: 29.0,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 0,
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),),
                  ),
                ],
              ),

              backgroundColor: Colors.white,
              elevation: 0.0,
            ),
            body: Container(
              //color: Color(0xffDADADA),
              child: Column(
                children: <Widget>[
                  CustomViews.getSepratorLine(),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 0.0),
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [

                        Padding(
                          padding: const EdgeInsets.only(top: 20.0, bottom: 5.0),
                          child: Text(
                            "Opportunity not approved",
                            textAlign: TextAlign.center,
                            style:  TextStyle(
                                color:  ColorValues.RADIO_BLACK,
                                fontSize: 18.0,
                                fontWeight: FontWeight.w600,
                                fontFamily:Constant.TYPE_CUSTOMREGULAR),
                          ),
                        ),
                        Text(
                          "Please see comments below, make the updates and resubmit for approval.",
                          textAlign: TextAlign.center,
                          style:  TextStyle(
                              color:  ColorValues.GREY__COLOR,
                              fontSize: 12.0,
                              fontWeight: FontWeight.w400,
                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 20.0, bottom: 0.0),
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            decoration:  BoxDecoration(
                              color: Colors.white,
                              border:  Border.all(
                                  color:  ColorValues.BORDER_COLOR, width: 1.0), ),
                            padding: const EdgeInsets.symmetric(horizontal: 13.0, vertical: 20.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(top: 0.0, bottom: 15.0),
                                child: Text(
                                  "Reason :",
                                  textAlign: TextAlign.left,
                                  style:  TextStyle(
                                      color:  ColorValues.RADIO_BLACK,
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w600,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                ),
                              ),
                              Text(
                                rejectionReason.toString() != 'null' ? "$rejectionReason" :"",
                                textAlign: TextAlign.left,
                                style:  TextStyle(
                                    color:  ColorValues.RADIO_BLACK,
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w400,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                              ),
                            ],
                          ),
                          ),

                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 10.0, bottom: 40.0),
                          child: RichText(
                            maxLines: 8,
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text:  "For additional questions email ",
                              style:  TextStyle(
                                  color:  ColorValues.GREY__COLOR,
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.w400,
                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                children: <TextSpan>[
                              TextSpan(
                                text: "team@spikeview.com",
                                style:  TextStyle(
                                    color:  ColorValues.GREY__COLOR,
                                    fontSize: 12.0,
                                    fontFamily: Constant.TYPE_CUSTOMBOLD),
                              ),

                            ],
                            ),
                          )




                        ),

                        InkWell(
                          onTap: (){
                            if(_mOpportunityModelForFeed!=null)
                            activateAgain();
                            },
                          child:  Container(
                              height: 35.0,
                              //width: 226.0,
                              color:  ColorValues.BLUE_COLOR,
                              child:  Row(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .center,
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .center,
                                children: <Widget>[
                                   Text(
                                    "Edit Opportunity",
                                    style:  TextStyle(
                                        color: Colors.white,
                                        fontFamily:
                                        Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 16.0,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  )
                                ],
                              )),
                        ),

                      ],
                    ),
                  ),
                ],
              ),
            )));

     */


  }




}
