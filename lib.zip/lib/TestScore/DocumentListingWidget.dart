import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/TestDataModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:url_launcher/url_launcher.dart';

class DocumentListingWidget extends StatefulWidget {
  TestDataModel testModel;

  DocumentListingWidget(this.testModel);

  @override
  DocumentListingWidgetState createState() {
    return     DocumentListingWidgetState(testModel);
  }
}

class DocumentListingWidgetState extends State<DocumentListingWidget> {
  TestDataModel testModel;
  static const platform = const MethodChannel('samples.flutter.io/battery');

  DocumentListingWidgetState(this.testModel);

  //=========================================================Api Calling =======================================

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    //-------------------------------------Main Ui ------------------------------------------
    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:     Scaffold(
            backgroundColor:     ColorValues.SCREEN_BG_COLOR,
            appBar:     AppBar(
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              elevation: 0.0,
              titleSpacing: 0.0,
              title:     Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                      Expanded(
                    child:     InkWell(
                      child:     SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                                Center(
                                child:     Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                    flex: 0,
                  ),
                      Expanded(
                    child:     Text(
                      MessageConstant.TEXT_SCORE_VIEW_PHOTOS,
                      textAlign: TextAlign.center,
                      style:   AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,18.0,FontType.Regular)   /*TextStyle(
                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                    Container(
                  width: 30.0,
                )
              ],
              backgroundColor: Colors.white,
            ),
            body: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                5.0,
                    Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    CustomViews.getSepratorLine(),
                        Expanded(
                      child: ListView(
                        children: <Widget>[
                          testModel.docList.length > 0
                              ? PaddingWrap.paddingfromLTRB(
                                  15.0,
                                  20.0,
                                  0.0,
                                  10.0,
                                  Text(
                                   MessageConstant.TEXT_SCORE_DOCUMENTS,
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.secondaryTextColor,
                                        14,
                                        FontType.Regular),
                                  ))
                              :     Container(
                                  height: 0.0,
                                ),
                              Container(
                              padding:
                                      EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                              child:     GridView.count(
                                primary: false,
                                shrinkWrap: true,
                                padding: const EdgeInsets.all(0.0),
                                crossAxisSpacing: 10.0,
                                childAspectRatio: 1.50,
                                scrollDirection: Axis.vertical,
                                crossAxisCount: 4,
                                children: testModel.docList.map((file) {
                                  return     Stack(
                                    children: <Widget>[
                                      Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              7.0, 5, 20, 0),
                                          child:     Container(
                                              decoration:     BoxDecoration(
                                                  border:     Border.all(
                                                      color:     Color(
                                                          0XFFE9E9EC))),
                                              child:     InkWell(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(5.0),
                                                  child:     Container(
                                                      height: 58.0,
                                                      width: 58.0,
                                                      child:     Image.asset(
                                                        "assets/newDesignIcon/patner/pdf.png",
                                                        height: 58.0,
                                                        width: 58.0,
                                                      )),
                                                ),
                                                onTap: () {
                                                  launch(Constant.IMAGE_PATH +
                                                      file);
                                                },
                                              ))),
                                    ],
                                  );
                                }).toList(),
                              )),
                          testModel.imgList.length > 0
                              ? PaddingWrap.paddingfromLTRB(
                                  15.0,
                                  20.0,
                                  0.0,
                                  10.0,
                                  Text(
                                    MessageConstant.TEXT_SCORE_PHOTOS,
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.secondaryTextColor,
                                        14,
                                        FontType.Regular),
                                  ))
                              :     Container(
                                  height: 0.0,
                                ),
                              Container(
                              padding:
                                      EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 0.0),
                              child:     GridView.count(
                                  primary: false,
                                  shrinkWrap: true,
                                  padding: const EdgeInsets.all(0.0),
                                  crossAxisSpacing: 10.0,
                                  childAspectRatio: 1.50,
                                  scrollDirection: Axis.vertical,
                                  crossAxisCount: 3,
                                  children:     List.generate(
                                      testModel.imgList.length, (int index2) {
                                    return InkWell(
                                      onTap: (){
                                        Navigator.of(context).push(new MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                CommonFullViewWidget(
                                                testModel
                                                    .imgList,
                                                MessageConstant
                                                    .TEST_SCORE_HEDING,
                                                index2,
                                                MessageConstant
                                                    .TEST_SCORE_HEDING)));
                                      },
                                      child:     Container(
                                          height: 60.0,
                                          child:     Stack(
                                            children: <Widget>[
                                                  Positioned(
                                                top: 5.0,
                                                child:     Column(
                                                  children: <Widget>[
                                                    FadeInImage.assetNetwork(
                                                      fit: BoxFit.cover,
                                                      placeholder:
                                                          'assets/aerial/default_img.png',
                                                      image: Constant
                                                              .IMAGE_PATH +
                                                          testModel
                                                              .imgList[index2],
                                                      height: 50.0,
                                                      width: 75.0,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        0.0, 5, 0, 0),
                                                child:     Container(
                                                  height: 50.0,
                                                  width: 75.0,
                                                  color:     Color(0XFFC0C0C0)
                                                      .withOpacity(.4),
                                                ),
                                              ),
                                            ],
                                          )),
                                    );
                                  })


                                  )),
                        ],
                      ),
                      flex: 1,
                    )
                  ],
                ))));
  }
}
