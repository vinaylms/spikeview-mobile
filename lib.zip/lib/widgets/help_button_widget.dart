import 'package:flutter/material.dart';
import 'package:spike_view_project/common/help_view.dart';

class HelpButtonWidget extends StatelessWidget {
  const HelpButtonWidget();

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => HelpView(),
            ),
        );
      },
      child: Image.asset(
        "assets/generateScript/help.png",
        height: 32,
        width: 32,
      ),
    );
  }
}
