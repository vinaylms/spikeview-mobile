import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'Util.dart';

class BaseCommonWidget {

  textInputDecorationCommon(
      String name, String icon, double height, double width, String hint) {
    return InputDecoration(
      hintMaxLines: 2,
      contentPadding: const EdgeInsets.fromLTRB(0.0, 7.0, 5.0, 10.0),counterText: "",
      focusedBorder:  UnderlineInputBorder(
          borderSide:  BorderSide(
              color:  ColorValues.DARK_GREY, width: 1.0)),
      enabledBorder:  UnderlineInputBorder(
          borderSide:  BorderSide(
              color:  ColorValues.DARK_GREY, width: 1.0)),
      border:  UnderlineInputBorder(
          borderSide:  BorderSide(
              color:  ColorValues.DARK_GREY, width: 1.0)),
      labelText: name,
      hintText: hint,
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      errorStyle: Util.errorTextStyle,
      errorMaxLines: 3,
      labelStyle:  TextStyle(
          color: Colors.grey, fontFamily: Constant.TYPE_CUSTOMREGULAR),
    );
  }



  static textFormFieldDecorationForErrorStyle(String lableText, String hintText, String error) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        5.0,
      ),
      labelText: lableText,
      hintText: hintText,
      errorStyle: Util.errorTextStyle,
      counterText: "",
      errorText: error,
      focusedBorder:     UnderlineInputBorder(
          borderSide:     BorderSide(
              color:     ColorValues.DARK_GREY, width: 1.0)),
      enabledBorder:     UnderlineInputBorder(
          borderSide:     BorderSide(
              color:     ColorValues.DARK_GREY, width: 1.0)),
      border:     UnderlineInputBorder(
          borderSide:     BorderSide(
              color:     ColorValues.DARK_GREY, width: 1.0)),
      fillColor: Colors.transparent,
      counterStyle:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),

    );
  }

  static textFormFieldDecorationAddTest(String lableText, String hintText, String error,var lable_size) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        5.0,
      ),
      labelText: lableText,
      hintText: hintText,
      errorStyle: Util.errorTextStyle,
      counterText: "",
      errorText: error,
      labelStyle:    AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,lable_size,FontType.Regular ),
      disabledBorder:     UnderlineInputBorder(
          borderSide:     BorderSide(
              color:     ColorValues.DARK_GREY,width: 1.0)),
      enabledBorder:     UnderlineInputBorder(
          borderSide:     BorderSide(
              color:     ColorValues.DARK_GREY,width: 1.0)),
      focusedBorder:     UnderlineInputBorder(
          borderSide:     BorderSide(
              color:     ColorValues.DARK_GREY, width: 1.0)),
      border:     UnderlineInputBorder(
          borderSide:     BorderSide(
              color:     ColorValues.DARK_GREY, width: 1.0)),
      fillColor: Colors.transparent,
      counterStyle:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),

    );
  }

  textFormFieldDecorationWithHint(
      String name, String icon, double height, double width, String hint) {
    return  InputDecoration(
      labelText: name,
      counterText: "",
      hintText: hint,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 0.0),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 15, FontType.Regular),
      errorStyle: TextStyle(fontFamily: AppTextStyle.getFont(FontType.Regular)),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),

    );
  }



  textFormFieldDecorationWithHintWithNewDesign(
      String name, String icon, double height, double width, String hint) {
    return  InputDecoration(
      counterText: "",
      hintText: hint,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      contentPadding: EdgeInsets.zero,
      hintStyle: AppTextStyle.getDynamicFontStyle(Palette.primaryTextColor, 16, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(Palette.secondaryTextNewColor, 14, FontType.Regular),
      errorStyle: TextStyle(fontFamily: AppTextStyle.getFont(FontType.Regular)),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),

    );
  }


  textFormFieldDecorationNewSignUp(
      String name, String icon, double height, double width, String hint) {
    return  InputDecoration(
      hintText: hint,
      counterText: "",counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      contentPadding: EdgeInsets.zero,
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.primaryTextColor, 16, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextNewColor, 14, FontType.Regular),
      errorStyle: TextStyle(fontFamily: AppTextStyle.getFont(FontType.Regular)),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),

    );
  }

  textFormFieldDecorationWithIcon(
      String name, String icon, double height, double width) {
    return  InputDecoration(
      labelText: name,
      counterText: "",counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      contentPadding: EdgeInsets.zero,
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 15, FontType.Regular),
      errorStyle: TextStyle(fontFamily: AppTextStyle.getFont(FontType.Regular)),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),

    );
  }
  textFormFieldDecorationWithIconhelpertextWithNewSignup(
      String name, String icon, double height, double width, String hint) {
    return  InputDecoration(

      counterText: "",
      hintMaxLines: 2,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      hintText: hint,
      contentPadding: EdgeInsets.zero,
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.primaryTextColor, 16, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextNewColor, 14, FontType.Regular),
      errorStyle: TextStyle(fontFamily: AppTextStyle.getFont(FontType.Regular)),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),

    );
  }

  textFormFieldDecorationBlueColor(
      String name, String icon, double height, double width, String hint) {
    return  InputDecoration(

      counterText: "",
      hintMaxLines: 2,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      hintText: hint,
      contentPadding: EdgeInsets.zero,
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.accentColor, 16, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.accentColor, 13, FontType.Regular),
      errorStyle: TextStyle(fontFamily: AppTextStyle.getFont(FontType.Regular)),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),

    );
  }

  textFormFieldDecorationWithIconhelpertext(
      String name, String icon, double height, double width) {
    return  InputDecoration(
      labelText: name,
      counterText: "",
      hintMaxLines: 2,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      hintText:
      "We are a premier tutoring service specializing in Advanced Math, Science and CS",
      contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 0.0),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 15, FontType.Regular),
      errorStyle: TextStyle(fontFamily: AppTextStyle.getFont(FontType.Regular)),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),

    );
  }

  static textFormFieldDecorationAddEducation(
      String labelText, String hintText) {
    return    InputDecoration(
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(
            color: ColorValues.DARK_GREY, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(
            color: ColorValues.DARK_GREY, width: 1.0),
      ),
      hintText: hintText,
      errorStyle:Util.errorTextStyle,
      contentPadding:   EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
      labelText: labelText,
      labelStyle:   TextStyle(
          color:   ColorValues.GREY_TEXT_COLOR,
          fontFamily:Constant.TYPE_CUSTOMREGULAR),
      counterText: "",
      fillColor: Colors.transparent,

    );
  }



  textFormFieldDecorationWithLabel(String name, {String helperText,String hintText,int hintLine}) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        0.0,
      ),
      labelText: name,
      counterText: "",
      errorMaxLines: 2,hintText: hintText,
      helperText: helperText,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      helperStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 16, FontType.Regular),

      errorStyle: TextStyle(
          fontFamily: AppTextStyle.getFont(FontType.Regular),
          color: Palette.redColor),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
    );
  }
  textFormFieldDecorationWithLabelStats(String name, {String helperText,String hintText,int hintLine}) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        0.0,
      ),
      labelText: name,
      counterText: "",
      errorMaxLines: 2,hintText: hintText,
      helperText: helperText,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      helperStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
      errorStyle: TextStyle(
          fontFamily: AppTextStyle.getFont(FontType.Regular),
          color: Palette.redColor),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
    );
  }

  static textFormFieldDecorationAchievment(String name, String hintText) {
    return InputDecoration(
      counterText: "",
      labelText: name,
      hintText: hintText,
      errorStyle: Util.errorTextStyle,
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        5.0,
      ),
      enabledBorder: UnderlineInputBorder(
        borderSide:
        BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
      ),
      hintStyle:  TextStyle(
          color:  ColorValues.GREY_TEXT_COLOR,
          fontFamily: Constant.TYPE_CUSTOMREGULAR,
          fontSize: 16),
      focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(
              color: ColorValues.DARK_GREY, width: 1.0)),
      labelStyle:  TextStyle(
          color:  ColorValues.GREY_TEXT_COLOR,
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
      fillColor: Colors.transparent,
    );
  }

  textFormFieldDecorationWithCounterText(String name, {String helperText}) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        0.0,
      ),
      labelText: name,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),

      errorStyle: TextStyle(
          fontFamily: AppTextStyle.getFont(FontType.Regular),
          color: Palette.redColor),
      hintText: helperText != null || helperText != ""
          ? helperText
          : 'Add the job description, key responsibilities, required skills here',
      helperStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 15, FontType.Regular),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
    );
  }

  textFormFieldDecorationWithNoBorders1(String name, {String helperText}) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        0.0,
      ),
      labelText: name,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      counterText: "",
      errorMaxLines: 3,
      errorStyle: TextStyle(
          fontFamily: AppTextStyle.getFont(FontType.Regular),
          color: Palette.redColor),
      hintText: helperText != null || helperText != ""
          ? helperText
          : 'Add the job description, key responsibilities, required skills here',
      helperStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 15, FontType.Regular),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
    );
  }


  static textFormFieldDecorationAccomplishment(String lableText, String hintText) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        5.0,
      ),
      labelText: lableText,
      hintText: hintText,
      errorStyle: Util.errorTextStyle,
      counterText: "",
      labelStyle: AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,null,FontType.Regular ),
      fillColor: Colors.transparent,
      enabledBorder: UnderlineInputBorder(
        borderSide:
        BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
      ),
      counterStyle:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
      focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(
              color: ColorValues.DARK_GREY, width: 1.0)),

    );
  }

  textFormFieldDecorationWithNoBorders11(String name, {String helperText}) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        0.0,
      ),
      labelText: name,counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      counterText: "",
      errorStyle: TextStyle(
          fontFamily: AppTextStyle.getFont(FontType.Regular),
          color: Palette.redColor),
      hintText: helperText != null || helperText != ""
          ? helperText
          : 'Add the job description, key responsibilities, required skills here',
      helperStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 9, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 15, FontType.Regular),
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
      border: UnderlineInputBorder(
        borderSide: BorderSide(color: Palette.dividerColor, width: 1.0),
      ),
    );
  }

  textFormFieldDecorationWithNoBorders(String name, {String helperText}) {
    return InputDecoration(
      contentPadding: const EdgeInsets.fromLTRB(
        0.0,
        5.0,
        5.0,
        5.0,
      ),
      labelText: name,
      counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
      errorStyle: TextStyle(
          fontFamily: AppTextStyle.getFont(FontType.Regular),
          color: Palette.redColor),
      helperText: helperText,
      helperStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 12, FontType.Regular),
      hintStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
      labelStyle: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 15, FontType.Regular),
      enabledBorder: InputBorder.none,
      focusedBorder: InputBorder.none,
      border: InputBorder.none,
    );
  }

  textFormFieldValueStyle() {
    return AppTextStyle.getDynamicFontStyle(
        Palette.primaryTextColor, 16, FontType.Regular);
  }


  backIcon(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0.0, 0.0, 25.0, 0.0),
      child: IconButton(
          icon: Image.asset(
            ImagePath.ICON_BACK,
            color: Palette.primaryTextColor,
            height: 20,
            width: 10,
          ),
          onPressed: () {
            Navigator.pop(context);
          }),
    );
  }

  circleWithCenterText(String text, Color primaryColor, Color circleColor) {
    return  Container(
        height: UIHelper.circleTabSize,
        width: UIHelper.circleTabSize,
        decoration:  BoxDecoration(
          color: Colors.white,
          borderRadius:
          BorderRadius.all(Radius.circular(UIHelper.circleTabSize / 2)),
          border: Border.all(color: circleColor, width: 1.0),
        ),
        child:  Center(
          child: Text(
            text,
            style: AppTextStyle.getDynamicFontStyle(
                primaryColor, 16, FontType.Regular),
          ),
        ));
  }

  circleWithCenterIcon(String iconAssetPath, Color primaryColor) {
    return Image.asset(
      iconAssetPath,
      color: primaryColor,
      width: UIHelper.circleNextPreviousSize,
      height: UIHelper.circleNextPreviousSize,
    );
  }

  customHeaderText(
      String title, String headerImage, double height, double width) {
    return Expanded(
      child: Container(
        height: double.infinity,
        alignment: Alignment.center,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              headerImage,
              height: height,
              width: width,
            ),
            Text(
              title,
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.primaryTextColor, 28, FontType.Regular),
            ),
          ],
        ),
      ),
    );
  }

  addMediaFileIconWidget(double width) {
    return Container(
      height: 54,
      width: width,
      decoration: rectangleDecoration(),
      margin: EdgeInsets.only(left: 5, right: 5),
      child: Image.asset(
        ImagePath.ICON_ADD_CIRCLE,
        height: 36.77,
        width: 37.77,
      ),
    );
  }

  showMediaFileWidget(double width, File image) {
    return Container(
      height: 54,
      width: width,
      decoration: rectangleDecoration(),
      margin: EdgeInsets.only(left: 0, right: 0),
      child: Image.file(
        image,
        fit: BoxFit.contain,
      ),
    );
  }

  showMediaFileWidget1(double width, File image) {
    return Container(
      height: 80.0,
      width: 140.0,
      decoration: rectangleDecoration(),
      margin: EdgeInsets.only(left: 0, right: 0),
      child: Image.file(
        image,
        fit: BoxFit.contain,
      ),
    );
  }

  showUrlMediaWidget(double width, String url) {
    return Container(
      height: 54,
      width: width,
      decoration: rectangleDecoration(),
      margin: EdgeInsets.only(left: 5, right: 5),
      child: Image.network(
        url,
        fit: BoxFit.contain,
      ),
    );
  }

  showMediaFileIconWidget(double width, Icon image) {
    return Container(
      height: 54,
      width: width,
      decoration: rectangleDecoration(),
      // padding: EdgeInsets.all(5),
      margin: EdgeInsets.only(left: 5, right: 5),
      child: image,
    );
  }

  bottomBorderDynamic(Color colorValue) {
    return BoxDecoration(border: Border(bottom: BorderSide(color: colorValue)));
  }

  bottomBorder() {
    return BoxDecoration(
        border: Border(bottom: BorderSide(color: Palette.dividerColor)));
  }

  mediaLabelNewColorText(String label) {
    return Text(
      label,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextNewColor, 14, FontType.Regular),
    );
  }

  rectangleDecoration() {
    return BoxDecoration(
        border: Border.all(color: Palette.dividerColor), color: Colors.white);
  }

  rectangleDecorationWithDynamicColor(Color webColor) {
    return BoxDecoration(

        border: Border.all(color: Palette.dividerColor), color: webColor);
  }


  rectangleDecorationWithDynamicColor2(Color webColor) {
    return BoxDecoration(
        borderRadius: BorderRadius.circular(15.0),
        border: Border.all(color: Palette.dividerColor), color: webColor);
  }

  colorIcon(String image, double height, double width) {
    return Image.asset(
      image,
      width: height,
      height: width,
    );
  }

  docNameLabelText(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0.0),
      child: Text(
        label,
        style: AppTextStyle.getDynamicFontStyle(Palette.secondaryTextColor, 10, FontType.Regular),
        maxLines: 1,
        overflow: TextOverflow.visible,
      ),
    );
  }


  mediaLabelText(String label) {
    return Text(
      label,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
    );
  }

  mediaLabelTextNew(String label) {
    return Text(
      label,
      style: TextStyle(
          color:  ColorValues.labelColor,
          fontWeight: FontWeight.w600,
          fontSize: 12.0,
          fontFamily: Constant.latoMedium),
    );
  }

  mediaLabelTextBold(String label) {
    return Text(
      label,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Bold),
    );
  }

  checkBoxLabelText(String label) {
    return Expanded(
      child: Text(
        label,
        style:TextStyle(
            color:  ColorValues.labelColor,
            fontWeight: FontWeight.w600,
            fontSize: 14.0,
            fontFamily: Constant.latoMedium),
      ),
    );
  }

  checkBoxLabelText1(String label) {
    return Expanded(
      child: Text(
        label,
        style: AppTextStyle.getDynamicFontStyle(
            Palette.primaryTextColor, 14, FontType.Regular),
      ),
    );
  }

  customCheckBox(bool isChecked) {
    return Image.asset(
      isChecked ? ImagePath.ICON_CHECKED : ImagePath.ICON_UNCHECKED,
      height: 20,
      width: 20,
      color: Palette.primaryTextColor,
    );
  }

  customRadioButton(bool isChecked) {
    return Image.asset(
        isChecked ? ImagePath.ICON_CHECKED_RADIO : ImagePath.ICON_UNCHECKED_RADIO,
        height: 22,
        width: 22);
  }

  activeInactiveSwitch(bool isChecked) {
    return Image.asset(
      isChecked ? ImagePath.ICON_ACTIVE : ImagePath.ICON_DEACTIVATE,
      height: 24,
      width: 42,
    );
  }

  void conformationDialogForBackNavigation(context, back, pageName) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.fromLTRB(
                                                15.0, 10.0, 15.0, 10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Are you sure you want to discard all changes?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontWeight: FontWeight.w400,
                                                        fontFamily:
                                                        Constant.latoRegular),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                        Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                                      fontSize: 16.0,
                                                      fontWeight: FontWeight.w500,
                                                      fontFamily:Constant.latoRegular),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "OK",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                                      fontSize: 16.0,
                                                      fontWeight: FontWeight.w500,
                                                      fontFamily:Constant.latoRegular),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              if (back == "back") {
                                                Navigator.pop(context);
                                              } else {
                                                if (pageName == "Login") {
                                                  Navigator.of(context)
                                                      .popUntil((route) =>
                                                  route.isFirst);
                                                } else {
                                                  Navigator.of(context)
                                                      .popUntil((route) =>
                                                  route.isFirst);
                                                  Navigator.of(context)
                                                      .pushReplacement(
                                                      MaterialPageRoute(
                                                          builder: (BuildContext
                                                          context) =>
                                                              LoginPage(
                                                                  null)));
                                                }

                                              }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  alreadyHaveAccountWidget(BuildContext context, bool isShowDialog, pageName) {
    return Container(
      // color: Palette.primaryTextColor,
      padding: EdgeInsets.only(left: 4.0, right: 4.0),
      height: 60.0 + MediaQuery.of(context).padding.bottom,
      child:  Container(
          padding:  EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 0.0),
          child:  Row(
            children: <Widget>[
              Expanded(
                child:  Text("Already have an account?",
                    style:  TextStyle(
                        color: Palette.secondaryTextColor,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                flex: 1,
              ),
              Expanded(
                child:  InkWell(
                  child:  Text("Sign in",
                      style:  TextStyle(
                          color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                          fontSize: 14.0,
                          fontFamily: Constant.TYPE_CUSTOMBOLD)),
                  onTap: () {
                    if (isShowDialog) {
                      conformationDialogForBackNavigation(
                          context, "", pageName);
                    } else {
                      Navigator.of(context).popUntil((route) => route.isFirst);

                    }
                  },
                ),
                flex: 0,
              )
            ],
          )),
    );
  }

  introTitleTest(String text) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.primaryTextColor, 16, FontType.Regular),
    );
  }

  introSubTitleTest(String text) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
    );
  }

  introBottomText(String text) {
    return Center(
      child: Text(
        text.toUpperCase(),
        style: AppTextStyle.getDynamicFontStyle(
            Palette.accentColor, 16, FontType.Regular),
      ),
    );
  }

  showCircularProgressDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return Center(child: CircularProgressIndicator());
      },
    );
  }

  showToastMessage(String message) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIos: 1,
        backgroundColor: Colors.black,
        textColor: Palette.white,
        fontSize: 16.0);
  }
}
